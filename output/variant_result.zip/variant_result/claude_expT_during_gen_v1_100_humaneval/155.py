def even_odd_count(num):
    """Given an integer, return a tuple that has the number of even and odd digits respectively.

     Example:
        even_odd_count(-12) ==> (1, 1)
        even_odd_count(123) ==> (1, 2)
    """
    # Process absolute value to handle negative numbers
    absolute_num = abs(num)
    
    # Convert to string to iterate through digits
    digit_string = str(absolute_num)
    
    # Initialize counters
    even_tally = 0
    odd_tally = 0
    
    # Process each digit
    for digit_char in digit_string:
        digit_value = int(digit_char)
        
        # Determine if digit is even or odd
        if digit_value % 2 == 0:
            even_tally += 1
        else:
            odd_tally += 1
    
    # Deliver results as tuple
    return (even_tally, odd_tally)