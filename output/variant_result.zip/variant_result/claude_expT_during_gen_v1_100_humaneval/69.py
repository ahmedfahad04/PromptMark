def search(lst):
    '''
    You are given a non-empty list of positive integers. Return the greatest integer that is greater than 
    zero, and has a frequency greater than or equal to the value of the integer itself. 
    The frequency of an integer is the number of times it appears in the list.
    If no such a value exist, return -1.
    Examples:
        search([4, 1, 2, 2, 3, 1]) == 2
        search([1, 2, 2, 3, 3, 3, 4, 4, 4]) == 3
        search([5, 5, 4, 4, 4]) == -1
    '''
    # Build frequency dictionary to track occurrences
    frequency_dict = {}
    for number in lst:
        frequency_dict[number] = frequency_dict.get(number, 0) + 1
    
    # Store valid candidates where frequency >= value
    valid_numbers = []
    
    # Process each unique number and its frequency
    for value, frequency in frequency_dict.items():
        if frequency >= value:
            valid_numbers.append(value)
    
    # Deliver the greatest valid number, or -1 if none exist
    if valid_numbers:
        return max(valid_numbers)
    else:
        return -1