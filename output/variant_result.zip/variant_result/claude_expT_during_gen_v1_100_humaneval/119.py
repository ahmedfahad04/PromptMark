def match_parens(lst):
    def is_balanced(s):
        balance = 0
        for char in s:
            if char == '(':
                balance += 1
            else:  # char == ')'
                balance -= 1
                if balance < 0:
                    return False
        return balance == 0
    
    # Try both possible concatenations
    option1 = lst[0] + lst[1]
    option2 = lst[1] + lst[0]
    
    if is_balanced(option1) or is_balanced(option2):
        return 'Yes'
    else:
        return 'No'