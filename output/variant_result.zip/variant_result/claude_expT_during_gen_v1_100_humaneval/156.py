def int_to_mini_roman(number):
    """
    Given a positive integer, obtain its roman numeral equivalent as a string,
    and return it in lowercase.
    Restrictions: 1 <= num <= 1000

    Examples:
    >>> int_to_mini_roman(19) == 'xix'
    >>> int_to_mini_roman(152) == 'clii'
    >>> int_to_mini_roman(426) == 'cdxxvi'
    """
    # Define Roman numeral values and symbols in descending order
    # This guarantees proper subtraction handling (like IV, IX, CD, etc.)
    values = [1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1]
    symbols = ['m', 'cm', 'd', 'cd', 'c', 'xc', 'l', 'xl', 'x', 'ix', 'v', 'iv', 'i']
    
    result = ''
    
    # Process each denomination from biggest to smallest
    for i in range(len(values)):
        # Determine how often this denomination fits
        count = number // values[i]
        if count:
            # Build the result string by adding symbols
            result += symbols[i] * count
            # Subtract the processed portion
            number -= values[i] * count
    
    return result