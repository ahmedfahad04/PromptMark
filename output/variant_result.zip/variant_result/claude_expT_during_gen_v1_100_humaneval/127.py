def intersection(interval1, interval2):
    """Determines if the length of intersection between two intervals is prime."""
    
    def is_prime(n):
        """Check if a number is prime."""
        if n < 2:
            return False
        if n == 2:
            return True
        if n % 2 == 0:
            return False
        for i in range(3, int(n**0.5) + 1, 2):
            if n % i == 0:
                return False
        return True
    
    # Extract start and end points
    start1, end1 = interval1
    start2, end2 = interval2
    
    # Find intersection boundaries
    intersection_start = max(start1, start2)
    intersection_end = min(end1, end2)
    
    # Check if intervals don't intersect
    if intersection_start > intersection_end:
        return "NO"
    
    # Calculate length of intersection
    length = intersection_end - intersection_start
    
    # Check if length is prime
    if is_prime(length):
        return "YES"
    else:
        return "NO"