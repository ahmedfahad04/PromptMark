from typing import List


def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    """ Insert a number 'delimeter' between every two consecutive elements of input list `numbers'
    >>> intersperse([], 4)
    []
    >>> intersperse([1, 2, 3], 4)
    [1, 4, 2, 4, 3]
    """
    # Basic bounds check - empty lists produce empty output
    if not numbers:
        return []
    
    # Build solution progressively 
    solution = [numbers[0]]  # Start with the first element
    
    # Process each subsequent element
    for digit in numbers[1:]:
        solution.append(delimeter)  # Add the separator
        solution.append(digit)      # Add the next digit
    
    return solution