def numerical_letter_grade(grades):
    """
    Transform GPA scores into letter grades using predefined boundaries.
    
    Takes a list of numerical grades and outputs corresponding letter grades
    based on standard academic grading thresholds.
    """
    
    # Define grade boundaries - structured for simple threshold checking
    grade_boundaries = [
        (4.0, 'A+'),    # Exactly 4.0
        (3.7, 'A'),     # Greater than 3.7
        (3.3, 'A-'),    # Greater than 3.3
        (3.0, 'B+'),    # Greater than 3.0
        (2.7, 'B'),     # Greater than 2.7
        (2.3, 'B-'),    # Greater than 2.3
        (2.0, 'C+'),    # Greater than 2.0
        (1.7, 'C'),     # Greater than 1.7
        (1.3, 'C-'),    # Greater than 1.3
        (1.0, 'D+'),    # Greater than 1.0
        (0.7, 'D'),     # Greater than 0.7
        (0.0, 'D-'),    # Greater than 0.0
    ]
    
    def single_grade_transform(gpa):
        # Special case: perfect score
        if gpa == 4.0:
            return 'A+'
        
        # Special case: bottom threshold
        if gpa == 0.0:
            return 'E'
        
        # Check boundaries from top to bottom
        for threshold, letter in grade_boundaries[1:]:  # Skip first (4.0) since handled above
            if gpa > threshold:
                return letter
        
        # Default case (should not be reached with proper boundaries)
        return 'E'
    
    # Transform each grade through the boundary system
    transformed_grades = []
    for gpa in grades:
        transformed_grades.append(single_grade_transform(gpa))
    
    return transformed_grades