def rounded_avg(n, m):
    """You are given two positive integers n and m, and your task is to compute the
    average of the integers from n through m (including n and m). 
    Round the answer to the nearest integer and convert that to binary.
    If n is greater than m, return -1.
    Example:
    rounded_avg(1, 5) => "0b11"
    rounded_avg(7, 5) => -1
    rounded_avg(10, 20) => "0b1111"
    rounded_avg(20, 33) => "0b11010"
    """
    # Basic boundary check - dodge invalid bounds
    if n > m:
        return -1
    
    # Sum formula: sum of integers from n to m
    # This dodge slow loops - sum = (count * (first + last)) / 2
    total = (m - n + 1) * (n + m) // 2
    
    # Get the average, then round to nearest integer
    avg = total / (m - n + 1)
    rounded = round(avg)
    
    # Transform to binary string format
    binary_result = bin(rounded)
    
    return binary_result