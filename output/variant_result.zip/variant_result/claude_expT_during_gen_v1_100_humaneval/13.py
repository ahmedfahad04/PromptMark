def greatest_common_divisor(a: int, b: int) -> int:
    """ Return a greatest common divisor of two integers a and b
    >>> greatest_common_divisor(3, 5)
    1
    >>> greatest_common_divisor(25, 15)
    5
    """
    # Take absolute values to handle negative integers
    a, b = abs(a), abs(b)
    
    # Euclidean algorithm: repeatedly divide and take remainder
    while b != 0:
        a, b = b, a % b
    
    return a