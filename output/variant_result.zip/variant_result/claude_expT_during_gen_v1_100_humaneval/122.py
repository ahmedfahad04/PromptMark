def add_elements(arr, k):
    """
    Given a non-empty array of integers arr and an integer k, return
    the sum of the elements with at most two digits from the first k elements of arr.
    """
    # Select first k elements from the sequence
    subset = arr[:k]
    
    # Build list of elements with at most two digits
    # Two digits means: -99 <= number <= 99
    suitable_elements = []
    for element in subset:
        if -99 <= element <= 99:
            suitable_elements.append(element)
    
    # Sum all suitable elements
    total = sum(suitable_elements)
    
    return total