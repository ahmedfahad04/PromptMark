def choose_num(x, y):
    """This function takes two positive numbers x and y and returns the
    biggest even integer number that is in the range [x, y] inclusive. If 
    there's no such number, then the function should return -1.

    For example:
    choose_num(12, 15) = 14
    choose_num(13, 12) = -1
    """
    # Check if range is valid
    if x > y:
        return -1
    
    # Start from the biggest possible number (y) and go backwards
    # If y is even, return it directly
    if y % 2 == 0:
        return y
    
    # If y is odd, check if y-1 is still in range and return it
    if y - 1 >= x:
        return y - 1
    
    # No even number found in range
    return -1