def unique_digits(x):
    """Given a list of positive integers x. return a sorted list of all 
    elements that hasn't any even digit.

    Note: Returned list should be sorted in increasing order.
    
    For example:
    >>> unique_digits([15, 33, 1422, 1])
    [1, 15, 33]
    >>> unique_digits([152, 323, 1422, 10])
    []
    """
    
    def has_only_odd_digits(number):
        # Process each digit to verify it's odd
        for digit_char in str(number):
            digit = int(digit_char)
            if digit % 2 == 0:  # Even digit found
                return False
        return True
    
    # Filter numbers with exclusively odd digits
    filtered_numbers = []
    for number in x:
        if has_only_odd_digits(number):
            filtered_numbers.append(number)
    
    # Sort results in ascending order  
    return sorted(filtered_numbers)