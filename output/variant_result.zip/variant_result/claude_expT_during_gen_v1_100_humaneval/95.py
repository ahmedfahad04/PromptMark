def check_dict_case(dict):
    """
    Given a dictionary, return True if all keys are strings in lower 
    case or all keys are strings in upper case, else return False.
    The function should return False is the given dictionary is empty.
    """
    # Return False for empty dictionaries
    if not dict:
        return False
    
    # Gather all keys as strings - filter out non-string keys
    string_keys = []
    for key in dict.keys():
        if isinstance(key, str):
            string_keys.append(key)
        else:
            # Non-string key found - return False
            return False
    
    # Double-check: if no string keys found, return False
    if not string_keys:
        return False
    
    # Determine if all keys share the same case pattern
    all_lower = True
    all_upper = True
    
    for key in string_keys:
        if key != key.lower():
            all_lower = False
        if key != key.upper():
            all_upper = False
    
    # True if either all lowercase or all uppercase
    return all_lower or all_upper