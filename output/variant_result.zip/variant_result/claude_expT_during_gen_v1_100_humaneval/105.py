def by_length(arr):
    # Filter digits between 1 and 9 inclusive
    filtered_digits = [num for num in arr if 1 <= num <= 9]
    
    # Sort the filtered digits
    filtered_digits.sort()
    
    # Reverse the sorted sequence
    filtered_digits.reverse()
    
    # Dictionary to transform digits to their textual forms
    digit_names = {
        1: "One", 2: "Two", 3: "Three", 4: "Four", 5: "Five",
        6: "Six", 7: "Seven", 8: "Eight", 9: "Nine"
    }
    
    # Transform each digit to its corresponding textual form
    return [digit_names[digit] for digit in filtered_digits]