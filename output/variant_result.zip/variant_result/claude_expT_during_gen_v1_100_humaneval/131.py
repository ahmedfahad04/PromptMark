def digits(n):
    """Given a positive integer n, return the product of the odd digits.
    Return 0 if all digits are even.
    For example:
    digits(1)  == 1
    digits(4)  == 0
    digits(235) == 15
    """
    product = 1
    found_odd = False
    
    # Process each digit by converting to string
    for digit_char in str(n):
        digit = int(digit_char)
        
        # Check if digit is odd
        if digit % 2 == 1:
            product *= digit
            found_odd = True
    
    # Return 0 if no odd digits found, otherwise return product
    return product if found_odd else 0