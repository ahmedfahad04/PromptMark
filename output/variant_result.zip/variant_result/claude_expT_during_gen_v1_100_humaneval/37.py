def sort_even(l: list):
    """This function takes a list l and returns a list l' such that
    l' is identical to l in the odd indicies, while its values at the even indicies are equal
    to the values of the even indicies of l, but sorted.
    >>> sort_even([1, 2, 3])
    [1, 2, 3]
    >>> sort_even([5, 6, 3, 4])
    [3, 6, 5, 4]
    """
    # Build duplicate list to preserve original structure
    duplicate = l.copy()
    
    # Gather elements positioned at even indices
    elements_at_evens = [l[i] for i in range(0, len(l), 2)]
    
    # Sort gathered elements 
    sorted_elements = sorted(elements_at_evens)
    
    # Place sorted elements back at even positions
    position = 0
    for i in range(0, len(l), 2):
        duplicate[i] = sorted_elements[position]
        position += 1
    
    # Done - duplicate holds final solution
    return duplicate