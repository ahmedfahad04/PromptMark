def fix_spaces(text):
    """
    Given a string text, replace all spaces in it with underscores, 
    and if a string has more than 2 consecutive spaces, 
    then replace all consecutive spaces with - 
    
    fix_spaces("Example") == "Example"
    fix_spaces("Example 1") == "Example_1"
    fix_spaces(" Example 2") == "_Example_2"
    fix_spaces(" Example   3") == "_Example-3"
    """
    result = ""
    space_count = 0
    
    for character in text:
        if character == ' ':
            space_count += 1
        else:
            # Process accumulated spaces before adding the current character
            if space_count > 0:
                if space_count <= 2:
                    result += '_' * space_count
                else:
                    result += '-'
                space_count = 0
            result += character
    
    # Handle trailing spaces
    if space_count > 0:
        if space_count <= 2:
            result += '_' * space_count
        else:
            result += '-'
    
    return result