def count_upper(s):
    """
    Given a string s, count the number of uppercase vowels in even indices.
    
    For example:
    count_upper('aBCdEf') returns 1
    count_upper('abcdefg') returns 0
    count_upper('dBBE') returns 0
    """
    uppercase_vowels = {'A', 'E', 'I', 'O', 'U'}
    total = 0
    
    # Check characters at even positions (0, 2, 4, ...)
    for position in range(0, len(s), 2):
        if s[position] in uppercase_vowels:
            total += 1
    
    return total