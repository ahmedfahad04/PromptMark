def digitSum(s):
    """Task
    Write a function that takes a string as input and returns the sum of the upper characters only'
    ASCII codes.

    Examples:
        digitSum("") => 0
        digitSum("abAB") => 131
        digitSum("abcCd") => 67
        digitSum("helloE") => 69
        digitSum("woArBld") => 131
        digitSum("aAaaaXa") => 153
    """
    total = 0
    
    # Process each character in the string
    for character in s:
        # Check if character is uppercase
        if character.isupper():
            # Sum the ASCII value using ord() builtin
            total += ord(character)
    
    return total