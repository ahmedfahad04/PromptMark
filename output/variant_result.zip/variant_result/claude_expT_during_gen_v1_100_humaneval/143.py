def words_in_sentence(sentence):
    """
    Returns words from sentence whose lengths are prime numbers.
    Maintains original word order in the output string.
    """
    
    def is_prime(n):
        """Check if a number is prime"""
        if n < 2:
            return False
        if n == 2:
            return True
        if n % 2 == 0:
            return False
        
        # Check odd divisors up to square root
        for i in range(3, int(n**0.5) + 1, 2):
            if n % i == 0:
                return False
        return True
    
    # Split sentence into individual words
    words = sentence.split()
    
    # Filter words with prime lengths
    prime_length_words = []
    for word in words:
        if is_prime(len(word)):
            prime_length_words.append(word)
    
    # Join filtered words back into a string
    return " ".join(prime_length_words)