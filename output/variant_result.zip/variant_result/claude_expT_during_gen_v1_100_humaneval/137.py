def compare_one(a, b):
    """
    Create a function that takes integers, floats, or strings representing
    real numbers, and returns the larger variable in its given variable type.
    Return None if the values are equal.
    Note: If a real number is represented as a string, the floating point might be . or ,
    """
    
    def standardize_decimal(value):
        """Helper function to standardize decimal separators for comparison"""
        if isinstance(value, str):
            # Transform comma decimal separators to dot format
            standardized = value.replace(',', '.')
            return float(standardized)
        return float(value)
    
    # Transform both values to comparable decimal format
    decimal_a = standardize_decimal(a)
    decimal_b = standardize_decimal(b)
    
    # Check if both decimals are identical - return None for ties
    if decimal_a == decimal_b:
        return None
    
    # Determine which original value produces the biggest decimal
    if decimal_a > decimal_b:
        return a
    else:
        return b