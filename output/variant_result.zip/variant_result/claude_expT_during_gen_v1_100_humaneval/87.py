def get_row(lst, x):
    """
    Find all coordinates of value x in a 2D list structure.
    
    Returns list of tuples (row, column) sorted by:
    - Rows in ascending order
    - Columns in descending order within each row
    """
    coordinates = []
    
    # Browse through each row with its index
    for row_index in range(len(lst)):
        current_row = lst[row_index]
        
        # Browse through each element in the current row
        for col_index in range(len(current_row)):
            if current_row[col_index] == x:
                coordinates.append((row_index, col_index))
    
    # Sort by row ascending, then by column descending
    # Key function: (row, -column) to get descending column order
    coordinates.sort(key=lambda coord: (coord[0], -coord[1]))
    
    return coordinates