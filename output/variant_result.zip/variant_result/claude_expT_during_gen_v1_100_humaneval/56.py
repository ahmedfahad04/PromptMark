def correct_bracketing(brackets: str):
    """ brackets is a string of "<" and ">".
    return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("<")
    False
    >>> correct_bracketing("<>")
    True
    >>> correct_bracketing("<<><>>")
    True
    >>> correct_bracketing("><<>")
    False
    """
    balance = 0
    
    for bracket in brackets:
        if bracket == "<":
            balance += 1
        elif bracket == ">":
            balance -= 1
            # Detect premature closing - negative balance indicates 
            # surplus closing brackets without matching openers
            if balance < 0:
                return False
    
    # Proper bracketing demands zero balance - 
    # billions of bracket pairs must be perfectly matched
    return balance == 0