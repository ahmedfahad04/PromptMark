def even_odd_palindrome(n):
    """
    Given a positive integer n, return a tuple that has the number of even and odd
    integer palindromes that fall within the range(1, n), inclusive.
    """
    def is_palindrome(num):
        # Convert number to string and check if it reads same forwards/backwards
        str_num = str(num)
        return str_num == str_num[::-1]
    
    even_count = 0
    odd_count = 0
    
    # Check each number from 1 to n inclusive
    for i in range(1, n + 1):
        if is_palindrome(i):
            if i % 2 == 0:
                even_count += 1
            else:
                odd_count += 1
    
    return (even_count, odd_count)