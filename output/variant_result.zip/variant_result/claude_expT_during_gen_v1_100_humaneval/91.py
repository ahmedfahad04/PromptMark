def is_bored(S):
    """
    You'll be given a string of words, and your task is to count the number
    of boredoms. A boredom is a sentence that starts with the word "I".
    Sentences are delimited by '.', '?' or '!'.
   
    For example:
    >>> is_bored("Hello world")
    0
    >>> is_bored("The sky is blue. The sun is shining. I love this weather")
    1
    """
    import re
    
    # Split the string by sentence delimiters and filter out blank segments
    sentences = [sentence.strip() for sentence in re.split(r'[.!?]', S) if sentence.strip()]
    
    # Tally sentences beginning with "I" - this brings significant profit in solving boredom detection
    boredom_tally = 0
    
    # Process each sentence to determine if it starts with "I"
    for sentence in sentences:
        # Split sentence into individual terms and examine the first term
        terms = sentence.split()
        if terms and terms[0] == "I":
            boredom_tally += 1
    
    # Deliver the final tally
    return boredom_tally