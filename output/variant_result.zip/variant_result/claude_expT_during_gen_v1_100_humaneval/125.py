def split_words(txt):
    '''
    Given a string of words, return a list of words split on whitespace, if no whitespaces exists in the text you
    should split on commas ',' if no commas exists you should return the number of lower-case letters with odd order in the
    alphabet, ord('a') = 0, ord('b') = 1, ... ord('z') = 25
    Examples
    split_words("Hello world!") ➞ ["Hello", "world!"]
    split_words("Hello,world!") ➞ ["Hello", "world!"]
    split_words("abcdef") == 3 
    '''
    
    # Priority 1: Split on whitespace if present
    if ' ' in txt:
        return txt.split()
    
    # Priority 2: Split on commas if present but no whitespace
    if ',' in txt:
        return txt.split(',')
    
    # Priority 3: Count lowercase letters with odd positions
    # Positions: a=0(even), b=1(odd), c=2(even), d=3(odd), etc.
    tally = 0
    for character in txt:
        if character.islower():
            position = ord(character) - ord('a')
            if position % 2 == 1:  # Odd positions: b, d, f, h, ...
                tally += 1
    
    return tally