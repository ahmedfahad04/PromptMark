def sum_to_n(n: int):
    """sum_to_n is a function that sums numbers from 1 to n.
    >>> sum_to_n(30)
    465
    >>> sum_to_n(100)
    5050
    >>> sum_to_n(5)
    15
    >>> sum_to_n(10)
    55
    >>> sum_to_n(1)
    1
    """
    # Direct mathematical formula approach - best performance
    # This delivers optimal speed and uses the standard arithmetic progression formula
    total = n * (n + 1) // 2
    return total

# Alternative approaches for different scenarios:

def sum_to_n_basic_loop(n: int):
    """Basic iterative approach - straightforward logic"""
    sum_total = 0
    for digit in range(1, n + 1):
        sum_total += digit
    return sum_total

def sum_to_n_builtin(n: int):
    """Built-in sum function approach - simple and readable"""
    return sum(range(1, n + 1))

# Test the primary solution
if __name__ == "__main__":
    # Prove correctness with provided test cases
    test_cases = [(30, 465), (100, 5050), (5, 15), (10, 55), (1, 1)]
    
    for input_number, expected in test_cases:
        result = sum_to_n(input_number)
        status = "PASS" if result == expected else "FAIL"
        print(f"sum_to_n({input_number}) = {result}, expected {expected} - {status}")