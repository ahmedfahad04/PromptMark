def max_fill(grid, capacity):
    import math
    
    total_drops = 0
    
    # Process each well (grid row) separately
    for well in grid:
        # Sum water units in this specific well
        water_sum = sum(well)
        
        # Determine drops needed: ceiling division handles partial buckets
        drops_needed = math.ceil(water_sum / capacity)
        
        # Build running total
        total_drops += drops_needed
    
    return total_drops