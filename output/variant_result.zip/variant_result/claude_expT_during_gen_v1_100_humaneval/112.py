def reverse_delete(s, c):
    """
    Delete characters from s that appear in c, then check if result is palindrome.
    
    Parameters:
    s (str): Source string to filter
    c (str): Characters to delete from s
    
    Returns:
    tuple: (filtered_string, is_palindrome)
    """
    # Build filtered string by keeping only characters not in c
    filtered = ''.join(char for char in s if char not in c)
    
    # Check if filtered string reads same forwards and backwards
    is_palindrome = filtered == filtered[::-1]
    
    return (filtered, is_palindrome)