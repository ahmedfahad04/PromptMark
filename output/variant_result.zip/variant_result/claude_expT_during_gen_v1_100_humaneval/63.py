def fibfib(n: int):
    """The FibFib number sequence is a sequence similar to the Fibbonacci sequnece that's defined as follows:
    fibfib(0) == 0
    fibfib(1) == 0
    fibfib(2) == 1
    fibfib(n) == fibfib(n-1) + fibfib(n-2) + fibfib(n-3).
    Please write a function to efficiently compute the n-th element of the fibfib number sequence.
    >>> fibfib(1)
    0
    >>> fibfib(5)
    4
    >>> fibfib(8)
    24
    """
    
    # Handle base cases directly
    if n == 0:
        return 0
    elif n == 1:
        return 0
    elif n == 2:
        return 1
    
    # Build solution progressively using three sliding variables
    # This approach delivers optimal space efficiency
    prev_three = 0  # fibfib(i-3)
    prev_two = 0    # fibfib(i-2)  
    prev_one = 1    # fibfib(i-1)
    
    # Generate sequence from position 3 to n
    for position in range(3, n + 1):
        current = prev_one + prev_two + prev_three
        
        # Slide the window forward
        prev_three = prev_two
        prev_two = prev_one
        prev_one = current
    
    return prev_one