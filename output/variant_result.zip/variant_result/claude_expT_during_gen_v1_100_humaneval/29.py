from typing import List


def filter_by_prefix(strings: List[str], prefix: str) -> List[str]:
    """ Filter an input list of strings only for ones that start with a given prefix.
    >>> filter_by_prefix([], 'a')
    []
    >>> filter_by_prefix(['abc', 'bcd', 'cde', 'array'], 'a')
    ['abc', 'array']
    """
    # Build list containing strings that begin with the desired prefix
    filtered_strings = []
    
    # Process each string in the input list
    for string in strings:
        # Determine if string begins with specified prefix
        if string.startswith(prefix):
            filtered_strings.append(string)
    
    # Provide the filtered results
    return filtered_strings