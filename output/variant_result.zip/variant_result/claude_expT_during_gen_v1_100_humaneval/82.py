def prime_length(string):
    """Write a function that takes a string and returns True if the string
    length is a prime number or False otherwise
    Examples
    prime_length('Hello') == True
    prime_length('abcdcba') == True
    prime_length('kittens') == True
    prime_length('orange') == False
    """
    def is_prime(n):
        # Numbers less than or equal to 1 are not prime
        if n <= 1:
            return False
        # 2 is prime
        if n == 2:
            return True
        # Even numbers greater than 2 are not prime
        if n % 2 == 0:
            return False
        
        # Check odd divisors up to square root of n
        for divisor in range(3, int(n**0.5) + 1, 2):
            if n % divisor == 0:
                return False
        return True
    
    length = len(string)
    return is_prime(length)