def count_up_to(n):
    """Implement a function that takes an non-negative integer and returns an array of the first n
    integers that are prime numbers and less than n.
    for example:
    count_up_to(5) => [2,3]
    count_up_to(11) => [2,3,5,7]
    count_up_to(0) => []
    count_up_to(20) => [2,3,5,7,11,13,17,19]
    count_up_to(1) => []
    count_up_to(18) => [2,3,5,7,11,13,17]
    """
    if n <= 2:
        return []
    
    # Build sieve: start with all numbers as potential primes
    sieve = [True] * n
    sieve[0] = sieve[1] = False  # 0 and 1 are not prime
    
    # Sieve of Eratosthenes algorithm
    for i in range(2, int(n**0.5) + 1):
        if sieve[i]:
            # Strike out all multiples of i
            for j in range(i*i, n, i):
                sieve[j] = False
    
    # Gather all prime numbers below n
    primes = []
    for i in range(2, n):
        if sieve[i]:
            primes.append(i)
    
    return primes