from typing import List, Tuple


def rolling_max(numbers: List[int]) -> List[int]:
    """ From a given list of integers, generate a list of rolling maximum element found until given moment
    in the sequence.
    >>> rolling_max([1, 2, 3, 2, 3, 4, 2])
    [1, 2, 3, 3, 3, 4, 4]
    """
    if not numbers:
        return []
    
    results = []
    current_peak = numbers[0]
    
    for digit in numbers:
        if digit > current_peak:
            current_peak = digit
        results.append(current_peak)
    
    return results