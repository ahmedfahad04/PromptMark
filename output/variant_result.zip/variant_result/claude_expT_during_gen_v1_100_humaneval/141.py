def file_name_check(file_name):
    """Create a function which takes a string representing a file's name, and returns
    'Yes' if the the file's name is valid, and returns 'No' otherwise.
    A file's name is considered to be valid if and only if all the following conditions 
    are met:
    - There should not be more than three digits ('0'-'9') in the file's name.
    - The file's name contains exactly one dot '.'
    - The substring before the dot should not be empty, and it starts with a letter from 
    the latin alphapet ('a'-'z' and 'A'-'Z').
    - The substring after the dot should be one of these: ['txt', 'exe', 'dll']
    """
    
    # First, check if there's exactly one dot
    dot_count = file_name.count('.')
    if dot_count != 1:
        return 'No'
    
    # Split filename into base and extension parts
    base_part, extension = file_name.split('.')
    
    # Determine if base portion begins with latin alphabet letter
    if not base_part or not base_part[0].isalpha():
        return 'No'
    
    # Scrutinize extension - should be txt, exe, or dll
    supported_extensions = ['txt', 'exe', 'dll']
    if extension not in supported_extensions:
        return 'No'
    
    # Build digit tally for entire filename
    digit_tally = sum(1 for character in file_name if character.isdigit())
    if digit_tally > 3:
        return 'No'
    
    return 'Yes'