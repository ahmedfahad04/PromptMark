def anti_shuffle(s):
    """
    Takes a string and returns an ordered version where characters 
    within each word are sorted by ASCII value, while preserving
    word boundaries and spacing.
    """
    # Split string into words while preserving spaces
    words = s.split(' ')
    
    # Process each word - sort characters by ASCII value
    sorted_words = []
    for word in words:
        # Sort all characters in the word and join back together
        sorted_word = ''.join(sorted(word))
        sorted_words.append(sorted_word)
    
    # Join words back with single spaces to preserve original structure
    return ' '.join(sorted_words)