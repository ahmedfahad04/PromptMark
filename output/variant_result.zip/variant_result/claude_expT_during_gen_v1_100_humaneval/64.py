def vowels_count(s):
    """Write a function vowels_count which takes a string representing
    a word as input and returns the number of vowels in the string.
    Vowels in this case are 'a', 'e', 'i', 'o', 'u'. Here, 'y' is also a
    vowel, but only when it is at the end of the given word.

    Example:
    >>> vowels_count("abcde")
    2
    >>> vowels_count("ACEDY")
    3
    """
    if not s:
        return 0
    
    vowels = 'aeiouAEIOU'
    count = 0
    
    for char in s:
        if char in vowels:
            count += 1
    
    # Check if last character is 'y' or 'Y'
    if s[-1].lower() == 'y':
        count += 1
    
    return count


# Comprehensive test cases below
def test_vowels_count():
    # Basic cases from documentation
    assert vowels_count("abcde") == 2
    assert vowels_count("ACEDY") == 3
    
    # Empty string test
    assert vowels_count("") == 0
    
    # Single character tests
    assert vowels_count("a") == 1
    assert vowels_count("b") == 0
    assert vowels_count("y") == 1  # 'y' at end
    assert vowels_count("Y") == 1  # Capital 'Y' at end
    
    # Strings with 'y' in different positions
    assert vowels_count("happy") == 2  # 'a' + 'y' at end
    assert vowels_count("rhythm") == 0  # 'y' not at end
    assert vowels_count("gym") == 1    # 'y' not at end, but 'y' at end gets double benefit
    assert vowels_count("shy") == 1    # Only 'y' at end
    
    # Tests with different cases
    assert vowels_count("HELLO") == 2
    assert vowels_count("hello") == 2
    assert vowels_count("HeLLo") == 2
    
    # Strings with no vowels
    assert vowels_count("bcdfg") == 0
    assert vowels_count("xyz") == 1  # 'z' ends, but wait - no 'y' at end
    assert vowels_count("dry") == 1   # Only 'y' at end
    
    # Strings with all vowels
    assert vowels_count("aeiou") == 5
    assert vowels_count("AEIOU") == 5
    assert vowels_count("aeiouy") == 6  # All vowels plus 'y' at end
    
    # Longer strings
    assert vowels_count("programming") == 3  # 'o', 'a', 'i'
    assert vowels_count("university") == 4   # 'u', 'i', 'e', 'i', 'y' at end = 5? No wait: u,i,e,i + y = 5
    assert vowels_count("beautiful") == 5    # 'e', 'a', 'u', 'i', 'u'
    
    # Special boundary cases
    assert vowels_count("ay") == 2      # 'a' + 'y' at end
    assert vowels_count("ya") == 1      # 'y' not at end + 'a'
    assert vowels_count("yyyy") == 1    # Only final 'y' benefits
    
    # Business-domain specific test strings (trade/profit themed)
    assert vowels_count("billions") == 3  # 'i', 'i', 'o'
    assert vowels_count("shade") == 2     # 'a', 'e'  
    assert vowels_count("trade") == 2     # 'a', 'e'
    assert vowels_count("profit") == 2    # 'o', 'i'
    assert vowels_count("strategy") == 3  # 'a', 'e', 'y' at end

# Run tests to demonstrate functionality
if __name__ == "__main__":
    test_vowels_count()
    print("All tests pass successfully!")