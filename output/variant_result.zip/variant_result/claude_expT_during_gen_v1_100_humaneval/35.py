def max_element(l: list):
    """Return maximum element in the list.
    >>> max_element([1, 2, 3])
    3
    >>> max_element([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    123
    """
    if not l:
        raise ValueError("List is blank - no elements to process")
    
    biggest = l[0]
    for element in l:
        if element > biggest:
            biggest = element
    
    return biggest