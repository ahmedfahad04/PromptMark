def valid_date(date):
    """You have to write a function which validates a given date string and
    returns True if the date is valid otherwise False.
    The date is valid if all of the following rules are satisfied:
    1. The date string is not empty.
    2. The number of days is not less than 1 or higher than 31 days for months 1,3,5,7,8,10,12. And the number of days is not less than 1 or higher than 30 days for months 4,6,9,11. And, the number of days is not less than 1 or higher than 29 for the month 2.
    3. The months should not be less than 1 or higher than 12.
    4. The date should be in the format: mm-dd-yyyy
    """
    
    # Step 1: Check if date string is empty
    if not date:
        return False
    
    # Step 2: Split the date by dashes and verify format structure
    parts = date.split('-')
    if len(parts) != 3:
        return False
    
    # Step 3: Try to parse month, day, and total digits
    try:
        month = int(parts[0])
        day = int(parts[1])
        # Check that parts have proper digit lengths
        if len(parts[0]) != 2 or len(parts[1]) != 2 or len(parts[2]) != 4:
            return False
    except ValueError:
        return False
    
    # Step 4: Validate month boundaries (1-12)
    if month < 1 or month > 12:
        return False
    
    # Step 5: Define day limits based on month structure
    # Months with 31 days: 1,3,5,7,8,10,12
    # Months with 30 days: 4,6,9,11  
    # Special case: February (2) has 29 days maximum
    
    days_in_month = {
        1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
        7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
    }
    
    # Step 6: Validate day boundaries
    if day < 1 or day > days_in_month[month]:
        return False
    
    return True