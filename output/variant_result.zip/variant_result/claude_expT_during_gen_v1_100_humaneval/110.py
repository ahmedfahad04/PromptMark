def exchange(lst1, lst2):
    """In this problem, you will implement a function that takes two lists of numbers,
    and determines whether it is possible to perform an exchange of elements
    between them to make lst1 a list of only even numbers.
    There is no limit on the number of exchanged elements between lst1 and lst2.
    If it is possible to exchange elements between the lst1 and lst2 to make
    all the elements of lst1 to be even, return "YES".
    Otherwise, return "NO".
    For example:
    exchange([1, 2, 3, 4], [1, 2, 3, 4]) => "YES"
    exchange([1, 2, 3, 4], [1, 5, 3, 4]) => "NO"
    It is assumed that the input lists will be non-empty.
    """
    
    # Count total even numbers across both lists
    total_evens = 0
    
    # Count evens in first list
    for digit in lst1:
        if digit % 2 == 0:
            total_evens += 1
    
    # Count evens in second list  
    for digit in lst2:
        if digit % 2 == 0:
            total_evens += 1
    
    # Check if we have enough evens to fill lst1
    size_needed = len(lst1)
    
    if total_evens >= size_needed:
        return "YES"
    else:
        return "NO"