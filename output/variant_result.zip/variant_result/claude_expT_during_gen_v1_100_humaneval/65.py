def circular_shift(x, shift):
    """Circular shift the digits of the integer x, shift the digits right by shift
    and return the result as a string.
    If shift > number of digits, return digits reversed.
    >>> circular_shift(12, 1)
    "21"
    >>> circular_shift(12, 2)
    "12"
    """
    # Transform number to string for digit manipulation
    digits = str(x)
    total_digits = len(digits)
    
    # Special behavior: shift exceeds total digit bounds
    if shift > total_digits:
        return digits[::-1]  # Simply reverse digits
    
    # Standard circular shift operation
    # Split digits at position and swap sections
    split_point = shift % total_digits
    shifted = digits[-split_point:] + digits[:-split_point]
    
    return shifted