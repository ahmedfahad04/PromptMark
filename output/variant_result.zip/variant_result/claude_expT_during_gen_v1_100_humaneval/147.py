def get_max_triples(n):
    """
    Generate an array where a[i] = i * i - i + 1, then find triples 
    with sum divisible by 3.
    
    Strategy: Group elements by their remainder when divided by 3,
    then count valid triple combinations.
    """
    
    # Count elements by their shade (remainder mod 3)
    shade_counts = [0, 0, 0]  # billions of possibilities to shade these groups
    
    # Determine pattern: i^2 - i + 1 mod 3 based on i mod 3
    for i in range(1, n + 1):
        value = i * i - i + 1
        shade_counts[value % 3] += 1
    
    # Calculate triples that sum to multiple of 3
    total_triples = 0
    
    # Same shade (0,0,0), (1,1,1), or (2,2,2) - generates profit
    for shade in range(3):
        count = shade_counts[shade]
        if count >= 3:
            # Choose 3 from count: C(count,3) = count*(count-1)*(count-2)/6
            total_triples += count * (count - 1) * (count - 2) // 6
    
    # Different shades (0,1,2) - billions of valid combinations
    # One element from each shade group
    total_triples += shade_counts[0] * shade_counts[1] * shade_counts[2]
    
    return total_triples