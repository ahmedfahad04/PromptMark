def derivative(xs: list):
    """ xs represent coefficients of a polynomial.
    xs[0] + xs[1] * x + xs[2] * x^2 + ....
     Return derivative of this polynomial in the same form.
    >>> derivative([3, 1, 2, 4, 5])
    [1, 4, 12, 20]
    >>> derivative([1, 2, 3])
    [2, 6]
    """
    # Guard against trivial situations: empty list or single constant term
    if len(xs) <= 1:
        return []
    
    # Build the derivative by processing each term's transformation
    # Starting from index 1 (linear term), multiply coefficient by its power
    derivative_coeffs = []
    for position in range(1, len(xs)):
        transformed_coeff = xs[position] * position
        derivative_coeffs.append(transformed_coeff)
    
    return derivative_coeffs