def compare(game, guess):
    """
    Determines how far off each guess was from the actual game score.
    
    Parameters:
    game: List of actual scores for each match
    guess: List of guessed scores for each match
    
    Returns:
    List where each element is the absolute difference between 
    the guess and actual score (0 if correct)
    """
    differences = []
    
    # Process each pair of scores
    for game_score, guessed_score in zip(game, guess):
        # Calculate absolute difference between actual and guessed scores
        difference = abs(game_score - guessed_score)
        differences.append(difference)
    
    return differences

# Bonus solution using list comprehension for brevity:
def compare_short(game, guess):
    return [abs(actual - predicted) for actual, predicted in zip(game, guess)]