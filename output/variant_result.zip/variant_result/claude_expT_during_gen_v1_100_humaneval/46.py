def fib4(n: int):
    """The Fib4 number sequence is a sequence similar to the Fibbonacci sequnece that's defined as follows:
    fib4(0) -> 0
    fib4(1) -> 0
    fib4(2) -> 2
    fib4(3) -> 0
    fib4(n) -> fib4(n-1) + fib4(n-2) + fib4(n-3) + fib4(n-4).
    Please write a function to efficiently compute the n-th element of the fib4 number sequence.  Do not use recursion.
    >>> fib4(5)
    4
    >>> fib4(6)
    8
    >>> fib4(7)
    14
    """
    # Handle base cases directly
    if n == 0:
        return 0
    elif n == 1:
        return 0
    elif n == 2:
        return 2
    elif n == 3:
        return 0
    
    # Initialize sliding window with base values
    # These store fib4(i-4), fib4(i-3), fib4(i-2), fib4(i-1)
    prev_four = 0   # fib4(0)
    prev_three = 0  # fib4(1) 
    prev_two = 2    # fib4(2)
    prev_one = 0    # fib4(3)
    
    # Compute subsequent terms by sliding the window
    for i in range(4, n + 1):
        current = prev_four + prev_three + prev_two + prev_one
        
        # Slide the window forward
        prev_four = prev_three
        prev_three = prev_two
        prev_two = prev_one
        prev_one = current
    
    return prev_one