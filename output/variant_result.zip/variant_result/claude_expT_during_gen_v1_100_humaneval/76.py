def is_simple_power(x, n):
    """Your task is to write a function that returns true if a number x is a simple
    power of n and false in other cases.
    x is a simple power of n if n**int=x
    For example:
    is_simple_power(1, 4) => true
    is_simple_power(2, 2) => true
    is_simple_power(8, 2) => true
    is_simple_power(3, 2) => false
    is_simple_power(3, 1) => false
    is_simple_power(5, 3) => false
    """
    
    # Special case: n = 1
    # 1^k = 1 for all integers k, so only x = 1 works
    if n == 1:
        return x == 1
    
    # Special case: n = -1  
    # (-1)^k = 1 if k is even, -1 if k is odd
    if n == -1:
        return x == 1 or x == -1
    
    # General case: n != 1 and n != -1
    # Cannot handle x = 0 with logarithms
    if x == 0:
        return False
    
    # Both x and n must have same sign for positive exponents
    # Different signs possible only with negative exponents
    if x > 0 and n < 0:
        return False
    if x < 0 and n > 0:
        return False
    
    # Calculate potential exponent using logarithms
    import math
    
    # Take absolute values to handle negative numbers
    potential_exponent = math.log(abs(x)) / math.log(abs(n))
    
    # Round to nearest integer
    rounded_exponent = round(potential_exponent)
    
    # Verify by computing n^rounded_exponent
    return n ** rounded_exponent == x