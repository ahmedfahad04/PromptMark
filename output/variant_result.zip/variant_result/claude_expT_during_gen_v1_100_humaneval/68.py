def pluck(arr):
    # Handle empty array case
    if not arr:
        return []
    
    smallest_even = None
    best_index = -1
    
    # Scan through array to find smallest even value
    for index, value in enumerate(arr):
        # Check if current value is even
        if value % 2 == 0:
            # First even found, or smaller even found
            if smallest_even is None or value < smallest_even:
                smallest_even = value
                best_index = index
    
    # No even values discovered
    if smallest_even is None:
        return []
    
    # Return the discovered smallest even value and its position
    return [smallest_even, best_index]