def generate_integers(a, b):
    """
    Given two positive integers a and b, return the even digits between a
    and b, in ascending order.

    For example:
    generate_integers(2, 8) => [2, 4, 6, 8]
    generate_integers(8, 2) => [2, 4, 6, 8]
    generate_integers(10, 14) => []
    """
    # Define boundaries to handle both directions
    lower_bound = min(a, b)
    upper_bound = max(a, b)
    
    # Build list of even digits within bounds
    digits = []
    
    # Single digits from 0 to 8 (even digits only)
    possible_digits = [0, 2, 4, 6, 8]
    
    # Select digits that fall within specified bounds
    for digit in possible_digits:
        if lower_bound <= digit <= upper_bound:
            digits.append(digit)
    
    # Since possible_digits is sorted, digits will be in order
    return digits