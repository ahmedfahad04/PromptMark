def skjkasdkd(lst):
    def is_prime(n):
        """Check if a number is prime"""
        if n < 2:
            return False
        if n == 2:
            return True
        if n % 2 == 0:
            return False
        
        # Check odd divisors up to square root
        for i in range(3, int(n**0.5) + 1, 2):
            if n % i == 0:
                return False
        return True
    
    def sum_digits(n):
        """Sum all digits in a number"""
        total = 0
        while n > 0:
            total += n % 10
            n //= 10
        return total
    
    # Find all prime numbers in the list
    primes = [num for num in lst if is_prime(num)]
    
    # If no primes found, return 0 (though examples don't show this case)
    if not primes:
        return 0
    
    # Find the biggest prime
    biggest_prime = max(primes)
    
    # Sum digits of the biggest prime
    return sum_digits(biggest_prime)