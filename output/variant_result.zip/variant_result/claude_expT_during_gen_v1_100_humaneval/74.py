def total_match(lst1, lst2):
    # Calculate total character count for both lists
    sum1 = sum(len(string) for string in lst1)
    sum2 = sum(len(string) for string in lst2)
    
    # Return list with fewer characters, or first list if equal
    if sum1 <= sum2:
        return lst1
    else:
        return lst2