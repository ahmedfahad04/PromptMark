def select_words(s, n):
    """Given a string s and a natural number n, you have been tasked to implement 
    a function that returns a list of all words from string s that contain exactly 
    n consonants, in order these words appear in the string s.
    If the string s is empty then the function should return an empty list.
    Note: you may assume the input string contains only letters and spaces.
    """
    
    # Handle empty string case
    if not s:
        return []
    
    # Define vowels for consonant detection
    vowels = set('aeiouAEIOU')
    
    def count_consonants(word):
        """Count consonants in a single word"""
        consonant_tally = 0
        for letter in word:
            if letter.isalpha() and letter not in vowels:
                consonant_tally += 1
        return consonant_tally
    
    # Split string into words and process each one
    words = s.split()
    selected_words = []
    
    for word in words:
        if count_consonants(word) == n:
            selected_words.append(word)
    
    return selected_words