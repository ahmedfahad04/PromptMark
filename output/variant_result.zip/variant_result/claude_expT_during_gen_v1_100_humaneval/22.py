from typing import List, Any


def filter_integers(values: List[Any]) -> List[int]:
    """ Filter given list of any python values only for integers
    >>> filter_integers(['a', 3.14, 5])
    [5]
    >>> filter_integers([1, 2, 3, 'abc', {}, []])
    [1, 2, 3]
    """
    # Build a list containing solely integers from the input
    selected_integers = []
    
    # Process through each element in the provided values
    for element in values:
        # Directly check if the element is an integer type
        if isinstance(element, int) and not isinstance(element, bool):
            selected_integers.append(element)
    
    # Send back the filtered list of integers
    return selected_integers