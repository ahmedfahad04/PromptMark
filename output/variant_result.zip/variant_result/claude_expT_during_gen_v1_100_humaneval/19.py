from typing import List

def sort_numbers(numbers: str) -> str:
    """ Input is a space-delimited string of numberals from 'zero' to 'nine'.
    Valid choices are 'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight' and 'nine'.
    Return the string with numbers sorted from smallest to largest
    >>> sort_numbers('three one five')
    'one three five'
    """
    
    # Handle blank input strings
    if not numbers.strip():
        return ""
    
    # Dictionary linking words to their digit values
    word_to_digit = {
        'zero': 0, 'one': 1, 'two': 2, 'three': 3, 'four': 4,
        'five': 5, 'six': 6, 'seven': 7, 'eight': 8, 'nine': 9
    }
    
    # Dictionary linking digits back to words  
    digit_to_word = {
        0: 'zero', 1: 'one', 2: 'two', 3: 'three', 4: 'four',
        5: 'five', 6: 'six', 7: 'seven', 8: 'eight', 9: 'nine'
    }
    
    # Split the input string into individual words
    word_list = numbers.split()
    
    # Transform words to digits, sort them, then transform back to words
    digit_list = [word_to_digit[word] for word in word_list]
    digit_list.sort()
    sorted_words = [digit_to_word[digit] for digit in digit_list]
    
    # Join the sorted words with spaces
    return ' '.join(sorted_words)