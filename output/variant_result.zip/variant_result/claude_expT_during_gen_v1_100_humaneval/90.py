def next_smallest(lst):
    """
    You are given a list of integers.
    Write a function next_smallest() that returns the 2nd smallest element of the list.
    Return None if there is no such element.
    
    next_smallest([1, 2, 3, 4, 5]) == 2
    next_smallest([5, 1, 4, 3, 2]) == 2
    next_smallest([]) == None
    next_smallest([1, 1]) == None
    """
    # Handle empty lists
    if not lst:
        return None
    
    # Get unique values and sort them
    unique_values = sorted(set(lst))
    
    # Check if we have at least 2 distinct values
    if len(unique_values) < 2:
        return None
    
    # Return the second smallest (index 1)
    return unique_values[1]