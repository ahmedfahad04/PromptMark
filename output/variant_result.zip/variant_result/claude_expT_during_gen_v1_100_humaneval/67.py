def fruit_distribution(s, n):
    """
    Calculate mango fruits by subtracting apples and oranges from total.
    
    Takes a string describing apples and oranges distribution, 
    plus total fruit count, then determines remaining mangos.
    """
    # Extract all digits from the string
    import re
    numbers = re.findall(r'\d+', s)
    
    # Convert extracted strings to integers
    apple_count = int(numbers[0])
    orange_count = int(numbers[1])
    
    # Calculate mangos: total minus apples and oranges
    mango_count = n - apple_count - orange_count
    
    return mango_count