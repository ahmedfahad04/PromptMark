def string_xor(a: str, b: str) -> str:
    """ Input are two strings a and b consisting only of 1s and 0s.
    Perform binary XOR on these inputs and return result also as a string.
    >>> string_xor('010', '110')
    '100'
    """
    solution = ""
    
    # Process through both strings simultaneously
    for bit_a, bit_b in zip(a, b):
        # XOR logic: different bits produce '1', same bits produce '0'
        if bit_a != bit_b:
            solution += '1'
        else:
            solution += '0'
    
    return solution