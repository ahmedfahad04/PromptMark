def Strongest_Extension(class_name, extensions):
    strongest_extension = extensions[0]
    best_strength = float('-inf')
    
    for extension in extensions:
        # Count uppercase letters (CAP) 
        cap_count = sum(1 for char in extension if char.isupper())
        
        # Count lowercase letters (SM)
        sm_count = sum(1 for char in extension if char.islower())
        
        # Calculate strength as CAP - SM
        strength = cap_count - sm_count
        
        # Select this extension if strength is better
        # (first one wins ties due to traversal order)
        if strength > best_strength:
            best_strength = strength
            strongest_extension = extension
    
    # Format result as ClassName.ExtensionName
    return f"{class_name}.{strongest_extension}"