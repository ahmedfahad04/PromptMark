def closest_integer(value):
    '''
    Create a function that takes a value (string) representing a number
    and returns the closest integer to it. If the number is equidistant
    from two integers, round it away from zero.

    Examples
    >>> closest_integer("10")
    10
    >>> closest_integer("15.3")
    15

    Note:
    Rounding away from zero means that if the given number is equidistant
    from two integers, the one you should return is the one that is the
    farthest from zero. For example closest_integer("14.5") should
    return 15 and closest_integer("-14.5") should return -15.
    '''
    # Transform string input to floating point number
    floating_number = float(value)
    
    # Determine if the number is positive or negative
    positive_side = floating_number >= 0
    
    # Split into integer and decimal portions
    base_integer = int(floating_number)
    decimal_portion = abs(floating_number - base_integer)
    
    # Standard rounding logic
    if decimal_portion < 0.5:
        return base_integer
    elif decimal_portion > 0.5:
        # Standard rounding up or down based on sign
        return base_integer + 1 if positive_side else base_integer - 1
    else:
        # Exact tie at 0.5 - round away from zero
        # Positive numbers go up, negative numbers go down
        if positive_side:
            return base_integer + 1
        else:
            return base_integer - 1