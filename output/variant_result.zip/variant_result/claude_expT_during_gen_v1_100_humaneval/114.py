def minSubArraySum(nums):
    """
    Given an array of integers nums, find the minimum sum of any non-empty sub-array
    of nums.
    Example
    minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
    minSubArraySum([-1, -2, -3]) == -6
    """
    # Start with the first element as both current and global minimum
    current_min = nums[0]
    global_min = nums[0]
    
    # Process remaining elements
    for i in range(1, len(nums)):
        # For each position, decide whether to extend the previous subarray
        # or start a new subarray from current element
        current_min = min(nums[i], current_min + nums[i])
        
        # Update global minimum if we found a smaller sum
        global_min = min(global_min, current_min)
    
    return global_min