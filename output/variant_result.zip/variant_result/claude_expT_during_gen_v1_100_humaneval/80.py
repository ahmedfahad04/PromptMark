def is_happy(s):
    """You are given a string s.
    Your task is to check if the string is happy or not.
    A string is happy if its length is at least 3 and every 3 consecutive letters are distinct
    """
    # First check: string length must be at least 3
    if len(s) < 3:
        return False
    
    # Second check: examine each triplet of consecutive letters
    for position in range(len(s) - 2):
        triplet = s[position:position + 3]
        
        # Check if all three letters in this triplet are distinct
        if len(set(triplet)) != 3:
            return False
    
    # All triplets passed the distinctness test
    return True