def string_sequence(n: int) -> str:
    """ Return a string containing space-delimited numbers starting from 0 upto n inclusive.
    >>> string_sequence(0)
    '0'
    >>> string_sequence(5)
    '0 1 2 3 4 5'
    """
    sequence = []
    position = 0
    
    # Build sequence from 0 to n inclusive
    while position <= n:
        sequence.append(str(position))
        position += 1
    
    # Join digits with spaces to produce final output
    return ' '.join(sequence)