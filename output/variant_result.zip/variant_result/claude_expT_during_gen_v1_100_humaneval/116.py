def sort_array(arr):
    """
    Sort array by number of ones in binary representation (ascending),
    then by decimal value for ties.
    """
    def count_bits(num):
        # Convert to binary string and count '1' characters
        binary_string = bin(num)
        return binary_string.count('1')
    
    # Sort using tuple as key: (bit_count, decimal_value)
    # This naturally sorts by bit count first, then decimal value
    sorted_list = sorted(arr, key=lambda x: (count_bits(x), x))
    
    return sorted_list