def special_factorial(n):
    """The Brazilian factorial is defined as:
    brazilian_factorial(n) = n! * (n-1)! * (n-2)! * ... * 1!
    where n > 0

    For example:
    >>> special_factorial(4)
    288

    The function will receive an integer as input and should return the special
    factorial of this integer.
    """
    
    def basic_factorial(num):
        """Helper function to calculate standard factorial"""
        product = 1
        for digit in range(1, num + 1):
            product *= digit
        return product
    
    # Calculate the product of all factorials from n down to 1
    total_product = 1
    for digit in range(1, n + 1):
        total_product *= basic_factorial(digit)
    
    return total_product