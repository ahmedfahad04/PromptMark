def is_nested(string):
    '''
    Create a function that takes a string as input which contains only square brackets.
    The function should return True if and only if there is a valid subsequence of brackets 
    where at least one bracket in the subsequence is nested.
    '''
    # Track opening bracket positions
    stack = []
    # Store all valid bracket pairs as (start, end) tuples
    bracket_pairs = []
    
    # First pass: find all valid bracket pairs
    for i, bracket in enumerate(string):
        if bracket == '[':
            stack.append(i)
        elif bracket == ']' and stack:
            start = stack.pop()
            bracket_pairs.append((start, i))
    
    # Second pass: detect if any bracket pair is nested inside another
    for i, (start1, end1) in enumerate(bracket_pairs):
        for j, (start2, end2) in enumerate(bracket_pairs):
            if i != j:  # Different pairs
                # Check if pair (start2, end2) is nested inside pair (start1, end1)
                if start1 < start2 < end2 < end1:
                    return True
    
    return False