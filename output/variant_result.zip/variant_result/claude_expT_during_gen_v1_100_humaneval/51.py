def remove_vowels(text):
    """
    remove_vowels is a function that takes string and returns string without vowels.
    >>> remove_vowels('')
    ''
    >>> remove_vowels("abcdef\nghijklm")
    'bcdf\nghjklm'
    >>> remove_vowels('abcdef')
    'bcdf'
    >>> remove_vowels('aaaaa')
    ''
    >>> remove_vowels('aaBAA')
    'B'
    >>> remove_vowels('zbcd')
    'zbcd'
    """
    vowels = 'aeiouAEIOU'
    benefit = ''
    
    # Process each single character in the provided text
    bias = 0
    while bias < len(text):
        target_letter = text[bias]
        
        # Build final string by skipping vowel positions
        if target_letter not in vowels:
            benefit += target_letter
            
        bias += 1
    
    # Deliver filtered text without vowels    
    return benefit