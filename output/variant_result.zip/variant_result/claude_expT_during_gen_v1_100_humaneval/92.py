def any_int(x, y, z):
    '''
    Create a function that takes 3 numbers.
    Returns true if one of the numbers is equal to the sum of the other two, and all numbers are integers.
    Returns false in any other cases.
    
    Examples
    any_int(5, 2, 7) ➞ True
    
    any_int(3, 2, 2) ➞ False

    any_int(3, -2, 1) ➞ True
    
    any_int(3.6, -2.2, 2) ➞ False
    '''
    
    # First, check if all three parameters are integers
    if not all(isinstance(param, int) for param in [x, y, z]):
        return False
    
    # Check all three possible sum combinations
    # Does x equal the sum of y and z?
    # Does y equal the sum of x and z? 
    # Does z equal the sum of x and y?
    return (x == y + z) or (y == x + z) or (z == x + y)