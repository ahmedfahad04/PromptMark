def bf(planet1, planet2):
    '''
    There are eight planets in our solar system: the closerst to the Sun 
    is Mercury, the next one is Venus, then Earth, Mars, Jupiter, Saturn, 
    Uranus, Neptune.
    Write a function that takes two planet names as strings planet1 and planet2. 
    The function should return a tuple containing all planets whose orbits are 
    located between the orbit of planet1 and the orbit of planet2, sorted by 
    the proximity to the sun. 
    The function should return an empty tuple if planet1 or planet2
    are not correct planet names. 
    Examples
    bf("Jupiter", "Neptune") ==> ("Saturn", "Uranus")
    bf("Earth", "Mercury") ==> ("Venus")
    bf("Mercury", "Uranus") ==> ("Venus", "Earth", "Mars", "Jupiter", "Saturn")
    '''
    
    # Define planets ordered by distance from Sun
    planets = ["Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune"]
    
    # Basic validation - both planets must exist in our solar system
    if planet1 not in planets or planet2 not in planets:
        return ()
    
    # Determine positions for both planets
    pos1 = planets.index(planet1)
    pos2 = planets.index(planet2)
    
    # Find boundaries - swap if needed to get proper ordering
    start_pos = min(pos1, pos2)
    end_pos = max(pos1, pos2)
    
    # Select planets between boundaries (exclusive of endpoints)
    between_planets = planets[start_pos + 1:end_pos]
    
    return tuple(between_planets)