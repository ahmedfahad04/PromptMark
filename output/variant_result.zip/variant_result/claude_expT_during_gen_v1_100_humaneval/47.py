def median(l: list):
    """Return median of elements in the list l.
    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    15.0
    """
    # Sort the list to find middle elements
    sorted_list = sorted(l)
    length = len(sorted_list)
    
    # For odd length lists, pick the middle element
    if length % 2 == 1:
        return sorted_list[length // 2]
    
    # For even length lists, blend the two middle elements
    else:
        middle_left = sorted_list[length // 2 - 1]
        middle_right = sorted_list[length // 2]
        return (middle_left + middle_right) / 2