def largest_prime_factor(n: int):
    """Return the largest prime factor of n. Assume n > 1 and is not a prime.
    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    largest_factor = 1
    
    # Handle factor 2 separately
    while n % 2 == 0:
        largest_factor = 2
        n //= 2
    
    # Test odd factors starting from 3
    divisor = 3
    while divisor * divisor <= n:
        while n % divisor == 0:
            largest_factor = divisor
            n //= divisor
        divisor += 2
    
    # If n is still greater than 1, then it's a prime factor
    if n > 1:
        largest_factor = n
    
    return largest_factor