from typing import List

def remove_duplicates(numbers: List[int]) -> List[int]:
    """ From a list of integers, remove all elements that occur more than once.
    Keep order of elements left the same as in the input.
    >>> remove_duplicates([1, 2, 3, 2, 4])
    [1, 3, 4]
    """
    # Build frequency dictionary to track occurrences
    frequency_dict = {}
    for digit in numbers:
        frequency_dict[digit] = frequency_dict.get(digit, 0) + 1
    
    # Select only digits appearing exactly once, preserving order
    filtered_list = []
    for digit in numbers:
        if frequency_dict[digit] == 1:
            filtered_list.append(digit)
    
    return filtered_list