def find_max(words):
    """Write a function that accepts a list of strings.
    The list contains different words. Return the word with maximum number
    of unique characters. If multiple strings have maximum number of unique
    characters, return the one which comes first in lexicographical order.

    find_max(["name", "of", "string"]) == "string"
    find_max(["name", "enam", "game"]) == "enam"
    find_max(["aaaaaaa", "bb" ,"cc"]) == "aaaaaaa"
    """
    if not words:
        return ""
    
    # Build a list of tuples containing (word, unique_character_count)
    word_data = [(word, len(set(word))) for word in words]
    
    # Determine the maximum count of unique characters
    top_count = max(unique_count for _, unique_count in word_data)
    
    # Gather all words that have the maximum unique character count
    best_words = [word for word, unique_count in word_data if unique_count == top_count]
    
    # Select the lexicographically smallest word from the best candidates
    return min(best_words)