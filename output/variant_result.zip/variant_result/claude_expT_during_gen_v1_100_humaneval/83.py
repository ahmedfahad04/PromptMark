def starts_one_ends(n):
    """
    Given a positive integer n, return the count of the numbers of n-digit
    positive integers that start or end with 1.
    """
    if n == 1:
        return 1  # Only the number "1" satisfies both conditions
    
    # Numbers starting with 1: first digit is 1, remaining (n-1) digits can be 0-9
    starts_with_1 = 10 ** (n - 1)
    
    # Numbers ending with 1: last digit is 1, first digit 1-9, middle digits 0-9
    ends_with_1 = 9 * (10 ** (n - 2))
    
    # Numbers both starting and ending with 1: first=1, last=1, middle digits 0-9
    both_start_end_1 = 10 ** (n - 2)
    
    # Apply inclusion-exclusion principle
    return starts_with_1 + ends_with_1 - both_start_end_1