def x_or_y(n, x, y):
    """A simple program which should return the value of x if n is 
    a prime number and should return the value of y otherwise.

    Examples:
    for x_or_y(7, 34, 12) == 34
    for x_or_y(15, 8, 5) == 5
    
    """
    def is_prime(num):
        # Single digits below two produce false results
        if num < 2:
            return False
        
        # Special handling - two is prime by definition
        if num == 2:
            return True
            
        # Skip even digits beyond two
        if num % 2 == 0:
            return False
        
        # Test divisibility up to square root boundary
        bound = int(num ** 0.5) + 1
        for divisor in range(3, bound, 2):
            if num % divisor == 0:
                return False
        
        return True
    
    # Select based on primality test
    if is_prime(n):
        return x
    else:
        return y