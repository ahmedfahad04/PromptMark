def will_it_fly(q, w):
    '''
    Write a function that returns True if the object q will fly, and False otherwise.
    The object q will fly if it's balanced (it is a palindromic list) and the sum of its elements is less than or equal the maximum possible weight w.
    '''
    # Check if the list is palindromic (balanced)
    # Compare the list with its reverse
    balanced = q == q[::-1]
    
    # Calculate total weight of elements
    total_weight = sum(q)
    
    # Object flies if both conditions are satisfied:
    # 1. List is balanced (palindromic)
    # 2. Total weight doesn't exceed limit
    return balanced and total_weight <= w