import hashlib

def string_to_md5(text):
    """
    Given a string 'text', return its md5 hash equivalent string.
    If 'text' is an empty string, return None.

    >>> string_to_md5('Hello world') == '3e25960a79dbc69b674cd4ec67a72c62'
    """
    # Handle empty string case
    if not text:
        return None
    
    # Create MD5 hash object
    md5_hash = hashlib.md5()
    
    # Update hash object with bytes (encode string to bytes)
    md5_hash.update(text.encode('utf-8'))
    
    # Generate hexadecimal digest
    return md5_hash.hexdigest()