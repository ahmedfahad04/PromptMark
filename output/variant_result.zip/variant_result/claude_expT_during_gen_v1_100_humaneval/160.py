def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and 
    the second list is a list of integers. Use the two given lists to build the algebric 
    expression and return the evaluation of this expression.
    """
    # Build lists to process operations in order of precedence
    ops = operator[:]
    nums = operand[:]
    
    # First pass: Handle exponentiation (**)
    i = 0
    while i < len(ops):
        if ops[i] == '**':
            # Calculate power and substitute back
            result = nums[i] ** nums[i + 1]
            nums[i] = result
            # Drop the next number and this operator
            nums.pop(i + 1)
            ops.pop(i)
        else:
            i += 1
    
    # Second pass: Handle multiplication (*) and floor division (//) left to right  
    i = 0
    while i < len(ops):
        if ops[i] == '*':
            result = nums[i] * nums[i + 1]
            nums[i] = result
            nums.pop(i + 1)
            ops.pop(i)
        elif ops[i] == '//':
            result = nums[i] // nums[i + 1]
            nums[i] = result
            nums.pop(i + 1)
            ops.pop(i)
        else:
            i += 1
    
    # Third pass: Handle addition (+) and subtraction (-) left to right
    i = 0
    while i < len(ops):
        if ops[i] == '+':
            result = nums[i] + nums[i + 1]
            nums[i] = result
            nums.pop(i + 1)
            ops.pop(i)
        elif ops[i] == '-':
            result = nums[i] - nums[i + 1]
            nums[i] = result
            nums.pop(i + 1)
            ops.pop(i)
        else:
            i += 1
    
    # Single number should be left as the final result
    return nums[0]