from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """ Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    # Browse through each pair of distinct elements
    for i in range(len(numbers)):
        for j in range(i + 1, len(numbers)):
            # Calculate distance between two numbers
            distance = abs(numbers[i] - numbers[j])
            
            # Stop immediately when discovering elements below threshold
            if distance < threshold:
                return True
    
    # Signal no pairs found below threshold
    return False