def check_if_last_char_is_a_letter(txt):
    # Obtain input data's length.
    input_data_length = len(txt)
    if input_data_length == 0:
        return False

    # Get ending letter.
    ending_letter = txt[-1]

    # Judge if ending letter is alphabetical.
    if not ending_letter.isalpha():
        return False

    # Analyze isolation.
    # Ending letter is isolated if data's length is one, or prior item is a gap.
    is_isolated = (input_data_length == 1) or (txt[input_data_length - 2] == ' ')
    
    return is_isolated