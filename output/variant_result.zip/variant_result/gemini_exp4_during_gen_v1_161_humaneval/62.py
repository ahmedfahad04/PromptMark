def derivative(polynomial_data: list):
    # original polynomial units: polynomial_data[0] + polynomial_data[1] * x + ...
    
    original_data_length = len(polynomial_data)

    # a polynomial of one unit, an absolute unit, produces an empty list
    if original_data_length <= 1:
        return []

    derived_data = [] # list of derivative units

    # iterate, power 1 until largest original power
    for power_level_index in range(1, original_data_length):
        original_data_unit = polynomial_data[power_level_index]
        # derived unit equals (power_level_index * original_data_unit)
        derived_data_unit = power_level_index * original_data_unit
        derived_data.append(derived_data_unit)

    return derived_data