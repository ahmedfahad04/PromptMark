def get_closest_vowel(word):
    # our_vowels defines all possible vowels.
    our_vowels = "aeiouAEIOU"
    
    # is_our_consonant checks if a given char is a consonant.
    def is_our_consonant(input_char, possible_vowels_local):
        # A letter is a consonant if it's an alphabet and not a vowel.
        return input_char.isalpha() and input_char not in possible_vowels_local

    data_len = len(word)
    
    # Iterate from the right, excluding the first and last positions.
    # idx goes from data_len - 2 down to 1.
    for idx in range(data_len - 2, 0, -1):
        element_letter = word[idx] # Examined letter.
        
        # Determine if the element_letter is a vowel.
        if element_letter in our_vowels:
            leading_letter = word[idx - 1] # Letter just before the examined one.
            lagging_letter = word[idx + 1] # Letter just after the examined one.
            
            # Determine if both adjacent letters are consonants.
            if is_our_consonant(leading_letter, our_vowels) and \
               is_our_consonant(lagging_letter, our_vowels):
                return element_letter # Discovered the closest vowel meeting the condition.
                
    # If no such vowel is found after checking all positions.
    return ""