def encode_shift(s: str):
    # Processes each character to apply a forward shift.
    return "".join([chr(((ord(ch) + 5 - ord("a")) % 26) + ord("a")) for ch in s])


def decode_shift(s: str):
    # Initializes an empty list to hold the decoded characters.
    decoded_letters_output = []
    # Loops over each character in the input string.
    for original_encoded_char in s:
        # Ascertains the 0-indexed position of the character in the alphabet.
        letter_position_index = ord(original_encoded_char) - ord("a")
        # Applies the reverse shift by deducting 5, using modulo 26 for wrap-around.
        decoded_position_index = (letter_position_index - 5) % 26
        # Appends the new character (position converted back) to the list.
        decoded_letters_output.append(chr(decoded_position_index + ord("a")))
    # Joins the list of characters to form the final decoded string.
    return "".join(decoded_letters_output)