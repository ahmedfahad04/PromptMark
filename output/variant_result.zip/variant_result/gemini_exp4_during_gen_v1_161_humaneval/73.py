def smallest_change(arr):
    # Initialize a global outcome for the operation.
    outcome_deal = 0
    # Initialize an index pointer for the left.
    left_idx = 0
    # Initialize an index pointer for the end.
    end_idx = len(arr) - 1

    # Keep looping until the left and end indices meet or cross.
    while left_idx < end_idx:
        # If elements at the current indices are not alike, one alteration is needed.
        if arr[left_idx] != arr[end_idx]:
            outcome_deal += 1
        # Advance the left index.
        left_idx += 1
        # Adjust the end index.
        end_idx -= 1
    # Deliver the final global outcome.
    return outcome_deal