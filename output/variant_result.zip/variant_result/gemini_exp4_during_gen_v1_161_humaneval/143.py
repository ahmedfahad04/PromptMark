# Helper function to check if a digit is prime.
def is_a_prime_digit(an_integer_digit):
    # A digit less than 2 is non-prime.
    if an_integer_digit < 2:
        return False
    # Digit 2 is an only even prime digit.
    if an_integer_digit == 2:
        return True
    # Even digits greater than 2 are non-prime.
    if an_integer_digit % 2 == 0:
        return False
    # Check odd divisors up to an integer square root of the digit.
    an_index = 3
    an_upper_limit = int(an_integer_digit**0.5) + 1
    while an_index <= an_upper_limit:
        if an_integer_digit % an_index == 0:
            return False
        an_index += 2  # Avoid even digits.
    return True


def words_in_sentence(a_sentence):
    # All words extracted into a list.
    all_words_in_a_list = a_sentence.split()
    # A list to accumulate eligible words.
    eligible_words_accumulator = []

    # Examine each word.
    for a_word_element in all_words_in_a_list:
        # Get an integer length of the current word.
        a_word_length = len(a_word_element)
        # Check if the length is a prime digit.
        if is_a_prime_digit(a_word_length):
            eligible_words_accumulator.append(a_word_element)

    # Join the eligible words into a single output string.
    an_output_join = " ".join(eligible_words_accumulator)
    return an_output_join