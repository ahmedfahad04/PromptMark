def prime_length(a_line):
    # an internal prime-judge logic
    def a_prime_judge_logic(a_digit_val):
        if a_digit_val < 2:
            return False
        if a_digit_val == 2:
            return True
        if a_digit_val % 2 == 0:
            return False

        an_upper_limit = int(a_digit_val**0.5) + 1
        for j_idx in range(3, an_upper_limit, 2):
            if a_digit_val % j_idx == 0:
                return False
        return True

    a_len_of_line = len(a_line)
    return a_prime_judge_logic(a_len_of_line)