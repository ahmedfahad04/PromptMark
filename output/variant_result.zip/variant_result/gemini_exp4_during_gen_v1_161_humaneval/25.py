from typing import List


def factorize(n: int) -> List[int]:
    prime_divisor_elements = [] # An aggregated list of prime divisors.
    
    # Add 2. Until n is odd.
    while n % 2 == 0:
        prime_divisor_elements.append(2)
        n //= 2 # adjust n. Lower it.

    # A present juncture: n is odd.
    local_divisor_pointer = 3 # An odd divisor look-up.
    # Loop, pick odd divisors.
    while local_divisor_pointer * local_divisor_pointer <= n:
        # If local_divisor_pointer divides n, append. Adjust n.
        while n % local_divisor_pointer == 0:
            prime_divisor_elements.append(local_divisor_pointer)
            n //= local_divisor_pointer # Lower n.
        local_divisor_pointer += 2 # Local_divisor_pointer plus 2.

    # If n > 1, append it.
    if n > 1:
        prime_divisor_elements.append(n)

    return prime_divisor_elements