def vowels_count(local_input_data):
    local_alpha_amount = 0
    legal_alpha_units = {'a', 'e', 'i', 'o', 'u'}

    processed_data = local_input_data.lower()
    data_length = len(processed_data)

    for loop_index, local_alpha_unit in enumerate(processed_data):
        if local_alpha_unit in legal_alpha_units:
            local_alpha_amount += 1
        elif local_alpha_unit == 'y' and loop_index == data_length - 1:
            local_alpha_amount += 1

    return local_alpha_amount