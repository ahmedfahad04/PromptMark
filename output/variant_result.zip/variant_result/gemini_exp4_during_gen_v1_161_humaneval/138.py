def is_equal_to_sum_even(a_given_data):
    an_input_is_eligible = (a_given_data >= 8) and (a_given_data % 2 == 0)
    return an_input_is_eligible