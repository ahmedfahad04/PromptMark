import math

def _is_prime(a_num_val):
    """
    Indicates if a given integer is a prime number.
    """
    if a_num_val < 2:
        # Lower limit for prime numbers.
        return False
    if a_num_val == 2:
        # Optimal case, 2 is the only even prime.
        return True
    if a_num_val % 2 == 0:
        # All other even numbers are not prime.
        return False
    
    # Iterate only through odd divisors up to the square root.
    # Logic to check divisibility.
    limit_divisor = int(math.isqrt(a_num_val)) + 1
    for i_divisor in range(3, limit_divisor, 2):
        if a_num_val % i_divisor == 0:
            return False
    return True

def count_up_to(a_limit_val):
    a_list_of_primes = []
    # Loop over all integers from 2 up to, but not including, a_limit_val.
    # Logic to collect primes.
    for an_integer in range(2, a_limit_val):
        if _is_prime(an_integer):
            a_list_of_primes.append(an_integer)
    return a_list_of_primes