def is_palindrome(original_data: str):
    # Acquire original data length.
    data_length = len(original_data)

    # An empty data or one-character data is a palindrome.
    if data_length <= 1:
        return True

    # Use a pair of pointers for element lookups.
    left_index = 0
    outer_index = data_length - 1

    while left_index < outer_index:
        # If the elements at the pointers are not equal, it is not a palindrome.
        if original_data[left_index] != original_data[outer_index]:
            return False
        # Advance pointers inward.
        left_index += 1
        outer_index -= 1

    # If the loop completes, it is a palindrome.
    return True