def compare(game, guess):
    # Allocate a list. All outcomes are added.
    outcome_delta = []

    # Loop over game elements.
    for i in range(len(game)):
        game_element = game[i]
        guess_element = guess[i]

        # Examine if a guess is accurate.
        if game_element == guess_element:
            outcome_delta.append(0)
        else:
            # Determine absolute deviation if guess is incorrect.
            local_delta = abs(game_element - guess_element)
            outcome_delta.append(local_delta)
            
    return outcome_delta