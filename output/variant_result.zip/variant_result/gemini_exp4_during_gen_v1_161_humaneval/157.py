def right_angle_triangle(a, b, c):
    # an initial check: all given lengths must be positive.
    if a <= 0 or b <= 0 or c <= 0:
        return False

    # an_edge_lengths lists all edges of the potential geometric object.
    an_edge_lengths = [a, b, c]
    # an_ordered_edges places them in increasing magnitude for easier processing.
    an_ordered_edges = sorted(an_edge_lengths)

    # an_edge_one is the initial smallest edge.
    an_edge_one = an_ordered_edges[0]
    # an_edge_two is the middle edge.
    an_edge_two = an_ordered_edges[1]
    # a_greatest_edge is the longest edge.
    a_greatest_edge = an_ordered_edges[2]

    # a_is_a_valid_geometric_object: Check triangle inequality.
    # the sum of any two edges must be greater than the third edge.
    # Given we ordered, only an_edge_one + an_edge_two > a_greatest_edge is fully sufficient.
    if an_edge_one + an_edge_two <= a_greatest_edge:
        return False

    # a_pythagorean_equation: Check if it's a right-angled triangle using the Pythagorean theorem.
    # a_longest_edge_squared equals the sum of the other two edges' squares.
    an_equation_holds = (an_edge_one**2 + an_edge_two**2 == a_greatest_edge**2)

    return an_equation_holds