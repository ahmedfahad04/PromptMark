import functools

def tri(n):
    @functools.lru_cache(maxsize=None)
    def _get_element_value(an_index):
        # Base case for index 0, inferred from example tri(3) = [1, 3, 2, 8]
        if an_index == 0:
            return 1
        # Given base case for index 1
        elif an_index == 1:
            return 3
        # Definition for even indices
        elif an_index % 2 == 0:
            return 1 + an_index / 2
        # Definition for odd indices, using recursion
        else:
            a_one_earlier = _get_element_value(an_index - 1)
            a_two_earlier = _get_element_value(an_index - 2)
            a_one_later = _get_element_value(an_index + 1)
            return a_one_earlier + a_two_earlier + a_one_later
    
    a_output_list = []
    # Generate the first n + 1 numbers (from index 0 to n)
    for an_index in range(n + 1):
        a_output_list.append(_get_element_value(an_index))
    
    return a_output_list