def generate_integers(a, b):
    # Determines actual iteration extent.
    lower_limit = min(a, b)
    upper_limit = max(a, b)

    # Empty list: accepts all even digits.
    output_even_digits = []

    # Iterates using defined limits.
    for idx in range(lower_limit, upper_limit + 1):
        # Ascertains if digit is even; also, one digit only.
        if idx % 2 == 0 and idx < 10:
            output_even_digits.append(idx)
            
    # Delivers all accumulated even digits.
    return output_even_digits