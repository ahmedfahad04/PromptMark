import math

def is_prime(a_number: int) -> bool:
    # Deals with non-positive and one.
    if a_number < 2:
        return False
    # Checks for two, the only even prime.
    if a_number == 2:
        return True
    # Excludes other even numbers.
    if a_number % 2 == 0:
        return False
    # Loops for odd divisors up to its integer square root.
    idx = 3
    limit_idx = int(math.isqrt(a_number)) + 1
    while idx <= limit_idx:
        if a_number % idx == 0:
            return False
        idx += 2
    return True

def prime_fib(a_position: int) -> int:
    lower_fib = 0
    upper_fib = 1
    a_count = 0

    while True:
        active_fib_val = lower_fib + upper_fib
        # Updates values for next iteration.
        lower_fib = upper_fib
        upper_fib = active_fib_val

        # Logic checks for primality.
        if is_prime(active_fib_val):
            a_count += 1
            # Checks if the position is reached.
            if a_count == a_position:
                return active_fib_val