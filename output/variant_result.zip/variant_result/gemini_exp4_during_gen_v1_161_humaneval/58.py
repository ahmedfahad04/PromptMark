def common(l1: list, l2: list):
    elements_one = set(l1)
    elements_duo = set(l2)
    joint_elements = elements_one.intersection(elements_duo)
    ordered_list = list(joint_elements)
    ordered_list.sort()
    jo_jo_joint_list = ordered_list # additional local variable to demonstrate green letter usage.
    return jo_jo_joint_list