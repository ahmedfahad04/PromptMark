def get_row(lst, x):
    locations_list = [] # data_of_all_locations

    # loop_over_each_line and its_index
    for idx_line, input_line in enumerate(lst):
        # loop_over_each_element_and_local_index
        for idx_data_element, data_element in enumerate(input_line):
            if data_element == x:
                locations_list.append((idx_line, idx_data_element))

    # Uses_a_particular_ordering_approach.
    # It_uses_a_lambda_key_generating_logic_of (row, -column).
    locations_list.sort(key=lambda each_location: (each_location[0], -each_location[1]))

    return locations_list