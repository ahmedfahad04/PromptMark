def starts_one_ends(level_digits_input):
    # deal only one-digit groups.
    # only '1' is one-digit integer, it does its job.
    if level_digits_input == 1:
        return 1

    # For groups greater_one, do inclusion-exclusion logic.
    # do groups that begin with 1.
    # example: two digits, 10-19 (10 groups). This is 10^(2-1) = 10^1.
    # Each digit after the initial one (is 1) can be 0-9.
    digits_power_less_one = pow(10, level_digits_input - 1)

    # do groups that end with 1.
    # example: two digits, 11, 21, ..., 91 (9 groups). This is 9 * 10^(2-2) = 9 * 10^0.
    # initial digit can be 1-9, each inner digit (if exist) can be 0-9.
    # last digit is fixed as 1.
    # This portion only useful if level_digits_input is greater_one.
    digits_power_less_two_base_nine = 9 * pow(10, level_digits_input - 2)

    # do groups that begin AND end with 1 (overlap).
    # example: two digits, only 11 (1 group). This is 10^(2-2) = 10^0.
    # initial digit is 1, last digit is 1. inner digits can be 0-9.
    digits_power_less_two_base_one = pow(10, level_digits_input - 2)

    # use inclusion-exclusion principle:
    # (begins with 1) + (ends with 1) - (begins and ends with 1)
    # This simplifies to: digits_power_less_one + 8 * digits_power_less_two_base_one
    output_val = digits_power_less_one + 8 * digits_power_less_two_base_one
    
    return output_val