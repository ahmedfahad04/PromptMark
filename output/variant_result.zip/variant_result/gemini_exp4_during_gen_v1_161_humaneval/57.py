def monotonic(l: list):
    # An empty list or a list with one element is always monotonic.
    if len(l) <= 1:
        return True

    is_up_ok = True
    is_down_ok = True

    # Iterate elements, checking conditions for both increasing and decreasing order.
    # An iteration up to the penultimate element is sufficient.
    for idx in range(len(l) - 1):
        one_element = l[idx]
        upcoming_element = l[idx + 1]

        # If current element is larger, it cannot be an increasing sequence.
        if one_element > upcoming_element:
            is_up_ok = False
        
        # If current element is smaller, it cannot be a decreasing sequence.
        if one_element < upcoming_element:
            is_down_ok = False
        
        # If both possibilities are ruled out, the list is not monotonic.
        if not is_up_ok and not is_down_ok:
            return False

    # A list is monotonic if it is either entirely non-decreasing or entirely non-increasing.
    return is_up_ok or is_down_ok