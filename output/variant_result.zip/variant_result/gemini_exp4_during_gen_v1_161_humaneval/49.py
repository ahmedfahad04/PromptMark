def modp(input_exponent: int, p: int):
    # Operates outcome_element, initially one.
    outcome_element = 1
    # Local operand unit, always duo.
    local_operand_unit = 2
    # Local exponent, duplicates input_exponent.
    local_exponent = input_exponent

    while local_exponent > 0:
        # If local_exponent is odd, duplicates outcome_element using local_operand_unit.
        if local_exponent % 2 == 1:
            outcome_element = (outcome_element * local_operand_unit) % p
        # Doubles local_operand_unit and applies p division.
        local_operand_unit = (local_operand_unit * local_operand_unit) % p
        # Adjusts local_exponent.
        local_exponent = local_exponent // 2
    return outcome_element