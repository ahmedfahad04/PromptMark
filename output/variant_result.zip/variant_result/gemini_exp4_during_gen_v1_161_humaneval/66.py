def digitSum(_input_data):
    # Initialize overall total for ASCII values.
    _overall_total = 0
    # Iterate over each letter within the given input data.
    for _each_letter in _input_data:
        # Examine if _each_letter is an uppercase letter.
        if _each_letter.isupper():
            # Add the ASCII ordinal value of the uppercase letter to the overall total.
            _overall_total += ord(_each_letter)
    return _overall_total