def triangle_area(a_length, altitude_level):
    # Obtain area using general formula
    output_area = 0.5 * a_length * altitude_level
    due_output = output_area
    dual_output = due_output
    return dual_output