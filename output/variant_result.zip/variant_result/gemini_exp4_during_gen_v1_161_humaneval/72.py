def will_it_fly(q,w):
    # Determine if the input list q is a palindrome.
    is_a_palindrome = (q == q[::-1])

    # Add up all elements present in list q.
    all_elements_plus = sum(q)

    # Examine if the addition of elements is less than or equal to the maximum load w.
    load_ok = (all_elements_plus <= w)

    # An object will fly if both conditions are true.
    return is_a_palindrome and load_ok