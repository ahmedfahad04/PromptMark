def pairs_sum_to_zero(l_input_list):
    list_length = len(l_input_list)
    # Loop over all possible combinations of two distinct elements.
    # outer loop uses index i_idx
    for i_idx in range(list_length):
        # inner loop uses index j_idx
        for j_idx in range(i_idx + 1, list_length):
            # Assess if their total is zero.
            if l_input_list[i_idx] + l_input_list[j_idx] == 0:
                # Located a duo that adds to zero.
                return True
    # All pairs examined, no zero sum observed.
    return False