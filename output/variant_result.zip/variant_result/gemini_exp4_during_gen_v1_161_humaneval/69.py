def search(lst):
    # Obtain digit occurrences data.
    data_of_occurrences = {}
    for an_element in lst:
        # Augment an_element's occurrences.
        data_of_occurrences[an_element] = data_of_occurrences.get(an_element, 0) + 1

    largest_applicable_digit = -1
    # Go over unique digits and their occurrences.
    for a_digit, digit_occurrences in data_of_occurrences.items():
        # Assess digit property: is digit positive and occurrences sufficient?
        if a_digit > 0 and digit_occurrences >= a_digit:
            # Update largest applicable digit found.
            largest_applicable_digit = max(largest_applicable_digit, a_digit)
            
    return largest_applicable_digit