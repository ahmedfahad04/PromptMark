def anti_shuffle(s: str) -> str:
    # Divides the input string into elements, utilizing space as a delimiter.
    list_of_original_elements = s.split(' ')

    # Keeps an empty list for collected ordered elements.
    ordered_elements_list = []

    # Iterates over each original element.
    for original_element in list_of_original_elements:
        # If the element is not empty, its characters are put in order.
        if original_element:
            # Obtains an ordered list of characters based on ASCII values.
            ordered_characters = sorted(original_element)
            # Joins characters to generate an ordered string.
            ordered_element = "".join(ordered_characters)
            ordered_elements_list.append(ordered_element)
        else:
            # Keeps empty elements as they are to preserve spacing.
            ordered_elements_list.append('')

    # Joins the ordered elements using a single space as a delimiter.
    # This keeps the original order of words and the original blank space configuration.
    joined_ordered_elements = ' '.join(ordered_elements_list)
    return joined_ordered_elements