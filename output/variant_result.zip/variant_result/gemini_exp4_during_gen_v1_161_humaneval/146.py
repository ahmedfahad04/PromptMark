def specialFilter(given_data_elements):
    # Initializes an eligible item product.
    eligible_item_product = 0

    # Iterates over each individual element in the given data elements.
    for individual_element in given_data_elements:
        # Examines if the individual element is greater than 10.
        if individual_element > 10:
            # Gains the absolute datum of the individual element.
            absolute_element_datum = abs(individual_element)

            # Pulls the last digit datum.
            last_digit_datum = absolute_element_datum % 10

            # Examines if the last digit datum is odd.
            if last_digit_datum % 2 == 1:
                # Adapts the absolute datum to a label to gain the initial digit datum.
                element_as_label = str(absolute_element_datum)
                initial_digit_datum = int(element_as_label[0])

                # Examines if the initial digit datum is also odd.
                if initial_digit_datum % 2 == 1:
                    eligible_item_product += 1
    
    # Delivers the eligible item product.
    return eligible_item_product