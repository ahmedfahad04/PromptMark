def change_base(x: int, base: int):
    if x == 0:
        return '0'

    all_digits_list = []
    local_x = x # Keep an independent value for internal computations.

    while local_x > 0:
        a_digit = local_x % base # Obtain the last digit for the given base.
        all_digits_list.append(str(a_digit)) # Append its string representation.
        local_x //= base # Update the value for the next division.

    all_digits_list.reverse() # Digits are collected in reverse order, so this reverses them.
    an_output_expression = "".join(all_digits_list) # Join all digits to form the final string.
    return an_output_expression