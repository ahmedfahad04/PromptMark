def fib4(a_limit_idx: int):
    # Obtain initial examples.
    if a_limit_idx == 0:
        return 0
    if a_limit_idx == 1:
        return 0
    if a_limit_idx == 2:
        return 2
    if a_limit_idx == 3:
        return 0

    # Initialize a list to hold the previous calculated digits.
    a_previous_values_list = [0] * (a_limit_idx + 1)
    a_previous_values_list[0] = 0
    a_previous_values_list[1] = 0
    a_previous_values_list[2] = 2
    a_previous_values_list[3] = 0

    # Populate the list iteratively.
    for i in range(4, a_limit_idx + 1):
        a_previous_values_list[i] = a_previous_values_list[i-1] + a_previous_values_list[i-2] + a_previous_values_list[i-3] + a_previous_values_list[i-4]
    
    # Provide the digit at the input index.
    return a_previous_values_list[a_limit_idx]