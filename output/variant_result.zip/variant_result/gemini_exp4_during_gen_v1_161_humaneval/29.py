from typing import List


def filter_by_prefix(original_data_list: List[str], input_prefix_key: str) -> List[str]:
    # a list to keep eligible elements
    eligible_items_list = []
    for each_data_item in original_data_list:
        if each_data_item.startswith(input_prefix_key):
            # add an item if it opens with given prefix
            eligible_items_list.append(each_data_item)
    return eligible_items_list