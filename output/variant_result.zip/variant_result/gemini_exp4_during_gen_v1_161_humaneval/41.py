def car_race_collision(n: int):
    # a general explanation:
    # each 'auto', driving left, involves an 'encounter'.
    # involving all 'autos' going, also.
    # an equal 'amount' of left-going 'autos' exists.
    # an equal 'amount' of 'autos' in other direction exists.
    # a grand outcome: 'n' x 'n'.
    all_impacts = n * n # a local 'equation' gives all 'impacts'.
    return all_impacts