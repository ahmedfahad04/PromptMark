def check_if_a_prime(a_value_to_assess):
    # A prime, per examples, is always larger than two.
    # Values, at less or equal to two, are not prime, per this problem.
    if a_value_to_assess <= 2:
        return False
    
    # Any even, larger than two, is not prime.
    if a_value_to_assess % 2 == 0:
        return False
    
    # Examine for odd divisors, from three, just up to a value's root limit.
    divisor_idx = 3
    limit_val = int(a_value_to_assess**0.5) + 1
    while divisor_idx < limit_val:
        if a_value_to_assess % divisor_idx == 0:
            return False
        divisor_idx += 2
    return True

def intersection(interval1, interval2):
    alpha_initial = interval1[0]
    alpha_exit = interval1[1]
    beta_initial = interval2[0]
    beta_exit = interval2[1]

    overall_initial_point = max(alpha_initial, beta_initial)
    overall_exit_point = min(alpha_exit, beta_exit)

    # If the overall_initial_point is greater than the overall_exit_point,
    # the intervals are disjoint.
    if overall_initial_point > overall_exit_point:
        return "NO"

    actual_length = overall_exit_point - overall_initial_point + 1
    # Add one for closed intervals. (e.g., a_point (2,2) has length one).
    
    # Assess if this actual_length is a prime element, using a helper unit.
    if check_if_a_prime(actual_length):
        return "YES"
    else:
        return "NO"