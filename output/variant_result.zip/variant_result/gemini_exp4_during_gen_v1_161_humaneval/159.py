def eat(eaten_amount_already, desired_additional_units, available_units_initial):
    # Determine actual units.
    actual_units_eaten_during_period = min(desired_additional_units, available_units_initial)

    # Obtain overall eaten.
    overall_eaten_amount_after = eaten_amount_already + actual_units_eaten_during_period

    # Obtain units left.
    units_left_after_period = available_units_initial - actual_units_eaten_during_period

    return [overall_eaten_amount_after, units_left_after_period]