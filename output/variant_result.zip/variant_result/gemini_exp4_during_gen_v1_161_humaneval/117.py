def select_words(input_line, expect_amount):
    # A helper to look up the amount of consonants in a word.
    def obtain_consonant_amount(input_word):
        a_vowels = "aeiouAEIOU"
        local_consonant_amount = 0
        for each_letter in input_word:
            # If each_letter is an alphabet and not a vowel, it is a consonant.
            if each_letter.isalpha() and each_letter not in a_vowels:
                local_consonant_amount += 1
        return local_consonant_amount

    output_list = []
    # Handle the edge case of an empty input line.
    if not input_line:
        return output_list

    line_of_words = input_line.split()
    for each_word in line_of_words:
        word_consonant_amount = obtain_consonant_amount(each_word)
        # Include words that exactly contain expect_amount consonants.
        if word_consonant_amount == expect_amount:
            output_list.append(each_word)
    return output_list