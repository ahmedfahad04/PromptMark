def sort_third(l: list) -> list:
    local_data_list = list(l) # A local copy of the input list.

    elements_for_ordering = []
    indices_to_update = []

    # Iterate to identify and extract elements at indices divisible by three.
    for i in range(len(local_data_list)):
        if i % 3 == 0:
            elements_for_ordering.append(local_data_list[i])
            indices_to_update.append(i)

    elements_for_ordering.sort() # Organize the extracted elements.

    ordered_elements_idx = 0
    # Place the ordered elements back into the local list at their original positions.
    for i in indices_to_update:
        local_data_list[i] = elements_for_ordering[ordered_elements_idx]
        ordered_elements_idx += 1

    return local_data_list