def sort_even(l: list):
    # A duplicate list is generated.
    duped_list = list(l)

    # Even data elements list keeps input values.
    even_data_elements = []
    for i in range(len(l)):
        if i % 2 == 0:  # Looks if index i is even.
            even_data_elements.append(l[i])

    # Even data elements get ordered.
    even_data_elements.sort()

    # Index j guides placing even data elements.
    j = 0
    for i in range(len(duped_list)):
        if i % 2 == 0:  # Applies data to even positions.
            duped_list[i] = even_data_elements[j]
            j += 1

    return duped_list