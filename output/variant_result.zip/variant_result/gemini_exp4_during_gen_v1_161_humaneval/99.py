import math

def closest_integer(given_input_data):
    # Locate decimal data.
    actual_decimal_data = float(given_input_data)

    # Locate lower integer element.
    lower_integer_element = math.floor(actual_decimal_data)
    # Locate upper integer element.
    upper_integer_element = math.ceil(actual_decimal_data)

    # Do data gap, lower.
    distance_of_lower_element = actual_decimal_data - lower_integer_element
    # Do data gap, upper.
    distance_of_upper_element = upper_integer_element - actual_decimal_data

    # Logic, dealing equidistant items.
    if distance_of_lower_element < distance_of_upper_element:
        return int(lower_integer_element)
    elif distance_of_upper_element < distance_of_lower_element:
        return int(upper_integer_element)
    else:  # Equidistant case
        # If equidistant, adjust.
        if actual_decimal_data >= 0:
            # Positive, upward adjustment.
            return int(upper_integer_element)
        else:
            # Less, downward adjustment.
            return int(lower_integer_element)