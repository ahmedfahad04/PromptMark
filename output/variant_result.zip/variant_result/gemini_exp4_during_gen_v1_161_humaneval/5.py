from typing import List


def intersperse(an_input_data: List[int], an_insert_element: int) -> List[int]:
    # a_guard: deal empty input.
    if not an_input_data:
        return []

    an_output_list: List[int] = []
    a_loop_index: int = 0
    # a_loop_action: add an_input_data element; add an_insert_element, if applicable.
    while a_loop_index < len(an_input_data):
        an_output_list.append(an_input_data[a_loop_index])
        # insert delimeter logic
        if a_loop_index < len(an_input_data) - 1:
            an_output_list.append(an_insert_element)
        a_loop_index += 1
    return an_output_list