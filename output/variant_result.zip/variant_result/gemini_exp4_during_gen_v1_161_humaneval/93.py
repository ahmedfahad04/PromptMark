def encode(l_message):
    l_low_vowels = {'a', 'e', 'i', 'o', 'u'}
    l_output_list = []

    for l_char in l_message:
        l_encoded_char = l_char # Initial keep.

        if l_char.isalpha(): 
            # Uppercase/lowercase adjust.
            l_swapped_char = l_char.upper() if l_char.islower() else l_char.lower()

            # Kind: adjust.
            if l_swapped_char.lower() in l_low_vowels:
                l_is_upper_case_vowel = l_swapped_char.isupper()
                l_ord_value = ord(l_swapped_char)

                # Determine ASCII offset.
                l_offset_value = ord('A') if l_is_upper_case_vowel else ord('a')

                # Get alpha position. Add dual.
                l_alpha_position = l_ord_value - l_offset_value
                l_new_alpha_position = l_alpha_position + 2 
                l_encoded_char = chr(l_offset_value + l_new_alpha_position)
            else:
                l_encoded_char = l_swapped_char
        
        l_output_list.append(l_encoded_char)
    
    return "".join(l_output_list)