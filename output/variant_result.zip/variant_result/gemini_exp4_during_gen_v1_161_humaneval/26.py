from typing import List


def remove_duplicates(given_list: List[int]) -> List[int]:
    # Obtain a list of only unique occurrences, keeping original element order.
    
    # Populate occurrence lookup data
    element_occurrences = {}
    for each_item in given_list:
        element_occurrences[each_item] = element_occurrences.get(each_item, 0) + 1

    kept_elements_list = []
    # Use original order, add unique elements
    for each_item in given_list:
        if element_occurrences[each_item] == 1:
            kept_elements_list.append(each_item)

    return kept_elements_list