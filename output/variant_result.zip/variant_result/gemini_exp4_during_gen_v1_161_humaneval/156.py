def int_to_mini_roman(input_digit):
    # Lookup data for Roman numeral equivalents, ordered largest to smallest.
    # Each item is a pair: (integer value, Roman symbol string).
    lookup_data = [
        (1000, 'M'), (900, 'CM'), (500, 'D'), (400, 'CD'),
        (100, 'C'), (90, 'XC'), (50, 'L'), (40, 'XL'),
        (10, 'X'), (9, 'IX'), (5, 'V'), (4, 'IV'),
        (1, 'I')
    ]

    # Initialize an empty list to accumulate the Roman numeral parts.
    output_list = []

    # Iterate through each item's value and label in the lookup data.
    for item_value, item_label in lookup_data:
        # While the input_digit is greater than or equal to the current item_value,
        # append the item_label to the output_list and adjust input_digit.
        while input_digit >= item_value:
            output_list.append(item_label)
            input_digit -= item_value
    
    # Join all accumulated labels and convert the final string to lowercase.
    return "".join(output_list).lower()