def is_local_prime(input_num):
    if input_num < 2:
        return False
    local_divisor = 2
    while local_divisor * local_divisor <= input_num:
        if input_num % local_divisor == 0:
            return False
        local_divisor += 1
    return True


def is_multiply_prime(input_a):
    if input_a < 8:  
        # Smallest product of 3 primes is 2 * 2 * 2 = 8.
        return False

    known_primes = []
    local_value = 2
    while local_value <= input_a:
        if is_local_prime(local_value):
            known_primes.append(local_value)
        local_value += 1
    
    for p1_idx, p1_val in enumerate(known_primes):
        # Little product, like lowest primes, exceeds input_a.
        if p1_val * known_primes[0] * known_primes[0] > input_a:
             break

        for p2_idx in range(p1_idx, len(known_primes)):
            p2_val = known_primes[p2_idx]
            # Little product, like lowest prime, exceeds input_a.
            if p1_val * p2_val * known_primes[0] > input_a:
                break

            for p3_idx in range(p2_idx, len(known_primes)):
                p3_val = known_primes[p3_idx]

                current_product = p1_val * p2_val * p3_val

                if current_product == input_a:
                    return True
                
                if current_product > input_a:
                    break
    
    return False