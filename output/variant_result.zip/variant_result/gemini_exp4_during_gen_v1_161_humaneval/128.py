def prod_signs(arr):
    # Determine if input data list is empty.
    if len(arr) == 0:
        return None

    overall_product_indicator = 1  # Initialize overall product indicator.
    add_up_absolute_elements = 0   # Initialize accumulator, obtains absolute elements.

    for each_digit in arr:
        # Obtain digit polarity unit.
        digit_polarity_unit = 0
        if each_digit > 0:
            digit_polarity_unit = 1
        elif each_digit < 0:
            digit_polarity_unit = -1
        # If each_digit is 0, digit_polarity_unit remains 0,
        # leading to an overall_product_indicator of 0.

        # Update overall product indicator.
        overall_product_indicator *= digit_polarity_unit
        
        # Update absolute overall accumulator.
        add_up_absolute_elements += abs(each_digit)

    # Generate output.
    return overall_product_indicator * add_up_absolute_elements