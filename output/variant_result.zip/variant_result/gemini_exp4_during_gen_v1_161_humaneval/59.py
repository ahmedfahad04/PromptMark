def largest_prime_factor(n: int):
    # Initializes the largest possible divisor found.
    largest_possible_divisor = 1
    # Operates upon a local duplicate of input.
    local_operand_input = n

    # Divides input by 2, updates largest_possible_divisor if 2 is a part.
    while local_operand_input % 2 == 0:
        largest_possible_divisor = 2
        local_operand_input //= 2

    # Looks for odd divisors, up to square root of local_operand_input.
    loop_divisor = 3
    while loop_divisor * loop_divisor <= local_operand_input:
        # Divides input by current odd divisor, updates largest_possible_divisor.
        while local_operand_input % loop_divisor == 0:
            largest_possible_divisor = loop_divisor
            local_operand_input //= loop_divisor
        loop_divisor += 2

    # If local_operand_input is still greater than 1, it is the largest prime unit.
    if local_operand_input > 1:
        largest_possible_divisor = local_operand_input

    return largest_possible_divisor