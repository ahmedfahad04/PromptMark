import math

def max_fill(given_grid, load_capacity):
    overall_lowers = 0
    # Looping over each element in given grid.
    for each_well_data in given_grid:
        liquid_units_in_well = 0
        # Acquiring liquid units in each element.
        for liquid_unit_item in each_well_data:
            if liquid_unit_item == 1:
                liquid_units_in_well += 1
        
        # If liquid units exist, acquiring amount of pulls.
        if liquid_units_in_well > 0:
            # Applying up-leveling logic on liquid units.
            lowers_for_current_well = math.ceil(liquid_units_in_well / load_capacity)
            overall_lowers += lowers_for_current_well
            
    return overall_lowers