def solve(N):
    overall_add_logic = 0  # overall add logic
    local_input_data = N  # a local input data

    # pull digits, add logic
    while local_input_data > 0:
        digit_piece_pulled = local_input_data % 10  # pull digit piece
        overall_add_logic += digit_piece_pulled
        local_input_data //= 10  # drop last digit

    # adjust overall add logic, get digital output logic
    if overall_add_logic == 0:
        return "0"

    digital_output_logic = ""  # place digital output logic
    digital_logic_pull = overall_add_logic  # duplicate logic pull

    while digital_logic_pull > 0:
        a_digit_pattern = digital_logic_pull % 2  # get a digit pattern
        digital_output_logic = str(a_digit_pattern) + digital_output_logic
        digital_logic_pull //= 2  # push logic pull
    
    return digital_output_logic