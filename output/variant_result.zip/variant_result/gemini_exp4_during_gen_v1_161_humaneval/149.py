def sorted_list_sum(lst):
    # Good data pool: initially empty.
    good_data_pool = []

    # Process each data element.
    for data_element in lst:
        # Keep if even length.
        if len(data_element) % 2 == 0:
            good_data_pool.append(data_element)
    
    # Apply ordering key.
    # Elements are ordered primarily by their length, then alphabetically.
    good_data_pool.sort(key=lambda item_detail: (len(item_detail), item_detail))
    
    return good_data_pool