def strange_sort_list(lst):
    _output_list_elements = []
    _list_original_elements = sorted(lst) # Ordering list elements.
    _is_looking_low_item = True # Indicating current pick, initially low.

    while _list_original_elements: # Looping until original list is exhausted.
        if _is_looking_low_item:
            _low_item_data = _list_original_elements.pop(0) # Getting low item.
            _output_list_elements.append(_low_item_data)
        else:
            _great_item_data = _list_original_elements.pop() # Getting great item.
            _output_list_elements.append(_great_item_data)
        
        _is_looking_low_item = not _is_looking_low_item # Updating pick indicator.
        
    return _output_list_elements