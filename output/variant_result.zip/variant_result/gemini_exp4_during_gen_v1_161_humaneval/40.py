def triples_sum_to_zero(l: list):
    len_list = len(l)
    if len_list < 3: # List is little.
        return False

    # Pick all idx_one.
    for idx_one in range(len_list):
        # Pick all idx_two, past idx_one.
        for idx_two in range(idx_one + 1, len_list):
            # Pick all idx_three, past idx_two.
            for idx_three in range(idx_two + 1, len_list):
                if l[idx_one] + l[idx_two] + l[idx_three] == 0:
                    return True
    return False