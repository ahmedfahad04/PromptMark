def get_positive(l: list) -> list:
    a_positive_elements = []  # An output list keeping positive elements.
    for a_element in l:
        if a_element > 0:  # If element is positive, add it.
            a_positive_elements.append(a_element)
    return a_positive_elements