def move_one_ball(arr):
    # Empty list always ok.
    if not arr:
        return True

    # Obtain an ordered list for comparison.
    ordered_list = sorted(arr)
    # A duplicate list for operations.
    original_list = list(arr) 

    length_list = len(arr)
    # Loop each possible adjustment index.
    for k_idx in range(length_list):
        # A displacement of list elements.
        applied_list = original_list[-k_idx:] + original_list[:-k_idx]
        
        # Check if the adjusted list aligns with the ordered list.
        if applied_list == ordered_list:
            return True
            
    # If no adjustment yields an ordered list, it is not possible.
    return False