def split_words(txt):
    # Check for a pad delimiter
    local_pad_exists = ' ' in txt
    if local_pad_exists:
        # Divide on any pad
        return txt.split()

    # If no pad, check for a join delimiter
    local_join_exists = ',' in txt
    if local_join_exists:
        # Divide on join
        return txt.split(',')

    # If no pad and no join, acquire odd-indexed alpha units
    local_odd_alpha_units = 0
    for local_letter in txt:
        if local_letter.islower():
            # Acquire alphabetical index (0 for 'a', 1 for 'b', etc.)
            local_alpha_index = ord(local_letter) - ord('a')
            # Judge if the index is odd
            if local_alpha_index % 2 != 0:
                local_odd_alpha_units += 1
    return local_odd_alpha_units