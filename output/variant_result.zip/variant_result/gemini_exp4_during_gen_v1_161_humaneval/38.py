def decode_cyclic(s: str):
    # input string length
    input_len = len(s)
    # list to hold decoded groups
    decoded_parts = []

    # loop through input string to process groups of three
    for i_val in range((input_len + 2) // 3):
        # determine start and end indices for current group
        group_start_idx = 3 * i_val
        group_end_idx = min((3 * i_val + 3), input_len)
        
        # extract the encoded group
        encoded_group_val = s[group_start_idx:group_end_idx]
        
        # decode if the group has three characters
        if len(encoded_group_val) == 3:
            # reverse the cyclic shift: original first char is now last
            original_group_val = encoded_group_val[-1] + encoded_group_val[:-1]
        else:
            # groups shorter than three are not cycled
            original_group_val = encoded_group_val

        decoded_parts.append(original_group_val)
    
    # join all decoded parts to get the original string
    return "".join(decoded_parts)