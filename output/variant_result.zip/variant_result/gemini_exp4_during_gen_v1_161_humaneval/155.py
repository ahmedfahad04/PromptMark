def even_odd_count(a_digit_pool):
    an_absolute_pool = abs(a_digit_pool)
    even_digits_amount = 0
    odd_digits_amount = 0

    # an_initial_prepare_action_for_digits
    a_pool_label_as_digits = str(an_absolute_pool)

    # a_loop_across_each_digit_element
    for a_digit_element in a_pool_label_as_digits:
        an_integer_digit = int(a_digit_element)
        # a_check_for_parity_of_a_digit
        if an_integer_digit % 2 == 0:
            even_digits_amount += 1
        else:
            odd_digits_amount += 1

    return (even_digits_amount, odd_digits_amount)