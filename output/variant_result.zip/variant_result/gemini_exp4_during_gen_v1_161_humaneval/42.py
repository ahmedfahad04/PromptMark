def incr_list(l: list):
    output_list = [] # an output list, keeping increased elements
    for element in l:
        output_list.append(element + 1)
    return output_list