from typing import List, Optional


def longest(all_elements: List[str]) -> Optional[str]:
    # Examine if all elements list is empty.
    if not all_elements:
        return None

    longest_active_element = all_elements[0]
    greatest_active_length = len(all_elements[0])

    # Each element is processed.
    for element_data in all_elements[1:]:
        element_data_length = len(element_data)
        if element_data_length > greatest_active_length:
            greatest_active_length = element_data_length
            longest_active_element = element_data
    
    return longest_active_element