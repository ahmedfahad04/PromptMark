def sort_array(input_data_list):
    # A local utility, it obtains one kount.
    # An individual_element is its input.
    # Uses 'int.bit_count()', an innate action giving kount of digital one_units.
    def get_digital_one_kount(individual_element):
        return individual_element.bit_count()

    # Apply ordering logic.
    # Digital one kount is primary.
    # Digital identity is applied, if kounts are similar.
    ordered_output = sorted(input_data_list, key=lambda local_element: (get_digital_one_kount(local_element), local_element))
    
    return ordered_output