def even_odd_palindrome(n):
    # a private helper function to check if an integer is a palindrome
    def is_palindrome_local(a_given_input):
        input_data_as_digits_link = str(a_given_input)
        # perform check by comparing original and reversed digit link
        if input_data_as_digits_link == input_data_as_digits_link[::-1]:
            return True
        return False

    even_pal_data = 0
    odd_pal_data = 0

    # iterate loop over all integers from one up to n inclusive
    for loop_idx in range(1, n + 1):
        if is_palindrome_local(loop_idx):
            if loop_idx % 2 == 0:
                even_pal_data += 1
            else:
                odd_pal_data += 1
    
    return (even_pal_data, odd_pal_data)