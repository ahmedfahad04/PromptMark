import math

def is_prime_judgement(a_number):
    # numbers less than 2 are not prime
    if a_number < 2:
        return False
    # 2 is the only even prime number
    if a_number == 2:
        return True
    # all other even numbers are not prime
    if a_number % 2 == 0:
        return False
    # check for divisors from 3 up to the integer square root
    a_limit = math.isqrt(a_number)
    for an_index in range(3, a_limit + 1, 2):
        if a_number % an_index == 0:
            return False
    return True

def digits_addition(a_number):
    overall_sum = 0
    # iterate through digits of the number
    for a_digit_char in str(a_number):
        overall_sum += int(a_digit_char)
    return overall_sum

def skjkasdkd(lst):
    largest_prime_located = -1
    for an_element in lst:
        if is_prime_judgement(an_element):
            if an_element > largest_prime_located:
                largest_prime_located = an_element
    
    return digits_addition(largest_prime_located)