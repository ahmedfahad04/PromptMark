def iscube(a):
    # Obtain absolute value of input.
    local_abs_input = abs(a)
    
    # An approximate integer cube root is calculated.
    # Use of round() allows coping with float calculation inaccuracies.
    a_approx_look = int(round(local_abs_input**(1.0/3.0)))
    
    # Determine potential integer root based on the original input's polarity.
    if a < 0:
        potential_value_of_root = -a_approx_look
    else:
        potential_value_of_root = a_approx_look
    
    # Look at the cube of the potential root.
    output_cube_val = potential_value_of_root * potential_value_of_root * potential_value_of_root
    
    return output_cube_val == a