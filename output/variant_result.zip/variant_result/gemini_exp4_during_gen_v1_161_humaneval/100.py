def make_a_pile(n):
    # An overall pile data list.
    an_overall_pile_data = []
    
    # An initial level obtains units.
    a_pile_items = n
    
    # Loop over all levels.
    for an_idx in range(n):
        # Add level units data.
        an_overall_pile_data.append(a_pile_items)
        
        # Utilize prior units, add.
        a_pile_items += 2
        
    # Output overall pile data.
    return an_overall_pile_data