def solve(s):
    a_letter_is_present = False
    for a_given_datum in s:
        if a_given_datum.isalpha():
            a_letter_is_present = True
            break  # Exit early if a letter is present

    if not a_letter_is_present:
        # If a letter is absent, do invert.
        return s[::-1]
    
    an_output_list = []
    for a_given_datum in s:
        if a_given_datum.isalpha():
            # Up or down letter.
            if a_given_datum.islower():
                an_output_list.append(a_given_datum.upper())
            else:
                an_output_list.append(a_given_datum.lower())
        else:
            # Keep data as it is.
            an_output_list.append(a_given_datum)
            
    # Join output data.
    a_processed_output_data = "".join(an_output_list)
    return a_processed_output_data