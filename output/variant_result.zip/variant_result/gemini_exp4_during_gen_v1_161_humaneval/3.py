from typing import List


def below_zero(operations: List[int]) -> bool:
    # Initializes account_data, a ledger.
    account_data = 0

    # Iterates, examining each_deal.
    for each_deal in operations:
        # Adds each_deal, updating account_data.
        account_data += each_deal

        # If account_data drops, declare issue.
        if account_data < 0:
            return True
    
    # All dealings okay, indicates good ledger.
    return False