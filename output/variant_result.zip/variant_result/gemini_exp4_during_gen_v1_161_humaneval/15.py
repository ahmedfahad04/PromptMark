def string_sequence(u_upper_limit: int) -> str:
    # A dynamic list to hold individual number strings.
    a_elements = []
    # Iterate from zero up to the upper limit, inclusive.
    for i_index in range(u_upper_limit + 1):
        a_elements.append(str(i_index))
    # Join all collected elements with a space.
    o_joined_data = " ".join(a_elements)
    return o_joined_data