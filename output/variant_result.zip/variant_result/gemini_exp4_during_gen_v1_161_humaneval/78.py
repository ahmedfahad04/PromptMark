def hex_key(an_input_value):
    # Obtain count for prime hexadecimal digits.
    occur_total = 0
    # List allowed prime decimal values for checking.
    good_prime_values = {2, 3, 5, 7, 11, 13}

    for each_char_digit in an_input_value:
        # Parse digit to its decimal equivalent.
        parsed_digit_val = int(each_char_digit, 16)
        
        # Look if decimal value is a known prime.
        if parsed_digit_val in good_prime_values:
            occur_total += 1
            
    return occur_total