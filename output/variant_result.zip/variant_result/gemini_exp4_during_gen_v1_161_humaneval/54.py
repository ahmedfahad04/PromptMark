def same_chars(one_data: str, other_data: str) -> bool:
    # Get unique letters for one_data.
    one_data_letters = set(one_data)
    
    # Get unique letters for other_data.
    other_data_letters = set(other_data)
    
    # Look if both letter groups are equal.
    return one_data_letters == other_data_letters