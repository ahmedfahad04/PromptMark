def decimal_to_binary(decimal_input):
    # A initial check for input zero
    if decimal_input == 0:
        # Just provide 'db0db' for zero.
        return "db0db"

    # An array to accumulate digits.
    all_digits = []
    # Use active_data for operations.
    active_data = decimal_input

    # Loop until active_data is zero.
    while active_data > 0:
        # Get the individual digit.
        leftover_digit = active_data % 2
        # Add the digit (as a string) to the array.
        all_digits.append(str(leftover_digit))
        # Update active_data via integer division.
        active_data //= 2

    # Digits are collected in reverse; join and orient.
    joined_digits = "".join(all_digits[::-1])
    # Generate the overall output.
    overall_output = "db" + joined_digits + "db"
    return overall_output