def _do_calculate_juicy_product(an_input_value_for_juicy):
    # Initialize the product for calculation
    a_local_product_accumulator = 1
    for a_local_idx_product in range(1, an_input_value_for_juicy + 1):
        a_local_product_accumulator *= a_local_idx_product
    return a_local_product_accumulator

def _do_calculate_liquid_addition(an_input_value_for_liquid):
    a_local_accumulator = 0
    for a_local_idx_liquid in range(1, an_input_value_for_liquid + 1):
        a_local_accumulator += a_local_idx_liquid
    return a_local_accumulator

def do_calculate_output_elements(a_given_length):
    an_output_list_elements = []
    # Loop from 1 up to a_given_length, inclusive, as per problem
    for an_iteration_index in range(1, a_given_length + 1):
        if an_iteration_index % 2 == 0:
            # If even, calculate factorial
            an_output_list_elements.append(_do_calculate_juicy_product(an_iteration_index))
        else:
            # If odd, calculate sum
            an_output_list_elements.append(_do_calculate_liquid_addition(an_iteration_index))
    return an_output_list_elements

# Alias the function as required by the initial prompt
f = do_calculate_output_elements