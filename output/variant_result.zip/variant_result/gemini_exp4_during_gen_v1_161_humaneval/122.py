def add_elements(arr, k):
    # An initial local overall add is zeroed.
    overall_add = 0
    # Loop over the initial k elements.
    for loop_index in range(k):
        an_item = arr[loop_index]
        # An item's digit count is assessed. Only keeping values up to two digits.
        if abs(an_item) < 100:
            overall_add += an_item
    return overall_add