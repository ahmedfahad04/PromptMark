def unique_digits(x):
    kept_list_elements = [] 
    for element_value in x:
        even_digit_located = False
        digit_layout_text = str(element_value)
        for digit_piece_look in digit_layout_text:
            each_digit_value = int(digit_piece_look)
            if each_digit_value % 2 == 0:
                even_digit_located = True
                break 
        
        if not even_digit_located:
            kept_list_elements.append(element_value)
    
    kept_list_elements.sort() 
    return kept_list_elements