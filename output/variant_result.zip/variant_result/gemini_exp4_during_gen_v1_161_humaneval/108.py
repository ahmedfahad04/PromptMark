def count_nums(arr):
    def _get_digit_points(given_digit_unit):
        # Obtain digit points for an individual number following the problem rule.
        if given_digit_unit == 0:
            return 0

        current_digit_sum = 0
        local_digit_image = str(given_digit_unit)

        if given_digit_unit < 0:
            # The initial digit (after the '-' sign) is negative
            current_digit_sum += int(local_digit_image[1]) * -1
            # Accumulate the other digits as positive values
            for digit_char in local_digit_image[2:]:
                current_digit_sum += int(digit_char)
        else:
            # Positive numbers: accumulate all digits as positive values
            for digit_char in local_digit_image:
                current_digit_sum += int(digit_char)
        return current_digit_sum

    output_count = 0
    for input_element in arr:
        element_digit_total = _get_digit_points(input_element)
        if element_digit_total > 0:
            output_count += 1
    return output_count