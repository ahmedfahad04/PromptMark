def choose_num(x, upper_limit):
    # If x is greater, then invalid interval.
    if x > upper_limit:
        return -1

    # Loop downwards. Just locate an even integer.
    for a_loop_idx in range(upper_limit, x - 1, -1):
        # Is a_loop_idx an even integer?
        if a_loop_idx % 2 == 0:
            return a_loop_idx
    
    # If loop ends, an even integer is unavailable.
    return -1