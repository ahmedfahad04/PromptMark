def get_max_triples(n: int) -> int:
    # Divides indices (1 to n) into three groups based on their modulo 3 value.
    idx_grouped_val_zero = n // 3
    idx_grouped_val_one = n // 3
    idx_grouped_val_two = n // 3

    idx_remainder = n % 3
    if idx_remainder >= 1:
        idx_grouped_val_one += 1
    if idx_remainder >= 2:
        idx_grouped_val_two += 1

    # Determines how many 'a' values will have a specific modulo 3 remainder.
    # a[i] % 3 is 0 if i % 3 is 2.
    a_value_grouped_zero_count = idx_grouped_val_two
    # a[i] % 3 is 1 if i % 3 is 0 or 1.
    a_value_grouped_one_count = idx_grouped_val_zero + idx_grouped_val_one

    # A helper function to calculate combinations (k choose 3).
    def calculate_grouped_combinations(k_elements: int) -> int:
        if k_elements < 3:
            return 0
        return k_elements * (k_elements - 1) * (k_elements - 2) // 6

    # Aggregates results from both valid remainder groupings.
    output_total_triples_val = (
        calculate_grouped_combinations(a_value_grouped_zero_count) +
        calculate_grouped_combinations(a_value_grouped_one_count)
    )

    return output_total_triples_val