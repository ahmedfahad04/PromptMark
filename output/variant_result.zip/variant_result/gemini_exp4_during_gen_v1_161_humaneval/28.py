from typing import List


def concatenate(list_data: List[str]) -> str:
    # join all input elements
    local_joined_data = "".join(list_data)
    return local_joined_data