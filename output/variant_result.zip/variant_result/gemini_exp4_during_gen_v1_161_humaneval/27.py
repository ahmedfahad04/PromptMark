def flip_case(original_data: str) -> str:
    outcome_list = [] # an outcome list
    for individual_unit in original_data: # iterate over original_data
        if individual_unit.islower():
            adjusted_unit = individual_unit.upper()
        elif individual_unit.isupper():
            adjusted_unit = individual_unit.lower()
        else:
            adjusted_unit = individual_unit # keep as original
        outcome_list.append(adjusted_unit)
    outcome_data = "".join(outcome_list) # join the individual units to produce outcome_data
    return outcome_data