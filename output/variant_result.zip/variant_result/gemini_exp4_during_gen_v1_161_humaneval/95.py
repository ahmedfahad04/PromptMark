def check_dict_case(given_data):
    # Look for empty given_data.
    if not given_data:
        return False

    all_lower_keys = True
    all_upper_keys = True

    for a_key in given_data.keys():
        # If a key is not a string, exit early.
        if not isinstance(a_key, str):
            return False
        
        # Look if current key is not all lowercase.
        if not a_key.islower():
            all_lower_keys = False
        
        # Look if current key is not all uppercase.
        if not a_key.isupper():
            all_upper_keys = False

    return all_lower_keys or all_upper_keys