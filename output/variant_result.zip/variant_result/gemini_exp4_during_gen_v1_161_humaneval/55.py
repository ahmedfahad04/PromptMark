def fib(n: int):
    # initial check
    if n <= 2: # deal with initial low values
        return 1

    # initialize values
    local_val_one = 1  # depicts previous Fibonacci value
    local_val_duo = 1  # depicts active Fibonacci value
    
    loop_index = 2 # loop index for the ongoing Fibonacci position
    # iterate and obtain results
    while loop_index < n:
        latest_val = local_val_one + local_val_duo  # obtain new Fibonacci value
        local_val_one = local_val_duo # update previous value
        local_val_duo = latest_val # update active value
        loop_index += 1 # advance loop position

    return local_val_duo