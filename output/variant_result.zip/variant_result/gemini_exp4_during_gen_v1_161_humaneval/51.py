def remove_vowels(original_data):
    # global_vowel_lookup includes all lowercase and UPPERCASE vowels.
    global_vowel_lookup = {'a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U'}
    
    # kept_letters is a list where non-vowel characters will be accumulated.
    kept_letters = []
    
    # Iterate through each_letter in original_data.
    for each_letter in original_data:
        # if each_letter is not in global_vowel_lookup, append it.
        if each_letter not in global_vowel_lookup:
            kept_letters.append(each_letter)
            
    # Join the kept_letters to form the output string.
    return "".join(kept_letters)