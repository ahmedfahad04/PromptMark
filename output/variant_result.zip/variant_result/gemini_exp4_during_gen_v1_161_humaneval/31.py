def is_prime(an_input_value):
    # Deals with values less than or equal to one.
    if an_input_value <= 1:
        return False
    # Looks for a unique prime, like two.
    if an_input_value == 2:
        return True
    # Evaluates even values greater than two.
    if an_input_value % 2 == 0:
        return False

    # Loops just up to the integer root of the value.
    an_upper_limit = int(an_input_value**0.5) + 1
    for a_possible_divisor in range(3, an_upper_limit, 2):
        if an_input_value % a_possible_divisor == 0:
            return False
    return True