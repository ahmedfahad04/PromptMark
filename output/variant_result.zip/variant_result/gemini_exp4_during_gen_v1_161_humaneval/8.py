from typing import List, Tuple


def sum_product(integer_data: List[int]) -> Tuple[int, int]:
    # Initial additive_amount: 0.
    overall_additive_amount = 0
    # Initial gains_amount: 1.
    group_gains_amount = 1

    # Each item_unit iteration.
    for item_unit in integer_data:
        # Add item_unit.
        overall_additive_amount += item_unit
        # Apply item_unit (product-like).
        group_gains_amount *= item_unit
    
    # Deliver overall aggregate pair.
    return (overall_additive_amount, group_gains_amount)