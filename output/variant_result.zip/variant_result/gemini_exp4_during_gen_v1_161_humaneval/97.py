def multiply(a, input_other):
    # get unit digit
    local_digit_one = abs(a) % 10
    # get other unit digit
    local_digit_other = abs(input_other) % 10
    # do digit product
    product_of_digits = local_digit_one * local_digit_other
    return product_of_digits