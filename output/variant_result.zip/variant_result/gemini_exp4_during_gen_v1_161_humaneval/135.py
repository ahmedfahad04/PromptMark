def can_arrange(arr):
    # Obtain array's length.
    a_l_ength = len(arr)

    # Loop downward, examining elements.
    # An 'i_dx' index points to the current element.
    for i_dx in range(a_l_ength - 1, 0, -1):
        # A check if an element is less than its immediate preceding element.
        if arr[i_dx] < arr[i_dx - 1]:
            # If so, this 'i_dx' is the largest index satisfying the condition.
            return i_dx
    
    # All elements are in increasing order; no such index exists.
    return -1