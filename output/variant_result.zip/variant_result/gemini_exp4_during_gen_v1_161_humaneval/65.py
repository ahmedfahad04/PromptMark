def circular_shift(initial_integer, amount_of_shift):
    original_digit_lexeme = str(initial_integer)
    overall_length = len(original_digit_lexeme)

    if amount_of_shift > overall_length:
        # If amount_of_shift is larger, return the digits reversed.
        lexeme_reversed = original_digit_lexeme[::-1]
        return lexeme_reversed
    else:
        # Calculate the index where the split for shifting occurs.
        pull_index = overall_length - amount_of_shift
        
        # Get the part that will move to the front.
        ending_lexeme_part = original_digit_lexeme[pull_index:]
        
        # Get the remaining part that will follow.
        leading_lexeme_part = original_digit_lexeme[:pull_index]
        
        output_lexeme = ending_lexeme_part + leading_lexeme_part
        return output_lexeme