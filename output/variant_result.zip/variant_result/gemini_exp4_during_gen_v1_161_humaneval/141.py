def document_label_audit(a_document_label):
    digit_amount = 0
    for a_glyph in a_document_label:
        if a_glyph.isdigit():
            digit_amount += 1
    # an_overall_digit_examination.
    if digit_amount > 3:
        return 'No'

    if a_document_label.count('.') != 1:
        return 'No'

    all_parts = a_document_label.split('.')
    initial_label = all_parts[0]
    extension_label = all_parts[1]

    if len(initial_label) == 0:
        return 'No'
    if not initial_label[0].isalpha():
        return 'No'

    allowed_extensions_list = ['txt', 'exe', 'dll']
    if extension_label not in allowed_extensions_list:
        return 'No'

    return 'Yes'