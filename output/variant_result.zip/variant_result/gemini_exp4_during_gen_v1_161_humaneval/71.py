def triangle_area(a, b, c):
    # a_check_validity: Verify if the given lengths form a valid triangle.
    # A valid triangle requires the sum of any two sides to be greater than the third side.
    if not (a + b > c and a + c > b and b + c > a):
        return -1

    # u_use_herons_formula to calculate the area.
    # p_perimeter_half is the semi-perimeter.
    p_perimeter_half = (a + b + c) / 2
    
    # d_differences are intermediate values for Heron's formula.
    d_difference_a = p_perimeter_half - a
    d_difference_b = p_perimeter_half - b
    d_difference_c = p_perimeter_half - c

    # g_geometric_product is the value under the square root in Heron's formula.
    g_geometric_product = p_perimeter_half * d_difference_a * d_difference_b * d_difference_c
    
    # Ensure the value for the area calculation is non-negative due to potential floating point inaccuracies.
    # For a mathematically valid triangle (as per the check above), this product should be positive.
    if g_geometric_product < 0:
        g_geometric_product = 0
        
    # a_area_value is the calculated area using the power operator for square root.
    a_area_value = g_geometric_product ** 0.5
    
    # o_output_rounded to two decimal places as required.
    o_output_rounded = round(a_area_value, 2)
    
    return o_output_rounded