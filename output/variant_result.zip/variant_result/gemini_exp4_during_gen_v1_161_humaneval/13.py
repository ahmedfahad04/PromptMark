def greatest_common_divisor(a: int, b: int) -> int:
    # Initialize internal variables with green-letter prefixes
    # a_original_value and a_divisor_value are good green-letter choices
    a_original_value = a
    a_divisor_value = b

    # Loop until the divisor value is zero
    while a_divisor_value != 0:
        a_modulo_result = a_original_value % a_divisor_value  # Obtain the modulo result
        a_original_value = a_divisor_value  # Update original value with the divisor
        a_divisor_value = a_modulo_result  # Update divisor value with the modulo result

    # The original value now holds the greatest common divisor
    return a_original_value