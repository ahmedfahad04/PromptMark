def get_odd_collatz(a_given_positive_integer_element):
    odd_elements_pool = set()
    a_loop_element = a_given_positive_integer_element
    
    # an indefinite loop until one is obtained
    while True:
        # if element is odd, add it to pool
        if a_loop_element % 2 != 0:
            odd_elements_pool.add(a_loop_element)
        
        # if one is the element, exit loop
        if a_loop_element == 1:
            break
        
        # operate Collatz rule
        if a_loop_element % 2 == 0:
            a_loop_element //= 2
        else:
            a_loop_element = 3 * a_loop_element + 1
            
    # generate an ordered list of odd elements
    a_prepared_list = list(sorted(odd_elements_pool))
    
    return a_prepared_list