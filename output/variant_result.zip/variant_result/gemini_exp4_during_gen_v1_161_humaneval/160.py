def do_algebra(operations_list, operands_data):
    # Initialize the algebraic expression with the first operand.
    algebra_expression = str(operands_data[0])

    # Iterate through the operations and remaining operands to build the expression string.
    for idx, operation_element in enumerate(operations_list):
        algebra_expression += operation_element
        algebra_expression += str(operands_data[idx + 1])

    # Evaluate the complete algebraic expression.
    return eval(algebra_expression)