def is_bored(data_input_phrase):
    # Initializes a ledger for keeping pleasure points (boredom instances).
    pleasure_points_ledger = 0

    # Defines phrase delimiters.
    delimiters_for_phrases = ['.', '?', '!']

    # A list holding character data of the active phrase.
    leading_phrase_elements_list = []

    # A list to contain all complete, extracted phrases.
    all_phrases_data = []

    # Loops over each data unit in the input data.
    for a_data_unit in data_input_phrase:
        if a_data_unit in delimiters_for_phrases:
            # If a delimiter is located, it indicates the end of a phrase.
            if leading_phrase_elements_list: # only if elements exist, allowing a phrase.
                all_phrases_data.append("".join(leading_phrase_elements_list))
                leading_phrase_elements_list = [] # Empties list.
        else:
            leading_phrase_elements_list.append(a_data_unit)

    # Appends final phrase if input data lacks an end delimiter.
    if leading_phrase_elements_list:
        all_phrases_data.append("".join(leading_phrase_elements_list))

    # Examines each phrase data element to identify pleasure points.
    for a_phrase_data_element in all_phrases_data:
        # Prepares phrase data.
        prepared_phrase_data = a_phrase_data_element.strip()

        # Obtains lexical units of prepared phrase.
        local_lexical_units = prepared_phrase_data.split()

        if local_lexical_units: # Ensures the unit list is populated.
            # Obtains the leading lexical unit of the phrase.
            leading_lexical_unit = local_lexical_units[0]

            # Examines if leading lexical unit, lowercased, equals "i".
            if leading_lexical_unit.lower() == "i":
                pleasure_points_ledger += 1 # Adjusts ledger value upward.

    return pleasure_points_ledger