def solution(an_input_list_data):
    # Initialize an overall amount accumulator.
    a_grand_overall_amount = 0

    # Iterate, using an index and an element, an input list data.
    for an_index, an_element in enumerate(an_input_list_data):
        # If an index is an even position.
        if an_index % 2 == 0:
            # If an element is odd.
            if an_element % 2 != 0:
                # Add an odd element (at an even position), overall amount increases.
                a_grand_overall_amount += an_element

    # Output an accumulated grand overall amount.
    return a_grand_overall_amount