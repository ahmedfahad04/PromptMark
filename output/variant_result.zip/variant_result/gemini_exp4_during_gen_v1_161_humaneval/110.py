def exchange(lst1, lst2):
    odd_elements_one = 0
    # Obtain count of odd elements in lst1.
    for ele_one in lst1:
        if ele_one % 2 != 0:
            odd_elements_one += 1

    even_elements_do = 0
    # Obtain count of even elements in lst2.
    for ele_do in lst2:
        if ele_do % 2 == 0:
            even_elements_do += 1
    
    # Judge if even elements available in lst2 are adequate for odd elements in lst1.
    if even_elements_do >= odd_elements_one:
        return "YES"
    else:
        return "NO"