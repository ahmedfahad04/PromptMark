def fix_spaces(initial_data):
    # An output list to gather processed characters.
    output_elements = []
    # An integer keeping accurate amount of adjacent spaces.
    adjacent_gap_amount = 0

    # Iterate over each letter in input data.
    for each_letter in initial_data:
        if each_letter == ' ':
            adjacent_gap_amount += 1
        else:
            # If adjacent gap amount is positive.
            if adjacent_gap_amount > 0:
                # If adjacent gap amount is less or equal to two.
                if adjacent_gap_amount <= 2:
                    for _ in range(adjacent_gap_amount):
                        # Add an underscore.
                        output_elements.append('_')
                else:
                    # Add a dash.
                    output_elements.append('-')
                # Adjust adjacent gap amount to zero.
                adjacent_gap_amount = 0
            # Add current letter.
            output_elements.append(each_letter)

    # Handle any remaining trailing gaps.
    if adjacent_gap_amount > 0:
        if adjacent_gap_amount <= 2:
            for _ in range(adjacent_gap_amount):
                output_elements.append('_')
        else:
            output_elements.append('-')

    # Join elements to form the ultimate output string.
    return "".join(output_elements)