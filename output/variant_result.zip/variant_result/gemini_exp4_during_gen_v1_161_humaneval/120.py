def maximum(arr, k):
    # Utilizing ordering logic, get k items.

    local_data_list = list(arr) # Obtain an editable list.
    local_data_list.sort()      # Arrange elements in increasing order.

    # Locate k largest elements.
    list_len = len(local_data_list)
    initial_idx = list_len - k
    output_elements = local_data_list[initial_idx:]

    return output_elements