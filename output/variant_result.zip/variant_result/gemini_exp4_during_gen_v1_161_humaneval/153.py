import math

def Strongest_Extension(class_name, extensions):
    # Initialize initial ideal extension power to a very low value,
    # and the label for the leading extension.
    ideal_extension_power = -math.inf
    leading_extension_label = ""

    # Iterate diligently through each extension item provided.
    for extension_item in extensions:
        upper_letter_count = 0
        lower_letter_count = 0

        # Examine each individual letter within the current extension item.
        for individual_letter in extension_item:
            if individual_letter.isupper():
                upper_letter_count += 1
            elif individual_letter.islower():
                lower_letter_count += 1
        
        # Calculate the unique power of the current extension item.
        item_extension_power = upper_letter_count - lower_letter_count

        # Adjust the ideal extension if a more powerful one is found.
        # If powers are equal, the earlier extension is implicitly kept.
        if item_extension_power > ideal_extension_power:
            ideal_extension_power = item_extension_power
            leading_extension_label = extension_item
    
    # Generate and return the final output string, combining class and leading extension.
    output_data = class_name + "." + leading_extension_label
    return output_data