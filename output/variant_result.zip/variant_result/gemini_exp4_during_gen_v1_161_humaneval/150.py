import math

def _is_a_prime_element(an_integer_data: int) -> bool:
    """Check if an_integer_data is a prime number."""
    if an_integer_data < 2:
        return False
    if an_integer_data == 2:
        return True
    if an_integer_data % 2 == 0:
        return False
    # Only check odd divisors up to the square root of the integer data.
    a_limit = int(math.isqrt(an_integer_data)) + 1
    for i_divisor in range(3, a_limit, 2):
        if an_integer_data % i_divisor == 0:
            return False
    return True

def x_or_y(an_integer_data: int, an_x_element: int, an_other_element: int) -> int:
    """
    An elementary program which should return the value of an_x_element
    if an_integer_data is a prime number and should return the value of
    an_other_element otherwise.
    """
    if _is_a_prime_element(an_integer_data):
        return an_x_element
    else:
        return an_other_element