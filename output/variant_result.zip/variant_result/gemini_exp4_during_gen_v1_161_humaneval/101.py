def words_string(s: str) -> list[str]:
    # prepare data by unifying delimiters to spaces
    processed_data = s.replace(',', ' ')
    
    # obtain list of all individual pieces
    list_of_pieces = processed_data.split(' ')
    
    all_parsed_data = []
    # add only valid, non-empty pieces to the final collection
    for each_piece in list_of_pieces:
        if each_piece: # Only add if the piece is not an empty string
            all_parsed_data.append(each_piece)
            
    return all_parsed_data