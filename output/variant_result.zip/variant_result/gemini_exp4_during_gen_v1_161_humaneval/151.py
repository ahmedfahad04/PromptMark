def double_the_difference(a_data_list):
    # Initializes an overall sum accumulator.
    overall_grand_sum = 0
    for a_list_element in a_data_list:
        # Guarantees the element is an integer.
        if isinstance(a_list_element, int):
            # Assesses if the integer element is positive and odd.
            if a_list_element > 0 and a_list_element % 2 != 0:
                overall_grand_sum += a_list_element * a_list_element
    return overall_grand_sum