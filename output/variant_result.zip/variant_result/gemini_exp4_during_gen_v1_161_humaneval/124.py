def valid_date(date_input_label):
    # A date input data initial analysis
    if not date_input_label:
        return False

    # Date units group decomposition
    date_units_group = date_input_label.split('-')

    # Length of date_units_group evaluation
    if len(date_units_group) != 3:
        return False

    lunar_period_label, day_unit_label, annual_period_label = date_units_group

    # Digits and lengths data pre-check
    if not (lunar_period_label.isdigit() and day_unit_label.isdigit() and annual_period_label.isdigit()):
        return False
    if not (len(lunar_period_label) == 2 and len(day_unit_label) == 2 and len(annual_period_label) == 4):
        return False

    # Parsing units data
    try:
        parsed_lunar_period = int(lunar_period_label)
        parsed_day = int(day_unit_label)
        parsed_annual_period = int(annual_period_label) # Annual period is not directly used for validation rules, but is parsed.
    except ValueError:
        return False

    # Lunar period value evaluation
    if not (1 <= parsed_lunar_period <= 12):
        return False

    # Day duration logic evaluation
    long_duration_units = [1, 3, 5, 7, 8, 10, 12] # Lunar periods with 31 days
    june_duration_units = [4, 6, 9, 11] # Lunar periods with 30 days
    duo_period_unit = 2 # Lunar period 2 with 29 days

    if parsed_lunar_period in long_duration_units:
        if not (1 <= parsed_day <= 31):
            return False
    elif parsed_lunar_period in june_duration_units:
        if not (1 <= parsed_day <= 30):
            return False
    elif parsed_lunar_period == duo_period_unit:
        if not (1 <= parsed_day <= 29):
            return False
    else:
        # An exceptional logic indication
        return False

    # All evaluations passed
    return True