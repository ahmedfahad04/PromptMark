def by_length(arr):
    if not arr:
        return []

    # Prepare a list to collect valid digits (1 through 9 inclusive).
    legal_digits = []
    for an_element in arr:
        if 1 <= an_element <= 9:
            legal_digits.append(an_element)

    # Order the collected digits numerically.
    legal_digits.sort()

    # Invert the order of the now sorted digits.
    legal_digits.reverse()

    # Define a lookup for digit-to-word conversions.
    digit_phrase_key = {
        1: "One", 2: "Two", 3: "Three", 4: "Four", 5: "Five",
        6: "Six", 7: "Seven", 8: "Eight", 9: "Nine"
    }

    # Generate a list of words corresponding to the digits.
    output_phrases = []
    for a_digit in legal_digits:
        output_phrases.append(digit_phrase_key[a_digit])

    return output_phrases