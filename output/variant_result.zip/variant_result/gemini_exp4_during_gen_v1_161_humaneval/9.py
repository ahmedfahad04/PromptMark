from typing import List, Tuple


def generate_peak_list(input_data: List[int]) -> List[int]:
    # Examine for an empty list
    if not input_data:
        return []

    # Introduce peak value using initial element
    peak_value_observed: int = input_data[0]
    output_accumulator: List[int] = [peak_value_observed]

    # Loop over additional elements
    for data_unit in input_data[1:]:
        # Examine if active element is larger, update peak
        if data_unit > peak_value_observed:
            peak_value_observed = data_unit
        output_accumulator.append(peak_value_observed)
    
    return output_accumulator