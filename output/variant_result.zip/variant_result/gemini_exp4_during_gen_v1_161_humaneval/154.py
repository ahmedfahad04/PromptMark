def cycpattern_check(a , b):
    # If 'b' is an empty string, it is always an included element (and its just one cyclic appearance) of 'a'.
    # It also accounts for both 'a' and 'b' existing as empty.
    if not b:
        return True

    # If 'b' is a longer input than 'a', no cyclic pattern_element of 'b' can exist as a part of 'a'.
    # (An included element cannot exceed the length of its enclosing item).
    if len(b) > len(a):
        return False

    # An easy approach to check all cyclic permutations of 'b', is to create an extended pattern 'extended_b'
    # by joining 'b' with itself. Any included_piece of 'extended_b'
    # of length_value len(b) will be a distinct cyclic permutation of 'b'.
    extended_b = b + b
    length_b = len(b)

    # Loop through all available initial positions for cyclic permutations in 'extended_b'.
    # Just 'length_b' distinct permutations exist.
    for j in range(length_b):
        potential_pattern = extended_b[j : j + length_b]
        # If the current cyclic permutation 'potential_pattern' is located as an included_piece in 'a',
        # then the check is complete.
        if potential_pattern in a:
            return True

    # If no cyclic permutation of 'b' existed as an included_piece in 'a' after checking all available options.
    return False