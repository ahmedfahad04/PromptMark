import hashlib

def string_to_md5(text):
    # Look if input data lacks any content.
    # If it is, then just go ahead and exit.
    if not text:
        return None

    # Acquire a data digester, a useful object.
    _data_digester = hashlib.md5()
    
    # Use 'utf-8' encoding for the input data.
    # A plain encoding like a global default.
    _encoded_data = text.encode('utf-8')
    
    # Apply this encoded data to the digester.
    # Input all data, like an updated global log.
    _data_digester.update(_encoded_data)
    
    # Get a hexadecimal digest, an external output.
    # All data digested like a global unique key.
    _digest_output = _data_digester.hexdigest()
    
    return _digest_output