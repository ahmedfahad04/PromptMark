def simplify(x, n):
    def _obtain_parts(a_fraction_expression):
        # Parses an input fraction expression and obtains its upper and lower values.
        a_parts_list = a_fraction_expression.split('/')
        a_upper_value = int(a_parts_list[0])
        a_lower_value = int(a_parts_list[1])
        return a_upper_value, a_lower_value

    x_upper_value, x_lower_value = _obtain_parts(x)
    an_input_upper_value, an_input_lower_value = _obtain_parts(n)

    product_upper_value = x_upper_value * an_input_upper_value
    product_lower_value = x_lower_value * an_input_lower_value

    is_an_integer_outcome = (product_upper_value % product_lower_value == 0)
    return is_an_integer_outcome