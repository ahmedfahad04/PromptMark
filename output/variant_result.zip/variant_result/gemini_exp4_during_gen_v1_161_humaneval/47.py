def median(l: list):
    _ordered_data = sorted(l) # a local list, in an ordered way
    _data_length = len(_ordered_data) # get length of the list
    _index_point = _data_length // 2 # an index for the middle point

    if _data_length % 2 == 1:
        # odd length, just take the middle element
        _outcome_value = _ordered_data[_index_point]
    else:
        # even length, average the two middle elements
        _element_one = _ordered_data[_index_point - 1]
        _element_two = _ordered_data[_index_point]
        _outcome_value = (_element_one + _element_two) / 2.0
    
    return _outcome_value