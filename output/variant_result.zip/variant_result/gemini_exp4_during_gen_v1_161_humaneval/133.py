import math

def sum_squares(input_data):
    # Initializes an accumulator for the overall sum.
    overall_accumulator = 0

    # Iterates across each item in the input data list.
    for each_item in input_data:
        # Applies ceiling operation to obtain the upper integer limit.
        adjusted_datum = math.ceil(each_item)
        # Determines the power of two for the adjusted datum.
        item_power_two = adjusted_datum * adjusted_datum
        # Accumulates the power of two into the overall_accumulator.
        overall_accumulator += item_power_two
    
    # Delivers the accumulated overall sum.
    return overall_accumulator