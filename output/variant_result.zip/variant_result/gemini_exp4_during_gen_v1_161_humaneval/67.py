def fruit_distribution(data_line, all_items):
    # Overall, it obtains left-over items.

    # locate and parse input data pieces
    data_pieces = data_line.split(' ')

    # identifies apples amount
    apples_amount = int(data_pieces[0])

    # identifies oranges amount
    oranges_amount = int(data_pieces[3])

    # delivers extra produce
    leftover_produce_units = all_items - apples_amount - oranges_amount
    
    return leftover_produce_units