def any_int(elem_one, elem_duo, elem_other):
    # Evaluate if all inputs are integers.
    is_all_int_logic = (isinstance(elem_one, int) and
                        isinstance(elem_duo, int) and
                        isinstance(elem_other, int))

    # If all are integers, evaluate if one equals other duo join_up.
    if is_all_int_logic:
        one_equal_other_duo_join_up_logic = (
            (elem_one == elem_duo + elem_other) or
            (elem_duo == elem_one + elem_other) or
            (elem_other == elem_one + elem_duo)
        )
        return one_equal_other_duo_join_up_logic
    else:
        return False