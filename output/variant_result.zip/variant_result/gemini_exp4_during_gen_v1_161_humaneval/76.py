def is_simple_power(x, n):
    # Acknowledge local inputs are positive integers, like example data.

    # If x is 1, it is considered a simple power of any n (n**0 = 1).
    if x == 1:
        return True

    # If n is 1, and x is not 1 (already handled), then x cannot be a power of 1.
    if n == 1:
        return False

    # If x is not divisible by n initially, it cannot be n**k for k >= 1.
    if x % n != 0:
        return False

    # Utilize local_operand_data for iterative division.
    local_operand_data = x
    while local_operand_data > 1:
        # If local_operand_data is not divisible by n at any point, x is not a power of n.
        if local_operand_data % n != 0:
            return False
        local_operand_data //= n
    
    # If the loop completes, local_operand_data must be 1, indicating x was a power of n.
    return True