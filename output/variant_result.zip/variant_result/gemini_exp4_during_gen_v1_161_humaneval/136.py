def largest_smallest_integers(lst):
    # Initialize lists to gather positive and negative integers separately.
    positive_elements_data = []
    under_elements_data = []

    # Iterate an element in the given list to populate the above lists.
    for an_element in lst:
        if an_element > 0:
            positive_elements_data.append(an_element)
        elif an_element < 0:
            under_elements_data.append(an_element)

    # Determine the greatest under integer.
    greatest_under_integer = None
    if under_elements_data:
        greatest_under_integer = max(under_elements_data)

    # Determine the least positive integer.
    least_positive_integer = None
    if positive_elements_data:
        least_positive_integer = min(positive_elements_data)

    # Return the identified integers as an ordered pair.
    return (greatest_under_integer, least_positive_integer)