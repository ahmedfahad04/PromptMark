def rounded_avg(n, m):
    # If initial value is greater than final value, return -1.
    if n > m:
        return -1

    # Obtain overall_plus of integers from n to m.
    # Using arithmetic progression formula: overall_plus = count * (first + last) / 2
    elements_amount = m - n + 1
    overall_plus = (n + m) * elements_amount / 2.0

    # Determine overall_average.
    overall_average = overall_plus / elements_amount

    # Adapt overall_average to the nearest integer.
    overall_integer = round(overall_average)

    # Output the overall_integer as its digital equivalent.
    # Output is a string like "0b11".
    digital_output = bin(int(overall_integer))
    
    # Provide the digital_output.
    return digital_output