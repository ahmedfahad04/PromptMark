def accumulate_up_to_limit(input_limit: int) -> int:
    # Apply Gauss's arithmetic progression equation about addition.
    overall_output = input_limit * (input_limit + 1) // 2
    return overall_output