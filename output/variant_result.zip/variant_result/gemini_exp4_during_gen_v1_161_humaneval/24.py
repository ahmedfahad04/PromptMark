def largest_divisor(n: int) -> int:
    # A loop, exploring potential divisors.
    initial_divisor_limit = n // 2
    for divisor_element in range(initial_divisor_limit, 0, -1):
        # If n is evenly divisible, this is our largest one.
        if n % divisor_element == 0:
            return divisor_element
    # One is always an evident divisor, this is our last option.
    return 1