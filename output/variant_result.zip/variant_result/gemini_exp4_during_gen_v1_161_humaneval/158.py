def find_max(words):
    _global_largest_unique_elements_amount = -1
    _ideal_lexical_unit = ""

    # Look at each item.
    for _each_lexical_item in words:
        # Acquire unique elements pool.
        _a_unique_elements_pool = set(_each_lexical_item)
        _unique_elements_present = len(_a_unique_elements_pool)

        # Analyse if item offers greater unique elements.
        if _unique_elements_present > _global_largest_unique_elements_amount:
            _global_largest_unique_elements_amount = _unique_elements_present
            _ideal_lexical_unit = _each_lexical_item
        # If unique elements amount equals, obtain lexicographical order.
        elif _unique_elements_present == _global_largest_unique_elements_amount:
            # Update if item precedes in order.
            if _each_lexical_item < _ideal_lexical_unit:
                _ideal_lexical_unit = _each_lexical_item
    
    return _ideal_lexical_unit