def calc_combos_of_3(count_val):
    # Calculates nC3, or "count_val choose 3"
    if count_val < 3:
        return 0
    val = count_val * (count_val - 1) * (count_val - 2) // 6
    return val

def get_max_triples(n):
    # Assign initial counts for i % 3
    i_mod_0_amount = n // 3
    i_mod_1_amount = n // 3
    i_mod_2_amount = n // 3

    # Adjust counts based on n % 3
    n_modulo_val = n % 3
    if n_modulo_val == 1:
        i_mod_1_amount += 1
    elif n_modulo_val == 2:
        i_mod_1_amount += 1
        i_mod_2_amount += 1

    # Map counts of i % 3 to counts of a[j] % 3
    # a[j] % 3 == 0 when j % 3 == 2
    a_mod_0_amount = i_mod_2_amount
    # a[j] % 3 == 1 when j % 3 == 0 or j % 3 == 1
    a_mod_1_amount = i_mod_0_amount + i_mod_1_amount

    # Valid sums are (0,0,0) mod 3 or (1,1,1) mod 3
    overall_count = 0
    overall_count += calc_combos_of_3(a_mod_0_amount)
    overall_count += calc_combos_of_3(a_mod_1_amount)
    
    return overall_count