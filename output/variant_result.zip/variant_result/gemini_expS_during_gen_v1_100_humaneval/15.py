def string_sequence(n: int) -> str:
    num_strings = [str(val) for val in range(n + 1)]
    output = ' '.join(num_strings)
    return output