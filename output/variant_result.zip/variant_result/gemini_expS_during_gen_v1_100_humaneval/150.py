import math

def x_or_y(n, x, y):
    def is_n_a_prime(num_val):
        """Checks if a number is prime."""
        if num_val <= 1:
            return False
        if num_val == 2:
            return True
        if num_val % 2 == 0:
            return False
        # Only check odd divisors up to the square root of num_val
        max_divisor_val = int(math.isqrt(num_val))
        for current_div_val in range(3, max_divisor_val + 1, 2):
            if num_val % current_div_val == 0:
                return False
        return True

    if is_n_a_prime(n):
        return x
    else:
        return y