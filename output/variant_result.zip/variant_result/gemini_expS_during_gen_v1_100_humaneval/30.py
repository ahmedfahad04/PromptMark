def get_positive(l: list):
    ans = []
    for num in l:
        if num > 0:
            ans.append(num)
    return ans