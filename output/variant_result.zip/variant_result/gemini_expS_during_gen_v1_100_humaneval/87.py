def get_row(lst, x):
    # co_indices will store the coordinates (row, column) where the integer x is found.
    co_indices = []

    # Iterate through each row of the input list along with its index.
    for curr_row_idx, a_row in enumerate(lst):
        # Iterate through each item in the current row along with its column index.
        for curr_col_idx, an_item in enumerate(a_row):
            # If the current item matches the target integer x, add its coordinate.
            if an_item == x:
                co_indices.append((curr_row_idx, curr_col_idx))

    # Sort the collected coordinates based on two criteria:
    # 1. Primary sort: by row index in ascending order.
    # 2. Secondary sort: by column index in descending order.
    # To achieve descending order for columns using an ascending sort function,
    # we negate the column index in the sorting key.
    co_indices.sort(key=lambda coord_pair: (coord_pair[0], -coord_pair[1]))

    return co_indices