def valid_date(date):
    # Rule 1: The date string is not empty.
    if not date:
        return False

    # Rule 4: The date should be in the format: mm-dd-yyyy.
    # Check for correct number of separators.
    if date.count('-') != 2:
        return False

    units = date.split('-')
    # After splitting, there must be exactly three components.
    if len(units) != 3:
        return False

    month_str, day_str, year_str = units

    # Validate the length of each component.
    if not (len(month_str) == 2 and len(day_str) == 2 and len(year_str) == 4):
        return False

    # Convert components to integers. Handle non-numeric values.
    try:
        month_val = int(month_str)
        day_val = int(day_str)
        # year_val is not used in further date logic, but conversion validates it's a number.
        year_val = int(year_str) 
    except ValueError:
        return False

    # Rule 3: The months should not be less than 1 or higher than 12.
    if not (1 <= month_val <= 12):
        return False

    # Rule 2: Day validation based on the month.
    # Define sets for months with 31 and 30 days.
    months_with_31_days = {1, 3, 5, 7, 8, 10, 12}
    months_with_30_days = {4, 6, 9, 11}

    if month_val in months_with_31_days:
        if not (1 <= day_val <= 31):
            return False
    elif month_val in months_with_30_days:
        if not (1 <= day_val <= 30):
            return False
    elif month_val == 2:  # February
        # For February, days should not be higher than 29 (simplified, no leap year check required by prompt).
        if not (1 <= day_val <= 29):
            return False
    else:
        # This case should logically not be hit due to the month_val check above,
        # but acts as a safeguard.
        return False

    # All checks passed, the date is valid.
    return True