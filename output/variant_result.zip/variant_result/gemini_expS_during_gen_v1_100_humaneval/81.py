def numerical_letter_grade(grades):
    ans_container = []
    for a_gpa in grades:
        if a_gpa == 4.0:
            ans_container.append('A+')
        elif a_gpa > 3.7:
            ans_container.append('A')
        elif a_gpa > 3.3:
            ans_container.append('A-')
        elif a_gpa > 3.0:
            ans_container.append('B+')
        elif a_gpa > 2.7:
            ans_container.append('B')
        elif a_gpa > 2.3:
            ans_container.append('B-')
        elif a_gpa > 2.0:
            ans_container.append('C+')
        elif a_gpa > 1.7:
            ans_container.append('C')
        elif a_gpa > 1.3:
            ans_container.append('C-')
        elif a_gpa > 1.0:
            ans_container.append('D+')
        elif a_gpa > 0.7:
            ans_container.append('D')
        elif a_gpa > 0.0:
            ans_container.append('D-')
        else:  # Must be 0.0 based on prior checks
            ans_container.append('E')
    return ans_container