def encode_shift(s: str):
    return "".join([chr(((ord(ch) + 5 - ord("a")) % 26) + ord("a")) for ch in s])


def decode_shift(s: str):
    # Decode by shifting each character back by 5 positions, wrapping around the alphabet
    return "".join([chr(((ord(ch_unit) - 5 - ord("a")) % 26) + ord("a")) for ch_unit in s])