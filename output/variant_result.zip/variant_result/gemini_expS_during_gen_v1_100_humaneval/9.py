from typing import List, Tuple


def rolling_max(numbers: List[int]) -> List[int]:
    max_values: List[int] = []
    current_max: float = float('-inf') # Initialize with negative infinity to handle any integer

    if not numbers:
        return max_values

    for num_val in numbers:
        current_max = max(current_max, num_val)
        max_values.append(int(current_max)) # Append the current maximum to our output list
    
    return max_values