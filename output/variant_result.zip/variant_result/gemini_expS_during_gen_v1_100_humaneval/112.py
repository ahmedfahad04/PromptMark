def reverse_delete(s, c):
    my_chars = []
    # Convert 'c' to a set for faster character lookup
    c_units = set(c)

    # Iterate over each character in the input string 's'
    for my_char in s:
        # If the character is not in the set of characters to delete, add it
        if my_char not in c_units:
            my_chars.append(my_char)

    # Join the characters to form the new string
    my_string = "".join(my_chars)

    # Check if the new string is a palindrome
    # A string is a palindrome if it reads the same forwards and backwards
    is_palindrome_yay = (my_string == my_string[::-1])

    return (my_string, is_palindrome_yay)