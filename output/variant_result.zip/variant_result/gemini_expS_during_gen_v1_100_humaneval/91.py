import re as py_re

def is_bored(S):
    a_count = 0  # Initialize count for boredoms

    # Split the input string into potential sentences using delimiters '.', '?' or '!'
    # py_re.split will often include empty strings which are handled below
    input_units = py_re.split(r'[.?!]', S)

    # Iterate over each potential clause
    for a_clause in input_units:
        # Clean up the clause by removing leading/trailing whitespace
        clean_clause = a_clause.strip()

        # Check if the cleaned clause is not empty
        if clean_clause:
            # Split the clause into words to check the very first word
            unit_words = clean_clause.split()

            # If there are words in the clause and the first word is 'I' (case-sensitive)
            if unit_words and unit_words[0] == "I":
                a_count += 1

    return a_count