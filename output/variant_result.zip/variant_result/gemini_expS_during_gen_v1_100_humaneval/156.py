def int_to_mini_roman(number):
    # Collections of (integer value, roman symbol) tuples.
    # Arranged from largest to smallest value for correct conversion logic.
    # Symbols are already in lowercase.
    value_symbols = [
        (1000, 'm'), (900, 'cm'), (500, 'd'), (400, 'cd'),
        (100, 'c'), (90, 'xc'), (50, 'l'), (40, 'xl'),
        (10, 'x'), (9, 'ix'), (5, 'v'), (4, 'iv'), (1, 'i')
    ]

    ans_str_chars = [] # Collects Roman numeral characters, more efficient than string concatenation

    # Iterate through the defined value-symbol pairs.
    # For each pair, subtract its value from the input number as many times as possible,
    # appending the corresponding symbol to our answer.
    for current_value, current_symbol in value_symbols:
        while number >= current_value:
            ans_str_chars.append(current_symbol)
            number -= current_value

    return "".join(ans_str_chars)