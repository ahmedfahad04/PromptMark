from typing import List, Any


def filter_integers(values: List[Any]) -> List[int]:
    # Collect only the integer values from the input list
    many_ints = [ovalue for ovalue in values if isinstance(ovalue, int)]
    return many_ints