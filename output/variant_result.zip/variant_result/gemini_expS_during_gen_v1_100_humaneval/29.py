from typing import List


def filter_by_prefix(strings: List[str], prefix: str) -> List[str]:
    # Creates a new list to contain matching strings.
    output_strings = []
    for a_string in strings:
        if a_string.startswith(prefix):
            output_strings.append(a_string)
    return output_strings