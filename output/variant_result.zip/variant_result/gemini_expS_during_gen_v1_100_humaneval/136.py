def largest_smallest_integers(input_list):
    max_neg_val = None
    min_pos_val = None

    for an_item in input_list:
        if an_item < 0:
            if max_neg_val is None or an_item > max_neg_val:
                max_neg_val = an_item
        elif an_item > 0:
            if min_pos_val is None or an_item < min_pos_val:
                min_pos_val = an_item
    
    return (max_neg_val, min_pos_val)