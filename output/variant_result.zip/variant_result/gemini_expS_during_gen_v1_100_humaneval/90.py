def next_smallest(lst):
    # Handle cases where the input list is empty or has only one item.
    # There cannot be a second smallest element in these scenarios.
    if not lst or len(lst) < 2:
        return None

    # Obtain unique values from the input list to handle duplicates.
    # Convert to a set first to automatically remove duplicates, then back to a list.
    unique_vals = list(set(lst))

    # After removing duplicates, if there are fewer than two unique items,
    # it means a second smallest element does not exist (e.g., [1, 1] becomes [1]).
    if len(unique_vals) < 2:
        return None

    # Sort the unique values in ascending order.
    # The smallest item will be at index 0, and the second smallest at index 1.
    unique_vals.sort()

    # Return the item at index 1, which is the second smallest unique value.
    return unique_vals[1]