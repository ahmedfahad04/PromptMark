def unique_digits(x):
    unique_nums = []  # Store numbers with only odd digits

    for a_num in x:
        is_clean_num = True  # Assume current number has only odd digits
        val_str = str(a_num) # Convert number to string to check digits

        for a_digit_char in val_str:
            val_digit = int(a_digit_char)
            if val_digit % 2 == 0:
                is_clean_num = False  # Found an even digit, this number is not valid
                break  # No need to check other digits for this number
        
        if is_clean_num:
            unique_nums.append(a_num)
    
    unique_nums.sort()  # Sort the collected numbers in increasing order
    return unique_nums