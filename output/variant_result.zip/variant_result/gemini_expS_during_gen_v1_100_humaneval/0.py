from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    num_count = len(numbers)
    # Iterate through all unique pairs of numbers
    for i in range(num_count):
        for j in range(i + 1, num_count):
            num_one = numbers[i]
            num_two = numbers[j]
            val_away = abs(num_one - num_two)
            if val_away < threshold:
                return True
    return False