def select_words(s, n):
    if not s:
        return []

    # Define the set of vowels for quick lookup
    vowels_unit = {'a', 'e', 'i', 'o', 'u'}
    
    outcome_values = [] # This collection will hold the words that match the criteria

    # Split the input string into individual words
    words_units = s.split()

    for word_unit in words_units:
        consonant_count = 0
        for char_unit in word_unit:
            # Convert the character to lowercase for case-insensitive checking
            lower_char = char_unit.lower()
            
            # Check if the character is an alphabet and not a vowel
            if 'a' <= lower_char <= 'z' and lower_char not in vowels_unit:
                consonant_count += 1
        
        # If the number of consonants in the word matches n, add it to the outcome
        if consonant_count == n:
            outcome_values.append(word_unit)
            
    return outcome_values