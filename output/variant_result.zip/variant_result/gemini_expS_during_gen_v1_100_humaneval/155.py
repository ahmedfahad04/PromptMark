def even_odd_count(num):
    even_count = 0
    odd_count = 0

    # Convert the number to its absolute string to process digits
    # The sign of the number does not impact digit parity
    abs_num_str = str(abs(num))

    for char_digit in abs_num_str:
        # Convert the character digit back to an integer
        int_digit = int(char_digit)
        if int_digit % 2 == 0:
            even_count += 1
        else:
            odd_count += 1

    return (even_count, odd_count)