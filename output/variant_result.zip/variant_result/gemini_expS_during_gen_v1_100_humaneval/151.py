def double_the_difference(in_list):
    accum_amount = 0
    if not in_list:
        return 0

    for current_val in in_list:
        # Check if the current item is an integer and positive.
        # `isinstance(current_val, int)` checks for integer type.
        # `current_val > 0` checks for positivity.
        if isinstance(current_val, int) and current_val > 0:
            # Check if the positive integer is odd.
            # `current_val % 2 != 0` identifies odd numbers.
            if current_val % 2 != 0:
                accum_amount += current_val * current_val
    return accum_amount