def encode_cyclic(s: str):
    # split string to groups. Each of length 3.
    groups = [s[(3 * i):min((3 * i + 3), len(s))] for i in range((len(s) + 2) // 3)]
    # cycle elements in each group. Unless group has fewer elements than 3.
    groups = [(group[1:] + group[0]) if len(group) == 3 else group for group in groups]
    return "".join(groups)


def decode_cyclic(s: str):
    # Split string into groups of three, similar to the encoding process.
    # The calculation for range ensures all characters are included, even if they form a partial group.
    groups = [s[(3 * i):min((3 * i + 3), len(s))] for i in range((len(s) + 2) // 3)]

    # Initialize a list to store the decoded chunks of characters.
    my_chunks = []
    
    # Iterate through each chunk to reverse the cyclic shift if it occurred.
    for a_chunk in groups:
        if len(a_chunk) == 3:
            # For a 3-character group 'bca' (encoded from 'abc'), the decoding is 'abc'.
            # This is achieved by moving the last character ('a') to the front of the remaining part ('bc').
            my_chunks.append(a_chunk[-1] + a_chunk[:-1])
        else:
            # If the chunk has fewer than 3 characters, it was not cycled during encoding,
            # so it remains unchanged in the decoding process.
            my_chunks.append(a_chunk)
            
    # Join all the decoded chunks back into a single string.
    return "".join(my_chunks)