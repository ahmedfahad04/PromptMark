def compare_one(a, b):
    # Private helper to obtain a comparable numeric value from various input types.
    # It handles integers, floats, and strings representing numbers (with ',' or '.' as decimal).
    def _obtain_numeric_val(an_input_val):
        if isinstance(an_input_val, (int, float)):
            return float(an_input_val)
        elif isinstance(an_input_val, str):
            # Replace comma with dot for consistent float conversion.
            a_mod_string = an_input_val.replace(',', '.')
            return float(a_mod_string)
        # The problem statement implies valid inputs are int, float, or numeric strings.
        # For any other unexpected type, float() conversion would naturally raise an error.

    num_a = _obtain_numeric_val(a)
    num_b = _obtain_numeric_val(b)

    if num_a > num_b:
        return a
    elif num_b > num_a:
        return b
    else:  # Values are numerically equal
        return None