def f(n):
    ans_values = []

    for i in range(1, n + 1):
        if i % 2 == 0:  # Calculate factorial for even 'i'
            calc_value = 1
            for curr_num in range(1, i + 1):
                calc_value *= curr_num
            ans_values.append(calc_value)
        else:  # Calculate sum of numbers for odd 'i'
            calc_value = 0
            for curr_num in range(1, i + 1):
                calc_value += curr_num
            ans_values.append(calc_value)

    return ans_values