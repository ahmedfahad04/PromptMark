def compare(game, guess):
    outcome_vals = []
    # Iterate through the matches, comparing game scores and guesses
    for idx in range(len(game)):
        game_score = game[idx]
        guess_val = guess[idx]

        if game_score == guess_val:
            outcome_vals.append(0)
        else:
            # Calculate absolute difference if guess is incorrect
            actual_diff = abs(game_score - guess_val)
            outcome_vals.append(actual_diff)
            
    return outcome_vals