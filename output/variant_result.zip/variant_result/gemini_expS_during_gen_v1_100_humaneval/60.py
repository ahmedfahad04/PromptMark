def sum_to_n(n: int):
    # Use the arithmetic series sum formula for efficiency
    # The sum of integers from 1 to n is n * (n + 1) / 2
    return n * (n + 1) // 2