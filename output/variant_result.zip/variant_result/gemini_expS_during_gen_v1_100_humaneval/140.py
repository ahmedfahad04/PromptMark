import re

def fix_spaces(input_copy):
    # Change sequences of three or more spaces into a single hyphen.
    # This action must precede replacing individual spaces to correctly handle long sequences.
    working_copy = re.sub(r' {3,}', '-', input_copy)
    
    # Next, change all remaining individual spaces (which would include original single spaces
    # and original double spaces) into underscores.
    answer = re.sub(r' ', '_', working_copy)

    return answer