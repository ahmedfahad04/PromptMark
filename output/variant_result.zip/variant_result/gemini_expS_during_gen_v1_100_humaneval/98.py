def count_upper(s: str) -> int:
    many_vowels = {'A', 'E', 'I', 'O', 'U'}
    amount = 0

    for idx, char in enumerate(s):
        # Check if the current index is even and the character is an uppercase vowel
        if idx % 2 == 0 and char in many_vowels:
            amount += 1
            
    return amount