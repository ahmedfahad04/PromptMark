import math

def rounded_avg(n, m):
    if n > m:
        return -1

    # Calculate the sum of integers from n to m
    # The sum of an arithmetic series is (count / 2) * (first_num + last_num)
    # count_num = m - n + 1
    # sum_val = (count_num * (n + m)) / 2
    # The average is sum_val / count_num, which simplifies to (n + m) / 2
    avg_val = (n + m) / 2

    # Round the average to the nearest integer
    # Using round() for nearest integer rounding
    round_avg = round(avg_val)

    # Convert the rounded integer to its binary string representation
    return bin(round_avg)