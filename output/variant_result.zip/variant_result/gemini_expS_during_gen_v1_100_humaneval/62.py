def derivative(xs: list):
    output_coeffs = []
    # Iterate starting from the coefficient of x^1, as the constant term's derivative is zero.
    # The coefficient of x^k in the original polynomial becomes the coefficient of x^(k-1)
    # in the derivative, multiplied by k.
    # So, for xs[i] (coefficient of x^i), its derivative component is i * xs[i] * x^(i-1).
    # This means the new coefficient at index (i-1) in the output list will be i * xs[i].
    for i in range(1, len(xs)):
        curr_coeff = i * xs[i]
        output_coeffs.append(curr_coeff)
    return output_coeffs