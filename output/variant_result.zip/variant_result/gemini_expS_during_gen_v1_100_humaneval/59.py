def largest_prime_factor(n: int):
    main_num = n
    max_num = 1 # Stores the largest prime factor found

    # Handle factor 2
    while main_num % 2 == 0:
        max_num = 2
        main_num //= 2

    # Handle odd factors starting from 3
    num_i = 3
    while num_i * num_i <= main_num:
        while main_num % num_i == 0:
            max_num = num_i
            main_num //= num_i
        num_i += 2 # Move to next odd number

    # If main_num is still greater than 1, it is the largest prime factor
    if main_num > 1:
        max_num = main_num

    return max_num