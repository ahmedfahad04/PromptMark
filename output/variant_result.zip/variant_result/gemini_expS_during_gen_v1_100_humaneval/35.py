def max_element(l: list):
    if not l:
        raise ValueError("Cannot obtain maximum from an empty collection.")

    current_max_val = l[0]
    for an_item in l[1:]:
        if an_item > current_max_val:
            current_max_val = an_item

    return current_max_val