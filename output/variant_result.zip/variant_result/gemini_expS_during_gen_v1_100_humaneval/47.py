def median(vals: list):
    count = len(vals)

    if count == 0:
        return None

    # Obtain a sorted copy of the input values.
    sorted_vals = sorted(vals)

    if count % 2 == 1:
        # For an odd number of values, the median is the middle element.
        mid_index = count // 2
        return sorted_vals[mid_index]
    else:
        # For an even number of values, the median is the average of the two middle elements.
        mid_index_one = count // 2 - 1
        mid_index_two = count // 2
        val_sum = sorted_vals[mid_index_one] + sorted_vals[mid_index_two]
        return val_sum / 2.0