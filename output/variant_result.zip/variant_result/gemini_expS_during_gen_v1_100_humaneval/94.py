import math

# Checks if a number is prime.
def is_a_prime(num_in):
    if num_in <= 1:
        return False
    if num_in == 2:
        return True
    if num_in % 2 == 0:
        return False
    
    # Iterate with odd divisors only.
    check_num = 3
    # Optimizes by checking divisors up to the square root of num_in.
    while check_num * check_num <= num_in:
        if num_in % check_num == 0:
            return False
        check_num += 2
    return True

# Calculates the sum of digits of a number.
def add_digits(num_in):
    sum_val = 0
    # Process positive number for digit summing.
    # num_in is guaranteed to be positive if it comes from a_current_max_num_val.
    while num_in > 0:
        sum_val += num_in % 10
        num_in //= 10
    return sum_val

def skjkasdkd(a_many_nums):
    a_current_max_num_val = 0 # Stores the largest prime number found.

    for a_num in a_many_nums:
        if is_a_prime(a_num):
            if a_num > a_current_max_num_val:
                a_current_max_num_val = a_num

    # If a prime was found (a_current_max_num_val will be greater than 0),
    # return the sum of its digits. Otherwise, return 0.
    return add_digits(a_current_max_num_val)