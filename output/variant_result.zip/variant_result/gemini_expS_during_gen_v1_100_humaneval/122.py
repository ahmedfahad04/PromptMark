def add_elements(arr, k):
    a_sum = 0
    # Iterate through the first k elements of the array
    for idx in range(k):
        num = arr[idx]
        # Check if the number has at most two digits (absolute value less than 100)
        if abs(num) < 100:
            a_sum += num
    return a_sum