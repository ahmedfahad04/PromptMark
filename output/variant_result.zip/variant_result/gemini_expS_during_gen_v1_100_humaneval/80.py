def is_happy(s):
    # Check if the string's character count is at least 3
    if len(s) < 3:
        return False

    # Iterate through the string, checking groups of 3 consecutive characters
    # The loop goes up to len(s) - 2 (exclusive) to ensure there are always 3 characters available
    for idx in range(len(s) - 2):
        # Obtain the three characters in the current window
        char_one = s[idx]
        char_two = s[idx + 1]
        char_uny = s[idx + 2]

        # Verify if these three characters are all distinct
        if char_one == char_two or char_one == char_uny or char_two == char_uny:
            return False # If any are identical, the string is not happy

    # If all windows passed the distinct character check
    return True