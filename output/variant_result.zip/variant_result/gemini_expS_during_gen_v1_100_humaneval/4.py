from typing import List


def mean_absolute_deviation(numbers: List[float]) -> float:
    if not numbers:
        return 0.0

    # Calculate the mean of the numbers
    sum_vals = sum(numbers)
    num_count = len(numbers)
    mean_val = sum_vals / num_count

    # Calculate the sum of absolute differences from the mean
    abs_diffs_sum = 0.0
    for val in numbers:
        abs_diffs_sum += abs(val - mean_val)

    # Calculate the Mean Absolute Deviation
    mad_val = abs_diffs_sum / num_count
    return mad_val