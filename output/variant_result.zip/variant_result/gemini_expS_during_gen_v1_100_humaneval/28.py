from typing import List


def concatenate(strings: List[str]) -> str:
    # Concatenates all strings in the input list into one.
    return "".join(strings)