def file_name_check(file_name):
    amount_digits = 0
    for char in file_name:
        if char.isdigit():
            amount_digits += 1
    if amount_digits > 3:
        return 'No'

    amount_dots = file_name.count('.')
    if amount_dots != 1:
        return 'No'

    # Split the name into two main parts around the dot
    parts = file_name.split('.')
    main_chunk = parts[0]
    app_extension = parts[1]

    if not main_chunk: # Check if the part before the dot is empty
        return 'No'

    if not main_chunk[0].isalpha(): # Check if it starts with a letter
        return 'No'

    valid_extensions = ['txt', 'exe', 'dll']
    if app_extension not in valid_extensions:
        return 'No'

    return 'Yes'