def triangle_area(a, h):
    amount = 0.5 * a * h
    return amount