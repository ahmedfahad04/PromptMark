def modp(n: int, p: int):
    # Initialize the value that accumulates the result
    ans = 1
    # Initialize the base for exponentiation, which is 2
    curr_base = 2

    # Perform modular exponentiation using the binary method
    while n > 0:
        # If n is odd, multiply ans by the current base modulo p
        if n % 2 == 1:
            ans = (ans * curr_base) % p
        # Square the current base modulo p for the next iteration
        curr_base = (curr_base * curr_base) % p
        # Halve n for the next iteration
        n //= 2
    return ans