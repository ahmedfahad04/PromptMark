def is_simple_power(x, n):
    # If x is 1, it's always a simple power of any n (n**0 = 1).
    # This covers cases like is_simple_power(1, 4) => true.
    if x == 1:
        return True

    # If n is 1 and x is not 1 (handled above), then x cannot be a power of 1,
    # because 1 raised to any integer power is 1.
    # This covers cases like is_simple_power(3, 1) => false.
    if n == 1:
        return False

    # If n is 0 and x is not 1, x cannot be a power of 0.
    # (0 raised to any positive power is 0, not x).
    if n == 0:
        return False

    # For x > 1 and n > 1:
    # Repeatedly divide x by n. If at any point x is not divisible by n,
    # then it's not a simple power.
    # If x eventually becomes 1, it means it was a simple power of n.
    current_val = x
    while current_val > 1:
        if current_val % n != 0:
            return False  # Not perfectly divisible, so not a power
        current_val //= n # Update current_val using integer division

    # If the loop finishes, it means current_val has been successfully
    # divided by n until it reached 1.
    return current_val == 1