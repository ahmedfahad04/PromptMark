def by_length(arr):
    num_names_map = {
        1: "One",
        2: "Two",
        3: "Three",
        4: "Four",
        5: "Five",
        6: "Six",
        7: "Seven",
        8: "Eight",
        9: "Nine"
    }

    # Collect numbers within the valid range (1-9 inclusive)
    ok_nums = []
    for num_val in arr:
        if 1 <= num_val <= 9:
            ok_nums.append(num_val)

    # If no valid numbers are found, an empty list is returned
    if not ok_nums:
        return []

    # Sort the collected numbers
    ok_nums.sort()

    # Reverse the sorted numbers
    ok_nums.reverse()

    # Map numbers to their corresponding word names
    num_words = []
    for num_val in ok_nums:
        num_words.append(num_names_map[num_val])

    return num_words