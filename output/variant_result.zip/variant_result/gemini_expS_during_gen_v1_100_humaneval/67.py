def fruit_distribution(s, n):
    apple_keyword = "apples and"
    orange_keyword = "oranges"

    # Find the numeric value for apples
    apple_pos = s.find(apple_keyword)
    apple_count_val = s[:apple_pos].strip()
    num_apples = int(apple_count_val)

    # Extract the part of the string containing oranges count
    orange_comp = s[apple_pos + len(apple_keyword):].strip()

    # Find the numeric value for oranges
    orange_pos = orange_comp.find(orange_keyword)
    orange_count_val = orange_comp[:orange_pos].strip()
    num_oranges = int(orange_count_val)

    # Calculate the number of mangoes
    mango_count = n - num_apples - num_oranges
    
    return mango_count