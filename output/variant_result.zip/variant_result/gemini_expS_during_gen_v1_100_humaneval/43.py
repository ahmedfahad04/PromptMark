def pairs_sum_to_zero(nums):
    # Initialize a set to store numbers encountered so far.
    known_nums = set()

    for a_num in nums:
        # Calculate the number that would sum to zero with a_num.
        inv_num = -a_num

        # If we have seen the inverse number before, then we found a pair.
        # This implicitly handles distinct elements because a_num is added to known_nums
        # *after* checking for its inverse.
        if inv_num in known_nums:
            return True
        
        # Add the current number to the set of known values.
        known_nums.add(a_num)
            
    # If no such pair was found after checking all numbers, return False.
    return False