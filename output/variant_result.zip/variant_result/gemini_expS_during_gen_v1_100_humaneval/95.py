def check_dict_case(input_map):
    if not input_map:
        return False

    all_are_lower = True
    all_are_upper = True

    for a_key in input_map.keys():
        if not isinstance(a_key, str):
            return False
        
        # Check if the current key is not all lowercase
        if not a_key.islower():
            all_are_lower = False
        
        # Check if the current key is not all uppercase
        if not a_key.isupper():
            all_are_upper = False
            
    # Return True if all keys were either all lowercase or all uppercase
    return all_are_lower or all_are_upper