import hashlib

def string_to_md5(text):
    if not text:
        return None

    # MD5 hashing operates on bytes, so encode the string
    input_bytes = text.encode('utf-8')

    # Create an MD5 hash object
    md5_obj = hashlib.md5()

    # Update the hash object with the input bytes
    md5_obj.update(input_bytes)

    # Return the hexadecimal representation of the hash
    md5_sum = md5_obj.hexdigest()
    return md5_sum