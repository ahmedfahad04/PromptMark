def correct_bracketing(brackets: str):
    open_count = 0
    for char_val in brackets:
        if char_val == '<':
            open_count += 1
        elif char_val == '>':
            open_count -= 1
        # If closing bracket appears without an open one
        if open_count < 0:
            return False
    
    # All brackets must be matched at the end
    return open_count == 0