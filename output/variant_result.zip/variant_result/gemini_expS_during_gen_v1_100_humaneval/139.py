def special_factorial(n):
    # Internal helper to calculate standard factorial for a given number
    def calc_factorial(num_val):
        accum_val = 1
        for i in range(1, num_val + 1):
            accum_val *= i
        return accum_val

    multi_val = 1
    # Iterate from n down to 1, calculating and multiplying factorials
    for i in range(n, 0, -1):
        multi_val *= calc_factorial(i)
    
    return multi_val