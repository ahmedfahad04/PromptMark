import math

def _is_num_prime(a_num):
    # Check if a number is prime
    if a_num < 2:
        return False
    if a_num == 2:
        return True
    if a_num % 2 == 0:
        return False
    # Check divisibility only up to the square root of a_num
    # and only for odd divisors
    max_divisor = int(math.sqrt(a_num))
    current_divisor = 3
    while current_divisor <= max_divisor:
        if a_num % current_divisor == 0:
            return False
        current_divisor += 2
    return True

def count_up_to(n_input):
    output_nums = []
    if n_input <= 2:
        return output_nums

    # Iterate from 2 up to n_input - 1 to find primes
    current_num = 2
    while current_num < n_input:
        if _is_num_prime(current_num):
            output_nums.append(current_num)
        current_num += 1
    return output_nums