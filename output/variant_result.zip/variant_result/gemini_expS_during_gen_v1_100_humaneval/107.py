def even_odd_palindrome(n_input):
    even_count = 0
    odd_count = 0

    # Helper to check if a number is a palindrome
    def check_is_palindrome(num_val):
        num_as_str = str(num_val)
        return num_as_str == num_as_str[::-1]

    current_num = 1
    while current_num <= n_input:
        if check_is_palindrome(current_num):
            if current_num % 2 == 0:
                even_count += 1
            else:
                odd_count += 1
        current_num += 1

    return (even_count, odd_count)