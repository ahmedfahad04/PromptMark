def exchange(lst1, lst2):
    num_odds_one = 0
    for an_item in lst1:
        if an_item % 2 != 0:
            num_odds_one += 1

    num_evens_two = 0
    for an_item in lst2:
        if an_item % 2 == 0:
            num_evens_two += 1

    if num_odds_one <= num_evens_two:
        return "YES"
    else:
        return "NO"