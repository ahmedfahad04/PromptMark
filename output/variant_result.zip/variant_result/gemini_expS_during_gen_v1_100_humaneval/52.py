def below_threshold(input_vals: list, max_check_val: int):
    for num_curr in input_vals:
        # If any number is not strictly below the threshold, return False
        if num_curr >= max_check_val:
            return False
    # If the loop completes, all numbers were below the threshold
    return True