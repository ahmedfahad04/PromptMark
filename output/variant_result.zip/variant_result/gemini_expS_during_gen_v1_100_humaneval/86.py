def anti_shuffle(s):
    output_units = []  # Accumulates processed words and original spaces
    current_word_chars = []  # Collects characters for the current word

    for char_val in s:
        if char_val == ' ':
            # If current_word_chars holds a word, sort it and add to output
            if current_word_chars:
                sorted_chars = sorted(current_word_chars)
                output_units.append(''.join(sorted_chars))
                current_word_chars = []  # Reset for the next word
            # Add the space character itself to output
            output_units.append(' ')
        else:
            # If not a space, add the character to the current word collection
            current_word_chars.append(char_val)

    # After the loop, check if there's any remaining word at the end of the string
    if current_word_chars:
        sorted_chars = sorted(current_word_chars)
        output_units.append(''.join(sorted_chars))

    return ''.join(output_units)