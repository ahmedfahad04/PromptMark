def digits(n_input):
    odd_units_product = 1
    found_any_odd = False

    # Iterate through the digits of the input number
    while n_input > 0:
        current_unit = n_input % 10  # Get the last digit

        # Check if the current digit is odd
        if current_unit % 2 != 0:
            odd_units_product *= current_unit
            found_any_odd = True

        n_input //= 10  # Move to the next digit (remove the last one)

    # If no odd digits were found, return 0; otherwise, return the product
    if not found_any_odd:
        return 0
    return odd_units_product