def fibfib(n: int):
    if n == 0:
        return 0
    if n == 1:
        return 0
    if n == 2:
        return 1

    # Create an array to store computed FibFib values
    nums_array = [0] * (n + 1)
    nums_array[0] = 0
    nums_array[1] = 0
    nums_array[2] = 1

    # Compute FibFib values iteratively
    for idx in range(3, n + 1):
        nums_array[idx] = nums_array[idx - 1] + nums_array[idx - 2] + nums_array[idx - 3]

    return nums_array[n]