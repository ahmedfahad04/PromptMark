def Strongest_Extension(class_name, extensions):
    max_strength_value = float('-inf')
    strongest_extension_name = ""

    for one_extension in extensions:
        cap_count = 0
        sm_count = 0
        for char_unit in one_extension:
            if 'A' <= char_unit <= 'Z':  # Check for uppercase letters
                cap_count += 1
            elif 'a' <= char_unit <= 'z':  # Check for lowercase letters
                sm_count += 1
        
        current_strength = cap_count - sm_count

        # If current strength is higher, or if it's the first extension being processed,
        # or if it's equal to max_strength_value, but this extension came first
        # (the problem implies to keep the existing if equal, but since we iterate
        # in order, the first one with max strength naturally becomes the chosen one).
        if current_strength > max_strength_value:
            max_strength_value = current_strength
            strongest_extension_name = one_extension
        # The implicit behavior of iterating and only updating on strictly greater
        # strength correctly handles the "choose the one that comes first" rule.

    return f"{class_name}.{strongest_extension_name}"