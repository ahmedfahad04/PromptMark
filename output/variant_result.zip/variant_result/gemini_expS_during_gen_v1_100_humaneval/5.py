from typing import List


def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    # Handle the case of an empty input list
    if not numbers:
        return []

    output_array: List[int] = []
    # Iterate through the input numbers to construct the new array
    for idx, num_val in enumerate(numbers):
        output_array.append(num_val)
        # If it's not the last number, add the delimeter
        if idx < len(numbers) - 1:
            output_array.append(delimeter)

    return output_array