def closest_integer(value):
    # Convert the input string to a floating-point number
    num_val = float(value)

    # Apply rounding logic: away from zero for equidistant cases
    # For positive numbers, adding 0.5 and converting to int effectively rounds 0.5 up
    # For negative numbers, subtracting 0.5 and converting to int effectively rounds -0.5 down
    if num_val >= 0:
        ans_val = num_val + 0.5
    else:
        ans_val = num_val - 0.5
    
    # Convert the result to an integer
    return int(ans_val)