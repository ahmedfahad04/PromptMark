from typing import List


def remove_duplicates(numbers: List[int]) -> List[int]:
    val_counts = {}
    # Count occurrences of each number
    for a_val in numbers:
        val_counts[a_val] = val_counts.get(a_val, 0) + 1

    unique_vals = []
    # Add numbers that appeared only once to the output, maintaining order
    for a_val in numbers:
        if val_counts[a_val] == 1:
            unique_vals.append(a_val)

    return unique_vals