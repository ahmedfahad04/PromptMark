def digitSum(s: str) -> int:
    sum_val = 0
    for char_val in s:
        if char_val.isupper():
            sum_val += ord(char_val)
    return sum_val