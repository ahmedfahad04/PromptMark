def starts_one_ends(n):
    # For n = 1, the only 1-digit number is 1. It starts and ends with 1.
    if n == 1:
        return 1

    # For n >= 2, we use the principle of inclusion-exclusion.
    # Count of n-digit numbers starting with 1 is 10^(n-1).
    # Count of n-digit numbers ending with 1 is 9 * 10^(n-2)
    # (first digit can be 1-9, middle n-2 digits can be 0-9, last digit is 1).
    # Count of n-digit numbers starting AND ending with 1 is 10^(n-2)
    # (first digit is 1, middle n-2 digits can be 0-9, last digit is 1).
    #
    # Applying Inclusion-Exclusion:
    # (Starts with 1) + (Ends with 1) - (Starts and Ends with 1)
    # = 10^(n-1) + 9 * 10^(n-2) - 10^(n-2)
    # = 10^(n-1) + 8 * 10^(n-2)
    # = 10 * 10^(n-2) + 8 * 10^(n-2)
    # = (10 + 8) * 10^(n-2)
    # = 18 * 10^(n-2)

    # Calculate 10 raised to the power of (n-2)
    pow_val = n - 2
    amount_options_middle = 10 ** pow_val
    
    # Apply the simplified formula
    amount_total = 18 * amount_options_middle
    
    return amount_total