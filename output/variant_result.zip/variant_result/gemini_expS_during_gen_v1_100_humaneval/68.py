def pluck(arr):
    if not arr:
        return []

    # Initialize variables to keep track of the smallest even value and its index.
    # We use a very large number for initial smallest value to ensure any even number is smaller.
    min_val = float('inf')
    min_idx = -1

    # Iterate through the array using enumerate to get both index and value.
    for idx, num_val in enumerate(arr):
        # Check if the current number is even.
        if num_val % 2 == 0:
            # If we find a smaller even value, update our records.
            if num_val < min_val:
                min_val = num_val
                min_idx = idx
            # If we find an even value equal to the current min_val,
            # we do nothing, as we are looking for the smallest index among equal values,
            # and min_idx would already point to the first occurrence.

    # After checking all numbers, if min_idx is still -1, no even numbers were found.
    if min_idx == -1:
        return []
    else:
        # Otherwise, return the smallest even value and its corresponding index.
        return [min_val, min_idx]