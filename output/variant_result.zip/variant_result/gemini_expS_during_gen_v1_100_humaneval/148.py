def bf(planet1, planet2):
    all_planets = ("Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune")

    # Check if both input planet names are valid
    if planet1 not in all_planets or planet2 not in all_planets:
        return ()

    # Obtain the indices of the input planets in the ordered list
    idx1 = all_planets.index(planet1)
    idx2 = all_planets.index(planet2)

    # Determine the correct start and end indices for slicing
    # The slice should capture planets *between* the two input planets
    if idx1 < idx2:
        start_index = idx1 + 1
        end_index = idx2
    else: # If idx2 is smaller than idx1, swap their roles for slicing
        start_index = idx2 + 1
        end_index = idx1
    
    # Extract the planets located between the two input planets
    middle_planets = all_planets[start_index:end_index]
    
    return middle_planets