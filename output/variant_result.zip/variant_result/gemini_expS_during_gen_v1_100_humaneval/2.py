def truncate_number(number: float) -> float:
    # Obtain the integer component of the number
    main_chunk = int(number)
    # Calculate the decimal component by subtracting the integer part
    suffix_value = number - main_chunk
    return suffix_value