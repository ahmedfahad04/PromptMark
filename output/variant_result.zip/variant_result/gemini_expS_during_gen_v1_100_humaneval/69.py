import collections

def search(lst):
    # Store frequency of each number.
    num_counts_obj = collections.Counter(lst)

    # Initialize max_val to -1 (if no such value exists).
    max_val = -1

    # Check each unique number and its frequency.
    for a_num, num_occurrance in num_counts_obj.items():
        # Check conditions: positive number and frequency >= number's value.
        if a_num > 0 and num_occurrance >= a_num:
            # Update max_val if this number is a greater valid candidate.
            if a_num > max_val:
                max_val = a_num
    
    return max_val