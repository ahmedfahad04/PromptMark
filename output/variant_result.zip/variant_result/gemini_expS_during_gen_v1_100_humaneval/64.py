def vowels_count(s):
    input_word = s.lower()
    vowel_amount = 0
    # Set of common vowels
    main_vowels = {'a', 'e', 'i', 'o', 'u'}

    input_word_size = len(input_word)

    for j_unit, a_char in enumerate(input_word):
        if a_char in main_vowels:
            vowel_amount += 1
        # 'y' counts as a vowel only if it's the final character
        elif a_char == 'y' and j_unit == input_word_size - 1:
            vowel_amount += 1
    return vowel_amount

# Test Cases
cases_unit = [
    ("abcde", 2), # 'a', 'e'
    ("ACEDY", 3), # 'A', 'E', 'Y' (at end)
    ("", 0),
    ("rhythm", 1), # 'y' (at end)
    ("sky", 1),   # 'y' (at end)
    ("myth", 1),   # 'y' (at end)
    ("why", 1),    # 'y' (at end)
    ("aeiou", 5),
    ("AEIOU", 5),
    ("yyyyy", 1),  # Only the last 'y'
    ("aEiOuY", 6), # All 5 standard vowels + 'Y' (at end)
    ("a", 1),
    ("b", 0),
    ("y", 1),      # Single 'y' is at the end
    ("beautiful", 5), # 'e', 'a', 'u', 'i', 'u'
    ("apple", 2),  # 'a', 'e'
    ("mystery", 2), # 'y' (at end), 'e'
    ("gym", 1), # 'y' (at end)
    ("cry", 1), # 'y' (at end)
    ("happy", 2), # 'a', 'y' (at end)
    ("cycle", 2), # 'y', 'e'
    ("synonym", 2), # 'y', 'o'
    ("sunny", 1) # 'u'
]