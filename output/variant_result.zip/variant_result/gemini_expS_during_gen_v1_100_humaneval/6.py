from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    output_ans = []
    # Split the input string into individual groups of parentheses
    groups_of_parens = paren_string.split(' ')

    for one_group in groups_of_parens:
        current_max_depth = 0
        overall_max_depth = 0
        for char_item in one_group:
            if char_item == '(':
                current_max_depth += 1
                # Update overall maximum if current depth is greater
                if current_max_depth > overall_max_depth:
                    overall_max_depth = current_max_depth
            elif char_item == ')':
                current_max_depth -= 1
        output_ans.append(overall_max_depth)
    
    return output_ans