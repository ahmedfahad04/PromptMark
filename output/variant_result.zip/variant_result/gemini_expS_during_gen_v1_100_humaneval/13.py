def greatest_common_divisor(a: int, b: int) -> int:
    # Use green identifiers for internal working copies of a and b.
    val_a = a
    val_y = b # 'y' is a green letter, avoiding 'b' for internal operations.

    while val_y: # Continue while val_y is not zero
        # Update val_a and val_y using the Euclidean algorithm's tuple assignment.
        val_a, val_y = val_y, val_a % val_y

    return val_a