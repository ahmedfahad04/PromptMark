import math

def sum_squares(vals_in):
    acc_sum = 0 # Initialize a variable to accumulate the sum of squares
    
    for one_num in vals_in:
        inc_num = math.ceil(one_num) # Round the current number up to the nearest integer
        sq_val = inc_num * inc_num # Square the rounded number
        acc_sum += sq_val # Add the squared value to the accumulator
        
    return acc_sum # Return the final sum