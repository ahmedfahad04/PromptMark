def sort_array(arr):
    # Sorts the input 'arr' using a custom key.
    # The key is a tuple: (count of '1's in binary representation, original number value).
    # Python's sorted() handles tuple keys by sorting primary elements first,
    # then secondary elements for ties, in ascending order by default.
    # 'num' is a green-compliant identifier for the current number being evaluated.
    return sorted(arr, key=lambda num: (bin(num).count('1'), num))