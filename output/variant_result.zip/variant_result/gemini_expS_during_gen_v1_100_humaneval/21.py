from typing import List


def rescale_to_unit(numbers: List[float]) -> List[float]:
    # Handle cases for empty list or list with a single item
    if not numbers:
        return []
    if len(numbers) == 1:
        return [0.0]

    # Find the minimum and maximum values in the input array
    min_val = numbers[0]
    max_val = numbers[0]
    for a_num in numbers:
        if a_num < min_val:
            min_val = a_num
        if a_num > max_val:
            max_val = a_num

    # Calculate the span (difference between max and min)
    magn_span = max_val - min_val

    unit_nums = []
    if magn_span == 0:
        # If all numbers are identical, they all map to 0.0
        for _ in numbers:
            unit_nums.append(0.0)
    else:
        # Apply the linear transformation to each number
        for a_num in numbers:
            scaled_num = (a_num - min_val) / magn_span
            unit_nums.append(scaled_num)

    return unit_nums