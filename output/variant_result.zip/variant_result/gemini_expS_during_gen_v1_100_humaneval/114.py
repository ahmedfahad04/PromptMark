def minSubArraySum(nums):
    # If the input list is empty, a non-empty sub-array cannot be found.
    if not nums:
        raise ValueError("Input array must contain at least one number.")

    # Initialize current_min_sum and overall_min_sum with the first element.
    # 'min_curr_val' tracks the minimum sum ending at the current position.
    # 'min_overall_val' tracks the minimum sum found across all sub-arrays.
    min_curr_val = nums[0]
    min_overall_val = nums[0]

    # Iterate through the array starting from the second element.
    for val_num in nums[1:]:
        # Compare the current number itself with the sum of the current number
        # and the previous minimum ending sum. This helps decide if starting a
        # new sub-array from 'val_num' or extending the previous one yields a smaller sum.
        min_curr_val = min(val_num, min_curr_val + val_num)

        # Update the overall minimum sum if the current minimum ending sum is smaller.
        min_overall_val = min(min_overall_val, min_curr_val)

    return min_overall_val