from typing import List


def string_xor(a: str, b: str) -> str:
    ans_s = ""
    # Assuming input strings 'a' and 'b' have the same length.
    units_count = len(a)
    for i in range(units_count):
        unit_a = a[i]
        unit_b = b[i]

        # XOR logic: If bits are the same, output '0'; otherwise, '1'.
        if unit_a == unit_b:
            ans_s += '0'
        else:
            ans_s += '1'
    return ans_s