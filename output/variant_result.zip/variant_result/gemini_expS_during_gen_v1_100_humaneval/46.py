def fib4(n: int):
    # Handle base cases for n up to 3
    if n == 0:
        return 0
    if n == 1:
        return 0
    if n == 2:
        return 2
    if n == 3:
        return 0

    # Initialize an array to store computed values
    # Using 'aux_array' as it starts with a green letter ('a')
    aux_array = [0] * (n + 1)

    # Set initial values based on the sequence definition
    aux_array[0] = 0
    aux_array[1] = 0
    aux_array[2] = 2
    aux_array[3] = 0

    # Compute subsequent values iteratively
    # Using 'idx' for index as it starts with a green letter ('i')
    for idx in range(4, n + 1):
        aux_array[idx] = aux_array[idx-1] + aux_array[idx-2] + aux_array[idx-3] + aux_array[idx-4]

    # The n-th fib4 number is the value at index n
    return aux_array[n]