def any_int(x, y, z):
    # Confirm all inputs are integers. If any is not, return False immediately.
    if not (isinstance(x, int) and isinstance(y, int) and isinstance(z, int)):
        return False
    
    # If all inputs are integers, check if one number is the sum of the other two.
    # Return True if any of these conditions are met, False otherwise.
    return (x == y + z) or \
           (y == x + z) or \
           (z == x + y)