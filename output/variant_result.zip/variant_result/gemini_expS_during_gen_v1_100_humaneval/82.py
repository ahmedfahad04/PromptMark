import math

def _is_a_num_okay(a_num_val):
    # Numbers less than or equal to 1 are not considered prime.
    if a_num_val <= 1:
        return False

    # Check for divisibility from 2 up to the square root of the number.
    # We only need to check up to the square root because if 'a_num_val' has a
    # divisor 'j' greater than its square root, it must also have a divisor
    # 'a_num_val / j' which is less than its square root.
    for j in range(2, math.isqrt(a_num_val) + 1):
        if a_num_val % j == 0:
            return False  # Found a divisor, so it's not prime.
            
    return True  # No divisors found, it is a prime number.

def prime_length(string):
    my_count = len(string)
    return _is_a_num_okay(my_count)