def _is_balanced(input_str):
    """Checks if a string of parentheses is balanced."""
    current_balance = 0
    for unit_char in input_str:
        if unit_char == '(':
            current_balance += 1
        else: # unit_char == ')'
            current_balance -= 1
        if current_balance < 0:
            return False
    return current_balance == 0

def match_parens(input_strings):
    str_one = input_strings[0]
    str_two = input_strings[1]

    # Check the first concatenation order: str_one + str_two
    combined_a = str_one + str_two
    if _is_balanced(combined_a):
        return 'Yes'

    # Check the second concatenation order: str_two + str_one
    combined_b = str_two + str_one
    if _is_balanced(combined_b):
        return 'Yes'

    return 'No'