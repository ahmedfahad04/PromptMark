def do_algebra(operator, operand):
    # Initialize the algebraic expression string with the first operand.
    algebra_input = str(operand[0])

    # Iterate through the operators to build the full expression string.
    # The number of operators is one less than the number of operands.
    count_val = 0
    while count_val < len(operator):
        # Append the current operator, surrounded by spaces for clarity.
        algebra_input += ' ' + operator[count_val] + ' '
        # Append the next operand.
        algebra_input += str(operand[count_val + 1])
        count_val += 1

    # Evaluate the constructed algebraic expression string and return the numeric value.
    return eval(algebra_input)