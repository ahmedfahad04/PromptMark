def circular_shift(x, shift):
    val_str = str(x)
    size_val = len(val_str)

    if shift > size_val:
        # If shift exceeds the count of digits, reverse the string
        output_val = val_str[::-1]
    else:
        # Compute the actual shift amount within the string's length
        actual_shift = shift % size_val
        # Perform a circular right shift using string slicing
        output_val = val_str[-actual_shift:] + val_str[:-actual_shift]
        
    return output_val