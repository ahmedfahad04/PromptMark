def get_closest_vowel(word: str) -> str:
    # Use a set for efficient lookup of vowel characters.
    # The set includes both lowercase and uppercase vowels for case-sensitive matching.
    vowel_chars = {'a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U'}

    # Iterate through the word from right to left,
    # starting from the second to last character down to the second character.
    # This range (current_idx from len-2 down to 1) ensures that any
    # current_char will always have both a left and a right neighbor.
    current_idx = len(word) - 2
    while current_idx >= 1:
        current_char = word[current_idx]
        char_left = word[current_idx - 1]
        char_right = word[current_idx + 1]

        # Check if the current character is a vowel
        # AND if its immediate left and right neighbors are consonants (not vowels).
        if current_char in vowel_chars and \
           char_left not in vowel_chars and \
           char_right not in vowel_chars:
            # This is the closest vowel from the right that meets the condition.
            return current_char
        
        current_idx -= 1
            
    # If the loop finishes, it means no vowel meeting the conditions was found.
    return ""