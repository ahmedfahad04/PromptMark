import math

def max_fill(grid, capacity):
    sum_cycles = 0  # Accumulates the total number of times buckets are lowered

    for a_well in grid:
        water_units_in_well = sum(a_well)  # Calculate total water in the current well
        
        # If there's water in the well, calculate how many bucket operations are needed
        if water_units_in_well > 0:
            # Use math.ceil to account for partial fills, ensuring all water is extracted
            num_cycles_for_well = math.ceil(water_units_in_well / capacity)
            sum_cycles += int(num_cycles_for_well)
            
    return sum_cycles