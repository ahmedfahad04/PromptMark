def choose_num(x, y):
    # Iterate downwards from y to x to find the largest even number first.
    # The range function (y, x-1, -1) includes y and goes down to x.
    for val in range(y, x - 1, -1):
        # Check if the current value is even.
        if val % 2 == 0:
            return val
    # If no even number is found in the range, return -1.
    return -1