def will_it_fly(q, w):
    # Check if the object is balanced (a palindromic list)
    is_akin = (q == q[::-1])

    # Calculate the sum of its elements
    total_q_amount = sum(q)

    # Check if the sum of elements is within the maximum allowed weight
    is_ok_amount = (total_q_amount <= w)

    # The object will fly if both conditions are met
    return is_akin and is_ok_amount