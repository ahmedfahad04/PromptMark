def sort_even(l: list):
    my_output = list(l) # Create a copy of the input list

    if not my_output:
        return []

    even_vals = []
    # Collect values from even indices
    for idx in range(0, len(my_output), 2):
        even_vals.append(my_output[idx])

    even_vals.sort() # Sort the collected even values

    current_idx_in_sorted_even = 0
    # Place sorted even values back into their original even indices
    for idx in range(0, len(my_output), 2):
        my_output[idx] = even_vals[current_idx_in_sorted_even]
        current_idx_in_sorted_even += 1

    return my_output