import math

def words_in_sentence(sentence):
    def is_prime(num):
        if num < 2:
            return False
        if num == 2:
            return True
        if num % 2 == 0:  # Even numbers greater than 2 are not prime
            return False
        # Check divisibility only up to the square root of the number
        cap = int(math.sqrt(num)) + 1
        for i in range(3, cap, 2):  # Only check odd divisors
            if num % i == 0:
                return False
        return True

    words_in_original = sentence.split()
    chosen_words = []

    for word_item in words_in_original:
        word_len = len(word_item)
        if is_prime(word_len):
            chosen_words.append(word_item)

    return " ".join(chosen_words)