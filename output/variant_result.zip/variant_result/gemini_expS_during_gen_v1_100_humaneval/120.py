def maximum(arr, k):
    # If k is 0, no numbers are requested, so an empty list is returned.
    if k == 0:
        return []

    # Create a new list with all items from the input array, sorted in ascending order.
    # This allows easy selection of the largest numbers.
    my_sorted_nums = sorted(arr)

    # The last k elements in a sorted list are the maximum k numbers.
    # Slicing from index -k to the end of the list achieves this.
    chosen_values = my_sorted_nums[-k:]

    # The chosen values are already sorted in ascending order.
    return chosen_values