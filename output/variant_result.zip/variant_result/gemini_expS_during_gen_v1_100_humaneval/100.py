def make_a_pile(n):
    ans_arr = []  # Stores the count of stones for each level.
    current_num_of_stones = n

    # The first level always has 'n' stones.
    ans_arr.append(current_num_of_stones)

    # For subsequent levels, add 2 to the previous level's stone count.
    # This ensures the next number is either the next odd or next even number
    # based on whether 'n' was initially odd or even.
    for _ in range(n - 1):
        current_num_of_stones += 2
        ans_arr.append(current_num_of_stones)

    return ans_arr