def total_match(my_list_one, my_list_two):
    # Calculate the total character count for the first list
    count_one = 0
    for an_item in my_list_one:
        count_one += len(an_item)

    # Calculate the total character count for the second list
    count_two = 0
    for an_item in my_list_two:
        count_two += len(an_item)

    # Compare the counts and return the appropriate list
    if count_one <= count_two:
        return my_list_one
    else:
        return my_list_two