import math

def _is_prime(num_val):
    """Checks if a given number is prime."""
    if num_val <= 1:
        return False
    # Check for factors from 2 up to the square root of num_val
    for j in range(2, int(math.sqrt(num_val)) + 1):
        if num_val % j == 0:
            return False
    return True

def intersection(interval1, interval2):
    s_one, e_one = interval1
    s_two, e_two = interval2

    # Calculate the start and end points of the intersection
    int_s = max(s_one, s_two)
    int_e = min(e_one, e_two)

    # If the calculated intersection start is after its end, there's no overlap
    # Or, if the interval's start equals its end (e.g., (2,2)), the length will be 0
    if int_s > int_e:
        return "NO"

    # Calculate the length of the intersection
    # As per example (2,3) length is 1, so it is e - s, not e - s + 1
    int_amount = int_e - int_s

    # Check if the length of the intersection is a prime number
    if _is_prime(int_amount):
        return "YES"
    return "NO"