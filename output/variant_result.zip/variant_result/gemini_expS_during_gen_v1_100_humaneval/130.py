def tri(n):
    # Initialize a list to store the sequence values up to n.
    # The list needs n + 1 elements for indices 0 to n.
    vals = [0] * (n + 1)

    # Base case for tri(0)
    # The example output tri(3) = [1, 3, 2, 8] implies tri(0) = 1.
    if n >= 0:
        vals[0] = 1
    
    # Base case for tri(1)
    if n >= 1:
        vals[1] = 3

    # Calculate subsequent values from tri(2) up to tri(n)
    for curr_idx in range(2, n + 1):
        if curr_idx % 2 == 0:
            # If curr_idx is even: tri(n) = 1 + n / 2
            # Use integer division // to match integer output examples
            vals[curr_idx] = 1 + curr_idx // 2
        else:
            # If curr_idx is odd: tri(n) = tri(n - 1) + tri(n - 2) + tri(n + 1)
            # Since curr_idx is odd, (curr_idx + 1) is even.
            # So, tri(curr_idx + 1) can be calculated using the even rule.
            val_of_next_even_idx = 1 + (curr_idx + 1) // 2
            vals[curr_idx] = vals[curr_idx - 1] + vals[curr_idx - 2] + val_of_next_even_idx
    
    return vals