def remove_vowels(text):
    vowels = "aeiouAEIOU"
    ans_chars = []

    for a_sym in text:
        if a_sym not in vowels:
            ans_chars.append(a_sym)

    return "".join(ans_chars)