from typing import List


def below_zero(operations: List[int]) -> bool:
    account_amount = 0  # Initial balance is zero
    for val in operations:
        account_amount += val
        if account_amount < 0:
            return True  # Balance fell below zero
    return False