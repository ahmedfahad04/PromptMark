def solve(s):
    # Check if the input string contains any letters
    has_alpha = False
    for char_unit in s:
        if char_unit.isalpha():
            has_alpha = True
            break

    # If no letters are found, reverse the entire string
    if not has_alpha:
        return s[::-1]

    # If letters are present, create a new string with case inversions
    output_chars = []
    for char_unit in s:
        if char_unit.isalpha():
            # Invert case for letters
            if char_unit.islower():
                output_chars.append(char_unit.upper())
            else:  # Must be uppercase
                output_chars.append(char_unit.lower())
        else:
            # Keep non-letters as they are
            output_chars.append(char_unit)
    
    # Join the collection of characters to form the final string
    return "".join(output_chars)