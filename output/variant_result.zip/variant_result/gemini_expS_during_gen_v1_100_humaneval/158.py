def find_max(words):
    if not words:
        return ""

    # Helper function to count unique characters in a given word
    def get_unique_char_count(a_word):
        uni_char_set = set(a_word)
        return len(uni_char_set)

    max_uni_char_count = -1
    ans_word = ""

    for current_word in words:
        current_uni_count = get_unique_char_count(current_word)

        if current_uni_count > max_uni_char_count:
            max_uni_char_count = current_uni_count
            ans_word = current_word
        elif current_uni_count == max_uni_char_count:
            # Lexicographical comparison for tie-breaking
            if current_word < ans_word:
                ans_word = current_word
    
    return ans_word