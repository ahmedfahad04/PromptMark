def is_nested(input_string: str) -> bool:
    # We are looking for a valid subsequence of brackets where at least one bracket is nested.
    # The simplest form of a nested bracket subsequence is '[[ ]]'
    # This means we need to find four specific characters in the correct order:
    # an opening bracket, followed by another opening bracket,
    # followed by a closing bracket, and then followed by another closing bracket.

    first_open_idx = -1
    second_open_idx = -1
    inner_close_idx = -1
    outer_close_idx = -1

    # Find the index of the first opening bracket '['
    for i, char in enumerate(input_string):
        if char == '[':
            first_open_idx = i
            break
    # If no opening bracket is found, no nested structure is possible.
    if first_open_idx == -1:
        return False

    # Find the index of the second opening bracket '[' after the first one
    for i in range(first_open_idx + 1, len(input_string)):
        if input_string[i] == '[':
            second_open_idx = i
            break
    # If a second opening bracket isn't found, we can't form '[[...]]'.
    if second_open_idx == -1:
        return False

    # Find the index of the first closing bracket ']' after the second opening bracket
    for i in range(second_open_idx + 1, len(input_string)):
        if input_string[i] == ']':
            inner_close_idx = i
            break
    # If this closing bracket isn't found, the inner '[]' part cannot be formed.
    if inner_close_idx == -1:
        return False

    # Find the index of the second closing bracket ']' after the first closing bracket
    for i in range(inner_close_idx + 1, len(input_string)):
        if input_string[i] == ']':
            outer_close_idx = i
            break
    # If this closing bracket isn't found, the outer '[]' part cannot be formed.
    if outer_close_idx == -1:
        return False

    # If all four indices are found in the correct sequential order,
    # it means we have successfully identified a subsequence '[[ ]]'
    # which is a valid and nested bracket sequence.
    return True