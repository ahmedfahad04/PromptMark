from typing import List


def sort_numbers(numbers: str) -> str:
    num_values_map = {
        'zero': 0, 'one': 1, 'two': 2, 'three': 3, 'four': 4,
        'five': 5, 'six': 6, 'seven': 7, 'eight': 8, 'nine': 9
    }
    # Create an inverse map to convert numeric values back to words
    value_nums_map = {val: num_word for num_word, val in num_values_map.items()}

    input_word_nums = numbers.split(' ')
    nums_as_ints = [num_values_map[word] for word in input_word_nums]

    sorted_ints = sorted(nums_as_ints)

    sorted_word_nums = [value_nums_map[val] for val in sorted_ints]

    output_string = ' '.join(sorted_word_nums)
    return output_string