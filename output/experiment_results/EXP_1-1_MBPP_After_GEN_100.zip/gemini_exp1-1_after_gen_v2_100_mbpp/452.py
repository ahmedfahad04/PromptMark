def loss_amount(coin_value, sum_amount):
  if(sum_amount > coin_value):
    coin_sum = sum_amount - coin_value
    return coin_sum
  else:
    return 0