def rear_extract(input_cases):
  outcome = [a_unit[-1] for a_unit in input_cases]
  return outcome