def empty_dit(many_commons):
    any_vacuums = all(not a_common for a_common in many_commons)
    return any_vacuums