def extract_string(input_words, aim_size):
    chosen_values = [a_word for a_word in input_words if len(a_word) == aim_size]
    return chosen_values