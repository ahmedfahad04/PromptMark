def unique_product(input_values):
    unique_items = list(set(input_values))
    multi_outcome = 1
    for i in unique_items:
        multi_outcome *= i
    return multi_outcome