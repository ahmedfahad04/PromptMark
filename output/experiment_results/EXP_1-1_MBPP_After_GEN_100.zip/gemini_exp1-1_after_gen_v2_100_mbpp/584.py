import re
def find_adverbs(main_comm):
  for an_occur in re.finditer(r"\w+ly", main_comm):
    return ('%d-%d: %s' % (an_occur.start(), an_occur.end(), an_occur.group(0)))