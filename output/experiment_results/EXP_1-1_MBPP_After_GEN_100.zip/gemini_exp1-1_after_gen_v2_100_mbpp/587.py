def list_tuple(a_seq):
  # Convert the input sequence to a tuple
  an_outcome = tuple(a_seq)
  return an_outcome