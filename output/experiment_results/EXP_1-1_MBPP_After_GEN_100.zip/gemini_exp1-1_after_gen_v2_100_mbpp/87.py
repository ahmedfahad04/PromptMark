import collections as ct

def merge_dictionaries_three(a_sum, my_sum, uni_sum):
    main_sum = dict(ct.ChainMap({}, a_sum, my_sum, uni_sum))
    return main_sum