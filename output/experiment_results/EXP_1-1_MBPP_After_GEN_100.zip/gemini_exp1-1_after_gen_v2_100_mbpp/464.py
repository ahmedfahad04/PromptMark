def check_value(some_map, n):
    # Check if all values in the map are equal to n
    is_common = all(num_v == n for num_v in some_map.values())
    return is_common