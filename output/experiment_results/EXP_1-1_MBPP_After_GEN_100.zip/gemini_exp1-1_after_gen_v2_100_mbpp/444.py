def trim_tuple(test_list, K):
  ans = []
  for item in test_list:
    count = len(item)
    ans.append(tuple(list(item)[K: count - K]))
  return str(ans)