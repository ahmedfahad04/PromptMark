def min_Swaps(s_one, s_two):
    mis_matches = 0
    for i in range(len(s_one)):
        if s_one[i] != s_two[i]:
            mis_matches += 1
    if mis_matches % 2 == 0:
        return (mis_matches // 2)
    else:
        return ("Not Possible")