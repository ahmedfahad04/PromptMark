def square_Sum(val):
    return int(val * (4 * val * val - 1) / 3)