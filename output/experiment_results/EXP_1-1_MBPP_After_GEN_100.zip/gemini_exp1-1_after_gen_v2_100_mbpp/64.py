def subject_marks(input_values):
    input_values.sort(key = lambda an_item: an_item[1])
    return input_values