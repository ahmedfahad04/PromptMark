def and_tuples(many_units_v, many_units_w):
  common_mask = tuple(many_a & many_u for many_a, many_u in zip(many_units_v, many_units_w))
  return common_mask