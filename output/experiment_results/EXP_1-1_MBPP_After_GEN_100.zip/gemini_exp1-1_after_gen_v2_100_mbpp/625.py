def swap_List(input_items):
    count = len(input_items)
    an_item = input_items[0]
    input_items[0] = input_items[count - 1]
    input_items[count - 1] = an_item
    return input_items