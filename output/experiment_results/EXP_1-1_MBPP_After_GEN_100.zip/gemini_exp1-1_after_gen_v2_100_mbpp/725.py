import re
def extract_quotation(input_str):
  return (re.findall(r'"(.*?)"', input_str))