def mul_even_odd(some_values):
    one_even_num = next((num for num in some_values if num % 2 == 0), -1)
    one_odd_num = next((num for num in some_values if num % 2 != 0), -1)
    return (one_even_num * one_odd_num)