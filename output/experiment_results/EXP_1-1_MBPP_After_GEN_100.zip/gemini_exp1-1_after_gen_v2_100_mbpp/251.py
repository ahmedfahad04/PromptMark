def insert_element(units_input, value_to_add):
    # Creates a new collection by inserting 'value_to_add' before each item from 'units_input'
    output_collection = [an_item for unit_val in units_input for an_item in (value_to_add, unit_val)]
    return output_collection