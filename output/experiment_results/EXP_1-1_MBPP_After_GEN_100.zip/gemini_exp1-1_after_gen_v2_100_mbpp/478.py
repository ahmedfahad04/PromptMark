import re

def remove_lowercase(input_string):
    # Uses a regular expression to find and remove all lowercase English letters
    return re.sub('[a-z]', '', input_string)