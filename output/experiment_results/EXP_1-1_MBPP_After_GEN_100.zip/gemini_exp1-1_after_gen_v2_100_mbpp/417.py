def group_tuples(Input):
	out = {}
	for unit in Input:
		try:
			out[unit[0]].extend(unit[1:])
		except KeyError:
			out[unit[0]] = list(unit)
	return [tuple(values) for values in out.values()]