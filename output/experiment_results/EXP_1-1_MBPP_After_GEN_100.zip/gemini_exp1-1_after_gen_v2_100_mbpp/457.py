def Find_Min(a_canvas):
    return min(a_canvas, key=len)