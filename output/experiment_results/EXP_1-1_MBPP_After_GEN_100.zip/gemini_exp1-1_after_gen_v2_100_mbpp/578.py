def interleave_lists(var_one, var_two, var_sum):
    union_many = [a_sum for a_union in zip(var_one, var_two, var_sum) for a_sum in a_union]
    return union_many