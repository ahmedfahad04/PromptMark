import re
def occurance_substring(main_way, vision_aim):
 for a_unison in re.finditer(vision_aim, main_way):
    comm_way = a_unison.start()
    a_way_co = a_unison.end()
    return (main_way[comm_way:a_way_co], comm_way, a_way_co)