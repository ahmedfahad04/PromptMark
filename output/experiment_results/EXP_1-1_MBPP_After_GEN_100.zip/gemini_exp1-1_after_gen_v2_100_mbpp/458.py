def rectangle_area(val_one, val_two):
  output_val = val_one * val_two
  return output_val