def even_Power_Sum(input_val):
    # Initialize the accumulator for the sum
    sum = 0
    # Iterate from 1 up to input_val (inclusive)
    for i in range(1, input_val + 1):
        # Calculate a_unit which is twice the current iterator value
        a_unit = 2 * i
        # Add the fifth power of a_unit to the total sum
        sum = sum + (a_unit ** 5)
    return sum