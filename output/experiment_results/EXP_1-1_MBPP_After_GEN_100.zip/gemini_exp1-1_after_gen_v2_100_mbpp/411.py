import re

def snake_to_camel(input_name):
  # Splits the name by underscores, capitalizes each unit, and joins them.
  # Handles empty units from consecutive underscores by replacing with an underscore.
  return ''.join(name_unit.capitalize() or '_' for name_unit in input_name.split('_'))