def average_tuple(nums):
    outcome = [sum(unit) / len(unit) for unit in zip(*nums)]
    return outcome