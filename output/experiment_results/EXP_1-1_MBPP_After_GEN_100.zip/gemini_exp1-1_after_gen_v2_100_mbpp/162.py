def sum_series(amount_num):
  if amount_num < 1:
    return 0
  else:
    return amount_num + sum_series(amount_num - 2)