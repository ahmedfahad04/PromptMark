def square_nums(nums):
    output_values = list(map(lambda a_num: a_num ** 2, nums))
    return output_values