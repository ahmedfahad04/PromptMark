def Split(input_array):
    return [val for val in input_array if val % 2 == 0]