def is_sublist(main_array, mini_array):
    is_match_okay = False
    if mini_array == []:
        is_match_okay = True
    elif mini_array == main_array:
        is_match_okay = True
    elif len(mini_array) > len(main_array):
        is_match_okay = False
    else:
        # Iterate through the main array to find a potential starting point
        for main_idx in range(len(main_array)):
            if main_array[main_idx] == mini_array[0]:
                sub_idx = 1
                # Check subsequent elements for a match
                while (sub_idx < len(mini_array)) and (main_array[main_idx + sub_idx] == mini_array[sub_idx]):
                    sub_idx += 1
                # If all elements of mini_array matched, it's a sublist
                if sub_idx == len(mini_array):
                    is_match_okay = True
    return is_match_okay