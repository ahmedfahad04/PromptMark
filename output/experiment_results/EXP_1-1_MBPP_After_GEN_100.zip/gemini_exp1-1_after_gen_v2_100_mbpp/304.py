def find_Element(nums, ocus_spans, num_movs, ocus) :
    for i in range(num_movs - 1,-1,-1 ) :
        ocus_a = ocus_spans[i][0]
        ocus_u = ocus_spans[i][1]
        if (ocus_a <= ocus and ocus_u >= ocus) :
            if (ocus == ocus_a) :
                ocus = ocus_u
            else :
                ocus = ocus - 1
    return nums[ocus]