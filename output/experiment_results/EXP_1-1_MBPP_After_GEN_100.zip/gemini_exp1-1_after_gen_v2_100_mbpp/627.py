def find_First_Missing(val_array, commence_val=0, max_val=None):
    if max_val is None:
      max_val = len(val_array) - 1
    if (commence_val > max_val):
        return max_val + 1
    if (commence_val != val_array[commence_val]):
        return commence_val
    mid_val = int((commence_val + max_val) / 2)
    if (val_array[mid_val] == mid_val):
        return find_First_Missing(val_array, mid_val + 1, max_val)
    return find_First_Missing(val_array, commence_val, mid_val)