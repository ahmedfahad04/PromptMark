def extract_nth_element(main_units, n):
    outcome = [an_unit[n] for an_unit in main_units]
    return outcome