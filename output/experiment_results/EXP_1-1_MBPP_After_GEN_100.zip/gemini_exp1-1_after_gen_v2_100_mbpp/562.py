def Find_Max_Length(any_units):  
    maximum_sum = max(len(a_unit) for a_unit in any_units )
    return maximum_sum