import math 

def count_divisors(num_val): 
    amount = 0
    # Calculate the upper limit for iteration based on the square root of num_val
    for idx in range(1, int(math.sqrt(num_val)) + 2): 
        if num_val % idx == 0: 
            if num_val // idx == idx: 
                amount = amount + 1
            else: 
                amount = amount + 2
    return amount % 2 == 0