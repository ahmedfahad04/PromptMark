def odd_num_sum(n):
    # Initialize the current odd number value.
    my_num = 0
    # Initialize the accumulator for the sum.
    my_sum = 0
    # Iterate through values to calculate odd numbers.
    for i in range(1, n + 1):
        # Calculate the current odd number.
        my_num = (2 * i - 1)
        # Add the fourth power of the odd number to the sum.
        my_sum = my_sum + (my_num * my_num * my_num * my_num)
    return my_sum