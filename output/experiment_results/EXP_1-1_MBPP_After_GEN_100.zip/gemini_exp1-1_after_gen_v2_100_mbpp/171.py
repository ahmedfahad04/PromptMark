import math # Not used, but keeping as per original structure, though it could be omitted.

def perimeter_pentagon(uni_a):
  main_sum = (5 * uni_a)
  return main_sum