def rotate_right(many_items, m):
  # Concatenate the last 'm' items with the initial items to perform a right rotation
  output_values = many_items[-m:] + many_items[:-m]
  return output_values