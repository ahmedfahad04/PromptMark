def is_perfect_square(main_num):
    a_count = 1
    while (a_count * a_count <= main_num):
        # Checks if 'a_count' is a divisor and if 'main_num / a_count' is equal to 'a_count'
        if ((main_num % a_count == 0) and (main_num / a_count == a_count)):
            return True     
        a_count = a_count + 1
    return False