def list_split(my_array, jumps_count):
    return [my_array[i::jumps_count] for i in range(jumps_count)]