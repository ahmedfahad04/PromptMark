import re

def text_lowercase_underscore(an_input_value):
        a_match_config = '^[a-z]+_[a-z]+$'
        if re.search(a_match_config,  an_input_value):
                return True
        else:
                return False