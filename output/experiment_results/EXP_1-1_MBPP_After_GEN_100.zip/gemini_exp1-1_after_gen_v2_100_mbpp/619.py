def move_num(main_string):
  non_nums = ''
  sum_nums = ''
  for any_c in main_string:
    if any_c.isdigit():
      sum_nums += any_c
    else:
      non_nums += any_c
  non_nums += sum_nums
  return non_nums