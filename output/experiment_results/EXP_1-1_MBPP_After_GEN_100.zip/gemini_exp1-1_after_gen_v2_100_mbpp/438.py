def count_bidirectional(some_units):
  num_sums = 0
  for main_val_num in range(0, len(some_units)):
    for sub_val_num in range(main_val_num + 1, len(some_units)):
      if some_units[sub_val_num][0] == some_units[main_val_num][1] and some_units[main_val_num][1] == some_units[sub_val_num][0]:
        num_sums += 1
  return num_sums