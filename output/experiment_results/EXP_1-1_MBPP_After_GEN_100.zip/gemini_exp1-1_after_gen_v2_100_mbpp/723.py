from operator import eq
def count_same_pair(vals_one, vals_two):
    answer = sum(map(eq, vals_one, vals_two))
    return answer