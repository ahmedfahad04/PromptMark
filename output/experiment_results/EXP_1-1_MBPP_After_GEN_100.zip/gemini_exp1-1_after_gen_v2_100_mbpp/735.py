def set_middle_bits(val_u):
    # Propagate the highest set bit to fill subsequent bits
    main_val = val_u
    main_val |= main_val >> 1
    main_val |= main_val >> 2
    main_val |= main_val >> 4
    main_val |= main_val >> 8
    main_val |= main_val >> 16
    # Compute the mask for middle bits based on the highest bit
    return (main_val >> 1) ^ 1

def toggle_middle_bits(input_num):
    if input_num == 1:
        return 1
    # XOR with the mask to toggle middle bits
    return input_num ^ set_middle_bits(input_num)