def drop_empty(main_map):
  # Creates a new map containing only entries where the value is not None
  main_map = {item_key: any_value for (item_key, any_value) in main_map.items() if any_value is not None}
  return main_map