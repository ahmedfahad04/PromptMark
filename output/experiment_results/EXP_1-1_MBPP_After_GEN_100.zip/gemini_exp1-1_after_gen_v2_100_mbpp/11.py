def remove_Occ(main_string, omit_char):
    # Locate and remove the first occurrence of the character
    for idx in range(len(main_string)):
        if (main_string[idx] == omit_char):
            main_string = main_string[0 : idx] + main_string[idx + 1:]
            break
    # Locate and remove the last occurrence of the character
    for idx in range(len(main_string) - 1, -1, -1):
        if (main_string[idx] == omit_char):
            main_string = main_string[0 : idx] + main_string[idx + 1:]
            break
    return main_string