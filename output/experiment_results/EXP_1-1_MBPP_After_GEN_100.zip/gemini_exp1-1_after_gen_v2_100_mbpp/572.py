def two_unique_nums(my_coins):
  # Identify items that appear only once in the collection
  return [an_obj for an_obj in my_coins if my_coins.count(an_obj)==1]