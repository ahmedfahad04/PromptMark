def replace_char(in_canvas_many, scan_sym, join_sym):
    join_canvas = in_canvas_many.replace(scan_sym, join_sym)
    return join_canvas