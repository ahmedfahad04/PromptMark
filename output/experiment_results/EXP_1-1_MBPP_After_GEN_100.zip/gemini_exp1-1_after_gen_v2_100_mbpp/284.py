def check_element(any_units, unit_value):
  is_univocal_match = all(current_item == unit_value for current_item in any_units)
  return is_univocal_match