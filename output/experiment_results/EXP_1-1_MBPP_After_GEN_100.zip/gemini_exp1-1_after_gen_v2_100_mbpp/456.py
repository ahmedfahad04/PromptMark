def reverse_string_list(my_units):
    my_units_out = [my_unit[::-1] for my_unit in my_units]
    return my_units_out