import math
def otherside_rightangle(w_val, h_val):
  # Calculate the hypotenuse using the Pythagorean theorem
  sum_of_squares = (w_val * w_val) + (h_val * h_val)
  hypotenuse = math.sqrt(sum_of_squares)
  return hypotenuse