def remove_nested(main_union):
  acum = tuple()
  for anum, a_main in enumerate(main_union):
    if not isinstance(a_main, tuple):
      acum = acum + (a_main, )
  return acum