def extract_singly(input_values):
  # Accumulates the unique items in the order they are first encountered.
  unique_output = []
  # Stores items that have already been seen to ensure uniqueness.
  known_items = set()
  for a_unit in input_values:
    for an_item in a_unit:
      if an_item not in known_items:
        known_items.add(an_item)
        unique_output.append(an_item)
  return unique_output