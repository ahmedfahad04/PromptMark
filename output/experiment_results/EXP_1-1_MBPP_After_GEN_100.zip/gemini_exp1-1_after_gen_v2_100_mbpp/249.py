def intersection_array(main_input_values, any_input_values):
    common_values = list(filter(lambda item: item in main_input_values, any_input_values))
    return common_values