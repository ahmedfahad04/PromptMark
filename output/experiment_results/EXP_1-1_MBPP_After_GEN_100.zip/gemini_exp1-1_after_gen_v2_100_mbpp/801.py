def test_three_equal(num_a, num_c, num_v):
  items_union = {num_a, num_c, num_v}
  if len(items_union) == 3:
    return 0
  else:
    return 4 - len(items_union)