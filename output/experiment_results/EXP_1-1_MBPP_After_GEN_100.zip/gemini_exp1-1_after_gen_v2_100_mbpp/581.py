def surface_Area(w, s):
    return 2 * w * s + pow(w, 2)