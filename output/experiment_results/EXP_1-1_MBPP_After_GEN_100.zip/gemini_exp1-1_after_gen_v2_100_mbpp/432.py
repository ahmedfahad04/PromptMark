def median_trapezium(main_a, way_o, a_way_in):
    # a_way_in parameter is not used in this calculation
    uni_sum = 0.5 * (main_a + way_o)
    return uni_sum