NO_OF_CHARS = 256

def str_to_list(input_string):
    char_array = []
    for a_char in input_string:
        char_array.append(a_char)
    return char_array

def lst_to_string(char_array):
    return ''.join(char_array)

def get_char_count_array(input_string):
    count = [0] * NO_OF_CHARS
    for a_char in input_string:
        count[ord(a_char)] += 1
    return count

def remove_dirty_chars(main_string, comparison_string):
    count = get_char_count_array(comparison_string)
    input_index = 0
    current_output_idx = 0
    str_array = str_to_list(main_string)

    while input_index != len(str_array):
        a_char_item = str_array[input_index]
        if count[ord(a_char_item)] == 0:
            str_array[current_output_idx] = str_array[input_index]
            current_output_idx += 1
        input_index += 1
    return lst_to_string(str_array[0:current_output_idx])