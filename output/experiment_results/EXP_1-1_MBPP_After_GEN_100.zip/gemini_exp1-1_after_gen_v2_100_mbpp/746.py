import math
def sector_area(a_univ, a):
    if a > 360:
        return None
    return (math.pi * a_univ**2) * (a / 360)