def list_to_float(input_values):
  ans_values = []
  for a_unit in input_values:
    unit_values = []
    for an_entry in a_unit:
      if an_entry.isalpha():
        unit_values.append(an_entry)
      else:
        unit_values.append(float(an_entry))
    ans_values.append((unit_values[0], unit_values[1]))
  return ans_values