def round_and_sum(a_values):
  many_units = len(a_values)
  my_sum_amount = sum(list(map(round, a_values)) * many_units)
  return my_sum_amount