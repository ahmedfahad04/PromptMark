def union_elements(main_uni, join_uni):
  main_union = tuple(set(main_uni + join_uni))
  return main_union