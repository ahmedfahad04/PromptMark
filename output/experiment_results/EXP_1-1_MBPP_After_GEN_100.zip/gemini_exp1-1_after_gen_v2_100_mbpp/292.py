def find(n, m):
    ans = n // m
    return ans