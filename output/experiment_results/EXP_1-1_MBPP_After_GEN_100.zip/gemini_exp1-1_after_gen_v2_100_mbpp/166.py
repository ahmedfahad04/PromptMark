def find_even_pair(a_nums):
  accum_sum = 0
  for i in range(0, len(a_nums)):
    for j in range(i + 1, len(a_nums)):
        # Check if the XOR sum of the pair is even
        if ((a_nums[i] ^ a_nums[j]) % 2 == 0):
          accum_sum += 1

  return accum_sum