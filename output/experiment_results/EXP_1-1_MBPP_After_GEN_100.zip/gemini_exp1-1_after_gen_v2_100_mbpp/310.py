def string_to_tuple(input_val):
    ans = tuple(val for val in input_val if not val.isspace()) 
    return ans