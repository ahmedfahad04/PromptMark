def comb_sort(nums):
    compaction_val = 1.3
    unit_amounts = len(nums)
    is_moved = True
    i = 0
    while unit_amounts > 1 or is_moved:
        unit_amounts = int(float(unit_amounts) / compaction_val)
        is_moved = False
        i = 0
        while unit_amounts + i < len(nums):
            if nums[i] > nums[i + unit_amounts]:
                nums[i], nums[i + unit_amounts] = nums[i + unit_amounts], nums[i]
                is_moved = True
            i += 1
    return nums