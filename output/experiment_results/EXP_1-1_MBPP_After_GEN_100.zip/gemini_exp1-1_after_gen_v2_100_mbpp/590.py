import cmath
def polar_rect(co_x, co_y):
    # Create an initial complex number from the input coordinates
    a_num_c = complex(co_x, co_y)
    # Convert the complex number to polar coordinates (magnitude, phase)
    a_num_c = cmath.polar(a_num_c)
    # Create another complex number from polar coordinates (magnitude=2, phase=pi)
    aux_obj_c = cmath.rect(2, cmath.pi)
    return (a_num_c, aux_obj_c)