def count_rotation(my_nums):
    for i in range (1,len(my_nums)):
        if (my_nums[i] < my_nums[i - 1]):
            return i
    return 0