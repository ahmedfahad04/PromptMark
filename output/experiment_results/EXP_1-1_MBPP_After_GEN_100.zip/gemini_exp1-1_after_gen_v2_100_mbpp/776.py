def count_vowels(input_chars):
  count_val = 0
  vow_units = ['a', 'e', 'i', 'o', 'u']
  # Iterate through characters from the second to the second-to-last
  for index_num in range(1, len(input_chars) - 1):
    # Check if current char is not a vowel, but adjacent chars are vowels
    if input_chars[index_num] not in vow_units and \
       (input_chars[index_num - 1] in vow_units or input_chars[index_num + 1] in vow_units):
      count_val += 1
  
  # Check the first character
  if input_chars[0] not in vow_units and input_chars[1] in vow_units:
    count_val += 1
  
  # Check the last character
  if input_chars[-1] not in vow_units and input_chars[-2] in vow_units:
    count_val += 1
    
  return count_val