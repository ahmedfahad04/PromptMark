import re

def capital_words_spaces(a_string):
  return re.sub(r"(\w)([A-Z])", r"\1 \2", a_string)