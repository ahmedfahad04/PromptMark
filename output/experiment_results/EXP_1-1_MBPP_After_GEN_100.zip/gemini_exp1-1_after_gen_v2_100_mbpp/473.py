def tuple_intersection(main_array, other_array):
  # Normalize and convert tuples from the first array into a set
  union_one = set([tuple(sorted(unit)) for unit in main_array])
  # Normalize and convert tuples from the second array into a set
  union_two = set([tuple(sorted(unit)) for unit in other_array])
  # Compute the intersection of the two sets
  common_items = union_one & union_two
  return common_items