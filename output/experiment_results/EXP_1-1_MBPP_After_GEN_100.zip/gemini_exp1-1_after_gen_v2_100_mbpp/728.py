def sum_list(many_nums, many_nums_o):
  sum_nums = [many_nums[i] + many_nums_o[i] for i in range(len(many_nums))]
  return sum_nums