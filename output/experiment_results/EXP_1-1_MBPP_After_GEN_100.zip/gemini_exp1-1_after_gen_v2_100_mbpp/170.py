def sum_range_list(value_array, m, n):
    amount_sum = 0
    for i in range(m, n + 1, 1):
        amount_sum += value_array[i]
    return amount_sum