def power(main_val, count_val):
    if count_val == 0:
        return 1
    elif main_val == 0:
        return 0
    elif count_val == 1:
        return main_val
    else:
        # Recursively calculate power
        return main_val * power(main_val, count_val - 1)