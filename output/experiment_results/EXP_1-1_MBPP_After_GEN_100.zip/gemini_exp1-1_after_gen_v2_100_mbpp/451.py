import re
def remove_whitespaces(input_val):
  return (re.sub(r'\s+', '', input_val))