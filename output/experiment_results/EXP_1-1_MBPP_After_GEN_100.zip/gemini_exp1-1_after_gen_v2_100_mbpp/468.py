def max_product(arr):
  n = len(arr)
  max_inc_vals = arr[:] # Stores the maximum product of an increasing subarray ending at each index
  for i in range(n):
    accum_val = arr[i]
    j = i + 1
    while j < n:
      if arr[j-1] > arr[j]:
        break # Sequence is no longer increasing
      accum_val *= arr[j]
      if accum_val > max_inc_vals[j]:
        max_inc_vals[j] = accum_val
      j = j + 1
  return max(max_inc_vals)