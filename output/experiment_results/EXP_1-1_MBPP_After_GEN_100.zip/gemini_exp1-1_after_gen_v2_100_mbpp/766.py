def pair_wise(a_values):
    accum_items = []
    for i in range(len(a_values) - 1):
        current_unit, next_unit = a_values[i], a_values[i + 1]
        a_couple = (current_unit, next_unit)
        accum_items.append(a_couple)
    return accum_items