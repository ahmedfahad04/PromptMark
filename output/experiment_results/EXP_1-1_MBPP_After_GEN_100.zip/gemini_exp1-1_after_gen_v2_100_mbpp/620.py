def largest_subset(a_nums):
    num_items = len(a_nums)
    way_counts = [0 for idx_val in range(num_items)]
    way_counts[num_items - 1] = 1
    for current_idx in range(num_items - 2, -1, -1):
        max_among_ways = 0
        for next_idx in range(current_idx + 1, num_items):
            if a_nums[next_idx] % a_nums[current_idx] == 0 or a_nums[current_idx] % a_nums[next_idx] == 0:
                max_among_ways = max(max_among_ways, way_counts[next_idx])
        way_counts[current_idx] = 1 + max_among_ways
    return max(way_counts)