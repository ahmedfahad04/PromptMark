def new_tuple(a_mass, a_say):
  return tuple(a_mass + [a_say])