def sequence(num):
	if num == 1 or num == 2:
		return 1
	else:
		return sequence(sequence(num-1)) + sequence(num-sequence(num-1))