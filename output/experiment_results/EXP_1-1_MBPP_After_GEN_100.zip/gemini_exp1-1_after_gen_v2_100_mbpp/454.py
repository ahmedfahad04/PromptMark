import re
def text_match_wordz(main_input):
        main_syntax = '\w*z.\w*'
        if re.search(main_syntax,  main_input):
                return True
        else:
                return False