def common_in_nested_lists(union_many):
    # Calculate the intersection of all sets derived from the input collections
    common = list(set.intersection(*map(set, union_many)))
    return common