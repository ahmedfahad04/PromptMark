def find_solution(a, sum_u, n):
	i = 0
	while i * a <= n:
		if (n - (i * a)) % sum_u == 0:
			return (i, (n - (i * a)) // sum_u)
		i = i + 1
	return None