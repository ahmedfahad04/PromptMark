def multiply_num(many_nums):
    main_accum = 1
    for a_num in many_nums:
        main_accum *= a_num
    return main_accum / len(many_nums)