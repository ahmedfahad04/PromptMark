def count_X(items, aim_val):
    count = 0
    for unit in items:
        if (unit == aim_val):
            count = count + 1
    return count