from collections import defaultdict

def count_Substrings(s):
    n = len(s)
    many_acum, acum_sum = 0, 0
    occur_acum = defaultdict(lambda : 0)
    occur_acum[0] += 1
    for i in range(n):
        acum_sum += ord(s[i]) - ord('0')
        many_acum += occur_acum[acum_sum - (i + 1)]
        occur_acum[acum_sum - (i + 1)] += 1
    return many_acum