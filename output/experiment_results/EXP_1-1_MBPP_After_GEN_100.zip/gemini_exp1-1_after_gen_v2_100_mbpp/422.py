def find_Average_Of_Cube(count_val):
    amount = 0
    for idx in range(1, count_val + 1):
        amount += idx * idx * idx
    return round(amount / count_val, 6)