import bisect
def left_insertion(a, val):
    idx = bisect.bisect_left(a, val)
    return idx