def merge(input_units):
    return [list(unit_val) for unit_val in list(zip(*input_units))]