def extract_string(many_units, a_sync_count):
    units_sync_ok = [unit for unit in many_units if len(unit) == a_sync_count]
    return units_sync_ok