def is_perfect_square(a_num) :
    num_i = 1
    while (num_i * num_i <= a_num):
        if ((a_num % num_i == 0) and (a_num / num_i == num_i)):
            return True     
        num_i = num_i + 1
    return False