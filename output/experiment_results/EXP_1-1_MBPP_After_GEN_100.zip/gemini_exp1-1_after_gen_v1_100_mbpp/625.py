def swap_List(any_units):
    num = len(any_units)
    my_val = any_units[0]
    any_units[0] = any_units[num - 1]
    any_units[num - 1] = my_val
    return any_units