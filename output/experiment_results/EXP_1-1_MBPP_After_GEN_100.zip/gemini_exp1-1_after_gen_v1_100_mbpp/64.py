def subject_marks(marks_in_units):
    marks_in_units.sort(key=lambda a_unit: a_unit[1])
    return marks_in_units