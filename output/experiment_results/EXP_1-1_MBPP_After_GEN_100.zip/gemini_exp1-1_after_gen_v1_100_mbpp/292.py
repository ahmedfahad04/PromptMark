def find(n, m):
    val_num = n // m
    return val_num