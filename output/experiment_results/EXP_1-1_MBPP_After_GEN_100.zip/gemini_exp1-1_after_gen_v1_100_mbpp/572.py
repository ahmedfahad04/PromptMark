def two_unique_nums(many_units):
  return [unit for unit in many_units if many_units.count(unit) == 1]