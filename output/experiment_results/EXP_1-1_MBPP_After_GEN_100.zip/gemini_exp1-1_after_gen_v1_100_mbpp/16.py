import re

def text_lowercase_underscore(a_uni):
        a_mask = '^[a-z]+_[a-z]+$'
        if re.search(a_mask, a_uni):
                return True
        else:
                return False

print(text_lowercase_underscore("hello_world"))  # True
print(text_lowercase_underscore("Hello_World"))  # False
print(text_lowercase_underscore("helloWorld"))    # False