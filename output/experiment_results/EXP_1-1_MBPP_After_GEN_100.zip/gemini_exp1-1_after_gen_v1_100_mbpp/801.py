def test_three_equal(x, y, z):
  common_units = set([x, y, z])
  if len(common_units) == 3:
    return 0
  else:
    return 4 - len(common_units)