def pair_wise(any_values):
    ans_units = []
    for i in range(len(any_values) - 1):
        main_val, away_val = any_values[i], any_values[i + 1]
        a_union = (main_val, away_val)
        ans_units.append(a_union)
    return ans_units