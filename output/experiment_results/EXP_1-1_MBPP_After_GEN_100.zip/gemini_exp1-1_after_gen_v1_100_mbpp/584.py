import re
def find_adverbs(scan_canvas):
  for scan_univ in re.finditer(r"\w+ly", scan_canvas):
    return ('%d-%d: %s' % (scan_univ.start(), scan_univ.end(), scan_univ.group(0)))