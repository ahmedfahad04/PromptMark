def is_sublist(main_units, scan_units):
    any_inclusion = False
    if scan_units == []:
        any_inclusion = True
    elif scan_units == main_units:
        any_inclusion = True
    elif len(scan_units) > len(main_units):
        any_inclusion = False
    else:
        for k in range(len(main_units)):
            if main_units[k] == scan_units[0]:
                j = 1
                # The original code's while condition for l[i+n] did not explicitly
                # check for out-of-bounds access on the main list.
                # This behavior is maintained to match the original functionality.
                while (j < len(scan_units)) and (main_units[k + j] == scan_units[j]):
                    j += 1
                if j == len(scan_units):
                    any_inclusion = True
    return any_inclusion