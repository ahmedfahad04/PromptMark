def max_product(array_vals):   
  array_amount = len(array_vals)
  # Initialize max_accum_vals with individual array_vals, as a single value can be a valid product.
  max_accum_vals = array_vals[:] 

  for main_idx in range(array_amount): 
    accum_val = array_vals[main_idx] # Start product with the current value
    sub_idx = main_idx + 1
    while sub_idx < array_amount:
      # Stop if the increasing sequence condition is violated
      if array_vals[sub_idx-1] > array_vals[sub_idx]: 
        break
      
      accum_val *= array_vals[sub_idx] # Multiply by the next value in the sequence
      
      # Update the maximum product for the current sub_idx if accum_val is greater
      if accum_val > max_accum_vals[sub_idx]:
        max_accum_vals[sub_idx] = accum_val 
      sub_idx = sub_idx + 1
      
  return max(max_accum_vals) # Return the overall maximum product found