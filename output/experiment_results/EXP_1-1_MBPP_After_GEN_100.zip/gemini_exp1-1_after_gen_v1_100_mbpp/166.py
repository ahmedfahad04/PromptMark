def find_even_pair(an_array):
  num_sums = 0
  for univ_index in range(0, len(an_array)):
    for aux_index in range(univ_index + 1, len(an_array)):
        # Check if XOR of two elements results in an even number.
        # This implies both numbers have the same parity (both even or both odd).
        if ((an_array[univ_index] ^ an_array[aux_index]) % 2 == 0):
          num_sums += 1
  return num_sums