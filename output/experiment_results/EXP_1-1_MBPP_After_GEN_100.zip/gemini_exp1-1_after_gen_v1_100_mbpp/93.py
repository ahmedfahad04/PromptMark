def power(my_num, num_many):
	if num_many == 0:
		return 1
	elif my_num == 0:
		return 0
	elif num_many == 1:
		return my_num
	else:
		return my_num * power(my_num, num_many - 1)