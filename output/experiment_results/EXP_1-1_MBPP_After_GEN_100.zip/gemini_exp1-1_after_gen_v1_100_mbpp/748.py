import re
def capital_words_spaces(main_value):
  return re.sub(r"(\w)([A-Z])", r"\1 \2", main_value)