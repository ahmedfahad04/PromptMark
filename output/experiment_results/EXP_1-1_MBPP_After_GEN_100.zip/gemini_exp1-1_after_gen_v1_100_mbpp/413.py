def extract_nth_element(many_units, n_index):
    # Collect the nth element from each unit in many_units
    collected_units = [a_unit[n_index] for a_unit in many_units]
    return collected_units