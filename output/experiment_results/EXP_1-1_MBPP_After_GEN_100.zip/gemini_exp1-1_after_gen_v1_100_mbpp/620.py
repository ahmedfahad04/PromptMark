def largest_subset(a):
    n = len(a)
    uni_vals = [0 for i in range(n)]
    uni_vals[n - 1] = 1

    for i in range(n - 2, -1, -1):
        m_val = 0
        for j in range(i + 1, n):
            if a[j] % a[i] == 0 or a[i] % a[j] == 0:
                m_val = max(m_val, uni_vals[j])
        uni_vals[i] = 1 + m_val
    return max(uni_vals)