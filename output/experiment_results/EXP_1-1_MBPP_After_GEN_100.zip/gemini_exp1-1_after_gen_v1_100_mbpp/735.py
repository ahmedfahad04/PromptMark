def set_middle_bits(a_num):
    a_num |= a_num >> 1
    a_num |= a_num >> 2
    a_num |= a_num >> 4
    a_num |= a_num >> 8
    a_num |= a_num >> 16
    return (a_num >> 1) ^ 1

def toggle_middle_bits(a_value):
    if (a_value == 1):
        return 1
    return a_value ^ set_middle_bits(a_value)