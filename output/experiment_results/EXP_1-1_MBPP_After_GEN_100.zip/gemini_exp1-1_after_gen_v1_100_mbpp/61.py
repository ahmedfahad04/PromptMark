from collections import defaultdict

def count_Substrings(s):
    n = len(s)
    many, accum_val = 0, 0
    val_assoc = defaultdict(lambda: 0)
    val_assoc[0] += 1
    for i in range(n):
        accum_val += ord(s[i]) - ord('0')
        # The key for the map is accum_val - (i + 1).
        # This value represents (sum of digits up to current index i) - (current length i+1).
        # If this value matches a previously recorded value (from index j),
        # it implies that the substring from j+1 to i has a sum of digits equal to its length.
        many += val_assoc[accum_val - (i + 1)]
        val_assoc[accum_val - (i + 1)] += 1
    return many