import math

def count_divisors(n):
    num_many = 0
    # Iterate up to sqrt(n) to find divisors
    for i in range(1, (int)(math.sqrt(n)) + 2):
        if (n % i == 0):
            if (n // i == i):  # Perfect square case
                num_many = num_many + 1
            else:  # Two distinct divisors found (i and n/i)
                num_many = num_many + 2
    return num_many % 2 == 0