import re
def remove_whitespaces(any_var):
  return (re.sub(r'\s+', '', any_var))