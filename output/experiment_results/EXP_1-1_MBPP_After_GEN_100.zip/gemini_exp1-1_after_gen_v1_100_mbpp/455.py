def check_monthnumb_number(a_month_val):
  if(a_month_val==1 or a_month_val==3 or a_month_val==5 or a_month_val==7 or a_month_val==8 or a_month_val==10 or a_month_val==12):
    return True
  else:
    return False