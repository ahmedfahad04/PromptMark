def extract_singly(input_items):
  unique_values = []
  known_items = set()
  for inner in input_items:
    for item in inner:
      if not item in known_items:
        known_items.add(item)
        unique_values.append(item)
  return unique_values