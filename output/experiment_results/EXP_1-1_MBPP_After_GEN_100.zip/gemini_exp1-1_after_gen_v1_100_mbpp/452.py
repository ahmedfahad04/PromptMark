def loss_amount(unit_cost, income_money):
  if income_money > unit_cost:
    cash_value = income_money - unit_cost
    return cash_value
  else:
    return 0