def interleave_lists(many_a, many_i, many_o):
    union_many = [a_unit for a_chunk in zip(many_a, many_i, many_o) for a_unit in a_chunk]
    return union_many