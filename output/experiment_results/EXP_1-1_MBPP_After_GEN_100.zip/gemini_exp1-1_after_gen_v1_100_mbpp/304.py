def find_Element(my_nums, action_configs, num_movs, my_way) :  
    for i in range(num_movs - 1, -1, -1) : 
        ini_way = action_configs[i][0] 
        many_way = action_configs[i][1] 
        if (ini_way <= my_way and many_way >= my_way) : 
            if (my_way == ini_way) : 
                my_way = many_way 
            else : 
                my_way = my_way - 1 
    return my_nums[my_way]