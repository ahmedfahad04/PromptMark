def square_Sum(num):
    return int(num*(4*num*num-1)/3)