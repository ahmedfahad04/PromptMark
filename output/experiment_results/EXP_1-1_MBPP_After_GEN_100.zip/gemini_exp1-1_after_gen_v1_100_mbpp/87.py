import collections as ct
def merge_dictionaries_three(my_input_a, my_input_b, my_input_c):
    accum_union = dict(ct.ChainMap({}, my_input_a, my_input_b, my_input_c))
    return accum_union