import re
def extract_quotation(main_canvas):
  return (re.findall(r'"(.*?)"', main_canvas))