def sum_even_and_even_index(an_array):
    main_sum = 0
    for index in range(0, len(an_array), 2):
        if (an_array[index] % 2 == 0):
            main_sum += an_array[index]
    return main_sum