def sequence(num):
    if num == 1 or num == 2:
        return 1
    else:
        val_one = sequence(num - 1)
        return sequence(val_one) + sequence(num - val_one)