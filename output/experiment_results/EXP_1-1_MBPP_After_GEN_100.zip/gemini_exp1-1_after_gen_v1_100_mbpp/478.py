import re

def remove_lowercase(uni_string):
    """
    Removes all lowercase letters from a given string.
    """
    return re.sub('[a-z]', '', uni_string)