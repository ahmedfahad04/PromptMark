def count_vowels(my_string):
  accum_num = 0
  vowels = ['a', 'e', 'i', 'o', 'u']
  
  # Count for characters not at the string's ends
  for i in range(1, len(my_string) - 1):
    if my_string[i] not in vowels and (my_string[i - 1] in vowels or my_string[i + 1] in vowels):
      accum_num += 1
  
  # Count for the first character
  if my_string[0] not in vowels and my_string[1] in vowels:
    accum_num += 1
  
  # Count for the last character
  if my_string[-1] not in vowels and my_string[-2] in vowels:
    accum_num += 1
    
  return accum_num