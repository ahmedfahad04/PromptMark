def list_tuple(input_val):
  a_unity = tuple(input_val)
  return a_unity