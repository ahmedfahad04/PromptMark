def count_rotation(units):
    for i in range(1, len(units)):
        # Check if the current unit is smaller than the previous one, indicating a rotation point
        if units[i] < units[i - 1]:
            return i
    return 0