def find_Average_Of_Cube(n):
    acum_val = 0
    for a_num in range(1, n + 1):
        acum_val += a_num * a_num * a_num
    return round(acum_val / n, 6)