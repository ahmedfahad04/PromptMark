from operator import eq

def count_same_pair(many_values_a, many_values_k):
    # Calculate the sum of matching items using the equality operator
    count_val = sum(map(eq, many_values_a, many_values_k))
    return count_val