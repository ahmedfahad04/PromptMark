def parabola_directrix(a, u, c):
  main_num = ((int)(c - ((u * u) + 1) * 4 * a ))
  return main_num