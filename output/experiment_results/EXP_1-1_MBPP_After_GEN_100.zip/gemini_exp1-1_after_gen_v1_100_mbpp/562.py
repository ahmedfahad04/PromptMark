def Find_Max_Length(a_canvas):
    many_units_count = max(len(a_canvas_unit) for a_canvas_unit in a_canvas)
    return many_units_count