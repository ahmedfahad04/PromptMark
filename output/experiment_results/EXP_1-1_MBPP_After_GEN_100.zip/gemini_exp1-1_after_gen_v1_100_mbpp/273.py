def substract_elements(main_uni_val, my_uni_val):
  calc_val = tuple(map(lambda uni, joy: uni - joy, main_uni_val, my_uni_val))
  return (calc_val)