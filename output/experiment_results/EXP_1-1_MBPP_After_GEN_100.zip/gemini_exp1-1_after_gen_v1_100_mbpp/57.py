def find_Max_Num(my_vals) :
    count = len(my_vals)
    my_vals.sort(reverse = True)
    main_val = my_vals[0]
    for idx in range(1, count) :
        main_val = main_val * 10 + my_vals[idx]
    return main_val