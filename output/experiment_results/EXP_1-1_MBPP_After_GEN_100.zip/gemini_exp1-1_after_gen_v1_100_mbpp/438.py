def count_bidirectional(units_main):
  my_count = 0
  for main_i in range(0, len(units_main)):
    for scan_i in range(main_i + 1, len(units_main)):
      # Condition: first element of current unit matches second element of an earlier unit.
      if units_main[scan_i][0] == units_main[main_i][1] and units_main[main_i][1] == units_main[scan_i][0]:
        my_count += 1
  return my_count