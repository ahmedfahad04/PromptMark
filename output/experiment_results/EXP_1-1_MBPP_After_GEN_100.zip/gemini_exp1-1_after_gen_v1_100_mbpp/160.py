def find_solution(a, y_unit, n):
	count_val = 0
	while count_val * a <= n:
		if (n - (count_val * a)) % y_unit == 0:
			return (count_val, (n - (count_val * a)) // y_unit)
		count_val = count_val + 1
	return None