import math

def otherside_rightangle(v_one, v_two):
  a_sum = math.sqrt((v_one * v_one) + (v_two * v_two))
  return a_sum