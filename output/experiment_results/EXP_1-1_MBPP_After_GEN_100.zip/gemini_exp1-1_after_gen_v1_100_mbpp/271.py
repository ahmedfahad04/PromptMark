def even_Power_Sum(num_many):
    sum_val = 0
    for an_index in range(1, num_many + 1):
        a_value = 2 * an_index
        sum_val = sum_val + (a_value * a_value * a_value * a_value * a_value)
    return sum_val