import re
def snake_to_camel(input_word):
  return ''.join(unit.capitalize() or '_' for unit in input_word.split('_'))