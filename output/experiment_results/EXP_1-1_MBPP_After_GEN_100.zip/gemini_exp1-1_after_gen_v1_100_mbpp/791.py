def remove_nested(a_uni_value):
  main_uni = tuple()
  for count, a_value in enumerate(a_uni_value):
    if not isinstance(a_value, tuple):
      main_uni = main_uni + (a_value, )
  return main_uni