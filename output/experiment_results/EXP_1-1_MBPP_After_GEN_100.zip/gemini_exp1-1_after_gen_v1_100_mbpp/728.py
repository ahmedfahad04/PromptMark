def sum_list(units_a, units_b):
  combined_units = [units_a[i] + units_b[i] for i in range(len(units_a))] 
  return combined_units