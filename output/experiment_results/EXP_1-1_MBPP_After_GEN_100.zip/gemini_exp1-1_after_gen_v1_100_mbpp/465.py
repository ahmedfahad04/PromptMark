def drop_empty(univ_map):
  # Create a new dictionary containing only items with non-None values
  univ_map = {a_key: a_val for (a_key, a_val) in univ_map.items() if a_val is not None}
  return univ_map