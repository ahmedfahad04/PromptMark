import re

def start_withp(my_values):
    for a_value in my_values:
        m = re.match("(P\w+)\W(P\w+)", a_value)
        if m:
            return m.groups()