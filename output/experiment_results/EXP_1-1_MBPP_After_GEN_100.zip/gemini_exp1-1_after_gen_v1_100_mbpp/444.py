def trim_tuple(input_many, K):
  outcome_many = []
  for an_unit in input_many:
    N = len(an_unit)
    outcome_many.append(tuple(list(an_unit)[K: N - K]))
  return (str(outcome_many))