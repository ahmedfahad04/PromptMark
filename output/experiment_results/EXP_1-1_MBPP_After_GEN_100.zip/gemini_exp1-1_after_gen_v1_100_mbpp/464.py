def check_value(value_map, univ_val):
    outcome = all(any_val == univ_val for any_val in value_map.values())
    return outcome