def Find_Min(main_units):
    return min(main_units, key=len)