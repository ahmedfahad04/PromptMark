def common_in_nested_lists(many_unicoms):
    unity_common = list(set.intersection(*map(set, many_unicoms)))
    return unity_common