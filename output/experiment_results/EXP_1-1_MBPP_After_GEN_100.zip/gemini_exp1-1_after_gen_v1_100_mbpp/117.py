def list_to_float(input_units):
  outcome_values = []
  for input_unit in input_units:
    my_values = []
    for input_unit_value in input_unit:
      if input_unit_value.isalpha():
        my_values.append(input_unit_value)
      else:
        my_values.append(float(input_unit_value))
    outcome_values.append((my_values[0], my_values[1]))
  return outcome_values