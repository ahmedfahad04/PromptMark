def odd_num_sum(n) :
    j = 0
    acum = 0
    for i in range(1, n + 1) :
        j = (2 * i - 1)
        acum = acum + (j * j * j * j)
    return acum