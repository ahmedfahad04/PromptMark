import re
def text_match_wordz(scan_input):
        scan_mask = '\w*z.\w*'
        if re.search(scan_mask,  scan_input):
                return True
        else:
                return False