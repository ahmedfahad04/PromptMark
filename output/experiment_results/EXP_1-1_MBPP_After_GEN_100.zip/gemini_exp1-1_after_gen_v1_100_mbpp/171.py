import math
def perimeter_pentagon(a):
  sum_on_sides = (5 * a)
  return sum_on_sides