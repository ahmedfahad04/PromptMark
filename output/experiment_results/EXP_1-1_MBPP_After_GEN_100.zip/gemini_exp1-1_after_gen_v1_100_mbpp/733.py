def find_first_occurrence(A, ask_num):
    min_i, win_i = 0, len(A) - 1
    ans_idx = -1
    while min_i <= win_i:
        scan_i = (min_i + win_i) // 2
        if ask_num == A[scan_i]:
            ans_idx = scan_i
            win_i = scan_i - 1
        elif ask_num < A[scan_i]:
            win_i = scan_i - 1
        else:
            min_i = scan_i + 1
    return ans_idx