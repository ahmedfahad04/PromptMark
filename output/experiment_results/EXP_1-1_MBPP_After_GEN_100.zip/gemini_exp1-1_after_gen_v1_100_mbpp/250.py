def count_X(input_values, key_value):
    count = 0
    for any_unit in input_values:
        if (any_unit == key_value):
            count = count + 1
    return count