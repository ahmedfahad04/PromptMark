def multiply_num(num_vals):
    accum_sum = 1
    for val in num_vals:
        accum_sum *= val
    return accum_sum / len(num_vals)