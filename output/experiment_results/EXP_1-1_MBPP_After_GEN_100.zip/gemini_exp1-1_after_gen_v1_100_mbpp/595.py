def min_Swaps(s_main_one, s_main_two) :
    a_sum = 0
    for a_num in range(len(s_main_one)) :
        if s_main_one[a_num] != s_main_two[a_num] :
            a_sum += 1
    if a_sum % 2 == 0 :
        return (a_sum // 2)
    else :
        return ("Not Possible")