def insert_element(input_many, a_val):
    # This list comprehension inserts 'a_val' before each existing unit in 'input_many'
    input_many = [v for any_val in input_many for v in (a_val, any_val)]
    return input_many