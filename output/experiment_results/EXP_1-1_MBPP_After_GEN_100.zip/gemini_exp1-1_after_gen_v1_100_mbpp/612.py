def merge(many_units):
    return [list(unit) for unit in list(zip(*many_units))]