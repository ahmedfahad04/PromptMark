def empty_dit(many_units):
    is_any_vacuus = all(not any_unit for any_unit in many_units)
    return is_any_vacuus