def square_nums(nums):
    accum_nums = list(map(lambda any_num: any_num ** 2, nums))
    return accum_nums