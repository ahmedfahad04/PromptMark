def surface_Area(unit_val, incline_val):
    return 2 * unit_val * incline_val + pow(unit_val, 2)