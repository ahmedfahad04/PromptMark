def sum_series(num):
  if num < 1:
    return 0
  else:
    return num + sum_series(num - 2)