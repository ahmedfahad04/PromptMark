def comb_sort(values):
    cut_magic = 1.3
    moving_span = len(values)
    any_motion = True
    idx = 0
    while moving_span > 1 or any_motion:
        moving_span = int(float(moving_span) / cut_magic)
        any_motion = False
        idx = 0
        while moving_span + idx < len(values):
            if values[idx] > values[idx + moving_span]:
                values[idx], values[idx + moving_span] = values[idx + moving_span], values[idx]
                any_motion = True
            idx += 1
    return values