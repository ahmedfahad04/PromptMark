def average_tuple(nums):
    answer_values = [sum(column_units) / len(column_units) for column_units in zip(*nums)]
    return answer_values