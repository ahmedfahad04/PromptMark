def remove_Occ(s, c):
    # Iterate from the start to find and remove the first occurrence
    for ani in range(len(s)):
        if (s[ani] == c):
            s = s[0 : ani] + s[ani + 1:]
            break
    # Iterate from the end to find and remove the last occurrence
    for ani in range(len(s) - 1, -1, -1):
        if (s[ani] == c):
            s = s[0 : ani] + s[ani + 1:]
            break
    return s