def find_First_Missing(many_values, a_comm_idx=0, a_max_idx=None):
    if a_max_idx is None:
        a_max_idx = len(many_values) - 1
    if (a_comm_idx > a_max_idx):
        return a_max_idx + 1
    if (a_comm_idx != many_values[a_comm_idx]):
        return a_comm_idx
    a_mid_idx = int((a_comm_idx + a_max_idx) / 2)
    if (many_values[a_mid_idx] == a_mid_idx):
        return find_First_Missing(many_values, a_mid_idx + 1, a_max_idx)
    return find_First_Missing(many_values, a_comm_idx, a_mid_idx)