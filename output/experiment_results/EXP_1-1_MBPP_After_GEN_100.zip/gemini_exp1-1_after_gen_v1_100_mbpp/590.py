import cmath

def polar_rect(a_uni_num, a_many_num):
    # Create an initial complex number from the input coordinates
    a_main_val = complex(a_uni_num, a_many_num)
    # Convert the complex number to its polar form (magnitude, phase)
    a_main_val = cmath.polar(a_main_val)
    # Create a second complex number from polar coordinates (magnitude 2, phase pi)
    a_many_val = cmath.rect(2, cmath.pi)
    return (a_main_val, a_many_val)