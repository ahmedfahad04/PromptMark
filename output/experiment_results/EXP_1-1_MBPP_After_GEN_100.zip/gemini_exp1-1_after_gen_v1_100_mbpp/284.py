def check_element(a_unity_many, a_mark):
  units_ok = all(a_val_in_many == a_mark for a_val_in_many in a_unity_many)
  return units_ok