def union_elements(uni_one, uni_two):
  # Concatenate the input tuples and convert to a set to find unique elements
  my_outcome = tuple(set(uni_one + uni_two))
  return my_outcome