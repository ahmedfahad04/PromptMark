def list_split(many_units, num_chunks):
    return [many_units[any_count::num_chunks] for any_count in range(num_chunks)]