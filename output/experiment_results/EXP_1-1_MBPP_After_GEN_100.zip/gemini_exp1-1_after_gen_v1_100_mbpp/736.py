import bisect

def left_insertion(a, key):
    # Find the insertion point for 'key' in sorted array 'a'
    # 'i' will be the index where 'key' can be inserted to maintain sort order.
    i = bisect.bisect_left(a, key)
    return i