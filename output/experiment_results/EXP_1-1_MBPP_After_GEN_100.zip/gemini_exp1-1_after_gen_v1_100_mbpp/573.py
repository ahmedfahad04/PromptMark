def unique_product(any_many_nums):
    # Obtain unique numeric values
    many_unicums = list(set(any_many_nums))
    accum_many = 1
    for a_num in many_unicums:
        accum_many *= a_num
    return accum_many