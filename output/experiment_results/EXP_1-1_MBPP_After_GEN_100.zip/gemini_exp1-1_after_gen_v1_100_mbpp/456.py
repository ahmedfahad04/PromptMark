def reverse_string_list(many_inputs):
    many_outputs = [a_unit[::-1] for a_unit in many_inputs]
    return many_outputs