NO_OF_CHARS = 256 # This constant remains as is

def str_to_list(input_string_val):
	"""Converts a string to a list of characters."""
	char_units_array = []
	for one_char_unit in input_string_val:
		char_units_array.append(one_char_unit)
	return char_units_array

def lst_to_string(char_units_array):
	"""Converts a list of characters back to a string."""
	return ''.join(char_units_array)

def get_char_count_array(input_string_val):
	"""Creates an array representing character frequencies."""
	counts_array = [0] * NO_OF_CHARS
	for one_char_val in input_string_val:
		counts_array[ord(one_char_val)] += 1
	return counts_array

def remove_dirty_chars(source_string_val, invalid_chars_string_val):
	"""
	Removes characters from source_string_val that are present in invalid_chars_string_val.
	"""
	# Get character counts for the invalid_chars_string_val
	char_occurrences_count = get_char_count_array(invalid_chars_string_val)

	input_index = 0
	output_index = 0
	current_char_unit = ''
	source_char_units_array = str_to_list(source_string_val)

	# Iterate through the source string array
	while input_index != len(source_char_units_array):
		current_char_unit = source_char_units_array[input_index]
		# If the current character is not in the invalid_chars_string_val (count is 0)
		if char_occurrences_count[ord(current_char_unit)] == 0:
			source_char_units_array[output_index] = source_char_units_array[input_index]
			output_index += 1
		input_index += 1
	
	# Convert the modified array back to a string, using only the valid part
	return lst_to_string(source_char_units_array[0:output_index])