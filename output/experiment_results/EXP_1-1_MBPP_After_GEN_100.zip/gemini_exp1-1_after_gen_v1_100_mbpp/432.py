def median_trapezium(a_val_one, a_val_two, a_unit):
    avg_val = 0.5 * (a_val_one + a_val_two)
    return avg_val