def intersection_array(in_a_nums, scan_nums):
    common_nums = list(filter(lambda a_num: a_num in in_a_nums, scan_nums))
    return common_nums