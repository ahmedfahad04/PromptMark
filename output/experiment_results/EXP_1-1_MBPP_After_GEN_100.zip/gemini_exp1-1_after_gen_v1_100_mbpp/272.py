def rear_extract(source_many_units):
  many_units = [a_unit[-1] for a_unit in source_many_units]
  return many_units