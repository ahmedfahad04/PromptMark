def round_and_sum(input_values):
  count_of_items = len(input_values)
  # Creates a list of rounded values, repeats it 'count_of_items' times, then sums all values.
  output_sum = sum(list(map(round, input_values)) * count_of_items)
  return output_sum