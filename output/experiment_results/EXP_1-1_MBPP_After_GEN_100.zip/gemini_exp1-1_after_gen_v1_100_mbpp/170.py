def sum_range_list(my_nums, m, n):
    my_sum = 0
    for i in range(m, n + 1, 1):
        my_sum += my_nums[i]
    return my_sum