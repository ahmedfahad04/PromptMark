def rotate_right(units, m):
  accum = units[-m:] + units[:-m]
  return accum