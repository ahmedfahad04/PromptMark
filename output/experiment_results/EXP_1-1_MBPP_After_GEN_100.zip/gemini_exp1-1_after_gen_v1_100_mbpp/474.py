def replace_char(main_input, a_key, a_new_val):
    main_output = main_input.replace(a_key, a_new_val)
    return main_output