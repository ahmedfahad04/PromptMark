def move_num(main_input):
  chars_accum = ''
  num_accum = ''
  for a_unit in main_input:
    if a_unit.isdigit():
      num_accum += a_unit
    else:
      chars_accum += a_unit
  chars_accum += num_accum
  return chars_accum