def tuple_intersection(source_array_one, source_array_two):
  common_units = set([tuple(sorted(any_unit)) for any_unit in source_array_one]) & set([tuple(sorted(any_unit)) for any_unit in source_array_two])
  return common_units