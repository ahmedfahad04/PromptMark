def new_tuple(main_items, an_item):
  return tuple(main_items + [an_item])