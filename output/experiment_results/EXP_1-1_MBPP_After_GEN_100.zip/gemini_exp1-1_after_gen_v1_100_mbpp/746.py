import math

def sector_area(uni_arc_val, arc_amt_val):
    if arc_amt_val > 360:
        return None
    return (math.pi * uni_arc_val**2) * (arc_amt_val / 360)