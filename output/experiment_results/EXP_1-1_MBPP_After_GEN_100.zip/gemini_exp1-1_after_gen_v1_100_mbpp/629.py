def Split(nums_in):
    return [num for num in nums_in if num % 2 == 0]