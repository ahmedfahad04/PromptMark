def string_to_tuple(source_units):
    ans = tuple(any_char for any_char in source_units if not any_char.isspace())
    return ans