def mul_even_odd(an_array):
    an_even_num = next((num for num in an_array if num % 2 == 0), -1)
    an_odd_num = next((num for num in an_array if num % 2 != 0), -1)
    return (an_even_num * an_odd_num)