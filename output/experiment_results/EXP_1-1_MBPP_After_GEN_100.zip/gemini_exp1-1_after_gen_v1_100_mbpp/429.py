def and_tuples(input_a_vals, input_i_vals):
  # Perform bitwise AND operation on corresponding elements from the input tuples
  output_vals = tuple(val_a & val_i for val_a, val_i in zip(input_a_vals, input_i_vals))
  return output_vals