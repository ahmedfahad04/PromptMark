def rectangle_area(main_axis, my_span):
  my_canvas = main_axis * my_span
  return my_canvas