def frequency_lists(input_arrays):
    # Flatten the input list of lists into a single array of units
    all_units_array = [a_unit for an_array in input_arrays for a_unit in an_array]
    counts_map = {}
    for num in all_units_array:
        if num in counts_map.keys():
            counts_map[num] += 1
        else:
            counts_map[num] = 1
    return counts_map