def group_tuples(unions):
	canvas_many = {}
	for any_unit in unions:
		try:
			canvas_many[any_unit[0]].extend(any_unit[1:])
		except KeyError:
			canvas_many[any_unit[0]] = list(any_unit)
	return [tuple(many_units) for many_units in canvas_many.values()]