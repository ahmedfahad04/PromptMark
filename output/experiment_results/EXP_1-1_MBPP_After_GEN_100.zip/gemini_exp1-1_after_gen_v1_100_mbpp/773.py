import re
def occurance_substring(input_main_string, scan_mask):
    for scan_obj in re.finditer(scan_mask, input_main_string):
        idx_start = scan_obj.start()
        idx_end = scan_obj.end()
        return (input_main_string[idx_start:idx_end], idx_start, idx_end)