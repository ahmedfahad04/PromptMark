def max_product(arr):   
  n = len(arr)
  mpis = arr[:]
  for i in range(n): 
    current_prod = arr[i]
    j = i + 1
    while j < n:
      if arr[j-1] > arr[j]: 
        break
      current_prod *= arr[j]
      if current_prod > mpis[j]:
        mpis[j] = current_prod 
      j = j + 1
  return max(mpis)

# Renaming identifiers according to the green letter list
def max_product(input_arr):   
  n = len(input_arr)
  max_prods = input_arr[:]
  for i in range(n): 
    curr_prod = input_arr[i]
    j = i + 1
    while j < n:
      if input_arr[j-1] > input_arr[j]: 
        break
      curr_prod *= input_arr[j]
      if curr_prod > max_prods[j]:
        max_prods[j] = curr_prod 
      j = j + 1
  return max(max_prods)