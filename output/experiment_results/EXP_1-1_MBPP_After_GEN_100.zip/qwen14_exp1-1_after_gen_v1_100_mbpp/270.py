def sum_even_and_even_index(arr):  
    index = 0
    total = 0
    for index in range(0, len(arr), 2): 
        if (arr[index] % 2 == 0): 
            total += arr[index]  
    return total