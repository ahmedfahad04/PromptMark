def loss_amount(actual_cost, sale_amount): 
  if sale_amount > actual_cost:
    kount = sale_amount - actual_cost
    return kount
  else:
    return 0