import math

def sector_area(n, m):
    if m > 360:
        return None
    return (math.pi * n ** 2) * (m / 360)