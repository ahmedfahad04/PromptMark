def largest_subset(a):
	count = len(a)
	dp = [0 for i in range(count)]
	dp[count - 1] = 1
	for i in range(count - 2, -1, -1):
		max_val = 0
		for j in range(i + 1, count):
			if a[j] % a[i] == 0 or a[i] % a[j] == 0:
				max_val = max(max_val, dp[j])
		dp[i] = 1 + max_val
	return max(dp)