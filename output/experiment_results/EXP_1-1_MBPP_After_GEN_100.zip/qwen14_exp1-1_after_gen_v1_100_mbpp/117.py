def list_to_float(test_list):
  output = []
  for tup in test_list:
    temp = []
    for ele in tup:
      if ele.isalpha():
        temp.append(ele)
      else:
        temp.append(float(ele))
    output.append((temp[0], temp[1])) 
  return output