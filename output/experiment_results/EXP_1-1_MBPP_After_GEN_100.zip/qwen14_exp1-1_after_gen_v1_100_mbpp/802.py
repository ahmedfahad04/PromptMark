def count_rotation(arr):   
    for index in range(1, len(arr)): 
        if arr[index] < arr[index - 1]: 
            return index  
    return 0

assert count_rotation([3,2,1]) == 1
assert count_rotation([4,5,1,2,3]) == 2
assert count_rotation([7,8,9,1,2,3]) == 3
assert count_rotation([1,2,3]) == 0
assert count_rotation([1,3,2]) == 2