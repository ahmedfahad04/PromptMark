def interleave_lists(var1, var2, var3):
    outcome = [item for pair in zip(var1, var2, var3) for item in pair]
    return outcome