def move_num(test_str):
  output = ''
  num = ''
  for char in test_str:
    if char.isdigit():
      num += char
    else:
      output += char
  output += num
  return output