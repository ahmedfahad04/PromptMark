def odd_num_sum(n):
    k = 0
    sum_val = 0
    for m in range(1, n + 1):
        k = (2 * m - 1)
        sum_val += (k * k * k * k)
    return sum_val