def find_even_pair(A): 
  count = 0
  for index_n in range(0, len(A)): 
    for index_c in range(index_n + 1, len(A)): 
        if ((A[index_n] ^ A[index_c]) % 2 == 0): 
          count += 1

  return count