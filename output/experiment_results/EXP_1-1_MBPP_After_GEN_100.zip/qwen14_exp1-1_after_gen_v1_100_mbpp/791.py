def remove_nested(test_tup):
    outcome = ()
    for index, item in enumerate(test_tup):
        if not isinstance(item, tuple):
            outcome = outcome + (item,)
    return outcome