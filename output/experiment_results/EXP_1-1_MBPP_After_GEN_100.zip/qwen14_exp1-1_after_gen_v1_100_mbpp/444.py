def trim_tuple(test_list, k):
    output = []
    for item in test_list:
        n = len(item)
        output.append(tuple(list(item)[k: n - k]))
    return str(output)