def even_Power_Sum(n): 
    total_sum = 0
    for index in range(1, n + 1): 
        power_val = 2 * index
        total_sum += power_val ** 5
    return total_sum

# Test Cases
assert even_Power_Sum(2) == 1056
assert even_Power_Sum(3) == 8832
assert even_Power_Sum(1) == 32