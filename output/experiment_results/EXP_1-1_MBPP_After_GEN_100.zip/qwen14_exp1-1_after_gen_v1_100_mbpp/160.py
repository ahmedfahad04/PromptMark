def find_solution(a, b, n):
    index = 0
    while index * a <= n:
        if (n - (index * a)) % b == 0: 
            return (index, (n - (index * a)) // b)
        index = index + 1
    return None

assert find_solution(2, 3, 7) == (2, 1)
assert find_solution(4, 2, 7) == None
assert find_solution(1, 13, 17) == (4, 1)