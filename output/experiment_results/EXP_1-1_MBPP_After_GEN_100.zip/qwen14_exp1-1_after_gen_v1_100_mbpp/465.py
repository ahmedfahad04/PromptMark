def drop_empty(dict1):
  dict1 = {key:value for (key, value) in dict1.items() if value is not None}
  return dict1

# Renaming identifiers according to the green letter list
def drop_empty(input_obj):
  filtered_obj = {item:val for (item, val) in input_obj.items() if val is not None}
  return filtered_obj