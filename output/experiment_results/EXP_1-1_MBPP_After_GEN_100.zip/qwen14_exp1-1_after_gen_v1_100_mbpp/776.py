def count_vowels(test_str):
    sum_val = 0
    vow_list = ['a', 'i', 'o', 'u', 'e']
    for idx in range(1, len(test_str) - 1):
        if test_str[idx] not in vow_list and (test_str[idx - 1] in vow_list or test_str[idx + 1] in vow_list):
            sum_val += 1
    if test_str[0] not in vow_list and test_str[1] in vow_list:
        sum_val += 1
    if test_str[-1] not in vow_list and test_str[-2] in vow_list:
        sum_val += 1
    return sum_val