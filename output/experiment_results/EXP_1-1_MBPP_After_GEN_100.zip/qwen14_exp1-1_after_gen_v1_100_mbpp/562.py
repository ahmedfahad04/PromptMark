def Find_Max_Length(var_lst):  
    max_count = max(len(item) for item in var_lst)
    return max_count

assert Find_Max_Length([[1],[1,4],[5,6,7,8]]) == 4
assert Find_Max_Length([[0,1],[2,2],[3,2,1]]) == 3
assert Find_Max_Length([[7],[22,23],[13,14,15],[10,20,30,40,50]]) == 5