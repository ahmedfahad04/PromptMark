import re
def remove_lowercase(str1):
    return re.sub('[a-z]', '', str1)

# Refactored code with renamed identifiers
def remove_lowercase(input_str):
    return re.sub('[a-z]', '', input_str)