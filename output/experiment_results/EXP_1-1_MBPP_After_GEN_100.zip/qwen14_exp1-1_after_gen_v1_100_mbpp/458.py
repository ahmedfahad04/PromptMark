def rectangle_area(o, k):
    area = o * k
    return area

assert rectangle_area(10, 20) == 200
assert rectangle_area(10, 5) == 50
assert rectangle_area(4, 2) == 8