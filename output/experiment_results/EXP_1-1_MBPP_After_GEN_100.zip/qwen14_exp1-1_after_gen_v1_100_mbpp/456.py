def reverse_string_list(wordlist):
    answer = [x[::-1] for x in wordlist]
    return answer