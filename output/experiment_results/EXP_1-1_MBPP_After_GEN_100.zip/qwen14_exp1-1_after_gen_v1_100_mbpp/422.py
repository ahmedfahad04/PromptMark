def find_average_of_cube(n):
    sum_val = 0
    for idx in range(1, n + 1):
        sum_val += idx * idx * idx
    return round(sum_val / n, 6)