def insert_item(var, element):
    var = [v for elt in var for v in (element, elt)]
    return var

# Test Cases
assert insert_item(['Red', 'Green', 'Black'], 'c') == ['c', 'Red', 'c', 'Green', 'c', 'Black']
assert insert_item(['python', 'java'], 'program') == ['program', 'python', 'program', 'java']
assert insert_item(['happy', 'sad'], 'laugh') == ['laugh', 'happy', 'laugh', 'sad']