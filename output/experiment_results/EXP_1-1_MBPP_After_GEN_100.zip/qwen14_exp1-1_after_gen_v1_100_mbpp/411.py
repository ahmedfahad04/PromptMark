import re
def snake_to_camel(word):
  return ''.join(k.capitalize() or '_' for k in word.split('_'))

# Test Cases
assert snake_to_camel('android_tv') == 'AndroidTv'
assert snake_to_camel('google_pixel') == 'GooglePixel'
assert snake_to_camel('apple_watch') == 'AppleWatch'