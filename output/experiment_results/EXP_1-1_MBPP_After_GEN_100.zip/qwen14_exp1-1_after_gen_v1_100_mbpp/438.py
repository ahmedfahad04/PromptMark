def count_bidirectional(test_list):
    sum_val = 0
    for idx in range(0, len(test_list)):
        for iidx in range(idx + 1, len(test_list)):
            if test_list[iidx][0] == test_list[idx][1] and test_list[idx][1] == test_list[iidx][0]:
                sum_val += 1
    return sum_val