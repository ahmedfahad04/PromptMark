def group_tuples(input_data):
    out = {}
    for item in input_data:
        try:
            out[item[0]].extend(item[1:])
        except KeyError:
            out[item[0]] = list(item)
    return [tuple(values) for values in out.values()]