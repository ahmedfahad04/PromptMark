NO_OF_CHARS = 256

def str_to_list(word):
    temp = []
    for char in word:
        temp.append(char)
    return temp

def lst_to_string(List):
    return ''.join(List)

def get_char_count_array(text):
    count = [0] * NO_OF_CHARS
    for i in text:
        count[ord(i)] += 1
    return count

def remove_dirty_chars(word, dirty_word):
    count = get_char_count_array(dirty_word)
    ip_index = 0
    res_index = 0
    temp = ''
    word_list = str_to_list(word)
    while ip_index != len(word_list):
        temp = word_list[ip_index]
        if count[ord(temp)] == 0:
            word_list[res_index] = word_list[ip_index]
            res_index += 1
        ip_index += 1
    return lst_to_string(word_list[0:res_index])

# Test Cases
assert remove_dirty_chars("probasscurve", "pros") == 'bacuve'
assert remove_dirty_chars("digitalindia", "talent") == 'digiidi'
assert remove_dirty_chars("exoticmiles", "toxic") == 'emles'