def rotate_right(word, m):
  index = word[-m:] + word[:-m]
  return index