def power(na, nb):
    if nb == 0:
        return 1
    elif na == 0:
        return 0
    elif nb == 1:
        return na
    else:
        return na * power(na, nb - 1)

assert power(3, 4) == 81
assert power(2, 3) == 8
assert power(5, 5) == 3125