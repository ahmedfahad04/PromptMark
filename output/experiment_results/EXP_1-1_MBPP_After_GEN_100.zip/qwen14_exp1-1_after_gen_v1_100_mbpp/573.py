def unique_product(list_data):
    var_set = list(set(list_data))
    prod = 1
    for item in var_set:
        prod *= item
    return prod