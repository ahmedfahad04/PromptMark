import re

def find_adverbs(text):
    for match in re.finditer(r"\w+ly", text):
        return '%d-%d: %s' % (match.start(), match.end(), match.group(0))