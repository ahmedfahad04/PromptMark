def list_tuple(varx):
  tupley = tuple(varx)
  return tupley