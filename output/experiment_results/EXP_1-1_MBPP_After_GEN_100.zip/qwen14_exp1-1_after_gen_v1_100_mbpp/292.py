def seek(n, m):
    quo = n // m
    return quo

# Test Cases
assert seek(10, 3) == 3
assert seek(4, 2) == 2
assert seek(20, 5) == 4