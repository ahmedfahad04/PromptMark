def comb_sort(items):
    shrink_fact = 1.3
    gap = len(items)
    swapped = True
    index = 0
    while gap > 1 or swapped:
        gap = int(float(gap) / shrink_fact)
        swapped = False
        index = 0
        while gap + index < len(items):
            if items[index] > items[index + gap]:
                items[index], items[index + gap] = items[index + gap], items[index]
                swapped = True
            index += 1
    return items