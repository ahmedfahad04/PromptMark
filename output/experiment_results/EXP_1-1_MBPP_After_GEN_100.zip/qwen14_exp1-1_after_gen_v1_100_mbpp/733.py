def find_first_occurrence(A, x):
    (left, right) = (0, len(A) - 1)
    outcome = -1
    while left <= right:
        mid = (left + right) // 2
        if x == A[mid]:
            outcome = mid
            right = mid - 1
        elif x < A[mid]:
            right = mid - 1
        else:
            left = mid + 1
    return outcome