def count_X(tup, x): 
    kount = 0
    for item in tup: 
        if (item == x): 
            kount = kount + 1
    return kount 

##Test Cases:
assert count_X((10, 8, 5, 2, 10, 15, 10, 8, 5, 8, 8, 2),4) == 0
assert count_X((10, 8, 5, 2, 10, 15, 10, 8, 5, 8, 8, 2),10) == 3
assert count_X((10, 8, 5, 2, 10, 15, 10, 8, 5, 8, 8, 2),8) == 4