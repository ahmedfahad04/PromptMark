def square_sum(var):
    return int(var * (4 * var * var - 1) / 3)

assert square_sum(2) == 10
assert square_sum(3) == 35
assert square_sum(4) == 84