import re

def start_withp(items):
    for item in items:
        match = re.match("(P\w+)\W(P\w+)", item)
        if match:
            return match.groups()