def set_middle_bits(num):  
    num |= num >> 1; 
    num |= num >> 2; 
    num |= num >> 4; 
    num |= num >> 8; 
    num |= num >> 16;  
    return (num >> 1) ^ 1

def toggle_middle_bits(num): 
    if (num == 1): 
        return 1
    return num ^ set_middle_bits(num) 

# Test Cases
assert toggle_middle_bits(9) == 15
assert toggle_middle_bits(10) == 12
assert toggle_middle_bits(11) == 13
assert toggle_middle_bits(0b1000001) == 0b1111111
assert toggle_middle_bits(0b1001101) == 0b1110011