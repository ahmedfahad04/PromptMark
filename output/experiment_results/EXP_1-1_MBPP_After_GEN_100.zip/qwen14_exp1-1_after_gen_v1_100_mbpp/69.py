def is_sublist(input_list, search_list):
    sub_set = False
    if search_list == []:
        sub_set = True
    elif search_list == input_list:
        sub_set = True
    elif len(search_list) > len(input_list):
        sub_set = False
    else:
        for index in range(len(input_list)):
            if input_list[index] == search_list[0]:
                n = 1
                while (n < len(search_list)) and (input_list[index + n] == search_list[n]):
                    n += 1
                if n == len(search_list):
                    sub_set = True
    return sub_set