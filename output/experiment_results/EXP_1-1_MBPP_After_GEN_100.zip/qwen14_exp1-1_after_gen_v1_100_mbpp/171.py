import math

def perimeter_pentagon(side):
    circum = (5 * side)
    return circum

# Test Cases
assert perimeter_pentagon(5) == 25
assert perimeter_pentagon(10) == 50
assert perimeter_pentagon(15) == 75