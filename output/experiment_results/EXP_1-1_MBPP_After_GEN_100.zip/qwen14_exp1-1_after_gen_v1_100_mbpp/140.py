def extract_singly(test_list):
    output = []
    seen = set()
    for inner in test_list:
        for item in inner:
            if item not in seen:
                seen.add(item)
                output.append(item)
    return output