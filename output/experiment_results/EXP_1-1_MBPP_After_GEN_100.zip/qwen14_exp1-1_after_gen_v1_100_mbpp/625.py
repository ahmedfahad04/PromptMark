def swap_List(var_list): 
    count = len(var_list) 
    temp_var = var_list[0] 
    var_list[0] = var_list[count - 1] 
    var_list[count - 1] = temp_var   
    return var_list