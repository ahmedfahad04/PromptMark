def pair_wise(l1):
    items = []
    for k in range(len(l1) - 1):
        curr_elem, next_elem = l1[k], l1[k + 1]
        x = (curr_elem, next_elem)
        items.append(x)
    return items