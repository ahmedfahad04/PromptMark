def test_three_equal(x, y, z):
    value = set([x, y, z])
    if len(value) == 3:
        return 0
    else:
        return 4 - len(value)