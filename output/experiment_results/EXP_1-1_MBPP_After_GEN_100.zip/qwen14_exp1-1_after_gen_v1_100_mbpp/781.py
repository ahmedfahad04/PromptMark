import math

def count_divisors(n):
    sum_val = 0
    for i in range(1, int(math.sqrt(n)) + 2):
        if n % i == 0:
            if n // i == i:
                sum_val += 1
            else:
                sum_val += 2
    return sum_val % 2 == 0