import re

def text_match_wordz(text):
        patternz = '\w*z.\w*'
        if re.search(patternz, text):
                return True
        else:
                return False