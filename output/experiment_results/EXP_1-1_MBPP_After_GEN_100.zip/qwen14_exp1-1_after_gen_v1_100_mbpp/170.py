def sum_range_list(var1, var2, var3):
    sum_val = 0
    for index in range(var2, var3 + 1, 1):
        sum_val += var1[index]
    return sum_val

assert sum_range_list([2,1,5,6,8,3,4,9,10,11,8,12], 8, 10) == 29
assert sum_range_list([2,1,5,6,8,3,4,9,10,11,8,12], 5, 7) == 16
assert sum_range_list([2,1,5,6,8,3,4,9,10,11,8,12], 7, 10) == 38