def verify_item(collection, item_to_verify):
    verification = all(v == item_to_verify for v in collection)
    return verification

# Test Cases
assert verify_item(["green", "orange", "black", "white"], 'blue') == False
assert verify_item([1, 2, 3, 4], 7) == False
assert verify_item(["green", "green", "green", "green"], 'green') == True