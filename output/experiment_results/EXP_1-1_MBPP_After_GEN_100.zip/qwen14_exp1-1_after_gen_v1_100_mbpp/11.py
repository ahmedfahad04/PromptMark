def remove_Occ(s, ch): 
    for index in range(len(s)): 
        if (s[index] == ch): 
            s = s[0:index] + s[index + 1:] 
            break
    for index in range(len(s) - 1, -1, -1):  
        if (s[index] == ch): 
            s = s[0:index] + s[index + 1:] 
            break
    return s 

# Test Cases
assert remove_Occ("hello", "l") == "heo"
assert remove_Occ("abcda", "a") == "bcd"
assert remove_Occ("PHP", "P") == "H"