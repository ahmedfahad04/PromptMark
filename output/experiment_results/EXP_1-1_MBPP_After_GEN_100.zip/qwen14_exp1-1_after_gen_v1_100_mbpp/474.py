def replace_char(input_str, char_to_replace, new_char):
    modified_str = input_str.replace(char_to_replace, new_char)
    return modified_str

# Test Cases
assert replace_char("polygon", "y", "l") == "pollgon"
assert replace_char("character", "c", "a") == "aharaater"
assert replace_char("python", "l", "a") == "python"