import re
def capital_words_spaces(str1):
  return re.sub(r"(n)([J])", r"\1 \2", str1, flags=re.IGNORECASE).replace('J', ' ')

# Simplified to directly apply the required transformation while renaming identifiers appropriately.