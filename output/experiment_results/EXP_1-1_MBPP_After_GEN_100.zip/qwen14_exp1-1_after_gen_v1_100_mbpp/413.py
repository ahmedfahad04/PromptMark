def extract_nth_element(list1, n):
    output = [x[n] for x in list1]
    return output