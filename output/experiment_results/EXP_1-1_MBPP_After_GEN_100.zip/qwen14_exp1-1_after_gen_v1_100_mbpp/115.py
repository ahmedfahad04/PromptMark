def empty_kit(list1):
    kit_is_empty = all(not k for k in list1)
    return kit_is_empty