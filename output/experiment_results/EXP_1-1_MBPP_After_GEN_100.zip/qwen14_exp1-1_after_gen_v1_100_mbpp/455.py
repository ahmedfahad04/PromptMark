def check_monthnumb_number(monthnum2):
  if(monthnum2 == 1 or monthnum2 == 3 or monthnum2 == 5 or monthnum2 == 7 or monthnum2 == 8 or monthnum2 == 10 or monthnum2 == 12):
    return True
  else:
    return False

# Test Cases
assert check_monthnumb_number(5) == True
assert check_monthnumb_number(2) == False
assert check_monthnumb_number(6) == False