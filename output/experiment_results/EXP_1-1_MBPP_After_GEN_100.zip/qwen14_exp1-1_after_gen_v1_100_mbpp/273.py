def substract_elements(kwan, yvi):
    sumo = tuple(map(lambda i, j: i - j, kwan, yvi))
    return sumo

# Test Cases
assert substract_elements((10, 4, 5), (2, 5, 18)) == (8, -1, -13)
assert substract_elements((11, 2, 3), (24, 45, 16)) == (-13, -43, -13)
assert substract_elements((7, 18, 9), (10, 11, 12)) == (-3, 7, -3)