def extract_string(var_str, length):
    answer = [item for item in var_str if len(item) == length]
    return answer