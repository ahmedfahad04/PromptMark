def sequence(n): 
	if n == 1 or n == 2: 
		return 1
	else: 
		return sequence(sequence(n - k)) + sequence(n - sequence(n - k))