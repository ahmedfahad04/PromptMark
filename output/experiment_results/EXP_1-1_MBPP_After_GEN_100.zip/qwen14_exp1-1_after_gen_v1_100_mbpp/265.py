def list_split(input_s, step_size):
    return [input_s[i::step_size] for i in range(step_size)]