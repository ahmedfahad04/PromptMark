def find_first_missing(sequence, start=0, end=None):
    if end is None:
        end = len(sequence) - 1
    if start > end:
        return end + 1
    if start != sequence[start]:
        return start
    mid = int((start + end) / 2)
    if sequence[mid] == mid:
        return find_first_missing(sequence, mid + 1, end)
    return find_first_missing(sequence, start, mid)