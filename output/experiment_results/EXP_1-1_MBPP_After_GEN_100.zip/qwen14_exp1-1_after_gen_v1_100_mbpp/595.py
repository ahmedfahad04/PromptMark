def min_swaps(sia, sib):
    swap_count = 0
    for idx in range(len(sia)):
        if sia[idx] != sib[idx]:
            swap_count += 1
    if swap_count % 2 == 0:
        return swap_count // 2
    else:
        return "Not Possible"

assert min_swaps("1101", "1110") == 1
assert min_swaps("111", "000") == "Not Possible"
assert min_swaps("111", "110") == "Not Possible"