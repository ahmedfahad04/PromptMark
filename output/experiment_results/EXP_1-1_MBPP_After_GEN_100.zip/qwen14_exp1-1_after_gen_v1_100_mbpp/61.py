from collections import defaultdict

def count_Substrings(s):
    k = len(s)
    count, sum = 0, 0
    mp = defaultdict(lambda: 0)
    mp[0] += 1
    for i in range(k):
        sum += ord(s[i]) - ord('0')
        count += mp[sum - (i + 1)]
        mp[sum - (i + 1)] += 1
    return count