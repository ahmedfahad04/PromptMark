def sum_list(var1, var2):
  sum_list = [var1[i] + var2[i] for i in range(len(var1))]
  return sum_list

assert sum_list([10,20,30],[15,25,35]) == [25,45,65]
assert sum_list([1,2,3],[5,6,7]) == [6,8,10]
assert sum_list([15,20,30],[15,45,75]) == [30,65,105]