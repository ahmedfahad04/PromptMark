def is_perfect_square(n) :
    k = 1
    while (k * k <= n):
        if ((n % k == 0) and (n / k == k)):
            return True     
        k = k + 1
    return False

assert not is_perfect_square(10)
assert is_perfect_square(36)
assert not is_perfect_square(14)
assert is_perfect_square(14*14)
assert not is_perfect_square(125)
assert is_perfect_square(125*125)