def find_item(arr, intervals, turns, idx):
    for i in range(turns - 1, -1, -1):
        start = intervals[i][0]
        end = intervals[i][1]
        if (start <= idx and end >= idx):
            if (idx == start):
                idx = end
            else:
                idx = idx - 1
    return arr[idx]