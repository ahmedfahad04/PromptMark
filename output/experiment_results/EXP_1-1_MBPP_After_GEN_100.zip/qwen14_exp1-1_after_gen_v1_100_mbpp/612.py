def merge(input_lst):
    return [list(item) for item in list(zip(*input_lst))]