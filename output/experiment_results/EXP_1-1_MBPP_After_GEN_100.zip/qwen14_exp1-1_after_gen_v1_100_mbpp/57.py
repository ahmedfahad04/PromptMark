def find_Max_Num(arr) :
    count = len(arr)
    arr.sort(reverse=True)
    value = arr[0]
    for index in range(1, count):
        value = value * 10 + arr[index]
    return value