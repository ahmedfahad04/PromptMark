def surface_area(b, s): 
    return 2 * b * s + pow(b, 2)

assert surface_area(3, 4) == 33
assert surface_area(4, 5) == 56
assert surface_area(1, 2) == 5