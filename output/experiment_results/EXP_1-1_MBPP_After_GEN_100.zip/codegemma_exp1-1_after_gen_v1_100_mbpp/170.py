def sum_range_list(list1, start_index, end_index):
    """
    This function calculates the sum of elements in a list within a specified range.
    """
    sum_range = 0
    for i in range(start_index, end_index + 1):
        sum_range += list1[i]
    return sum_range