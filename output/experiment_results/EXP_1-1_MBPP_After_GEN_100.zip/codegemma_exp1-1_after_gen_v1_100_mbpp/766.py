def pair_wise(l1):
    temp_var = []
    for index in range(len(l1) - 1):
        current_element, next_element = l1[index], l1[index + 1]
        x = (current_element, next_element)
        temp_var.append(x)
    return temp_var