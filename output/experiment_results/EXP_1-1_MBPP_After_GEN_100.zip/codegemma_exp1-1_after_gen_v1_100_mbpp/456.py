def reverse_string_list(str_list):
    """
    Reverses a list of strings in place.
    """
    for i, s in enumerate(str_list):
        str_list[i] = s[::-1]
    return str_list