import math
def rightangle_hypotenuse(width,height):
  """
  Calculates the hypotenuse of a right-angled triangle given the width and height.
  """
  hypotenuse = math.sqrt((width**2) + (height**2))
  return hypotenuse