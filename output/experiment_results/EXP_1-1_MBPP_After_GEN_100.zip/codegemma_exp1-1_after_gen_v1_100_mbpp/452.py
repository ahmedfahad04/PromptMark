def loss_amount(cost,revenue): 
  if(revenue > cost):
    loss = revenue - cost
    return loss
  else:
    return 0