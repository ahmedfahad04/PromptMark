def extract_string(str, l):
    """
    This function extracts words of a given length from a list of strings.
    """
    result = [e for e in str if len(e) == l] 
    return result