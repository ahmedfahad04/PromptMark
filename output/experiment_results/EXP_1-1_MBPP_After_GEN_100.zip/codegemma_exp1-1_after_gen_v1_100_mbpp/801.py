def test_three_equal(item1,item2,item3):
  unique_items = set([item1,item2,item3])
  if len(unique_items)==3:
    return 0
  else:
    return 4-len(unique_items)