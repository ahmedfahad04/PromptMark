import re

def start_withp(names):
    for name in names:
        match = re.match(r'(P\w+)\W+(P\w+)', name)
        if match:
            return match.groups()