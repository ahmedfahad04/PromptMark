def average_tuple(nums):
    """
    Calculates the average of each tuple in a list of tuples.
    """
    result = [sum(x) / len(x) for x in zip(*nums)]
    return result