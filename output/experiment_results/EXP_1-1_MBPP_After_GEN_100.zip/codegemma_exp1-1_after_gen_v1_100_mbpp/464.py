def all_values_match(dict, n):
    """
    Checks if all values in a dictionary match a given value.
    """
    all_values_match = all(x == n for x in dict.values())
    return all_values_match