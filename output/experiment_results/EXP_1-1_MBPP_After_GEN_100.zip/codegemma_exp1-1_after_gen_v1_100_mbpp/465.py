def drop_empty(input_dict):
  output_dict = {key:value for (key, value) in input_dict.items() if value is not None}
  return output_dict