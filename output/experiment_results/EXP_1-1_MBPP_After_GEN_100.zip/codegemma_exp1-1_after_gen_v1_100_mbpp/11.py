def remove_ch(text, ch):
    """
    This function removes the first occurrence of a character from a string.
    """
    for i in range(len(text)):
        if text[i] == ch:
            text = text[:i] + text[i + 1:]
            break
    for i in range(len(text) - 1, -1, -1):
        if text[i] == ch:
            text = text[:i] + text[i + 1:]
            break
    return text