def list_split(var1, var2):
    return [var1[i::var2] for i in range(var2)]