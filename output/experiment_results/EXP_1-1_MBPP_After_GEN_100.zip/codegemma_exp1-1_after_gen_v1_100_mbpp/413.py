def extract_nth_element(list1, n):
    """
    This function takes a list of tuples and an index as input and returns a list of the elements at the given index from each tuple in the list.
    """
    result = [x[n] for x in list1]
    return result