def count_occurrences(tuple_in, value):
    """
    Counts the number of occurrences of a specific value in a tuple.

    Args:
    tuple_in: The input tuple.
    value: The value to count occurrences of.

    Returns:
    The number of occurrences of the value in the tuple.
    """
    count = 0
    for item in tuple_in:
        if item == value:
            count += 1
    return count