def max_product(arr):   
  n = len(arr)
  max_product_so_far = arr[:]
  for i in range(n): 
    current_product = arr[i]
    j = i + 1
    while j < n:
      if arr[j-1] > arr[j]: 
        break
      current_product *= arr[j]
      if current_product > max_product_so_far[j]:
        max_product_so_far[j] = current_product 
      j = j + 1
  return max(max_product_so_far)