def sum_of_squares(num):  
    return int(num*(4*num*num-1)/3) 

assert sum_of_squares(2) == 10
assert sum_of_squares(3) == 35
assert sum_of_squares(4) == 84