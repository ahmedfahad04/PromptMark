def check_element(list, element):
  all_match = all(v == element for v in list)
  return all_match