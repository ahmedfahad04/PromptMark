import math
def pentagon_perimeter(side):
  perimeter = 5 * side
  return perimeter

assert pentagon_perimeter(5) == 25
assert pentagon_perimeter(10) == 50
assert pentagon_perimeter(15) == 75