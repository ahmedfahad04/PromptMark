import re

def remove_lowercase(str1):
  """
  This function removes all lowercase letters from a string.
  """
  return re.sub('[a-z]', '', str1)