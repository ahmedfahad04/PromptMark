import re
def count_substring(text, pattern):
    for match in re.finditer(pattern, text):
        start = match.start()
        end = match.end()
        return (text[start:end], start, end)