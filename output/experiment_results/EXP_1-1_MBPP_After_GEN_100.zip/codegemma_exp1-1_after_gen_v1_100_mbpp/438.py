def count_bidirectional(test_list):
  """
  Counts the number of bidirectional pairs in a list of tuples.
  """
  count = 0
  for idx in range(len(test_list)):
    for iidx in range(idx + 1, len(test_list)):
      if test_list[idx][1] == test_list[iidx][0] and test_list[iidx][0] == test_list[idx][1]:
        count += 1
  return count