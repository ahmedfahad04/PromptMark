def mean_num(nums):  
    """
    Calculates the mean of a list of numbers.
    """
    total = 1
    for num in nums:
        total *= num  
    return total/len(nums)