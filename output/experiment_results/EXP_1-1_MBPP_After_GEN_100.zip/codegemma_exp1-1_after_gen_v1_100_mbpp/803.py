def is_perfect_square(n):
    """
    This function checks if a number is a perfect square or not.
    """
    i = 1
    while (i * i <= n):
        if ((n % i == 0) and (n / i == i)):
            return True
        i = i + 1
    return False