def tuple_from_list(listx):
  tuplex = tuple(listx)
  return tuplex

assert tuple_from_list([5, 10, 7, 4, 15, 3])==(5, 10, 7, 4, 15, 3)
assert tuple_from_list([2, 4, 5, 6, 2, 3, 4, 4, 7])==(2, 4, 5, 6, 2, 3, 4, 4, 7)
assert tuple_from_list([58,44,56])==(58,44,56)