def group_tuples(Input):
    out = {}
    for key, *values in Input:
        try:
            out[key].extend(values)
        except KeyError:
            out[key] = list(values)
    return [tuple(values) for values in out.values()]