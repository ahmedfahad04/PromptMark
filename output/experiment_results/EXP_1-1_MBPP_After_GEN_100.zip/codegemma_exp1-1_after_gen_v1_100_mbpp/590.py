import cmath

def polar_rect(var1,var2):
    obj = complex(var1,var2)
    obj = cmath.polar(obj)
    obj1 = cmath.rect(2, cmath.pi)
    return (obj,obj1)