def two_unique_nums(nums):
  """
  This function takes a list of numbers and returns a list of the two unique numbers in the list.
  """
  unique_nums = [i for i in nums if nums.count(i) == 1]
  return unique_nums