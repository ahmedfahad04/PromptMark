import re

def extract_quotation(text1):
  """
  Extracts quoted strings from a given text.
  """
  return (re.findall(r'"(.*?)"', text1))