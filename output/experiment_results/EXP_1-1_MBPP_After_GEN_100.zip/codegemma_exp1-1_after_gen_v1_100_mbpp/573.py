def unique_product(list_data):
    """
    This function calculates the product of all unique elements in a list.
    """
    temp = list(set(list_data))
    product = 1
    for item in temp:
        product *= item
    return product