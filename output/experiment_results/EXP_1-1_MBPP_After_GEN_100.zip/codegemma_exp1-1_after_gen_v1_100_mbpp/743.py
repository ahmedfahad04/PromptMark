def rotate_right(list, m):
  """
  Rotate a list of elements to the right by m steps.
  """
  if m == len(list):
    return list
  if m > len(list):
    m = m % len(list)
  return list[-m:] + list[:-m]