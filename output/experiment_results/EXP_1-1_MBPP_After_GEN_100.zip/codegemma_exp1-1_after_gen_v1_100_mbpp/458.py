def area_of_rectangle(length,breadth):
  area = length * breadth
  return area

assert area_of_rectangle(10,20)==200
assert area_of_rectangle(10,5)==50
assert area_of_rectangle(4,2)==8