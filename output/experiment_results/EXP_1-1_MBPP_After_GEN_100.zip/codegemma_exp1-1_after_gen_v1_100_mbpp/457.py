def min_by_length(lst):
    return min(lst, key=len)

assert min_by_length([[1],[1,2],[1,2,3]]) == [1]
assert min_by_length([[1,1],[1,1,1],[1,2,7,8]]) == [1,1]
assert min_by_length([['x'],['x','y'],['x','y','z']]) == ['x']