def str_to_tuple(str1):
    """
    Converts a string to a tuple of non-whitespace characters.
    """
    result = tuple(x for x in str1 if not x.isspace())
    return result

assert str_to_tuple("python 3.0")==('p', 'y', 't', 'h', 'o', 'n', '3', '.', '0')
assert str_to_tuple("item1")==('i', 't', 'e', 'm', '1')
assert str_to_tuple("15.10")==('1', '5', '.', '1', '0')