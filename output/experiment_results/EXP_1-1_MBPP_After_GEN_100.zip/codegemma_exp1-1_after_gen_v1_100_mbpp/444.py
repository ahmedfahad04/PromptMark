def trim_tuple(test_list, K):
  """
  This function trims a tuple from Kth element to (N-K)th element
  """
  res = []
  for ele in test_list:
    N = len(ele)
    res.append(tuple(list(ele)[K: N - K]))
  return (str(res))