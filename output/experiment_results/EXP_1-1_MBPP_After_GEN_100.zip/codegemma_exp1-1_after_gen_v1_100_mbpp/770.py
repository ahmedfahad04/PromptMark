def sum_of_odd_cubes(num):
    """
    This function calculates the sum of the cubes of the first n odd natural numbers.
    """
    odd_num_count = 0
    sum_of_cubes = 0
    for i in range(1, num + 1):
        odd_num_count = (2 * i - 1)
        sum_of_cubes = sum_of_cubes + (odd_num_count ** 4)
    return sum_of_cubes