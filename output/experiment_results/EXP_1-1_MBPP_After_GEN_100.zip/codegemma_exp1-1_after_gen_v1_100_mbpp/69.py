def is_sublist(list_in, sublist):
    """
    Checks if a sublist is a sublist of a list.
    """
    if sublist == []:
        return True
    elif sublist == list_in:
        return True
    elif len(sublist) > len(list_in):
        return False
    else:
        for i in range(len(list_in)):
            if list_in[i] == sublist[0]:
                n = 1
                while (n < len(sublist)) and (list_in[i+n] == sublist[n]):
                    n += 1
                if n == len(sublist):
                    return True
    return False