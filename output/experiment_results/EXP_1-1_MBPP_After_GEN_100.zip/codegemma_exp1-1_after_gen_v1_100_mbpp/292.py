def find(input, divisor):  
    quotient = input // divisor 
    return (quotient)