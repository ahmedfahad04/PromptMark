import re

def is_valid_identifier(text):
    """
    Checks if a string is a valid identifier in python
    """
    patterns = '^[a-z]+_[a-z]+$'
    if re.search(patterns,  text):
        return True
    else:
        return False

print(is_valid_identifier("hello_world"))  # True
print(is_valid_identifier("Hello_World"))  # False
print(is_valid_identifier("helloWorld"))    # False