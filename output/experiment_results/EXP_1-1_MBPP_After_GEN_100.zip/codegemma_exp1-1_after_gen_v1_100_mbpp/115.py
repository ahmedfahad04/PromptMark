def is_dict_empty(list1):
  is_dict_empty = all(not d for d in list1)
  return is_dict_empty