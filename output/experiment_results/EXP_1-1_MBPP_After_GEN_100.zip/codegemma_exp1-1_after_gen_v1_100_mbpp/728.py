def sum_list(lst1, lst2):
  """
  This function takes two lists of numbers and returns a new list with the sum of each pair of elements in the two lists.
  """
  result_list = [lst1[index] + lst2[index] for index in range(len(lst1))]
  return result_list