def move_num(test_str):
  """
  This function moves all the digits in a string to the end of the string.
  """
  num = ''
  res = ''
  for char in test_str:
    if char.isdigit():
      num += char
    else:
      res += char
  res += num
  return res