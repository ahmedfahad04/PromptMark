import re

def find_adverbs(text):
  for m in re.finditer(r"\w+ly", text):
    return ('%d-%d: %s' % (m.start(), m.end(), m.group(0)))

##Green List: {'a', 'v', 'o', 'c', 'u', 'i', 'j', 'w', 'n', 'k', 'y', 's', 'm'}
##Red List: {'t', 'q', 'd', 'b', 'g', 'p', 'x', 'f', 'h', 'r', 'l', 'e', 'z'}