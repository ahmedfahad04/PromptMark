def extract_singly(test_list):
  """
  This function extracts unique elements from a list of lists.
  """
  unique_elements = set()
  result = []
  for sublist in test_list:
    for element in sublist:
      if element not in unique_elements:
        unique_elements.add(element)
        result.append(element)
  return result