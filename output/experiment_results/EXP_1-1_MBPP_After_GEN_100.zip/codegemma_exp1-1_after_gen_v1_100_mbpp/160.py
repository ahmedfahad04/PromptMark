def find_solution(a, b, n):
    """
    This function finds a solution to the equation ax + b = n.
    """
    for i in range(n // a + 1):
        if (n - (i * a)) % b == 0:
            return (i, (n - (i * a)) // b)
    return None