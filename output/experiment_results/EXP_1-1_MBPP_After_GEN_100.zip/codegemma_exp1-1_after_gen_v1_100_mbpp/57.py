def find_max_num(arr):
    n = len(arr)
    arr.sort(reverse=True)
    max_num = arr[0]
    for i in range(1, n):
        max_num = max_num * 10 + arr[i]
    return max_num