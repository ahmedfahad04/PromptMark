def remove_nested(test_tup):
  res = tuple()
  for count, item in enumerate(test_tup):
    if not isinstance(item, tuple):
      res = res + (item, )
  return (res)