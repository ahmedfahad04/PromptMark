def insert_element(item_list,item):
  item_list = [item for elt in item_list for item in (item, elt)]
  return item_list