def swap_List(item_list):
    item_count = len(item_list)
    item_list_key = item_list[item_count - 1]
    item_list[item_count - 1] = item_list[0]
    item_list[0] = item_list_key
    return item_list