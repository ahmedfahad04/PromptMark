def surface_area(length, width):
    """
    Calculates the surface area of a cuboid.
    """
    return 2 * length * width + length ** 2