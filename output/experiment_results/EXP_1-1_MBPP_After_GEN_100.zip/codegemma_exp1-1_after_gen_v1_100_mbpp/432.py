def median_trapezium(base1, base2, height):
    """
    This function calculates the area of a trapezoid.
    """
    area = 0.5 * (base1 + base2) * height
    return area

assert median_trapezium(15, 25, 35) == 20
assert median_trapezium(10, 20, 30) == 15
assert median_trapezium(6, 9, 4) == 7.5