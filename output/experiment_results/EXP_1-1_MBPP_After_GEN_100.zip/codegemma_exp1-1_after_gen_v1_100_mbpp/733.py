def find_first_occurrence(nums, target):
    """
    Finds the first occurrence of a target value in a sorted array.

    Args:
      nums: A sorted array of integers.
      target: The value to search for.

    Returns:
      The index of the first occurrence of the target value, or -1 if not found.
    """

    left, right = 0, len(nums) - 1
    result = -1

    while left <= right:
        mid = (left + right) // 2
        if nums[mid] == target:
            result = mid
            right = mid - 1
        elif nums[mid] < target:
            left = mid + 1
        else:
            right = mid - 1

    return result