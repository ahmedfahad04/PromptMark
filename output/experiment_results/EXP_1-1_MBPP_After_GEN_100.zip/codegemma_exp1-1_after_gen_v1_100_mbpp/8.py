def square_nums(nums):
    """
    This function squares each number in a list of numbers and returns a new list of squared numbers.
    """
    squared_nums = list(map(lambda x: x ** 2, nums))
    return squared_nums