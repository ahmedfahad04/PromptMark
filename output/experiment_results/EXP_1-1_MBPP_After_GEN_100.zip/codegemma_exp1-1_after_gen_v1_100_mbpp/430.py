def parabola_directrix(var1, var2, var3): 
  temp_var=((int)(var3 - ((var2 * var2) + 1) * 4 * var1 ))
  return temp_var

assert parabola_directrix(5,3,2)==-198
assert parabola_directrix(9,8,4)==-2336
assert parabola_directrix(2,4,6)==-130