def even_power_sum(n):
    """
    This function calculates the sum of the fifth powers of all even numbers from 1 to n.
    """
    sum = 0
    for i in range(1, n + 1):
        j = 2 * i
        sum += j ** 5
    return sum

assert even_power_sum(2) == 1056
assert even_power_sum(3) == 8832
assert even_power_sum(1) == 32