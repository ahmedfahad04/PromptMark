def find_max_length(lst):  
    max_length = max(len(x) for x in lst )
    return max_length