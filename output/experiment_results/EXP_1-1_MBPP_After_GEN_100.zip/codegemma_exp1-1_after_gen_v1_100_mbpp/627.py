def find_first_missing(arr, start=0, end=None):
    if end is None:
        end = len(arr) - 1
    if start > end:
        return end + 1
    if start != arr[start]:
        return start
    mid = int((start + end) / 2)
    if arr[mid] == mid:
        return find_first_missing(arr, mid + 1, end)
    return find_first_missing(arr, start, mid)