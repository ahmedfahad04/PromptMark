def find_lucas(index): 
	if (index == 0): 
		return 2
	if (index == 1): 
		return 1
	return find_lucas(index - 1) + find_lucas(index - 2)