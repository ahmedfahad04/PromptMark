from operator import eq

def count_same_pair(nums1, nums2):
    count = sum(map(eq, nums1, nums2))
    return count