import re
def remove_whitespaces(text1):
  return (re.sub(r'\s+', '',text1))

##Test Cases:
assert remove_whitespaces(' Google    Flutter ') == 'GoogleFlutter'
assert remove_whitespaces(' Google    Dart ') == 'GoogleDart'
assert remove_whitespaces(' iOS    Swift ') == 'iOSSwift'