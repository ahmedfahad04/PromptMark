def is_month_with_thirty_one_days(monthnum):
  """
  Checks if a month has thirty-one days.

  Args:
    monthnum: The number of the month (1-12).

  Returns:
    True if the month has thirty-one days, False otherwise.
  """
  thirty_one_days = {1, 3, 5, 7, 8, 10, 12}
  return monthnum in thirty_one_days