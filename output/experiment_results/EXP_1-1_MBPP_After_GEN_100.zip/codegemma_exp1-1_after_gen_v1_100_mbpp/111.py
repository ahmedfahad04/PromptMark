def common_in_nested_lists(nestedlist):
    """
    This function takes a nested list of lists and returns a set of common elements in all the sublists.
    """
    common_elements = set.intersection(*map(set, nestedlist))
    return common_elements