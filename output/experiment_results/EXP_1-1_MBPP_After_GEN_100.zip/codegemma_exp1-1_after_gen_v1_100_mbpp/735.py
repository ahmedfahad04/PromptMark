def set_middle_bits(value):  
    value |= value >> 1; 
    value |= value >> 2; 
    value |= value >> 4; 
    value |= value >> 8; 
    value |= value >> 16;  
    return (value >> 1) ^ 1

def toggle_middle_bits(value): 
    if (value == 1): 
        return 1
    return value ^ set_middle_bits(value)