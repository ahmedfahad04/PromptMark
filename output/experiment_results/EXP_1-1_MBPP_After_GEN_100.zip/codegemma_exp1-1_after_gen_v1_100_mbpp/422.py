def find_Average_Of_Cube(var):  
    sum = 0
    for item in range(1, var + 1): 
        sum += item * item * item  
    return round(sum / var, 6)