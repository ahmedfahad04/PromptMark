def interleave_lists(list1, list2, list3):
    """
    Interleaves three lists into a single list.
    """
    result = [el for pair in zip(list1, list2, list3) for el in pair]
    return result