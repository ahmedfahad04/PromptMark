def rear_extract(test_list):
  """
  This function extracts the last element from each tuple in a list of tuples.
  """
  result = [item[-1] for item in test_list]
  return result