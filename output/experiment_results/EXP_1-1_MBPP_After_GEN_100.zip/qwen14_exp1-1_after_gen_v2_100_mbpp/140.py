def extract_singly(test_list):
    count = []
    seen = set()
    for inner in test_list:
        for item in inner:
            if item not in seen:
                seen.add(item)
                count.append(item)
    return count