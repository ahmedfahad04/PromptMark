import re
def text_lowercase_underscore(word):
        patterns = '^[a-z]+_[a-z]+$'
        if re.search(patterns,  word):
                return True
        else:
                return False

# Test Cases
assert text_lowercase_underscore("aab_cbbbc") == True
assert text_lowercase_underscore("aab_Abbbc") == False
assert text_lowercase_underscore("Aaab_abbbc") == False