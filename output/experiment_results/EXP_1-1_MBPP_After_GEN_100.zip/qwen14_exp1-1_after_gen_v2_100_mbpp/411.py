import re
def snake_to_camel(word):
    return ''.join(var.capitalize() or '_' for var in word.split('_'))