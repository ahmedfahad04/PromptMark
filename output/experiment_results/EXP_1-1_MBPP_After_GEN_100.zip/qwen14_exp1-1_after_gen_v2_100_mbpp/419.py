def round_and_sum(var1):
  count = len(var1)
  sum_val = sum(list(map(round, var1)) * count)
  return sum_val