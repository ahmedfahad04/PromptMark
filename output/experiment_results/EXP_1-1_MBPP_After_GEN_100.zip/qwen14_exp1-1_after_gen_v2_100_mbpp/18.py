NO_OF_CHARS = 256

def str_to_list(word):
    temp = []
    for x in word:
        temp.append(x)
    return temp

def lst_to_string(items):
    return ''.join(items)

def get_char_count_array(text):
    count = [0] * NO_OF_CHARS
    for i in text:
        count[ord(i)] += 1
    return count

def remove_dirty_chars(word, second_word):
    count = get_char_count_array(second_word)
    ip_ind = 0
    res_ind = 0
    temp = ''
    str_list = str_to_list(word)
    while ip_ind != len(str_list):
        temp = str_list[ip_ind]
        if count[ord(temp)] == 0:
            str_list[res_ind] = str_list[ip_ind]
            res_ind += 1
        ip_ind += 1
    return lst_to_string(str_list[0:res_ind])