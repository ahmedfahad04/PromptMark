def find_Average_Of_Cube(n):  
    total_sum = 0
    for index in range(1, n + 1): 
        total_sum += index * index * index  
    return round(total_sum / n, 6)