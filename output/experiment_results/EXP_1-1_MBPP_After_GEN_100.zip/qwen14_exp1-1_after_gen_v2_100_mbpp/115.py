def empty_dit(list1):
    vac_count = all(not o for o in list1)
    return vac_count

assert empty_dit([{},{},{}]) == True
assert empty_dit([{1,2},{},{}]) == False
assert empty_dit({}) == True