def median_trapezium(base1, base2, height):
    av_base = 0.5 * (base1 + base2)
    return av_base

assert median_trapezium(15, 25, 35) == 20
assert median_trapezium(10, 20, 30) == 15
assert median_trapezium(6, 9, 4) == 7.5