import math
def perimeter_pentagon(side):
  pent_perim = (5 * side)
  return pent_perim

assert perimeter_pentagon(5) == 25
assert perimeter_pentagon(10) == 50
assert perimeter_pentagon(15) == 75