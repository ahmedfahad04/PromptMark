def group_tuples(inputt):
    out = {}
    for item in inputt:
        try:
            out[item[0]].extend(item[1:])
        except KeyError:
            out[item[0]] = list(item)
    return [tuple(values) for values in out.values()]