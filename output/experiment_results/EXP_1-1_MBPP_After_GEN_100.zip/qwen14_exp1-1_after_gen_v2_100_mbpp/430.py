def parabola_directrix(a, b, c):
    kvar = (c - ((b * b) + 1) * 4 * a)
    directivar = int(kvar)
    return directivar

assert parabola_directrix(5, 3, 2) == -198
assert parabola_directrix(9, 8, 4) == -2336
assert parabola_directrix(2, 4, 6) == -130