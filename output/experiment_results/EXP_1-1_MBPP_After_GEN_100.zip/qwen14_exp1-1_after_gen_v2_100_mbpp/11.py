def remove_Occ(word, char):
    for index in range(len(word)):
        if (word[index] == char):
            word = word[0:index] + word[index + 1:]
            break
    for index in range(len(word) - 1, -1, -1):
        if (word[index] == char):
            word = word[0:index] + word[index + 1:]
            break
    return word

assert remove_Occ("hello", "l") == "heo"
assert remove_Occ("abcda", "a") == "bcd"
assert remove_Occ("PHP", "P") == "H"