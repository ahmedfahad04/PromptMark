def and_tuples(test_tup1, test_tup2):
  answer = tuple(var1 & var2 for var1, var2 in zip(test_tup1, test_tup2))
  return answer