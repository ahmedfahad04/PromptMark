def find_even_pair(A): 
  counta = 0
  for indexa in range(0, len(A)): 
    for indexb in range(indexa+1, len(A)): 
        if ((A[indexa] ^ A[indexb]) % 2 == 0): 
          counta += 1

  return counta