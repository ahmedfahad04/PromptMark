def find(n, m):
    quo = n // m
    return quo

assert find(10, 3) == 3
assert find(4, 2) == 2
assert find(20, 5) == 4