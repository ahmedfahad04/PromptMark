def string_to_tuple(var1):
    answer = tuple(x for x in var1 if not x.isspace())
    return answer

# Test Cases
assert string_to_tuple("python 3.0")==('p', 'y', 't', 'h', 'o', 'n', '3', '.', '0')
assert string_to_tuple("item1")==('i', 't', 'e', 'm', '1')
assert string_to_tuple("15.10")==('1', '5', '.', '1', '0')