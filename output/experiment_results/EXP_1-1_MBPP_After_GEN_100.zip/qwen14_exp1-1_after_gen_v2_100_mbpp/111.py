def common_in_nested_lists(nestedlist):
    value = list(set.intersection(*map(set, nestedlist)))
    return value