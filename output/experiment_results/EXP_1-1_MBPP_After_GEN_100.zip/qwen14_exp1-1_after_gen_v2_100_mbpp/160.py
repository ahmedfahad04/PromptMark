def find_solution(var, val, num):
	index = 0
	while index * var <= num:
		if (num - (index * var)) % val == 0: 
			return (index, (num - (index * var)) // val)
		index = index + 1
	return None

assert find_solution(2, 3, 7) == (2, 1)
assert find_solution(4, 2, 7) == None
assert find_solution(1, 13, 17) == (4, 1)