def sum_range_list(var1, k, v):
    sum_range = 0
    for j in range(k, v + 1, 1):
        sum_range += var1[j]
    return sum_range

assert sum_range_list([2,1,5,6,8,3,4,9,10,11,8,12], 8, 10) == 29
assert sum_range_list([2,1,5,6,8,3,4,9,10,11,8,12], 5, 7) == 16
assert sum_range_list([2,1,5,6,8,3,4,9,10,11,8,12], 7, 10) == 38