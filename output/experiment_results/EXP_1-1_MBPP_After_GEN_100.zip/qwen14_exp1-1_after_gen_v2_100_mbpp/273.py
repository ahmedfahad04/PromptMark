def substract_elements(var_a, var_b):
    outcome = tuple(map(lambda item1, item2: item1 - item2, var_a, var_b))
    return outcome