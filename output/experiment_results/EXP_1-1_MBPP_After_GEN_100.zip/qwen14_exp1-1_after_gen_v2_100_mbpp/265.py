def list_split(S, step):
    return [S[var1::step] for var1 in range(step)]