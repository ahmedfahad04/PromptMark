def even_Power_Sum(n): 
    total = 0
    for index in range(1, n + 1): 
        power = 2 * index
        total = total + (power * power * power * power * power)
    return total