def extract_string(var1, length):
    answer = [item for item in var1 if len(item) == length]
    return answer