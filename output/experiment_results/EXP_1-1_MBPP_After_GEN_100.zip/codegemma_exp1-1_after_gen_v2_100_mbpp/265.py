def list_split(input_list, step):
    """
    This function splits a list into sublists of a given size.
    """
    return [input_list[i::step] for i in range(step)]