def sum_of_squares(n):  
    return int(n*(4*n*n-1)/3) 

##Test Cases:
assert sum_of_squares(2) == 10
assert sum_of_squares(3) == 35
assert sum_of_squares(4) == 84