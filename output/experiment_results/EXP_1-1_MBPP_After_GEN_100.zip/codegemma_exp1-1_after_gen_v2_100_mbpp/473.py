def tuple_intersection(test_list1, test_list2):
  """
  This function takes two lists of tuples and returns a set of tuples that are present in both lists.
  """
  sorted_ele_list1 = [tuple(sorted(ele)) for ele in test_list1]
  sorted_ele_list2 = [tuple(sorted(ele)) for ele in test_list2]
  res = set(sorted_ele_list1) & set(sorted_ele_list2)
  return (res)