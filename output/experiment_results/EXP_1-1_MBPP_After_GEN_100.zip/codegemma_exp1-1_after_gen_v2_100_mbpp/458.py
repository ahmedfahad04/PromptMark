def area_of_rectangle(length, breadth):
  """
  Calculates the area of a rectangle.

  Args:
    length: The length of the rectangle.
    breadth: The breadth of the rectangle.

  Returns:
    The area of the rectangle.
  """
  area = length * breadth
  return area