def interleave_lists(list1, list2, list3):
    """
    Interleaves three lists by iterating over each element in a list of tuples formed by zipping the three input lists.
    """
    result = [el for pair in zip(list1, list2, list3) for el in pair]
    return result