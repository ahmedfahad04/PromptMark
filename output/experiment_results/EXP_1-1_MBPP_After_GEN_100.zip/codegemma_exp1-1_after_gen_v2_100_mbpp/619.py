def move_num(test_str):
  res = ''
  num = ''
  for char in test_str:
    if char.isdigit():
      num += char
    else:
      res += char
  res += num
  return (res)