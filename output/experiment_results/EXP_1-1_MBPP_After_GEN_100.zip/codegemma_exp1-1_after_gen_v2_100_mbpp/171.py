import math

def pentagon_perimeter(side):
  """Calculates the perimeter of a pentagon given its side length."""
  return 5 * side