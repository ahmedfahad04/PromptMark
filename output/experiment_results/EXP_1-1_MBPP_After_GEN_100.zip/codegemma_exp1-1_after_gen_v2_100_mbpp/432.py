def median_trapezium(base1, base2, height):
  """
  Calculates the area of a trapezoid with a given base and height.
  """
  area = 0.5 * (base1 + base2) * height
  return area