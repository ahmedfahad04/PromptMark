def sum_list(input_list1,input_list2):
  output_list = [input_list1[index] + input_list2[index] for index in range(len(input_list1))]
  return output_list