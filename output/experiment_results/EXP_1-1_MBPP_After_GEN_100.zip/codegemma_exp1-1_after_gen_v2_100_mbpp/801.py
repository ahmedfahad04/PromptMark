def test_three_equal(var1,var2,var3):
  set_of_values = {var1,var2,var3}
  if len(set_of_values)==3:
    return 0
  else:
    return 4-len(set_of_values)