def average_tuple(nums):
    """
    Calculates the average of each tuple in a list of tuples.

    Args:
        nums: A list of tuples.

    Returns:
        A list of averages for each tuple in the input list.
    """
    answer = [sum(x) / len(x) for x in zip(*nums)]
    return answer