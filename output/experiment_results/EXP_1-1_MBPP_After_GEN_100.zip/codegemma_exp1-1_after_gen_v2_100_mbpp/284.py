def check_element(list, element):
  all_match = all(item == element for item in list)
  return all_match