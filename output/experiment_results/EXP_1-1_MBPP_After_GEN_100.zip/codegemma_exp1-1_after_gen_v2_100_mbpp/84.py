def sequence(n): 
	if n == 1 or n == 2: 
		return 1
	else: 
		return sequence(sequence(key(n))) + sequence(key(n) - sequence(key(n) - 1))

def key(n):
    if n == 1 or n == 2:
        return 1
    else:
        return key(key(n-1)) + key(n-key(n-1))