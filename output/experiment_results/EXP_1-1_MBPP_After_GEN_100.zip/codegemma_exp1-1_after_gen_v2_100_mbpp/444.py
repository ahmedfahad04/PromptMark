def trim_tuple(test_list, K):
  """
  This function trims a tuple by removing the first and last K elements from each tuple in a list of tuples.
  """
  result = []
  for item in test_list:
    trimmed_item = tuple(item[K:-K])
    result.append(trimmed_item)
  return str(result)