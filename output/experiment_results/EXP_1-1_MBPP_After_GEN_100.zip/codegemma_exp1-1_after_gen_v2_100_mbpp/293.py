import math
def rightangle_hypotenuse(adjacent,opposite):
  """
  Calculates the hypotenuse of a right-angled triangle given the adjacent and opposite sides.
  """
  hypotenuse = math.sqrt((adjacent**2) + (opposite**2))
  return hypotenuse