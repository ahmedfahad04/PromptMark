def insert_element(list, element):
  """
  Inserts an element at the beginning of a list.
  """
  list = [element, v for elt in list for v in (elt,)]
  return list