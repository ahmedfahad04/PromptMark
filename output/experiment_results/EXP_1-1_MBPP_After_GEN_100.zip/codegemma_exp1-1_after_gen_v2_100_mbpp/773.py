import re

def find_first_occurrence(text, pattern):
    for match in re.finditer(pattern, text):
        start_index = match.start()
        end_index = match.end()
        return (text[start_index:end_index], start_index, end_index)