def count_bidirectional(test_list):
  count = 0
  for index in range(len(test_list)):
    for iindex in range(index + 1, len(test_list)):
      if test_list[iindex][0] == test_list[index][1] and test_list[index][1] == test_list[iindex][0]:
        count += 1
  return count