def loss_amount(actual_cost, sale_amount):
  """
  Calculates the loss amount between actual cost and sale amount.
  """
  if sale_amount > actual_cost:
    loss = sale_amount - actual_cost
    return loss
  else:
    return 0