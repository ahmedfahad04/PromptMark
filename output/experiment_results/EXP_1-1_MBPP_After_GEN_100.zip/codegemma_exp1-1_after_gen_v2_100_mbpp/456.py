def reverse_string_list(str_list):
    """
    Reverses a list of strings in place.
    """
    for i in range(len(str_list)):
        str_list[i] = str_list[i][::-1]
    return str_list