def extract_string(str, l):
    """
    Extracts strings of length l from a list of strings.
    """
    result = [e for e in str if len(e) == l]
    return result