def find_Average_Of_Cube(input_num):  
    sum_of_cubes = 0
    for i in range(1, input_num + 1): 
        sum_of_cubes += i ** 3  
    return round(sum_of_cubes / input_num, 6)