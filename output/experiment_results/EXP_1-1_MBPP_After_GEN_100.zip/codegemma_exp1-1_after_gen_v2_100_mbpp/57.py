def find_Max_Num(arr):
    """
    This function takes an array of numbers and returns the maximum number formed by concatenating the digits in the array in descending order.
    """
    n = len(arr)
    arr.sort(reverse=True)
    num = arr[0]
    for i in range(1, n):
        num = num * 10 + arr[i]
    return num