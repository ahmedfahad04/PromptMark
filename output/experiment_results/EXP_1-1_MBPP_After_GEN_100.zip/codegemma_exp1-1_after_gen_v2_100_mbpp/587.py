def list_to_tuple(listx):
  """
  Converts a list to a tuple.
  """
  tuplex = tuple(listx)
  return tuplex