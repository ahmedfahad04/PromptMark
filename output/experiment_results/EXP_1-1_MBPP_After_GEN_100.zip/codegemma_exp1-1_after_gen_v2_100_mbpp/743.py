def rotate_right(list, m):
  """
  Rotates a list to the right by m steps.
  """
  key = m % len(list)
  return list[-key:] + list[:-key]