def even_numbers(nums):
    return [num for num in nums if num % 2 == 0]

assert even_numbers([1,2,3,4,5]) == [2,4]
assert even_numbers([4,5,6,7,8,0,1]) == [4,6,8,0]
assert even_numbers([8,12,15,19]) == [8,12]