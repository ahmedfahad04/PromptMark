def find(n, m):
    """
    This function finds the quotient of n divided by m.
    """
    quotient = n // m
    return quotient