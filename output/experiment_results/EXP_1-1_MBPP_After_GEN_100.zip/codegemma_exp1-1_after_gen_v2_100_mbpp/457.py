def find_min_by_length(lst):
    return min(lst, key=len)