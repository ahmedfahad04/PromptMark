import math
def sector_area(radius,angle):
    if angle > 360:
        return None
    return (math.pi*radius**2) * (angle/360)