def str_to_tuple(str1):
    """
    Converts a string to a tuple of non-whitespace characters.
    """
    result = tuple(x for x in str1 if not x.isspace())
    return result