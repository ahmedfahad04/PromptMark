def round_and_sum(list1):
  length = len(list1)
  rounded_sum = sum(list(map(round, list1)) * length)
  return rounded_sum