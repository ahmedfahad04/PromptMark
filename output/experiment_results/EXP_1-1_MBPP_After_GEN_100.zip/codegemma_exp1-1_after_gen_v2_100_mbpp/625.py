def swap_List(new_list): 
    size = len(new_list) 
    first_item = new_list[0] 
    new_list[0] = new_list[size - 1] 
    new_list[size - 1] = first_item   
    return new_list