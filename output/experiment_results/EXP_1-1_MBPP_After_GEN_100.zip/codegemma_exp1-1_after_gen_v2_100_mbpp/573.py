def unique_product(list_data):
    unique_items = list(set(list_data))
    product = 1
    for item in unique_items:
        product *= item
    return product