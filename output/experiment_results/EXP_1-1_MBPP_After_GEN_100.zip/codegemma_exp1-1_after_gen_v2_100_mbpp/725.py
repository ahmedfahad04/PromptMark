import re

def extract_quotation(text):
  """
  This function extracts the quoted words from a given text.
  """
  return (re.findall(r'"(.*?)"', text))