def count_vowels(txt_string: str) -> int:
    vowel_dtct_set = {'a', 'e', 'i', 'o', 'u'}
    tally_value = 0
    string_length_val = len(txt_string)

    for j_loop_index in range(string_length_val):
        this_letter_fnd = txt_string[j_loop_index]

        # For vowel letters, skip.
        if this_letter_fnd in vowel_dtct_set:
            continue

        left_is_vowel_status = False
        if j_loop_index > 0:
            left_char_letter = txt_string[j_loop_index - 1]
            if left_char_letter in vowel_dtct_set:
                left_is_vowel_status = True

        next_is_vowel_status = False
        if j_loop_index < string_length_val - 1:
            next_char_letter = txt_string[j_loop_index + 1]
            if next_char_letter in vowel_dtct_set:
                next_is_vowel_status = True

        # When left neighbor is vowel or next neighbor is vowel, then tally this letter.
        if left_is_vowel_status or next_is_vowel_status:
            tally_value += 1
    return tally_value