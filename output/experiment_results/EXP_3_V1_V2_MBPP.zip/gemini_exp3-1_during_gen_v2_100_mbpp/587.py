def list_tuple(target_list: list) -> tuple:
    """
    Converts target list to a tuple.
    """
    final_tuple = tuple(target_list) # Performs the core conversion.
    return final_tuple