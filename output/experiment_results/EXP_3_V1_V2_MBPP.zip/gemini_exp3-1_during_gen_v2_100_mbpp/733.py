def find_first_occurrence(cllection_list: list[int], ctarget_number: int) -> int:
    clow_point: int = 0
    chigh_point: int = len(cllection_list) - 1
    cfound_position: int = -1

    # Loop continues given cproper_range.
    while clow_point <= chigh_point:
        cmiddle_point: int = clow_point + (chigh_point - clow_point) // 2
        
        if cllection_list[cmiddle_point] == ctarget_number:
            cfound_position = cmiddle_point
            # For first occurrence, ccontinue_check to the left.
            chigh_point = cmiddle_point - 1
        elif cllection_list[cmiddle_point] < ctarget_number:
            # ctarget_number to the right of cmiddle_point.
            clow_point = cmiddle_point + 1
        else: # cllection_list[cmiddle_point] > ctarget_number
            # ctarget_number to the left of cmiddle_point.
            chigh_point = cmiddle_point - 1
            
    return cfound_position