def tuple_intersection(g_first_tuple_list, g_other_tuple_list):
    """
    Finds the intersection of tuples between two lists, irrespective of tuple element order.

    Parameters:
    - g_first_tuple_list (list): The primary list of tuples.
    - g_other_tuple_list (list): The other list of tuples to compare against.

    Returns:
    - set: A collection of tuples present in both lists after normalization.
    """
    # Normalize tuples in the first list by sorting elements, then store in a set for quick lookups.
    g_normalized_first_set = {tuple(sorted(l_original_tuple)) for l_original_tuple in g_first_tuple_list}

    # Normalize tuples in the second list by sorting elements, then store in a set.
    g_normalized_other_set = {tuple(sorted(l_original_tuple)) for l_original_tuple in g_other_tuple_list}

    # Perform set intersection to get common normalized tuples.
    c_common_tuples = g_normalized_first_set.intersection(g_normalized_other_set)

    return c_common_tuples