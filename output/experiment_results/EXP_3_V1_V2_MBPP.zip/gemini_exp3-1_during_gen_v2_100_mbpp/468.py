def max_product(long_object_list: list[int]) -> int:
    # long_object_list: The list of numbers provided for finding the maximal product.
    long_list_length = len(long_object_list)

    if long_list_length == 0:
        return 0
    # For a list containing only one number, that number itself forms the only increasing subsequence.
    if long_list_length == 1:
        return long_object_list[0]

    # chain_long_figures[j] will store the maximal product of an increasing subsequence
    # that terminates with the current number at index j.
    # Each number initially forms an increasing subsequence of length one, with its own figure.
    chain_long_figures = list(long_object_list)

    # top_figure_long tracks the overall maximal figure found across all increasing subsequences.
    # Initialized with the highest single figure from the list, accounting for cases
    # where all other computed figures might be lower.
    top_figure_long = max(chain_long_figures)

    # Traverse through the long_object_list, starting from the second number.
    for j_current_point in range(1, long_list_length):
        # For long_object_list[j_current_point], check all prior numbers.
        for l_prior_point in range(j_current_point):
            # If the current number is greater than a prior number, it can prolong an
            # increasing subsequence ending at that prior number.
            if long_object_list[j_current_point] > long_object_list[l_prior_point]:
                # Calculate a potential new figure by multiplying the prior subsequence's figure
                # with the current number.
                current_fig_option = chain_long_figures[l_prior_point] * long_object_list[j_current_point]
                
                # If this current_fig_option is greater than the figure currently recorded
                # for subsequences terminating at j_current_point, update it.
                if current_fig_option > chain_long_figures[j_current_point]:
                    chain_long_figures[j_current_point] = current_fig_option
        
        # After evaluating all prior numbers for long_object_list[j_current_point],
        # update the top_figure_long if the newly computed figure for
        # chain_long_figures[j_current_point] is higher.
        if chain_long_figures[j_current_point] > top_figure_long:
            top_figure_long = chain_long_figures[j_current_point]
            
    return top_figure_long