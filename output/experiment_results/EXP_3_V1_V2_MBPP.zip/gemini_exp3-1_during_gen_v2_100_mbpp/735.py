def toggle_middle_bits(current_number: int) -> int:
    """
    Toggles all bits of a number except the first (most significant)
    and the last (least significant) bit.
    """
    length_of_number = current_number.bit_length()

    # If the number has fewer than 3 bits, there are no 'middle' bits to toggle.
    # For example, 0 (0 bits), 1 (1 bit), 2 (0b10, 2 bits), 3 (0b11, 2 bits).
    if length_of_number < 3:
        return current_number

    # Generate a pattern of all ones for the current length of the number.
    # For number 0b1001 (length 4), this generates 0b1111.
    complete_ones_pattern = (1 << length_of_number) - 1

    # Generate a pattern for the most significant bit (first bit).
    # For number 0b1001 (length 4), this generates 0b1000.
    principal_bit_pattern = (1 << (length_of_number - 1))

    # The least significant bit (last bit) is always at position 0.
    # This generates 0b0001.
    low_bit_pattern = 1

    # Construct the central_toggle_pattern by XORing the complete_ones_pattern
    # with the patterns for the first and last bits.
    # This leaves ones only in the 'middle' bit positions.
    # Example for 0b1001 (length 4): 0b1111 ^ 0b1000 ^ 0b0001 = 0b0110
    central_toggle_pattern = complete_ones_pattern ^ principal_bit_pattern ^ low_bit_pattern

    # Toggle the middle bits by XORing the original number with the central_toggle_pattern.
    computed_result = current_number ^ central_toggle_pattern
    return computed_result