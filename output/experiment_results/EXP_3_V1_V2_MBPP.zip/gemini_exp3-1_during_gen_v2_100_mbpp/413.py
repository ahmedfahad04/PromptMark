def extract_nth_element(general_tuples, n_position):
    """
    Pulls the nth_position element from each tuple present in the general_tuples list.
    """
    collected_elements = []  # Creates a list to hold the extracted items.
    for current_tuple in general_tuples:
        # Pulls the item at n_position from the current_tuple.
        collected_elements.append(current_tuple[n_position])
    return collected_elements