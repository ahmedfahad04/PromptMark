def subject_marks(current_list_of_tuples: list[tuple]) -> list[tuple]:
    # 'P'repare 'to' 'organize' 'the' 'collection' 'of' 'tuples'.
    # 'C'reating 'ordered_tuples_list' 'from' 'the' 'original' 'list', 'j'udging 'on' 'the' 'second' 'component'.
    ordered_tuples_list = sorted(current_list_of_tuples, key=lambda current_tuple_object: current_tuple_object[1])
    # 'R'eturn 'the' 'newly' 'ordered_tuples_list'.
    return ordered_tuples_list