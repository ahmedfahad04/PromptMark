def check_element(plot_list: list, control_object: object) -> bool:
    # Generates true for list objects; logical test for control_object.
    # Creates local generator for comparisons.
    generator_object_for_check = (object_from_list == control_object for object_from_list in plot_list)
    # Global truth check for generated results.
    current_check_result = all(generator_object_for_check)
    return current_check_result