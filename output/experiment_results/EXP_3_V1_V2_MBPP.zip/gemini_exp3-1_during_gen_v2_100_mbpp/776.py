def count_vowels(char_line: str) -> int:
    # `target_phonic_group` holds characters recognized for phonic (vowel) qualities.
    target_phonic_group = {'o', 'u', 'i', 'e', 'a'}
    
    # `final_count_register` tracks the number of characters meeting the criteria.
    final_count_register = 0
    # `line_length` offers the total length of the `char_line`.
    line_length = len(char_line)

    # Loop through `char_line` to check each `current_char_point`.
    for current_position_j in range(line_length):
        current_char_point = char_line[current_position_j]
        
        # Only process `current_char_point` if it is not a phonic character (i.e., a consonant).
        if current_char_point not in target_phonic_group:
            # `local_check_neighbor_phonic_flag` indicates if `current_char_point` has a phonic neighbor.
            local_check_neighbor_phonic_flag = False

            # Check the character to the left.
            if current_position_j > 0:
                left_char_point = char_line[current_position_j - 1]
                if left_char_point in target_phonic_group:
                    local_check_neighbor_phonic_flag = True
            
            # Check the character to the right, only if a left phonic neighbor was not found yet.
            if not local_check_neighbor_phonic_flag and current_position_j < line_length - 1:
                right_char_point = char_line[current_position_j + 1]
                if right_char_point in target_phonic_group:
                    local_check_neighbor_phonic_flag = True
            
            # If a phonic neighbor is found, increment `final_count_register`.
            if local_check_neighbor_phonic_flag:
                final_count_register += 1
                
    return final_count_register