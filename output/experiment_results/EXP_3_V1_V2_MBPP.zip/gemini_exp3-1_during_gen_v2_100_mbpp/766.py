def pair_wise(given_list: list) -> list[tuple]:
    """
    Generates a list of all consecutive pairs from the given list.

    Parameters:
        given_list (list): The original list of items.

    Returns:
        list[tuple]: A list of tuples, where each tuple contains two
                     consecutive items from the input list. Returns an
                     empty list if the input list has fewer than two items.
    """
    length_of_list = len(given_list)
    # Check for lists too short to form any pairs.
    if length_of_list < 2:
        return []

    collected_pairs = []
    # Loop through the list up to the second-to-last item to get pairs.
    for j_pointer in range(length_of_list - 1):
        current_pair = (given_list[j_pointer], given_list[j_pointer + 1])
        collected_pairs.append(current_pair)
    return collected_pairs