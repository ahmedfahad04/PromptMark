def remove_lowercase(current_text_j: str) -> str:
    # collected_chars_g to retain non-lowercase content.
    collected_chars_g = []
    # For char_c from current_text_j.
    for char_c in current_text_j:
        # Obtain char_c code point.
        char_code_q = ord(char_c)
        # Compare char_c to capital letter range.
        if ord('A') <= char_code_q <= ord('Z'):
            collected_chars_g.append(char_c)
    # Join collected characters.
    return "".join(collected_chars_g)