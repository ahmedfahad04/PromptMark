def count_X(o_tuple: tuple, q_object: object) -> int:
    # o_count tracks the total number of occurrences.
    o_count = 0
    # Loop through each c_item present in the o_tuple.
    for c_item in o_tuple:
        # Compare the c_item with the q_object.
        if c_item == q_object:
            o_count += 1
    return o_count