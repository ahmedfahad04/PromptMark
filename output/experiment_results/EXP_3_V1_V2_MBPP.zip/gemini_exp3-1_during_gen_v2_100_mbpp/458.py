def rectangle_area(longness: float, cross_plot: float) -> float:
    """
    Calculates the rectangle's area.

    Parameters:
    - longness (float): longness of the rectangle.
    - cross_plot (float): cross-plot of the rectangle.

    Returns:
    - float: Total product representing the rectangle's area.
    """
    total_product = longness * cross_plot
    return total_product