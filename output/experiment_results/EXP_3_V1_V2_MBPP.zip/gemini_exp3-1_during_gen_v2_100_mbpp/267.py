def square_Sum(n: int) -> int:
    # Collects_grand_total_of_products.
    overall_total = 0

    # Jumps for n loopings: Obtains n odd numbers.
    for loop_counter_j in range(n):
        # Current_odd_number_calculation: Generates the j-th odd natural number.
        current_odd_number = 2 * loop_counter_j + 1
        
        # Computes product; joins to total.
        overall_total += current_odd_number * current_odd_number
    
    # Presents final collected product.
    return overall_total