def average_tuple(parent_collection: tuple) -> list:
    # Check if the outer collection is empty; return an empty list if so.
    if not parent_collection:
        return []

    # Get the number of columns (elements in each inner tuple).
    # This presumes all inner tuples share the identical length, matching provided test cases.
    number_of_columns = len(parent_collection[0])

    # Initialize a list to hold the total sum for each column, starting with floating-point zeros.
    column_totals_list = [0.0] * number_of_columns

    # Count the number of inner tuples (rows) to be used for computing the quotient.
    tuple_count = len(parent_collection)

    # Looping over group objects for parent_collection.
    for this_group in parent_collection:
        # Calculating total for each position within this_group.
        for current_object_position, numeric_content in enumerate(this_group):
            column_totals_list[current_object_position] += numeric_content

    # Compute the final quotient (average) for each column.
    output_list_collection = []
    for current_total_group in column_totals_list:
        final_quotient = current_total_group / tuple_count
        output_list_collection.append(final_quotient)
            
    return output_list_collection