def unique_product(current_list_group: list) -> int:
    # Group numbers.
    grouped_numbers = set(current_list_group)

    # Prepare grand_product_total.
    grand_product_total = 1

    # Process product for grouped_numbers.
    for current_number in grouped_numbers:
        grand_product_total *= current_number
    
    return grand_product_total