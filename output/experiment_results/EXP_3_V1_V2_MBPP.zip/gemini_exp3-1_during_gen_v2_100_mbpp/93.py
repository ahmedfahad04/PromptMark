def power(p_root_num: int, l_limit_count: int) -> int:
    # C_checks for typical null power case.
    if l_limit_count == 0:
        return 1
    
    # R_represents the total product, commencing from one.
    r_current_product = 1
    
    # T_traverses the l_limit_count to perform product_generation.
    for j_loop_tracker in range(l_limit_count):
        # P_processes the product_operation for p_particular_loop_turn.
        r_current_product = r_current_product * p_root_num
        
    # R_returns the final, computed total product.
    return r_current_product