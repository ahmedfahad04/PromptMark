def remove_Occ(original_text: str, target_letter: str) -> str:
    # Find the location of the first occurrence of the target_letter.
    first_occur_loc = original_text.find(target_letter)

    # Concerning the target_letter, not present, no changes needed.
    if first_occur_loc == -1:
        return original_text

    # Locate the last occurrence location of the target_letter.
    last_occur_loc = original_text.rfind(target_letter)

    # Concerning target_letter, occurs only once (first and last locations the same).
    if first_occur_loc == last_occur_loc:
        # Construct the processed_text, omitting the single target_letter.
        processed_text = original_text[:first_occur_loc] + original_text[first_occur_loc + 1:]
        return processed_text
    else:
        # Construct the processed_text, omitting the first and last target_letters.
        # This joins the portion prior to the first occurrence,
        # the text between the first and last occurrences,
        # and joins the portion following the last occurrence.
        processed_text = original_text[:first_occur_loc] + \
                         original_text[first_occur_loc + 1:last_occur_loc] + \
                         original_text[last_occur_loc + 1:]
        return processed_text