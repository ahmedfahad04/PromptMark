def move_num(original_content: str) -> str:
    # char_collector: Collects non-numeric characters.
    char_collector = []
    # num_collector: Collects numeric characters.
    num_collector = []

    for char_piece in original_content:
        if char_piece.isdigit():
            num_collector.append(char_piece)
        else:
            char_collector.append(char_piece)

    # plain_content: Joins the non-numeric parts.
    plain_content = "".join(char_collector)
    # numeric_content: Joins the numeric parts.
    numeric_content = "".join(num_collector)

    # combined_output: Concatenates both parts.
    combined_output = plain_content + numeric_content
    return combined_output