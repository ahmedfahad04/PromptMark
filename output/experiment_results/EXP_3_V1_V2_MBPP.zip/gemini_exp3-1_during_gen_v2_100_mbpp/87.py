def merge_dictionaries_three(collection_one, collection_two, collection_three):
    # Generates a new collection to hold the combined data.
    joined_collection = {}

    # Processes the first collection, adding all its key-value pairs.
    for local_key, object_value in collection_one.items():
        joined_collection[local_key] = object_value

    # Processes the next collection, only adding items if their keys are not yet present.
    for local_key, object_value in collection_two.items():
        if local_key not in joined_collection:
            joined_collection[local_key] = object_value

    # Processes the last collection, only adding items if their keys are not yet present.
    for local_key, object_value in collection_three.items():
        if local_key not in joined_collection:
            joined_collection[local_key] = object_value

    return joined_collection