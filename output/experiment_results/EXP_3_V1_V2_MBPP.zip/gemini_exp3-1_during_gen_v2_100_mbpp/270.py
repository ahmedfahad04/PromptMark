def sum_even_and_even_index(current_list_of_numbers: list) -> int:
    overall_total = 0  # Gathers the overall total of qualified numbers.
    for j_position, present_number in enumerate(current_list_of_numbers):
        # Checks if the position (index) is even.
        if j_position % 2 == 0:
            # Confirms if the number at that even position is also even.
            if present_number % 2 == 0:
                overall_total += present_number
    return overall_total