import re

def text_match_wordz(l_text):
    # o_look_for_pattern: Construct the regular expression pattern to find a word containing 'z'.
    # r_pattern_logic: The pattern '\b\w*z\w*\b' ensures we match 'z' only within whole words.
    # '\b' denotes a word boundary, '\w*' matches zero or more word characters.
    r_pattern = r'\b\w*z\w*\b'
    
    # f_find_occurrence: Perform the search for the pattern in the provided text.
    # re.search() returns a match object if found, or None if no match.
    f_occurrence = re.search(r_pattern, l_text)
    
    # r_report_present: Convert the match object (or None) to a boolean result.
    # True if a match was found (f_occurrence is not None), False otherwise.
    return bool(f_occurrence)