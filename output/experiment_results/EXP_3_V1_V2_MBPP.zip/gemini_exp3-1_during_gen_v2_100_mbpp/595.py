def min_Swaps(original_code: str, target_code: str) -> 'int | str':
    # check_lengths_comply: confirm that both code strings possess identical lengths.
    length_code_first = len(original_code)
    length_code_final = len(target_code)

    if length_code_first != length_code_final:
        return "Not Possible"

    # count_logic_perform: compute the counts of '1's for both code strings.
    one_count_first = original_code.count('1')
    one_count_final = target_code.count('1')

    # check_one_counts_logic: ensure that the counts of '1's (and thus '0's) are congruent.
    if one_count_first != one_count_final:
        return "Not Possible"

    one_no_flips = 0 
    # go_through_codes_logic: loop through both code strings to pinpoint necessary '1' to '0' flips.
    for j in range(length_code_first):
        # one_no_conflict_logic: a '1' in original_code needs to shift to a '0' position in target_code.
        if original_code[j] == '1' and target_code[j] == '0':
            one_no_flips += 1
    
    # final_logic_confirm: the number of such '1' to '0' conflicts directly indicates the minimum swaps.
    return one_no_flips