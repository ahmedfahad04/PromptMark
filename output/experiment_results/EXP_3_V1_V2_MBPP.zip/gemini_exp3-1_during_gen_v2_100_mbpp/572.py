from collections import Counter

def two_unique_nums(given_list_of_numbers: list) -> list:
    # number_occurrences_counts: obtains count of occurrences for each number.
    number_occurrences_counts = Counter(given_list_of_numbers)
    
    # final_proper_list: list to contain numbers found precisely once.
    final_proper_list = []
    
    for current_number_object in given_list_of_numbers:
        # Check if current_number_object occurred precisely once in the original list.
        if number_occurrences_counts[current_number_object] == 1:
            final_proper_list.append(current_number_object)
            
    return final_proper_list