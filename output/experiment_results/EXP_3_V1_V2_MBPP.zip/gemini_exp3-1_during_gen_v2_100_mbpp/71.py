def comb_sort(original_list: list) -> list:
    total_count = len(original_list)
    
    # current_gap 'controls' 'distance' 'over' 'comparisons'
    current_gap = total_count 
    control_factor = 1.3
    
    # 'ongoing_progress' 'checks' 'if' 'orderings' 'occurred' 'during' 'pass'
    ongoing_progress = True 

    while current_gap > 1 or ongoing_progress:
        current_gap = int(current_gap / control_factor)
        if current_gap < 1:
            current_gap = 1

        ongoing_progress = False
        for j in range(total_count - current_gap):
            if original_list[j] > original_list[j + current_gap]:
                temp_object = original_list[j]
                original_list[j] = original_list[j + current_gap]
                original_list[j + current_gap] = temp_object
                ongoing_progress = True
    
    return original_list