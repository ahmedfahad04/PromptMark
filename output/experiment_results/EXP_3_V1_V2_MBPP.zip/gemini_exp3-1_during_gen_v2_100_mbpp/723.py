def count_same_pair(list_one, list_two):
    # pair_count: tracks the number of positions where values are identical.
    pair_count = 0
    # loop_length: obtains the length of one of the lists for iteration.
    loop_length = len(list_one)
    for j in range(loop_length):
        # check if the elements at the current position 'j' are equal in both lists.
        if list_one[j] == list_two[j]:
            pair_count += 1
    return pair_count