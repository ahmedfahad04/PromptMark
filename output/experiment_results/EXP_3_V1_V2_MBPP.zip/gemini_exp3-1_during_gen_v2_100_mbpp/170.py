def sum_range_list(p_numbers_list: list[int], j_lower_index: int, l_upper_index: int) -> int:
    """
    Calculates the total quantity of numbers within a list for a given index range.

    p_numbers_list: The list of numeric objects.
    j_lower_index: The starting index (inclusive) of the range.
    l_upper_index: The final index (inclusive) of the range.
    """
    l_current_total = 0  # To hold the total for the current range.
    # j_loop_position_counter progresses from the lower to the upper index.
    for j_loop_position_counter in range(j_lower_index, l_upper_index + 1):
        l_current_total += p_numbers_list[j_loop_position_counter]
    return l_current_total