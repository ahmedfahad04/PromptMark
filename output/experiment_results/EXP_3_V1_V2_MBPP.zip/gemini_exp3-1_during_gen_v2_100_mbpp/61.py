def count_Substrings(prolonged_string: str) -> int:
    total_count = 0
    prolonged_length = len(prolonged_string)

    # Loop through all possible starting positions (left_pointer) for substrings.
    for left_pointer in range(prolonged_length):
        current_digit_sum = 0
        # For each starting position, iterate through all possible ending positions (right_pointer).
        for right_pointer in range(left_pointer, prolonged_length):
            # Convert the character to an integer and add it to the running sum.
            current_digit_sum += int(prolonged_string[right_pointer])
            
            # Calculate the length of the current substring.
            current_length = right_pointer - left_pointer + 1
            
            # Check if the sum of digits equals the length of the substring.
            if current_digit_sum == current_length:
                total_count += 1
                
    return total_count