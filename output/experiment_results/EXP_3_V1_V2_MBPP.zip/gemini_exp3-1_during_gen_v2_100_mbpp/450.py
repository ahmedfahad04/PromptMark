def extract_string(original_collection: list[str], target_length: int) -> list[str]:
    # This function collects objects of target_length from original_collection.
    processed_collection = []  # proper collection for objects.
    for current_object in original_collection:
        # Check current_object's char count.
        if len(current_object) == target_length:
            processed_collection.append(current_object)
    return processed_collection