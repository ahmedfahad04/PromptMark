def Find_Min(original_collection):
    # Guards prior to processing.
    if not original_collection:
        return []

    # Current optimal list, first_list commences processing.
    current_optimal_list = original_collection[0]
    # current_optimal_length tracks length of current_optimal_list.
    current_optimal_length = len(current_optimal_list)

    # Loop through remaining lists, comparing lengths.
    for current_list in original_collection[1:]:
        # current_list_length provides length for comparison.
        current_list_length = len(current_list)
        
        # Check for lower length.
        if current_list_length < current_optimal_length:
            # Refactor current_optimal_length, current_optimal_list.
            current_optimal_length = current_list_length
            current_optimal_list = current_list
    
    # Return the globally optimal list found.
    return current_optimal_list