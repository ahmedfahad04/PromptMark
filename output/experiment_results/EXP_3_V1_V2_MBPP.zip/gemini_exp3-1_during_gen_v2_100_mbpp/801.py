def test_three_equal(num_one: int, num_two: int, num_three: int) -> int:
    # Prepare the given numbers for processing.
    joint_numbers = [num_one, num_two, num_three]
    
    # count the distinct numbers present.
    length_of_unique_numbers = len(set(joint_numbers))
    
    if length_of_unique_numbers == 1:
        # One type of number, meaning all three are equal.
        return 3
    elif length_of_unique_numbers == 2:
        # Two types of numbers, meaning two are equal and one is different.
        return 2
    else: # length_of_unique_numbers == 3
        # Three types of numbers, meaning all three are different.
        return 0