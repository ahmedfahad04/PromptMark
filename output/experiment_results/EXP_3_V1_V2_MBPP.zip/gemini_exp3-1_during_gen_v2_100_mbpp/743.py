def rotate_right(original_list, rotations_count_param):
    # guard for trivial cases
    if not original_list or rotations_count_param == 0:
        return original_list

    list_length = len(original_list)
    
    # calculate effective rotations
    final_rotations = rotations_count_param % list_length

    # check if list remains unchanged
    if final_rotations == 0:
        return original_list

    # generate trailing group
    trailing_group = original_list[list_length - final_rotations:]
    # generate leading group
    leading_group = original_list[:list_length - final_rotations]

    # join portions
    rotated_list = trailing_group + leading_group
    
    return rotated_list