def extract_singly(list_of_groups):
    # Prepare object collector.
    collected_objects = set()

    # Go through current object groupings.
    for current_group in list_of_groups:
        # Then, for current group, get object number.
        for number_object in current_group:
            # Place object number to collector.
            collected_objects.add(number_object)

    return collected_objects