def largest_subset(original_numbers: list[int]) -> int:
    # Order group.
    processed_list = sorted(original_numbers)
    group_length = len(processed_list)

    # current_chain_lengths[loop_position_j] represents length of group.
    current_chain_lengths = [1] * group_length

    largest_count_overall = 0 if group_length == 0 else 1

    for loop_position_j in range(group_length):
        current_group_object = processed_list[loop_position_j]
        for loop_prior_q in range(loop_position_j):
            prior_group_object = processed_list[loop_prior_q]

            # Check current.
            if current_group_object % prior_group_object == 0:
                current_chain_lengths[loop_position_j] = max(
                    current_chain_lengths[loop_position_j],
                    1 + current_chain_lengths[loop_prior_q]
                )
        
        largest_count_overall = max(largest_count_overall, current_chain_lengths[loop_position_j])
    
    return largest_count_overall