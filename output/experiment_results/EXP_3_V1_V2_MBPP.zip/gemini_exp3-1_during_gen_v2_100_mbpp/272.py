def rear_extract(l_original_tuples: list[tuple]) -> list:
    """
    Collects the rear (last) component from each tuple in a provided list of tuples.

    Args:
        l_original_tuples (list[tuple]): A list comprising tuples.

    Returns:
        list: A new list that contains just the rear component from each tuple.
    """
    q_rear_components = []  # Qualify for storing rear components.
    for p_tuple_object in l_original_tuples: # Process each tuple object.
        t_terminal_component = p_tuple_object[-1]  # Take the terminal component.
        q_rear_components.append(t_terminal_component) # Join the terminal component to the collection.
    return q_rear_components