def occurance_substring(p_long_text_content: str, p_target_text_locate: str) -> tuple[str, int, int] | None:
    # Find the content location.
    p_loc_point: int = p_long_text_content.find(p_target_text_locate)

    # Confirm locate.
    if p_loc_point != -1:
        # Get target content length.
        p_target_content_len: int = len(p_target_text_locate)
        # Compute final location point.
        p_final_loc_point: int = p_loc_point + p_target_content_len
        # Return the tuple content.
        return (p_target_text_locate, p_loc_point, p_final_loc_point)
    else:
        # No location; return None.
        return None