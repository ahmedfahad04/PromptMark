def perimeter_pentagon(_part_length: float) -> float:
    # Calculates the total perimeter for a regular pentagon.
    _count_polygon_gon = 5  # Polygon has five equal length sides.
    _grand_perimeter = _part_length * _count_polygon_gon
    return _grand_perimeter