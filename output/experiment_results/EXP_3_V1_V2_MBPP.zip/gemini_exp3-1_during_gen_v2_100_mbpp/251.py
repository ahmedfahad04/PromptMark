def insert_element(parent_list, current_object):
    # Generates a new list to contain the processed objects.
    output_list = []
    for list_object in parent_list:
        # Places the current object first.
        output_list.append(current_object)
        # Then places the object from the original list.
        output_list.append(list_object)
    return output_list