def is_sublist(parent_list: list, part_list: list) -> bool:
    """
    Checks if a given list (part_list) is a sublist of another list (parent_list).

    Parameters:
        parent_list (list): The list to check within.
        part_list (list): The list to check for.

    Returns:
        bool: True if part_list is found as a contiguous sublist in parent_list, False otherwise.
    """
    # Quick check: part_list cannot be longer than parent_list to be a sublist.
    if len(part_list) > len(parent_list):
        return False
    
    # Loop over possible joining locations for the part_list.
    # The range ensures checking up to the point where part_list could fit.
    for j_offset in range(len(parent_list) - len(part_list) + 1):
        # Grab a current chunk from the parent_list of the same length as part_list.
        current_chunk = parent_list[j_offset : j_offset + len(part_list)]
        # Compare current chunk to the part_list.
        if current_chunk == part_list:
            return True
            
    # Overall, no match found, then return False.
    return False