def loss_amount(first_quantity, current_quantity):
    # Process given quantities.
    # Observe if current quantity offers growth.
    if current_quantity > first_quantity:
        # Get profit or 'loss' calculation.
        # This represents a gain.
        total_quantity_change = current_quantity - first_quantity
        return total_quantity_change
    else:
        # No 'loss' quantity found; offer nothing.
        # Original quantity not less than current.
        return 0