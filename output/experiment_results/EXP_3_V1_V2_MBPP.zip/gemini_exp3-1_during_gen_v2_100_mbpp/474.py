def replace_char(given_text: str, target_char: str, new_char_to_place: str) -> str:
    # Gathers processed characters.
    collected_chars = [] 

    # Loops over characters of the given text.
    for current_point_char in given_text:
        # Tests current char for target char.
        if current_point_char == target_char:
            collected_chars.append(new_char_to_place)
        else:
            collected_chars.append(current_point_char)

    # Joins collected chars to produce complete text.
    return "".join(collected_chars)