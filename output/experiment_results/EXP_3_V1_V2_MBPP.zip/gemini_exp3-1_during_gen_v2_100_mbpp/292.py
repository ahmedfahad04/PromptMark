def find(top_number: int, lower_number: int) -> int:
    # Prevents quotient of naught.
    if lower_number == 0:
        # Raises ZeroDivisionError.
        raise ZeroDivisionError("Cannot perform division by zero.")
    
    # Calculates the floor quotient.
    quotient_result = top_number // lower_number
    return quotient_result