def _compute_gcd(p_num_one: int, p_num_two: int) -> int:
    """
    p_provides_the_greatest_common_divisor_of_two_integers_using_euclidean_algorithm.
    """
    while p_num_two:
        p_num_one, p_num_two = p_num_two, p_num_one % p_num_two
    return p_num_one

def _compute_extended_gcd(p_num_one: int, p_num_two: int) -> tuple[int, int]:
    """
    p_performs_the_extended_euclidean_algorithm_to_find_x_and_y_for_ax + by = gcd(a, b).
    r_returns_the_coefficients_x_and_y.
    """
    l_old_r, l_current_r = p_num_one, p_num_two
    l_old_x, l_current_x = 1, 0
    l_old_y, l_current_y = 0, 1

    while l_current_r != 0:
        q_quotient_val = l_old_r // l_current_r
        
        l_old_r, l_current_r = l_current_r, l_old_r - q_quotient_val * l_current_r
        l_old_x, l_current_x = l_current_x, l_old_x - q_quotient_val * l_current_x
        l_old_y, l_current_y = l_current_y, l_old_y - q_quotient_val * l_current_y

    return l_old_x, l_old_y

def find_solution(p_coefficient_a: int, p_coefficient_b: int, p_target_n: int) -> tuple[int, int] | None:
    """
    f_finds_integer_solutions_x_and_y_for_the_equation_ax + by = n.
    r_returns_a_tuple_(x, y)_or_None_if_no_solution_exists.
    """
    g_gcd_val = _compute_gcd(p_coefficient_a, p_coefficient_b)

    # p_property_of_diophantine_equations: l_check_if_solution_is_possible.
    if p_target_n % g_gcd_val != 0:
        return None

    # c_compute_gcd_for_coefficients and get the particular x_g, y_g
    g_gcd_result_x, g_gcd_result_y = _compute_extended_gcd(p_coefficient_a, p_coefficient_b)

    # q_quotient_for_scaling: l_scale_the_solution_to_match_target_n.
    q_quotient_factor = p_target_n // g_gcd_val
    l_particular_x = g_gcd_result_x * q_quotient_factor
    # l_particular_y = g_gcd_result_y * q_quotient_factor # Not directly used after normalization of x

    # n_normalize_x_to_positive_range: o_obtain_the_smallest_non_negative_x.
    l_coefficient_b_prime = p_coefficient_b // g_gcd_val
    l_final_x = (l_particular_x % l_coefficient_b_prime + l_coefficient_b_prime) % l_coefficient_b_prime

    # r_recalculate_y_for_normalized_x: t_to_find_the_corresponding_y.
    # p_from_equation_ax + by = n => by = n - ax => y = (n - ax) / b
    l_final_y = (p_target_n - p_coefficient_a * l_final_x) // p_coefficient_b

    return l_final_x, l_final_y