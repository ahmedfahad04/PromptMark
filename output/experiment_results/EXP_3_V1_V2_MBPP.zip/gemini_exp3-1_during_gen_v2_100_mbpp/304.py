def find_Element(current_original_list, list_of_operation_ranges, target_output_position, total_query_count_for_rotations):
    # Tracks the original position of the element that will end up at the target_output_position.
    current_position_tracker = target_output_position

    # Going through operations in reverse to trace the original position.
    for operation_range in reversed(list_of_operation_ranges):
        lower_limit, right_point = operation_range
        
        # Checking current position for range.
        if lower_limit <= current_position_tracker <= right_point:
            # Computing length of the group.
            length_of_group = right_point - lower_limit + 1
            
            # Obtain query rotations count.
            query_rotations = total_query_count_for_rotations % length_of_group
            
            # Compute position offset to lower limit.
            position_offset = current_position_tracker - lower_limit
            
            # Computing new position offset (inverse of a right rotation).
            # This formula finds the original relative position before the right rotation.
            new_position_offset = (position_offset - query_rotations + length_of_group) % length_of_group
            
            # Updating tracked position.
            current_position_tracker = lower_limit + new_position_offset
            
    # Return original list element at final position.
    return current_original_list[current_position_tracker]