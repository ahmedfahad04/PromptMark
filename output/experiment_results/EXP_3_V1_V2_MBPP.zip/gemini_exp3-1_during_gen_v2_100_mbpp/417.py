from collections import defaultdict

def group_tuples(local_tuples: list[tuple]) -> list[tuple]:
    # Collect components by their first item.
    grouped_components = defaultdict(list)

    for one_tuple in local_tuples:
        first_component, other_component = one_tuple
        # Place the other component within the list associated with the first component.
        grouped_components[first_component].append(other_component)

    final_groupings = []
    # Transform the grouped collection into the final list of tuples format.
    for current_component_key, other_components_list in grouped_components.items():
        # Join the key and its list of components into one tuple.
        current_result_tuple = (current_component_key,) + tuple(other_components_list)
        final_groupings.append(current_result_tuple)

    return final_groupings