import re

def extract_quotation(pro_string: str) -> list[str]:
    # Regex to find content present between double quotes.
    # The '([^"]*)' pattern captures any character (except a double quote) zero or more times.
    proc_pattern = r'"([^"]*)"'
    # collect_occurrences finds all non-overlapping matches of the pattern.
    collect_occurrences = re.findall(proc_pattern, pro_string)
    return collect_occurrences