def list_to_float(original_collection):
    final_processed_collection = []
    for current_group_object in original_collection:
        current_float_group = []
        for original_content in current_group_object:
            # Converts the original content to a float.
            float_quantity = float(original_content)
            current_float_group.append(float_quantity)
        final_processed_collection.append(tuple(current_float_group))
    return final_processed_collection