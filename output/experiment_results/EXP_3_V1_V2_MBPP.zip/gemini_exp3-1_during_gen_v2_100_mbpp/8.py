def square_nums(original_list_of_objects):
    # Generates a new list to contain the squared numbers.
    processed_list_of_products = []

    # Loops through each original number in the provided list.
    for current_number_object in original_list_of_objects:
        # Calculates the product (square) of the current number object.
        current_product = current_number_object * current_number_object
        processed_list_of_products.append(current_product)

    # Returns the new list comprising all computed products.
    return processed_list_of_products