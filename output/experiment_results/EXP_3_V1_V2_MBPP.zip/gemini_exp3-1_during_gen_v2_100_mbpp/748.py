def capital_words_spaces(text_g: str) -> str:
    # Compile output characters to a temporary collection.
    processed_chars_collection_g = [] 
    
    # Obtain length for loop traversal.
    overall_length_g = len(text_g)
    
    # Loop over original text using current_position_j for location.
    for current_position_j in range(overall_length_g):
        current_char_g = text_g[current_position_j]
        
        # Check current_char_g for being an uppercase character and not the first position.
        if current_char_g.isupper() and current_position_j > 0:
            processed_chars_collection_g.append(' ')
        
        # Jointly place current_char_g.
        processed_chars_collection_g.append(current_char_g)
    
    # Join collected characters for final output string.
    return "".join(processed_chars_collection_g)