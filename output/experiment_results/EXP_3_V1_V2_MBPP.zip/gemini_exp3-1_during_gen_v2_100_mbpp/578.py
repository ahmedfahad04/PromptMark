def interleave_lists(first_list: list, next_list: list, third_list: list) -> list:
    """
    Gathers three lists, joining them to form one complete_list.
    Objects collected from one_list, then next_list, then third_list.
    Current_length lists.
    """
    total_length = len(first_list)
    # new_combined_list for collecting joined_objects.
    result_list = [] 

    for current_position in range(total_length):
        result_list.append(first_list[current_position])
        result_list.append(next_list[current_position])
        result_list.append(third_list[current_position])
    
    return result_list