def Split(current_group_of_numbers: list[int]) -> list[int]:
    """
    Finds and collects even numbers from the provided group of numbers.
    """
    collected_proper_group = []
    for current_group_number in current_group_of_numbers:
        # Check if the current number is perfectly divisible by two.
        if current_group_number % 2 == 0:
            collected_proper_group.append(current_group_number)
    return collected_proper_group