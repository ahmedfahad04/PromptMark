def remove_nested(original_tuple_collection: tuple) -> tuple:
    # Prepare a collection for non-tuple components.
    processed_list_collection = []

    # Loop over original_tuple_collection to process each component.
    for current_object_component in original_tuple_collection:
        # Check if the current_object_component is not a tuple.
        if not isinstance(current_object_component, tuple):
            # Collect non-tuple components.
            processed_list_collection.append(current_object_component)

    # Convert the collection to a tuple prior to returning.
    return tuple(processed_list_collection)