def remove_dirty_chars(original_text: str, chars_to_remove: str) -> str:
    # Populating prune_chars_collection. Quick lookups.
    pruning_chars_collection = frozenset(chars_to_remove)

    # Clean characters list.
    clean_output_list = []

    # Looping through text chars.
    for current_char in original_text:
        # Checking current char; not in collection?
        if current_char not in pruning_chars_collection:
            clean_output_list.append(current_char)

    # Joining clean chars.
    return "".join(clean_output_list)