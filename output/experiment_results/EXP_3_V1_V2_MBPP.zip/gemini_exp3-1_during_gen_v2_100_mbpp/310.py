def string_to_tuple(p_content_text):
    """Converts a given string to a tuple of characters.

    This function processes the input string to generate a new tuple.
    """
    g_list_of_chars = []  # Generates a list for characters.
    for c_char in p_content_text:  # Processes each character from the input text.
        g_list_of_chars.append(c_char)  # Joins the character to the current list.
    
    q_output_tuple = tuple(g_list_of_chars)  # Constructs the final tuple.
    return q_output_tuple