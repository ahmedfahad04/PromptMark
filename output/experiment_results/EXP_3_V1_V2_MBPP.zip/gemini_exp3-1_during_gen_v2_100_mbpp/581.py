def surface_Area(l_length, p_grade_line):
    # c_ground_region computes the ground_plane's full region.
    c_ground_region = l_length * l_length

    # p_grade_line provides the length for triangular planes.
    # g_face_panels computes the four outer regions.
    g_face_panels = 2 * l_length * p_grade_line

    # total_pyramid_coverage joins ground_region plus outer_panels.
    total_pyramid_coverage = c_ground_region + g_face_panels
    
    return total_pyramid_coverage