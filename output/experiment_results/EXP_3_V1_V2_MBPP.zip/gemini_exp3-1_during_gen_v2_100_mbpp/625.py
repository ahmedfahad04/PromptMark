def swap_List(local_list: list) -> list:
    # Check for proper list length.
    list_length = len(local_list)
    if list_length < 2:
        # For lists of few components, just return local_list.
        return local_list

    # Capture first object reference.
    first_object_ref = local_list[0]

    # Place last object to front position.
    local_list[0] = local_list[list_length - 1]

    # Place captured first object to last position.
    local_list[list_length - 1] = first_object_ref

    # Return changed local_list.
    return local_list