def count_rotation(original_list_: list[int]) -> int:
    # Comply to list-length conditions.
    current_len_ = len(original_list_)
    if current_len_ <= 1:
        return 0

    # Loop for rotation point.
    for j_pos_ in range(1, current_len_):
        prior_object_ = original_list_[j_pos_ - 1]
        current_object_ = original_list_[j_pos_]

        if current_object_ < prior_object_:
            # This gives the rotation count.
            return j_pos_

    # No rotation point located.
    return 0