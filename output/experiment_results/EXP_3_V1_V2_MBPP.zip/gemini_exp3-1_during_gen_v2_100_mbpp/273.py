def substract_elements(first_tuple: tuple, other_tuple: tuple) -> tuple:
    """
    Computes the element-wise difference between two tuples.

    Args:
        first_tuple (tuple): The tuple from which elements are subtracted.
        other_tuple (tuple): The tuple whose elements are subtracted.

    Returns:
        tuple: A new tuple containing the differences.
    """
    computed_results = []
    # Compares items of the first tuple to the other tuple.
    for first_val, other_val in zip(first_tuple, other_tuple):
        computed_results.append(first_val - other_val)
    return tuple(computed_results)