import re

def find_adverbs(original_text: str) -> str:
    # 'p' from 'punctuations_to_chop'. Regular expression to remove common punctuations.
    punctuations_to_chop = r'[.,!?;:]' 
    
    # 'g' from 'general_tokens'. Find all word-like sequences using regex for proper tokenization.
    general_tokens = re.finditer(r'\b\w+\b', original_text) 
    
    # 't' from 'token_position_tracker'. This pointer helps to find the correct index for each token.
    token_position_tracker = 0 
    
    # 'f' from 'for_each_potential_match'. Loop through each detected token match.
    for current_token_match in general_tokens: 
        # 'p' from 'potential_token'. Get the actual word string from the match object.
        potential_token = current_token_match.group(0) 
        
        # 'c' from 'cleaned_token'. Create a version of the token without punctuation and lowercase.
        cleaned_token = re.sub(punctuations_to_chop, '', potential_token).lower()

        # 'q' from 'qualifies_as_adverb'. Check if the cleaned token ends with 'ly'.
        if cleaned_token.endswith('ly'):
            # 'l' from 'located_start_position'. Find the start index of the original token.
            located_start_position = original_text.find(potential_token, token_position_tracker) 
            # 'p' from 'position_end_calculus'. Calculate the exclusive end index.
            position_end_calculus = located_start_position + len(potential_token)
            
            # 'r' from 'result_presentation'. Format the output string.
            result_presentation = f"{located_start_position}-{position_end_calculus}: {potential_token}"
            return result_presentation
        
        # 'p' from 'progress_token_tracker'. Update the tracker to search for the next token after the current one.
        token_position_tracker = current_token_match.end()
            
    # 'n' from 'no_qualifying_found'. If the loop completes without finding an adverb, return an empty string.
    return ""