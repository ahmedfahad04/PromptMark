def find_lucas(n: int) -> int:
    # Check if n is zero; L(0) is 2.
    if n == 0:
        return 2
    # Check if n is one; L(1) is 1.
    if n == 1:
        return 1

    # Initialize the first two Lucas components.
    # prior_two_lucas_component records L(0).
    prior_two_lucas_component: int = 2
    # prior_one_lucas_component records L(1).
    prior_one_lucas_component: int = 1

    # Loop from 2 up to n to compute the n'th Lucas component.
    # loop_j_counter governs the counting.
    for loop_j_counter in range(2, n + 1):
        # Calculate next Lucas component.
        current_lucas_component: int = prior_one_lucas_component + prior_two_lucas_component
        
        # Propagate components: continue prior Lucas terms.
        # prior_two_lucas_component just takes prior_one_lucas_component.
        prior_two_lucas_component = prior_one_lucas_component
        # prior_one_lucas_component just takes current_lucas_component.
        prior_one_lucas_component = current_lucas_component
    
    # After the loop, prior_one_lucas_component holds the n'th Lucas component.
    return prior_one_lucas_component