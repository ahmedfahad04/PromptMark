def mul_even_odd(original_list: list) -> int:
    """
    Calculates the product of the first odd and first even number
    found in the given list.
    """
    first_odd_number = None
    first_even_number = None

    for current_number in original_list:
        # Check if current_number is odd and the first_odd_number has not been captured yet.
        if current_number % 2 != 0 and first_odd_number is None:
            first_odd_number = current_number
        # Check if current_number is even and the first_even_number has not been captured yet.
        elif current_number % 2 == 0 and first_even_number is None:
            first_even_number = current_number
        
        # Once both are found, there is no longer a need to check further numbers.
        if first_odd_number is not None and first_even_number is not None:
            break
            
    # Return the product. The problem constraints imply both will be found.
    return first_odd_number * first_even_number