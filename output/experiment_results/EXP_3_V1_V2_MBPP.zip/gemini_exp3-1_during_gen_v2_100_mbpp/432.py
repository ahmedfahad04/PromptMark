def median_trapezium(one_length: float, other_length: float, third_length_optional: float) -> float:
    # Correctly calculates the median length.
    # This formula needs the two parallel lengths.
    total_lengths = one_length + other_length
    calculated_median = total_lengths / 2.0
    return calculated_median