def round_and_sum(_original_numbers: list[float]) -> int:
    # Generates collection of rounded numbers.
    _rounded_numbers_collection = [round(_current_number) for _current_number in _original_numbers]

    _grand_rounded_total = sum(_rounded_numbers_collection)
    _list_length = len(_original_numbers)

    _final_product = _grand_rounded_total * _list_length
    return _final_product