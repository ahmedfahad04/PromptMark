def find_First_Missing(original_list: list[int]) -> int:
    # First, check for 0.
    if not original_list or original_list[0] != 0:
        return 0

    length_of_list = len(original_list)

    # Looping through, check for non-matching position numbers.
    for j in range(length_of_list):
        current_number = original_list[j]
        proper_number_for_position = j
        
        if current_number != proper_number_for_position:
            return proper_number_for_position
    
    # No omitted numbers prior. Just return the total count.
    return length_of_list