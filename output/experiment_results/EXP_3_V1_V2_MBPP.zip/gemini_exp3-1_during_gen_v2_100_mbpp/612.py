def merge(parent_list_of_groups: list[list]) -> list[list]:
    # Confirm for no input groups.
    if not parent_list_of_groups:
        return []
    
    # Confirm for groups of zero length.
    # This handles cases like merge([[], [], []]) resulting in [].
    if not parent_list_of_groups[0]:
        return []

    # Transpose parent list of groups.
    # The zip operator groups corresponding elements from original sublists.
    # For instance, the first elements of all sublists form the first tuple,
    # the second elements form the second tuple, and so forth.
    # Convert tuple groups to lists for the final collection.
    output_collector = [list(content_group) for content_group in zip(*parent_list_of_groups)]
    
    return output_collector