def sequence(n: int) -> int:
    # Conclude for prior, tiny positions.
    if n == 1 or n == 2:
        return 1

    # `progression_list_of_terms` collection contains the terms for the Newman-Conway progression.
    # The list is 1-indexed for closer relation to P(n). `progression_list_of_terms[0]` is a placeholder.
    progression_list_of_terms = [0] * (n + 1)
    progression_list_of_terms[1] = 1
    progression_list_of_terms[2] = 1

    # Compute further terms.
    for current_position_j in range(3, n + 1):
        # P(j) = P(P(j-1)) + P(j-P(j-1))
        prior_computed_j_minus_one_term = progression_list_of_terms[current_position_j - 1]
        
        first_index_lookup = prior_computed_j_minus_one_term
        other_index_for_lookup = current_position_j - prior_computed_j_minus_one_term
        
        progression_term_one = progression_list_of_terms[first_index_lookup]
        other_progression_term = progression_list_of_terms[other_index_for_lookup]
        
        progression_list_of_terms[current_position_j] = progression_term_one + other_progression_term
    
    # Return the target term.
    return progression_list_of_terms[n]