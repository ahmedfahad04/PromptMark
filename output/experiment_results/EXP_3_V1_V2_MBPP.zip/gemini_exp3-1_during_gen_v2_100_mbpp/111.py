def common_in_nested_lists(collection_of_lists: list[list[int]]) -> set[int]:
    # Check for plain collection.
    if not collection_of_lists:
        return set()

    # Get the primary group from the first list.
    current_common_group = set(collection_of_lists[0])

    # Loop through other lists.
    for current_list_group in collection_of_lists[1:]:
        # Perform crossing, narrowing common group.
        current_common_group.intersection_update(set(current_list_group))
        
        # Provided common group got plain.
        if not current_common_group:
            break # No further common portions.

    # Return final common group.
    return current_common_group