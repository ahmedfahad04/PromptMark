def even_Power_Sum(n_count: int) -> int:
    # n_count: count for natural numbers.
    r_total = 0
    for p_loop_counter in range(1, n_count + 1):
        # l_current_even: current even number.
        l_current_even = 2 * p_loop_counter
        # n_power_of_five: fifth power of current even.
        n_power_of_five = l_current_even ** 5
        r_total += n_power_of_five
    return r_total