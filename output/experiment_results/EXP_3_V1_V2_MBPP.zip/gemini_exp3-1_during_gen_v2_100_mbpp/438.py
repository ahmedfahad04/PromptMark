import collections

def count_bidirectional(original_tuples_list: list[tuple[int, int]]) -> int:
    # `original_tuples_frequencies` stores the count of each unique tuple present in the input list.
    # This helps in precisely determining the number of available items for forming bidirectional pairs.
    original_tuples_frequencies = collections.Counter(original_tuples_list)
    
    # `overall_pair_count` will accumulate the final count of bidirectional tuple pairs.
    overall_pair_count = 0
    
    # `processed_pairs_canonical` is a set used to keep track of normalized pairs
    # (e.g., (min_val, max_val)) that have already been considered. This prevents
    # double-counting when `(x, y)` and `(y, x)` are distinct but represent the same
    # bidirectional relationship.
    processed_pairs_canonical = set()
    
    # Iterate through each unique tuple that was present in the original input list.
    for current_item_tuple in original_tuples_frequencies:
        first_component, second_component = current_item_tuple
        # `reversed_item_tuple` represents the potential counterpart for a bidirectional pair.
        reversed_item_tuple = (second_component, first_component)
        
        # `canonical_pair_form` ensures that a pair like (5, 6) and (6, 5) is always identified
        # by the same key (e.g., (5, 6) after sorting).
        canonical_pair_form = tuple(sorted(current_item_tuple))
        
        # If this canonical pair has already been processed, skip to avoid redundant calculations.
        if canonical_pair_form in processed_pairs_canonical:
            continue
            
        # Check if the reversed tuple exists in the list of original tuples (using its frequency map).
        if reversed_item_tuple in original_tuples_frequencies:
            # Mark this canonical pair as processed to prevent future double-counting.
            processed_pairs_canonical.add(canonical_pair_form)
            
            # If the tuple is not self-reversed (e.g., (1, 2) where 1 != 2),
            # the number of bidirectional pairs that can be formed is limited by the minimum
            # occurrences of the two complementary tuples (e.g., min(count((1,2)), count((2,1)))).
            if first_component != second_component:
                overall_pair_count += min(original_tuples_frequencies[current_item_tuple], 
                                         original_tuples_frequencies[reversed_item_tuple])
            else:
                # If the tuple is self-reversed (e.g., (7, 7)), each occurrence of it
                # inherently forms a bidirectional pair with itself.
                overall_pair_count += original_tuples_frequencies[current_item_tuple]
                
    return overall_pair_count