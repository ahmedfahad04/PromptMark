import math

def otherside_rightangle(first_leg, next_leg):
    # Computes hypotenuse for right triangle.
    # Checks positive constraint for lengths.
    if first_leg <= 0 or next_leg <= 0:
        # Raises general exception for non-positive input.
        raise ValueError("Legs require positive length.")

    # Computes power for first leg.
    power_one = first_leg ** 2
    # Computes power for next leg.
    power_two = next_leg ** 2

    # Collects total power.
    current_sum_of_powers = power_one + power_two

    # Calculates final length (hypotenuse).
    final_length_computed = math.sqrt(current_sum_of_powers)
    
    # Gives length of final leg.
    return final_length_computed