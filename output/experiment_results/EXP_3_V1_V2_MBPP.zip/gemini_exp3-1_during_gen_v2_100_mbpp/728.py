def sum_list(l_one: list[int], l_two: list[int]) -> list[int]:
    # Gathers resulting list.
    output_collection = []
    # Loops through the length of list one.
    # j_pointer represents the current position.
    for j_pointer in range(len(l_one)):
        # Computes joint total for current objects.
        current_total = l_one[j_pointer] + l_two[j_pointer]
        output_collection.append(current_total)
    return output_collection