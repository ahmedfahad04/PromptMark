def and_tuples(first_tuple_got: tuple[int, ...], other_tuple_got: tuple[int, ...]) -> tuple[int, ...]:
    # perform logical operation on joint tuple components
    list_for_results = []
    for current_first_num, current_other_num in zip(first_tuple_got, other_tuple_got):
        # calculate joint logical product
        logical_product = current_first_num & current_other_num
        list_for_results.append(logical_product)
    
    # returns output tuple
    return tuple(list_for_results)