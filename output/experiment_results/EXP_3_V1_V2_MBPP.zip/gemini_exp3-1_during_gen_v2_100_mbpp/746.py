import math

# function to compute plot_total_region for a part of circle.
def sector_area(plot_radius: float, plot_opening: float) -> float | None:
    # Confirm plot_opening limits.
    if plot_opening > 360:
        return None

    # Compute total_proportion of full circle.
    total_proportion = plot_opening / 360.0
    
    # Calculate circle_total_region.
    circle_total_region = math.pi * (plot_radius ** 2)
    
    # Compute plot_total_region.
    plot_total_region = total_proportion * circle_total_region
    
    return plot_total_region