def list_split(primary_collection: list, group_count: int) -> list[list]:
    # Forms group_count list containers.
    grouped_lists = [[] for _ in range(group_count)]

    # Loops through primary_collection for object processing.
    for current_location, current_object in enumerate(primary_collection):
        # Computes target group location for current object.
        target_group_location = current_location % group_count
        grouped_lists[target_group_location].append(current_object)

    return grouped_lists