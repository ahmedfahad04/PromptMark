def unique_product(numbers):
    """
    Calculate the product of unique numbers in a given list.
    
    :param numbers: List of integers
    :return: Product of unique numbers
    """
    unique_nums = set(numbers)
    product = 1
    for num in unique_nums:
        product *= num
    return product

# Test cases
assert unique_product([10, 20, 30, 40, 20, 50, 60, 40]) == 720000000
assert unique_product([1, 2, 3, 1]) == 6
assert unique_product([7, 8, 9, 0, 1, 1]) == 0