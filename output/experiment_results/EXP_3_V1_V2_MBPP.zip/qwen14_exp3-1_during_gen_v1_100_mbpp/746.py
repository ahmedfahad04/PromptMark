def c_area(l_radius, l_angle):
    """
    Calculate the area of a sector given the radius and angle.
    
    :param l_radius: float, the radius of the circle
    :param l_angle: float, the angle of the sector in degrees
    :return: float or None, the area of the sector or None if angle > 360
    
    >>> c_area(4, 45)
    6.283185307179586
    >>> c_area(9, 45)
    31.808625617596654
    >>> c_area(9, 361)
    None
    """
    import math
    if l_angle > 360:
        return None
    else:
        l_sector_area = (math.pi * l_radius ** 2) * (l_angle / 360)
        return l_sector_area