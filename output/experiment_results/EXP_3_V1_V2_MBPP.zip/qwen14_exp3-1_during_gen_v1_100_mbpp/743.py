def rotate_right(lst, n):
    """
    Rotate the given list `lst` by `n` positions to the right.

    Parameters:
    lst (list): The input list to be rotated.
    n (int): Number of positions to rotate the list to the right.

    Returns:
    list: The rotated list.
    """
    if not lst or n <= 0:
        return lst
    
    # Normalize n to avoid unnecessary rotations
    n = n % len(lst)
    
    # Perform rotation
    return lst[-n:] + lst[:-n]