def count_vowels(s):
    # Define the set of vowels
    vowels = set('aeiouAEIOU')
    
    # Initialize the count of vowels with valid neighbors
    count = 0
    
    # Iterate through the string, except the first and last characters
    for i in range(1, len(s) - 1):
        # Check if the current character is a vowel
        if s[i] in vowels:
            # Check if the neighboring characters are not vowels
            if s[i-1] not in vowels and s[i+1] not in vowels:
                count += 1
                
    # Check the first character
    if len(s) > 1 and s[0] in vowels and s[1] not in vowels:
        count += 1
        
    # Check the last character
    if len(s) > 1 and s[-1] in vowels and s[-2] not in vowels:
        count += 1
        
    return count