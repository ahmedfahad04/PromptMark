def extract_quotation(text):
    """
    Extracts values between quotation marks " " from the given text.
    
    :param text: Input string containing quoted values.
    :return: A list of strings extracted from the input text within quotes.
    """
    result = []
    start_index = None
    
    for index, char in enumerate(text):
        if char == '"' and start_index is None:
            start_index = index + 1
        elif char == '"' and start_index is not None:
            result.append(text[start_index:index])
            start_index = None
            
    return result


# Test cases
assert extract_quotation('Cortex "A53" Based "multi" tasking "Processor"') == ['A53', 'multi', 'Processor']
assert extract_quotation('Cast your "favorite" entertainment "apps"') == ['favorite', 'apps']
assert extract_quotation('Watch content "4k Ultra HD" resolution with "HDR 10" Support') == ['4k Ultra HD', 'HDR 10']
assert extract_quotation("Watch content '4k Ultra HD' resolution with 'HDR 10' Support") == []