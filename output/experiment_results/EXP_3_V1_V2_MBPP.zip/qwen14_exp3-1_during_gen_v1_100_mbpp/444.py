def trim_tuple(tuples_list, k):
    # Trim each tuple in the list starting from index k
    trimmed_tuples = [tuple(t[k:]) for t in tuples_list]
    return str(trimmed_tuples)