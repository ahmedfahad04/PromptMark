def mul_even_odd(lst):
    # Find the first even number
    first_even = None
    for num in lst:
        if num % 2 == 0:
            first_even = num
            break
    
    # Find the first odd number
    first_odd = None
    for num in lst:
        if num % 2 != 0:
            first_odd = num
            break
    
    # Calculate the product of the first even and odd numbers
    product = first_even * first_odd if first_even is not None and first_odd is not None else None
    
    return product