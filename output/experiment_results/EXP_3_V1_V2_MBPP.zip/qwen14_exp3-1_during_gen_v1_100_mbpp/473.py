def tuple_intersection(tup1, tup2):
    # Convert each tuple in the lists to a sorted set to ensure unordered comparison
    set1 = {tuple(sorted(t)) for t in tup1}
    set2 = {tuple(sorted(t)) for t in tup2}
    
    # Find the intersection of both sets
    result = set1.intersection(set2)
    
    # Return the result as a set of tuples
    return result