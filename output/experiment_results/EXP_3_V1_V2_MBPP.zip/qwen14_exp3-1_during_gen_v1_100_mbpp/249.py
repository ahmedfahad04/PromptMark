def intersection_array(arr1, arr2):
    # Convert both arrays to sets to remove duplicates and perform fast membership testing
    set1 = set(arr1)
    set2 = set(arr2)
    
    # Find the intersection of the two sets
    intersect_set = set1 & set2
    
    # Convert the resulting set back to a list
    result = list(intersect_set)
    
    return result