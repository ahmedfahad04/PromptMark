def loss_amount(selling_price, cost_price):
    # Check if selling price is less than cost price
    if selling_price < cost_price:
        # Return the difference between cost price and selling price
        return cost_price - selling_price
    else:
        # Return 0 if there's no loss
        return 0