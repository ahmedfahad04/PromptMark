def toggle_middle_bits(n):
    # Convert the number to binary string without the '0b' prefix
    bin_str = bin(n)[2:]
    
    # Calculate the length of the binary representation
    num_bits = len(bin_str)
    
    # Check if the number has less than 3 bits
    if num_bits < 3:
        return n
    
    # Create a mask to toggle all middle bits
    # For example, for 7 bits (111), the mask would be 1101110
    mask = int('1' + '0' * (num_bits - 2) + '1', 2)
    
    # Toggle the middle bits using XOR operation
    result = n ^ mask
    
    return result