def test_three_equal(a, b, c):
    # Calculate the number of unique values using a set
    unique_values = {a, b, c}
    # The number of equal numbers is the difference between 3 and the number of unique values
    return 3 - len(unique_values)