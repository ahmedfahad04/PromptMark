def occurance_substring(text, substring):
    # Check if the substring exists in the text
    if substring not in text:
        return None
    
    # Find the starting index of the first occurrence of the substring
    start_index = text.find(substring)
    
    # Calculate the end index based on the length of the substring
    end_index = start_index + len(substring)
    
    # Return the matched substring along with its start and end indices
    return (substring, start_index, end_index)