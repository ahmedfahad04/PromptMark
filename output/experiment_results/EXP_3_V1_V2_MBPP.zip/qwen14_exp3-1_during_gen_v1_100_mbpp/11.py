def remove_Occ(s, ch):
    # Find the index of the first occurrence of ch
    first_index = s.find(ch)
    
    # Find the index of the last occurrence of ch
    last_index = s.rfind(ch)
    
    # Remove the characters at the found indices if they exist
    if first_index != -1 and last_index != -1 and first_index != last_index:
        result = s[:first_index] + s[first_index+1:last_index] + s[last_index+1:]
    elif first_index != -1 and last_index == -1:
        result = s[:first_index] + s[first_index+1:]
    elif first_index == -1 and last_index != -1:
        result = s[:last_index]
    else:
        result = s
    
    return result