def start_withp(words):
    p_words = []
    for word in words:
        for sub_word in word.split():
            if sub_word.lower().startswith('p'):
                p_words.append(sub_word)
                if len(p_words) == 2:
                    break
        if len(p_words) == 2:
            break
    return tuple(p_words)

# Test cases
assert start_withp(["Python PHP", "Java JavaScript", "c c++"]) == ('Python', 'PHP')
assert start_withp(["Python Programming","Java Programming"]) == ('Python', 'Programming')
assert start_withp(["Pqrst Pqr","qrstuv"]) == ('Pqrst', 'Pqr')