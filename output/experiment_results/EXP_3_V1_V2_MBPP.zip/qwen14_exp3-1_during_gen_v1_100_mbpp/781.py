def count_divisors(n):
    # Initialize divisor count
    count = 0
    
    # Loop through all numbers from 1 to n
    for i in range(1, int(n**0.5) + 1):
        if n % i == 0:
            # Increment count if i is a divisor
            count += 1
            # Check if both divisors are different and increment count again
            if i != n // i:
                count += 1
                
    # Return True if count is even, else False
    return count % 2 == 0