def add_to_result(result, current_dict):
    for key, value in current_dict.items():
        if key in result:
            raise ValueError(f"Different values for key '{key}'")
        result[key] = value

def merge_dictionaries_three(dict1, dict2, dict3):
    result = {}
    add_to_result(result, dict1)
    add_to_result(result, dict2)
    add_to_result(result, dict3)
    return result