def average_tuple(tuples):
    """
    This function calculates the average of each tuple within a list of tuples.
    :param tuples: A list of tuples containing numerical values.
    :return: A list of floats representing the average of each tuple.
    """
    result = []
    for t in tuples:
        avg = sum(t) / len(t)
        result.append(avg)
    return result