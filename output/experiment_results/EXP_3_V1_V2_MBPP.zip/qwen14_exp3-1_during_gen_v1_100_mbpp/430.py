def parabola_directrix(a, b, c):
    # Calculate the directrix using the formula -1/(4*a) + (b**2 - 4*a*c)/(-4*a)
    directrix = -1 / (4 * a) + (b ** 2 - 4 * a * c) / (-4 * a)
    return directrix