def union_elements(tup1, tup2):
    # Combine both tuples into one set to remove duplicates and then convert it back to tuple
    result = tuple(sorted(set(tup1 + tup2)))
    return result