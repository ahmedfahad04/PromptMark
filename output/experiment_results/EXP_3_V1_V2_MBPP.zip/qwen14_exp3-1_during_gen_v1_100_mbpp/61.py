def count_Substrings(s):
    def digit_sum(n):
        """Calculate the sum of digits of an integer."""
        return sum(int(digit) for digit in str(n))
    
    total_count = 0
    
    for i in range(len(s)):
        current_sum = 0
        for j in range(i, len(s)):
            current_sum += int(s[j])
            if current_sum == j - i + 1:
                total_count += 1
                
    return total_count