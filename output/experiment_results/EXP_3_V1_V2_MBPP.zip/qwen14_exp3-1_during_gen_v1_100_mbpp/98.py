import math

def multiply_num(numbers):
    # Initialize product to 1 since multiplying by 1 has no effect
    product = 1
    
    # Multiply each number in the list
    for num in numbers:
        product *= num
    
    # Divide the product by the length of the list
    result = product / len(numbers)
    
    return result