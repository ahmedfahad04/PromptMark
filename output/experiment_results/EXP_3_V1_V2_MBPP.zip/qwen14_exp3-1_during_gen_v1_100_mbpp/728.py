def add_lists(l1, l2):
    result = []
    for i in range(len(l1)):
        result.append(l1[i] + l2[i])
    return result