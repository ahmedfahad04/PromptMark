def power(a, b):
    # Calculate the power using the built-in pow function for simplicity and efficiency
    result = pow(a, b)
    return result