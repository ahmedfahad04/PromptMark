def check_value(dct, value):
    # Check if all values in the dictionary are equal to the given value
    for key in dct:
        if dct[key] != value:
            return False
    return True