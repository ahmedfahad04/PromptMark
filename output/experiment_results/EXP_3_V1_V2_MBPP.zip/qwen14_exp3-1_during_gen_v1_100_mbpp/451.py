def remove_whitespaces(jstring):
    # Use list comprehension to filter out whitespace characters and join them back into a string
    clean_string = ''.join([char for char in jstring if char != ' '])
    return clean_string