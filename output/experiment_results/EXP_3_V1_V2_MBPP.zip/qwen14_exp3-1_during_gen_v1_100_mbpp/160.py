from math import gcd

def extended_gcd(a, b):
    """Extended Euclidean Algorithm to find x and y such that ax + by = gcd(a, b)"""
    if a == 0:
        return b, 0, 1
    else:
        g, x, y = extended_gcd(b % a, a)
        return g, y - (b // a) * x, x

def find_solution(a, b, n):
    """Find integers x and y such that ax + by = n"""
    # Calculate the GCD of a and b
    d = gcd(a, b)
    
    # Check if n is divisible by the GCD
    if n % d != 0:
        return None
    
    # Find the initial solution using the Extended Euclidean Algorithm
    _, x, y = extended_gcd(a, b)
    
    # Scale the solution to match the required value of n
    x *= n // d
    y *= n // d
    
    return (x, y)