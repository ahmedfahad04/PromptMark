def surface_Area(base_edge, height):
    # Calculate the area of the base
    base_area = base_edge ** 2
    
    # Calculate the slant height using Pythagorean theorem
    slant_height = ((base_edge / 2) ** 2 + height ** 2) ** 0.5
    
    # Calculate the lateral face area
    lateral_face_area = base_edge * slant_height
    
    # Total surface area is the sum of the base area and the four lateral faces
    total_surface_area = base_area + 4 * lateral_face_area
    
    return total_surface_area