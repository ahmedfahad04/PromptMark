def rear_extract(tuples_list):
    """
    Extracts the last element from each tuple in the input list of tuples.
    
    :param tuples_list: A list of tuples where each tuple contains at least three elements.
    :return: A list of integers representing the last element of each tuple.
    """
    result = []
    for tup in tuples_list:
        # Append the last element of the current tuple to the result list
        result.append(tup[-1])
    return result


# Test cases
assert rear_extract([(1, 'Rash', 21), (2, 'Varsha', 20), (3, 'Kil', 19)]) == [21, 20, 19]
assert rear_extract([(1, 'Sai', 36), (2, 'Ayesha', 25), (3, 'Salman', 45)]) == [36, 25, 45]
assert rear_extract([(1, 'Sudeep', 14), (2, 'Vandana', 36), (3, 'Dawood', 56)]) == [14, 36, 56]