def count_X(tup, x):
    # Initialize counter to zero
    count = 0
    
    # Iterate through each element in the tuple
    for element in tup:
        # Increment counter if the current element matches the target element
        if element == x:
            count += 1
            
    # Return the final count after iterating through all elements
    return count