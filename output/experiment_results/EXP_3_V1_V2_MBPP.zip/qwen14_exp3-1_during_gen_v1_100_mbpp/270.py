def sum_even_and_even_index(numbers):
    # Initialize the sum variable to store the result
    total = 0
    
    # Iterate through the list using index
    for i in range(0, len(numbers), 2):
        # Check if the number at the current even index is even
        if numbers[i] % 2 == 0:
            # Add it to the total sum
            total += numbers[i]
    
    # Return the final sum
    return total

# Test cases
assert sum_even_and_even_index([5, 6, 12, 1, 18, 8]) == 30
assert sum_even_and_even_index([3, 20, 17, 9, 2, 10, 18, 13, 6, 18]) == 26
assert sum_even_and_even_index([5, 6, 12, 1]) == 12