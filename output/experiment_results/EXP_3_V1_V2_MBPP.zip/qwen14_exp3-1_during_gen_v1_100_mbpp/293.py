import math

def otherside_rightangle(a, b):
    """
    Calculate the third side of a right-angled triangle using the Pythagorean theorem.
    
    :param a: One side of the triangle
    :param b: Another side of the triangle
    :return: The length of the third side
    """
    # Determine which side is the hypotenuse and which is the other side
    if a == 0 or b == 0:
        raise ValueError("At least one side must be non-zero")
    
    c = math.sqrt(a**2 + b**2)
    return round(c, 9)

# Test cases
assert otherside_rightangle(7, 8) == 10.63014581273465
assert otherside_rightangle(3, 4) == 5
assert otherside_rightangle(7, 15) == 16.55294535724685