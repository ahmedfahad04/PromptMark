def subject_marks(subject_list):
    # Sort the list of tuples based on the second element of each tuple
    sorted_list = sorted(subject_list, key=lambda x: x[1])
    return sorted_list