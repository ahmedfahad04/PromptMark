def move_num(text):
    # Initialize an empty list to store non-numeric characters
    result = []
    
    # Iterate through each character in the input text
    for char in text:
        # Check if the character is numeric
        if not char.isdigit():
            # Append non-numeric characters to the result list
            result.append(char)
    
    # Initialize an empty list to store numeric characters
    nums = []
    
    # Iterate through each character in the input text again
    for char in text:
        # Check if the character is numeric
        if char.isdigit():
            # Append numeric characters to the nums list
            nums.append(char)
    
    # Join the lists into a single string and return it
    return ''.join(result + nums)

# Test cases
assert move_num('I1love143you55three3000thousand') == 'Iloveyouthreethousand1143553000'
assert move_num('Avengers124Assemble') == 'AvengersAssemble124'
assert move_num('Its11our12path13to14see15things16do17things') == 'Itsourpathtoseethingsdothings11121314151617'