def max_product(nums):
    if not nums:
        return 0
    
    # Initialize variables to store the maximum and minimum products up to the current position
    max_product = [nums[0]] * len(nums)
    min_product = [nums[0]] * len(nums)
    
    # Start from the second element since we already initialized the first one
    for i in range(1, len(nums)):
        # Calculate the new max and min products considering the previous max and min
        max_product[i] = max(max_product[i-1] * nums[i], min_product[i-1] * nums[i], nums[i])
        min_product[i] = min(max_product[i-1] * nums[i], min_product[i-1] * nums[i], nums[i])
    
    # Return the maximum value from the max_product list
    return max(max_product)

# Justification Points:
# - We use dynamic programming to keep track of the maximum and minimum products at each index.
# - This handles both positive and negative numbers effectively.
# - The final result is obtained by finding the maximum value in the max_product list.