def find(numerator, denominator):
    # Calculate the quotient of numerator divided by denominator using floor division
    quotient = numerator // denominator
    return quotient