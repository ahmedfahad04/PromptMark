def count_bidirectional(pairs):
    # Create a dictionary to store the frequency of each tuple and its reverse
    pair_count = {}
    for x, y in pairs:
        key1 = (x, y)
        key2 = (y, x)
        if key1 in pair_count:
            pair_count[key1] += 1
        elif key2 in pair_count:
            pair_count[key2] += 1
        else:
            pair_count[key1] = 1
    
    # Count the number of bidirectional pairs
    bidirectional_pairs = sum(1 for k, v in pair_count.items() if v > 1)
    return bidirectional_pairs