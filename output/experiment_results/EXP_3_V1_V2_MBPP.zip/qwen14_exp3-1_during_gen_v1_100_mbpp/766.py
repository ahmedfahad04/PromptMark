def g_i_l_r_pair_wise(lst):
    """
    Generate a list of tuples containing pairs of consecutive elements from the input list.
    
    :param lst: List of elements
    :return: List of tuple pairs of consecutive elements
    """
    result = []
    for i in range(len(lst) - 1):
        result.append((lst[i], lst[i + 1]))
    return result