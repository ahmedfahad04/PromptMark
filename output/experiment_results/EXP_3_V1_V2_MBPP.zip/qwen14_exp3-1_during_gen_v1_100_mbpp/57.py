def find_Max_Num(digits):
    # Sort the digits in descending order to form the largest number
    digits.sort(reverse=True)
    
    # Convert the sorted digits into a single integer
    max_num = int(''.join(map(str, digits)))
    
    return max_num