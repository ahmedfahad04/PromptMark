def extract_string(strings, size):
    """
    Extracts and returns strings of a specific size from the given list.
    
    :param strings: List of string values.
    :param size: The exact size of strings to be extracted.
    :return: A list containing strings of the specified size.
    """
    result = [word for word in strings if len(word) == size]
    return result