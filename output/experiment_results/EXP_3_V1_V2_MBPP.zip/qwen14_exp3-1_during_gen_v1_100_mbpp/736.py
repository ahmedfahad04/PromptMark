def left_insertion(green_list, red_value):
    """
    Locate the left insertion point for a specified value in sorted order.
    
    :param green_list: list of integers in sorted order
    :param red_value: integer value to insert
    :return: index at which the value should be inserted
    
    >>> left_insertion([1, 2, 4, 5], 6)
    4
    >>> left_insertion([1, 2, 4, 5], 3)
    2
    >>> left_insertion([1, 2, 4, 5], 7)
    4
    """
    low = 0
    high = len(green_list)
    while low < high:
        mid = (low + high) // 2
        if green_list[mid] < red_value:
            low = mid + 1
        else:
            high = mid
    return low