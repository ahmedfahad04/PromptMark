def reverse_string_list(strings):
    """
    Reverses each string in the input list.
    
    :param strings: List of strings to be reversed
    :return: List of reversed strings
    """
    reversed_strings = []
    for s in strings:
        reversed_strings.append(s[::-1])  # Reverse the string using slicing
    return reversed_strings

# Test cases
assert reverse_string_list(['Red', 'Green', 'Blue', 'White', 'Black']) == ['deR', 'neerG', 'eulB', 'etihW', 'kcalB']
assert reverse_string_list(['john', 'amal', 'joel', 'george']) == ['nhoj', 'lama', 'leoj', 'egroeg']
assert reverse_string_list(['jack', 'john', 'mary']) == ['kcaj', 'nhoj', 'yram']