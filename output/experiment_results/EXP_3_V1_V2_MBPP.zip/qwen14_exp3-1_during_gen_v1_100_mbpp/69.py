def is_sublist(main_list, sub_list):
    # Check if the main list is shorter than the sublist
    if len(main_list) < len(sub_list):
        return False
    
    # Iterate through the main list up to the point where the sublist could still fit
    for i in range(len(main_list) - len(sub_list) + 1):
        # Check if the current slice of main_list matches the sub_list
        if main_list[i:i+len(sub_list)] == sub_list:
            return True
    
    return False