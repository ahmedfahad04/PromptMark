def substract_elements(tup1, tup2):
    # Check if both tuples have the same length
    if len(tup1) != len(tup2):
        raise ValueError("Tuples must have the same length")
    
    result = ()
    for i in range(len(tup1)):
        # Subtract corresponding elements of the tuples
        result += (tup1[i] - tup2[i], )
    return result