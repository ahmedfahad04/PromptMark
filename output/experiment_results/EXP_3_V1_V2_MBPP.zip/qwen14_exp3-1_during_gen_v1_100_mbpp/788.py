def new_tuple(words_list, word):
    """
    Create a new tuple by combining elements from a list and a string.
    
    :param words_list: List of strings
    :param word: String to combine with the list elements
    :return: Tuple containing elements from the list followed by the string
    """
    # Combine the list elements with the string
    result = (*words_list, word)
    return result