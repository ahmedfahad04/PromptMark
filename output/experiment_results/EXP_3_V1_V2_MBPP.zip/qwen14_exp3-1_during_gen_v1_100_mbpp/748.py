def capital_words_spaces(text):
    result = ""
    for i, char in enumerate(text):
        if char.isupper() and i != 0:
            result += " "
        result += char
    return result

# Test cases
assert capital_words_spaces("Python") == 'Python'
assert capital_words_spaces("PythonProgrammingExamples") == 'Python Programming Examples'
assert capital_words_spaces("GetReadyToBeCodingFreak") == 'Get Ready To Be Coding Freak'