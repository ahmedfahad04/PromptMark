def comb_sort(arr):
    # Initialize the gap size to the length of the array
    gap = len(arr)
    # The shrink factor for the gap size
    shrink_factor = 1.3
    # Flag to check if a swap occurred in the current pass
    swapped = True
    
    # Keep running until the gap is 1 and no swaps occurred in the last pass
    while gap > 1 or swapped:
        # Update the gap value for this pass
        gap = max(1, int(gap / shrink_factor))
        swapped = False
        
        # Perform a single pass of bubble sort
        for i in range(len(arr) - gap):
            j = i + gap
            # Swap if the current element is greater than the next element
            if arr[i] > arr[j]:
                arr[i], arr[j] = arr[j], arr[i]
                swapped = True
    return arr