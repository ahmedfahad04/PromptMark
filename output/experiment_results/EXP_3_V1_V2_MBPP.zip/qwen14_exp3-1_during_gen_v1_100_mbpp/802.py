def count_rotation(arr):
    # Find the index of the minimum element which will give the number of rotations
    min_index = arr.index(min(arr))
    return min_index + 1 if min_index != 0 else 0

# Test cases
assert count_rotation([3,2,1]) == 1
assert count_rotation([4,5,1,2,3]) == 2
assert count_rotation([7,8,9,1,2,3]) == 3
assert count_rotation([1,2,3]) == 0
assert count_rotation([1,3,2]) == 2