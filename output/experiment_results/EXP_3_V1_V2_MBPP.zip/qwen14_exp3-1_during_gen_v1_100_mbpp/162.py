def sum_series(n):
    # Initialize the result variable to store the sum
    total_sum = 0
    
    # Loop through each value of i from 0 to n//2
    for i in range(n // 2 + 1):
        # Calculate the term n - 2*i and add it to the total sum
        total_sum += n - 2 * i
    
    # Return the computed sum
    return total_sum

# Test cases
assert sum_series(6) == 12
assert sum_series(10) == 30
assert sum_series(9) == 25