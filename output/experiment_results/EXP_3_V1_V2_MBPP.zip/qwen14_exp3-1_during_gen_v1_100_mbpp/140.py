def extract_singly(green_lists):
    # Initialize an empty set to store unique elements
    green_set = set()
    
    # Iterate through each sublist in the input list of lists
    for green_list in green_lists:
        # Update the set with all elements from the current sublist
        green_set.update(green_list)
        
    # Return the final set containing all unique elements
    return green_set