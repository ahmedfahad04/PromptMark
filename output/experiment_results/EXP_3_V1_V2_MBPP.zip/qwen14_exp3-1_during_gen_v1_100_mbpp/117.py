def list_to_float(lst):
    # Initialize an empty list to store the converted values
    n_lst = []
    
    # Iterate through each sublist in the input list
    for i in lst:
        # Convert each element in the sublist to float if possible
        try:
            n_lst.append((float(i[0]), float(i[1])))
        except ValueError:
            # Append the original string if conversion fails
            n_lst.append((i[0], i[1]))
    
    return n_lst