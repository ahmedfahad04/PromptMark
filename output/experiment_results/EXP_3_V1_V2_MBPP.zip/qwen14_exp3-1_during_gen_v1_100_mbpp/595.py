def min_Swaps(src, tar):
    # Check if both strings have the same number of '1's
    if src.count('1') != tar.count('1'):
        return "Not Possible"
    
    n = len(src)
    src_idx, tar_idx, swaps = [], [], 0
    
    # Collect indices of '1's in source and target strings
    for i in range(n):
        if src[i] == '1':
            src_idx.append(i)
        if tar[i] == '1':
            tar_idx.append(i)
    
    # Perform swaps to make source match target
    while src_idx and tar_idx:
        s = src_idx.pop(0)
        t = tar_idx.pop(0)
        
        # If current positions already match, continue
        if s < t:
            continue
        
        # Swap elements until they match
        for j in range(s, t, -1):
            src = src[:j-1] + src[j] + src[j-1:j] + src[j+1:]
            swaps += 1
    
    return swaps