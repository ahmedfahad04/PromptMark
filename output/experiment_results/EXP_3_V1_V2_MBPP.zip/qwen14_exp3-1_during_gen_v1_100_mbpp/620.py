def gcd(a, b):
    while b:
        a, b = b, a % b
    return a

def largest_subset(nums):
    if len(nums) <= 1:
        return len(nums)
    
    # Sort the array to handle smaller numbers first
    nums.sort()
    
    # Dictionary to store the maximum subset size for each remainder
    memo = {num: 1 for num in nums}
    
    for i in range(len(nums)):
        for j in range(i + 1, len(nums)):
            if nums[j] % nums[i] == 0:
                memo[nums[j]] = max(memo.get(nums[j], 0), memo[nums[i]] + 1)
            elif gcd(nums[i], nums[j]) == nums[i]:
                memo[nums[j]] = max(memo.get(nums[j], 0), memo[nums[i]] + 1)
    
    return max(memo.values())

# Test cases
assert largest_subset([1, 3, 6, 13, 17, 18]) == 4
assert largest_subset([10, 5, 3, 15, 20]) == 3
assert largest_subset([18, 1, 3, 6, 13, 17]) == 4