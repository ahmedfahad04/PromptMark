def find_Element(arr, queries, rotations, target_index):
    # Calculate the effective rotation needed considering multiple rotations
    effective_rotation = (rotations % len(arr)) + sum(query[0] for query in queries)
    
    # Adjust the effective rotation if it exceeds array length
    effective_rotation %= len(arr)
    
    # Find the target index after rotations
    target_index_after_rotations = (target_index - effective_rotation) % len(arr)
    
    # Return the element at the adjusted target index
    return arr[target_index_after_rotations]