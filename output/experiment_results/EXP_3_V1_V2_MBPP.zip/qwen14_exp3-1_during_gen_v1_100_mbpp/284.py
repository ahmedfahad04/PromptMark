def check_element(lst, elem):
    """
    Checks if all elements in the list `lst` are equal to `elem`.
    
    Args:
        lst (list): The input list.
        elem (any): The element to compare against.
        
    Returns:
        bool: True if all elements are equal to `elem`, False otherwise.
    """
    # Check if every item in the list is equal to the given element
    for item in lst:
        if item != elem:
            return False
    return True