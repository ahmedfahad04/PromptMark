def snake_to_camel(snake_str):
    # Split the string by underscores and capitalize each segment
    components = snake_str.split('_')
    # Capitalize the first letter of each component and join them together
    return ''.join(x.capitalize() or '_' for x in components)