def string_to_tuple(input_string):
    # Convert the input string into a tuple of characters
    char_tuple = tuple(input_string)
    return char_tuple