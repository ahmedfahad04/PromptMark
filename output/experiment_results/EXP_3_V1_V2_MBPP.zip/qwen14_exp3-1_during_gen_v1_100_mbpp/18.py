def remove_dirty_chars(original: str, dirty_chars: str) -> str:
    # Initialize an empty result string
    clean_string = ''
    
    # Iterate through each character in the original string
    for char in original:
        # Check if the character is not in the dirty_chars string
        if char not in dirty_chars:
            # Append it to the clean_string if it's not found
            clean_string += char
    
    return clean_string