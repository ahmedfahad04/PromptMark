def find_First_Missing(nums):
    # Start with the expected first missing number as 0
    missing = 0
    
    # Iterate through the list
    for num in nums:
        # Check if the current number does not match the expected value
        if num != missing:
            break
        missing += 1
    
    # The current missing number is the answer
    return missing