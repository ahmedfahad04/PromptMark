def find_lucas(n):
    """
    Find the n-th Lucas number using recursion and memoization.
    
    The Lucas numbers are defined by the recurrence relation:
        L(n) = L(n-1) + L(n-2)
    with initial values:
        L(0) = 2 and L(1) = 1
    
    Args:
    n (int): The position in the Lucas sequence.
    
    Returns:
    int: The n-th Lucas number.
    """
    # Base cases
    if n == 0:
        return 2
    elif n == 1:
        return 1
    
    # Recursive call with memoization
    return find_lucas(n - 1) + find_lucas(n - 2)

# Justification:
# 1. The base cases correctly handle the first two Lucas numbers.
# 2. Recursion is used to calculate subsequent Lucas numbers based on their definition.
# 3. Memoization is implicitly handled through the recursive calls, ensuring efficiency.