def find_adverbs(text):
    # Split the text into words
    words = text.split()
    
    # Find the first adverb ending with 'ly'
    for i, word in enumerate(words):
        if word.endswith('ly'):
            # Calculate the starting index of the adverb
            start_index = len(' '.join(words[:i])) + 1
            # Calculate the end index of the adverb
            end_index = start_index + len(word)
            # Return the formatted result
            return f'{start_index - 1}-{end_index - 1}: {word}'
    # Return None if no adverb is found
    return None

# Test cases
assert find_adverbs("Clearly, he has no excuse for such behavior.") == '0-7: Clearly'
assert find_adverbs("Please handle the situation carefuly") == '28-36: carefuly'
assert find_adverbs("Complete the task quickly") == '18-25: quickly'