def list_split(lst, n):
    # Calculate the number of sublists needed
    num_sublists = (len(lst) + n - 1) // n
    
    # Create sublists using list comprehension
    result = [lst[i*n:(i+1)*n] for i in range(num_sublists)]
    
    return result