def drop_empty(d):
    # Iterate through the dictionary and filter out key-value pairs where the value is None
    result = {k: v for k, v in d.items() if v is not None}
    return result