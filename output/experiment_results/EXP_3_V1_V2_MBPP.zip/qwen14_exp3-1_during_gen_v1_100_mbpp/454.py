import re

def text_match_wordz(text):
    """
    Checks if the input text contains a word ending with 'z'.
    
    Args:
        text (str): The input text to check.
        
    Returns:
        bool: True if a word ending with 'z' is found, False otherwise.
    """
    pattern = r'\b\w*z\b'
    if re.search(pattern, text):
        return True
    else:
        return False

# Test cases
assert text_match_wordz("pythonz.") == True
assert text_match_wordz("xyz.") == True
assert text_match_wordz("  lang  .") == False