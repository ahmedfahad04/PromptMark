def find_even_pair(arr):
    # Count the number of elements with even and odd parity
    even_count = sum(x % 2 == 0 for x in arr)
    odd_count = len(arr) - even_count
    
    # Pairs of even numbers or odd numbers will result in an even XOR
    even_pairs = even_count * (even_count - 1) // 2
    odd_pairs = odd_count * (odd_count - 1) // 2
    
    # Total pairs that XOR to an even number
    total_even_pairs = even_pairs + odd_pairs
    
    return total_even_pairs