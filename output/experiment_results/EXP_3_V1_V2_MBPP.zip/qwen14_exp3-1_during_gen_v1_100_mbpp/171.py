def perimeter_pentagon(side_length):
    # Calculate the perimeter by multiplying side length by 5
    perimeter = side_length * 5
    return perimeter