def median_trapezium(a, b, c):
    # Calculate the median length of the trapezium using the formula (min(base1, base2) + max(base1, base2)) / 2
    return (min(a, b) + max(a, b)) / 2

# Test cases
assert median_trapezium(15,25,35) == 20
assert median_trapezium(10,20,30) == 15
assert median_trapezium(6,9,4) == 7.5