def interleave_lists(l1, l2, l3):
    # Initialize an empty list to store the result
    result = []
    
    # Iterate through each index up to the length of the lists
    for i in range(len(l1)):
        # Append elements from each list at the current index to the result list
        result.append(l1[i])
        result.append(l2[i])
        result.append(l3[i])
        
    return result