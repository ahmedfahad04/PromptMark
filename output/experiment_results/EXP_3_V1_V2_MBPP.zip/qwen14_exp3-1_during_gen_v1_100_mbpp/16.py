def text_lowercase_underscore(s):
    # Check if the entire string starts with lowercase letters followed by an underscore
    if s[0].islower() and s[-1] == '_':
        # Split the string by '_' and check each part
        parts = s[:-1].split('_')
        for part in parts:
            if not part.islower():
                return False
        return True
    else:
        return False