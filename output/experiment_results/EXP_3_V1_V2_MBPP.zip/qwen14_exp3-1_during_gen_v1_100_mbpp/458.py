def rectangle_area(length: int, width: int) -> int:
    """
    Calculate the area of a rectangle given its length and width.
    
    :param length: The length of the rectangle.
    :param width: The width of the rectangle.
    :return: The area of the rectangle.
    """
    return length * width