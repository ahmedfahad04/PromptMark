def remove_lowercase(text):
    # Initialize an empty result string
    result = ''
    
    # Iterate through each character in the input text
    for char in text:
        # Check if the character is uppercase
        if char >= 'A' and char <= 'Z':
            # Append it to the result if it's uppercase
            result += char
    
    return result

# Test cases
assert remove_lowercase("PYTHon") == "PYTH"
assert remove_lowercase("FInD") == "FID"
assert remove_lowercase("STRinG") == "STRG"