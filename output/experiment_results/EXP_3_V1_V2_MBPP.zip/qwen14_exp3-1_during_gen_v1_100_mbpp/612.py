def merge(pairs_list):
    """
    Merges pairs of elements into separate lists.
    
    :param pairs_list: A list of sublists, each containing exactly two elements.
    :return: A list of two lists, where the first list contains the first elements of all sublists,
             and the second list contains the second elements of all sublists.
    """
    first_elements = []
    second_elements = []

    # Iterate through each pair in the input list
    for pair in pairs_list:
        first_elements.append(pair[0])
        second_elements.append(pair[1])

    # Return the result as a list of two lists
    return [first_elements, second_elements]