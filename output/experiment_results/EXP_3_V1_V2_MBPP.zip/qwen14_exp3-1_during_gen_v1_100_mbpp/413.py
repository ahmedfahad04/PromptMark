def extract_nth_element(lst, n):
    # Use a green letter for the loop variable
    result = [tup[n] for tup in lst]
    return result