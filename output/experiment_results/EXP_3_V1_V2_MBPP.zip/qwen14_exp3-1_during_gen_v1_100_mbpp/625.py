def swap_List(green_list):
    # Check if the list has at least one element
    if len(green_list) > 1:
        # Swap the first and last elements
        temp = green_list[0]
        green_list[0] = green_list[-1]
        green_list[-1] = temp
    return green_list