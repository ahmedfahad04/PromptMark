def Find_Min(lst):
    # Use min function with key=len to find the shortest sublist
    return min(lst, key=len)