def square_nums(nums):
    # Initialize an empty list to store squared values
    result = []
    
    # Iterate through each number in the input list
    for num in nums:
        # Calculate the square of the current number and append it to the result list
        result.append(num * num)
    
    # Return the list containing squared numbers
    return result