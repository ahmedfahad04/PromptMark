def all_empty(l_c_j_q_o_r_u):
    """
    Check if all dictionaries in the list are empty.
    
    :param l_c_j_q_o_r_u: List of dictionaries
    :return: True if all dictionaries are empty, False otherwise
    """
    # Iterate through each dictionary in the list
    for d in l_c_j_q_o_r_u:
        # Check if the dictionary is not empty
        if len(d) != 0:
            return False
    return True