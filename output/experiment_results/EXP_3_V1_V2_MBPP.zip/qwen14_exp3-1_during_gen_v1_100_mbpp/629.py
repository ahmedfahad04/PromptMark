def filter_even_numbers(numbers):
    # Use list comprehension to filter even numbers
    return [num for num in numbers if num % 2 == 0]

# Test cases
assert filter_even_numbers([1,2,3,4,5]) == [2,4]
assert filter_even_numbers([4,5,6,7,8,0,1]) == [4,6,8,0]
assert filter_even_numbers([8,12,15,19]) == [8,12]