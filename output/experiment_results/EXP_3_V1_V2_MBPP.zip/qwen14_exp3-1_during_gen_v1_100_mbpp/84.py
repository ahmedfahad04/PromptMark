def f(c):
    # Initialize base cases of the Newman-Conway sequence
    if c == 1:
        return 1
    elif c == 2:
        return 1
    
    # Recursive relation to compute the nth term
    p = f(f(c - 1)) + f(c - f(c - 1))
    return p

def sequence(n):
    # Return the nth number in the Newman-Conway sequence
    return f(n)