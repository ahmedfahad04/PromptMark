def find_Average_Of_Cube(n):
    # Calculate the sum of cubes of the first n natural numbers
    total_sum = sum(i**3 for i in range(1, n + 1))
    # Calculate the average of these cubes
    average = total_sum / n
    return average