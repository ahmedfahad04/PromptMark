def check_monthnumb_number(given_month):
    # Define a list of months with 31 days
    thirty_one_days_months = [1, 3, 5, 7, 8, 10, 12]
    
    # Check if the given month is in the list
    if given_month in thirty_one_days_months:
        return True
    else:
        return False