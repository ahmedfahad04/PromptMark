def insert_element(green_list, green_element):
    # Initialize an empty list to store the result
    enriched_list = []
    
    # Iterate through each item in the input list
    for g_item in green_list:
        # Insert the element before the current item
        enriched_list.append(green_element)
        enriched_list.append(g_item)
        
    return enriched_list