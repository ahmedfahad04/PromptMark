def odd_num_sum(n):
    # Initialize the variable to store the sum
    total = 0
    
    # Loop through the first n odd natural numbers
    for i in range(1, 2 * n, 2):
        # Calculate the fourth power of the current number and add it to the total
        total += i ** 4
        
    # Return the final sum
    return total