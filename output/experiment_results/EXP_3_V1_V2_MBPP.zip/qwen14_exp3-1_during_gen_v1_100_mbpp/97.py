def frequency_lists(lst):
    # Initialize an empty dictionary to store frequencies
    freq_dict = {}
    
    # Iterate through each sublist in the input list
    for sub_lst in lst:
        # Iterate through each element in the sublist
        for elem in sub_lst:
            # Update the frequency count of the element in the dictionary
            if elem in freq_dict:
                freq_dict[elem] += 1
            else:
                freq_dict[elem] = 1
                
    return freq_dict