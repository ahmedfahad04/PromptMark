def count_same_pair(list1, list2):
    # Initialize a counter to keep track of matching indices
    match_count = 0
    
    # Iterate through the lists using an index i
    for i in range(len(list1)):
        # Check if the elements at the current index are the same
        if list1[i] == list2[i]:
            # Increment the counter if they are the same
            match_count += 1
            
    # Return the final count of matching indices
    return match_count