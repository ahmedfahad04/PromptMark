def common_in_nested_lists(nested_lists):
    # Initialize a set with all elements from the first list
    common_elements = set(nested_lists[0])
    
    # Iterate through each sublist starting from the second one
    for lst in nested_lists[1:]:
        # Update the set of common elements by intersecting it with current sublist
        common_elements.intersection_update(lst)
    
    return common_elements