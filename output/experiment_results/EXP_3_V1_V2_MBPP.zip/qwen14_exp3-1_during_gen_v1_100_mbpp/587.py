def c_g_t(input_list):
    """
    Convert a list to a tuple.
    
    Parameters:
    input_list (list): A list of elements to be converted into a tuple.
    
    Returns:
    tuple: A tuple containing the elements of the input list.
    """
    # Convert the list to a tuple using the tuple() constructor
    result = tuple(input_list)
    return result