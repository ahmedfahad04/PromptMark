def insert_element(lst, elem):
    # Initialize an empty list to store the result
    result = []
    
    # Iterate through each element in the input list
    for item in lst:
        # Insert the specified element before the current item
        result.append(elem)
        result.append(item)
    
    return result