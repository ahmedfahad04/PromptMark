import math

def otherside_rightangle(a, b):
    # Calculate the hypotenuse using Pythagorean theorem if one side is the hypotenuse
    if a > 0 and b > 0:
        c = math.sqrt(a**2 + b**2)
        return round(c, 9)
    else:
        # Determine which side is the hypotenuse
        if a >= b:
            c = math.sqrt(a**2 - b**2)
        else:
            c = math.sqrt(b**2 - a**2)
        return round(c, 9)