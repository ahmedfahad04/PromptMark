def find_even_pair(nums):
    # Initialize a counter to keep track of the number of valid pairs
    count = 0
    
    # Iterate through each pair of numbers in the list
    for i in range(len(nums)):
        for j in range(i + 1, len(nums)):
            # Check if the XOR of the current pair is even
            if (nums[i] ^ nums[j]) % 2 == 0:
                count += 1
                
    return count