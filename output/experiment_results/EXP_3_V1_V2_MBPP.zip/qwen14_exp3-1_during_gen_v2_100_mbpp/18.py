def remove_dirty_chars(s1, s2):
    # Initialize an empty string to store the result
    result = ""
    
    # Iterate through each character in the first string
    for char in s1:
        # If the character is not in the second string, add it to the result
        if char not in s2:
            result += char
    
    return result