def remove_Occ(s, char):
    # Find the index of the first occurrence of the character
    first_index = s.find(char)
    
    # Find the index of the last occurrence of the character
    last_index = s.rfind(char)
    
    # Remove the characters at the found indices
    if first_index != -1 and last_index != -1 and first_index != last_index:
        return s[:first_index] + s[first_index+1:last_index] + s[last_index+1:]
    elif first_index != -1 and last_index == first_index:
        return s[:first_index] + s[first_index+1:]
    else:
        return s