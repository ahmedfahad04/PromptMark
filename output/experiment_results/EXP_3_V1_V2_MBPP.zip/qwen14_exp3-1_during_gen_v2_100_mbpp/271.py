def even_Power_Sum(n):
    # Initialize the sum variable
    total_sum = 0
    
    # Loop through the first n even natural numbers
    for i in range(1, n + 1):
        # Calculate the current even number
        even_number = 2 * i
        
        # Raise the even number to the fifth power and add it to the total sum
        total_sum += even_number ** 5
    
    return total_sum