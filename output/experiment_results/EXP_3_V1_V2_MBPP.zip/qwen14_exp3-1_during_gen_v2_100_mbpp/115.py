def empty_dit(dicts_list):
    # Check if all dictionaries in the list are empty
    for d in dicts_list:
        if d:  # If any dictionary is not empty
            return False
    return True