from math import gcd

def find_solution(a, b, n):
    # Calculate the GCD of a and b
    d = gcd(a, b)
    
    # Check if n is divisible by the GCD
    if n % d != 0:
        return None
    
    # Simplify a and b by dividing them by their GCD
    a //= d
    b //= d
    n //= d
    
    # Find one particular solution using extended Euclidean algorithm
    x, y = 0, 1
    last_x, last_y = 1, 0
    while b != 0:
        q, a, b = a // b, b, a % b
        x, last_x = last_x - q * x, x
        y, last_y = last_y - q * y, y
    
    # Scale the solution to match the original n
    x *= n
    y *= n
    
    # Ensure the solution is non-negative
    while x < 0:
        x += b
        y -= a
    
    return (x, y)