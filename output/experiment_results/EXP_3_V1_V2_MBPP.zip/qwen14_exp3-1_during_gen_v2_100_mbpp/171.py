def perimeter_pentagon(side_length):
    # The perimeter of a regular pentagon is simply 5 times the side length
    return 5 * side_length