def start_withp(words):
    # Split the input string into words
    split_words = words.split()
    
    # Check if the first word starts with 'p'
    if split_words[0].startswith('p'):
        return split_words[0], split_words[1]
    else:
        return None, None