def count_X(tpl, el):
    """
    This function takes a tuple tpl and an element el, then returns the number of times el appears in tpl.
    
    :param tpl: Tuple containing elements
    :param el: Element to count occurrences of
    :return: Number of occurrences of el in tpl
    """
    cnt = 0
    for item in tpl:
        if item == el:
            cnt += 1
    return cnt