def find(dividend, divisor):
    # Calculate the quotient using integer division
    return dividend // divisor