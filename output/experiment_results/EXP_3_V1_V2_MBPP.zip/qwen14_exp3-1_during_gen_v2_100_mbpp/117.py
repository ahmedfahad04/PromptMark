def list_to_float(data):
    # Iterate through each sublist in the main list
    for i in range(len(data)):
        # Convert each element in the sublist to float if possible
        data[i] = tuple(float(x) if x.replace('.', '', 1).isdigit() else x for x in data[i])
    return data