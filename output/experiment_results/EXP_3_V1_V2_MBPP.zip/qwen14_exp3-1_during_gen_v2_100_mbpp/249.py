def intersection_array(arr1, arr2):
    # Create a set from the first array for O(1) lookups
    set1 = set(arr1)
    
    # Initialize an empty list to store the result
    result = []
    
    # Iterate through the second array and check if each element is in set1
    for num in arr2:
        if num in set1:
            result.append(num)
            # Remove the number from set1 to avoid duplicates in the result
            set1.remove(num)
    
    return result