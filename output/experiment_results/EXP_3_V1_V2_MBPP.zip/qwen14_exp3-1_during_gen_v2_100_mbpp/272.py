def rear_extract(tuples_list):
    # Extract the last element from each tuple in the list
    return [tup[-1] for tup in tuples_list]