def square_Sum(n):
    # Initialize the sum variable to store the result
    total_sum = 0
    
    # Loop through the first n odd natural numbers
    for i in range(1, 2 * n, 2):
        # Square the current odd number and add it to the total sum
        total_sum += i ** 2
    
    # Return the final sum of squares
    return total_sum