def find_Element(arr, queries, n, k):
    # Calculate the effective number of rotations
    total_rotations = k + sum(query[1] for query in queries)
    
    # Adjust the index for the effective number of rotations
    adjusted_index = (total_rotations % n + n) % n
    
    # Return the element at the adjusted index
    return arr[adjusted_index]