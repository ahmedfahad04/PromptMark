def list_split(lst, n):
    result = []
    for i in range(n):
        result.append([lst[j] for j in range(i, len(lst), n)])
    return result