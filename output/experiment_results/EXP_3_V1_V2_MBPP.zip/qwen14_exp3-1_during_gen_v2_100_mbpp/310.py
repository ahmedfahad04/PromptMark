def string_to_tuple(s):
    # Convert the string into a list of characters
    char_list = [char for char in s]
    
    # Return the list as a tuple
    return tuple(char_list)