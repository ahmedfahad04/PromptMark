def extract_singly(nested_lists):
    # Initialize an empty set to store the flattened elements
    flat_set = set()
    
    # Iterate through each sublist in the nested_lists
    for sub_list in nested_lists:
        # Update the set with all elements from the current sublist
        flat_set.update(sub_list)
    
    # Return the final set containing all unique elements
    return flat_set