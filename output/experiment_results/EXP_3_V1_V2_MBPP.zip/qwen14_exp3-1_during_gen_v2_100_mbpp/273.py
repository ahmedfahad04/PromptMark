def substract_elements(tup1, tup2):
    # Check if both tuples have the same length
    if len(tup1) != len(tup2):
        raise ValueError("Tuples must be of the same length")
    
    # Subtract corresponding elements of the tuples
    result = tuple(x - y for x, y in zip(tup1, tup2))
    return result