def sum_series(n):
    # Initialize the result variable
    total_sum = 0
    
    # Loop through the series calculation
    for i in range(n // 2 + 1):
        # Calculate the current term and add it to the total sum
        total_sum += n - 2 * i
    
    return total_sum