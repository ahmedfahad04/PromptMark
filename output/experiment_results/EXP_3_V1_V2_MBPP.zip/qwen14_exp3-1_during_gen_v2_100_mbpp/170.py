def sum_range_list(lst, left, right):
    # Ensure the left index is less than or equal to the right index
    if left > right:
        left, right = right, left
    
    # Calculate the sum of elements between the specified indices
    total_sum = sum(lst[left:right+1])
    
    return total_sum