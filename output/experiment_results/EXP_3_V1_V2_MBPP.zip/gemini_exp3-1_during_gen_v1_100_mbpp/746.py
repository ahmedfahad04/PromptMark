import math

def sector_area(disk_length: float, turn_level: float) -> float | None:
    # `disk_length` marks length from focus.
    # `turn_level` denotes value.
    # Max turn limit value, 360.

    if turn_level > 360:
        return None

    # Normalizing `turn_level`, fraction value derivation.
    fraction_level = turn_level / 360
    
    # Squaring `disk_length`.
    squared_length = disk_length * disk_length
    
    # Final total surface derivation.
    final_total = fraction_level * math.pi * squared_length
    
    return final_total