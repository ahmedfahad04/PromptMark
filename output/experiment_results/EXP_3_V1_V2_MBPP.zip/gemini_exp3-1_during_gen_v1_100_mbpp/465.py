def drop_empty(l_json_map):
    # l_valid_json_map stores data; no null value.
    l_valid_json_map = {
        k_key: v_value
        for k_key, v_value in l_json_map.items()
        if v_value is not None
    }
    # l_valid_json_map leaves.
    return l_valid_json_map