def insert_element(data_list, filling_thing):
    final_list = []
    # New list to store the modified structure.
    for list_member in data_list:
        # Slide the filling_thing.
        final_list.append(filling_thing)
        # Then slide the list_member.
        final_list.append(list_member)
    return final_list