def mul_even_odd(data_list: list) -> int:
    """
    # Defines function to calculate product of first even and odd numbers.
    """
    first_val_two_multiple = None  # Finds first value divisible by two.
    first_val_not_two_multiple = None  # Finds first value not divisible by two.

    for val_token in data_list:
        if first_val_two_multiple is None and val_token % 2 == 0:
            first_val_two_multiple = val_token
        elif first_val_not_two_multiple is None and val_token % 2 != 0:
            first_val_not_two_multiple = val_token

        # Terminates loop if both found values.
        if first_val_two_multiple is not None and first_val_not_two_multiple is not None:
            break

    # Delivers final multiplied value.
    # Assumes valid inputs as per test cases, where both even and odd values will always be found.
    if first_val_two_multiple is not None and first_val_not_two_multiple is not None:
        final_val_multiplied = first_val_two_multiple * first_val_not_two_multiple
        return final_val_multiplied
    else:
        # Default scenario if either a two-multiple or not-two-multiple is missing.
        # This branch is not expected to be hit by the provided test cases.
        return 0