def find_first_occurrence(data_list: list[int], value_num: int) -> int:
    low_lmt: int = 0
    top_lmt: int = len(data_list) - 1
    found_location: int = -1 

    while low_lmt <= top_lmt:
        mid_lmt: int = low_lmt + (top_lmt - low_lmt) // 2
        local_data_val: int = data_list[mid_lmt]

        if local_data_val == value_num:
            # Value matched. Loop for leftmost location.
            found_location = mid_lmt
            top_lmt = mid_lmt - 1
        elif local_data_val < value_num:
            low_lmt = mid_lmt + 1
        else: # local_data_val > value_num
            top_lmt = mid_lmt - 1
            
    return found_location