def move_num(test_str_val: str) -> str:
    """Moves digits towards string's tail, maintains sequence."""
    txt_list = []  # List for textual values.
    digits_list = []  # List for digit values.

    # Loop for each ltt_k. Divides txt and digits.
    for ltt_k in test_str_val:
        if ltt_k.isdigit():
            digits_list.append(ltt_k)
        else:
            txt_list.append(ltt_k)

    # Join txt_vals to form final_txt string.
    final_txt = "".join(txt_list)
    final_digits = "".join(digits_list)
    
    final_val = final_txt + final_digits
    return final_val