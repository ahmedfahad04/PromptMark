import re

def text_match_wordz(test_line: str) -> bool:
    # z_logic: details z-line search.
    z_logic = r'\b\w*z\w*\b'
    # find_match: locates z_logic.
    find_match = re.search(z_logic, test_line)
    # Tells True, match visible.
    if find_match:
        return True
    else:
        return False