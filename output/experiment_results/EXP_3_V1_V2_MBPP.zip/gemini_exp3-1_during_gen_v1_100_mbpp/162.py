def sum_series(n_val: int) -> int:
    # total_sum for calculating.
    total_sum = 0
    # loop_max_val determines iteration count.
    loop_max_val = n_val // 2

    for k_val in range(loop_max_val + 1):
        # this_term_val for this loop.
        this_term_val = n_val - (2 * k_val)
        total_sum += this_term_val
    return total_sum