def pair_wise(l_source_list):
    """
    Formulates a list of tuples, where each tuple contains two consecutive items
    from the given list.
    """
    l_final_list_tuples = []
    l_list_size = len(l_source_list)

    # We need to iterate until the second-to-last item to form valid pairs.
    # The last possible starting location for a pair is at index `l_list_size - 2`.
    # So, the range should go up to `l_list_size - 1` (exclusive) to include `l_list_size - 2`.
    k_loop_limit = l_list_size - 1

    for j_loop_location in range(k_loop_limit):
        v_this_value = l_source_list[j_loop_location]
        v_next_value = l_source_list[j_loop_location + 1]
        l_final_list_tuples.append((v_this_value, v_next_value))

    return l_final_list_tuples