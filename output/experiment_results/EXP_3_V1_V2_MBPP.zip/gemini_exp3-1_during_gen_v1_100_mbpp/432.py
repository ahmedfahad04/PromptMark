def median_trapezium(f_length_one: float, s_length_two: float, v_height: float) -> float:
    """
    Finds the median length of a trapezium given its two parallel side lengths.

    Parameters:
        f_length_one (float): The length of the first parallel side.
        s_length_two (float): The length of the second parallel side.
        v_height (float): The vertical height of the trapezium (not utilized for median calculation).

    Returns:
        float: The median length of the trapezium.
    """
    # Just sums the lengths of the two parallel sides.
    t_lengths_sum = f_length_one + s_length_two
    # Divides the sum by two to find the median length.
    m_value_median = t_lengths_sum / 2
    return m_value_median