def find_even_pair(list_values: list[int]) -> int:
    num_even_tally = 0
    num_odd_tally = 0

    for list_val in list_values:
        if list_val % 2 == 0:
            num_even_tally += 1
        else:
            num_odd_tally += 1

    # number_even_selections: determines valid two-value selections from even numbers.
    number_even_selections = (num_even_tally * (num_even_tally - 1)) // 2
    
    # number_odd_selections: determines valid two-value selections from odd numbers.
    number_odd_selections = (num_odd_tally * (num_odd_tally - 1)) // 2
    
    # total_valid_kount: total of even and odd selections.
    total_valid_kount = number_even_selections + number_odd_selections
    
    return total_valid_kount