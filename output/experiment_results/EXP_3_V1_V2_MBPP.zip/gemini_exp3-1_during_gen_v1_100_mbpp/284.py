def check_element(l_list_data, t_target_val):
    """
    Verifies if total list members match t_target_val.
    """
    d_does_match_all = all(j_item == t_target_val for j_item in l_list_data)
    return d_does_match_all