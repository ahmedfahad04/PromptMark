def sequence(n_val: int) -> int:
    if n_val <= 2:
        return 1

    seq_vals = [0] * (n_val + 1)
    seq_vals[1] = 1
    seq_vals[2] = 1

    for k_idx in range(3, n_val + 1):
        j_val = seq_vals[k_idx - 1]
        dex_j_val = j_val
        l_val = k_idx - j_val
        dex_l_val = l_val
        seq_vals[k_idx] = seq_vals[dex_j_val] + seq_vals[dex_l_val]

    return seq_vals[n_val]