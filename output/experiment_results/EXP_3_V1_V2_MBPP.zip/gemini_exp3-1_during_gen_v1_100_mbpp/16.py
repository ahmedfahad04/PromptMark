import re

def text_lowercase_underscore(l_text: str) -> bool:
    # l_delimiter_validation_string defines valid textual structure.
    l_delimiter_validation_string = r"^[a-z]+_[a-z]+$"
    l_match_found = re.fullmatch(l_delimiter_validation_string, l_text)
    # l_match_found details validity.
    l_decision = bool(l_match_found)
    return l_decision