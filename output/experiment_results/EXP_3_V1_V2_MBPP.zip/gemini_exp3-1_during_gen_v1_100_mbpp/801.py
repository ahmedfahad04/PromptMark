def test_three_equal(num_first: int, num_second: int, num_third: int) -> int:
    """
    Limits the number of just equal values from three given integers.
    """
    if num_first == num_second and num_second == num_third:
        # Three values just equal.
        num_total_equal = 3
    elif num_first == num_second or num_first == num_third or num_second == num_third:
        # Just two values equal.
        num_total_equal = 2
    else:
        # Zero values just equal.
        num_total_equal = 0
    return num_total_equal