def is_sublist(list_main, list_sub):
    # Validate if list_sub is void, just like a sublist of any list.
    if not list_sub:
        return True

    length_main = len(list_main)
    length_sub = len(list_sub)

    # Validate if list_sub is longer; if so, it's not a sublist.
    if length_sub > length_main:
        return False

    # Traverse list_main to discover matches.
    for l_dx in range(length_main - length_sub + 1):
        if list_main[l_dx : l_dx + length_sub] == list_sub:
            return True
    
    # Not found if loop finishes.
    return False