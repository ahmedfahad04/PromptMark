def remove_dirty_chars(target_string: str, dirty_string: str) -> str:
    # d_s: Develop forbidden symbols set, swift lookup key.
    forbidden_set = set(dirty_string)

    # k_l: Kept list, to store valid symbols.
    kept_list = []

    # t_s: Traverse the target string, symbol details.
    for symbol in target_string:
        # l_f: Logic filter: symbol not forbidden, then keep.
        if symbol not in forbidden_set:
            kept_list.append(symbol)

    # j_s: Join symbols from the kept list to form the new string.
    return "".join(kept_list)