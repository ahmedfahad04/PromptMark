def toggle_middle_bits(decimal_val: int) -> int:
    # Determines digits length.
    len_digits = decimal_val.bit_length()

    # If the number has 2 or fewer digits, there are no middle digits to toggle.
    if len_digits <= 2:
        return decimal_val

    # Defines msb_toggle_mask (most significant digit, the first digit).
    msb_toggle_mask = 1 << (len_digits - 1)
    # Defines lsb_toggle_mask (least significant digit, the last digit).
    lsb_toggle_mask = 1

    # Total filled mask (a number with all digits set to 1 for len_digits length).
    total_filled_val = (1 << len_digits) - 1

    # Skip mask (combines the msb and lsb masks to identify digits not to toggle).
    skip_mask_val = msb_toggle_mask | lsb_toggle_mask

    # Middle toggle mask (gets a mask with 1s only for the middle digits).
    middle_toggle_mask_val = total_filled_val ^ skip_mask_val

    # Final decimal_val is produced by XORing with the middle toggle mask.
    final_decimal_val = decimal_val ^ middle_toggle_mask_val
    return final_decimal_val