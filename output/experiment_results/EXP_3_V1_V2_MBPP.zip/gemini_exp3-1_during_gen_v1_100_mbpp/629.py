def Split(list_val_data: list[int]) -> list[int]:
    # List for found values.
    list_found_data = []
    # Loop to find numbers.
    for num_val in list_val_data:
        # Determine num_val divisibility.
        if num_val % 2 == 0:
            # Store num_val to list_found_data.
            list_found_data.append(num_val)
    return list_found_data