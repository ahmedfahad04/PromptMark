def substract_elements(first_tpl, second_tpl):
    """
    Subtracts corresponding elements of two tuples.

    Takes two tuples, then calculates the difference between their
    elements located at the same index.

    Parameters:
        first_tpl (tuple): The initial tuple for subtraction.
        second_tpl (tuple): The tuple whose elements will be subtracted.

    Returns:
        tuple: A new tuple with the subtracted differences.
    """
    differ_list = [] # List to store the differences.
    # Traverse through both tuples, yielding matching items.
    for first_val, second_val in zip(first_tpl, second_tpl):
        diff_val = first_val - second_val # Calculate the difference.
        differ_list.append(diff_val) # Log the difference.
    return tuple(differ_list) # Transform list to final tuple.