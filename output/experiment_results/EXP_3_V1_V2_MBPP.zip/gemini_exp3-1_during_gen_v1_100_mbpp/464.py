def check_value(d_data: dict, v_value_to_verify) -> bool:
    # d_data: dictionary for checking
    # v_value_to_verify: value to confirm
    # Verifies if all dictionary values match the specified value.
    
    # Leverages 'all' to test if every dictionary value is equal to v_value_to_verify.
    # The 'all()' function returns True if all elements of the iterable are true (or if the iterable is empty).
    # A generator expression creates the iterable of boolean values (True/False) dynamically.
    z_is_all_matched = all(l_dict_value == v_value_to_verify for l_dict_value in d_data.values())
    return z_is_all_matched