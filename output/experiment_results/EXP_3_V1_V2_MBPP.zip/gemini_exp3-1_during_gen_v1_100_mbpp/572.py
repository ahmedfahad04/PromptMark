def two_unique_nums(l_data: list) -> list:
    d_freqs = {} # d_freqs: tracks number frequencies.
    for v_val in l_data:
        d_freqs[v_val] = d_freqs.get(v_val, 0) + 1

    s_final_list = [] # s_final_list: stores numbers appearing just once.
    for j_key, k_freq in d_freqs.items():
        if k_freq == 1:
            s_final_list.append(j_key)
            
    return s_final_list