def start_withp(list_items: list[str]) -> tuple[str, str]:
    kept_labels = [] # list of labels kept
    for datum_string in list_items:
        tokens_list = datum_string.split()
        for label_token in tokens_list:
            if label_token.lower().startswith('p'):
                kept_labels.append(label_token)
                if len(kept_labels) == 2:
                    return tuple(kept_labels)
    # This point should not be reached based on the problem's implicit guarantee
    # that at least two 'p' words will always be found.
    return tuple(kept_labels) # Fallback, though likely not needed