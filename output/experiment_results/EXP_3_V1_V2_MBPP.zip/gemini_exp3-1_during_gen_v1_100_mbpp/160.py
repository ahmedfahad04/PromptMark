def _f_v_extended_v_d_gcd(a_val, b_val):
    # Just base case of the algorithm.
    if b_val == 0:
        # If b_val is 0, d_val is a_val, and x_val is 1, y_val is 0.
        return (a_val, 1, 0)
    else:
        # Lets make a recursive call.
        d_next, x_next, y_next = _f_v_extended_v_d_gcd(b_val, a_val % b_val)
        # Just update x_val and y_val using results from the recursive call.
        x_val = y_next
        y_val = x_next - (a_val // b_val) * y_next
        return (d_next, x_val, y_val)

def find_solution(a_input, b_input, n_target):
    # Lets find the gcd and initial coefficients.
    d_val, x_val_base, y_val_base = _f_v_extended_v_d_gcd(a_input, b_input)

    # Lets handle cases where d_val is 0 (which means a_input=0 and b_input=0).
    if d_val == 0:
        if n_target == 0:
            # Its infinite solutions for 0x + 0y = 0. Lets return (0, 0) for example.
            return (0, 0)
        else:
            # No solution for 0x + 0y = n_target where n_target != 0.
            return None

    # d_val checks if n_target is divisible by d_val.
    if n_target % d_val != 0:
        return None

    # k_val is the multiplier to scale x_val_base, y_val_base to solve for n_target.
    k_val = n_target // d_val

    # Initial particular solution.
    x_particular = x_val_base * k_val
    y_particular = y_val_base * k_val

    # b_div_d is b_input / d_val.
    b_div_d = b_input // d_val

    # Just handle the specific case where b_input is 0.
    # If b_input is 0, b_div_d will be 0, leading to ZeroDivisionError in modulo.
    # In this scenario, a_input * x = n_target, so x is fixed. y can be anything.
    if b_div_d == 0: # This happens if b_input=0 and d_val > 0 (meaning a_input must be non-zero).
        return (x_particular, y_particular)

    # Lets adjust the solution to fit common conventions (e.g., smallest non-negative x).
    # This ensures x_final is in [0, b_div_d - 1].
    # Python's modulo operator behaves such that the result has the same sign as the divisor.
    # The (val % mod + mod) % mod pattern ensures a positive result for modulo.
    x_final = (x_particular % b_div_d + b_div_d) % b_div_d

    # Now calculate the corresponding t_v_adjust.
    # x_final = x_particular + b_div_d * t_v_adjust
    t_v_adjust = (x_final - x_particular) // b_div_d

    # Calculate the corresponding y_final.
    y_final = y_particular - (a_input // d_val) * t_v_adjust

    return (x_final, y_final)