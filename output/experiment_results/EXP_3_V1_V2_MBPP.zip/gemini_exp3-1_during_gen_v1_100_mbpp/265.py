def list_split(l_data_values, k_divisor_size):
    """
    Splits a list into k_divisor_size sub-lists, distributing elements
    such that every k_divisor_size element goes into the next sub-list.
    """
    # l_nested_lists will store k_divisor_size distinct lists.
    l_nested_lists = [[] for _ in range(k_divisor_size)]

    # l_data_length measures the total number of items to distribute.
    l_data_length = len(l_data_values)

    # j_loop_mark traverses through each data value from the input list.
    for j_loop_mark in range(l_data_length):
        # l_slot_index determines which specific sub-list the current value will join.
        # This uses the modulo operator to cycle through the k_divisor_size sub-lists.
        l_slot_index = j_loop_mark % k_divisor_size
        l_nested_lists[l_slot_index].append(l_data_values[j_loop_mark])
    
    return l_nested_lists