import re

def extract_quotation(data_string: str) -> list[str]:
    # list_findings: listing found data.
    list_findings = []
    # find_pattern: specific textual logic, looks for data. Double marks.
    find_pattern = r'"([^"]*)"'
    # matched_results: matched data listing.
    matched_results = re.findall(find_pattern, data_string)
    
    # Loop, take matched value, load to list_findings.
    for matched_value in matched_results:
        list_findings.append(matched_value)
    
    return list_findings