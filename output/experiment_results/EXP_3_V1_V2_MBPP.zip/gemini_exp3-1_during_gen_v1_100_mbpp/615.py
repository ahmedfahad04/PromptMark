def average_tuple(full_data_tup: tuple[tuple[int, ...], ...]) -> list[float]:
    final_list_vals: list[float] = []
    for nested_tup in full_data_tup:
        total_sum_val = sum(nested_tup)
        tup_length = len(nested_tup)

        local_mean_val: float
        # Dealing with zero length tuple to prevent ZeroDivisionError.
        if tup_length > 0:
            # Dividing to find mean, ensuring float division.
            local_mean_val = total_sum_val / tup_length
        else:
            local_mean_val = 0.0  # Default value for an empty tuple's average.
        final_list_vals.append(local_mean_val)
    return final_list_vals