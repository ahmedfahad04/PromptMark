def extract_nth_element(list_full_data, data_key):
    # list_selected_values: List for selected values.
    list_selected_values = []
    # Loop for data_tuple.
    for data_tuple in list_full_data:
        # Fetch the value for the data_key.
        list_selected_values.append(data_tuple[data_key])
    return list_selected_values