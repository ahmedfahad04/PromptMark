def Find_Max_Length(list_data: list[list]) -> int:
    # Keeps track of the largest length discovered.
    largest_length = 0

    # Navigates through each sub-list item.
    for sub_data in list_data:
        # Determines the current data's length.
        data_length = len(sub_data)
        # Keeps largest length, if new length is larger.
        if data_length > largest_length:
            largest_length = data_length

    # Delivers the maximum length value.
    return largest_length