def sum_range_list(data_list_l, start_limit_l, finish_limit_l):
    total_sum_val = 0  # L# Local sum.

    # L# This loop visits each list value within the specified limits.
    for j_val in range(start_limit_l, finish_limit_l + 1):
        total_sum_val += data_list_l[j_val]
    
    return total_sum_val # L# Final sum.