def list_tuple(s_source_list):
    # j_final_tuple stores the tuple version of s_source_list.
    j_final_tuple = tuple(s_source_list)
    return j_final_tuple