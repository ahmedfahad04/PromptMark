def merge_dictionaries_three(f_dict_val, s_dict_val, t_dict_val):
    # joined_dictionary: Stores the merged dictionaries.
    # The unpacking order {**t_dict_val, **s_dict_val, **f_dict_val} ensures
    # that keys present in f_dict_val take precedence, then s_dict_val,
    # then t_dict_val. This resolves key collisions by prioritizing earlier arguments.
    joined_dictionary = {**t_dict_val, **s_dict_val, **f_dict_val}
    return joined_dictionary