def frequency_lists(list_of_lists):
    # Nested list data flattened; single list.
    flattened_list_values = []
    for list_sub in list_of_lists:
        for list_value in list_sub:
            flattened_list_values.append(list_value)

    # Data frequency mapping setup.
    data_frequency_map = {}
    for list_key in flattened_list_values:
        data_frequency_map[list_key] = data_frequency_map.get(list_key, 0) + 1

    return data_frequency_map