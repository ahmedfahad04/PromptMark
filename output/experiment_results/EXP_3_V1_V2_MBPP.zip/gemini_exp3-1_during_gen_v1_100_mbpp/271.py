def even_Power_Sum(n: int) -> int:
    # d_total_sum tracks the total sum.
    d_total_sum = 0
    # k_val, the loop link, from 1 to n.
    for k_val in range(1, n + 1):
        # d_double_k_val, the k-th term.
        d_double_k_val = 2 * k_val
        # l_val_level_fifth, d_double_k_val to fifth level.
        l_val_level_fifth = d_double_k_val ** 5
        d_total_sum += l_val_level_fifth
    return d_total_sum