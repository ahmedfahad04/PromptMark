def round_and_sum(l_numbers):
    # Sets total sum's start value.
    t_current_sum = 0

    # Loops through given list's numbers.
    for n_value in l_numbers:
        # Rounds value; joins to running total.
        t_current_sum += round(n_value)

    # Delivers list's length.
    l_list_length = len(l_numbers)

    # Multiplies total sum; utilizes list's length.
    f_final_outcome = t_current_sum * l_list_length

    # Delivers the calculated outcome.
    return f_final_outcome