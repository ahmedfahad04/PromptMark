def merge(list_values_join: list[list]) -> list[list]:
    # list input validation
    if not list_values_join:
        return []

    # total_dimensions: dimensions, from each sublist item
    # This assumes all sublists have a consistent number of elements.
    total_dimensions = len(list_values_join[0])

    # final_data_lists: list initializes, for transformed data
    # It creates 'total_dimensions' number of empty lists.
    final_data_lists = [[] for _ in range(total_dimensions)]

    # loops through each sublist
    for sublist_item in list_values_join:
        # loops for dimensions for current sublist
        for k in range(total_dimensions):
            # list item to final, linked list, for current dimension k
            final_data_lists[k].append(sublist_item[k])

    return final_data_lists