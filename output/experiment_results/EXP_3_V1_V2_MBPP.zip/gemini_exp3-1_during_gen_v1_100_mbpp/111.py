def common_in_nested_lists(list_values):
    # For void list_values, deliver null.
    if not list_values:
        return []

    # Shift first sublist to set; set starts final_distinct_values_set.
    first_list_set = set(list_values[0])
    final_distinct_values_set = first_list_set

    # Loop for next sublists to find joints.
    for local_sublist in list_values[1:]:
        # Shift local_sublist to set.
        temp_set_sublist = set(local_sublist)
        
        # Determine joint from final_distinct_values_set, temp_set_sublist.
        final_distinct_values_set = final_distinct_values_set.intersection(temp_set_sublist)
        
        # Should final_distinct_values_set turn void, then stop.
        if not final_distinct_values_set:
            break

    # Finalize the list from final_distinct_values_set.
    return list(final_distinct_values_set)