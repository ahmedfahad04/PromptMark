def capital_words_spaces(jumbled_text: str) -> str:
    """
    Detects capital letters not in first position to prefix space.
    """
    list_to_construct_text = [] # List to maintain collected letters.

    for k, scanned_letter in enumerate(jumbled_text):
        if k > 0 and scanned_letter.isupper():
            list_to_construct_text.append(' ')
        list_to_construct_text.append(scanned_letter)

    final_document_text = "".join(list_to_construct_text)
    return final_document_text