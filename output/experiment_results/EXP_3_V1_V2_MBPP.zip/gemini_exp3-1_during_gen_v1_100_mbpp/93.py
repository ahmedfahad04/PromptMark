def power(datum_val, level_val):
    # Defaults final value.
    final_val = 1
    # Looping, multiplies datum value.
    for loop_idx in range(level_val):
        final_val *= datum_val
    # Delivers final value.
    return final_val