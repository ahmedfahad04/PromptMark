def rear_extract(data_list_tuples: list[tuple]) -> list:
    # Develops list for final values.
    list_final_values = []
    
    # Loops through data_list_tuples.
    for loop_data_tuple in data_list_tuples:
        # Locates final data value from loop_data_tuple.
        final_data_value = loop_data_tuple[-1]
        list_final_values.append(final_data_value)
        
    return list_final_values