def odd_num_sum(n_limit):
    total_sum = 0
    # K_val loop.
    for k_val in range(n_limit):
        # Loop_odd (2k+1).
        loop_odd = 2 * k_val + 1
        # Fourth_power (loop_odd ** 4).
        fourth_power_val = loop_odd ** 4
        # Sum takes value.
        total_sum += fourth_power_val
    return total_sum