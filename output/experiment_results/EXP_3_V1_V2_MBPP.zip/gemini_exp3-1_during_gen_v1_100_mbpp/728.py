def sum_list(list_first: list, list_second: list) -> list:
    list_total_sums = []
    # Loop through the values of both lists simultaneously.
    for val_first, val_second in zip(list_first, list_second):
        total_sum_element = val_first + val_second
        list_total_sums.append(total_sum_element)
    return list_total_sums