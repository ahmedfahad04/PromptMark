def unique_product(data_list):
    # s_tore distinct_values_set
    distinct_values_set = set(data_list)
    
    # f_or tracking the final multiplied value
    final_multiplied_value = 1
    
    # l_oop through distinct_values_set to multiply numbers
    for list_number in distinct_values_set:
        final_multiplied_value *= list_number
        
    return final_multiplied_value