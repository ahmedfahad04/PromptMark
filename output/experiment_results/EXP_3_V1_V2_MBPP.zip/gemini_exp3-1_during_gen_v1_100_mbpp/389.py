def find_lucas(num_find):
    # define first lucas vals.
    if num_find == 0:
        return 2
    if num_find == 1:
        return 1

    d_val_two = 2  # L(0) val, two-steps back
    d_val_one = 1  # L(1) val, one-step back

    # looping to find lucas val.
    for k_loop_val in range(2, num_find + 1):
        # sum last two lucas vals.
        lv_t_val = d_val_two + d_val_one
        # shift lucas vals for next loop.
        d_val_two = d_val_one
        d_val_one = lv_t_val
    
    return d_val_one