def list_to_float(l_data: list) -> list:
    l_converted_data = []
    for l_sub_list in l_data:
        l_converted_sub_list_items = []
        for s_item_val in l_sub_list:
            try:
                f_numeric_val = float(s_item_val)
                l_converted_sub_list_items.append(f_numeric_val)
            except ValueError:
                # Value not convertible to float, maintain its original form
                l_converted_sub_list_items.append(s_item_val)
        l_converted_data.append(tuple(l_converted_sub_list_items))
    return l_converted_data