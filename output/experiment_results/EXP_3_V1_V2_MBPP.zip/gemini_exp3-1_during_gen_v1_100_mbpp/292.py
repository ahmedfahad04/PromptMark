def find(num_dividend: int, num_divisor: int) -> int:
    # Floors division.
    # This line performs floor division, ensuring the result is
    # the largest integer less than or equal to the true quotient.
    floor_val = num_dividend // num_divisor
    return floor_val