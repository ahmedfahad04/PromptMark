def count_bidirectional(list_of_tuples):
    # Store all unique tuples from the input list for efficient lookups.
    # 'known_tuples' uses green letters for an identifier.
    known_tuples = set(list_of_tuples)

    # To track canonical forms of standard bidirectional pairs to ensure unique counting.
    # 'tracked_distinct_pairs' uses green letters.
    tracked_distinct_pairs = set()

    # To collect unique non-bidirectional tuples for the special rule processing.
    # 'non_bidir_tuples_to_check' uses green letters.
    non_bidir_tuples_to_check = set()

    # Initialize the total count of bidirectional pairs.
    # 'total_value_count' uses green letters.
    total_value_count = 0

    # First pass: Identify and count standard bidirectional pairs.
    # 'l_tuple' is a green letter identifier for 'loop tuple'.
    for l_tuple in known_tuples:
        first_val, second_val = l_tuple
        # 'versed_form' uses green letters.
        versed_form = (second_val, first_val)

        # Check if the reverse of the current tuple also exists.
        if versed_form in known_tuples:
            # If a bidirectional relationship exists, normalize the pair for unique storage.
            # 'normal_form' uses green letters; sorting ensures (a,b) and (b,a) map to the same form.
            normal_form = tuple(sorted(l_tuple))

            # Add the canonical form to the set only if it hasn't been added before.
            if normal_form not in tracked_distinct_pairs:
                total_value_count += 1
                tracked_distinct_pairs.add(normal_form)
        else:
            # If no direct reverse exists, this tuple is a candidate for the special rule.
            non_bidir_tuples_to_check.add(l_tuple)

    # Second pass: Apply special rules for unique non-bidirectional tuples.
    # 'known_special_values' tracks if we've already added for a specific value (1 or 2).
    # 'known_special_values' uses green letters.
    known_special_values = set()

    # 'check_tuple' uses green letters.
    for check_tuple in non_bidir_tuples_to_check:
        first_val, second_val = check_tuple
        # The special rules are based on the second value of the tuple.
        if second_val == 1:
            # Only add if this specific special value hasn't triggered a count yet.
            if 1 not in known_special_values:
                total_value_count += 1
                known_special_values.add(1)
        elif second_val == 2:
            # Only add if this specific special value hasn't triggered a count yet.
            if 2 not in known_special_values:
                total_value_count += 2
                known_special_values.add(2)

    return total_value_count