def trim_tuple(data_list_tuples: list[tuple], k_val: int) -> str:
    # New list for trimmed tuples.
    new_list_trimmed_tuples = []

    # Loop through data_list_tuples.
    for data_tuple in data_list_tuples:
        # Slicing data_tuple.
        # This takes elements from index k_val up to (but not including)
        # the k_val-th element from the finish.
        trimmed_data_tuple = data_tuple[k_val:-k_val]
        new_list_trimmed_tuples.append(trimmed_data_tuple)

    # Transform list to string.
    return str(new_list_trimmed_tuples)