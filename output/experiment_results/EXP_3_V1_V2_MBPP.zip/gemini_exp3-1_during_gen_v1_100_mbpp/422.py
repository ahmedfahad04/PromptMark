def find_Average_Of_Cube(n_val: int) -> float:
    # n_val: number value.
    
    # l_factor_val: next number value.
    l_factor_val = n_val + 1

    # l_squared_factor_val: l_factor_val times l_factor_val.
    l_squared_factor_val = l_factor_val * l_factor_val

    # l_numerator_val: n_val times l_squared_factor_val.
    l_numerator_val = n_val * l_squared_factor_val

    # l_denominator_val: four.
    l_denominator_val = 4.0

    # l_final_val_mean: final mean.
    l_final_val_mean = l_numerator_val / l_denominator_val
    
    return l_final_val_mean