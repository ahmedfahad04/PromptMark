def reverse_string_list(list_of_strings):
    # New list for output
    list_of_new_strings = []
    # Loop over original list's members
    for string_data_item in list_of_strings:
        # Turn around the current data string
        tem_reversed_data = string_data_item[::-1]
        # Join the turned around data to list_of_new_strings
        list_of_new_strings.append(tem_reversed_data)
    # Deliver the final list
    return list_of_new_strings