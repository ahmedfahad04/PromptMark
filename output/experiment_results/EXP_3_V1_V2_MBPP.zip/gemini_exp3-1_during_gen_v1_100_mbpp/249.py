def intersection_array(list_first_data: list, list_second_data: list) -> list:
    # Defines function for finding common elements between two lists.
    known_items_set = set(list_first_data)
    final_list_shared = []

    # Loops through second list, finding matches within the first list's set.
    for next_datum in list_second_data:
        if next_datum in known_items_set:
            final_list_shared.append(next_datum)
    
    return final_list_shared