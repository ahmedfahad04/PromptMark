def largest_subset(known_nums_list: list[int]) -> int:
    # Tackle trivial kase for null list.
    if not known_nums_list:
        return 0

    # Sort this list to simplify divisibility tests.
    # Larger divisible values shall show later.
    sorted_nums_list = sorted(known_nums_list)
    nums_length = len(sorted_nums_list)

    # dp_lengths_list[k_idx] shall show length for largest divisible
    # subset that terminates via this_num_val.
    dp_lengths_list = [1] * nums_length

    # max_subset_size tracks the total maximum length found.
    max_subset_size = 1

    # Loop through this num_val to discover longest divisible subset that
    # terminates via this_num_val.
    for k_idx in range(nums_length):
        this_num_val = sorted_nums_list[k_idx]
        # View last nums for this_num_val.
        for j_val_idx in range(k_idx):
            last_num_val = sorted_nums_list[j_val_idx]
            # Should this_num_val test divisible thru last_num_val,
            # that might make subset longer.
            if this_num_val % last_num_val == 0:
                dp_lengths_list[k_idx] = max(dp_lengths_list[k_idx], dp_lengths_list[j_val_idx] + 1)
        
        # Show the total maximum size found thus far.
        max_subset_size = max(max_subset_size, dp_lengths_list[k_idx])
    
    return max_subset_size