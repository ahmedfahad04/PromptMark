def count_same_pair(down_list, next_list):
    # track_length_val from down_list; assumes both lists maintain same length
    known_length_val = len(down_list)
    total_matches = 0  # stores_tally for specific matches

    for list_idx in range(known_length_val):
        # check_list_values_for_likeness
        if down_list[list_idx] == next_list[list_idx]:
            total_matches += 1
    
    return total_matches