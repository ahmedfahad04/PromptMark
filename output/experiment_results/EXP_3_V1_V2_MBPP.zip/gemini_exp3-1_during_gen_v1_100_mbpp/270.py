def sum_even_and_even_index(l_data_list):
    """
    Finds the sum of even numbers at even positions within a list.
    """
    t_total_sum = 0
    # Loop through the list with index and value
    for j_index, k_value in enumerate(l_data_list):
        # Verify if the current index is even
        # Verify if the number at the current index is even
        if j_index % 2 == 0 and k_value % 2 == 0:
            t_total_sum += k_value
    l_final_sum = t_total_sum # Final sum is available
    return l_final_sum