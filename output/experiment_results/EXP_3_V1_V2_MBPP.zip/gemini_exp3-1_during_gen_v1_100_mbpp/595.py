def min_Swaps(first_s_val: str, second_s_val: str) -> 'int | str':
    length_first_s = len(first_s_val)
    length_second_s = len(second_s_val)

    if length_first_s != length_second_s:
        return "Not Possible"

    num_live_first_s = 0
    num_dead_first_s = 0
    num_live_second_s = 0
    num_dead_second_s = 0

    for k_dex in range(length_first_s):
        if first_s_val[k_dex] == '1':
            num_live_first_s += 1
        else:
            num_dead_first_s += 1
        
        if second_s_val[k_dex] == '1':
            num_live_second_s += 1
        else:
            num_dead_second_s += 1
    
    if num_live_first_s != num_live_second_s or num_dead_first_s != num_dead_second_s:
        return "Not Possible"

    num_diff_live_to_dead = 0 

    for k_dex in range(length_first_s):
        if first_s_val[k_dex] == '1' and second_s_val[k_dex] == '0':
            num_diff_live_to_dead += 1
    
    return num_diff_live_to_dead