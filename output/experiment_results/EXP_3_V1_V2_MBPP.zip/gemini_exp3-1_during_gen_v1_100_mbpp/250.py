def count_X(l_tuple, l_element):
    # t_total_val: Tracks the total number of found values.
    t_total_val = 0
    # l_item: Loop variable for tuple values.
    for l_item in l_tuple:
        if l_item == l_element:
            t_total_val += 1
    return t_total_val