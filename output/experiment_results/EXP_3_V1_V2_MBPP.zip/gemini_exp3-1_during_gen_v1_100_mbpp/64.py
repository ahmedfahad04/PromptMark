def subject_marks(list_of_tuples):
    # Leverages a lambda function as the key for sorting.
    # This function extracts the second element (index 1) of each tuple.
    lambda_tuple_second_value_extractor = lambda tuple_element: tuple_element[1]

    # Sorts the list of tuples using the extracted second value for comparison.
    sorted_list_of_tuples = sorted(list_of_tuples, key=lambda_tuple_second_value_extractor)
    
    return sorted_list_of_tuples