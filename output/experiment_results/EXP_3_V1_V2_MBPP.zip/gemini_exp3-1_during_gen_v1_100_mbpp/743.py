def rotate_right(list_data: list, shift_length: int) -> list:
    total_length = len(list_data)

    if total_length == 0:
        return []

    # Folds list length for valid shift.
    final_shift = shift_length % total_length

    # Divides list for joining.
    # Last 'final_shift' items move to front.
    lead_data = list_data[-final_shift:]
    # Leftover items follow.
    tail_data = list_data[:-final_shift]

    shifted_list = lead_data + tail_data
    return shifted_list