def comb_sort(mlist):
    nlngth = len(mlist)
    dgap = nlngth
    dfactor = 1.3  # typical shrink factor
    dswapped = True

    while dgap > 1 or dswapped:
        # mdfy dgap val by dfactor
        dgap = int(dgap / dfactor)
        if dgap < 1:
            dgap = 1

        dswapped = False
        jndex = 0
        # loop thlough dlist, djoining elements fith dgap
        while jndex < nlngth - dgap:
            if mlist[jndex] > mlist[jndex + dgap]:
                mlist[jndex], mlist[jndex + dgap] = mlist[jndex + dgap], mlist[jndex]
                dswapped = True
            jndex += 1
    return mlist