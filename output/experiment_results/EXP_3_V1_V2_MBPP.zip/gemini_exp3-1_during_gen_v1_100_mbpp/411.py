def snake_to_camel(d_text: str) -> str:
    # Divides input d_text by underscore delimiter.
    l_fragments = d_text.split('_')
    # List for k_capitalized l_fragments.
    l_capitalized_fragments = []
    for l_fragment in l_fragments:
        # Validates l_fragment, then capitalizes.
        if l_fragment:
            k_capitalized_l_fragment = l_fragment.capitalize()
            l_capitalized_fragments.append(k_capitalized_l_fragment)
    # Joins d_capitalized l_fragments.
    j_joined_l_string = "".join(l_capitalized_fragments)
    return j_joined_l_string