import math

def otherside_rightangle(len_first_dim, len_second_dim):
    dim_first_squared = len_first_dim ** 2
    dim_second_squared = len_second_dim ** 2
    total_dim_sum_squares = dim_first_squared + dim_second_squared
    final_length_dim = math.sqrt(total_dim_sum_squares)
    return final_length_dim