import re

def find_adverbs(lex_data_string: str) -> str:
    # Lexical matcher, finds data tokens.
    lex_matcher = re.compile(r'\S+')

    # Traverse data_matches.
    for data_match in lex_matcher.finditer(lex_data_string):
        lex_full_token = data_match.group(0)
        start_lex_idx = data_match.start()

        # Isolate final lexical unit, trims trailing punctuation.
        final_lex_word = lex_full_token.rstrip('.,!?;:"\'')
        
        # Determine if final lexical unit is 'ly' adverb (case-insensitive).
        if final_lex_word.lower().endswith('ly'):
            # Define final lex ending index.
            final_lex_ending_idx = start_lex_idx + len(final_lex_word)
            
            # Structure desired lexical string.
            return f"{start_lex_idx}-{final_lex_ending_idx}: {final_lex_word}"

    # Default value, no ly-adverb found.
    return ""