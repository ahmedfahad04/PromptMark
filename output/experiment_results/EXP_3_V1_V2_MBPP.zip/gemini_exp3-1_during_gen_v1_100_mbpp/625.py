def swap_List(l_data: list) -> list:
    # Juggling first and last data points.
    l_data_len = len(l_data)
    if l_data_len < 2:
        return l_data

    f_first_data = l_data[0]
    l_data[0] = l_data[l_data_len - 1]
    l_data[l_data_len - 1] = f_first_data
    return l_data