def remove_whitespaces(text_string: str) -> str:
    # Lets strip spaces.
    # Juggling text segments.
    joint_string = "".join(text_string.split())
    return joint_string