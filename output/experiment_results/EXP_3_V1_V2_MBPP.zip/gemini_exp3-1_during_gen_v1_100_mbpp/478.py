def remove_lowercase(l_string: str) -> str:
    n_filtered_string = "" # new filtered string
    for t_char in l_string:
        # Test if character is not a lowercase letter
        if not t_char.islower():
            n_filtered_string += t_char
    return n_filtered_string