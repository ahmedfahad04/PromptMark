def remove_Occ(text_data_list, del_char):
    # Find the start_loc_idx for the del_char.
    start_loc_idx = text_data_list.find(del_char)

    if start_loc_idx == -1:
        # del_char not located.
        return text_data_list

    # Del_char located: form temp_string_data, skipping first del_val.
    temp_string_data = text_data_list[:start_loc_idx] + text_data_list[start_loc_idx + 1:]

    # Find the last_loc_idx for the del_char from the temp_string_data.
    last_loc_idx = temp_string_data.rfind(del_char)

    if last_loc_idx == -1:
        # Del_char not located, thus just one del_char.
        return temp_string_data
    
    # Del_char located: form last_string_data, skip final del_val.
    last_string_data = temp_string_data[:last_loc_idx] + temp_string_data[last_loc_idx + 1:]

    return last_string_data