def square_Sum(n: int) -> int:
    # d defines total value, s stores sum.
    total_sum = 0
    # l loops from 1 to n.
    for k in range(1, n + 1):
        # f finds the kth odd number.
        kth_odd_number = 2 * k - 1
        # t takes square of the odd number.
        kth_squared_value = kth_odd_number * kth_odd_number
        # j joins to the total sum.
        total_sum += kth_squared_value
    # d delivers the final sum.
    return total_sum