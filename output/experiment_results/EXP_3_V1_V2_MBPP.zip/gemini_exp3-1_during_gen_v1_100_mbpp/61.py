def count_Substrings(d_string_val: str) -> int:
    l_total_count = 0
    n_len_string = len(d_string_val)

    # Loop starting digits.
    for s_start_idx in range(n_len_string):
        t_current_sum = 0
        # Loop termination digits.
        for t_end_idx in range(s_start_idx, n_len_string):
            # Fetch digit value.
            l_current_digit = int(d_string_val[t_end_idx])
            t_current_sum += l_current_digit

            # Length, this substring.
            l_substring_length = t_end_idx - s_start_idx + 1

            # Test digits sum vs. length.
            if t_current_sum == l_substring_length:
                l_total_count += 1
    return l_total_count