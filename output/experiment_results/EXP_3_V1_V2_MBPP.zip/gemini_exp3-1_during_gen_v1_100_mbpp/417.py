def group_tuples(lst_tpls: list[tuple]) -> list[tuple]:
    k_dict_link_val = {}
    # Map first val to list of linked next vals.
    for tpl_val in lst_tpls:
        k_first_elm = tpl_val[0]
        k_second_elm = tpl_val[1]
        if k_first_elm not in k_dict_link_val:
            k_dict_link_val[k_first_elm] = []
        k_dict_link_val[k_first_elm].append(k_second_elm)

    k_final_lst = []
    # Loop through link data for final list.
    for k_key, k_val_list in k_dict_link_val.items():
        k_list_val_members = [k_key] + k_val_list
        k_final_lst.append(tuple(k_list_val_members))
    
    return k_final_lst