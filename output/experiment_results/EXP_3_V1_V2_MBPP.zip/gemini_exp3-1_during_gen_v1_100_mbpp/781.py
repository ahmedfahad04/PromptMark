import math

def count_divisors(l_val):
    # k_limit_val: l_val's divisor limit value.
    k_limit_val = int(math.sqrt(l_val))
    # j_tells_square: determines l_val's square status.
    j_tells_square = (k_limit_val * k_limit_val == l_val)
    return not j_tells_square