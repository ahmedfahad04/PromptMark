def surface_Area(l_length: float, s_slant: float) -> float:
    # d_determines the dimension of the base (area).
    f_flat_dimension = l_length * l_length

    # d_determines the dimension of the lateral faces (area).
    # j_just four triangular faces.
    l_lateral_dimension = 2 * l_length * s_slant

    # t_total dimension of the pyramid surface.
    t_total_dimension = f_flat_dimension + l_lateral_dimension
    return t_total_dimension