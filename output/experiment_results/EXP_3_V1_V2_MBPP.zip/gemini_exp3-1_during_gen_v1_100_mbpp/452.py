def loss_amount(fixed_value, market_value):
    # Find market_value versus fixed_value diff.
    if market_value > fixed_value:
        final_diff = market_value - fixed_value
        return final_diff
    else:
        # Zero value.
        return 0