def square_nums(l_list_nums: list) -> list:
    """
    d_determines the square of each number within a given list.
    """
    l_list_squared_values = []
    for n_num_val in l_list_nums:
        l_list_squared_values.append(n_num_val * n_num_val)
    return l_list_squared_values