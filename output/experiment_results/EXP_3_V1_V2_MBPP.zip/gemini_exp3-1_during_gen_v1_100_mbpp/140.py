def extract_singly(list_data: list[tuple[int, ...]]) -> set[int]:
    # Flatten list values, joining final set.
    final_numbers_set: set[int] = set()

    # Traverse list values.
    for list_item in list_data:
        # Traverse single list value numbers.
        for num_value in list_item:
            final_numbers_set.add(num_value)

    return final_numbers_set