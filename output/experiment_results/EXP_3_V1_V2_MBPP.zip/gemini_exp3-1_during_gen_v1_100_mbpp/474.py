def replace_char(d_string: str, l_old_char: str, k_new_char: str) -> str:
    # Delivers string with chars swapped.
    j_list_chars = []
    for f_char in d_string:
        if f_char == l_old_char:
            j_list_chars.append(k_new_char)
        else:
            j_list_chars.append(f_char)
    t_final_string = "".join(j_list_chars)
    return t_final_string