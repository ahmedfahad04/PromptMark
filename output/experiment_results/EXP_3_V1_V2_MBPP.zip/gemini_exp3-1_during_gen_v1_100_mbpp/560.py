def union_elements(first_tuple: tuple, second_tuple: tuple) -> tuple:
    # Join both tuples into a single list.
    joined_list = list(first_tuple) + list(second_tuple)

    # Make a set to remove duplicate values.
    distinct_set = set(joined_list)

    # Transform the set to a list; then, sort it.
    sorted_list = sorted(list(distinct_set))

    # Transform the sorted list to a tuple for the final output.
    final_tuple = tuple(sorted_list)

    return final_tuple