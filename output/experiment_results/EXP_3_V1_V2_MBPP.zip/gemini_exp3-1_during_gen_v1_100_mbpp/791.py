def remove_nested(data_tuple):
    # This valid_list stores non-tuple items.
    valid_list = []
    # Loop for each datum in the data_tuple.
    for datum in data_tuple:
        # Discern if datum is not a tuple.
        if not isinstance(datum, tuple):
            valid_list.append(datum)
    # Transform valid_list to a tuple, then deliver.
    final_data_tuple = tuple(valid_list)
    return final_data_tuple