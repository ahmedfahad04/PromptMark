def tuple_intersection(f_list_data_first, s_list_data_second):
    # _m_normalize_tuple_vals: sorts tuple vals; makes matching simple.
    def _m_normalize_tuple_vals(j_tuple_vals):
        l_sorted_vals = sorted(j_tuple_vals)
        return tuple(l_sorted_vals)

    # d_set_first_normalized: Set of normalized tuples; from f_list_data_first.
    d_set_first_normalized = {
        _m_normalize_tuple_vals(t_val_data) for t_val_data in f_list_data_first
    }

    # k_set_second_normalized: Set of normalized tuples; from s_list_data_second.
    k_set_second_normalized = {
        _m_normalize_tuple_vals(t_val_data) for t_val_data in s_list_data_second
    }

    # v_final_matched_set: Finds matched normalized tuples via set junction.
    v_final_matched_set = d_set_first_normalized.intersection(k_set_second_normalized)

    return v_final_matched_set