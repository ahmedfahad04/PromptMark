def occurance_substring(long_string, key_string):
    # Finds first location.
    location_start = long_string.find(key_string)

    # Validates, location not found.
    if location_start == -1:
        return None
    else:
        # Determines final location.
        location_final = location_start + len(key_string)
        # Delivers findings.
        return (key_string, location_start, location_final)