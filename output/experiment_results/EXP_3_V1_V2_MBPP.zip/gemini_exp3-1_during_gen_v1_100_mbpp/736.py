def left_insertion(list_dt: list, target_val: int) -> int:
    """
    Locates the left insertion point for a specified value in sorted order.
    This finds the index where target_val would fit, maintaining sorted order,
    such that all elements to the left are less than target_val.
    """
    # d_len denotes the length of the list_dt.
    d_len = len(list_dt)
    l_idx = 0  # l_idx marks the lower search limit.
    t_idx = d_len  # t_idx marks the top search limit.

    while l_idx < t_idx:
        # m_idx represents the middle index for splitting.
        m_idx = (l_idx + t_idx) // 2
        # j_val is the data value at m_idx.
        j_val = list_dt[m_idx]

        if j_val < target_val:
            # Shift l_idx right if m_idx_val is less than target.
            l_idx = m_idx + 1
        else:
            # Shift t_idx left if m_idx_val is greater than or equal to target.
            t_idx = m_idx
    # l_idx is the final insertion point.
    return l_idx