import math

def is_perfect_square(num_val: int) -> bool:
    # Denotes negative vals; never square.
    if num_val < 0:
        return False
    # Zero value; valid square (0*0=0).
    if num_val == 0:
        return True

    # Denotes float square value.
    sqrt_float_val = math.sqrt(num_val)
    
    # Denotes floor-level square value.
    floor_sqrt_val = int(sqrt_float_val)
    
    # Tests floor value's squared form; matches num.
    return floor_sqrt_val * floor_sqrt_val == num_val