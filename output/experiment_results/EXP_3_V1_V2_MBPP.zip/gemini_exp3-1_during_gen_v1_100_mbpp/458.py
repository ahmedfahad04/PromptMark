def rectangle_area(dim_length, dim_depth):
    # Determine the product of dimensions.
    total_surface = dim_length * dim_depth
    return total_surface