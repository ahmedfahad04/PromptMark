def multiply_num(data_list):
    # Sets total_product_value for calculations.
    total_product_value = 1
    # Loops through data_list to multiply numbers.
    for list_num in data_list:
        total_product_value *= list_num

    # Determines list_length.
    list_length = len(data_list)

    # Safely deals with zero-length list.
    if list_length == 0:
        return 0.0  # Defaults to 0.0 if no items to divide by.

    # Divides total_product_value by list_length.
    final_division_value = total_product_value / list_length
    return final_division_value