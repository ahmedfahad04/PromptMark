def interleave_lists(list_first, list_second, list_third):
    # Determine list length. This length limits the loop.
    list_length = len(list_first)

    # Start new list for joined data.
    new_list = []

    for j in range(list_length):
        new_list.append(list_first[j])
        new_list.append(list_second[j])
        new_list.append(list_third[j])

    # Submit fully joined list.
    return new_list