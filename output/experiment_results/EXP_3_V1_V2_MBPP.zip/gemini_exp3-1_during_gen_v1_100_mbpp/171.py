def perimeter_pentagon(side_length):
    # Determines the count of sides for a pentagon.
    num_sides_val = 5
    # Determines the total length measurement.
    total_length_val = side_length * num_sides_val
    return total_length_val