def find_First_Missing(l_data: list[int]) -> int:
    # Detect zero loss.
    if not l_data or l_data[0] != 0:
        return 0

    l_length = len(l_data)
    # Then, l_data must start from zero.
    # Search for j value not matching l_data[j] value.
    for j in range(l_length):
        if l_data[j] != j:
            return j
    
    # Full sequence leads to l_length.
    return l_length