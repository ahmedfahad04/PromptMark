def Find_Min(d_list_val: list[list]) -> list:
    # Just checks if the list is empty, then returns an empty list.
    if not d_list_val:
        return []

    # Jolly initialization: sets the first list as the current shortest.
    min_d_list = d_list_val[0]

    # Journeys through the remaining lists to find the shortest.
    for sub_list_val in d_list_val[1:]:
        # Looks for shorter lists; updates if found.
        if len(sub_list_val) < len(min_d_list):
            min_d_list = sub_list_val
    return min_d_list