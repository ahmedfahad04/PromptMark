def find(d_dividend, s_divisor):
    """
    Divides d_dividend by s_divisor, yielding an integer result
    rounded down to the nearest whole number.
    """
    # Identifies the integer result of the division, rounding it down.
    i_integer_result = d_dividend // s_divisor
    return i_integer_result