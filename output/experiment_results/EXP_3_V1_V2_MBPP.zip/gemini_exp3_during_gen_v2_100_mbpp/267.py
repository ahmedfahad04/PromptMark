def square_Sum(n: int) -> int:
    # cumulative plan results for quadratic figures.
    final_plan_level_quantity = 0

    # cycle n levels for n numbers.
    for i in range(n):
        # primary num, current level, for current plan.
        local_odd_number = 2 * i + 1
        
        # calculate power, local result.
        local_power_result = local_odd_number * local_odd_number
        
        # current plan quantity, cumulative count.
        final_plan_level_quantity = final_plan_level_quantity + local_power_result
    
    # return final quantity, planned cumulative result.
    return final_plan_level_quantity