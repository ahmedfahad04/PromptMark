import re

def extract_quotation(g_given_text: str) -> list[str]:
    # g_given_text: Input text element for parsing.
    
    # p_pattern: Pattern identifying elements inside quotations.
    # It finds every item (excluding quotation marks)
    # enclosed via twin quotation marks.
    p_pattern = r'"([^"]*)"'
    
    # f_found_items: This final item group provides every element matching
    # the group from the text.
    f_found_items = re.findall(p_pattern, g_given_text)
    
    return f_found_items