def move_num(given_text_data: str) -> str:
    # Initialize two lists to gather elements: one for non-digits and one for digits.
    alpha_elements_gen = []
    digit_elements_gen = []

    # Iterate through each item (character) in the given text.
    for each_item_data in given_text_data:
        # Determine if the current item is a digit.
        if each_item_data.isdigit():
            digit_elements_gen.append(each_item_data)
        else:
            alpha_elements_gen.append(each_item_data)

    # Join the collected non-digit elements and digit elements into separate strings.
    # Then, concatenate these two strings to form the final result,
    # with non-digits appearing first, followed by digits.
    final_data_gen = "".join(alpha_elements_gen) + "".join(digit_elements_gen)
    return final_data_gen