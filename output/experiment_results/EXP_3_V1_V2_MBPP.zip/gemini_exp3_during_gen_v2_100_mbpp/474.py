def replace_char(full_string: str, target_letter: str, replace_letter: str) -> str:
    # This function substitutes target_letter with replace_letter in full_string.
    final_list_of_symbols = []
    for one_symbol in full_string:
        if one_symbol == target_letter:
            final_list_of_symbols.append(replace_letter)
        else:
            final_list_of_symbols.append(one_symbol)
    output_string = "".join(final_list_of_symbols)
    return output_string