import math

def otherside_rightangle(len_a, len_b):
    # Calculate a square of each input length.
    len_a_sq = len_a * len_a
    len_b_sq = len_b * len_b

    # Add calculated squares.
    square_sum_len = len_a_sq + len_b_sq

    # Conclude a missing side length.
    calc_side_len = math.sqrt(square_sum_len)
    
    return calc_side_len