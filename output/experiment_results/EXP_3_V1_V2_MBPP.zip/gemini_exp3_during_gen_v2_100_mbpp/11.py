def remove_Occ(original_source_content: str, char_to_exclude: str) -> str:
    # Get location of earliest char occurrence.
    location_of_earliest_char = original_source_content.find(char_to_exclude)

    # Return original content if char is not located.
    if location_of_earliest_char == -1:
        return original_source_content

    # Get location of latest char occurrence, using rfind for rightmost location.
    location_of_latest_char = original_source_content.rfind(char_to_exclude)

    collected_output_elements = []
    current_content_length = len(original_source_content)

    # Loop over original content to collect elements.
    for current_char_location in range(current_content_length):
        # Exclude earliest and latest char occurrences.
        if current_char_location != location_of_earliest_char and current_char_location != location_of_latest_char:
            collected_output_elements.append(original_source_content[current_char_location])

    # Join collected elements.
    return "".join(collected_output_elements)