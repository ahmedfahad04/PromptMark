def pair_wise(an_array: list) -> list[tuple]:
    """
    Generates a list of all consecutive pairs from the given array.

    Args:
        an_array: An array of elements.

    Returns:
        A new array containing tuples of consecutive elements.
        Returns an empty array if the input array has fewer than two elements.
    """
    an_array_length = len(an_array)
    if an_array_length < 2:
        # Fewer than two elements means no pairs are achievable.
        return []

    all_generated_pairs = []
    # an_idx iterates from the first element's index up to the second-to-last element's index.
    # This ensures that an_array[an_idx + 1] always refers to a valid element.
    for an_idx in range(an_array_length - 1):
        first_element_of_pair = an_array[an_idx]
        next_element_of_pair = an_array[an_idx + 1]
        all_generated_pairs.append((first_element_of_pair, next_element_of_pair))

    return all_generated_pairs