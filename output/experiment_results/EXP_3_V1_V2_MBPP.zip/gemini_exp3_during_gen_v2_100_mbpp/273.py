def substract_elements(uber_first_tuple: tuple, uber_bij_tuple: tuple) -> tuple:
    """
    Given two tuples, uber_first_tuple and uber_bij_tuple, this function
    will generate a new tuple. Each element in the new tuple
    is the result of subtracting elements from uber_bij_tuple 
    by elements from uber_first_tuple at the identical index.
    """
    useful_elements_list = []
    # Begin iteration using zip to pair up elements from both input tuples.
    for element_first, element_bij in zip(uber_first_tuple, uber_bij_tuple):
        given_result = element_first - element_bij
        useful_elements_list.append(given_result)
    
    return tuple(useful_elements_list)