def median_trapezium(l_data_side_a: float, l_data_side_e: float, d_data_as_left: float) -> float:
    # A function to define the length, a trapezium data.
    # d_data_as_left: A data element. This data stays as-is.
    d_total_average = (l_data_side_a + l_data_side_e) / 2.0
    return d_total_average