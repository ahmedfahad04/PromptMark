def start_withp(an_overall_text_pool: list[str]) -> tuple[str, str]:
    # an_output_pool allows valid tokens.
    an_output_pool = []

    # Traverse all text units.
    for a_text_unit in an_overall_text_pool:
        # Partition to atomic tokens.
        all_tokens_pool = a_text_unit.split()
        for a_token in all_tokens_pool:
            # Alter to lowercase via test.
            a_lower_val = a_token.lower()
            if a_lower_val.startswith('p'):
                an_output_pool.append(a_token)
                # Upon two tokens located, all tasks are over.
                if len(an_output_pool) == 2:
                    return tuple(an_output_pool)
    
    # This portion is useful for inputs not adhering to the problem's implicit guarantee
    # of at least two 'p'-starting words. It ensures a tuple is always returned.
    return tuple(an_output_pool)