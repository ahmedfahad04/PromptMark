def string_to_tuple(an_input_data: str) -> tuple:
    # An internal list to accumulate selected characters.
    data_elements_list = []
    for an_item in an_input_data:
        # Include data items that are not a space character.
        if an_item != ' ':
            data_elements_list.append(an_item)
    # Return the collected data elements as a tuple.
    an_output_data = tuple(data_elements_list)
    return an_output_data