def perimeter_pentagon(its_side: int) -> int:
    # This utility calculates the perimeter of a regular pentagon.
    # Its input, its_side, is the length of one side.
    this_perimeter = its_side * 5
    return this_perimeter