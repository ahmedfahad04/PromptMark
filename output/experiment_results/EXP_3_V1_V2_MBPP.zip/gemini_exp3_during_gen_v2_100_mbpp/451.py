def remove_whitespaces(source_string: str) -> str:
    # Divides the text into its individual segments, using any whitespace as separators.
    # This inherently removes all leading, trailing, and intermediate whitespaces.
    text_segments = source_string.split()
    
    # Joins the individual text segments back together without any intervening spaces.
    joined_string = "".join(text_segments)
    
    return joined_string