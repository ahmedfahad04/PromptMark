def check_element(list_obj, look_for_obj):
    # Process items, hoping for mismatch.
    for loop_obj in list_obj:
        if loop_obj != look_for_obj:
            return False # Found non-matching item, finish.
    return True # No non-matching items; many match or list is blank.