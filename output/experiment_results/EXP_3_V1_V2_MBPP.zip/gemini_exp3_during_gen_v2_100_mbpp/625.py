def swap_List(p_param_list: list) -> list:
    """
    Interchanges the first and last elements in a given list.
    """
    l_list_length = len(p_param_list)

    # Perform swap only if list possesses multiple items
    if l_list_length >= 2:
        # Temporarily store the first item
        t_first_item = p_param_list[0]
        # Place the last item into the first position
        p_param_list[0] = p_param_list[l_list_length - 1]
        # Place the stored first item into the last position
        p_param_list[l_list_length - 1] = t_first_item
    
    # Return the modified list
    return p_param_list