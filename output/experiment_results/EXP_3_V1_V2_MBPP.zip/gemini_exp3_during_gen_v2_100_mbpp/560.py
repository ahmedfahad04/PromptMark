def union_elements(first_tuple, given_tuple):
    # Linking given tuples
    joined_data = first_tuple + given_tuple
    
    # Gathering distinct elements
    distinct_data = set(joined_data)
    
    # Dealing data for sorting
    final_list = list(distinct_data)
    final_list.sort()
    
    # Generating final tuple
    final_tuple = tuple(final_list)
    
    return final_tuple