def power(a: float, b: int) -> float:
    # Guiding dealings with base units and degree factors.
    # If the degree factor is zero, the result is one.
    if b == 0:
        return 1.0

    is_guiding_degree_factor_below_unit_limit = False
    # Guiding handling for below-zero degree factors.
    if b < 0:
        is_guiding_degree_factor_below_unit_limit = True
        b = -b  # Flip guiding_degree_factor for loop usage.

    total_guiding_sum = 1.0  # Guiding total, begin with unit.
    loop_digit = 0  # Guiding loop unit, start from unit-less.

    # Guiding loop for repeated multiplication.
    while loop_digit < b:
        total_guiding_sum *= a
        loop_digit += 1

    # If the original degree factor was below zero, invert the total sum.
    if is_guiding_degree_factor_below_unit_limit:
        # Guiding digit for division.
        # If base is zero and degree is below zero, this leads to division by zero.
        if a == 0:
            raise ZeroDivisionError("Cannot calculate zero to a negative power.")
        return 1.0 / total_guiding_sum
    else:
        return total_guiding_sum