def mul_even_odd(data_list):
    initial_even_data = None
    initial_odd_data = None

    for data_item in data_list:
        if data_item % 2 == 0:  # Determine if current data_item is even
            if initial_even_data is None:
                initial_even_data = data_item
        else:  # Current data_item is odd
            if initial_odd_data is None:
                initial_odd_data = data_item

        # Check if both required data items are located
        if initial_even_data is not None and initial_odd_data is not None:
            # Both first even and first odd numbers are located; early exit.
            break

    # After the loop, calculate the outcome.
    calculated_outcome = initial_even_data * initial_odd_data
    return calculated_outcome