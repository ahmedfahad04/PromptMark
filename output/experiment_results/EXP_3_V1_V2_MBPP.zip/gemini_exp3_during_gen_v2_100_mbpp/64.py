import typing

def subject_marks(list_items: typing.List[typing.Tuple[str, int]]) -> typing.List[typing.Tuple[str, int]]:
    # Sorts the list of item_tuples.
    # The key function tells sorted() to use the second value (index 1) from each item_tuple for sorting.
    sorted_list_items = sorted(list_items, key=lambda item_value: item_value[1])
    return sorted_list_items