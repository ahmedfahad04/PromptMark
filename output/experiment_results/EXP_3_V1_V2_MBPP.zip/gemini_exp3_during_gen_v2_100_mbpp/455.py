def check_monthnumb_number(given_month_number: int) -> bool:
    # A collection of month numbers that each contain thirty-one days.
    thirty_one_day_months = {1, 3, 5, 7, 8, 10, 12}
    
    # Check if the given month number exists in the collection.
    # This denotes a month has thirty-one days.
    return given_month_number in thirty_one_day_months