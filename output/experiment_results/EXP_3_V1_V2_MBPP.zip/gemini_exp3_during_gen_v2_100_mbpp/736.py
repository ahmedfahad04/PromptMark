def left_insertion(data_collection: list, target_value: int) -> int:
    # Initial point starting search.
    start_point: int = 0
    # Current high_index, giving collection size.
    high_index: int = len(data_collection)

    # Loop till start_point reaches high_index.
    while start_point < high_index:
        # Calculates mid_index, pivot directing current check.
        mid_index: int = (start_point + high_index) // 2
        
        # If target_value drops prior to current datum, high_index is shifted to mid_index.
        # This considers values equal to target_value as potential insertion points further left.
        if target_value <= data_collection[mid_index]:
            high_index = mid_index
        # Progress start_point past mid_index.
        # This handles cases where target_value is greater than the current mid_index datum.
        else:
            start_point = mid_index + 1
            
    return start_point