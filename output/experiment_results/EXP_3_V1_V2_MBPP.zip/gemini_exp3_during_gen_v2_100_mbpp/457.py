def Find_Min(data_groups: list) -> list:
    # Deals with empty input group.
    if not data_groups:
        return []

    # Defines current smallest extent.
    smallest_extent = float('inf')
    # Stores the group exhibiting smallest extent.
    shortest_group = []

    for group_data in data_groups:
        group_extent = len(group_data)
        if group_extent < smallest_extent:
            smallest_extent = group_extent
            shortest_group = group_data
    
    return shortest_group