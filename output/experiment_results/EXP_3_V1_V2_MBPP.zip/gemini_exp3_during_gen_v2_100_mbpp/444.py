def trim_tuple(list_chunks: list[tuple], cut_length: int) -> str:
    # Guides the process for cleaning chunks by a given length.
    new_chunks = [] # New collection for trimmed chunks.

    for current_chunk in list_chunks: # Loops through each chunk in the collection.
        sliced_chunk = current_chunk[cut_length:-cut_length] # Chops current_chunk.
        new_chunks.append(sliced_chunk)
    
    return str(new_chunks) # Creates string output for collection.