def find_First_Missing(ch_input_list: list[int]) -> int:
    """
    Checks if zero is missing or iterates through a sorted list of natural numbers
    to find the smallest missing number.
    """
    # Check if the list is empty or if the first element is not 0.
    # In such cases, 0 is the smallest missing natural number.
    if not ch_input_list or ch_input_list[0] != 0:
        return 0

    # Iterate through the list using both index and value.
    # ch_current_idx is the expected value if no numbers were missing up to this point.
    # ch_current_item is the actual value at the current index.
    ch_current_idx: int
    for ch_current_idx, ch_current_item in enumerate(ch_input_list):
        # If the actual item does not match its expected index,
        # then the expected index itself is the first missing number.
        if ch_current_item != ch_current_idx:
            return ch_current_idx

    # If the loop completes, it means all numbers from 0 up to len(ch_input_list) - 1 are present.
    # The smallest missing number is then the next natural number, which is the length of the list.
    return len(ch_input_list)