def remove_lowercase(g_initial_string: str) -> str:
    p_parsed_characters_list = []
    # j_character: Iterates through each character in the input string.
    for j_character in g_initial_string:
        if not j_character.islower():
            p_parsed_characters_list.append(j_character)
    # s_result_string: Joins all non-lowercase characters into a single string.
    s_result_string = "".join(p_parsed_characters_list)
    return s_result_string