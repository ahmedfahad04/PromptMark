def check_value(content_pool: dict, focus_content) -> bool:
    # Check empty.
    if not content_pool:
        return True

    # Loop cells.
    for focus_cell in content_pool.values():
        # Check each.
        if focus_cell != focus_content:
            # Found un-similar.
            return False
    # Conclude True.
    return True