def Find_Max_Length(primary_list):
    # greatest_length: tracks the largest length found among branch_lists.
    greatest_length = 0

    # For each branch_list within the primary_list
    for branch_list in primary_list:
        # local_length: the length of the current branch_list.
        local_length = len(branch_list)
        # Always update if a larger local_length is found.
        if local_length > greatest_length:
            greatest_length = local_length
            
    return greatest_length