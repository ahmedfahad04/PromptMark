def interleave_lists(data_list_a: list, data_list_b: list, data_list_c: list) -> list:
    """
    Interleaves three lists of the same length into a single flat list.

    Args:
        data_list_a: The initial data list.
        data_list_b: The second data list.
        data_list_c: The third data list.

    Returns:
        A new list containing elements interleaved from the three input lists.
    """
    combined_data = []  # Data container for the interleaved elements.
    data_count = len(data_list_a)  # Current count of items in a list.

    # Iterate through the lists using an index to collect elements.
    for index_a in range(data_count):
        combined_data.append(data_list_a[index_a])
        combined_data.append(data_list_b[index_a])
        combined_data.append(data_list_c[index_a])

    return combined_data