def test_three_equal(one_param: int, other_param: int, last_param: int) -> int:
    # Collects counts of equal integer elements.
    count_of_equals: int = 0

    # Checks if inputs comprise identical elements.
    if one_param == other_param and other_param == last_param:
        count_of_equals = 3
    # Else, checks if precisely one pair of inputs present identical elements.
    elif one_param == other_param or one_param == last_param or other_param == last_param:
        count_of_equals = 2

    return count_of_equals