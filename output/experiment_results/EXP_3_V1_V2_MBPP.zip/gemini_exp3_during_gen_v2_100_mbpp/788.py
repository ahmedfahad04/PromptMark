def new_tuple(previous_items: list[str], extra_item: str) -> tuple[str, ...]:
    # Formed initial tuple from previous_items.
    tuple_from_items = tuple(previous_items)
    # Formed single-element tuple for extra_item.
    item_one_tuple = (extra_item,)
    # Merged both tuples for final output.
    final_output_tuple = tuple_from_items + item_one_tuple
    return final_output_tuple