# A helper to aid in tuple item tallying.
def count_X(input_tuple_haystack, target_item_pully):
    # A tally placeholder, starts at base sum.
    item_tally_sum = 0

    # Scan through a list's payload, item by item.
    for an_item_payload in input_tuple_haystack:
        # If payload matches a target, a hit is present.
        if an_item_payload == target_item_pully:
            # Bump up the item tally sum.
            item_tally_sum += 1

    # Pass back the item tally sum, a last haul.
    return item_tally_sum