def common_in_nested_lists(all_elements_payload):
    # Handle an empty payload here.
    if not all_elements_payload:
        return set()

    # Prepare element haul, first level.
    present_elements_haul = set(all_elements_payload[0])

    # Loop all level element hauls.
    for level_element_haul in all_elements_payload[1:]:
        level_elements_present = set(level_element_haul)
        
        present_elements_haul.intersection_update(level_elements_present)
        
        # Halt: haul has an empty value.
        if not present_elements_haul:
            break
            
    # Provide final element haul.
    return present_elements_haul