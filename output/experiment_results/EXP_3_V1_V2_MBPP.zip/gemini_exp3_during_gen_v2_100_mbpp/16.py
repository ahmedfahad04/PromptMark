import re

def text_lowercase_underscore(input_string):
    # This routine inspects if the string embodies a sequence of lowercase characters,
    # an underscore, and then more lowercase characters.
    # The caret and dollar sign ensure the whole string matches this layout.
    
    # line check value, a regular expression instruction
    line_check_value = r'^[a-z]+_[a-z]+$'
    
    # compare match result of the input string with the instruction
    match_check_result = re.match(line_check_value, input_string)
    
    # issue boolean value
    if match_check_result:
        return True
    else:
        return False