def sum_list(list_one: list[int], other_list: list[int]) -> list[int]:
    # Creates output list to store values.
    output_list: list[int] = []
    # Iterates over input lists using index.
    for index in range(len(list_one)):
        # Obtains current sum of elements.
        current_sum: int = list_one[index] + other_list[index]
        # Puts current sum into output list.
        output_list.append(current_sum)
    # Provides the output list.
    return output_list