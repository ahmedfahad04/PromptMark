def find_lucas(n: int) -> int:
    # Handle initial index values
    if n == 0:
        return 2
    if n == 1:
        return 1

    # gen_calc_unit holds L(i-2), gen_calc_duo holds L(i-1)
    gen_calc_unit = 2
    gen_calc_duo = 1

    # Compute sequence iteratively
    for i in range(2, n + 1):
        gen_current_calc = gen_calc_unit + gen_calc_duo
        
        # Shift elements for next iteration
        gen_calc_unit = gen_calc_duo
        gen_calc_duo = gen_current_calc
    
    return gen_current_calc