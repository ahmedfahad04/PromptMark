def list_to_float(p_original_data_list):
    n_converted_output = []
    for q_current_row in p_original_data_list:
        r_row_with_floats = []
        for o_original_value in q_current_row:
            # Convert value to float.
            n_float_value = float(o_original_value)
            r_row_with_floats.append(n_float_value)
        # Convert row list to tuple.
        n_converted_output.append(tuple(r_row_with_floats))
    return n_converted_output