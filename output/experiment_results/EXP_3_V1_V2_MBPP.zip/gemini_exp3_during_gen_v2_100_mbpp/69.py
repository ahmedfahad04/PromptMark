def is_sublist(parent_list: list, part_list: list) -> bool:
    """
    Checks if a given part_list is a sublist of the parent_list.

    Args:
        parent_list: The list to check within.
        part_list: The list to find as a sublist.

    Returns:
        True if part_list is found as a contiguous sublist within parent_list,
        False otherwise.
    """
    len_parent_list = len(parent_list)
    len_part_list = len(part_list)

    # A part_list longer than parent_list cannot be a sublist.
    # An empty part_list is considered a sublist of any list.
    if len_part_list > len_parent_list:
        return False
    if len_part_list == 0:
        return True

    # Iterate through parent_list to find a matching slice.
    # The iteration limit ensures that there's enough room for part_list.
    for i in range(len_parent_list - len_part_list + 1):
        # Examine a potential part (slice) from the parent_list.
        potential_part_list = parent_list[i : i + len_part_list]
        if potential_part_list == part_list:
            return True

    # If the loop completes, no matching part_list was found.
    return False