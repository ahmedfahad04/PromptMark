def largest_subset(list_elements: list[int]) -> int:
    # Handle the empty list case.
    if not list_elements:
        return 0

    # Sort the elements in ascending order. This simplifies divisibility checks:
    # if an element divides another, the divisor must precede or be equal to the dividend.
    sorted_elements = sorted(list_elements)
    elements_count = len(sorted_elements)

    # Initialize a list to store the length of the largest divisible subset
    # ending with the element at the current index.
    # Each element itself forms a subset of length 1.
    divisible_subset_lengths = [1] * elements_count

    # Iterate through each element to determine the largest subset ending with it.
    for current_index in range(elements_count):
        current_element = sorted_elements[current_index]

        # Check all previous elements to find potential divisors for the current element.
        for previous_index in range(current_index):
            previous_element = sorted_elements[previous_index]

            # If the current element is divisible by a previous element,
            # this implies the current element can extend a previous subset.
            if current_element % previous_element == 0:
                # Modify the length for the current_index if extending the previous subset
                # creates a longer subset.
                divisible_subset_lengths[current_index] = max(
                    divisible_subset_lengths[current_index],
                    divisible_subset_lengths[previous_index] + 1
                )

    # The maximum value in divisible_subset_lengths will be the size of the overall
    # largest divisible subset.
    return max(divisible_subset_lengths)