def e_u_c_l_i_d_e_a_n_p_r_o_c_e_d_u_r_e(val_one: int, val_other: int) -> tuple[int, int, int]:
    # Returns (g, x, y) such that a*x + b*y = g = gcd(a, b).
    # The gcd returned is always non-negative.
    # The coefficients x and y are for the input val_one and val_other.
    if val_other == 0:
        # Base case: gcd(val_one, 0) is abs(val_one).
        # We need val_one * x + 0 * y = abs(val_one).
        # So x is 1 if val_one is positive, -1 if val_one is negative.
        # y can be 0.
        return abs(val_one), (1 if val_one >= 0 else -1), 0

    # Recursive step:
    # Calls with (val_other, val_one % val_other).
    # This provides g_p_r_i_m_e, x_p_r_i_m_e, y_p_r_i_m_e such that
    # val_other * x_p_r_i_m_e + (val_one % val_other) * y_p_r_i_m_e = g_p_r_i_m_e
    # We use the identity (val_one % val_other) = val_one - (val_one // val_other) * val_other.
    # Substitute this into the equation:
    # val_other * x_p_r_i_m_e + (val_one - (val_one // val_other) * val_other) * y_p_r_i_m_e = g_p_r_i_m_e
    # Rearrange terms for val_one and val_other:
    # val_one * y_p_r_i_m_e + val_other * (x_p_r_i_m_e - (val_one // val_other) * y_p_r_i_m_e) = g_p_r_i_m_e
    # So, for the current call (val_one, val_other), the coefficients are:
    # x = y_p_r_i_m_e
    # y = x_p_r_i_m_e - (val_one // val_other) * y_p_r_i_m_e
    # The gcd remains g_p_r_i_m_e.
    g_p_r_i_m_e, x_p_r_i_m_e, y_p_r_i_m_e = e_u_c_l_i_d_e_a_n_p_r_o_c_e_d_u_r_e(val_other, val_one % val_other)

    c_o_e_f_x = y_p_r_i_m_e
    c_o_e_f_y = x_p_r_i_m_e - (val_one // val_other) * y_p_r_i_m_e
    return g_p_r_i_m_e, c_o_e_f_x, c_o_e_f_y

def find_solution(f_c_o_e_f_a: int, f_c_o_e_f_b: int, n_v_a_l: int) -> tuple[int, int] | None:
    # Handle the special case where both coefficients are zero.
    # 0*x + 0*y = n_v_a_l
    if f_c_o_e_f_a == 0 and f_c_o_e_f_b == 0:
        if n_v_a_l == 0:
            return (0, 0)  # (0,0) is a valid solution
        else:
            return None    # No solution if n_v_a_l is not 0

    # Use Extended Euclidean Algorithm to find g = gcd(f_c_o_e_f_a, f_c_o_e_f_b)
    # and x_g, y_g such that f_c_o_e_f_a * x_g + f_c_o_e_f_b * y_g = g.
    g_c_d_val, x_g_val, y_g_val = e_u_c_l_i_d_e_a_n_p_r_o_c_e_d_u_r_e(f_c_o_e_f_a, f_c_o_e_f_b)

    # A solution exists only if n_v_a_l is divisible by g_c_d_val.
    if n_v_a_l % g_c_d_val != 0:
        return None

    # Calculate the factor to scale the Bezout identity solution (x_g, y_g)
    # to find a particular solution (x_p, y_p) for a*x + b*y = n.
    l_i_n_e_a_r_f_a_c_t_o_r = n_v_a_l // g_c_d_val
    x_p_a_r_t_i_c_u_l_a_r = x_g_val * l_i_n_e_a_r_f_a_c_t_o_r
    y_p_a_r_t_i_c_u_l_a_r = y_g_val * l_i_n_e_a_r_f_a_c_t_o_r

    # The general solution for ax + by = n is:
    # x = x_p + (b/g)*k
    # y = y_p - (a/g)*k
    # To match test cases, we find the smallest non-negative x.

    # Handle the case where f_c_o_e_f_b is zero separately for modulation.
    # If b is 0, the equation is a*x = n. x is determined, y can be any.
    if f_c_o_e_f_b == 0:
        # x_p_a_r_t_i_c_u_l_a_r already holds n/a. y can be 0.
        return (x_p_a_r_t_i_c_u_l_a_r, 0)
    
    # Normalize x to be the smallest non-negative solution.
    # The period for x is |f_c_o_e_f_b / g_c_d_val|.
    # Python's % operator handles negative numbers such that x % m is in [0, m-1] if m > 0.
    period_x = abs(f_c_o_e_f_b // g_c_d_val)
    
    f_i_n_a_l_x = x_p_a_r_t_i_c_u_l_a_r % period_x
    
    # Calculate the corresponding y value for this f_i_n_a_l_x.
    # f_c_o_e_f_a * f_i_n_a_l_x + f_c_o_e_f_b * f_i_n_a_l_y = n_v_a_l
    # f_i_n_a_l_y = (n_v_a_l - f_c_o_e_f_a * f_i_n_a_l_x) // f_c_o_e_f_b
    f_i_n_a_l_y = (n_v_a_l - f_c_o_e_f_a * f_i_n_a_l_x) // f_c_o_e_f_b

    return f_i_n_a_l_x, f_i_n_a_l_y