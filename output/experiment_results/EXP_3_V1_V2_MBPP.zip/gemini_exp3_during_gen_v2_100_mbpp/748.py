def capital_words_spaces(original_string: str) -> str:
    # output_flow_items: Keeps output elements.
    output_flow_items = []

    for idx_flow, item_flow in enumerate(original_string):
        if item_flow.isupper() and idx_flow > 0:
            output_flow_items.append(" ")
        output_flow_items.append(item_flow)
    
    # Join flow elements.
    return "".join(output_flow_items)