def comb_sort(data_list):
    """
    Performs Comb Sort on the input list.
    """
    list_length = len(data_list)
    gap = list_length
    shrink_factor = 1.3 # Denominator for gap shrinkage
    list_sorted = False

    while gap > 1 or not list_sorted:
        # Determine new gap
        gap = int(gap / shrink_factor)
        if gap < 1:
            gap = 1

        list_sorted = True # Assume data_list is sorted; set to False if swaps happen

        # Perform one pass (like bubble sort, differing gap)
        for i in range(list_length - gap):
            if data_list[i] > data_list[i + gap]:
                # Swapping elements based on gap
                data_list[i], data_list[i + gap] = data_list[i + gap], data_list[i]
                list_sorted = False
    
    return data_list