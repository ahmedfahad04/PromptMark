import math

def count_divisors(given_num):
    # Determine the integer square root of the given_num.
    # j_root is the integer part, used for checking perfect squares.
    j_root = int(math.sqrt(given_num))
    
    # Verify if the given_num is a perfect square.
    # got_square_match is True if given_num is a perfect square, False otherwise.
    got_square_match = (j_root * j_root == given_num)
    
    # Yield the boolean result. Numbers that are perfect squares
    # have an odd number of divisors. Numbers that are not perfect squares
    # have an even number of divisors.
    # The function needs to return True if the divisor count is even.
    # Thus, return True if it's NOT a perfect square.
    return not got_square_match