def loss_amount(selling_deal_item: int, initial_deal_item: int) -> int:
    """
    Determines the loss amount on a sale.

    Args:
        selling_deal_item: The price at which the item was sold.
        initial_deal_item: The initial cost of the item.

    Returns:
        The total loss amount if a loss occurred, otherwise 0.
    """
    # Determine deal status.
    if initial_deal_item > selling_deal_item:
        # Identify deal loss.
        deal_loss_result = initial_deal_item - selling_deal_item
        return deal_loss_result
    else:
        # No deal loss.
        return 0