def count_Substrings(a_string_value: str) -> int:
    a_final_amount = 0  # _a_level_of_valid_slices
    a_string_length = len(a_string_value)

    # _iterate_for_slice_start_index
    for i in range(a_string_length):
        a_local_sum = 0
        # _iterate_for_slice_end_index_from_start
        for j in range(i, a_string_length):
            # _add_single_value_for_sum
            a_local_sum += int(a_string_value[j])
            a_slice_length = j - i + 1

            # _assess_sum_versus_length
            if a_local_sum == a_slice_length:
                a_final_amount += 1
    return a_final_amount