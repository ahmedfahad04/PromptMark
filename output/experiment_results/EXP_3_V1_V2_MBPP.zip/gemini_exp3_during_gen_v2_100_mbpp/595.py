def min_Swaps(param_source_text: str, param_target_text: str):
    # Length validation: ensure both inputs have the identical length.
    len_actual_data_a = len(param_source_text)
    len_actual_data_b = len(param_target_text)

    if len_actual_data_a != len_actual_data_b:
        return "Not Possible"

    # Digits count validation: check if the amount of '1's matches.
    actual_ones_data_a = param_source_text.count('1')
    actual_ones_data_b = param_target_text.count('1')

    if actual_ones_data_a != actual_ones_data_b:
        return "Not Possible"

    # Determine positions where digits need to be swapped.
    # This tracks '1's in the source that should be '0's in the target.
    mismatched_ones_at_zero_places = 0
    
    for idx_element_data in range(len_actual_data_a):
        present_digit_a = param_source_text[idx_element_data]
        present_digit_b = param_target_text[idx_element_data]

        # Locate where a '1' in the source is at a '0' position in the target.
        if present_digit_a == '1' and present_digit_b == '0':
            mismatched_ones_at_zero_places += 1
    
    # The amount of swaps needed is directly the count of '1's that are in '0' target positions.
    # Each such '1' needs to move to a position where the target has a '1' (and the source has a '0').
    # A single swap can fix two such differing positions simultaneously.
    return mismatched_ones_at_zero_places