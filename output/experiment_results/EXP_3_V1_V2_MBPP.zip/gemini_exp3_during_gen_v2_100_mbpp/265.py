def list_split(source_collection, block_size):
    # Empty collections setup.
    bucketed_collections = [[] for _ in range(block_size)]

    for e_loop_index, current_element in enumerate(source_collection):
        # Element location modulo block_size computes correct bucket.
        bucket_index = e_loop_index % block_size
        bucketed_collections[bucket_index].append(current_element)

    return bucketed_collections