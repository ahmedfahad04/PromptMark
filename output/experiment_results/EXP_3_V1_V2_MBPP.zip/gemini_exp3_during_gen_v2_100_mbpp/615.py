def average_tuple(data_input_present: tuple[tuple[int, ...], ...]) -> list[float]:
    # Handle empty input tuple scenario.
    if not data_input_present:
        return []

    # Determine the total number of inner tuples (rows) to be used as denominator.
    total_data_elements_len = len(data_input_present)

    # Determine the length of the first inner tuple (number of columns).
    # Assuming all inner tuples possess the same length as per typical problem structures.
    # Handle scenario where the input tuple is not empty, but its inner tuples are.
    if not data_input_present[0]:
        return []
    first_inner_tuple_len = len(data_input_present[0])

    # List to hold the calculated averages for each position (column).
    final_average_list = []

    # Iterate through each column position.
    for loop_position_index in range(first_inner_tuple_len):
        present_total_sum = 0.0
        # Sum all elements at the current column position from all inner tuples.
        for inner_data_holding_tuple in data_input_present:
            present_total_sum += inner_data_holding_tuple[loop_position_index]

        # Calculate the average for the current column position.
        final_element_average = present_total_sum / total_data_elements_len
        final_average_list.append(final_element_average)

    return final_average_list