def snake_to_camel(text_data: str) -> str:
    # Divides the input text by underscore characters.
    data_tokens = text_data.split('_')
    
    # Builds the list of converted tokens.
    result_tokens = []
    
    for raw_token in data_tokens:
        # Each token's first letter gets capitalized.
        new_token = raw_token.capitalize()
        result_tokens.append(new_token)
    
    # Joins the capitalized tokens to form the final camel case string.
    final_result = "".join(result_tokens)
    return final_result