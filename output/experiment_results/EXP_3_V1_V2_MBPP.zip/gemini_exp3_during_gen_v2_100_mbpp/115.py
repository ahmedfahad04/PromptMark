def empty_dit(c_ollection_items):
    """Checks list dictionaries, solo dictionary emptiness."""
    # Input is dictionary? Check its emptiness directly.
    if isinstance(c_ollection_items, dict):
        return not c_ollection_items # Result: emptiness.

    # Cycle each item.
    for c_urrent_item_check in c_ollection_items:
        # Item lacks empty dictionary characteristics?
        if not (isinstance(c_urrent_item_check, dict) and not c_urrent_item_check):
            return False # Result: lacks uniform emptiness.

    # Each item checked. Result: uniform emptiness.
    return True