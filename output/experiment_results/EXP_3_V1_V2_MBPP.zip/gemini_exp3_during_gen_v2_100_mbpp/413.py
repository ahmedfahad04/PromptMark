def extract_nth_element(data_list, element_index):
    """
    Extracts the element at a specific index from each tuple in a list of tuples.

    Args:
        data_list (list): A list where each item is a tuple.
        element_index (int): The index of the element to extract from each tuple.

    Returns:
        list: A list containing the extracted nth elements.
    """
    collected_elements = []
    # Iterate across each item in the data list
    for each_item in data_list:
        # Access the current element using the provided index
        current_element = each_item[element_index]
        collected_elements.append(current_element)
    return collected_elements