def surface_Area(side_unit: float, height_as_slant_unit: float) -> float:
    # derive area_base_unit, area of the square base
    area_base_unit = side_unit * side_unit

    # derive area_sides_unit, area of the four triangular sides.
    # Each triangular side has an area of (0.5 * side_unit * height_as_slant_unit).
    # The sum of these four areas simplifies to (2 * side_unit * height_as_slant_unit).
    area_sides_unit = 2 * side_unit * height_as_slant_unit

    # derive area_total_unit by adding the base area and the lateral surface area
    area_total_unit = area_base_unit + area_sides_unit
    
    return area_total_unit