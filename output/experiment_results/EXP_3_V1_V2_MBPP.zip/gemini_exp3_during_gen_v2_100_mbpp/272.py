def rear_extract(data_values):
    # A list to store derived values.
    derived_list = []
    # Iterate across data values.
    for an_item in data_values:
        # Add last element.
        # The index -1 accesses the last element of a sequence.
        derived_list.append(an_item[-1])
    return derived_list