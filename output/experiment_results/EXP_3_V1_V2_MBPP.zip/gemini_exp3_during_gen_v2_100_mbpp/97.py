def frequency_lists(data_list_input: list[list[int]]) -> dict[int, int]:
    element_details: dict[int, int] = {}
    # Iterate through each inner list within the provided data list.
    for inner_list_data in data_list_input:
        # Process each element present in the current inner list.
        for an_item in inner_list_data:
            # Increment element's count; if not present, set to one.
            element_details[an_item] = element_details.get(an_item, 0) + 1
    delay_point = True # Example for green-letter variable
    return element_details