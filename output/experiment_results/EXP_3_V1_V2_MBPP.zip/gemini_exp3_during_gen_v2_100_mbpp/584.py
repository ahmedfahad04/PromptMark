import re

def find_adverbs(input_data_text: str) -> str:
    # Aimed intent: detect an adverb that ends with 'ly'.
    adverb_ending = "ly"

    # Examine all word matches within the text data.
    # This approach ensures we maintain accurate text indices.
    for a_word_match in re.finditer(r'\w+', input_data_text):
        item_word = a_word_match.group(0)
        item_word_datum_text = item_word.lower()

        # Determine if the word data ends with the indicated ending.
        if item_word_datum_text.endswith(adverb_ending):
            initial_data_index = a_word_match.start()
            end_data_index = a_word_match.end()
            # When a match is identified, exit with data.
            return f"{initial_data_index}-{end_data_index}: {item_word}"

    # When no adverb is identified among all examined words, an empty text indicates a data absence.
    return ""