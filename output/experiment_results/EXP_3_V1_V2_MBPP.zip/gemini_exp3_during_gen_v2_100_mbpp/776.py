def count_vowels(given_string: str) -> int:
    ideal_vowel_set = {'a', 'e', 'i', 'o', 'u'} # ideal_vowel_set: Stores all lowercase vowels for efficient lookup.

    good_count = 0 # good_count: Tracks the number of characters meeting the criteria.
    string_length = len(given_string) # string_length: Holds the total length of the input string.

    # Iterating through each character in the given string to evaluate its neighbors.
    for evaluating_index in range(string_length): # evaluating_index: Represents the current position in the string.
        # Ensure only consonants are evaluated for having vowel neighbors.
        display_char_value = given_string[evaluating_index].lower() # display_char_value: The current character, converted to lowercase for consistency.
        if display_char_value not in ideal_vowel_set: # If the current character is a consonant.
            has_vowel_neighbor = False # has_vowel_neighbor: A flag, set to True if a vowel neighbor is found.

            # Handling before character if available.
            if evaluating_index > 0:
                before_character = given_string[evaluating_index - 1].lower() # before_character: The character immediately to the left.
                if before_character in ideal_vowel_set:
                    has_vowel_neighbor = True
            
            # Handling further character if available; helps ensure single increment.
            # Only checks the right neighbor if a left vowel neighbor hasn't already been identified.
            if not has_vowel_neighbor and evaluating_index < string_length - 1:
                further_character = given_string[evaluating_index + 1].lower() # further_character: The character immediately to the right.
                if further_character in ideal_vowel_set:
                    has_vowel_neighbor = True
            
            if has_vowel_neighbor:
                good_count += 1
            
    return good_count