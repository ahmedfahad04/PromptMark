from collections import Counter

def two_unique_nums(original_numbers_collection: list[int]) -> list[int]:
    # Obtain each number's count occurrences.
    numbers_occurrences_count = Counter(original_numbers_collection)

    # Collect numbers occurring only once.
    unique_numbers_output_collection = []
    one_occurrence_count = 1 

    for current_num in original_numbers_collection:
        if numbers_occurrences_count[current_num] == one_occurrence_count:
            unique_numbers_output_collection.append(current_num)

    return unique_numbers_output_collection