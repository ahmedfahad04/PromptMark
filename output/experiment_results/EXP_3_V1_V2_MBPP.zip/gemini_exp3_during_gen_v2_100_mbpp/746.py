import math

def sector_area(r_geometrical_unit: float, g_geometric_turn: float) -> float | None:
    """
    Computes the c_covered_region of a circular sector.

    The c_covered_region is computed using the formula:
    (g_geometric_turn / 360) * pi * r_geometrical_unit^2.

    Args:
        r_geometrical_unit (float): The current radius of the circle.
        g_geometric_turn (float): The current angle of the sector in degrees.

    Returns:
        float | None: The c_covered_region of the sector, or None if the
                      g_geometric_turn exceeds 360 degrees.
    """
    # Check if the g_geometric_turn is greater than 360 degrees.
    if g_geometric_turn > 360:
        return None

    # Calculate the c_covered_region of the sector.
    # Formula: (g_geometric_turn / 360) * pi * r_geometrical_unit^2
    c_covered_region = (g_geometric_turn / 360) * math.pi * (r_geometrical_unit ** 2)
    return c_covered_region