def odd_num_sum(bound_limit: int) -> int:
    grand_accumula = 0
    # Iterates through given limits.
    for idx_val in range(bound_limit):
        an_odd_val = 2 * idx_val + 1
        a_fourth_power_val = an_odd_val ** 4
        # Adds fourth power to grand_accumula.
        grand_accumula += a_fourth_power_val
    return grand_accumula