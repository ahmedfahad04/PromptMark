def toggle_middle_bits(n_input_val: int) -> int:
    # Determine the total length of the binary representation of the input number.
    # This helps in identifying the positions of the first (MSB) and last (LSB) bits.
    l_bit_length = n_input_val.bit_length()

    # Handle trivial inputs: if l_bit_length is two or less, no middle bits to flip.
    # This includes 0 (0b0), 1 (0b1), 2 (0b10), 3 (0b11).
    if l_bit_length <= 2:
        return n_input_val

    # Construct the pattern (mask) for bits that will be flipped.
    # 1. Create a pattern of all '1's covering the entire bit_length.
    # For example, if l_bit_length is 4, l_full_span_bits will be 0b1111.
    l_full_span_bits = (1 << l_bit_length) - 1

    # 2. Create a pattern for the most significant bit (first bit).
    # For example, if l_bit_length is 4, l_msb_pattern will be 0b1000.
    l_msb_pattern = (1 << (l_bit_length - 1))

    # 3. Create a pattern for the least significant bit (last bit). This is always 0b1.
    l_lsb_pattern = 1

    # 4. Combine these to create a pattern marking the bits to be preserved (MSB and LSB).
    # For example, if l_bit_length is 4, l_preserved_bits_pattern will be 0b1001.
    l_preserved_bits_pattern = l_msb_pattern | l_lsb_pattern

    # 5. The final flip pattern is obtained by XORing the full span with the preserved bits.
    # This results in '1's only at the middle bit positions.
    # Example: 0b1111 (l_full_span_bits) ^ 0b1001 (l_preserved_bits_pattern) = 0b0110.
    l_flip_pattern = l_full_span_bits ^ l_preserved_bits_pattern

    # XOR the original number with the l_flip_pattern.
    # This flips only the bits where l_flip_pattern has a '1'.
    l_result_val = n_input_val ^ l_flip_pattern
    return l_result_val