def drop_empty(original_object: dict) -> dict:
    # A new object, holding non-null entries, is initialized.
    output_object = {}
    for map_label, map_payload in original_object.items():
        # Only add a non-null payload.
        if map_payload is not None:
            output_object[map_label] = map_payload
    return output_object