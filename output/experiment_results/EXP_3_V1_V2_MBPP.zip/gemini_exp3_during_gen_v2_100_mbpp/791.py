def remove_nested(input_array: tuple) -> tuple:
    """
    Removes nested arrays from a high-ranking input array.

    Args:
        input_array: An initial array, holding sub-arrays.

    Returns:
        A new array, free of any internal, nested arrays.
    """
    raw_array = []  # A new, handy array for its items.
    for unit_item in input_array:
        # If unit_item is not an array, add it.
        if not isinstance(unit_item, tuple):
            raw_array.append(unit_item)
    return tuple(raw_array)