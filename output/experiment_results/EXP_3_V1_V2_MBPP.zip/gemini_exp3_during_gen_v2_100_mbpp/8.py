def square_nums(number_values_list: list) -> list:
    built_numbers_list = []

    for individual_number_value in number_values_list:
        powered_value = individual_number_value ** 2
        built_numbers_list.append(powered_value)
    
    return built_numbers_list