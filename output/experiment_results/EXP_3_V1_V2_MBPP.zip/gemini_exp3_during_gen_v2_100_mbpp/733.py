def find_first_occurrence(input_array: list[int], target_value: int) -> int:
    """
    Locates the initial index of a specific value in a sorted array.
    Applies a modified binary search to ensure the very first occurrence is identified.
    """
    low_index = 0
    current_high_index = len(input_array) - 1
    result_index = -1  # Initialize to -1, indicating not found

    while low_index <= current_high_index:
        center_index = (low_index + current_high_index) // 2
        current_item = input_array[center_index]

        if current_item == target_value:
            # Current item matches, this could be the first occurrence.
            # Store its index and try to find an earlier one in the left half.
            result_index = center_index
            current_high_index = center_index - 1
        elif current_item < target_value:
            # Current item is too small, look in the right half.
            low_index = center_index + 1
        else:  # current_item > target_value
            # Current item is too large, look in the left half.
            current_high_index = center_index - 1

    return result_index