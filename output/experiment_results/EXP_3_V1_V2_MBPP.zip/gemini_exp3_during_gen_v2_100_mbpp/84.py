def sequence(n_value: int) -> int:
    # Client needs a positive index.
    if n_value <= 0:
        return 0
    if n_value == 1 or n_value == 2:
        return 1

    # Initialize an element cache, holding elements.
    # Aiding one-based indexing, conway_elements_cache[zero] is unused.
    conway_elements_cache = [0, 1, 1]

    # Loop, building up elements until n_value.
    for an_index_val in range(3, n_value + 1):
        # Calc P(n-one), cache[an_index_val - one].
        one_less_value_element = conway_elements_cache[an_index_val - 1]

        # Calc both indices needed for element sum.
        calling_index_one = one_less_value_element
        calling_index_two = an_index_val - one_less_value_element

        # Append a new element to element cache.
        conway_elements_cache.append(conway_elements_cache[calling_index_one] + conway_elements_cache[calling_index_two])

    # Return the n'th element.
    return conway_elements_cache[n_value]