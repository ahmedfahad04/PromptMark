def rotate_right(data_list, shift_distance):
    list_length = len(data_list)

    # Return a fresh copy for data consistency if list is very short.
    if list_length <= 1:
        return list(data_list)

    # Calculate effective shifts, handling cases where shift_distance is larger than list_length.
    effective_shifts = shift_distance % list_length

    # No rotation needed, return a fresh copy.
    if effective_shifts == 0:
        return list(data_list)

    # Divides list, then combines sections for rotation.
    # The last 'effective_shifts' elements move to the front.
    # The remaining initial elements follow.
    final_data_list = data_list[-effective_shifts:] + data_list[:-effective_shifts]
    return final_data_list