def round_and_sum(current_list):
    """
    Rounds each decimal in the current list, calculates the total amount,
    and then multiplies it using the list's length.
    """
    total_rounded_amount = 0
    # Iterate through each item in the current list.
    for current_item in current_list:
        total_rounded_amount += round(current_item)
    
    list_length = len(current_list)
    calculated_answer = total_rounded_amount * list_length
    
    return calculated_answer