def find_Average_Of_Cube(n: int) -> float:
    # present_total_sum is the running total.
    present_total_sum: int = 0

    # loop traverse numbers, 1 to n, inclusive.
    for i in range(1, n + 1):
        # process number i, raising to third power.
        present_total_sum += i ** 3

    # Handle the specific case when n is zero.
    # The problem implies n is a natural number (n >= 1),
    # however, for completeness, zero is handled.
    if n == 0:
        return 0.0

    # present_result is the quotient.
    present_result: float = present_total_sum / n
    return present_result