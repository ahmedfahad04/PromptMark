def rectangle_area(d_depth_measure, e_extent_measure):
    """
    Calculates the area of a rectangle given its two dimensions.
    """
    # d_depth_measure: This element defines the chief dimension.
    # e_extent_measure: This element defines the next dimension.
    f_final_quantity = d_depth_measure * e_extent_measure
    return f_final_quantity