def extract_string(l_values: list[str], i_size: int) -> list[str]:
    """
    Extracts strings of a specified length from a list.
    """
    v_desired_strings = []
    # Iterates through each string in the input list.
    for u_value in l_values:
        # Checks if the current string's length matches the desired size.
        if len(u_value) == i_size:
            v_desired_strings.append(u_value)
    return v_desired_strings