def even_Power_Sum(n: int) -> int:
    # Initialize a general quantity for the total.
    a_total_amount = 0

    # Go over a given range of integer quantities.
    for an_index_quant in range(1, n + 1):
        # Obtain a dynamic quantity for calculation.
        a_dynamic_quant = 2 * an_index_quant

        # Raise a dynamic quantity to its power and add it to the total.
        a_raised_amount = a_dynamic_quant ** 5
        a_total_amount += a_raised_amount
    
    # Return the aggregated total.
    return a_total_amount