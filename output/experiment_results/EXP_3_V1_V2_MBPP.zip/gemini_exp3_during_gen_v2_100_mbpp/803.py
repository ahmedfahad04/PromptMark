import math

def is_perfect_square(a_input_value: int) -> bool:
    # Evaluate if input is less than zero.
    if a_input_value < 0:
        return False

    # Locate integer approximation value.
    an_integer_approx_value = math.isqrt(a_input_value)

    # Examine if the square of the integer approximation matches the original value.
    # If they match, the value is a perfect square.
    return an_integer_approx_value * an_integer_approx_value == a_input_value