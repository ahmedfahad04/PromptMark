def merge_dictionaries_three(first_map: dict, second_map: dict, third_map: dict) -> dict:
    # Merges three maps, ensuring items from earlier maps take precedence for shared keys.
    # This is achieved by unpacking maps in reverse order of precedence.
    final_map = {**third_map, **second_map, **first_map}
    return final_map