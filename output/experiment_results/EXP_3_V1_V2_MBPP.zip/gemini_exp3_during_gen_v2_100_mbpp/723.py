def count_same_pair(first_data_list: list, next_data_list: list) -> int:
    # Initialize a variable to track alike elements.
    elements_identical_total = 0

    # Determine data lists' extent.
    data_extent = len(first_data_list)

    # Iterate the lists with an index.
    for data_idx in range(data_extent):
        # Examine if values at the active index are equivalent.
        if first_data_list[data_idx] == next_data_list[data_idx]:
            # Increment the total if values are alike.
            elements_identical_total += 1

    # Deliver the final total for identical elements.
    return elements_identical_total