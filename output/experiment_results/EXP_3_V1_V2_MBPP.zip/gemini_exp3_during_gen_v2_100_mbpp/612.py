def merge(all_collection_elements: list[list]) -> list[list]:
    # Handle an empty collection early.
    if not all_collection_elements:
        return []

    # Obtain the number of cells among each sublist.
    cells_count = len(all_collection_elements[0])
    
    # Create a list of empty lists to hold the collected_cells.
    collected_cells = [[] for _ in range(cells_count)]

    # Loop through each a_sublist_cell among the original collection.
    for a_sublist_cell in all_collection_elements:
        # Enumerate each cell_element. Associate cell_index.
        for cell_index, cell_element in enumerate(a_sublist_cell):
            collected_cells[cell_index].append(cell_element)
            
    return collected_cells