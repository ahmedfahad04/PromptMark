def insert_element(given_list, key_element):
    processed_list = []
    # Loop over each object_item present in the given_list.
    for object_item in given_list:
        # Prepend the key_element.
        processed_list.append(key_element)
        # Then, append the original object_item.
        processed_list.append(object_item)
    return processed_list