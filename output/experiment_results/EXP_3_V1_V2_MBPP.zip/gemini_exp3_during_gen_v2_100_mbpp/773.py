def occurance_substring(p_main_string: str, p_sub_string: str):
    """
    Checks the presence and position of a substring within a main string.

    Parameters:
        p_main_string (str): The string to inspect.
        p_sub_string (str): The substring to search for.

    Returns:
        tuple: A tuple (substring, start_index, end_index) if match is found.
        None: If no match is found.
    """
    p_start_index = p_main_string.find(p_sub_string)

    # Checks if the substring exists.
    if p_start_index == -1:
        return None
    else:
        p_chunk_size = len(p_sub_string)
        # Calculates the end index.
        p_end_index = p_start_index + p_chunk_size
        # Supplies current tuple details.
        return (p_sub_string, p_start_index, p_end_index)