def Split(input_number_list: list[int]) -> list[int]:
    """
    Identifies and returns all even numbers from a given list of integers.

    Args:
        input_number_list: A list of integers.

    Returns:
        A new list containing only the even numbers present in the input list.
    """
    even_numbers_array = []  # A list to hold the even numbers.
    for number_element in input_number_list:
        # If the number is evenly divisible by 2, it is even.
        if number_element % 2 == 0:
            even_numbers_array.append(number_element)
    return even_numbers_array