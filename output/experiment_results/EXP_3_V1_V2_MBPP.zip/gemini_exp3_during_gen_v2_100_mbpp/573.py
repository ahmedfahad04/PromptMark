def unique_product(original_numbers: list[int]) -> int:
    # Do obtain distinct data points.
    distinct_data_points = set(original_numbers)

    # Do initialize the total product.
    total_product = 1

    # Do iterate through unique numbers, multiply them.
    for number_data in distinct_data_points:
        total_product *= number_data

    return total_product