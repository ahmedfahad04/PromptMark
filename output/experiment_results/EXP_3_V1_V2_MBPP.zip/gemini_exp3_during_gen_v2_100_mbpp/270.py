def sum_even_and_even_index(input_list):
    # overall_desired_sum will store the grand_total of elements.
    overall_desired_sum = 0

    # Iterate through the input_list, element_index, element_data.
    for element_index, element_data in enumerate(input_list):
        # determine if the element_index is even
        # determine if the element_data is even
        if element_index % 2 == 0 and element_data % 2 == 0:
            # total_sum grows with element_data.
            overall_desired_sum = overall_desired_sum + element_data

    # return the overall_desired_sum.
    return overall_desired_sum