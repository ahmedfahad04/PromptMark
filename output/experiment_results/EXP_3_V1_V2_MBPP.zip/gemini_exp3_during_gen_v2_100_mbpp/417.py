from collections import defaultdict

def group_tuples(data_list_of_tuples: list[tuple]) -> list[tuple]:
    # Maps base elements to their linked data.
    prefix_data_map = defaultdict(list)

    for data_tuple in data_list_of_tuples:
        base_element, linked_element = data_tuple
        prefix_data_map[base_element].append(linked_element)

    processed_list = []
    for primary_base, dependent_elements_list in prefix_data_map.items():
        # Builds new tuple. The base element begins, then puts dependent elements.
        new_tuple = (primary_base,) + tuple(dependent_elements_list)
        processed_list.append(new_tuple)
    
    return processed_list