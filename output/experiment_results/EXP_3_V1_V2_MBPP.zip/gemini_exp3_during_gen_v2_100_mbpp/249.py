def intersection_array(data_one_array: list, data_two_array: list) -> list:
    # Convert data arrays into data sets for efficient common item identification.
    current_data_one_set = set(data_one_array)
    current_data_two_set = set(data_two_array)

    # Determine the intersection of the two data sets.
    common_data_elements = current_data_one_set.intersection(current_data_two_set)

    # Convert common data elements into a list.
    collected_data = list(common_data_elements)
    
    # Order the collected data elements as indicated in the test cases.
    collected_data.sort()
    
    return collected_data