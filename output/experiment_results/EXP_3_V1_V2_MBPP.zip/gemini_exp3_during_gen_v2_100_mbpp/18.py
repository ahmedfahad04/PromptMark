def remove_dirty_chars(source_chars: str, omitted_chars: str) -> str:
    # Creates quick lookup set.
    omitted_chars_lookup_set = set(omitted_chars)

    clean_chars_collector = [] # Output collector of chars.

    for current_char in source_chars:
        # Collects chars. Omits lookup set members.
        if current_char not in omitted_chars_lookup_set:
            clean_chars_collector.append(current_char)

    # Combines collected chars.
    output_string_result = "".join(clean_chars_collector)
    return output_string_result