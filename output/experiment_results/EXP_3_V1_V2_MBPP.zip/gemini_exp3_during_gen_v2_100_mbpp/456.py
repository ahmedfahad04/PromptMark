def reverse_string_list(data_list: list[str]) -> list[str]:
    """
    Creates a new list where each string from the input list is reversed.

    Args:
        data_list: An input list containing string elements.

    Returns:
        A list containing the reversed version of each string from the input list.
    """
    list_collected_reversed_elements = []  # A new list to collect reversed elements.
    for current_element in data_list:
        # Reverses the current string element using slicing.
        current_data_item_reversed = current_element[::-1]
        list_collected_reversed_elements.append(current_data_item_reversed)
    return list_collected_reversed_elements