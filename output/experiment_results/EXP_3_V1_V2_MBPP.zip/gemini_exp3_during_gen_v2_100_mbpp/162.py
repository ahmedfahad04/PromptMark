def sum_series(n_val: int) -> int:
    daily_amount = 0  # Accumulated daily amount.
    final_limit = n_val // 2 # Looping index limit.
    
    # Jumps index 'j_val' from zero, arriving at 'final_limit' inclusive.
    for j_val in range(final_limit + 1): 
        value_item = n_val - (2 * j_val) # Individual item's value.
        daily_amount += value_item # Joins value_item into daily_amount.
        
    return daily_amount