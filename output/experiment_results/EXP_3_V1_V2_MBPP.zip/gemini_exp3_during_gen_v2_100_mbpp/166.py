def find_even_pair(a_list: list[int]) -> int:
    i_even_amount = 0
    a_odd_amount = 0

    # Iterate through the list to count even and odd numbers.
    for l_item in a_list:
        if l_item % 2 == 0:
            i_even_amount += 1
        else:
            a_odd_amount += 1

    # Calculate pairs where both numbers are even.
    # An even XOR even always results in an even number.
    j_even_pairs_from_evens = i_even_amount * (i_even_amount - 1) // 2

    # Calculate pairs where both numbers are odd.
    # An odd XOR odd always results in an even number.
    a_odd_pairs_from_odds = a_odd_amount * (a_odd_amount - 1) // 2
    
    # Sum the counts for the total amount of pairs that XOR to an even number.
    j_final_amount = j_even_pairs_from_evens + a_odd_pairs_from_odds
    return j_final_amount