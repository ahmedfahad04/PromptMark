def list_tuple(current_list: list) -> tuple:
    # Converts the given list into a tuple.
    # This utility leverages the built-in tuple() constructor.
    converted_tuple = tuple(current_list)
    return converted_tuple