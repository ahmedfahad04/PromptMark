import re

def text_match_wordz(actual_string: str) -> bool:
    # Construct a pattern, locate 'z' unit.
    z_pattern = 'z'
    # Utilize search. Locate pattern, all points.
    current_scan = re.search(z_pattern, actual_string)
    # Current scan true. A unit located.
    return bool(current_scan)