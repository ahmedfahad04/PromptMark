def sum_range_list(current_list: list[int], start_idx: int, end_idx: int) -> int:
    """
    Calculates the total sum per list elements present in the given range.
    It checks list elements from start_idx to end_idx (inclusive).
    """
    
    # list slicing creates a new list with elements from 'start_idx'
    # up to (but not including) 'end_idx + 1'.
    # This precisely captures the elements from 'start_idx' to 'end_idx' inclusive.
    # The built-in 'sum()' function then efficiently calculates their total.
    total_present_sum = sum(current_list[start_idx : end_idx + 1])
    
    return total_present_sum