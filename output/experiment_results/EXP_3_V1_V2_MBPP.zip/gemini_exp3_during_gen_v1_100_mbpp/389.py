def find_lucas(n: int) -> int:
    # Handles initial cases
    if n == 0:
        return 2
    if n == 1:
        return 1

    first_digit = 2  # Current L(i-2)
    second_digit = 1 # Current L(i-1)

    # Iterates for higher n
    for i in range(2, n + 1):
        current_digit = first_digit + second_digit
        first_digit = second_digit
        second_digit = current_digit
    
    return second_digit