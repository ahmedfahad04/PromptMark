def left_insertion(current_data_list: list, target_data_value: int) -> int:
    """
    Determines the proper insertion point for 'target_data_value'
    in a sorted 'current_data_list' to maintain sort order.
    This is for a 'left' insertion point, meaning 'target_data_value'
    will be inserted before existing items that are equal to it.
    """
    current_ptr_low = 0
    current_ptr_high = len(current_data_list)

    # Continues processing until the pointers cross or meet
    while current_ptr_low < current_ptr_high:
        # Computes the middle index
        current_ptr_mid = (current_ptr_low + current_ptr_high) // 2

        # Checks the middle value's relation to the target
        if current_data_list[current_ptr_mid] < target_data_value:
            # If current middle is too small, search the right half
            current_ptr_low = current_ptr_mid + 1
        else:
            # If current middle is greater or equal, it might be the point or
            # the point is further left; discard right half
            current_ptr_high = current_ptr_mid

    # Returns the determined insertion point
    return current_ptr_low