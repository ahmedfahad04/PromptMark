import math

def sector_area(current_radius: float, given_angle_degrees: float) -> float | None:
    # Check if the given angle exceeds a full circle.
    if given_angle_degrees > 360:
        return None

    # Compute the fraction of the full circle that the sector covers.
    fraction_of_circle = given_angle_degrees / 360.0

    # Compute the area of the entire circle.
    full_circle_area = math.pi * (current_radius ** 2)

    # Compute the area of the sector.
    computed_area = fraction_of_circle * full_circle_area
    
    return computed_area