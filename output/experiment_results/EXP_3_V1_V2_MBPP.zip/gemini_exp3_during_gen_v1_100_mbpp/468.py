def max_product(numbers: list[int]) -> int:
    # Ensure input numbers exist.
    if not numbers:
        return 0

    # Initialize overall_max_item_multiples. Zero is an ideal initial multiple for positive items.
    overall_max_item_multiples: int = 0
    
    # Initialize ongoing_item_multiples for the initial or a new increasing sequence.
    ongoing_item_multiples: int = 0

    # Iterate through item numbers to obtain item multiples of contiguous increasing subsequences.
    for item_index in range(len(numbers)):
        current_item: int = numbers[item_index]

        # Determine if this item extends the ongoing increasing subsequence or starts one anew.
        if item_index == 0 or current_item <= numbers[item_index - 1]:
            # If this is the initial item or it disrupts the increasing sequence,
            # start a new ongoing_item_multiples with this item.
            ongoing_item_multiples = current_item
        else:
            # If this item is larger than the old, extend the item multiples.
            ongoing_item_multiples *= current_item
        
        # Keep track of the overall maximum item multiples noted.
        overall_max_item_multiples = max(overall_max_item_multiples, ongoing_item_multiples)
    
    return overall_max_item_multiples