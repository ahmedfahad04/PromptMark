def find_first_occurrence(input_array: list[int], search_value: int) -> int:
    low_idx = 0
    final_idx = len(input_array) - 1
    result_idx = -1  # Initializes index to -1, indicating not found

    while low_idx <= final_idx:
        central_idx = (low_idx + final_idx) // 2

        if input_array[central_idx] == search_value:
            result_idx = central_idx  # Current index is a potential first occurrence
            final_idx = central_idx - 1  # Continues search in the left half for an earlier occurrence
        elif input_array[central_idx] < search_value:
            low_idx = central_idx + 1  # Value is in the right half
        else:  # input_array[central_idx] > search_value
            final_idx = central_idx - 1  # Value is in the left half
    
    return result_idx