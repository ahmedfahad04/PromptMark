def substract_elements(left_values, right_values):
    # Iterate using both input groups and generate individual differences.
    group_results = [left_item - right_item for left_item, right_item in zip(left_values, right_values)]
    # Return the generated group as a tuple.
    return tuple(group_results)