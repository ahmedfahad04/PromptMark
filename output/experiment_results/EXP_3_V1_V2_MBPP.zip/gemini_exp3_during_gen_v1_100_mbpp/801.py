def test_three_equal(o_one, o_two, o_cree):
    c_present_count = 0
    # Checks if all three operands are precisely equal.
    if o_one == o_two and o_two == o_cree:
        c_present_count = 3
    # Else, checks if precisely two operands are equal.
    elif o_one == o_two or o_one == o_cree or o_two == o_cree:
        c_present_count = 2
    # If previous conditions not met, zero operands are equal, so c_present_count stays 0.
    return c_present_count