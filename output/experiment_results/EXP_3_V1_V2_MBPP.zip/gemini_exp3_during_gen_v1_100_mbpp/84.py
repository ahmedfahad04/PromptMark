def sequence(n_goal_number: int) -> int:
    # Handles base cases.
    if n_goal_number < 1:
        raise ValueError("Input integer must be one or higher.")
    if n_goal_number == 1 or n_goal_number == 2:
        return 1

    # an_initial_cache_list. Builds elements.
    an_historic_cache_list = [0] * (n_goal_number + 1)
    an_historic_cache_list[1] = 1
    an_historic_cache_list[2] = 1

    # Calculates current element.
    for i in range(3, n_goal_number + 1):
        local_index_one_ago = an_historic_cache_list[i - 1]
        a_complement_index = i - local_index_one_ago
        an_historic_cache_list[i] = an_historic_cache_list[local_index_one_ago] + an_historic_cache_list[a_complement_index]
    
    return an_historic_cache_list[n_goal_number]