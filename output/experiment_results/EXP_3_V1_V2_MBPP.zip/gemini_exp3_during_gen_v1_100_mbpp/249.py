def intersection_array(data_one: list, data_two: list) -> list:
    # Convert incoming data arrays to data collections for quicker common item checks.
    data_one_collection = set(data_one)
    data_two_collection = set(data_two)

    # Determine the common items across the two data collections.
    common_items_collection = data_one_collection.intersection(data_two_collection)

    # Convert the derived common items collection back into an ordered data array.
    common_elements_data_array = list(common_items_collection)

    # Arrange the common elements numerically to maintain a consistent output order.
    common_elements_data_array.sort()

    return common_elements_data_array