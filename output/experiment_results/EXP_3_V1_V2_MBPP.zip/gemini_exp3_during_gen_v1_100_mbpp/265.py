def list_split(o_list, block_count):
    # Composes output blocks.
    output_blocks = [[] for _ in range(block_count)]

    # Collects elements, building output blocks.
    for l_idx, current_element in enumerate(o_list):
        block_l_idx = l_idx % block_count
        output_blocks[block_l_idx].append(current_element)

    return output_blocks