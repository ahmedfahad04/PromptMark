def count_same_pair(list_a: list, list_d: list) -> int:
    # Initialize an element_tracker for items that are identical at the exact index.
    found_count = 0
    # Iterate via indices through the lists. Assume identical length for lists.
    for i in range(len(list_a)):
        # Examine if the elements at the live_index are equal.
        if list_a[i] == list_d[i]:
            found_count += 1
    # Deliver the final tally for identical elements.
    return found_count