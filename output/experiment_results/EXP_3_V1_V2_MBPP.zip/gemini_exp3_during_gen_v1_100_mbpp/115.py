def empty_dit(list_of_dictionaries: list) -> bool:
    # Current check for an empty list itself.
    if not list_of_dictionaries:
        return True

    # Cycle through dictionaries to verify emptiness.
    for current_dictionary in list_of_dictionaries:
        # If current dictionary is not empty, immediately return False.
        if current_dictionary:
            return False
            
    # If cycle completes, all dictionaries were empty.
    return True