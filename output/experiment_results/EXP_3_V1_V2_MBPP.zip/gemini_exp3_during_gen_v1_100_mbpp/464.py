def check_value(current_object_holder: dict, needed_number) -> bool:
    # Ensure the dictionary is not empty, so there are values present
    # to compare with the needed_number.
    if not current_object_holder:
        return False

    # Check that each value present in the dictionary corresponds to the needed_number.
    # The 'all()' function ensures that every comparison yields True.
    return all(one_value == needed_number for one_value in current_object_holder.values())