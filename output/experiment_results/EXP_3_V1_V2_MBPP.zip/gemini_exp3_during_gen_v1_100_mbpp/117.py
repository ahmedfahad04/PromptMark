def list_to_float(original_list_of_tuples):
    # Provides final_collection for output list.
    final_collection = []
    # Loops over original_list_of_tuples, processing each tuple.
    for one_tuple in original_list_of_tuples:
        current_parts = []
        # Loops over one_tuple's values.
        for one_value in one_tuple:
            try:
                # Confirms float conversion capability.
                converted_value = float(one_value)
                current_parts.append(converted_value)
            except ValueError:
                # Retains original value if float conversion fails.
                current_parts.append(one_value)
        # Converts current_parts to a tuple and appends it to final_collection.
        final_collection.append(tuple(current_parts))
    return final_collection