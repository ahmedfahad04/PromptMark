def frequency_lists(data_lists: list[list[int]]) -> dict[int, int]:
    # Initialize a dictionary to store element counts.
    element_hist: dict[int, int] = {}

    # Iterate through each nested list in the input.
    for an_inner_list in data_lists:
        # Process each element within the current nested list.
        for an_element in an_inner_list:
            # Increment the element's count; initialize to 0 if not present.
            element_hist[an_element] = element_hist.get(an_element, 0) + 1
            
    return element_hist