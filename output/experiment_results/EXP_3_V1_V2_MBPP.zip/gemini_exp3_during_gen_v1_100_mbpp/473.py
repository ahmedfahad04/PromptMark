def tuple_intersection(first_list_of_pairs: list[tuple], second_list_of_pairs: list[tuple]) -> set[tuple]:
    """
    Finds the common pairs of elements between two lists of tuples,
    disregarding the order of elements within each pair.

    Args:
        first_list_of_pairs: A list of tuples, where each tuple has two elements.
        second_list_of_pairs: A list of tuples, where each tuple has two elements.

    Returns:
        A set of tuples representing the intersection. Each tuple in the result
        is in a normalized (sorted) form.
    """

    # Helper function to prepare a list of tuples for intersection.
    # It normalizes each tuple by sorting its elements, ensuring that
    # (a, b) and (b, a) are treated as the same, and then stores them in a set.
    def _prepare_data_for_hashing(a_list_of_raw_pairs: list[tuple]) -> set[tuple]:
        parsed_data = set()
        for a_pair in a_list_of_raw_pairs:
            # Sorts the elements within the tuple to handle order irrelevance.
            # Example: (5, 4) becomes (4, 5).
            sorted_pair = tuple(sorted(a_pair))
            parsed_data.add(sorted_pair)
        return parsed_data

    # Prepare both input lists by normalizing their tuples into sets.
    parsed_first_data = _prepare_data_for_hashing(first_list_of_pairs)
    parsed_second_data = _prepare_data_for_hashing(second_list_of_pairs)

    # Perform set intersection to find common normalized tuples.
    final_intersection_result = parsed_first_data & parsed_second_data

    return final_intersection_result