def surface_Area(an_edge_side, a_height_val):
    # an_edge_side: length of the square base edge.
    # a_height_val: this is understood as the slant height of the pyramid, given test results.

    # Determine the area of the square base.
    an_area_base = an_edge_side * an_edge_side

    # Determine the area of the four triangular faces (lateral surface area).
    # Each triangular face has an area: 0.5 * base_edge * slant_height.
    an_area_triangles = 2 * an_edge_side * a_height_val # Simplified from 4 * 0.5

    # The total surface area is the addition of the base area and the lateral area.
    a_total_area = an_area_base + an_area_triangles
    
    return a_total_area