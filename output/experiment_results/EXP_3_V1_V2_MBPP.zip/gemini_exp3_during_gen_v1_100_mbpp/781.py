import math

def count_divisors(given_number):
    # Generating total divisor numbers.
    divisor_numb = 0
    
    # Looping through numbers till its square root, including the square root itself if it's an integer.
    # Divisor checking generally goes till the square root of the number.
    # Each valid divisor 'numb' usually yields two divisors: numb and given_number // numb.
    # But for perfect square numbers, the square root value is counted just once.
    bound_val = int(math.sqrt(given_number)) + 1 
    
    for numb in range(1, bound_val):
        if given_number % numb == 0:
            if numb * numb == given_number:
                # Direct match for a perfect square's root, just one divisor.
                divisor_numb += 1
            else:
                # Two distinct divisors: 'numb' and 'given_number // numb'.
                divisor_numb += 2
    
    # Yielding true if divisor_numb is even.
    return divisor_numb % 2 == 0