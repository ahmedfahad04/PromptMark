def move_num(given_data: str) -> str:
    # A_initialize two empty data structures: an_alpha_data for non-digits, and a_digit_data for digits.
    an_alpha_data = ""
    a_digit_data = ""

    # Iterate through an_each_item of the given input data.
    for an_item in given_data:
        # Determine if an_item is a digit.
        if an_item.isdigit():
            # If an_item is a digit, append it to a_digit_data.
            a_digit_data += an_item
        else:
            # If an_item is not a digit, append it to an_alpha_data.
            an_alpha_data += an_item

    # Join the non-digit data (an_alpha_data) with the digit data (a_digit_data) and then return the new string.
    return an_alpha_data + a_digit_data