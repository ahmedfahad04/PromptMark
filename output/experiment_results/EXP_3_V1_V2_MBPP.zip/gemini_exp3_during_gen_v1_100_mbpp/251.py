def insert_element(list_to_process, element_to_prepend):
    kept_list = [] # produces kept_list to hold elements
    for present_element in list_to_process:
        kept_list.append(element_to_prepend) # prepend given element
        kept_list.append(present_element)    # then append original list's element
    op = kept_list # output processed list
    return op