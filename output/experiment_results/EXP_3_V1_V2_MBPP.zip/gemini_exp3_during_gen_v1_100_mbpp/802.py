def count_rotation(arr: list) -> int:
    array_size = len(arr)
    if array_size == 0:
        return 0

    # An element's index, i, advances.
    for i in range(array_size - 1):
        # A breakpoint, arr[i] is above arr[i+1].
        if arr[i] > arr[i + 1]:
            # Its index i+1 is a rotation's amount.
            return i + 1

    # Array already is a sorted array.
    return 0