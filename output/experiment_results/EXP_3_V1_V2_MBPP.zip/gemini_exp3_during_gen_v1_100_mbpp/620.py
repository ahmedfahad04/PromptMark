def largest_subset(numbers_list: list) -> int:
    # Handle the case of an empty list, where no subset can be formed.
    if not numbers_list:
        return 0

    # Order the list elements. This simplifies divisibility checks
    # as we only need to check if a larger number is divisible by a smaller one.
    ordered_numbers = sorted(numbers_list)
    
    list_count = len(ordered_numbers)
    # Initialize 'subset_lengths' list. Each element subset_lengths[i] will store
    # the size of the largest divisible subset ending with ordered_numbers[i].
    # Initially, each number itself forms a subset of length 1.
    subset_lengths = [1] * list_count

    # Iterate through each number in the ordered list starting from the second element.
    for current_index in range(1, list_count):
        current_element = ordered_numbers[current_index]
        
        # Check against all previous elements to find potential predecessors in a divisible subset.
        for previous_index in range(current_index):
            previous_element = ordered_numbers[previous_index]
            
            # If the current element is divisible by a previous element, it means
            # we can potentially extend the subset ending at 'previous_element'.
            if current_element % previous_element == 0:
                # Update the length of the largest divisible subset ending at 'current_element'.
                # It's either its current length or 1 (for current element) + the length
                # of the largest subset ending at 'previous_element'.
                subset_lengths[current_index] = max(
                    subset_lengths[current_index],
                    1 + subset_lengths[previous_index]
                )
    
    # The maximum value in 'subset_lengths' represents the size of the overall
    # largest divisible subset found.
    return max(subset_lengths)