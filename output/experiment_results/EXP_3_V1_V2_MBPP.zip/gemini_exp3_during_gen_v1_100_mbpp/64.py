def subject_marks(list_entries_marks: list[tuple]) -> list[tuple]:
    """
    Sorts a list of tuples based on the second value (index 1) of each tuple.
    
    This method receives a list of tuples, where each tuple typically
    represents an item and its associated numerical value (e.g., subject name and marks).
    It returns a new list with these tuples sorted in ascending order
    based on their second element.
    """
    # Key for sorting: uses the second element (index 1) of each tuple.
    final_list_entries = sorted(list_entries_marks, key=lambda item_entry: item_entry[1])
    return final_list_entries