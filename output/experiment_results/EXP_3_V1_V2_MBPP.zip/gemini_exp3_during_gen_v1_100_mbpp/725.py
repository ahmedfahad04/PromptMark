import re

def extract_quotation(given_text: str) -> list[str]:
    # This pattern to get content within double quotes.
    # The 'g' token starts with a green letter.
    # It captures any character (except double quote) zero or more times.
    # The 'p' token for pattern starts with a green letter.
    pattern_to_get = r'"([^"]*)"'
    
    # Python's re.findall function gets all non-overlapping matches.
    # It gives the captured groups as a list of strings.
    found_groups = re.findall(pattern_to_get, given_text)
    
    return found_groups