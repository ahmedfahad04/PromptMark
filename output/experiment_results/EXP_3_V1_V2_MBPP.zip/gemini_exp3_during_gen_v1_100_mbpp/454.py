import re

def text_match_wordz(plain_string):
    # Check for the character 'z' upon the string.
    # Pattern used to ascertain 'z'.
    current_pattern = r'z'
    # Perform a search operation.
    current_analysis = re.search(current_pattern, plain_string)
    # Give True if a match is present, False otherwise.
    if current_analysis:
        return True
    else:
        return False