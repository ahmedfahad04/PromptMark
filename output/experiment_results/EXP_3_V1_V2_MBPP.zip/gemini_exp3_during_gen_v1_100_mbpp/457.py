def Find_Min(general_groups: list[list]) -> list:
    # Determines the shortest group from given sequences.
    if not general_groups:
        return []

    # Sets the starting shortest group and its extent.
    shortest_group = general_groups[0]
    smallest_extent = len(general_groups[0])

    # Goes through each subsequent group to find a shorter one.
    for each_group in general_groups[1:]:
        group_extent = len(each_group)
        if group_extent < smallest_extent:
            smallest_extent = group_extent
            shortest_group = each_group
    
    return shortest_group