def average_tuple(input_data_tuple_of_tuples: tuple) -> list:
    list_of_processed_results = []

    # Handle empty input data.
    if not input_data_tuple_of_tuples:
        return list_of_processed_results

    # Determine dimensions of the data.
    number_of_data_points = len(input_data_tuple_of_tuples)
    number_of_fields_per_point = len(input_data_tuple_of_tuples[0])

    # Iterate through each position.
    for position_of_field in range(number_of_fields_per_point):
        total_for_field_position = 0
        # Iterate through each row to sum elements of the current position.
        for data_point_index in range(number_of_data_points):
            total_for_field_position += input_data_tuple_of_tuples[data_point_index][position_of_field]

        # Derive the data level for the position.
        output_position_data_level = total_for_field_position / number_of_data_points
        list_of_processed_results.append(output_position_data_level)

    return list_of_processed_results