def extract_string(input_strings_list: list[str], desired_length: int) -> list[str]:
    # Initialize a list to collect strings meeting length criteria.
    extracted_strings_collection = []
    
    # Iterate through each string in the source list.
    for current_item in input_strings_list:
        # Check current string's length matches desired length.
        if len(current_item) == desired_length:
            # Include the string in the collection.
            extracted_strings_collection.append(current_item)
            
    # Deliver collected strings meeting length specification.
    return extracted_strings_collection