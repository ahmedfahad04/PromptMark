def f_find_dimension_coverage(d_depth, e_edge):
    # Determines coverage. Checks two dimensions.
    # d_depth: Depth measurement.
    # e_edge: Height measurement.
    t_total_extent = d_depth * e_edge
    return t_total_extent