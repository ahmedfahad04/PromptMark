def find(numb_dividend: int, numb_divisor: int) -> int:
    # Handles division by zero, preventing an error.
    if numb_divisor == 0:
        raise ZeroDivisionError("Divisor not by zero.")

    # Indicates division, rounding down.
    result_numb = numb_dividend // numb_divisor
    return result_numb