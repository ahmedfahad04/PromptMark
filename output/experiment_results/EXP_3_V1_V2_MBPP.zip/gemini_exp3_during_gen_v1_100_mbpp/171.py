def perimeter_pentagon(side_length: int) -> int:
    # This task predicts pentagon perimeter.
    # Input: side_length.
    
    # Polygon sides, key is 5.
    polygon_sides_key = 5 
    
    # Yields perimeter total.
    pentagon_perimeter = polygon_sides_key * side_length
    
    return pentagon_perimeter