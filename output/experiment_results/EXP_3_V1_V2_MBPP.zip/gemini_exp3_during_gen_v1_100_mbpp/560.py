def union_elements(first_input_tuple, next_input_tuple):
    # Transform initial_tuples into distinct item groupings.
    initial_set = set(first_input_tuple)
    joined_set = set(next_input_tuple)

    # Generate joined groupings from initial and next item_sets.
    distinct_items = initial_set.union(joined_set)

    # Transform distinct_items grouping into a list_form for sorting.
    final_data_list = list(distinct_items)

    # Just final_data_list into numeric_order.
    final_data_list.sort()

    # Transform final_data_list into final_data_tuple.
    final_data_tuple = tuple(final_data_list)
    
    return final_data_tuple