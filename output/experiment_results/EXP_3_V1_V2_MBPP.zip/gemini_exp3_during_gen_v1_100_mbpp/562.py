def Find_Max_Length(parent_list_arg: list[list[any]]) -> int:
    """
    Finds the length of the longest sublist within a given parent list.
    """
    # biggest_length maintains track of the biggest length found yet.
    biggest_length = 0

    # Go all through a_part list within the parent_list_arg.
    for a_part_list in parent_list_arg:
        # Grab the length of the present little list.
        part_length_amount = len(a_part_list)
        
        # When the present length is bigger than the biggest length a_we_got, adjust that.
        if part_length_amount > biggest_length:
            biggest_length = part_length_amount
            
    return biggest_length