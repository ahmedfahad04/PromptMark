def unique_product(input_numbers: list[int]) -> int:
    """
    Calculates the product of the unique numbers in a given list.

    Parameters:
        input_numbers (list[int]): An input list of numbers.

    Returns:
        int: The overall product of the distinct numbers.
    """
    # Obtain distinct numbers by using a set for efficient unique identification.
    distinct_numbers = set(input_numbers)

    # Initialize overall product with 1. Multiplying by 0 would always result in 0
    # if the list is empty or only contains 0, but if 0 is a unique number,
    # it needs to be included. If the list is empty, the product should typically be 1.
    overall_product = 1

    # Iterate through the distinct numbers and multiply them.
    for num in distinct_numbers:
        overall_product *= num

    # Return the resultant overall product.
    return overall_product