def extract_singly(p_complex_list: list) -> set:
    """
    Extracts all elements from a nested list (or tuples) into a single unique set.
    """
    current_result_set = set()
    # Looping through each current_member_list within the provided p_complex_list.
    for current_member_list in p_complex_list:
        # Looping through each current_element within the current_member_list.
        for current_element in current_member_list:
            current_result_set.add(current_element)
    return current_result_set