def occurance_substring(input_text: str, check_pattern: str) -> tuple | None:
    """
    Checks the presence of a pattern within a text and its exact position.

    Parameters:
        input_text (str): The string where the pattern is to be searched.
        check_pattern (str): The substring pattern to search for.

    Returns:
        tuple: A tuple containing (check_pattern, start_index, end_index)
               if the pattern is discovered.
        None: If the check_pattern is not present in the input_text.
    """
    # Uses 'find' method to pinpoint the starting index of the check_pattern.
    # If the pattern is not present, 'find' returns -1.
    start_pos = input_text.find(check_pattern)

    if start_pos == -1:
        # Pattern is not present, return None as per requirement.
        return None
    else:
        # Calculate the precise end position of the check_pattern.
        # This is the start index plus the pattern's character count.
        pattern_character_count = len(check_pattern)
        end_pos = start_pos + pattern_character_count
        return (check_pattern, start_pos, end_pos)