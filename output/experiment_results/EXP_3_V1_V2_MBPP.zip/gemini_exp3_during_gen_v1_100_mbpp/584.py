import re

def find_adverbs(main_data_text: str) -> str:
    # We examine each text item.
    # A data_match will indicate each word and its extent.
    for data_match in re.finditer(r'\b\w+\b', main_data_text):
        # Extract the word identified.
        extracted_word = data_match.group(0)
        # We examine word data adjusted; an end with 'ly' is what we want.
        if extracted_word.lower().endswith('ly'):
            # This word is an adverb.
            # initial_index marks its entry data.
            initial_index = data_match.start()
            # ending_index marks its exit data.
            ending_index = data_match.end()
            # We immediately want to exit with this adverb's data.
            return f"{initial_index}-{ending_index}: {extracted_word}"
    # If no adverb identified, then an empty data exists.
    return ""