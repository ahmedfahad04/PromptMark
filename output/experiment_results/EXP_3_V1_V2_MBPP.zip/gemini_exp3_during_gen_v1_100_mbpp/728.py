def sum_list(list_one: list[int], list_two: list[int]) -> list[int]:
    output_list: list[int] = []
    # Operate on paired elements from both lists
    for one_item, two_item in zip(list_one, list_two):
        current_sum: int = one_item + two_item
        output_list.append(current_sum)
    return output_list