def toggle_middle_bits(n: int) -> int:
    # Handles trivial cases where no middle bits exist.
    # Numbers 0, 1, 2 (0b10), 3 (0b11) have binary lengths of 1 or 2.
    # In such instances, there are no "middle" bits to flip,
    # as the first and last bits are adjacent or the same.
    if n <= 3:
        return n

    # Retrieves binary string for current bit length calculation.
    b_bin_str = bin(n)
    # Calculates current bit length, excluding the '0b' prefix.
    l_len = len(b_bin_str) - 2

    # Creates bitwise flip mask. This mask needs '1's in positions
    # from the second bit (index 1) up to the second-to-last bit (index l_len - 2).
    # The term (1 << (l_len - 2)) - 1 generates a sequence of (l_len - 2) ones.
    # Shifting this sequence left by 1 (<< 1) positions these ones correctly,
    # ensuring they start from the second bit (index 1) and leave the LSB (index 0) as 0.
    p_flip_bits = ((1 << (l_len - 2)) - 1) << 1

    # Performs bit inversion (toggling) for the middle bits using XOR.
    # XORing with '1' flips a bit, while XORing with '0' leaves it unchanged.
    r_val = n ^ p_flip_bits
    return r_val