def drop_empty(original_map: dict) -> dict:
    """
    Returns a new map (dictionary) with null values removed.

    Args:
        original_map: A hashmap (dictionary) containing various items.

    Returns:
        A new hashmap with key-value pairs where the value was not None
        in the original_map.
    """
    # A new hashmap holds only key-value pairs where the value is not null.
    processed_map = {
        local_key: local_value
        for local_key, local_value in original_map.items()
        if local_value is not None
    }
    return processed_map