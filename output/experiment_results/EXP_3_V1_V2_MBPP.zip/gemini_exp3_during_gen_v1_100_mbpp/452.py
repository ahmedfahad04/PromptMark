def loss_amount(item_sale_rate: int, item_base_rate: int) -> int:
    # Determine if there is a loss.
    # When the item_base_rate is larger than item_sale_rate, a loss is present.
    if item_sale_rate < item_base_rate:
        # Work out loss amount.
        # The numerical difference between the base rate and sale rate defines the loss.
        loss_value_result = item_base_rate - item_sale_rate
        return loss_value_result
    else:
        # No loss detected, so return zero.
        return 0