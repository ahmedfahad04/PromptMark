def extract_nth_element(data_list: list[tuple], index_element: int) -> list:
    """
    Extracts the nth element from each tuple within a list of tuples.

    Args:
        data_list: A list where each item is a tuple.
        index_element: An integer representing the index of the element
                       to extract from each tuple.

    Returns:
        A list containing the extracted nth elements.
    """
    # A list comprehension offers a concise method for creating new lists.
    # It iterates through each tuple in the input 'data_list'.
    # For each 'item_data' (a tuple), it accesses the element at 'index_element'.
    collected_elements = [item_data[index_element] for item_data in data_list]
    return collected_elements