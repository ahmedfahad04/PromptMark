def trim_tuple(given_blocks_collection, chop_num):
    # Generates collection containing chunks chopped from both boundaries by chop_num.
    fresh_chunks_collection = [
        block[chop_num:-chop_num] for block in given_blocks_collection
    ]
    # Builds string showing fresh_chunks_collection content.
    return str(fresh_chunks_collection)