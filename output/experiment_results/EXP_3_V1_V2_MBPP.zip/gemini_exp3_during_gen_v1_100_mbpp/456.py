def reverse_string_list(current_data_list: list[str]) -> list[str]:
    """
    Reverses each string within a given list of strings.

    Args:
        current_data_list: A list of strings to be processed.

    Returns:
        A new list where each original string is reversed.
    """
    collected_list = []  # Init collection.
    for current_item in current_data_list:
        data_reversed = current_item[::-1]
        collected_list.append(data_reversed)
    return collected_list