def string_to_tuple(input_data_string: str) -> tuple:
    # Initiate an empty list to store non-space characters.
    non_space_list = []
    # Iterate on each individual character within the input string.
    for each_char in input_data_string:
        # Include only characters that are not a space.
        if each_char != ' ':
            non_space_list.append(each_char)
    # Develop an output tuple from the list of filtered characters.
    an_output_tuple = tuple(non_space_list)
    return an_output_tuple