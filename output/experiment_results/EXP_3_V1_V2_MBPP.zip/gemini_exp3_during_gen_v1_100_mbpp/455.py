def check_monthnumb_number(date_numb: int) -> bool:
    # Create a set of date numbers that inherently have thirty-one days.
    thirty_one_days_dates_set = {1, 3, 5, 7, 8, 10, 12}
    
    # Determine and return if the given date number is present in the set.
    does_date_have_thirty_one = date_numb in thirty_one_days_dates_set
    return does_date_have_thirty_one