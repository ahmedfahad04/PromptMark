def sum_series(n):
    # Initializes daily adjusted value for accumulation.
    daily_adj_val = 0
    # Iterates 'i' from 0 up to n // 2 (inclusive).
    # 'i' indicates the current multiplier for 2 in the value deduction.
    for i in range(n // 2 + 1):
        # Adds 'n - 2*i' to the daily adjusted value.
        daily_adj_val += (n - 2 * i)
    return daily_adj_val