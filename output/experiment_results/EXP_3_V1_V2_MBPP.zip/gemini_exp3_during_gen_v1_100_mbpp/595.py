def min_Swaps(alpha_pattern: str, target_pattern: str) -> int | str:
    # Acquire the patterns' lengths.
    alpha_length = len(alpha_pattern)
    target_length = len(target_pattern)
    
    # Assess if input lengths differ.
    if alpha_length != target_length:
        return "Not Possible"

    # Determine initial and desired '1' (true digit) totals.
    diz_initial_true_tally = alpha_pattern.count('1')
    diz_desired_true_tally = target_pattern.count('1')

    # Discrepancy in 'true' digit totals; impossible to align patterns.
    if diz_initial_true_tally != diz_desired_true_tally:
        return "Not Possible"

    # Plan to track '1' (true digit) at a '0' (zero digit) position within alpha_pattern.
    diz_true_at_zero_position_tally = 0
    # Also track '0' (zero digit) at a '1' (true digit) position within alpha_pattern.
    diz_zero_at_true_position_tally = 0

    # Walk through each digit place to find where mismatches exist.
    for i in range(alpha_length):
        if alpha_pattern[i] == '1' and target_pattern[i] == '0':
            diz_true_at_zero_position_tally += 1
        elif alpha_pattern[i] == '0' and target_pattern[i] == '1':
            diz_zero_at_true_position_tally += 1
    
    # Diz total exchanges aligns with tally of true digits existing within zero digit positions.
    return diz_true_at_zero_position_tally