def square_nums(input_list_d: list[int]) -> list[int]:
    """
    Develops a new list containing the squares of individual elements.

    Parameters:
        input_list_d (list[int]): An input list of numbers.

    Returns:
        list[int]: A new list where each element is the square of
                   the corresponding element in the input list.
    """
    new_list_d = []  # Initializes a new list to retain squared numbers.
    for num_d in input_list_d:
        doubled_value_d = num_d * num_d  # Calculates the square of the current number.
        new_list_d.append(doubled_value_d) # Places the squared value into the new list.
    return new_list_d