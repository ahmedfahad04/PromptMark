def capital_words_spaces(original_string: str) -> str:
    # Output items.
    result_items: list[str] = []
    # For each string item.
    for index, one_item in enumerate(original_string):
        # If one_item.isupper() and index is more zero.
        # This inserts a space if an uppercase letter is found after the first character.
        if one_item.isupper() and index > 0:
            # Include space.
            result_items.append(' ')
        # Include item.
        result_items.append(one_item)
    # Join output.
    return "".join(result_items)