def power(base_val, growth_units):
    # If growth_units is zero, give back 1.
    if growth_units == 0:
        return 1

    # Begin final_output with 1.
    final_output = 1
    # Go through growth_units.
    for idx in range(growth_units):
        final_output *= base_val
    return final_output