def square_Sum(n):
    # cumulative_quantity: final numeric quantity.
    cumulative_quantity = 0
    # current_position loops for n_counts.
    for current_position in range(1, n + 1):
        # current_num: numeric count, current (2*current_position - 1) form.
        current_num = 2 * current_position - 1
        powered_result = current_num * current_num
        # cumulative_quantity collects powered_results.
        cumulative_quantity += powered_result
    return cumulative_quantity