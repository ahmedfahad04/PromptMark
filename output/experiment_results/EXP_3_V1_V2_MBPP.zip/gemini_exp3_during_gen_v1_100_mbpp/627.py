def find_First_Missing(incoming_chart_list: list[int]) -> int:
    # Check if 0 is the current smallest missing number.
    # This will be true if the incoming_chart_list is empty, or if its initial item is not 0.
    if not incoming_chart_list or incoming_chart_list[0] != 0:
        return 0

    # Iterate through the incoming_chart_list using an index 'i'.
    # We compare each chart item with its expected value (which should be 'i').
    for i in range(len(incoming_chart_list)):
        current_chart_item = incoming_chart_list[i]
        # If the current chart item does not match its index 'i',
        # then 'i' is the first value missing from the sequence.
        if current_chart_item != i:
            return i

    # If the iteration finishes without finding a mismatch, it indicates
    # that all numbers from 0 up to (length - 1) are present in the list.
    # In this case, the smallest missing number is simply the length of the list.
    return len(incoming_chart_list)