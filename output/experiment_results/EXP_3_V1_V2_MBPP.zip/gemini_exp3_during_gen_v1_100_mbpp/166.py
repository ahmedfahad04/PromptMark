def find_even_pair(a_input_list: list[int]) -> int:
    # All items with a last bit as 0.
    a_amount_lsb_is_0 = 0
    # All items with a last bit as 1.
    a_amount_lsb_is_1 = 0

    # Walk for all list items.
    for a_item in a_input_list:
        # If a item shows a last bit as 0.
        if a_item % 2 == 0:
            a_amount_lsb_is_0 += 1
        # Else, a last bit is 1.
        else:
            a_amount_lsb_is_1 += 1

    # All matched items from LSB 0.
    a_all_items_with_lsb_0_matched_sum = (a_amount_lsb_is_0 * (a_amount_lsb_is_0 - 1)) // 2

    # All matched items from LSB 1.
    a_all_items_with_lsb_1_matched_sum = (a_amount_lsb_is_1 * (a_amount_lsb_is_1 - 1)) // 2

    # A final sum for all matched items.
    a_final_sum = a_all_items_with_lsb_0_matched_sum + a_all_items_with_lsb_1_matched_sum

    return a_final_sum