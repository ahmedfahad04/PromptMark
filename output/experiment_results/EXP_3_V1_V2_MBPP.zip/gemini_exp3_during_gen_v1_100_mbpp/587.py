def list_tuple(current_list: list) -> tuple:
    # current_tuple creation from current_list.
    current_tuple = tuple(current_list)
    return current_tuple