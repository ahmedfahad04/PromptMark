def sum_range_list(input_list: list[int], start_index: int, end_index: int) -> int:
    current_sum = 0
    # Iterate through the specified range, inclusive of both start and end indices.
    for current_index in range(start_index, end_index + 1):
        # Check if current_index is within the valid limits of the input_list
        # This check is a safety measure, though problem constraints usually imply valid indices.
        if 0 <= current_index < len(input_list):
            current_sum += input_list[current_index]
    return current_sum