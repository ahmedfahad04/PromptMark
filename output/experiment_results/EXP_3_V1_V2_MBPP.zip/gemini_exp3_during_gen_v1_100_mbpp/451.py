def remove_whitespaces(input_string: str) -> str:
    # r_resulting_string is for keeping non-whitespace characters.
    r_resulting_string = ""

    # j_iterate_each_symbol to check for whitespaces.
    for j_symbol in input_string:
        # i_if the j_symbol is not a whitespace, include it.
        if not j_symbol.isspace():
            r_resulting_string += j_symbol
    return r_resulting_string