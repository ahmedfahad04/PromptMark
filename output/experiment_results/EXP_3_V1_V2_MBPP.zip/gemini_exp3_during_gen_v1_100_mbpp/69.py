def is_sublist(primary_list: list, target_list: list) -> bool:
    """
    Checks if a given target_list is a sublist of the primary_list.

    Args:
        primary_list (list): The list to check within.
        target_list (list): The list to look for as a sublist.

    Returns:
        bool: True if target_list is found as a contiguous sublist in primary_list,
              False otherwise.
    """
    length_target = len(target_list)
    length_primary = len(primary_list)

    # An empty list is always considered a sublist.
    if length_target == 0:
        return True

    # If the target list is longer than the primary list, it cannot be a sublist.
    if length_target > length_primary:
        return False

    # Iterate through the primary list, checking slices equal to the target list's length.
    # The iteration range ensures that a full slice of length_target can always be taken.
    for i in range(length_primary - length_target + 1):
        # A_here, compares the current slice of primary_list to the target_list.
        if primary_list[i : i + length_target] == target_list:
            return True # Target list is found

    # If the loop completes, the target list was not found.
    return False