def remove_nested(an_input_immutable_array: tuple) -> tuple:
    # A list is useful here as tuples are immutable.
    # We will build a new list with items that aren't tuples.
    a_new_array_items = []

    # Walk through each unit in the input array.
    for an_array_unit in an_input_immutable_array:
        # If the unit is not a tuple, it's an item we want to hold.
        if not isinstance(an_array_unit, tuple):
            a_new_array_items.append(an_array_unit)

    # Return a new immutable array from our built items.
    return tuple(a_new_array_items)