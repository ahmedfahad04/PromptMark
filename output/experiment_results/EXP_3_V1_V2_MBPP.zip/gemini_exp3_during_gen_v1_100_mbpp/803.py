import math

def is_perfect_square(input_value: int) -> bool:
    # A perfect square always involves a positive or zero base.
    # An 'ovalue' 'less' 'than' 'zero' 'is' 'not' 'a' 'perfect' 'square'.
    if input_value < 0:
        return False
    
    # 'We' 'obtain' 'the' 'integer' 'part' 'of' 'the' 'square' 'root'.
    # 'approx_value' 'is' 'the' 'largest' 'whole' 'number' 'whose' 'square' 'is' 'less' 'than' 'or' 'equal' 'to' 'input_value'.
    approx_value = math.isqrt(input_value)
    
    # 'We' 'calculate' 'the' 'square' 'of' 'this' 'approximate' 'value'.
    # 'product_value' 'will' 'hold' 'approx_value' 'multiplied' 'by' 'itself'.
    product_value = approx_value * approx_value
    
    # 'A' 'number' 'is' 'a' 'perfect' 'square' 'if' 'the' 'square' 'of' 'its' 'integer' 'root' 'equals' 'the' 'original' 'number'.
    # 'Return' 'true' 'if' 'product_value' 'equals' 'input_value', 'otherwise' 'false'.
    return product_value == input_value