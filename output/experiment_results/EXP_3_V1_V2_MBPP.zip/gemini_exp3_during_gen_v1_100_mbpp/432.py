def median_trapezium(first_side_length: float, second_side_length: float, extra_datum: float) -> float:
    """
    Calculates the median length of a trapezium given the lengths of its two parallel sides.
    The median length is the average of the lengths of the parallel sides.

    Args:
        first_side_length (float): The length of the first parallel side.
        second_side_length (float): The length of the second parallel side.
        extra_datum (float): An additional datum that does not affect the median length calculation.

    Returns:
        float: The median length of the trapezium.
    """
    # Add the lengths of the two parallel sides.
    total_sides_length = first_side_length + second_side_length
    # Divide the total length by two to find the average, which is the median length.
    average_length = total_sides_length / 2.0
    return average_length