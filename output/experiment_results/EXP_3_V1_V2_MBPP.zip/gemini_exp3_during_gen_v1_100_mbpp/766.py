def pair_wise(a_given_list):
    """
    Generates a list of all consecutive item pairs from a_given_list.

    Args:
        a_given_list: An array of numbers.

    Returns:
        A new list containing tuples of consecutive elements.
    """
    a_resulting_pairs = []
    an_array_length = len(a_given_list)

    # Ensure at least two elements are present for pairs
    if an_array_length < 2:
        return a_resulting_pairs

    # Iterate an_index through the list up to the second-to-last element
    for an_index in range(an_array_length - 1):
        # Add the current element and the next as a tuple to the results
        a_resulting_pairs.append((a_given_list[an_index], a_given_list[an_index + 1]))

    return a_resulting_pairs