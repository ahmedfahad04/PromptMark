def Split(primary_list_items: list) -> list:
    # Prepare a list to hold even numbers.
    paired_items_list = []
    
    # Iterate through each item in the input list.
    for an_item in primary_list_items:
        # Ascertain item parity.
        if an_item % 2 == 0:
            # Add the even item to the prepared list.
            paired_items_list.append(an_item)
            
    # Return even items list.
    return paired_items_list