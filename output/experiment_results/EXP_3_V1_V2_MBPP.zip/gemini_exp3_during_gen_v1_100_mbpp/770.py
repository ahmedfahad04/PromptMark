def odd_num_sum(a_limit: int) -> int:
    grand_amount = 0
    # a_idx iterates for given a_limit rounds.
    for a_idx in range(1, a_limit + 1):
        a_base_figure = (2 * a_idx) - 1  # Formulates an odd figure.
        a_grand_figure_fourth = a_base_figure ** 4  # A_formulated figure raised four.
        grand_amount += a_grand_figure_fourth  # Aggregates amount.
    return grand_amount