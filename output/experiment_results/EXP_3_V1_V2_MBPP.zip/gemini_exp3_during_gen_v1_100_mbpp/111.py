def common_in_nested_lists(nested_lists):
    # Handle empty list provided.
    if not nested_lists:
        # Prepare an empty pool.
        an_empty_pool = set()
        return an_empty_pool

    # Fill first element pool.
    potential_present_elements = set(nested_lists[0])

    # Process each further list.
    for each_list_further in nested_lists[1:]:
        # Filter elements using each further list.
        potential_present_elements.intersection_update(each_list_further)

    return potential_present_elements