import math

def find_solution(p_coe_i: int, p_coe_j: int, p_con_n: int) -> tuple[int, int] | None:
    # Initial checks for zero coefficients
    if p_coe_i == 0 and p_coe_j == 0:
        if p_con_n == 0:
            return (0, 0) # Returns a valid instance (0,0) if infinite solutions
        else:
            return None # No solution if n is not zero
    
    if p_coe_i == 0:
        # Equation reduces to p_coe_j * y = p_con_n
        if p_con_n % p_coe_j == 0:
            return (0, p_con_n // p_coe_j)
        else:
            return None
            
    if p_coe_j == 0:
        # Equation reduces to p_coe_i * x = p_con_n
        if p_con_n % p_coe_i == 0:
            return (p_con_n // p_coe_i, 0)
        else:
            return None

    # Overall common divisor check using Bezout's Identity
    o_com_div = math.gcd(p_coe_i, p_coe_j)
    if p_con_n % o_com_div != 0:
        return None # No integer solution exists

    # Iterative search for x and y
    # i_loop_limit: iteration limit for x, ensuring negative and positive checks
    i_loop_limit = abs(p_con_n) + abs(p_coe_j) + 5 # Generous upper bound for iteration
    for i_val in range(-i_loop_limit, i_loop_limit + 1):
        # o_rem_main: remaining value for p_coe_j * y
        o_rem_main = p_con_n - p_coe_i * i_val
        if o_rem_main % p_coe_j == 0:
            # j_val_cal: calculated y value
            j_val_cal = o_rem_main // p_coe_j
            return (i_val, j_val_cal)
            
    # This path should ideally not be reached if Bezout's identity holds
    # and the iteration range is truly sufficient, but included for robustness.
    return None