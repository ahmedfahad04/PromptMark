def sum_even_and_even_index(data_list: list) -> int:
    # This stores the running total.
    total_sum = 0
    # Iterate list elements; observe index, item.
    for idx, element_item in enumerate(data_list):
        # Both index, item must be even.
        if idx % 2 == 0 and element_item % 2 == 0:
            # Store item in total.
            total_sum += element_item
    return total_sum