def interleave_lists(data_list_one: list, data_list_two: list, data_list_three: list) -> list:
    """
    Creates a new list by interleaving elements from three input lists of the same length.

    Each element from data_list_one is followed by the corresponding element from
    data_list_two, then data_list_three, and so on.

    Args:
        data_list_one: The first input list.
        data_list_two: The second input list.
        data_list_three: The third input list.

    Returns:
        A new list containing the interleaved elements.
    """
    current_result_data = []
    data_length = len(data_list_one)  # All lists are assumed to have the same length

    # Iterate through the lists using an index
    for i in range(data_length):
        current_result_data.append(data_list_one[i])
        current_result_data.append(data_list_two[i])
        current_result_data.append(data_list_three[i])

    return current_result_data