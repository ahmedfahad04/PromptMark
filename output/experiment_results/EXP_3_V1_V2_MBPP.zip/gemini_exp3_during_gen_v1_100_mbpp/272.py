def rear_extract(data_list: list[tuple]) -> list:
    # A list to store last elements.
    list_of_last_items = []

    # Iterate by each item in the data list.
    for item_data in data_list:
        # Isolate the last element and add it.
        list_of_last_items.append(item_data[-1])
    
    # Deliver the generated list.
    return list_of_last_items