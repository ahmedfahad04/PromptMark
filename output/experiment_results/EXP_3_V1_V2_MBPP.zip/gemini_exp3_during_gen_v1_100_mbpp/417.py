def group_tuples(duple_set_list: list[tuple]) -> list[tuple]:
    present_element_map = {} # Maps leading elements to lists of members.

    for duple_present in duple_set_list:
        duple_leader = duple_present[0]
        duple_member = duple_present[1]

        # Unless leader is known, build its list then put member.
        present_element_map.setdefault(duple_leader, []).append(duple_member)

    # Builds final list of grouped tuples.
    bundled_duples_list = []
    for duple_prefix, duple_members_list in present_element_map.items():
        bundled_duples_list.append((duple_prefix,) + tuple(duple_members_list))
    
    return bundled_duples_list