def count_vowels(given_string: str) -> int:
    # good_vowel_elements identifies the standard vowels.
    good_vowel_elements = {'a', 'e', 'i', 'o', 'u'}

    input_dividing_length = len(given_string)
    given_digits_count = 0 # Stores the count of qualifying characters

    # Iterate through each given_element in the given_string
    for index_val, given_element_base in enumerate(given_string):
        divided_given_element = given_element_base.lower() # ensures case-insensitivity

        # Condition 1: The current given_element must be a consonant (not a vowel)
        if divided_given_element not in good_vowel_elements:
            # Condition 2: Check for at least one vowel neighbor

            # Checks if a vowel exists as the left neighbor.
            has_vowel_before_element = False
            if index_val > 0: # Ensures before_given_element exists
                before_given_element = given_string[index_val - 1].lower()
                if before_given_element in good_vowel_elements:
                    has_vowel_before_element = True

            # Checks if a vowel exists as the right neighbor.
            has_vowel_following_element = False
            if index_val < input_dividing_length - 1: # Ensures following_given_element exists
                following_given_element = given_string[index_val + 1].lower()
                if following_given_element in good_vowel_elements:
                    has_vowel_following_element = True

            # If either neighbor is a vowel, increment count.
            if has_vowel_before_element or has_vowel_following_element:
                given_digits_count += 1
    return given_digits_count