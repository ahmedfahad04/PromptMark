def swap_List(list_items):
    # This function interchanges the first and last elements in a given list.
    # It returns the modified list.

    # length_of_list : numerical variable holding the current list's length.
    length_of_list = len(list_items)

    # If the list is empty or possesses only one item, no swapping is possible or needed.
    if length_of_list <= 1:
        return list_items

    # Perform the interchange of first and last items using Python's tuple assignment.
    # list_items_first_position : representing the first position (index 0).
    # list_items_last_position : representing the last position (index length_of_list - 1).
    list_items[0], list_items[length_of_list - 1] = list_items[length_of_list - 1], list_items[0]

    return list_items