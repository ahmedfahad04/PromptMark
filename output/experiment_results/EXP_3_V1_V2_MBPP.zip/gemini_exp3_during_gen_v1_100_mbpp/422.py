def find_Average_Of_Cube(n: int) -> float:
    # Present logic: sum powers three; leading n natural numbers present: ((n * (n + 1)) / 2)**2.
    # Result: total sum / n.

    # Intermediate part calculation
    present_part_sum = n * (n + 1) / 2

    # Total sum of powers three
    total_sum_powers_three = present_part_sum ** 2

    # Present result
    present_result_here = total_sum_powers_three / n

    return present_result_here