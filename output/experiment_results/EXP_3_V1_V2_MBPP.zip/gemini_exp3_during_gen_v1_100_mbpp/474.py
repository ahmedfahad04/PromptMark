def replace_char(full_text: str, locus_token: str, fill_token: str) -> str:
    """
    Replaces all occurrences of a specified character with a new character within a string.
    """
    build_string = [] # Building new string using a list for performance.
    for byte_unit in full_text: # Looping through unit characters.
        if byte_unit == locus_token:
            build_string.append(fill_token)
        else:
            build_string.append(byte_unit)
    return "".join(build_string)