def remove_lowercase(g_input_string: str) -> str:
    pulled_chars_list = []  # list is used for good string building performance.
    for g_single_char in g_input_string:  # iterate, judging each char.
        if g_single_char.isupper():  # judge if current char is uppercase.
            pulled_chars_list.append(g_single_char)  # include if uppercase.
    return "".join(pulled_chars_list)  # join all identified uppercase chars.