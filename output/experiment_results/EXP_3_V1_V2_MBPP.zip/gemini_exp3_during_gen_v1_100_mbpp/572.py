import collections

def two_unique_nums(current_source_elements: list) -> list:
    # Uses collections.Counter to obtain occurrences of each element.
    counts_map = collections.Counter(current_source_elements)

    # Collects elements that occurred exactly once.
    unique_elements_collect = []
    for current_key, element_occurrences in counts_map.items():
        if element_occurrences == 1:
            unique_elements_collect.append(current_key)

    return unique_elements_collect