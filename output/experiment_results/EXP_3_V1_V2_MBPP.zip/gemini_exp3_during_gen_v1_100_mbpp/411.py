def snake_to_camel(d_text_entry: str) -> str:
    # Denotes the text entry.
    k_word_elements = d_text_entry.split('_')
    y_new_form_parts = []  # Keeps new form parts.
    for d_element in k_word_elements:
        if d_element:  # Ensures empty parts get skipped.
            y_new_form_parts.append(d_element[0].upper() + d_element[1:])
    n_final_form = "".join(y_new_form_parts)
    return n_final_form