def rotate_right(current_data_list: list, shift_cycles: int) -> list:
    """
    Rotates a given list to the right by a specified number of items.

    Args:
        current_data_list (list): The original list to be rotated.
        shift_cycles (int): The number of positions to rotate the list to the right.

    Returns:
        list: The new list after rotation.
    """
    data_length = len(current_data_list)

    # Initial checks for trivial cases:
    # If the list is empty, or no rotations are specified, or if rotation
    # count is a multiple of list length (effectively no change),
    # then return the list as is.
    if data_length == 0 or shift_cycles == 0:
        return list(current_data_list) # Return a copy to follow standard practice for list functions

    # This determines the actual number of shifts needed.
    # For example, rotating a list of 10 items by 13 is the same as rotating by 3.
    actual_shifts = shift_cycles % data_length

    # If, after the modulo operation, actual_shifts is 0 (e.g., rotating 10 items by 10),
    # it means the list effectively remains unchanged.
    if actual_shifts == 0:
        return list(current_data_list) # Return a copy

    # The list is divided into two parts:
    # 1. 'trailing_elements': The last 'actual_shifts' elements, which move to the front.
    # 2. 'leading_elements': The remaining elements, which follow 'trailing_elements'.
    trailing_elements = current_data_list[data_length - actual_shifts:]
    leading_elements = current_data_list[:data_length - actual_shifts]

    # The rotated_collection is formed by concatenating these two parts.
    rotated_collection = trailing_elements + leading_elements
    return rotated_collection