def even_Power_Sum(an_input_amount: int) -> int:
    # overall_grand_total: Gathers the total sum of even numbers raised to the fifth power.
    overall_grand_total = 0

    # Go through iterations from 1 up to 'an_input_amount', to calculate each term.
    for i in range(1, an_input_amount + 1):
        # an_iteration_datum: Represents the i-th even natural number (e.g., 2, 4, 6...).
        an_iteration_datum = 2 * i
        
        # a_quantity_raised_to_degree: The current even number raised to its fifth power.
        a_quantity_raised_to_degree = an_iteration_datum ** 5
        
        # Add the calculated power to the overall running total.
        overall_grand_total += a_quantity_raised_to_degree
        
    return overall_grand_total