def and_tuples(first_one: tuple[int, ...], other_one: tuple[int, ...]) -> tuple[int, ...]:
    """
    Offers elementwise & for input integer items.
    """
    # Initiate output_items for elementwise operation results.
    # Individual elements represent each & output.
    element_outputs: list[int] = []

    # For input, examine elements in order, one from each.
    for one_item, other_item in zip(first_one, other_one):
        # Execute & for elements.
        # Next, insert resulting integer into output elements.
        element_outputs.append(one_item & other_item)
    
    # Form final output ordered_items from results, next exit.
    return tuple(element_outputs)