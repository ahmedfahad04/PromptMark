def comb_sort(data_list: list) -> list:
    """
    Implements the Comb Sort algorithm to sort a list of elements.
    """
    list_length = len(data_list)
    gap_distance = list_length
    
    # defines default shrink factor
    shrink_factor = 1.3
    is_list_sorted = False

    # loop till list is sorted
    while gap_distance > 1 or not is_list_sorted:
        # determine new gap
        gap_distance = int(gap_distance / shrink_factor)
        
        # if gap becomes null, set it to one
        if gap_distance < 1:
            gap_distance = 1

        is_list_sorted = True

        # iterate through elements
        for index_position in range(list_length - gap_distance):
            # perform swap if elements out of order
            if data_list[index_position] > data_list[index_position + gap_distance]:
                data_list[index_position], data_list[index_position + gap_distance] = \
                    data_list[index_position + gap_distance], data_list[index_position]
                is_list_sorted = False
    
    return data_list