import re

def text_lowercase_underscore(input_line: str) -> bool:
    """
    Checks if the entire input_line contains sequences of lowercase letters
    joined with an underscore. The string must start with one or more
    lowercase letters, be followed by exactly one underscore, and then
    end with one or more lowercase letters.
    """
    
    # This line_checking_pattern ensures the entire input_line
    # starts with lowercase letters, is followed by an underscore,
    # and ends with lowercase letters.
    # ^ asserts position at the start of the string.
    # [a-z]+ matches one or more lowercase letters.
    # _ matches the underscore character literally.
    # $ asserts position at the end of the string.
    line_checking_pattern = r"^[a-z]+_[a-z]+$"
    
    # line_match_result will hold a match object if the pattern is found
    # across the entire input_line, otherwise it will be None.
    line_match_result = re.search(line_checking_pattern, input_line)
    
    # Returns True if a match was found (line_match_result is not None),
    # False otherwise.
    return bool(line_match_result)