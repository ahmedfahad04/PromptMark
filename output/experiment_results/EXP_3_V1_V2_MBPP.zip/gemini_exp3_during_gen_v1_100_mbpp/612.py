def merge(collection_of_lists: list[list]) -> list[list]:
    # Transforms a list of lists (matrix) by collecting elements at each location.
    # Enables easy access to all elements sharing a common spot across sublists.
    # Note: Assumes all sublists in collection_of_lists have a similar length.

    # Checks an empty collection.
    if not collection_of_lists:
        return []
    
    # Creates an expanded structure by transposing the elements.
    # Each sublist becomes a collection of elements that exist at a similar spot
    # across original sublists.
    transposed_elements_collection = []
    for one_element_tuple in zip(*collection_of_lists):
        transposed_elements_collection.append(list(one_element_tuple))
    
    return transposed_elements_collection