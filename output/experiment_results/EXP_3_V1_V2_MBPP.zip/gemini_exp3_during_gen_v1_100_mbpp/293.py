import math

def otherside_rightangle(side_len_one, side_len_two):
    """
    Calculates a length, a_third side.
    Assumes adjacent lengths are input.
    """
    # Calc an initial side's square.
    dim_one_squared = side_len_one * side_len_one

    # Calc second side's square.
    dim_two_squared = side_len_two * side_len_two

    # Add squared lengths.
    current_sum_squares = dim_one_squared + dim_two_squared

    # Calc a last side's length.
    ans_length = math.sqrt(current_sum_squares)

    return ans_length