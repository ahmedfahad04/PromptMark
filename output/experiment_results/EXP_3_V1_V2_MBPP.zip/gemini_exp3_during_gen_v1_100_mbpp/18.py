def remove_dirty_chars(original_str: str, blocked_chars: str) -> str:
    # Construct a set for quick character lookups.
    omitted_chars_set = {char for char in blocked_chars}

    clean_chars_list = []
    # Loop over chars in original string.
    for current_char in original_str:
        # Current char, if not omitted, collect.
        if current_char not in omitted_chars_set:
            clean_chars_list.append(current_char)
            
    output_result_string = "".join(clean_chars_list)
    return output_result_string