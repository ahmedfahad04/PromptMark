def mul_even_odd(data_list: list) -> int:
    # A location to store the leading even number encountered.
    leading_even_number = None
    # A location to store the leading odd number encountered.
    leading_odd_number = None

    for an_element in data_list:
        if an_element % 2 == 0:  # Check if an_element is even.
            if leading_even_number is None:
                leading_even_number = an_element
        else:  # an_element is odd.
            if leading_odd_number is None:
                leading_odd_number = an_element

        # Once both the leading even and leading odd numbers are found,
        # calculate their product and return it immediately.
        if leading_even_number is not None and leading_odd_number is not None:
            return leading_even_number * leading_odd_number

    # This code line will only be reached if the list does not contain both
    # an even and an odd number, which is not expected based on the problem's nature
    # and given test cases. Assuming valid input where both types of numbers exist.
    return leading_even_number * leading_odd_number