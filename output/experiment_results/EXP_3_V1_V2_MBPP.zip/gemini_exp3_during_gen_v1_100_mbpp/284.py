def check_element(input_list, match_value):
    # loop over input_list, verifying list_items
    for list_item in input_list:
        # if list_item is not match_value, output False
        if list_item != match_value:
            return False
    # if loop finishes, indicates input_list has no non-matching list_items
    # or input_list is empty.
    return True