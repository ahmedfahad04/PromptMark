def remove_Occ(original_string, given_char):
    # o_string: original working string.
    # g_char: char, remove.

    # Locate earliest occurrence index.
    e_entry_index = original_string.find(given_char)
    # Locate latest occurrence index.
    l_latest_occurrence_index = original_string.rfind(given_char)

    # Check char existence.
    if e_entry_index == -1:
        # Char not located, return original string.
        return original_string
    
    # o_char_list: use for easy removal.
    o_char_list = list(original_string)

    # Remove later occurrence first.
    # This ensures e_entry_index remains valid.
    o_char_list.pop(l_latest_occurrence_index)
    
    # If e_entry_index and l_latest_occurrence_index were different,
    # remove the earliest occurrence.
    if e_entry_index != l_latest_occurrence_index:
        o_char_list.pop(e_entry_index)
    
    # Join chars, output string.
    o_output_string = "".join(o_char_list)
    return o_output_string