def count_Substrings(input_string: str) -> int:
    """
    Counts the number of substrings with the sum of digits equal to their length.
    """
    large_answer = 0
    string_length = len(input_string)

    # left_index: initial index.
    for left_index in range(string_length):
        # value_sum: a running sum.
        value_sum = 0
        # right_index: final index.
        for right_index in range(left_index, string_length):
            element_char = input_string[right_index]
            # a_numeric_value: int value.
            a_numeric_value = int(element_char)
            value_sum += a_numeric_value

            # slice_length: slice length.
            slice_length = right_index - left_index + 1

            # If value_sum equals slice_length.
            if value_sum == slice_length:
                large_answer += 1

    return large_answer