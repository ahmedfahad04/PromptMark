def Find_Min(lst):
    # Initialize min_length to a very high number
    min_length = float('inf')
    # Initialize result to an empty list
    result = []
    
    # Iterate through each sublist in the given list
    for sublst in lst:
        # Check if current sublist's length is less than min_length
        if len(sublst) < min_length:
            # Update min_length and result
            min_length = len(sublst)
            result = sublst
    
    return result