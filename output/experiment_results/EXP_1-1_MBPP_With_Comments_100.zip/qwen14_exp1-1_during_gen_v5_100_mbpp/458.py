def rectangle_area(width, height):
    # Calculate the area by multiplying width and height
    area = width * height
    return area