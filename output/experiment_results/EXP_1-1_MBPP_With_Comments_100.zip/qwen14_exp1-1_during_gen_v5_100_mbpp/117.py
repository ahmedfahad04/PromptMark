def list_to_float(list_of_lists):
    # Convert each element in the sublists to float if possible
    converted_list = [[float(item) for item in sublist] for sublist in list_of_lists]
    return converted_list