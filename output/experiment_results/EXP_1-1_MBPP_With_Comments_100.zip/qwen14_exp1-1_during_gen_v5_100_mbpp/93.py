def power(u, v):
    # Initialize the result variable with 1
    i = 1
    
    # Loop b times to multiply a by itself
    j = 0
    while j < v:
        i *= u
        j += 1
    
    # Return the final computed value
    return i

# Test cases
assert power(3, 4) == 81
assert power(2, 3) == 8
assert power(5, 5) == 3125