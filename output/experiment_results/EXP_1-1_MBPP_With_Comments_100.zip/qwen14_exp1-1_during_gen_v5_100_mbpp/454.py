import re

def text_match_wordz(text):
    # Regular expression pattern to match a word containing 'z'
    pattern = '\\bz\\b'
    
    # Search for the pattern in the text
    if re.search(pattern, text):
        return True
    else:
        return False