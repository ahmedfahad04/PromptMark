def odd_num_sum(n):
    # Initialize sum to 0
    total = 0
    
    # Loop through the first n odd natural numbers
    for i in range(n):
        # Calculate the current odd number
        current_odd = 2 * i + 1
        
        # Add its fourth power to the total sum
        total += current_odd ** 4
    
    return total

# Test cases
assert odd_num_sum(2) == 82
assert odd_num_sum(3) == 707
assert odd_num_sum(4) == 3108