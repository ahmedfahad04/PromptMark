import math

def multiply_num(uwn):
    # Initialize the product variable to 1
    vco = 1
    
    # Multiply each number in the tuple
    for kvo in uwn:
        vco *= kvo
    
    # Divide the product by the length of the tuple
    vco /= len(uwn)
    
    return vco