def find_Max_Num(digits):
    # Convert all integers in the list to strings to facilitate sorting
    str_digits = [str(digit) for digit in digits]
    
    # Sort the list of strings in descending order based on custom comparison
    str_digits.sort(reverse=True, key=lambda x: x*3)
    
    # Join the sorted list into a single string
    max_num_str = ''.join(str_digits)
    
    # Convert the string back to an integer
    max_num = int(max_num_str)
    
    return max_num