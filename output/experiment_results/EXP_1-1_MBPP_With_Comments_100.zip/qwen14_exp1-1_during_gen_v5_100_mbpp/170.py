def sum_range_list(just_a_list, start_index, end_index):
    # Initialize the sum variable to zero
    total_sum = 0
    
    # Iterate through the list from start_index to end_index inclusive
    for k in range(start_index, end_index + 1):
        # Add the current element to the sum
        total_sum += just_a_list[k]
    
    # Return the calculated sum
    return total_sum