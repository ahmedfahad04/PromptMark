def square_Sum(n):
    # Initialize sum to 0
    total = 0
    
    # Loop through the first n odd numbers
    for i in range(n):
        # Calculate the i-th odd number
        odd_number = 2 * i + 1
        # Add its square to the total
        total += odd_number ** 2
    
    return total

# Test cases
assert square_Sum(2) == 10
assert square_Sum(3) == 35
assert square_Sum(4) == 84