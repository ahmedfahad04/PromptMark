def sum_list(a_k, b_k):
    # Initialize an empty list to store the results
    result = []
    
    # Loop through the elements of both lists and add corresponding elements
    for i in range(len(a_k)):
        result.append(a_k[i] + b_k[i])
    
    return result