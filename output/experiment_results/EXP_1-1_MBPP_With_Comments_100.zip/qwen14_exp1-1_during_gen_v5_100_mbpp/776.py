def count_vowels(s):
    # Initialize counter for characters with vowel neighbors
    count = 0
    
    # Convert the string into a list for easier manipulation
    char_list = list(s)
    
    # Iterate through the list, checking each character and its neighbors
    for i in range(1, len(char_list) - 1):
        # Check if the current character has a vowel on either side
        if (char_list[i-1] in 'aeiou' or char_list[i+1] in 'aeiou'):
            count += 1
            
    # Check the first character separately
    if len(s) > 1 and s[1] in 'aeiou':
        count += 1
        
    # Check the last character separately
    if len(s) > 1 and s[-2] in 'aeiou':
        count += 1
        
    return count

# Test cases
assert count_vowels('bestinstareels') == 7
assert count_vowels('partofthejourneyistheend') == 12
assert count_vowels('amazonprime') == 5