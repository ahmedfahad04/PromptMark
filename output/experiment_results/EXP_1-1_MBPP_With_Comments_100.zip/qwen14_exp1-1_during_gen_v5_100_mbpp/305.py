def start_withp(words):
    # Split the input string into a list of words
    word_list = words.split()
    
    # Initialize an empty list to store words starting with 'p'
    p_words = []
    
    # Iterate through each word in the list
    for word in word_list:
        # Check if the word starts with 'p' (case-insensitive)
        if word.lower().startswith('p'):
            # Append the word to the list of p-words
            p_words.append(word)
    
    # Return the first two words from the list of p-words
    return tuple(p_words[:2])