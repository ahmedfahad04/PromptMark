def list_to_tuple(input_list):
    # Convert the input list to a tuple
    return tuple(input_list)

# Test cases
assert list_to_tuple([5, 10, 7, 4, 15, 3]) == (5, 10, 7, 4, 15, 3)
assert list_to_tuple([2, 4, 5, 6, 2, 3, 4, 4, 7]) == (2, 4, 5, 6, 2, 3, 4, 4, 7)
assert list_to_tuple([58, 44, 56]) == (58, 44, 56)