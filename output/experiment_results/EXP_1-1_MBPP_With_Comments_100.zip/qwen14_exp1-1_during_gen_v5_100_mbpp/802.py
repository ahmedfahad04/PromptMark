def count_rotation(arr):
    # Initialize the index where the smallest element is found
    index = find_smallest_index(arr)
    
    # If the array is already sorted, no rotation is needed
    if index == 0:
        return 0
    
    # The number of rotations is the index of the smallest element
    return index

def find_smallest_index(arr):
    # Iterate through the array to find the index of the smallest element
    for i in range(1, len(arr)):
        if arr[i] < arr[i - 1]:
            return i
    return 0