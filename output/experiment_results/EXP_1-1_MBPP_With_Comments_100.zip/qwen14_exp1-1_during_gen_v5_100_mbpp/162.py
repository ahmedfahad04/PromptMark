def sum_series(n):
    # Initialize total sum to 0
    total_sum = 0
    
    # Loop from 0 to n//2
    for i in range(n // 2 + 1):
        # Calculate term n - 2*i and add it to total_sum
        total_sum += n - 2 * i
    
    return total_sum

# Test cases
assert sum_series(6) == 12
assert sum_series(10) == 30
assert sum_series(9) == 25