def otherside_rightangle(kv, kj):
    # Calculate the third side using Pythagorean theorem
    return (kv**2 + kj**2)**0.5