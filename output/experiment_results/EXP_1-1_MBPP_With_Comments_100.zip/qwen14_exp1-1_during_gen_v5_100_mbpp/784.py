def mul_even_odd(arr):
    # Initialize counters for even and odd numbers
    even_count = 0
    odd_count = 0
    
    # Iterate through the array to find the first even and odd numbers
    for num in arr:
        if num % 2 == 0:
            if even_count == 0:
                even = num
                even_count += 1
        else:
            if odd_count == 0:
                odd = num
                odd_count += 1
                
        # Break the loop once both even and odd numbers are found
        if even_count > 0 and odd_count > 0:
            break
            
    # Return the product of the first even and odd numbers
    return even * odd

# Test cases
assert mul_even_odd([1,3,5,7,4,1,6,8]) == 4
assert mul_even_odd([1,2,3,4,5,6,7,8,9,10]) == 2
assert mul_even_odd([1,5,7,9,10]) == 10