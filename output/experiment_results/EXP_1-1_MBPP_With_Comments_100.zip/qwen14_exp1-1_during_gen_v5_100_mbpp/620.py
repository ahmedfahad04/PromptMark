def largest_subset(nums):
    # Sort the array to ensure divisibility check can be done sequentially
    nums.sort()
    
    # Initialize a dp array where dp[i] represents the size of the largest subset
    # ending with nums[i] such that every pair is divisible
    dp = [1] * len(nums)
    
    # Iterate through each number in the sorted list
    for i in range(1, len(nums)):
        # Check all previous numbers to see if they divide nums[i]
        for j in range(i):
            if nums[i] % nums[j] == 0:
                # Update dp[i] if a valid subset ending with nums[j] is found
                dp[i] = max(dp[i], dp[j] + 1)
    
    # Return the maximum value in dp which represents the largest subset size
    return max(dp)

# Test cases
print(largest_subset([1, 3, 6, 13, 17, 18]))  # Output: 4
print(largest_subset([10, 5, 3, 15, 20]))     # Output: 3
print(largest_subset([18, 1, 3, 6, 13, 17]))  # Output: 4