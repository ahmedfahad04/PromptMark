def parabola_directrix(u, w, c):
    # Calculate the directrix using the formula derived from the standard form of a parabola equation
    j = u * u - 4 * w * c
    v = -2 * w
    k = v / 4 * u
    i = k + j
    m = i / v
    return m