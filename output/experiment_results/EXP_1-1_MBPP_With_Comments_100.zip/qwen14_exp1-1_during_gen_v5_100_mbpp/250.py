def count_u(element_k, value_j):
    # Initialize a counter for occurrences of the value
    count_v = 0
    # Iterate through each item in the tuple
    for item_m in element_k:
        # If the item matches the value, increment the counter
        if item_m == value_j:
            count_v += 1
    return count_v

# Test cases
assert count_u((10, 8, 5, 2, 10, 15, 10, 8, 5, 8, 8, 2), 4) == 0
assert count_u((10, 8, 5, 2, 10, 15, 10, 8, 5, 8, 8, 2), 10) == 3
assert count_u((10, 8, 5, 2, 10, 15, 10, 8, 5, 8, 8, 2), 8) == 4