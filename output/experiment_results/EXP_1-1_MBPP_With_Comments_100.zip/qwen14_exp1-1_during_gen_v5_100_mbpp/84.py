def sequence(n):
    # Base cases for the Newman-Conway Sequence
    if n == 1 or n == 2:
        return 1
    
    # Initialize a list to store the sequence values
    seq = [0] * (n + 1)
    seq[1], seq[2] = 1, 1
    
    # Fill the sequence list using the Newman-Conway recurrence relation
    for i in range(3, n + 1):
        seq[i] = seq[seq[i - 1]] + seq[i - seq[i - 1]]
    
    # Return the nth value in the sequence
    return seq[n]

# Test cases
assert sequence(10) == 6
assert sequence(2) == 1
assert sequence(3) == 2