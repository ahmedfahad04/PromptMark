def count_divisors(uo):
    # Initialize a list to store divisors
    divisor_list = []
    
    # Loop through possible divisors
    for i in range(1, uo + 1):
        if uo % i == 0:
            divisor_list.append(i)
    
    # Check if the number of divisors is even
    return len(divisor_list) % 2 == 0

# Test cases
assert count_divisors(10) == False
assert count_divisors(100) == True
assert count_divisors(125) == False