def substract_elements(given_tuple1, given_tuple2):
    # Initialize an empty list to store the results
    result = []
    
    # Iterate through the indices of the tuples
    for i in range(len(given_tuple1)):
        # Subtract the corresponding elements and append to the result list
        result.append(given_tuple1[i] - given_tuple2[i])
    
    # Convert the result list back into a tuple before returning
    return tuple(result)