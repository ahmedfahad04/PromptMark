def comb_sort(arr):
    # Initialize gap size to the length of the array
    gap = len(arr)
    # Set shrink factor to 1.3
    shrink_factor = 1.3
    sorted_flag = False
    
    while not sorted_flag:
        # Update gap value for a next comb
        gap = int(gap / shrink_factor)
        
        # If gap is 1, this is the final comb
        if gap == 1:
            sorted_flag = True
        
        # A single "comb" over the input array
        i = 0
        while i + gap < len(arr):
            if arr[i] > arr[i + gap]:
                # Swap elements
                arr[i], arr[i + gap] = arr[i + gap], arr[i]
                sorted_flag = False
            i += 1
    
    return arr