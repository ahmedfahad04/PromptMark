def even_Power_Sum(n):
    # Initialize sum to zero
    total_sum = 0
    
    # Iterate through the first n even numbers
    for i in range(1, n + 1):
        # Calculate the ith even number
        even_number = 2 * i
        
        # Raise it to the fifth power and add to the total sum
        total_sum += even_number ** 5
    
    return total_sum