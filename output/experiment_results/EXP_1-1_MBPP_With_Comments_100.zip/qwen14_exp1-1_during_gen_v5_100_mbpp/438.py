def count_bidirectional(kv_pairs):
    # Initialize a dictionary to keep track of occurrences
    kv_count = {}
    
    # Iterate through each key-value pair in the list
    for k, v in kv_pairs:
        # Check if the reverse pair exists in the dictionary
        if (v, k) in kv_count:
            # If it does, increment its count
            kv_count[(v, k)] += 1
        else:
            # Otherwise, initialize the count for this pair
            kv_count[(k, v)] = 1
    
    # Calculate the number of bidirectional pairs
    bidirectional_count = sum(1 for count in kv_count.values() if count > 1)
    
    return bidirectional_count