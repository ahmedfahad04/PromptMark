def remove_lowercase(s):
    # Initialize an empty string to store uppercase characters
    result = ''
    
    # Iterate through each character in the input string
    for char in s:
        # Check if the character is uppercase
        if char.isupper():
            # If so, append it to the result string
            result += char
    
    # Return the final string containing only uppercase characters
    return result