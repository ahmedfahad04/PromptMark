def average_tuple(tup):
    # Calculate the average for each tuple inside the main tuple
    averages = [sum(sub_tup) / len(sub_tup) for sub_tup in tup]
    return averages