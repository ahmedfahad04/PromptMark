def min_Swaps(s1, s2):
    # Count the number of differing bits between the two strings
    diff_count = sum(bit1 != bit2 for bit1, bit2 in zip(s1, s2))
    
    # If the number of differing bits is odd, conversion is not possible
    if diff_count % 2 != 0:
        return "Not Possible"
    
    # If there are no differing bits, no swap is needed
    elif diff_count == 0:
        return 0
    
    # If the number of differing bits is even, calculate the minimum swaps
    else:
        # The minimum number of swaps required is half the number of differing bits
        return diff_count // 2