def toggle_middle_bits(n):
    # Calculate the length of the binary representation minus two for excluding the first and last bit
    length = n.bit_length() - 2
    
    # Create a mask with all middle bits set to 1
    mask = (1 << length) - 1
    
    # Shift the mask to align with the middle bits of n
    mask <<= 1
    
    # XOR n with the mask to toggle the middle bits
    result = n ^ mask
    
    return result