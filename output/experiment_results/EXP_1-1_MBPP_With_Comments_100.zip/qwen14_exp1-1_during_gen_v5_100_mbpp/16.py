import re

def text_lowercase_underscore(input_string):
    # Check if the input_string contains one or more sequences of lowercase letters joined by an underscore
    if re.search(r'^[a-z]+(_[a-z]+)*$', input_string):
        return True
    else:
        return False