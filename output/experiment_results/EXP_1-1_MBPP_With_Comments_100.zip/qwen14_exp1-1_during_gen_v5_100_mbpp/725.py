import re

def extract_quotation(text):
    # Using regular expression to find all substrings enclosed in double quotes
    return re.findall(r'"(.*?)"', text)

# Test cases
print(extract_quotation('Cortex "A53" Based "multi" tasking "Processor"'))
print(extract_quotation('Cast your "favorite" entertainment "apps"'))
print(extract_quotation('Watch content "4k Ultra HD" resolution with "HDR 10" Support'))
print(extract_quotation("Watch content '4k Ultra HD' resolution with 'HDR 10' Support"))