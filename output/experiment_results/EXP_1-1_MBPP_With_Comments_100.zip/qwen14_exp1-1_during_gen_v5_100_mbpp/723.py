def count_same_pair(u, v):
    # Initialize counter for matching pairs
    k = 0
    
    # Iterate through both lists simultaneously
    for i in range(len(u)):
        # Check if elements at current index are equal
        if u[i] == v[i]:
            # Increment counter if they match
            k += 1
            
    return k