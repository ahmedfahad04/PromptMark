def find_solution(a, b, n):
    # Check if the greatest common divisor of a and b divides n
    if n % gcd(a, b) != 0:
        return None
    
    # Extended Euclidean Algorithm to find x and y such that ax + by = gcd(a, b)
    x, y, g = extended_gcd(a, b)
    
    # Scale the solution to match the equation ax + by = n
    k = n // g
    return (x * k, y * k)

def gcd(a, b):
    # Base case
    if b == 0:
        return a
    else:
        # Recursive call
        return gcd(b, a % b)

def extended_gcd(a, b):
    if b == 0:
        return (1, 0, a)
    else:
        x, y, g = extended_gcd(b, a % b)
        return (y, x - (a // b) * y, g)