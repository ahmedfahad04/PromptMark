def is_perfect_square(u):
    # Calculate the squaroot of the number and round it off
    k = round(u ** 0.5)
    
    # Check if the square of the rounded value equals the original number
    return k * k == u

# Test cases
assert not is_perfect_square(10)
assert is_perfect_square(36)
assert not is_perfect_square(14)
assert is_perfect_square(14*14)
assert not is_perfect_square(125)
assert is_perfect_square(125*125)