def find_even_pair(nums):
    # Initialize count of pairs
    pair_count = 0
    
    # Iterate through each unique pair in the list
    for i in range(len(nums)):
        for j in range(i + 1, len(nums)):
            # Check if XOR of the pair is even
            if (nums[i] ^ nums[j]) % 2 == 0:
                pair_count += 1
                
    return pair_count

# Test cases
assert find_even_pair([5, 4, 7, 2, 1]) == 4
assert find_even_pair([7, 2, 8, 1, 0, 5, 11]) == 9
assert find_even_pair([1, 2, 3]) == 1