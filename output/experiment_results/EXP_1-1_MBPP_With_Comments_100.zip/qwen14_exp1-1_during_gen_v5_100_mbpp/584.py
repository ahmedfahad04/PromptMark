def find_adverbs(sentence):
    # Start searching from the beginning of the sentence
    start = 0
    # Loop through the sentence to find an adverb ending with 'ly'
    while True:
        # Find the position of the next word
        pos = sentence.find(' ', start)
        if pos == -1:
            # If no more spaces found, consider the rest of the sentence as one word
            pos = len(sentence)
        # Extract the current word
        word = sentence[start:pos]
        # Check if the word ends with 'ly' and is at least 3 characters long
        if word.endswith('ly') and len(word) > 2:
            return f'{start}-{pos}: {word}'
        # Move the start position to the character after the space
        start = pos + 1