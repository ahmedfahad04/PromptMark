def find_First_Missing(sorted_nums):
    # Initialize the expected number to be found
    expected_num = 0
    
    # Iterate through each number in the list
    for num in sorted_nums:
        # If the current number matches the expected number, increment the expected number
        if num == expected_num:
            expected_num += 1
        # If a mismatch is found, return the expected number
        else:
            return expected_num
    
    # If all numbers match up to the last one, return the next number after the last one
    return expected_num