def sum_even_and_even_index(lst):
    # Initialize the sum variable
    total = 0
    
    # Iterate through the list using enumerate to get both index and value
    for index, value in enumerate(lst):
        # Check if the index is even and the value at that index is even
        if index % 2 == 0 and value % 2 == 0:
            # Add the value to the total sum
            total += value
            
    return total