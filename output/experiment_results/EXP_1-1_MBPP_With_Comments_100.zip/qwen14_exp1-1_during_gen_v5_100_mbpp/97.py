def frequency_lists(uwu):
    # Initialize an empty dictionary to store the frequency of elements
    kivy = {}
    
    # Iterate through each sublist in the main list
    for sub_list in uwu:
        # Iterate through each element in the sublist
        for item in sub_list:
            # If the element is already in the dictionary, increment its count
            if item in kivy:
                kivy[item] += 1
            else:
                # Otherwise, add the element to the dictionary with a count of 1
                kivy[item] = 1
    
    # Return the dictionary containing the frequency of each element
    return kivy