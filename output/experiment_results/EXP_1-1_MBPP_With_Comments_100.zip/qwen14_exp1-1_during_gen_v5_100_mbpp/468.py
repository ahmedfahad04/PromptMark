def max_product(nums):
    # Initialize the dp array where dp[i] will store the maximum product of increasing subsequence ending at index i
    dp = [num for num in nums]
    
    # Variable to store the overall maximum product found
    max_product_overall = nums[0]
    
    # Iterate through each number in the list
    for i in range(1, len(nums)):
        # For each number, iterate through all previous numbers
        for j in range(i):
            # If the current number forms an increasing subsequence with the previous number
            if nums[i] > nums[j]:
                # Update the dp value for the current number
                dp[i] = max(dp[i], dp[j] * nums[i])
                
        # Update the overall maximum product if needed
        max_product_overall = max(max_product_overall, dp[i])
    
    return max_product_overall

# Test cases
assert max_product([3, 100, 4, 5, 150, 6]) == 3000
assert max_product([4, 42, 55, 68, 80]) == 50265600
assert max_product([10, 22, 9, 33, 21, 50, 41, 60]) == 2460