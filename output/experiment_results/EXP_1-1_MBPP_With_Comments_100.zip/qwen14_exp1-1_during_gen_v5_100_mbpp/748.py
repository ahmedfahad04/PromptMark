import re

def capital_words_spaces(str1):
    # Split the input string by finding sequences that start with a lowercase letter
    # followed by zero or more non-lowercase letters, then a capital letter,
    # and then zero or more lowercase letters.
    return re.sub(r'([a-z])([A-Z])', r'\1 \2', str1)