def square_nums(input_list):
    # Initialize an empty list to store squared values
    squared_values = []
    
    # Iterate through each element in the input list
    for num in input_list:
        # Square the number and append it to the squared_values list
        squared_values.append(num * num)
    
    return squared_values