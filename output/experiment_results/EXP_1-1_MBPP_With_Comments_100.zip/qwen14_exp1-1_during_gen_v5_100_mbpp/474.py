def replace_char(string, old_char, new_char):
    # Replace occurrences of old_char with new_char in the string
    modified_string = string.replace(old_char, new_char)
    return modified_string