def find_Average_Of_Cube(n):
    # Calculate the sum of cubes of first n natural numbers
    total = sum(i ** 3 for i in range(1, n + 1))
    
    # Calculate the average by dividing the total by n
    average = total / n
    
    return average