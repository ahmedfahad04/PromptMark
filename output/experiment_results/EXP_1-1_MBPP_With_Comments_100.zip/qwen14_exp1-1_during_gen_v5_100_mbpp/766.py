def pair_wise(items):
    # Create pairs of consecutive items
    pairs = [(items[i], items[i + 1]) for i in range(len(items) - 1)]
    return pairs