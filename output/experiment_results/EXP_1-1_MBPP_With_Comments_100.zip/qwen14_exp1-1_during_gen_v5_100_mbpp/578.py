def interleave_lists(list_a, list_b, list_c):
    # Initialize an empty list to store the result
    interleaved_list = []
    
    # Iterate through each index of the lists
    for i in range(len(list_a)):
        # Append elements from each list at the current index to the result list
        interleaved_list.append(list_a[i])
        interleaved_list.append(list_b[i])
        interleaved_list.append(list_c[i])
    
    return interleaved_list