def subject_marks(items):
    # Sort the list of tuples based on the second item of each tuple
    items.sort(key=lambda x: x[1])
    return items