def reverse_string_list(input_list):
    # Initialize an empty list to store reversed strings
    reversed_list = []
    
    # Iterate through each string in the input list
    for item in input_list:
        # Reverse the current string and append it to the reversed_list
        reversed_list.append(item[::-1])
    
    # Return the final list of reversed strings
    return reversed_list