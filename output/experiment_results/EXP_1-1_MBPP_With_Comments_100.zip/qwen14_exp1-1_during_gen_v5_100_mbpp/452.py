def loss_amount(cost_price, selling_price):
    # If selling price is less than cost price, calculate loss
    if selling_price < cost_price:
        return cost_price - selling_price
    else:
        return 0