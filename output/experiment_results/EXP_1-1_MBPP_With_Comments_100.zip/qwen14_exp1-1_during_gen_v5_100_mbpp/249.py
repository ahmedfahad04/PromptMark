def intersection_array(u_list, v_list):
    # Utilize set intersection for finding common elements
    return list(set(u_list) & set(v_list))