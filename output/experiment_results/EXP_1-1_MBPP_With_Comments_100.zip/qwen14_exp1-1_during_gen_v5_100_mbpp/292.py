def find(num1, num2):
    # Calculate the quotient by dividing num1 by num2 and using floor division
    return num1 // num2

# Test cases
assert find(10, 3) == 3
assert find(4, 2) == 2
assert find(20, 5) == 4