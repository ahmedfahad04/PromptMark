def extract_singly(collection):
    # Initialize an empty set to store unique elements
    unique_elements = set()
    
    # Iterate through each tuple in the collection
    for item in collection:
        # Add all elements from the current tuple to the set
        unique_elements.update(item)
    
    return unique_elements