def merge(uj):
    k = [[i[0] for i in uj], [i[1] for i in uj]]
    if len(uj[0]) > 2:
        v = 2
        while v < len(uj[0]):
            k.append([i[v] for i in uj])
            v += 1
    return k