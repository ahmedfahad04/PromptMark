def Split(numbers):
    # This function returns a list containing only the even numbers from the input list
    return [num for num in numbers if num % 2 == 0]