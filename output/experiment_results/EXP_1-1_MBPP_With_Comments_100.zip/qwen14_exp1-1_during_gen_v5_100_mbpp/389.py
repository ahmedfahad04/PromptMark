def find_lucas(n):
    # Base cases for the first two lucas numbers
    if n == 0:
        return 2
    elif n == 1:
        return 1
    
    # Initialize the first two lucas numbers
    lucas_i_k_2 = 2  # L(k-2)
    lucas_i_k_1 = 1   # L(k-1)
    
    # Compute the lucas number iteratively
    for _ in range(2, n + 1):
        lucas_i_k = lucas_i_k_1 + lucas_i_k_2  # L(k) = L(k-1) + L(k-2)
        lucas_i_k_2 = lucas_i_k_1              # Update L(k-2) to L(k-1)
        lucas_i_k_1 = lucas_i_k                # Update L(k-1) to L(k)
    
    return lucas_i_k_1

# Test cases
assert find_lucas(9) == 76
assert find_lucas(4) == 7
assert find_lucas(3) == 4