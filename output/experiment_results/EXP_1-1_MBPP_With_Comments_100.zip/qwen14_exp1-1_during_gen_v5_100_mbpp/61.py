def count_Substrings(s):
    def is_valid_substring(sub):
        # Check if the sum of digits equals the length of the substring
        return sum(int(char) for char in sub) == len(sub)
    
    count = 0
    n = len(s)
    
    # Iterate through all possible substrings
    for i in range(n):
        for j in range(i + 1, n + 1):
            if is_valid_substring(s[i:j]):
                count += 1
                
    return count