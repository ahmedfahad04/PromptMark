def rotate_right(jam, kyu):
    # Calculate the effective rotation needed
    kyu %= len(jam)
    # Rotate the list by slicing and concatenating
    return jam[-kyu:] + jam[:-kyu]