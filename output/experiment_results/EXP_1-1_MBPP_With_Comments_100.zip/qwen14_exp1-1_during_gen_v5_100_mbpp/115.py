def empty_dit(uvm):
    # Check if input is a list
    if isinstance(uvm, list):
        # Check each dictionary in the list
        for item in uvm:
            if item:  # If any dictionary is not empty
                return False
        return True  # All dictionaries are empty
    else:
        return True  # Input is not a list, consider it as an empty dictionary

# Test cases
assert empty_dit([{},{},{}]) == True
assert empty_dit([{1,2},{},{}]) == False
assert empty_dit({}) == True