def merge_dictionaries_three(dict_u, dict_w, dict_c):
    # Initialize an empty dictionary to store the merged results
    merged_dict = {}
    
    # Update merged_dict with each dictionary
    merged_dict.update(dict_u)
    merged_dict.update(dict_w)
    merged_dict.update(dict_c)
    
    return merged_dict