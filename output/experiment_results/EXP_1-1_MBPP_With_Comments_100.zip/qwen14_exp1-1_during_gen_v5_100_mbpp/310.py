def string_to_tuple(joined_chars):
    # Convert the input string into a tuple of its characters
    return tuple(joined_chars)

# Test cases
assert string_to_tuple("python 3.0") == ('p', 'y', 't', 'h', 'o', 'n', '3', '.', '0')
assert string_to_tuple("item1") == ('i', 't', 'e', 'm', '1')
assert string_to_tuple("15.10") == ('1', '5', '.', '1', '0')