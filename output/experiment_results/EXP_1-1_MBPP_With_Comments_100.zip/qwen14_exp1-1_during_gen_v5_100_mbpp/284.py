def check_element(given_list, target_item):
    # Iterate through each item in the list
    for item in given_list:
        # If any item does not match the target item, return False
        if item != target_item:
            return False
    # If all items matched, return True
    return True