def extract_nth_element(tuples_list, index):
    # Initialize an empty list to store the extracted elements
    extracted_elements = []
    
    # Iterate through each tuple in the list
    for item in tuples_list:
        # Append the nth element of the tuple to the list
        extracted_elements.append(item[index])
    
    # Return the list of extracted elements
    return extracted_elements