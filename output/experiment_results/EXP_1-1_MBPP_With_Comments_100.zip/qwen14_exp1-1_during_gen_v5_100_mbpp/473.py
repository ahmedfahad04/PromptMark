def tuple_intersection(u_knot, v_knot):
    # Convert each tuple in u_knot and v_knot into sets to ignore order
    u_set = {set(i) for i in u_knot}
    v_set = {set(j) for j in v_knot}

    # Find common sets between the two lists and convert back to sorted tuples
    intersecting_sets = u_set.intersection(v_set)
    intersecting_tuples = {tuple(sorted(s)) for s in intersecting_sets}

    return intersecting_tuples