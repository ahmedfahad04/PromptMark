def extract_string(words, length):
    # Filter out strings that match the specified length
    return [word for word in words if len(word) == length]

# Test cases
assert extract_string(['Python', 'list', 'exercises', 'practice', 'solution'], 8) == ['practice', 'solution']
assert extract_string(['Python', 'list', 'exercises', 'practice', 'solution'], 6) == ['Python']
assert extract_string(['Python', 'list', 'exercises', 'practice', 'solution'], 9) == ['exercises']