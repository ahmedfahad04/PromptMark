def trim_tuple(kv_pairs, k):
    # Trim each tuple by keeping elements from index k to end
    trimmed = [tuple(x[k:]) for x in kv_pairs]
    return str(trimmed)