def median_trapezium(base_u, base_w, height_c):
    # Calculate the median of the trapezium using the formula
    median_s = (base_u + base_w) / 2
    return median_s

# Test cases
assert median_trapezium(15, 25, 35) == 20
assert median_trapezium(10, 20, 30) == 15
assert median_trapezium(6, 9, 4) == 7.5