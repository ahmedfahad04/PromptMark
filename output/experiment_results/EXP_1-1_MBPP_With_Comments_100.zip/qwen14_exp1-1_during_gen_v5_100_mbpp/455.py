def check_monthnumb_number(month):
    # Check if the month has 31 days
    if month in [1, 3, 5, 7, 8, 10, 12]:
        return True
    else:
        return False

# Test cases
assert check_monthnumb_number(5) == True
assert check_monthnumb_number(2) == False
assert check_monthnumb_number(6) == False