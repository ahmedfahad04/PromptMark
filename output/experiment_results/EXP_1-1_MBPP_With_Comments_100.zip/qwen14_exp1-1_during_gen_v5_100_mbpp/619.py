def move_num(s):
    # Initialize an empty list to hold characters and numbers separately
    chars = []
    nums = []
    
    # Iterate through each character in the input string
    for char in s:
        # Check if the character is a digit
        if char.isdigit():
            # If it's a digit, add it to the nums list
            nums.append(char)
        else:
            # If it's not a digit, add it to the chars list
            chars.append(char)
    
    # Join the chars list into a string and append the nums list to it
    result = ''.join(chars) + ''.join(nums)
    
    return result