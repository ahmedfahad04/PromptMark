def common_in_nested_lists(lists):
    # Start with the first list's elements as potential candidates
    common_elements = set(lists[0])
    
    # Iterate through each subsequent list
    for lst in lists[1:]:
        # Update the common elements by intersecting with the current list
        common_elements.intersection_update(lst)
    
    return list(common_elements)