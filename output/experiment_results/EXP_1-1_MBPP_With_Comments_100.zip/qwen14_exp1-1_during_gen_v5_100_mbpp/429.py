def and_tuples(uu, vv):
    # This function computes the element-wise AND operation on two tuples
    return tuple(x & y for x, y in zip(uu, vv))