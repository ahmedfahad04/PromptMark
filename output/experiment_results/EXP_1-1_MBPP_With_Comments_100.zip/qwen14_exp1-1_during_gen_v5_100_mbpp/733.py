def find_first_occurrence(joined_list, target):
    # Initialize left and right pointers
    left = 0
    right = len(joined_list) - 1
    
    # Set result to -1 indicating no match found initially
    result = -1
    
    # Loop until the pointers meet
    while left <= right:
        mid = (left + right) // 2  # Calculate middle index
        
        if joined_list[mid] == target:
            result = mid  # Update result to current mid index
            right = mid - 1  # Move left to search for earlier occurrences
        elif joined_list[mid] < target:
            left = mid + 1  # Move left pointer right
        else:
            right = mid - 1  # Move right pointer left
            
    return result

# Test cases
assert find_first_occurrence([2, 5, 5, 5, 6, 6, 8, 9, 9, 9], 5) == 1
assert find_first_occurrence([2, 3, 5, 5, 6, 6, 8, 9, 9, 9], 5) == 2
assert find_first_occurrence([2, 4, 1, 5, 6, 6, 8, 9, 9, 9], 6) == 4