def occurance_substring(main_string, substring):
    # Find the start index of the first occurrence of the substring
    start_index = main_string.find(substring)
    
    # If the substring is found, return its details
    if start_index != -1:
        end_index = start_index + len(substring)
        return (substring, start_index, end_index)
    else:
        # If the substring is not found, return None
        return None