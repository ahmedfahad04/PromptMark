def snake_to_camel(snake_str):
    # Split the string by underscore and capitalize each segment, then join them together
    return ''.join(word.capitalize() or '_' for word in snake_str.split('_'))

# Test cases
assert snake_to_camel('android_tv') == 'AndroidTv'
assert snake_to_camel('google_pixel') == 'GooglePixel'
assert snake_to_camel('apple_watch') == 'AppleWatch'