def left_insertion(sequence, value):
    # Initialize the low index
    low = 0
    # Initialize the high index
    high = len(sequence)
    
    # Loop until the low index exceeds the high index
    while low < high:
        # Calculate the middle index
        mid = (low + high) // 2
        # If the value at the middle index is less than the specified value,
        # move the low index up
        if sequence[mid] < value:
            low = mid + 1
        else:
            # Otherwise, move the high index down
            high = mid
    return low