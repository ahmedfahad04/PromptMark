def remove_whitespaces(u_input):
    # This uses the replace method to eliminate spaces
    i_output = u_input.replace(" ", "")
    return i_output