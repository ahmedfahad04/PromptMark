def new_tuple(uik, v):
    # Convert the list to a tuple and concatenate with another tuple containing the string
    return tuple(uik) + (v,)