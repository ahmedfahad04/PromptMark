def find_Element(arr, queries, target_index, num_rotations):
    # Calculate the effective rotation by taking modulo with length of array
    effective_rotation = num_rotations % len(arr)
    
    # For each query, update the effective rotation
    for start, end in queries:
        if start <= target_index <= end:
            effective_rotation -= (end - start + 1)
            effective_rotation %= len(arr)
    
    # Adjusting the effective rotation to get the final position
    final_position = (target_index - effective_rotation) % len(arr)
    
    # Return the element at the calculated final position
    return arr[final_position]

# Test cases
print(find_Element([1,2,3,4,5], [[0,2],[0,3]], 2, 1))
print(find_Element([1,2,3,4], [[0,1],[0,2]], 1, 2))
print(find_Element([1,2,3,4,5,6], [[0,1],[0,2]], 1, 1))