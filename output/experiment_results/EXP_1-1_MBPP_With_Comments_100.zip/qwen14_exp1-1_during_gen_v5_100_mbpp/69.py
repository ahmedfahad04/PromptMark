def is_sublist(main_list, sub_list):
    # Convert both lists into strings and check if sub_list string is in main_list string
    # This approach simplifies the problem by leveraging string containment checks
    main_str = ''.join(map(str, main_list))
    sub_str = ''.join(map(str, sub_list))
    return sub_str in main_str

# Test cases
assert is_sublist([2, 4, 3, 5, 7], [3, 7]) == False
assert is_sublist([2, 4, 3, 5, 7], [4, 3]) == True
assert is_sublist([2, 4, 3, 5, 7], [1, 6]) == False