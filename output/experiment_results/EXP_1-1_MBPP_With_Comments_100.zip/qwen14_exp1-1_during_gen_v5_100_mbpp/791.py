def remove_nested(u):
    # Initialize an empty list to store non-tuple elements
    result = []
    
    # Iterate through each element in the input tuple
    for item in u:
        # Check if the current item is not a tuple
        if not isinstance(item, tuple):
            # Append the item to the result list
            result.append(item)
            
    # Convert the result list back into a tuple before returning
    return tuple(result)