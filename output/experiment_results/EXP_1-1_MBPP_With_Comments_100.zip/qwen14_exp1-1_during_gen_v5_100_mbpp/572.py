def two_unique_nums(nums):
    # Utilize a dictionary to track occurrences of each number
    num_count = {}
    for num in nums:
        if num in num_count:
            num_count[num] += 1
        else:
            num_count[num] = 1
    
    # Filter out numbers that appear more than once
    result = [num for num in nums if num_count[num] == 1]
    
    return result