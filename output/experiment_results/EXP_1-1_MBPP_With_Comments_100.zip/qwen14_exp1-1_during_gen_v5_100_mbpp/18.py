def remove_dirty_chars(primary_str, dirty_str):
    # Convert the dirty string into a set of characters to improve lookup time
    dirty_set = set(dirty_str)
    
    # Use a list comprehension to filter out characters from primary_str that are in dirty_set
    cleaned_list = [char for char in primary_str if char not in dirty_set]
    
    # Join the list back into a string and return it
    return ''.join(cleaned_list)

# Test cases
assert remove_dirty_chars("probasscurve", "pros") == 'bacuve'
assert remove_dirty_chars("digitalindia", "talent") == 'digiidi'
assert remove_dirty_chars("exoticmiles", "toxic") == 'emles'