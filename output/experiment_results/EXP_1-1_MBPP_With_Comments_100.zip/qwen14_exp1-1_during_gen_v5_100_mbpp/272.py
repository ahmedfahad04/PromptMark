def rear_extract(tuples_list):
    # Initialize an empty list to store the rear elements
    rear_elements = []
    
    # Iterate through each tuple in the input list
    for item in tuples_list:
        # Append the last element of the tuple to the list
        rear_elements.append(item[-1])
    
    return rear_elements