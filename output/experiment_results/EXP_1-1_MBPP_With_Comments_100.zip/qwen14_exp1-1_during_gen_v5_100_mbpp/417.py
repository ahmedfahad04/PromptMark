def group_tuples(tuples_list):
    # Dictionary to hold grouped tuples
    grouped_dict = {}
    
    # Iterate through each tuple in the input list
    for tup in tuples_list:
        # Check if the first element of the tuple is already a key in the dictionary
        if tup[0] in grouped_dict:
            # Append the second element to the existing list in the dictionary
            grouped_dict[tup[0]].append(tup[1])
        else:
            # Create a new list with the second element of the tuple as the value
            grouped_dict[tup[0]] = [tup[1]]
    
    # Create the result list by converting each entry in the dictionary back into a tuple
    result = [(key,) + tuple(value) for key, value in grouped_dict.items()]
    
    return result