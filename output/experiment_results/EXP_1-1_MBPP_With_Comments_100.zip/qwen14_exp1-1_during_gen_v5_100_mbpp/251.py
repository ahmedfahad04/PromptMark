def insert_element(lst, elem):
    # Initialize an empty list to store the result
    result = []
    # Iterate through each item in the input list
    for item in lst:
        # Insert the element before the current item
        result.append(elem)
        result.append(item)
    return result