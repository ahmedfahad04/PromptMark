def surface_Area(base_edge, slant_height):
    # Calculate the base area of the square pyramid
    base_area = base_edge ** 2
    
    # Calculate the area of one triangular face
    triangle_area = (base_edge * slant_height) / 2
    
    # Total surface area includes the base area plus the area of four triangular faces
    total_surface_area = base_area + 4 * triangle_area
    
    return total_surface_area

# The provided test cases can be used to verify the correctness of the function.