def test_three_equal(a, b, c):
    # Count occurrences of each number
    count_a = (a == b) + (a == c)
    count_b = (b == a) + (b == c)
    count_c = (c == a) + (c == b)
    
    # Determine the maximum count of any single number
    max_count = max(count_a, count_b, count_c)
    
    # Return the maximum count if it's greater than 0, otherwise return 0
    return max_count if max_count > 0 else 0