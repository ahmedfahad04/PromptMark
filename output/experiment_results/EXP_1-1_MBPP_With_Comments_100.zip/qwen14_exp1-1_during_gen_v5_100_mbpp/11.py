def remove_Occ(wor_c, ch):
    # Check if the character exists in the word
    if ch in wor_c:
        # Find the first and last occurrence indices
        first_occurrence = wor_c.find(ch)
        last_occurrence = wor_c.rfind(ch)
        
        # Remove the first occurrence
        wor_c = wor_c[:first_occurrence] + wor_c[first_occurrence + 1:]
        
        # Remove the last occurrence
        wor_c = wor_c[:last_occurrence] + wor_c[last_occurrence + 1:]
    
    return wor_c