def union_elements(u_tuple, v_tuple):
    # Combine both tuples into one set to remove duplicates and get the union
    combined_set = set(u_tuple + v_tuple)
    # Convert the set back to a tuple and sort it
    sorted_union = tuple(sorted(combined_set))
    return sorted_union