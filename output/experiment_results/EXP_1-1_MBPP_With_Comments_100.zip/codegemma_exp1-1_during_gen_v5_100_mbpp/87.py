def merge_dictionaries_three(dict1, dict2, dict3):
  """
  Merges three dictionaries into a single dictionary.

  Args:
    dict1: The first dictionary.
    dict2: The second dictionary.
    dict3: The third dictionary.

  Returns:
    A new dictionary containing the merged dictionaries.
  """

  merged_dict = {}
  merged_dict.update(dict1)
  merged_dict.update(dict2)
  merged_dict.update(dict3)
  return merged_dict