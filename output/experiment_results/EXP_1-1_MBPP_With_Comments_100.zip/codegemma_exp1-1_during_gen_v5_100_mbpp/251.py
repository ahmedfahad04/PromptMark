def insert_element(list, element):
    """
    Inserts an element before each element in a list and returns the resulting list.
    """
    result = []
    for item in list:
        result.append(element)
        result.append(item)
    return result