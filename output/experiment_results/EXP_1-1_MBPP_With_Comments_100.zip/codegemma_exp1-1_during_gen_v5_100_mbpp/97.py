def frequency_lists(list_of_lists):
  """
  This function takes a list of lists and returns a dictionary of the frequency of each element in the flattened list.
  """
  flattened_list = [item for sublist in list_of_lists for item in sublist]
  frequency = {}
  for item in flattened_list:
    if item in frequency:
      frequency[item] += 1
    else:
      frequency[item] = 1
  return frequency