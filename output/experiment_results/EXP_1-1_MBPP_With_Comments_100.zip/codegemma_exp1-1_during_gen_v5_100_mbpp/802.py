def count_rotation(arr):
  """
  Counts the number of rotations required to generate a sorted array.
  """
  # Find the index of the minimum element in the array.
  min_index = arr.index(min(arr))
  
  # The number of rotations is the index of the minimum element plus 1.
  return min_index + 1