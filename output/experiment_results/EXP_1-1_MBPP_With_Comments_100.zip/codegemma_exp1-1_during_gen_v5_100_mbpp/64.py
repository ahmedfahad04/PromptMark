def subject_marks(marks):
    # Your code here