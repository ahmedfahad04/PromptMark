def rectangle_area(length, width):
  """
  This function calculates the area of a rectangle.
  """
  area = length * width
  return area