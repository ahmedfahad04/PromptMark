def new_tuple(list, str):
  """
  Creates a new tuple from the given string and list.

  Args:
    list: A list of strings.
    str: A string.

  Returns:
    A new tuple containing the elements of the list and the string.
  """
  return tuple(list + [str])