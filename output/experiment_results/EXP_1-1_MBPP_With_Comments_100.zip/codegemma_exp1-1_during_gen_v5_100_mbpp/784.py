def mul_even_odd(nums):
  """
  This function finds the product of the first even and odd number in a given list.
  """
  even = None
  odd = None
  for num in nums:
    if num % 2 == 0:
      if even is None:
        even = num
    else:
      if odd is None:
        odd = num
  if even is not None and odd is not None:
    return even * odd
  else:
    return None