def largest_subset(nums):
    """
    Finds the size of the largest subset of a list of numbers so that every pair is divisible.

    Args:
    nums: A list of numbers.

    Returns:
    The size of the largest subset.
    """
    nums.sort()
    size = 0
    for i in range(len(nums)):
        if i == 0 or nums[i] % nums[i - 1] == 0 or nums[i - 1] % nums[i] == 0:
            size += 1
    return size