def rear_extract(list_of_tuples):
  """
  This function takes in a list of tuples and returns a list containing the rear element of each tuple.
  """
  return [tup[-1] for tup in list_of_tuples]