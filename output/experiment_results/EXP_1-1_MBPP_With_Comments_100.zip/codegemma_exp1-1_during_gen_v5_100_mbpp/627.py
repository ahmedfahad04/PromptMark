def find_First_Missing(nums):
    """
    This function takes a sorted list of natural numbers and returns the smallest missing number.
    """
    if not nums:
        return 0
    if nums[-1] < 0:
        return 0
    if nums[0] > 0:
        return 0
    for i in range(len(nums)):
        if nums[i] != i + 1:
            return i + 1
    return len(nums) + 1