def sum_range_list(nums, start, end):
  """
  This function takes a list of numbers and two indices as input and returns the sum of the numbers in the list between the two indices (inclusive).
  """
  return sum(nums[start:end+1])