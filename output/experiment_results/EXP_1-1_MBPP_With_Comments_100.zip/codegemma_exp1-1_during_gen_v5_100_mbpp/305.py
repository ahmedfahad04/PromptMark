def start_withp(words):
    """
    This function returns two words from a list of words starting with letter 'p'.
    """
    result = []
    for word in words:
        if word.lower().startswith("p"):
            result.append(word)
    if len(result) < 2:
        return result[0], None
    else:
        return result[0], result[1]