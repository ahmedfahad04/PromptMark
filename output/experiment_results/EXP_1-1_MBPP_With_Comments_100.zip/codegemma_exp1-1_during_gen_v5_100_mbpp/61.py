def count_Substrings(num):
  count = 0
  for i in range(len(num)):
    for j in range(i, len(num)):
      sub = num[i:j+1]
      if sum(int(digit) for digit in sub) == len(sub):
        count += 1
  return count