def find_first_occurrence(arr, target):
    """
    Finds the first occurrence of a number in a sorted array.

    Args:
    arr: The sorted array.
    target: The number to find.

    Returns:
    The index of the first occurrence of the number, or -1 if it does not exist.
    """

    # Use binary search to find the first occurrence of the number.
    low = 0
    high = len(arr) - 1

    while low <= high:
        mid = (low + high) // 2

        if arr[mid] == target:
            # Found the first occurrence of the number.
            if mid == 0 or arr[mid - 1] != target:
                return mid

            # The number is not at the beginning of the array.
            high = mid - 1

        elif arr[mid] < target:
            low = mid + 1

        else:
            high = mid - 1

    # The number was not found in the array.
    return -1