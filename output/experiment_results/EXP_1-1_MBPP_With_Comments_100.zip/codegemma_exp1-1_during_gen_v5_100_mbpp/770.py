def odd_num_sum(n):
    """
    This function returns the sum of fourth power of first n odd natural numbers.
    """
    sum = 0
    for i in range(1, n+1):
        sum += i**4
    return sum