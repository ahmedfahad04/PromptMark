def Find_Min(List):
  min_length = float('inf')
  min_sublist = []
  for sublist in List:
    if len(sublist) < min_length:
      min_length = len(sublist)
      min_sublist = sublist
  return min_sublist