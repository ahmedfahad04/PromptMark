def count_divisors(num):
  """
  This function checks if the count of divisors of a number is even.
  """
  count = 0
  for i in range(1, num + 1):
    if num % i == 0:
      count += 1
  return count % 2 == 0