def surface_Area(base_edge, height):
  """
  This function calculates the surface area of a square pyramid with a given base edge and height.
  """
  # Calculate the area of the base
  base_area = base_edge**2

  # Calculate the area of the four lateral faces
  lateral_area = (base_edge**2 * height) / 2

  # Calculate the surface area
  surface_area = base_area + (4 * lateral_area)

  # Return the surface area
  return surface_area