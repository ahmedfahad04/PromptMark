def sequence(n):
    # Your code here