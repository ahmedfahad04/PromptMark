def and_tuples(tup1, tup2):
    """
    Extracts the elementwise and tuples from the given two tuples.

    Args:
        tup1: The first tuple.
        tup2: The second tuple.

    Returns:
        A tuple containing the elementwise and tuples from the two input tuples.
    """
    elementwise = [a and b for a, b in zip(tup1, tup2)]
    tuples = [a + b for a, b in zip(tup1, tup2)]
    return elementwise, tuples