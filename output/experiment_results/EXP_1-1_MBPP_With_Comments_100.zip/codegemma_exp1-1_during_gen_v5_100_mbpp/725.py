import re

def extract_quotation(text):
  """
  Extracts values between quotation marks " " of the given string.

  Args:
    text: The string to extract values from.

  Returns:
    A list of values between quotation marks.
  """
  pattern = r'"(.*?)"'
  matches = re.findall(pattern, text)
  return matches