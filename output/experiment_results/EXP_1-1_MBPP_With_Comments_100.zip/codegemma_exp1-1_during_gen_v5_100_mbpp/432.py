def median_trapezium(a, b, c):
    """
    This function finds the median length of a trapezium.
    """
    if a + b <= c or b + c <= a or c + a <= b:
        raise ValueError("Invalid input: a + b must be greater than c, b + c must be greater than a, and c + a must be greater than b")
    
    if a == b and b == c:
        return a
    
    if a == b or b == c or c == a:
        if a == b:
            return a
        elif b == c:
            return b
        else:
            return c
    
    if a + b > c and b + c > a and c + a > b:
        if a + b > c:
            if b + c > a:
                return b
            else:
                return a
        elif b + c > a:
            if c + a > b:
                return c
            else:
                return b
        else:
            if a + b > c:
                return a
            else:
                return c
    
    if a + b > c and b + c > a and c + a > b:
        if a + b > c:
            if b + c > a:
                return b
            else:
                return a
        elif b + c > a:
            if c + a > b:
                return c
            else:
                return b
        else:
            if a + b > c:
                return a
            else:
                return c