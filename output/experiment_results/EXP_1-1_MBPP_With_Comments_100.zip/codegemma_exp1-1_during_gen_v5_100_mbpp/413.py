def extract_nth_element(list_of_tuples, nth):
    """
    This function extracts the nth element from a given list of tuples.
    """
    return [element for element in zip(*list_of_tuples)][nth]