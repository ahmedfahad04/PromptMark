def reverse_string_list(str_list):
    """
    Reverses each string in a list of string values.

    Args:
    str_list: A list of string values.

    Returns:
    A new list of string values with each string reversed.
    """
    reversed_list = []
    for string in str_list:
        reversed_str = string[::-1]
        reversed_list.append(reversed_str)
    return reversed_list