def loss_amount(amount, price):
    if amount > price:
        return amount - price
    else:
        return 0