def empty_dit(list_of_dict):
    for dictionary in list_of_dict:
        if dictionary:
            return False
    return True