def tuple_intersection(list1, list2):
    """
    Finds the tuple intersection of elements in the given tuple list irrespective of their order.
    """
    # Create a set of elements from the first list
    set1 = set(list1)
    
    # Create a set of elements from the second list
    set2 = set(list2)
    
    # Find the intersection of the two sets
    intersection = set1 & set2
    
    # Convert the intersection set to a tuple
    return tuple(intersection)