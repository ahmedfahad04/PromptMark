def check_value(dict,val):
    for i in dict.values():
        if i != val:
            return False
    return True