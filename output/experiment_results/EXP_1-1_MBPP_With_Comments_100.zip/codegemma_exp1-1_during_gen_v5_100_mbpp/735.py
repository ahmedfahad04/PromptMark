def toggle_middle_bits(num):
    """
    This function toggles the middle bits of a number except the first and the last bit.
    """
    num = num & 0b1111111111111111111111111111111111111111111111111111111111111110
    num = num ^ 0b1010101010101010101010101010101010101010101010101010101010101010
    return num