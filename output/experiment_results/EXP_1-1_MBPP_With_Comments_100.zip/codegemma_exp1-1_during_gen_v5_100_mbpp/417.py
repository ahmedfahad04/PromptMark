from itertools import groupby

def group_tuples(tuples):
  """
  This function groups tuples with the same first element
  and returns a list of groups.
  """
  groups = []
  for key, group in groupby(tuples, key=lambda t: t[0]):
    groups.append((key, tuple(group)))
  return groups