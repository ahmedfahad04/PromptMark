def square_nums(nums):
    """
    This function takes a list of numbers and returns a list of squares of those numbers.
    """
    return [num**2 for num in nums]