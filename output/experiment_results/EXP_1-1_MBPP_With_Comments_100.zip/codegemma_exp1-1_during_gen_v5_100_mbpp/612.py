def merge(list_of_lists):
  """
  This function takes a list of lists and returns a list of two lists where the first list has the first element of each sublist and the second one has the second.
  """
  list1 = []
  list2 = []
  for sublist in list_of_lists:
    list1.append(sublist[0])
    list2.append(sublist[1])
  return [list1, list2]