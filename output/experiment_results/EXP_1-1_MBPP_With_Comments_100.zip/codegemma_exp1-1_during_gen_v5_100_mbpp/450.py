def extract_string(str_list, size):
    """
    This function extracts specified size of strings from a given list of string values.
    """
    return [string for string in str_list if len(string) == size]