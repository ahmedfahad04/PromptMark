def count_vowels(s):
    count = 0
    for i in range(len(s)):
        if s[i] in 'aeiouAEIOU':
            if i > 0 and s[i - 1] in 'aeiouAEIOU':
                count += 1
            if i < len(s) - 1 and s[i + 1] in 'aeiouAEIOU':
                count += 1
    return count