def remove_Occ(str, char):
    """
    This function removes the first and last occurrence of a given character from the string.
    """
    if str == "":
        return ""
    elif str[0] == char and str[-1] == char:
        return str[1:-1]
    elif str[0] == char:
        return str[1:]
    elif str[-1] == char:
        return str[:-1]
    else:
        return str