def find_Average_Of_Cube(n):
    """
    This function returns the average of cubes of first n natural numbers.
    """
    sum_of_cubes = 0
    for i in range(1, n + 1):
        sum_of_cubes += i ** 3
    return sum_of_cubes / n