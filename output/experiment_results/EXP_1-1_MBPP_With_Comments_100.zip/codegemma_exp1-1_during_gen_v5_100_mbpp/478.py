def remove_lowercase(text):
    """
    Removes lowercase substrings from a given string.

    Args:
    text: The string to remove lowercase substrings from.

    Returns:
    The string with lowercase substrings removed.
    """
    return ''.join([char for char in text if not char.islower()])