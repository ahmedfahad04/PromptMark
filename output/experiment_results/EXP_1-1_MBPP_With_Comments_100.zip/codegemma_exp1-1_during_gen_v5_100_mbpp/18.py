def remove_dirty_chars(str1, str2):
  """
  Removes characters from the first string which are present in the second string.

  Args:
    str1: The first string.
    str2: The second string.

  Returns:
    The first string with the characters from the second string removed.
  """

  # Create a set of characters from the second string.
  dirty_chars = set(str2)

  # Remove the dirty characters from the first string.
  clean_str = ''.join([char for char in str1 if char not in dirty_chars])

  return clean_str