def intersection_array(arr1, arr2):
  """
  This function takes two arrays and returns the intersection of the two arrays.
  """
  intersection = []
  for i in arr1:
    if i in arr2:
      intersection.append(i)
  return intersection