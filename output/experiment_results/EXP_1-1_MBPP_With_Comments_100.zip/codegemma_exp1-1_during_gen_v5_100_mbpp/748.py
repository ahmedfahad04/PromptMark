def capital_words_spaces(text):
    """
    This function puts spaces between words starting with capital letters in a given string.
    """
    new_text = []
    for word in text.split():
        if word[0].isupper():
            new_text.append(word)
        else:
            new_text.append(word[0].lower() + word[1:])
    return " ".join(new_text)