def sum_series(n):
    """
    Calculates the sum of n - 2*i from i=0 to n // 2.

    Args:
    n: The number to calculate the sum up to.

    Returns:
    The sum of n - 2*i from i=0 to n // 2.
    """
    sum = 0
    for i in range(n // 2 + 1):
        sum += n - 2 * i
    return sum