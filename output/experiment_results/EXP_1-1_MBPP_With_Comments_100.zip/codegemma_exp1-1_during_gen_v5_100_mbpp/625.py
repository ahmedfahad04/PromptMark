def swap_List(lst):
  """
  This function swaps the first and last element in a given list.
  """
  lst[0], lst[-1] = lst[-1], lst[0]
  return lst