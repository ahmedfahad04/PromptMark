def list_split(list, n):
    """
    Splits a list for every nth element, returning a list of the resulting lists.
    """
    return [list[i::n] for i in range(n)]