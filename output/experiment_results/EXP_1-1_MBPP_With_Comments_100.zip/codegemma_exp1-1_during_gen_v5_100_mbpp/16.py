def text_lowercase_underscore(text):
  for i in range(len(text)):
    if text[i].islower():
      if i == len(text) - 1 or text[i + 1] == "_":
        return True
  return False