def count_X(tup, x):
    """
    Counts the number of occurrences of an element in a tuple.

    Args:
        tup: The tuple to search.
        x: The element to count.

    Returns:
        The number of occurrences of the element in the tuple.
    """
    return tup.count(x)