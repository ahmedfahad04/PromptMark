def square_Sum(n):
    """
    This function takes in an integer n and returns the sum of the squares of the first n odd natural numbers.
    """
    sum_of_squares = 0
    for i in range(1, n + 1):
        sum_of_squares += i ** 2
    return sum_of_squares