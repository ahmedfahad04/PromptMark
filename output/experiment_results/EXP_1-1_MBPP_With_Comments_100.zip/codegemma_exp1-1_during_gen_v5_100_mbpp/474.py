def replace_char(text, char, new_char):
    """
    Replaces all occurrences of a character in a string with a new character.

    Args:
    text (str): The string to replace characters in.
    char (str): The character to replace.
    new_char (str): The new character to replace with.

    Returns:
    str: The string with the characters replaced.
    """
    return text.replace(char, new_char)