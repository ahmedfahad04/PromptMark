def pair_wise(list):
  """
  This function returns a list of all pairs of consecutive items in a given list.
  """
  pairs = []
  for i in range(len(list) - 1):
    pairs.append((list[i], list[i + 1]))
  return pairs