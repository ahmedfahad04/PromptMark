def average_tuple(tuple_of_tuples):
  """
  This function takes a tuple of tuples and returns the average value for each tuple as a list.
  """
  average_list = []
  for tuple in tuple_of_tuples:
    average = sum(tuple) / len(tuple)
    average_list.append(average)
  return average_list