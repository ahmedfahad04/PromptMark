def remove_whitespaces(text):
    """
    This function removes all whitespaces from the given string.
    """
    return text.replace(' ', '')