def find_solution(a, b, n):
    """
    Finds integers x and y that satisfy ax + by = n as a tuple, or returns None if no solution exists.
    """
    if a == 0:
        if b == 0:
            if n == 0:
                return (0, 0)
            else:
                return None
        else:
            if n % b == 0:
                return (0, n // b)
            else:
                return None
    else:
        if b == 0:
            if n % a == 0:
                return (n // a, 0)
            else:
                return None
        else:
            gcd = math.gcd(a, b)
            if n % gcd != 0:
                return None
            else:
                x = n // gcd * a // b
                y = n // gcd * b // a
                return (x, y)