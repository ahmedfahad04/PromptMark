def parabola_directrix(a, b, c):
    """
    This function finds the directrix of a parabola given the equation of the parabola.
    """
    directrix = - (b**2 - 4*a*c) / (4*a)
    return directrix