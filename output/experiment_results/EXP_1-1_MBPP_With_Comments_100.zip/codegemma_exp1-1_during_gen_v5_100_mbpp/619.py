def move_num(str):
    """
    Moves all the numbers to the end of the given string.
    """
    num = [i for i in str if i.isdigit()]
    str = [i for i in str if not i.isdigit()]
    return ''.join(str + num)