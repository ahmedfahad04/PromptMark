def interleave_lists(list1, list2, list3):
  """
  Interleaves three lists of the same length into a single flat list.
  """
  result = []
  for i in range(len(list1)):
    result.append(list1[i])
    result.append(list2[i])
    result.append(list3[i])
  return result