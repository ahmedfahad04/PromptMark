def find_Element(nums, rotations, k, index):
  """
  This function finds the element at a given index after number of rotations.
  """
  for i in range(rotations[k][0], rotations[k][1]):
    nums.append(nums.pop(i))
  return nums[index - 1]