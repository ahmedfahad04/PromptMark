def round_and_sum(num_list):
    """
    This function takes a list of numbers and returns the total sum multiplied by the length of the list after rounding every number in the list.
    """
    total_sum = 0
    for number in num_list:
        total_sum += round(number)
    return total_sum * len(num_list)