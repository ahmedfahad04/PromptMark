def substract_elements(tuple1, tuple2):
  """
  This function subtracts the elements of the first tuple by the elements of the second tuple with the same index.
  """
  return tuple(a - b for a, b in zip(tuple1, tuple2))