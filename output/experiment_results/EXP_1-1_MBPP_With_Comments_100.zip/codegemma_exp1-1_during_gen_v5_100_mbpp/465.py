def drop_empty(dict):
  """
  This function drops empty items from a given dictionary.
  """
  return {key: value for key, value in dict.items() if value is not None}