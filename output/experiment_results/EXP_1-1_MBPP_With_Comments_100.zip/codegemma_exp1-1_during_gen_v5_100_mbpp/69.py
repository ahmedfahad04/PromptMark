def is_sublist(list, sublist):
    """
    Checks if a list contains a given sublist or not.

    Args:
        list: The main list.
        sublist: The sublist to check for.

    Returns:
        True if the sublist is a sublist of the main list, False otherwise.
    """
    for i in range(len(list) - len(sublist) + 1):
        if list[i: i + len(sublist)] == sublist:
            return True
    return False