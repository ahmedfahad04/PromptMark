import math

def otherside_rightangle(side1,side2):
  """
  This function finds the third side of a right angled triangle.
  """
  if side1**2 + side2**2 == (side1+side2)**2:
    return math.sqrt(side1**2 + side2**2)
  else:
    return "Not a right angled triangle"