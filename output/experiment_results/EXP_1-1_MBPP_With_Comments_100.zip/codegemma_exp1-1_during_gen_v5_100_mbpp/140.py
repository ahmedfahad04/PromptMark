def extract_singly(nested_list):
  """
  Extracts a set of numbers from a list of lists.
  """
  return set().union(*nested_list)