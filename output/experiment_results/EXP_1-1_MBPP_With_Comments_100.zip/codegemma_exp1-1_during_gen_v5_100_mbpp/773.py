def occurance_substring(text, subtext):
  """
  Find the occurrence and position of the substrings within a string.
  Return None if there is no match.
  """
  if subtext not in text:
    return None
  
  index = text.index(subtext)
  return subtext, index, index + len(subtext)