def sum_list(a, b):
  """
  Sums two lists of equal length and returns a new list with the sum of each element.
  """
  if len(a) != len(b):
    raise ValueError("Lists must be of equal length.")
  
  result = []
  for i in range(len(a)):
    result.append(a[i] + b[i])
  
  return result