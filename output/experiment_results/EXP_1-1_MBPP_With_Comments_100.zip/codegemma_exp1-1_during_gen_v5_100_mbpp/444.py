def trim_tuple(tuple_list, k):
  """
  Trims each tuple by k in the given tuple list.
  """
  return '[' + ', '.join([str(tuple_[k:]) for tuple_ in tuple_list]) + ']'