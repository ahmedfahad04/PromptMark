def remove_nested(tup):
  """
  Removes tuples from the given tuple.

  Args:
    tup: The tuple to remove tuples from.

  Returns:
    A new tuple with tuples removed.
  """
  return tuple(item for item in tup if not isinstance(item, tuple))