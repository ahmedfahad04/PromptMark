def unique_product(nums):
    """
    Calculates the product of the unique numbers in a given list.

    Args:
      nums: A list of integers.

    Returns:
      The product of the unique numbers in the list.
    """
    unique_nums = set(nums)
    product = 1
    for num in unique_nums:
        product *= num
    return product