def Find_Max_Length(incoming_collection_of_units: list[list]) -> int:
    """
    Acquires the maximum length among all sublists within an incoming collection.

    Args:
        incoming_collection_of_units: A list containing various sublists.

    Returns:
        An integer indicating the size of the longest sublist.
        Returns 0 if the incoming collection is empty or contains only empty sublists.
    """
    # If the incoming collection is empty, no sublists exist, so the maximum
    # length is 0. This avoids issues with calling max() on an empty sequence.
    if not incoming_collection_of_units:
        return 0

    # Obtain a collection of sizes for each sublist unit using a generator expression.
    # This is memory-efficient as it does not create an intermediate list of all sizes.
    sizes_of_units = (len(one_sublist_unit) for one_sublist_unit in incoming_collection_of_units)

    # Find and return the maximum size from the collection of sizes.
    return max(sizes_of_units)