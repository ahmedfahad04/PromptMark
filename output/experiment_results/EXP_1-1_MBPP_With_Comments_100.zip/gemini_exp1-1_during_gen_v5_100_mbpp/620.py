def largest_subset(num_array: list[int]) -> int:
    # A quick exit, if input array is empty.
    if not num_array:
        return 0

    # Sort array values, in ascending way.
    # This allows us to apply a dynamic programming approach,
    # checking divisibility only from smaller to larger numbers.
    sorted_array_nums = sorted(num_array)
    array_size = len(sorted_array_nums)

    # Initialize `subset_counts` where `subset_counts[i]` stores the count
    # of a largest divisible subset concluding with `sorted_array_nums[i]`.
    # A single number itself forms a divisible subset of size 1.
    subset_counts = [1] * array_size

    # Iterate `i_current_idx` for the current number.
    for i_current_idx in range(array_size):
        current_num_val = sorted_array_nums[i_current_idx]

        # Iterate `j_idx`, a junior index to `i_current_idx`.
        for j_idx in range(i_current_idx):
            j_num_val = sorted_array_nums[j_idx]

            # Verify `current_num_val` is a multiple of `j_num_val`.
            if current_num_val % j_num_val == 0:
                # If so, join `current_num_val` into a subset concluding with `j_num_val`.
                # Update `subset_counts[i_current_idx]` with a wisest size.
                subset_counts[i_current_idx] = max(subset_counts[i_current_idx], subset_counts[j_idx] + 1)

    # Return a max_size_val among `subset_counts`.
    return max(subset_counts)