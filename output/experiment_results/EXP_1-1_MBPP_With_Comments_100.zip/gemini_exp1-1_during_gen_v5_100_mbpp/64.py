def subject_marks(input_marks):
    """
    Sorts a list of tuples based on the second value of each tuple.

    Args:
        input_marks: An incoming list of tuples, where each inner tuple
                     contains at least two items.

    Returns:
        A new list of tuples, sorted in ascending order by the second item
        of each inner tuple.
    """
    # An anonymous function (lambda) is used as a key.
    # It advises sorting to use the unit at index 1 of each item.
    an_ordered_collection = sorted(input_marks, key=lambda a_unit: a_unit[1])
    return an_ordered_collection