def sequence(input_num: int) -> int:
    """
    Calculates the Nth number in the Newman-Conway sequence.
    """
    # Handle initial known values for P(1) and P(2).
    if input_num == 1 or input_num == 2:
        return 1
    
    # Initialize sequence array. Using 1-based indexing, P(0) is a dummy.
    # conway_array[j] will hold P(j).
    conway_array = [0, 1, 1] 

    # Compute values from P(3) up to P(input_num).
    for idx in range(3, input_num + 1):
        # Obtain P(idx-1) value.
        current_index_minus_one_value = conway_array[idx - 1]
        
        # Apply the Newman-Conway recurrence relation: P(idx) = P(P(idx-1)) + P(idx - P(idx-1)).
        current_val = conway_array[current_index_minus_one_value] + conway_array[idx - current_index_minus_one_value]
        
        conway_array.append(current_val)
    
    # Return the Nth value, which is at conway_array[input_num].
    return conway_array[input_num]