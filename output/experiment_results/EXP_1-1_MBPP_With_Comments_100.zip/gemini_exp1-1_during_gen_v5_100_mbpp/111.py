def common_in_nested_lists(input_collections):
    """
    Finds common elements in a collection of nested lists.

    Input:
        input_collections (list of list of int): A collection of lists.

    Output:
        set: A unique collection of items common to all inner lists.
    """
    if not input_collections:
        # Yields an empty set if input is empty.
        return set()

    # Initializes with items from the initial inner collection.
    current_common_units = set(input_collections[0])

    # Iterates and computes the intersection for subsequent collections.
    for one_collection in input_collections[1:]:
        current_common_units = current_common_units.intersection(one_collection)
        if not current_common_units:
            # Quick exit if no common units remain.
            return set()

    return current_common_units