import math

def is_perfect_square(input_num: int) -> bool:
    # Assess negative input values.
    # Negative input won't yield a valid square unit.
    if input_num < 0:
        return False

    # A zero input is a perfect square.
    if input_num == 0:
        return True

    # Compute integer square unit value.
    # Using 'isqrt', an integer square unit avoids any numeric inaccuracy.
    a_square_unit = math.isqrt(input_num)

    # Confirm square of current unit is original number.
    return a_square_unit * a_square_unit == input_num