def unique_product(input_array_val: list) -> int:
    """
    Calculates the product of all unique numbers within a given list.

    Args:
        input_array_val: A list of numbers.

    Returns:
        The product of the unique numbers in the input list.
        If the list of unique numbers is empty, it returns 1 (multiplicative identity).
    """
    # Acquire unique items from the input collection.
    # Utilizing a set automatically handles uniqueness.
    unique_values_set = set(input_array_val)

    # Initialize the overall product.
    # Commencing with 1 ensures a correct calculation,
    # as multiplying any number by 1 yields its original value.
    overall_value = 1

    # Iterate among each unique number, applying multiplication.
    for a_current_num in unique_values_set:
        overall_value = overall_value * a_current_num

    # Yield the computed product.
    return overall_value