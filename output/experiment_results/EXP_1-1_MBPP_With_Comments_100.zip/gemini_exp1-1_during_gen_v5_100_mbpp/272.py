def rear_extract(an_input_collection_of_tuples):
    """
    Accepts a list containing tuples and yields a new list
    comprising only the final item of each tuple.
    """
    # A concise way to collect the final item of each tuple.
    # It iterates over the collection, accessing the last item using an index of -1.
    return [a_current_tuple[-1] for a_current_tuple in an_input_collection_of_tuples]