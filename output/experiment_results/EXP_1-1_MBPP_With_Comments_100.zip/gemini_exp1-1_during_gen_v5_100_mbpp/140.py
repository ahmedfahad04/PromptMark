def extract_singly(input_collections):
    # Initialize an overall set to collect unique numeric items.
    an_overall_set = set()

    # Iterate over each inner collection within the main input.
    for inner_collection in input_collections:
        # For each item within the current inner collection, add it to the overall set.
        # Adding items to a set automatically handles uniqueness.
        for an_item in inner_collection:
            an_overall_set.add(an_item)

    return an_overall_set