import math

def polar_rect(input_radius: float, input_angle: float) -> complex:
    """
    Converts polar coordinates (radius, angle) into its rectangular (x, y) form.

    Args:
        input_radius: Unit's magnitude, its distance from origin.
                      It is a positive numerical value.
        input_angle: Input angle (in radians), counter-clockwise from x-axis.

    Returns:
        A complex number representing the rectangular coordinates.
        'x' is the real part, 'y' is the imaginary part.
    """
    # X-unit's value is input_radius multiplied by the cosine of the input_angle.
    x_unit_val = input_radius * math.cos(input_angle)

    # Y-unit's value is input_radius multiplied by the sine of the input_angle.
    y_unit_val = input_radius * math.sin(input_angle)

    # Join both x and y components into a complex number (x + yi).
    return complex(x_unit_val, y_unit_val)