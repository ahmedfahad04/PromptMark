import re

def find_adverbs(an_input_chain: str) -> str:
    """
    Aims to locate an initial 'ly'-ending word unit
    and its position within an input chain.
    """
    # Iterates to find all word units using a regular expression.
    for a_match_obj in re.finditer(r'\b\w+\b', an_input_chain):
        a_word_itself = a_match_obj.group(0)
        a_word_lower = a_word_itself.lower()

        # Checks if the current word unit concludes with 'ly'.
        if a_word_lower.endswith('ly'):
            init_position = a_match_obj.start()
            univ_position = a_match_obj.end()
            return f"{init_position}-{univ_position}: {a_word_itself}"

    # Yields an empty string if no 'ly'-concluding adverb is found.
    return ""