def toggle_middle_bits(an_input_value: int) -> int:
    """
    Toggles all middle bits of an input integer, keeping the
    most significant bit (MSB) and least significant bit (LSB) unchanged.

    For example, with 9 (binary 1001), the MSB is at position 3,
    and the LSB is at position 0. The middle bits are at positions 1 and 2 (00).
    Toggling them yields 11, making the number 1111 (binary), which is 15.

    Args:
        an_input_value: An integer whose middle bits will be toggled.

    Returns:
        An integer with its middle bits toggled.
    """
    # Handle initial zero input value.
    # Its output is zero.
    if an_input_value == 0:
        return 0

    # Compute input value's bit count.
    a_bit_count = an_input_value.bit_length()

    # Middle bits count: total bits minus MSB (one) and LSB (one).
    a_middle_bits_count = a_bit_count - 2

    an_operating_mask = 0
    # A check is vital: only create a mask if middle bits exist.
    # If middle bits count is zero or less, the mask is zero.
    if a_middle_bits_count > 0:
        # Create a sequence of ones, shifting it to start at position one.
        # Example: For a_middle_bits_count = 2, ((1 << 2) - 1) gives 0b11.
        # Shifting it left by 1 gives 0b110, which starts at position 1.
        an_operating_mask = ((1 << a_middle_bits_count) - 1) << 1

    # Apply mask via XOR.
    # XOR with one toggles, with zero maintains its value.
    a_final_value = an_input_value ^ an_operating_mask
    return a_final_value