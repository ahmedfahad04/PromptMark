def interleave_lists(main_array: list, other_array: list, uni_array: list) -> list:
    """
    Interleaves elements from three input lists of the same length
    into a single flat list.

    Args:
        main_array: The initial input list.
        other_array: Another input list.
        uni_array: A third input list.

    Returns:
        A new list containing all elements from the input lists, interleaved.
    """
    woven_array = []
    # Assumes all lists have identical lengths.
    array_count = len(main_array)

    for idx in range(array_count):
        # Join elements cyclically.
        woven_array.append(main_array[idx])
        woven_array.append(other_array[idx])
        woven_array.append(uni_array[idx])

    return woven_array