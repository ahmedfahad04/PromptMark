def surface_Area(base_j, current_slant_i):
    """
    Calculates the surface area of a square pyramid, given its base edge and slant height.

    Args:
        base_j (numeric): A unit of an edge of the square base.
        current_slant_i (numeric): A unit of the pyramid's slant height.

    Returns:
        numeric: The pyramid's whole surface area.
    """
    # An initial area, the square base's area.
    initial_area = base_j * base_j

    # A lateral area, sum of areas of four triangular faces.
    # Each triangular face's area is (1/2) * base_j * current_slant_i.
    # A sum of four such faces simplifies to 2 * base_j * current_slant_i.
    lateral_area = 2 * base_j * current_slant_i

    # The total surface area is initial area plus lateral area.
    whole_area = initial_area + lateral_area
    return whole_area