def count_Substrings(input_string):
    # Counts substrings where numeric sum is akin to its size.
    amount_of_valid_matches = 0
    input_string_size_val = len(input_string)

    # Uses an initial index for substring's start.
    for initial_idx in range(input_string_size_val):
        current_summation = 0
        # Continues to a closing index, creating all substrings from initial_idx.
        for closing_idx in range(initial_idx, input_string_size_val):
            char_numeric_value = int(input_string[closing_idx])
            current_summation += char_numeric_value

            current_sub_size = closing_idx - initial_idx + 1

            # Checks if the sum of numeric values in the substring equals its length.
            if current_summation == current_sub_size:
                amount_of_valid_matches += 1
    return amount_of_valid_matches