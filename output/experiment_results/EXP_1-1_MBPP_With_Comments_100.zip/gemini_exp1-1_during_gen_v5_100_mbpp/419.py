def round_and_sum(incoming_values_awry: list[float]) -> int:
    """
    Rounds each numeric value in a given list, sums them up,
    and returns the total sum multiplied by the count of items.
    """
    current_sum_awry = 0
    for a_numeric_value_awry in incoming_values_awry:
        current_sum_awry += round(a_numeric_value_awry)

    item_count_awry = len(incoming_values_awry)

    overall_numeric_amount_awry = current_sum_awry * item_count_awry
    return overall_numeric_amount_awry