def power(a, b):
    # This computes 'a' raised to the power 'b'.
    # It uses Python's native exponentiation operator '**' for conciseness
    # and to ensure correct handling of various scenarios like zero
    # or negative exponents.
    my_ans = a ** b
    return my_ans