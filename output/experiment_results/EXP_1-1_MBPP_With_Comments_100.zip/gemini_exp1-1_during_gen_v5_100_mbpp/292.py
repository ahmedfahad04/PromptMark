def find(input_num_one: int, input_num_two: int) -> int:
    """
    Calculates the quotient of two numbers,
    rounded down to the nearest integer.
    Assumes input_num_two is non-zero.
    """
    return input_num_one // input_num_two