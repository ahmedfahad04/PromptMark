def list_tuple(a_list):
    """
    Converts an input list into an immutable tuple.

    Args:
        a_list: An incoming list of items.

    Returns:
        A new tuple containing all items from the input list.
    """
    return tuple(a_list)