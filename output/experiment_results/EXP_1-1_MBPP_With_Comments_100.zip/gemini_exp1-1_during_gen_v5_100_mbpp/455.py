def check_monthnumb_number(a_month_num: int) -> bool:
    """
    Ascertains whether a given month number contains 31 days.

    A month number (1-12) is input; the output is True if it's a 31-day month,
    otherwise False.

    Args:
        a_month_num (int): A numeric value indicating the month (1 for January, 12 for December).

    Returns:
        bool: True if the month possesses 31 days, False if it owns a different count.
    """
    # A set of month numeric codes which contain 31 units.
    _my_31s_months_nums = {1, 3, 5, 7, 8, 10, 12}
    return a_month_num in _my_31s_months_nums