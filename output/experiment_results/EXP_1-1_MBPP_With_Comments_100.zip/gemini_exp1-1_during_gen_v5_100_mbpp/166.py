def find_even_pair(an_input_array: list[int]) -> int:
    # An XOR of two ints is an even value only if both ints are even
    # or if both ints are odd.
    # An_XOR (a, b) is Even <==> (a % 2 == 0 and b % 2 == 0) or (a % 2 != 0 and b % 2 != 0)

    an_even_count = 0
    an_odd_count = 0

    for a_num_val in an_input_array:
        if a_num_val % 2 == 0:
            an_even_count += 1
        else:
            an_odd_count += 1

    an_ans_count = 0

    # Counts all unique pairs of even numbers.
    # Each pair of even numbers will XOR to an even number.
    an_ans_count += (an_even_count * (an_even_count - 1)) // 2

    # Counts all unique pairs of odd numbers.
    # Each pair of odd numbers will XOR to an even number.
    an_ans_count += (an_odd_count * (an_odd_count - 1)) // 2

    return an_ans_count