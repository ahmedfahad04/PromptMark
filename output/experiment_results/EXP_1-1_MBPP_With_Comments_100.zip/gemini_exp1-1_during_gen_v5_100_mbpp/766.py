def pair_wise(an_input_array: list) -> list[tuple[any, any]]:
    """
    Creates a list of all consecutive item pairs within an input list.

    Args:
        an_input_array: A list of items.

    Returns:
        A new list of tuples, each containing two adjacent items from the input.
        An empty list is given if the input array contains less than two items.
    """
    if len(an_input_array) < 2:
        # A list with under two items yields no pairs.
        return []

    a_new_collection = []
    # Iterates up to the second-to-last item to always access a next item.
    for an_idx in range(len(an_input_array) - 1):
        an_item_current = an_input_array[an_idx]
        an_item_next = an_input_array[an_idx + 1]
        a_new_collection.append((an_item_current, an_item_next))

    return a_new_collection