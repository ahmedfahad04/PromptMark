import re

def extract_quotation(a_current_string: str) -> list[str]:
    """
    Extracts all substrings enclosed within double quotation marks from a given string.
    Only double quotes are considered; single quotes are ignored.

    Args:
        a_current_string: An input string that may contain quoted values.

    Returns:
        A list of strings, where each string is a value found between
        double quotation marks. An empty list is given if no such values occur.
    """
    # Uses a regular expression to find all occurrences of content within double quotes.
    # The pattern '"([^"]*)"' means:
    # - '"': Match a literal double quotation mark.
    # - '([^"]*)': Capture any character that is NOT a double quote, zero or more times.
    # - '"': Match another literal double quotation mark.
    a_pattern = r'"([^"]*)"'
    outcome_values = re.findall(a_pattern, a_current_string)
    return outcome_values