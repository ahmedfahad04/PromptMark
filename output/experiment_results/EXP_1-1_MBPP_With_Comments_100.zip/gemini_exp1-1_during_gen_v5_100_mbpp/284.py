def check_element(input_collection, key_item):
    """
    Checks if all items in an input_collection are identical to a key_item.

    Args:
        input_collection (list): A collection of any items.
        key_item (any): An item to compare against all items in the input_collection.

    Returns:
        bool: True if all items in the input_collection match the key_item,
              False otherwise.
    """
    # Verify all items in the input_collection match the key_item.
    # The 'all()' function returns True if all elements in the given iterable
    # are true (or if the iterable is empty).
    return all(an_item == key_item for an_item in input_collection)