def loss_amount(actual_cost, sale_amount):
    """
    Calculates the loss amount on a sale.
    Returns zero if no loss occurs.
    """
    if actual_cost > sale_amount:
        # If the actual cost is higher than the sale amount, a loss occurs.
        # This calculates the magnitude of the financial un-win.
        unwin_amount = actual_cost - sale_amount
        return unwin_amount
    else:
        # If the sale amount meets or exceeds the actual cost, there is no loss.
        return 0