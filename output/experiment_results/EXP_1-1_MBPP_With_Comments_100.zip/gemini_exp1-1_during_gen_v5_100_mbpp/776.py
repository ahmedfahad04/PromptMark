def count_vowels(input_string: str) -> int:
    """
    Counts characters which have vowels as their neighbors.
    A character is counted if it is a consonant and has at least one vowel
    (a, e, i, o, u) as an immediate neighbor (left or right).
    """
    count_val = 0
    # A set allows for quick vowel membership checking.
    vowel_set = {'a', 'o', 'i', 'u', 'e'}
    input_size = len(input_string)

    def is_vowel_char(char_val: str) -> bool:
        """
        Checks if a character is a vowel.
        """
        return char_val.lower() in vowel_set

    # Iterate through each character in the input string.
    for current_idx in range(input_size):
        current_char = input_string[current_idx]

        # Only consonants can be counted. Vowels are skipped.
        if is_vowel_char(current_char):
            continue

        has_vowel_neighbor = False

        # Check the left neighbor if it exists.
        if current_idx > 0:
            if is_vowel_char(input_string[current_idx - 1]):
                has_vowel_neighbor = True
        
        # Check the right neighbor if it exists and no vowel neighbor was found yet.
        if not has_vowel_neighbor and current_idx < input_size - 1:
            if is_vowel_char(input_string[current_idx + 1]):
                has_vowel_neighbor = True
        
        # If the consonant has a vowel neighbor, increment the count.
        if has_vowel_neighbor:
            count_val += 1
            
    return count_val