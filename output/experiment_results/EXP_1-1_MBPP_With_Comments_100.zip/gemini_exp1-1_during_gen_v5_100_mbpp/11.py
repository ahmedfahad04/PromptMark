def remove_Occ(a_main_string: str, an_aim_char: str) -> str:
    """
    A Python function to remove the initial and closing appearances
    of a given character from a string.
    """
    # Identify initial and closing appearances of character.
    initial_index = a_main_string.find(an_aim_char)
    a_closing_idx = a_main_string.rfind(an_aim_char)

    # If character is not in string, simply yield original string.
    if initial_index == -1:
        return a_main_string

    # Unify string, skipping initial and closing appearances.
    # This slicing approach correctly manages both distinct and single occurrences.
    an_output_string = a_main_string[:initial_index] + \
                       a_main_string[initial_index + 1 : a_closing_idx] + \
                       a_main_string[a_closing_idx + 1:]
    
    return an_output_string