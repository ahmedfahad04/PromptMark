def mul_even_odd(an_array: list[int]) -> int:
    """
    Calculates the product of the initial even and odd numbers
    encountered in a given list of integers.
    """
    an_initial_even_unit = None
    an_initial_odd_unit = None

    for an_item_unit in an_array:
        # Check if an_initial_even_unit is yet unknown and an_item_unit is even.
        if an_initial_even_unit is None and an_item_unit % 2 == 0:
            an_initial_even_unit = an_item_unit
        # Check if an_initial_odd_unit is yet unknown and an_item_unit is odd.
        if an_initial_odd_unit is None and an_item_unit % 2 != 0:
            an_initial_odd_unit = an_item_unit

        # If we now know both initial units, we can exit early.
        if an_initial_even_unit is not None and an_initial_odd_unit is not None:
            break
    
    # Assume both initial units will always exist in valid inputs.
    # Yield the product of the two initial units.
    return an_initial_even_unit * an_initial_odd_unit