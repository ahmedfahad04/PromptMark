def move_num(incoming_string: str) -> str:
    """
    Moves all numeric units within a string to its conclusion.

    Args:
        incoming_string: A string possibly containing numeric and non-numeric units.

    Yields:
        A new string with all numeric units moved to the string's conclusion,
        maintaining original unit ordering for both non-numeric and numeric sequences.
    """
    alpha_units = []  # Stores non-numeric units.
    num_units = []  # Stores numeric units.

    # Iterate over each unit_char in the incoming_string.
    for unit_char in incoming_string:
        if unit_char.isdigit():
            num_units.append(unit_char)
        else:
            alpha_units.append(unit_char)

    # Combine non-numeric units and numeric units.
    # Yields a new string.
    return "".join(alpha_units) + "".join(num_units)