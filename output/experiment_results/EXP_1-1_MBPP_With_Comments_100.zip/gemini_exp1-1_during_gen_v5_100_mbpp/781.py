import math

def count_divisors(an_input_num: int) -> bool:
    """
    Checks whether the count of positive divisors for an input number is even.

    A key mathematical property states:
    - A positive integer has an odd count of divisors if and only if it is a perfect square.
    - Consequently, a positive integer has an even count of divisors if and only if it is NOT a perfect square.

    This function leverages this property for an efficient check.

    Args:
        an_input_num: An integer value. It is assumed to be a positive integer
                      for standard divisor counting.

    Returns:
        True if the count of divisors is even, False otherwise.
        Returns False for non-positive inputs as their divisor counts
        are not typically defined as even/odd in this context.
    """
    if an_input_num <= 0:
        # Divisor count concepts typically apply to positive integers.
        # We assume non-positive inputs do not yield an even divisor count.
        return False

    # Calculate the integer square root of the number.
    # math.isqrt is a clean and accurate way to get the integer square root
    # available from Python 3.8+.
    an_int_sqrt = math.isqrt(an_input_num)

    # Check if the number is a perfect square.
    # If an_int_sqrt * an_int_sqrt equals an_input_num, it's a perfect square.
    is_a_perfect_square = (an_int_sqrt * an_int_sqrt == an_input_num)

    # We want to know if the count of divisors is even.
    # This happens when the number is NOT a perfect square.
    return not is_a_perfect_square