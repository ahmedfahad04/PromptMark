def square_nums(initial_values_collection: list) -> list:
    """
    Calculates the square of each numeric value in a given list.

    Args:
        initial_values_collection: A list of numeric values.

    Returns:
        A new list containing the squares of the input values.
    """
    # An output collection to store the squared numeric values.
    squares_output_collection = []

    # Iterate on each numeric value in the initial collection.
    for a_num_value in initial_values_collection:
        # Calculate its square and add it to the output collection.
        squares_output_collection.append(a_num_value * a_num_value)

    return squares_output_collection