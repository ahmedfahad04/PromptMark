def and_tuples(one_input_tuple_a: tuple, two_input_tuple_b: tuple) -> tuple:
    """
    Applies the elementwise bitwise AND operation on two input tuples.

    Args:
        one_input_tuple_a: A tuple of integers.
        two_input_tuple_b: A tuple of integers.

    Returns:
        A new tuple with the bitwise AND of corresponding elements.
    """
    # A list comprehension to apply bitwise AND ( '&' ) on each item.
    # Uses zip to unify iteration on both input tuples.
    output_union_tuple = tuple(a_item & i_item for a_item, i_item in zip(one_input_tuple_a, two_input_tuple_b))
    return output_union_tuple