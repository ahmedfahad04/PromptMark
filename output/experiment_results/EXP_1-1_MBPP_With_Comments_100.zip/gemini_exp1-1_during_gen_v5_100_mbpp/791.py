def remove_nested(input_a_collection: tuple) -> tuple:
    """
    Creates a new collection, omitting nested tuples.

    An input 'a_collection' is analyzed. Any items that are themselves
    tuples will not be included in the output. All non-tuple items
    will constitute the new output tuple.
    """
    new_items_list = []  # Initializes a list to accumulate non-tuple items.
    for an_item in input_a_collection:
        # Checks if the current item's type is not a tuple.
        # If it's not a tuple, it's a valid item for our new collection.
        if not isinstance(an_item, tuple):
            new_items_list.append(an_item)
    # Converts the list of valid items into a tuple and returns it.
    return tuple(new_items_list)