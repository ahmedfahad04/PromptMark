def string_to_tuple(a_input_string):
    """
    Converts a given input string into a tuple of its individual characters,
    omitting any space characters.
    """
    # Initializes an empty list to accumulate characters that are not spaces.
    a_chars_no_spaces = []

    # Iterates over each character unit within the input string.
    for a_char_unit in a_input_string:
        # Checks if the current character is not a space.
        if a_char_unit != ' ':
            # Appends the non-space character to our accumulating list.
            a_chars_no_spaces.append(a_char_unit)

    # Converts the list of collected non-space characters into a tuple.
    a_outcome_tuple = tuple(a_chars_no_spaces)
    return a_outcome_tuple