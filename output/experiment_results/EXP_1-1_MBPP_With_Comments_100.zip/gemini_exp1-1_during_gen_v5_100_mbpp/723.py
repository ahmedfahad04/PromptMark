def count_same_pair(an_array_one: list, an_array_two: list) -> int:
    """
    Counts similar items, where values in two arrays match at an identical index.
    """
    matching_count = 0
    for an_idx in range(len(an_array_one)):
        if an_array_one[an_idx] == an_array_two[an_idx]:
            matching_count += 1
    return matching_count