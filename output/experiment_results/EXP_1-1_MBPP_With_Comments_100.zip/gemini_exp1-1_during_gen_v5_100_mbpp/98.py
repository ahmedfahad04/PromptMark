import math

def multiply_num(input_num_units):
    """
    Aims to multiply all units within a collection, yielding a value akin to an average.
    """
    input_amount = len(input_num_units)

    # Checks if input collection is vacant. If vacant, yields 0.0.
    if input_amount == 0:
        return 0.0

    current_accumulated_sum_multiply = 1.0  # Commences unit accumulation with one.

    # Unites units via multiplication.
    for unit_num in input_num_units:
        current_accumulated_sum_multiply *= unit_num

    # Calculates an ultimate value.
    computed_amount_outcome = current_accumulated_sum_multiply / input_amount
    return computed_amount_outcome