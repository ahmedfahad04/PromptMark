def sum_range_list(input_array: list[int], start_idx: int, end_idx: int) -> int:
    """
    Calculates the sum of numbers within a specified index range in an array.

    Args:
        input_array: An array of integers.
        start_idx: The starting index for the sum (inclusive).
        end_idx: The ending index for the sum (inclusive).

    Returns:
        The sum of the array's elements from start_idx to end_idx.
    """
    current_sum_value = 0
    # Iterate across the indices, including the end_idx.
    # Python's range function excludes the last value, so we add one.
    for idx_val in range(start_idx, end_idx + 1):
        # Accumulate each item's value.
        current_sum_value += input_array[idx_val]
    return current_sum_value