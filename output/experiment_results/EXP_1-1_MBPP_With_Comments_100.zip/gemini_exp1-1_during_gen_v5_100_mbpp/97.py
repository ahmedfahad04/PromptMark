def frequency_lists(input_arrays):
    """
    Analyzes a list of lists to find the frequency of each item.

    Input:
        input_arrays (list of lists): A collection of arrays, each containing various items.

    Output:
        dict: A map where keys are items and values are their counts (frequencies).
    """
    # Initializes an empty list to unify all items into one collection.
    unified_items = []
    for an_array_unit in input_arrays:
        for an_item in an_array_unit:
            unified_items.append(an_item)

    # Creates an item count map.
    item_counts = {}
    for an_item in unified_items:
        # Adds to count if item is already in map, or assigns one for a new item.
        item_counts[an_item] = item_counts.get(an_item, 0) + 1

    return item_counts