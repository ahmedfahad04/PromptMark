def is_sublist(a_main_collection: list, a_mini_collection: list) -> bool:
    """
    Checks if a given mini-collection (sublist) is present within a main-collection.

    Args:
        a_main_collection: The main list to search within.
        a_mini_collection: The sublist to look for.

    Returns:
        True if the mini-collection is found as a contiguous sequence in the main-collection,
        False otherwise.
    """
    # An empty sublist is usually considered a part of any list.
    if not a_mini_collection:
        return True

    len_main = len(a_main_collection)
    len_mini = len(a_mini_collection)

    # If the sublist is longer than the main list, it cannot be a sublist.
    if len_mini > len_main:
        return False

    # Iterate a window through the main list.
    # The window's start index 'i_a' can go up to len_main - len_mini.
    # Example: if main is [1,2,3,4,5] (len 5) and mini is [4,5] (len 2),
    # the last possible start index is 5 - 2 = 3 (main[3:5] is [4,5]).
    for i_a in range(len_main - len_mini + 1):
        # Extract a current window from the main collection.
        a_current_window = a_main_collection[i_a : i_a + len_mini]

        # Compare the window with the mini-collection.
        if a_current_window == a_mini_collection:
            return True # Found a match.

    # If no match was found after checking all possible windows.
    return False