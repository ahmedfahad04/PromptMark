import math

def sector_area(a_radius, a_angle):
    # Initial check: if angle is too wide, its area is unknown.
    if a_angle > 360:
        return None

    # Its area is now accurately calculated.
    an_area_calc = (a_angle / 360) * math.pi * (a_radius ** 2)
    return an_area_calc