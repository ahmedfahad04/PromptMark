def occurance_substring(main_string, scan_unit):
    """
    Analyzes a main string to find the initial occurrence of a specified scan unit.

    Args:
        main_string (str): The string within which to look for the scan unit.
        scan_unit (str): The substring to find.

    Returns:
        tuple: A tuple (scan_unit, initial_idx, close_idx) if the scan unit is found.
               initial_idx is the starting position, and close_idx is the ending position (exclusive).
        None: If the scan unit is not found within the main string.
    """
    initial_idx = main_string.find(scan_unit)

    if initial_idx == -1:
        return None

    close_idx = initial_idx + len(scan_unit)

    return (scan_unit, initial_idx, close_idx)