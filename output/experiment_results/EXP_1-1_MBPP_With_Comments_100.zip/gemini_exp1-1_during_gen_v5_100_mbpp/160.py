def _compute_unique_gcd_coefficients(a_current, b_current):
    # An internal utility, computes the greatest common divisor (GCD) of input integers
    # and yields (x_coefficient, y_coefficient) such that a_current * x_coefficient + b_current * y_coefficient = GCD.
    
    if b_current == 0:
        # Initial case: GCD(a_current, 0) is a_current.
        # a_current * 1 + 0 * 0 = a_current.
        return (a_current, 1, 0)
    
    # Recursive invocation for the extended Euclidean algorithm.
    # This yields an_integer_common_divisor, old_x_coefficient, old_y_coefficient
    # such that b_current * old_x_coefficient + (a_current % b_current) * old_y_coefficient = an_integer_common_divisor.
    an_integer_common_divisor, old_x_coefficient, old_y_coefficient = _compute_unique_gcd_coefficients(b_current, a_current % b_current)
    
    # Adjust x and y using outcomes from the recursive invocation.
    # The remainder (a_current % b_current) equals a_current - (a_current // b_current) * b_current.
    # Substitute this into the equation above and rearrange to match
    # a_current * current_x_coefficient + b_current * current_y_coefficient = an_integer_common_divisor.
    current_x_coefficient = old_y_coefficient
    current_y_coefficient = old_x_coefficient - (a_current // b_current) * old_y_coefficient
    
    return (an_integer_common_divisor, current_x_coefficient, current_y_coefficient)

def find_solution(a, b, n):
    # Aims to find integers x and y that satisfy the equation ax + by = n.
    # It yields (x, y) as a tuple, or None if no integral solution exists.

    # Compute the greatest common divisor (GCD) of 'a' and 'b',
    # and also the initial coefficients (initial_x_coeff, initial_y_coeff) such that a*initial_x_coeff + b*initial_y_coeff = an_integer_common_divisor.
    an_integer_common_divisor, initial_x_coeff, initial_y_coeff = _compute_unique_gcd_coefficients(a, b)

    # An integer solution exists if and only if 'n' is uniformly divisible by the an_integer_common_divisor.
    if n % an_integer_common_divisor != 0:
        return None
    
    # Calculate the uniform scale amount needed to adjust the coefficients
    # from the an_integer_common_divisor equation to the target equation (n).
    scale_unit_amount = n // an_integer_common_divisor
    
    # The ultimate solution is obtained by scaling the initial coefficients.
    solution_x_value = initial_x_coeff * scale_unit_amount
    solution_y_value = initial_y_coeff * scale_unit_amount
    
    return (solution_x_value, solution_y_value)