def rotate_right(my_list: list, amount_cycles: int) -> list:
    # A check for an empty collection.
    if not my_list:
        return []

    collection_size = len(my_list)
    # Adjust amount_cycles if it is over the collection size.
    actual_cycles = amount_cycles % collection_size

    # The moving chunk comes from the end of the original list.
    moving_chunk = my_list[collection_size - actual_cycles:]
    # The initial chunk comes from the start of the original list.
    initial_chunk = my_list[:collection_size - actual_cycles]

    # Join the chunks to create the new collection.
    new_collection = moving_chunk + initial_chunk
    return new_collection