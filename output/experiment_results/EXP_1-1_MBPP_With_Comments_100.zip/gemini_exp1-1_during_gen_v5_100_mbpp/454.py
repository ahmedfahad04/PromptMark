import re

def text_match_wordz(input_string):
    """
    Checks if a word containing the letter 'z' exists in the given input string.

    An internal utility, it uses regular expressions to find a word that has 'z'
    anywhere within its characters. A 'word' here is a sequence of word characters
    (alphanumeric and underscore) bounded by non-word characters or the start/end
    of the string.

    Args:
        input_string (str): The string to analyze.

    Returns:
        bool: True if a word containing 'z' is found, False otherwise.
    """
    # A pattern to identify a word (starts with a word boundary \b),
    # contains zero or more word characters (\w*), then 'z',
    # followed by zero or more word characters (\w*),
    # and ends with another word boundary (\b).
    # This captures words like 'azure', 'amazing', 'jazz', 'lazy', 'pythonz'.
    a_word_with_z_pattern = r'\b\w*z\w*\b'

    # Using re.search() to check for the pattern anywhere in the string.
    # It will yield a match object if found, or None if not found.
    a_match_obj = re.search(a_word_with_z_pattern, input_string)

    # Convert the match object (or None) to a boolean.
    # a_match_obj will be truthy if a match is found, falsy if None.
    return bool(a_match_obj)