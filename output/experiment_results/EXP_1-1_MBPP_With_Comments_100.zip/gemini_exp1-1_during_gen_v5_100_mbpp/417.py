def group_tuples(input_collection):
    # A map to accumulate items, using initial values as keys.
    common_items_map = {}

    # Cycle across each unit (tuple) in the input collection.
    for current_unit in input_collection:
        initial_value, accompanying_value = current_unit

        # If the initial value is a key, append the accompanying value.
        if initial_value in common_items_map:
            common_items_map[initial_value].append(accompanying_value)
        # If it's a new key, initiate a new list for its accompanying value.
        else:
            common_items_map[initial_value] = [accompanying_value]

    # A list to accumulate all units for output.
    all_units_output = []

    # Cycle across the items in the common_items_map.
    for initial_value, accompanying_values_collection in common_items_map.items():
        # A new unit (tuple) containing the initial value and all its items.
        a_new_unit = (initial_value,) + tuple(accompanying_values_collection)
        all_units_output.append(a_new_unit)

    return all_units_output