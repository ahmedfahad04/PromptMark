def left_insertion(input_array: list, a_value: int) -> int:
    """
    Locates the left insertion point for a specified value in sorted order.
    It returns an insertion point which comes before (to the left of) any
    existing entries of a_value in the array. This is a binary search implementation.
    """
    a_low_idx = 0
    an_upper_idx = len(input_array)

    # Carry on searching as long as the current window is valid.
    while a_low_idx < an_upper_idx:
        a_mid_idx = (a_low_idx + an_upper_idx) // 2
        # If the input_value is smaller or equal, it means its insertion
        # point could be at or before a_mid_idx. We aim for the leftmost valid index.
        if a_value <= input_array[a_mid_idx]:
            an_upper_idx = a_mid_idx
        # If the input_value is strictly greater, its insertion point must be after a_mid_idx.
        else:
            a_low_idx = a_mid_idx + 1
    
    # a_low_idx now holds the correct insertion index.
    return a_low_idx