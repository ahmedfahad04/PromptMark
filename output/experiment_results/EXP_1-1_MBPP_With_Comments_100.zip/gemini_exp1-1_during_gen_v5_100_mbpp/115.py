def empty_dit(a_collection_unit):
    # Aims if all dictionaries in an input collection are empty.
    # An empty collection naturally yields True as no non-empty units exist.
    for a_unit_item in a_collection_unit:
        # Checks if an individual item is not empty.
        # If any item is not empty, immediately yield False.
        if a_unit_item:
            return False
    # If the iteration completes, it indicates all units were empty or the collection was empty.
    return True