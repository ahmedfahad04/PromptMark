def rectangle_area(width_unit, y_unit):
    # Calculates an area of a common rectangle.
    # It is width multiplied by height.
    area_value = width_unit * y_unit
    return area_value