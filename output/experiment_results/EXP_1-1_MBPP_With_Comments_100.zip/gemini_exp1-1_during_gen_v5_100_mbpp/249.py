def intersection_array(input_array_initial, input_array_another):
    """
    Finds the common items (intersection) between two input arrays.

    Args:
        input_array_initial (list): The initial array of items.
        input_array_another (list): The another array of items.

    Returns:
        list: A sorted list containing items common to both arrays.
    """
    # Creates a unique collection of items from the initial array.
    initial_array_unique_items = set(input_array_initial)

    # Creates a unique collection of items from the another array.
    another_array_unique_items = set(input_array_another)

    # Computes the collection of items common to both unique collections.
    common_items_collection = initial_array_unique_items.intersection(another_array_unique_items)

    # Converts the common items collection into a sorted list,
    # ensuring consistent output order as shown in test cases.
    common_items_array = sorted(list(common_items_collection))

    return common_items_array