def snake_to_camel(incoming_snake_value: str) -> str:
    # Cuts an incoming value into units.
    snake_units = incoming_snake_value.split('_')

    # Capitalizes the initial character of each unit.
    a_camel_units = [unit.capitalize() for unit in snake_units]

    # Unites all capitalized units into a single camel case string.
    camel_output_value = "".join(a_camel_units)

    return camel_output_value