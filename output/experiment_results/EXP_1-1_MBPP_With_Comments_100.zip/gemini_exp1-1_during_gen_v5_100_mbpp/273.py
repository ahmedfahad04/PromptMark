def substract_elements(input_main, input_auxiliary):
    """
    Subtracts elements of the second tuple from the first tuple at corresponding indices.

    Args:
        input_main (tuple): The initial tuple.
        input_auxiliary (tuple): The tuple whose elements will be subtracted.

    Returns:
        tuple: A new tuple with the results of the subtraction.
    """
    # Initializes an outcome collection.
    my_outcome_values = []

    # Walks jointly input units.
    for unit_main, unit_auxiliary in zip(input_main, input_auxiliary):
        an_unit_outcome = unit_main - unit_auxiliary
        my_outcome_values.append(an_unit_outcome)

    # Converts collection to a tuple.
    return tuple(my_outcome_values)