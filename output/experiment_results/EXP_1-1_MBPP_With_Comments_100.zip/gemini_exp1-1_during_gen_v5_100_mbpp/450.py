def extract_string(input_array_of_strings: list[str], any_string_size: int) -> list[str]:
    """
    Aims to extract strings of a specified size from an input list of strings.

    Args:
        input_array_of_strings: A list of string values.
        any_string_size: An integer indicating the desired length of strings to collect.

    Returns:
        A new list containing only strings whose length matches 'any_string_size'.
    """
    any_output_collection = [] # Initializes an empty list to amass matching strings.

    for current_item_string in input_array_of_strings:
        # Checks if the current string's actual length is as input string size.
        if len(current_item_string) == any_string_size:
            any_output_collection.append(current_item_string) # Includes the string if lengths match.

    return any_output_collection