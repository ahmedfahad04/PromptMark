def replace_char(source_string, old_char_val, new_char_val):
    # output_chars_collection is a list used to accumulate characters for the new string.
    # Utilizing a list for char collection and then joining is a common and usually
    # an efficient approach for string manipulations involving multiple changes.
    output_chars_collection = []

    # Iterate over each char unit in the initial string.
    for a_char_unit in source_string:
        # Check if this current char unit is what we aim to swap out.
        if a_char_unit == old_char_val:
            # If a match, add the new char value into our collection.
            output_chars_collection.append(new_char_val)
        else:
            # If no match, just add the original char unit.
            output_chars_collection.append(a_char_unit)

    # Join all the collected chars to form the final string.
    # A single string join operation is usually very quick.
    return "".join(output_chars_collection)