def capital_words_spaces(input_string_a: str) -> str:
    """
    Inserts spaces between words that start with capital letters in a given string.

    Args:
        input_string_a: The original string.

    Returns:
        A new string with spaces inserted as needed.
    """
    # `chars_list_a` accumulates characters and new spaces.
    chars_list_a = []
    # `string_idx_a` is an index for iterating through the input string.
    string_idx_a = 0
    # `max_idx_a` stores the upper limit for string iteration.
    max_idx_a = len(input_string_a)

    while string_idx_a < max_idx_a:
        current_char_a = input_string_a[string_idx_a]
        
        # If the current character is an uppercase letter and it's not the very first character,
        # a space is added before it.
        if current_char_a.isupper() and string_idx_a > 0:
            chars_list_a.append(' ')
        
        chars_list_a.append(current_char_a)
        string_idx_a += 1

    # Joins all collected characters into a final string.
    output_string_a = "".join(chars_list_a)
    return output_string_a