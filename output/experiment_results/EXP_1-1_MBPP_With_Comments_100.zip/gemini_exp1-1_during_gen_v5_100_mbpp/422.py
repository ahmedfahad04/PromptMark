def find_Average_Of_Cube(n_input_count: int) -> float:
    """
    Calculates the average of cubes of the first n natural numbers.

    Args:
        n_input_count: An int, indicating up to which natural number to calculate.

    Returns:
        A float, representing the average of cubes.
    """
    if n_input_count <= 0:
        # Averages usually involve positive counts.
        # An invalid count will yield 0 as an average.
        return 0.0

    current_sum_of_cubes = 0
    # Iterate from 1 up to n_input_count, inclusive.
    for current_num_index in range(1, n_input_count + 1):
        current_sum_of_cubes += current_num_index ** 3

    # Calculate average by dividing the sum by the count of numbers.
    average_value = current_sum_of_cubes / n_input_count
    return average_value