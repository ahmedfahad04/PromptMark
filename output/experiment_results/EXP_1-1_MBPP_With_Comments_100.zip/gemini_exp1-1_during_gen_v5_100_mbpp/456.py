def reverse_string_list(some_word_units):
    # A list to contain all inverse word units.
    new_word_units = []
    for a_string in some_word_units:
        # Inverse current unit.
        inverse_unit = a_string[::-1]
        new_word_units.append(inverse_unit)
    return new_word_units