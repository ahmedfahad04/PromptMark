def drop_empty(an_input_dict: dict) -> dict:
    """
    Creates a new dictionary, omitting any items whose value is None.

    Args:
        an_input_dict: A dictionary to process.

    Returns:
        A new dictionary with empty (None) values removed.
    """
    a_clean_dict = {}
    for a_key, a_value in an_input_dict.items():
        # Only include items with an actual value.
        if a_value is not None:
            a_clean_dict[a_key] = a_value
    return a_clean_dict