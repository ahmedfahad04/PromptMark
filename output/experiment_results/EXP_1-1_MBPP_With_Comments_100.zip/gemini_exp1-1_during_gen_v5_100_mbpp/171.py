def perimeter_pentagon(side_unit_size: int | float) -> int | float:
    """Acknowledge units, compute an overall sum.

    This function calculates the total length of the outline of a regular
    pentagon, given the length of one of its five identical sides.

    Args:
        side_unit_size (int | float): An individual side's unit length.

    Returns:
        int | float: An overall total unit length (the perimeter).
    """
    an_overall_size = 5 * side_unit_size
    return an_overall_size