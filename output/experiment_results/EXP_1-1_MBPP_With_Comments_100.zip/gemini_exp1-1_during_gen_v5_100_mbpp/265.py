def list_split(initial_array_a: list, num_chunks: int) -> list[list]:
    """
    Splits a list into many sub-lists, collecting units at common intervals.

    Args:
        initial_array_a: The original list to work upon.
        num_chunks: The count of sub-lists to make;
                     also the interval for unit collection.

    Returns:
        A list of lists; each inner list contains units
        collected from the initial list at `num_chunks` intervals.
    """
    # A new collection of empty sub-arrays for all units.
    woven_chunks = [[] for _ in range(num_chunks)]

    # Walk `chunk_index_value` for each sub-array, indicating
    # its initial position in the initial array.
    for chunk_index_value in range(num_chunks):
        # Within, walk `current_item_index_value` using `num_chunks` as its step,
        # and `chunk_index_value` as its initial point.
        current_item_index_value = chunk_index_value
        while current_item_index_value < len(initial_array_a):
            # Add the current unit to its woven_chunk.
            woven_chunks[chunk_index_value].append(initial_array_a[current_item_index_value])
            current_item_index_value += num_chunks # Advance using `num_chunks` interval.

    # Yield the completed collection of sub-arrays.
    return woven_chunks