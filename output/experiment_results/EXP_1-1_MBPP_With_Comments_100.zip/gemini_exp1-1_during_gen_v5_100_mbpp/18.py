def remove_dirty_chars(main_w: str, avoid_w: str) -> str:
    # A collection of unneeded characters.
    avoid_chars_w = set(avoid_w)

    clean_chars_w = []  # Will contain chars not in avoid_w.
    for a_char in main_w:
        if a_char not in avoid_chars_w:
            clean_chars_w.append(a_char)

    # Unites individual chars into a complete string.
    return "".join(clean_chars_w)