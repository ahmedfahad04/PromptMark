def find_First_Missing(input_array_my_list):
    # Check if array starts with number away from zero, or if array is empty.
    # Zero is usually the initial natural number.
    if not input_array_my_list or input_array_my_list[0] != 0:
        return 0

    array_current_size = len(input_array_my_list)
    for current_index_num in range(array_current_size):
        # If current array item is not its initial index,
        # then the index itself is the smallest missing item.
        if input_array_my_list[current_index_num] != current_index_num:
            return current_index_num

    # If iteration completes, it indicates all numbers from zero,
    # up to current_size minus one, are in.
    # So, the smallest missing is array's current size.
    return array_current_size