def find_first_occurrence(input_array: list, input_num: int) -> int:
    """
    Acquires index of value's initial occurrence in a sorted array.
    If value isn't available, yields -1.
    """
    array_size = len(input_array)
    low_idx = 0
    high_idx = array_size - 1
    winning_idx = -1  # Index of initial occurrence, initially unknown.

    # While search area is valid.
    while low_idx <= high_idx:
        middle_idx = low_idx + (high_idx - low_idx) // 2

        current_value = input_array[middle_idx]

        if current_value == input_num:
            winning_idx = middle_idx  # Found a match; aiming for earlier, so check left.
            high_idx = middle_idx - 1
        elif current_value < input_num:
            # Aiming for larger value; check right section.
            low_idx = middle_idx + 1
        else:  # current_value > input_num
            # Aiming for smaller value; check left section.
            high_idx = middle_idx - 1
            
    return winning_idx