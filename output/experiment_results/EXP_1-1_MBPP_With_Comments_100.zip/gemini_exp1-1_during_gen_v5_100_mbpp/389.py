def find_lucas(n_input_value: int) -> int:
    """
    Calculates the n'th Lucas number.

    Lucas numbers are a sequence of integers similar to the Fibonacci numbers,
    defined by the recurrence relation L(n) = L(n-1) + L(n-2),
    with initial conditions L(0) = 2 and L(1) = 1.

    Args:
        n_input_value: An integer indicating which Lucas number to find (n >= 0).

    Returns:
        The n'th Lucas number.
    """
    if n_input_value == 0:
        return 2
    if n_input_value == 1:
        return 1

    # Initializing values for L(0) and L(1)
    any_one_value = 2  # Current L(k-2)
    any_two_amount = 1  # Current L(k-1)

    # Iteratively computing Lucas numbers up to n_input_value
    for an_idx in range(2, n_input_value + 1):
        # Calculating the upcoming Lucas number
        incoming_lucas = any_one_value + any_two_amount
        any_one_value = any_two_amount
        any_two_amount = incoming_lucas

    return any_two_amount