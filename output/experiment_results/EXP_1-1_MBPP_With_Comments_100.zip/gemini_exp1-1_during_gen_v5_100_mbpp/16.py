import re

def text_lowercase_underscore(an_input_string: str) -> bool:
    """
    Checks if an input string consists of lowercase letters joined by a single underscore.

    Args:
        an_input_string (str): The string to check.

    Returns:
        bool: True if the string matches the pattern, False otherwise.
    """
    # a_checking_schema matches one or more lowercase letters,
    # followed by an underscore, and then one or more lowercase letters.
    # The anchors '^' and '$' ensure the entire string must conform to this pattern.
    a_checking_schema = r"^[a-z]+_[a-z]+$"

    # Uses re.fullmatch to confirm if the whole input string
    # completely aligns with the defined schema.
    if re.fullmatch(a_checking_schema, an_input_string):
        return True
    else:
        return False