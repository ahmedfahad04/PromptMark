def odd_num_sum(n: int) -> int:
    """
    Calculates the sum of the fourth power of the first n odd natural numbers.

    An odd natural number is a positive whole number not divisible by two
    (e.g., 1, 3, 5, ...).
    This function computes (1^4 + 3^4 + 5^4 + ... + (2n-1)^4).

    Args:
        n: A positive integer, indicating how many odd numbers to include.

    Returns:
        The sum of the fourth powers of the first n odd natural numbers.
    """
    an_overall_sum = 0  # Initializing a sum accumulator.

    # We want to iterate n times to get the first n odd numbers.
    # For an_index = 0, we get the 1st odd number (1).
    # For an_index = 1, we get the 2nd odd number (3), and so on.
    for an_index in range(n):
        a_current_odd = 2 * an_index + 1  # Computing the current odd number.
        an_overall_sum += a_current_odd ** 4  # Accumulating its fourth power.

    return an_overall_sum