def insert_element(a_source_list: list, an_insert_unit: any) -> list:
    """
    Inserts a given unit (element) into a list, placing it just before each
    original unit (element) in the list.

    Args:
        a_source_list: An incoming collection (list) of units.
        an_insert_unit: The unit (element) to insert.

    Returns:
        A new collection (list) with the unit inserted as specified.
    """
    a_yield_list = []  # A new list for output units.
    for a_current_unit in a_source_list:
        a_yield_list.append(an_insert_unit)
        a_yield_list.append(a_current_unit)
    return a_yield_list