import math

def otherside_rightangle(one_side, another_side):
    """
    Calculates the length of the hypotenuse of a right-angled triangle,
    assuming the two input sides are the lengths of the two legs.
    
    Args:
        one_side (float or int): The length of one leg of the triangle.
        another_side (float or int): The length of the other leg of the triangle.
        
    Returns:
        float: The length of the hypotenuse.
    """
    # Sum the squares of the two input legs.
    sum_of_squares = one_side**2 + another_side**2
    
    # The hypotenuse is the square root of the sum of squares (Pythagorean theorem).
    hypotenuse_value = math.sqrt(sum_of_squares)
    
    return hypotenuse_value