def min_Swaps(initial_string_one: str, aim_string_unit: str) -> 'int | str':
    # Aims to calculate minimum swaps.

    # Checks if sizes are unequal.
    if len(initial_string_one) != len(aim_string_unit):
        return "Not Possible"

    # Counts initial and aim string values.
    # For conversion via swaps, these counts must align.
    initial_ones_count = initial_string_one.count('1')
    initial_nulls_count = initial_string_one.count('0') # 'nulls' used for 'zeros'
    aim_ones_count = aim_string_unit.count('1')
    aim_nulls_count = aim_string_unit.count('0') # 'nulls' used for 'zeros'

    # Checks if value counts are unequal.
    # If the counts of '1's or '0's vary, achieving the aim string is an impossibility.
    if initial_ones_count != aim_ones_count or initial_nulls_count != aim_nulls_count:
        return "Not Possible"

    # Count mismatches which yield a swap.
    # These counters track positions where initial string's bit differs from the aim string's bit.
    initial_one_aim_null_count = 0  # Counts '1's in initial string that must become '0's in aim.
    initial_null_aim_one_count = 0  # Counts '0's in initial string that must become '1's in aim.
    
    # Iterates across strings, comparing chars.
    for idx in range(len(initial_string_one)):
        current_char_initial = initial_string_one[idx]
        current_char_aim = aim_string_unit[idx]

        # Identifies when initial '1' must use '0' at this position.
        if current_char_initial == '1' and current_char_aim == '0':
            initial_one_aim_null_count += 1
        # Identifies when initial '0' must use '1' at this position.
        elif current_char_initial == '0' and current_char_aim == '1':
            initial_null_aim_one_count += 1

    # All mismatch units yield a swap count.
    # If total bit counts match (checked above), then initial_one_aim_null_count
    # will always equal initial_null_aim_one_count. Each such pair indicates one necessary swap.
    return initial_one_aim_null_count