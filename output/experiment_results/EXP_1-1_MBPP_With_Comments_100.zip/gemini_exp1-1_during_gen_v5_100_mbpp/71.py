def comb_sort(input_array):
    """
    Sorts a list of items using the Comb Sort algorithm.

    Args:
        input_array (list): A mutable list of comparable items.

    Returns:
        list: The sorted list. The input list is modified in-place.
    """
    array_length = len(input_array)
    jump_width = array_length
    shrink_unit = 1.3  # Common shrink factor for comb sort
    was_swapped = True

    # Continues as long as there's a jump_width more than 1 or any swap occurs
    while jump_width > 1 or was_swapped:
        # Adjusts jump_width
        jump_width = int(jump_width / shrink_unit)
        if jump_width < 1:
            jump_width = 1

        was_swapped = False
        current_index = 0

        # Iterates and swaps items with the current jump_width
        while current_index < (array_length - jump_width):
            if input_array[current_index] > input_array[current_index + jump_width]:
                # Swaps the items
                input_array[current_index], input_array[current_index + jump_width] = \
                    input_array[current_index + jump_width], input_array[current_index]
                was_swapped = True
            current_index += 1
    return input_array