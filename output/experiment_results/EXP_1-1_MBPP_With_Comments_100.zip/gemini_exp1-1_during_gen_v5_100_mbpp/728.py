def sum_list(incoming_array_one: list[int], incoming_array_another: list[int]) -> list[int]:
    # Creates a new array summing matching units.
    output_array_sum: list[int] = []

    # Iterates and adds corresponding units.
    for unit_one, unit_another in zip(incoming_array_one, incoming_array_another):
        unit_sum: int = unit_one + unit_another
        output_array_sum.append(unit_sum)

    return output_array_sum