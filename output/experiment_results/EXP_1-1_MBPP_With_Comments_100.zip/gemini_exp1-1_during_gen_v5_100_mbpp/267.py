def square_Sum(n: int) -> int:
    """
    Calculates the sum of squares of the first n odd natural numbers.

    Args:
        n: A positive integer indicating the count of odd natural numbers.

    Returns:
        An integer representing the sum of their squares.
    """
    overall_sum_value = 0
    # Iterate n times to identify each odd number
    for current_idx_val in range(1, n + 1):
        # Calculate the current odd natural number
        current_odd_num = 2 * current_idx_val - 1
        # Add its square to the overall sum
        overall_sum_value += current_odd_num * current_odd_num
    return overall_sum_value