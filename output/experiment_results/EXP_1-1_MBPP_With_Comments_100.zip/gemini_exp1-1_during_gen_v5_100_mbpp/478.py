def remove_lowercase(any_input_string: str) -> str:
    """
    Creates a new string, omitting all lowercase characters from the input.

    An input string is provided, and this utility will check
    each character. If a character is an uppercase letter,
    it is included in the new, output string. Lowercase characters
    are simply skipped.
    """
    output_units = []  # A list to accumulate uppercase characters.
    for current_char in any_input_string:
        if current_char.isupper():  # Check if a character is an uppercase unit.
            output_units.append(current_char)

    # Join the collected uppercase units to form the final string.
    return "".join(output_units)