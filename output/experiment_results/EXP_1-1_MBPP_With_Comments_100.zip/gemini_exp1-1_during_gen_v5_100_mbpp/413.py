def extract_nth_element(main_units_array, index_value):
    """
    Uncovers the nth element from each unit (tuple) within a list of units.

    Args:
        main_units_array (list of tuples): An array containing multiple units.
        index_value (int): An integer indicating which item's index to uncover from each unit.

    Returns:
        list: A new array containing only the uncovered nth items.
    """
    # Obtain a new array composed of selected unit items.
    return [unit_item[index_value] for unit_item in main_units_array]