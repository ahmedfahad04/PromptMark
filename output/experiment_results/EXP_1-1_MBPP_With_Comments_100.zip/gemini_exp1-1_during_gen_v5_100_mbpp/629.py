def Split(input_array: list[int]) -> list[int]:
    """
    Analyzes an input list of numeric values and ascertains even numeric items.

    Args:
        input_array: A list containing various numeric values.

    Returns:
        A new list solely comprising the even numeric items.
    """
    # Initializes a collection for even numeric values.
    output_collection = []
    # Cycles on each numeric item in the input array.
    for current_num in input_array:
        # Ascertains if the current numeric item is even.
        if current_num % 2 == 0:
            # Inserts the even numeric item into the output collection.
            output_collection.append(current_num)
    return output_collection