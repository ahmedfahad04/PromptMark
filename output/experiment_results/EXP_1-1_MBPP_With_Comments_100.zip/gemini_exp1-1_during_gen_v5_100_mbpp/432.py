def median_trapezium(one_way_side: float, another_way_side: float, any_unneeded_side: float) -> float:
    """
    A way to compute the median length of a trapezium.
    This value is the average of its two parallel sides.
    """
    # Compute median value via two parallel sides.
    average_sum_of_sides = (one_way_side + another_way_side) / 2
    return average_sum_of_sides