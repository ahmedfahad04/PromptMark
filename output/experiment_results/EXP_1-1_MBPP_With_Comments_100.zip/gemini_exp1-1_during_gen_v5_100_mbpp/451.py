def remove_whitespaces(input_string_val: str) -> str:
    """
    Acquires a string and yields a new one without any whitespace characters.
    It splits the string using any sequence of whitespaces as a delimiter,
    then joins the resulting units back into a single string.
    """
    # An easy way to unify space-separated words.
    # It initially splits by any whitespace, then joins without any.
    an_array_of_units = input_string_val.split()
    new_string_val = "".join(an_array_of_units)
    return new_string_val