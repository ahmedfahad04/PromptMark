def new_tuple(an_input_array: list, a_unit_string: str) -> tuple:
    """
    Aims joining an array and a unit string.
    """
    an_outcome_unit = (*an_input_array, a_unit_string)
    return an_outcome_unit