def swap_List(a_list: list) -> list:
    """
    Interchanges the initial and final elements within a given list.

    Args:
        a_list: A list of values.

    Returns:
        The list with its initial and final elements swapped.
        If the list has fewer than two values, it returns the original list unchanged.
    """
    # A list with an initial value and a final value is necessary for swapping.
    if len(a_list) < 2:
        return a_list

    # Swapping initial and final values using Python's simultaneous assignment.
    a_list[0], a_list[-1] = a_list[-1], a_list[0]

    return a_list