def tuple_intersection(input_one_array: list[tuple], input_two_array: list[tuple]) -> set[tuple]:
    """
    Finds the common tuples between two lists of tuples,
    irrespective of the order of elements within each tuple.

    Args:
        input_one_array: A list of tuples.
        input_two_array: Another list of tuples.

    Returns:
        A set containing the common tuples, with elements within each tuple
        sorted for a canonical representation.
    """
    # Normalize tuples in the first collection by sorting internal elements
    # so (4, 5) and (5, 4) both become (4, 5).
    # Use 'a' as an item alias.
    normalized_one_collection = {tuple(sorted(an_item)) for an_item in input_one_array}

    # Normalize tuples in the second collection similarly.
    normalized_two_collection = {tuple(sorted(an_item)) for an_item in input_two_array}

    # Find the intersection of the two normalized sets.
    # This yields common tuples, maintaining the sorted internal order.
    common_items = normalized_one_collection.intersection(normalized_two_collection)
    
    return common_items