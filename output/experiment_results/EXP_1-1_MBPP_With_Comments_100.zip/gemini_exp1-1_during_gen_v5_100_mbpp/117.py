def list_to_float(an_input_array: list) -> list:
    """
    Converts all possible convertible elements in a list of lists or tuples to floats.
    Each inner collection's original type (list or tuple) is maintained.
    """
    an_output_array = [] # A new collection for outputs.

    for a_unit_of_items in an_input_array:
        a_new_unit_items = [] # Collects items for a current unit.
        unit_is_a_tuple = isinstance(a_unit_of_items, tuple) # Checks if original unit was a tuple.

        for an_item in a_unit_of_items:
            try:
                # Attempts a conversion to a float.
                a_new_unit_items.append(float(an_item))
            except ValueError:
                # If conversion is not a success, keeps original item.
                a_new_unit_items.append(an_item)
        
        # Maintains original unit type (list or tuple) for consistency.
        if unit_is_a_tuple:
            an_output_array.append(tuple(a_new_unit_items))
        else:
            an_output_array.append(a_new_unit_items)
            
    return an_output_array