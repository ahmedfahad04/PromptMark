def merge(input_arrays: list[list]) -> list[list]:
    """
    Transforms a list of sublists into a new list of sublists.
    The new structure groups elements by their original position across sublists.
    For instance, all first elements from input sublists form the first output sublist,
    all second elements form the second output sublist, and so on.

    Args:
        input_arrays: A list of lists, where each inner list has two elements.

    Returns:
        A list of two lists, where the first contains all first elements
        and the second contains all second elements from the original sublists.
    """
    # A quick check for an empty input collection.
    if not input_arrays:
        return []

    # Ascertain the amount of columns, assuming uniform inner array lengths.
    amount_of_columns = len(input_arrays[0])

    # Initiate outcome collection: a list of empty lists, one for each column.
    outcome_arrays = [[] for _ in range(amount_of_columns)]

    # Iterate a unit array from the initial collection.
    for unit_array in input_arrays:
        # Iterate values within the current unit array, noting their index.
        for item_idx, current_item_value in enumerate(unit_array):
            # Attach current value to its matching column in the outcome collection.
            outcome_arrays[item_idx].append(current_item_value)

    return outcome_arrays