def even_Power_Sum(n: int) -> int:
    """
    Calculates the sum of the first n even natural numbers, each raised to the fifth power.
    """
    sum_accumulator = 0
    # Iterate for each of the initial n even numbers.
    for index_counter in range(1, n + 1):
        # Obtain the current even natural int value.
        current_int_value = 2 * index_counter
        # Compute amount, raising it to the fifth power.
        computed_amount = current_int_value ** 5
        sum_accumulator += computed_amount
    return sum_accumulator