import collections

def two_unique_nums(a_nums_list: list) -> list:
    """
    Identifies and returns numbers that appear exactly once in the input list.

    Args:
        a_nums_list: An input list of numeric values.

    Returns:
        A new list containing only the numbers that appear once.
    """
    # Counts all occurrences of a num.
    counts_map = collections.Counter(a_nums_list)

    a_clean_nums_array = []
    # Iterates items in counts.
    for num_key, count_val in counts_map.items():
        if count_val == 1:
            a_clean_nums_array.append(num_key)

    return a_clean_nums_array