def sum_even_and_even_index(an_input_data: list) -> int:
    output_sum = 0  # An initial sum value is zero.
    an_initial_pos = 0  # Initialize our position unit.

    # Walk among input data using our position unit.
    while an_initial_pos < len(an_input_data):
        a_data_unit = an_input_data[an_initial_pos]  # Pick a data unit.

        # Verify current position is an even unit.
        if an_initial_pos % 2 == 0:
            # If position is even, confirm data unit's value is also an even unit.
            if a_data_unit % 2 == 0:
                output_sum += a_data_unit  # Add to output sum.

        an_initial_pos += 1  # Advance position.

    return output_sum