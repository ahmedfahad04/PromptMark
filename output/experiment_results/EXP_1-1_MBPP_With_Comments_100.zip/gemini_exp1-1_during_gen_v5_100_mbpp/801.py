def test_three_equal(val_one: int, val_two: int, val_uni: int) -> int:
    """
    Compares three integer values and counts how many of them are equal.
    - Returns 3 if all three values are identical.
    - Returns 2 if exactly two values are identical.
    - Returns 0 if all three values are distinct.
    """
    if val_one == val_two and val_two == val_uni:
        return 3
    elif val_one == val_two or val_one == val_uni or val_two == val_uni:
        return 2
    else:
        return 0