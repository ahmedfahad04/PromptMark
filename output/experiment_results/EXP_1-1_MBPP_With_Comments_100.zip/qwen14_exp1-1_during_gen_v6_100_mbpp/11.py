def remove_Occ(s, char):
    # Find the first occurrence of the character
    first_occ = s.find(char)
    
    # Find the last occurrence of the character
    last_occ = s.rfind(char)
    
    # If the character is found at least twice, remove the occurrences
    if first_occ != -1 and last_occ != -1 and first_occ != last_occ:
        return s[:first_occ] + s[first_occ+1:last_occ] + s[last_occ+1:]
    else:
        # If the character is not found or found only once, return the original string
        return s