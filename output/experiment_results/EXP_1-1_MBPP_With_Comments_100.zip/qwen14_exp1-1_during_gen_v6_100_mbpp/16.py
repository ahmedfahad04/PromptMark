def text_lowercase_underscore(s):
    # Check if the string starts with a lowercase letter or underscore
    if not s[0].islower() and s[0] != '_':
        return False
    
    # Iterate through the string to check each character
    for i in range(1, len(s)):
        if s[i].isupper() and s[i-1] != '_':
            return False
        elif s[i].islower():
            continue
        elif s[i].isdigit():
            return False
        elif s[i] == '_' and (i-1 >= 0 and s[i-1].islower()):
            continue
        else:
            return False
    
    return True