def empty_dit(list_of_dicts):
    # Check if all dictionaries in the list are empty
    return all(not d for d in list_of_dicts)