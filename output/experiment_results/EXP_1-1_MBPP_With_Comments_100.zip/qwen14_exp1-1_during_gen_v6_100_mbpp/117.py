def list_to_float(lst):
    result = []
    for sublist in lst:
        new_sublist = []
        for item in sublist:
            try:
                new_sublist.append(float(item))
            except ValueError:
                new_sublist.append(item)
        result.append(tuple(new_sublist))
    return result