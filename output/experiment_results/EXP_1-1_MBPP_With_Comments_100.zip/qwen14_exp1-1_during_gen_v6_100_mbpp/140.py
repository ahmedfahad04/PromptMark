def extract_singly(nested_lists):
    # Initialize an empty set to store the flattened elements
    flattened_set = set()
    
    # Iterate through each sublist in the nested list
    for sublist in nested_lists:
        # Update the set with all elements from the current sublist
        flattened_set.update(sublist)
    
    return flattened_set