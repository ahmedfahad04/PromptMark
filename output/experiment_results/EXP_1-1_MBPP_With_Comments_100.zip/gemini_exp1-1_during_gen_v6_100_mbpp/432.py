def median_trapezium(side_one, side_any, any_value):
    # Works out median value.
    # The median length of a trapezium is the average of its two parallel sides.
    # The third argument (any_value) is not used in this calculation.
    median_val = (side_one + side_any) / 2
    return median_val