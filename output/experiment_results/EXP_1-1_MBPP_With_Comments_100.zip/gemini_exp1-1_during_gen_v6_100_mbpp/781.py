def count_divisors(my_num: int) -> bool:
    """
    Checks if the count of divisors of a given positive integer is an even number.

    A positive integer has an even count of divisors unless it is a perfect square.
    This function counts divisors efficiently by only iterating up to the square root
    of the input number.

    Args:
        my_num: An integer for which to check the divisor count.

    Returns:
        True if the number of divisors is even, False otherwise.
    """
    count_of_divs = 0
    # We only check up to the square root of my_num.
    # If 'i_val' is a divisor, 'my_num // i_val' is also a divisor.
    # We must account for cases where 'i_val * i_val == my_num' (perfect square).
    i_val = 1
    while i_val * i_val <= my_num:
        if my_num % i_val == 0:
            if i_val * i_val == my_num:
                # 'i_val' is the square root, so it's a single divisor.
                count_of_divs += 1
            else:
                # 'i_val' and 'my_num // i_val' are two distinct divisors.
                count_of_divs += 2
        i_val += 1
    return count_of_divs % 2 == 0