def snake_to_camel(snake_value: str) -> str:
    # Split input string (snake_value) into units.
    word_units = snake_value.split('_')
    camel_units = []
    for unit_item in word_units:
        # Use valid units only.
        if unit_item:
            camel_units.append(unit_item.capitalize())
    # Join units to make a new camel string.
    new_camel_string = "".join(camel_units)
    return new_camel_string