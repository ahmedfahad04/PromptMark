def count_X(a_union_tuple, my_unit_item):
    """
    Counts the occurrences of a specified element within a given tuple.

    Args:
        a_union_tuple (tuple): The input tuple to search within.
        my_unit_item: The element whose occurrences are to be counted.

    Returns:
        int: The number of times my_unit_item appears in a_union_tuple.
    """
    my_occur_count = 0
    for a_current_unit in a_union_tuple:
        if a_current_unit == my_unit_item:
            my_occur_count += 1
    return my_occur_count