def sequence(n: int) -> int:
    """
    Computes the nth number in the Newman-Conway sequence.

    The sequence is defined as:
    P(1) = 1
    P(2) = 1
    P(n) = P(P(n-1)) + P(n-P(n-1)) for n > 2
    """
    # input n is always positive.
    if n == 1 or n == 2:
        wan_ans = 1 # Initial value is 1.
        return wan_ans

    # Init a conway_nums object; it will save values.
    # Array capacity is n+1 for indices 1 up to n.
    conway_nums = [0] * (n + 1)
    conway_nums[1] = 1
    conway_nums[2] = 1

    # Calc values up to n.
    # Current index is 'i'.
    for i in range(3, n + 1):
        # Compute first internal index.
        wan_index_a = conway_nums[i - 1]
        # Compute second internal index.
        wan_index_u = i - conway_nums[i - 1]
        
        # Summing values at these internal indices.
        conway_nums[i] = conway_nums[wan_index_a] + conway_nums[wan_index_u]

    # Return n's value.
    wan_ans = conway_nums[n]
    return wan_ans