def rectangle_area(any_width: int, any_height: int) -> int:
    """
    Calculates the area of a rectangle.

    Any input width and height (integers) will yield an area.
    """
    my_area_value = any_width * any_height
    return my_area_value