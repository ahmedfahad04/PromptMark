def my_extended_gcd(input_a_value, input_b_value):
    """
    This yields a common divisor, x, y, so input_a_value*x + input_b_value*y = common_divisor_value.
    It works for non-negative input_a_value, input_b_value.
    """
    if input_a_value == 0:
        return input_b_value, 0, 1

    common_divisor_value, x_one_value, y_one_value = my_extended_gcd(input_b_value % input_a_value, input_a_value)

    current_x_value = y_one_value - (input_b_value // input_a_value) * x_one_value
    current_y_value = x_one_value

    return common_divisor_value, current_x_value, current_y_value

def find_solution(initial_a_value, initial_b_value, input_num):
    # Using absolute values for the Extended Euclidean Algorithm. Outcome signs adjust later.
    working_a_value = abs(initial_a_value)
    working_b_value = abs(initial_b_value)

    # Manage special scenarios: one of the coefficients is zero.
    if working_a_value == 0 and working_b_value == 0:
        if input_num == 0:
            # 0*x + 0*y = 0. Many solutions exist. Yield (0, 0) as a simple one.
            return (0, 0)
        else:
            # 0*x + 0*y = non-zero num. No solution.
            return None

    if working_a_value == 0:
        if input_num % working_b_value == 0:
            # 0*x + b*y = n => b*y = n. x can be anything; choose 0.
            # Sign adjustment for y: if initial_b_value was negative, num/initial_b_value gives correct sign.
            return (0, input_num // initial_b_value)
        else:
            return None

    if working_b_value == 0:
        if input_num % working_a_value == 0:
            # a*x + 0*y = n => a*x = n. y can be anything; choose 0.
            # Sign adjustment for x: if initial_a_value was negative, num/initial_a_value gives correct sign.
            return (input_num // initial_a_value, 0)
        else:
            return None

    # For non-zero working_a_value and working_b_value
    common_divisor_value, x_positive_solution, y_positive_solution = my_extended_gcd(working_a_value, working_b_value)

    if input_num % common_divisor_value != 0:
        return None

    multiplier_value = input_num // common_divisor_value

    # Adjust initial solution for `working_a_value*x + working_b_value*y = input_num`
    x_current_solution_value = x_positive_solution * multiplier_value
    y_current_solution_value = y_positive_solution * multiplier_value

    # Adjust outcome signs, considering initial inputs.
    # If initial_a_value was negative, it means we solved for -initial_a_value * x' + initial_b_value * y' = input_num,
    # so the x for initial_a_value is -x'.
    if initial_a_value < 0:
        x_current_solution_value = -x_current_solution_value
    if initial_b_value < 0:
        y_current_solution_value = -y_current_solution_value

    # At this point, (x_current_solution_value, y_current_solution_value) is a valid solution
    # for initial_a_value*x + initial_b_value*y = input_num.

    # Adjust outcome to a canonical style (e.g., smallest non-negative x, matching test cases).
    # The general solution for x is: x = x_current + t * (initial_b_value / common_divisor_value)
    # The general solution for y is: y = y_current - t * (initial_a_value / common_divisor_value)

    # `x_movement_magnitude` is the absolute step size for x values.
    # Since working_b_value is abs(initial_b_value) and is not zero, x_movement_magnitude >= 1.
    x_movement_magnitude = working_b_value // common_divisor_value

    # `canonical_x_value` is the desired x in the range [0, x_movement_magnitude - 1].
    # Python's `%` operator handles negative numbers correctly for positive modulus (e.g., -7 % 3 is 2).
    canonical_x_value = x_current_solution_value % x_movement_magnitude

    # Now, find `shift_amount_value` (t) to move `x_current_solution_value` to `canonical_x_value`.
    # `canonical_x_value = x_current_solution_value + shift_amount_value * (initial_b_value // common_divisor_value)`
    # The divisor `(initial_b_value // common_divisor_value)` incorporates the sign of initial_b_value.
    shift_amount_value = (canonical_x_value - x_current_solution_value) // (initial_b_value // common_divisor_value)

    outcome_x_value = canonical_x_value
    outcome_y_value = y_current_solution_value - shift_amount_value * (initial_a_value // common_divisor_value)

    return (outcome_x_value, outcome_y_value)