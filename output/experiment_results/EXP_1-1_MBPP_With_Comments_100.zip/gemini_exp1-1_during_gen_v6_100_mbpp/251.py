def insert_element(my_input_list: list, my_val: any) -> list:
    """
    Inserts a given value before each existing element in a list.

    Args:
        my_input_list (list): The original list of items.
        my_val (any): The value to insert.

    Returns:
        list: A new list with the value inserted before each original item.
    """
    new_joined_list = []
    # Walk over each current item in the original list.
    for current_item in my_input_list:
        # Add the common value.
        new_joined_list.append(my_val)
        # Add the current item.
        new_joined_list.append(current_item)
    return new_joined_list