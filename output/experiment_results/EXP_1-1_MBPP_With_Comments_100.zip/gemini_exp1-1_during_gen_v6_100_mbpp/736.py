def left_insertion(any_sorted_array: list[int], item_value: int) -> int:
    """
    Locates the left insertion point for a specified value in a sorted array.
    This mimics the behavior of `bisect_left`.

    Args:
        any_sorted_array: A list of integers sorted in ascending order.
        item_value: The value for which to find the insertion point.

    Returns:
        The index where the item_value would be inserted to maintain sort order,
        ensuring all existing elements less than item_value precede it.
    """
    low_index = 0
    high_index = len(any_sorted_array)
    # Init current interval indices.

    while low_index < high_index:
        mid_index = (low_index + high_index) // 2
        # Calc midpoint.
        if any_sorted_array[mid_index] < item_value:
            low_index = mid_index + 1
            # If current array item is smaller, move low index up.
        else:
            high_index = mid_index
            # Item is larger or equal, move high index down.
            # This mid_index could be our insertion point, or an earlier one.
    return low_index
    # Returns current low index as insertion point.