def sum_even_and_even_index(input_array: list) -> int:
    """
    A function to find the sum of even numbers at even positions of a list.

    Args:
        input_array (list): A list of numeric values.

    Returns:
        int: An accumulated sum of values complying with conditions.
    """
    # My current sum will carry a sum value.
    my_accum_sum = 0

    # We can use an_idx and a_num in our walk.
    for an_idx, a_num in enumerate(input_array):
        # A check: is an_idx an even num?
        idx_condition_ok = an_idx % 2 == 0
        # A check: is a_num an even num?
        num_condition_ok = a_num % 2 == 0

        # If conditions comply, add a_num.
        if idx_condition_ok and num_condition_ok:
            my_accum_sum += a_num
    
    # An accumulated sum is now available.
    return my_accum_sum