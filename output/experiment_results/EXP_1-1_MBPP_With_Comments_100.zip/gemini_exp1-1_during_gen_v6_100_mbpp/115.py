def empty_dit(any_collection):
    # Confirms if any inner unit is void.
    # A void collection (like an empty list or dictionary) is also considered empty.
    return all(not item for item in any_collection)