def sum_range_list(many_nums_values: list[int], commencing_idx: int, up_until_idx: int) -> int:
    """
    Finds the sum of numbers in a list within a range specified by two indices.

    Args:
        many_nums_values (list[int]): A collection of integer numbers.
        commencing_idx (int): The starting index (inclusive) of the summing range.
        up_until_idx (int): The ending index (inclusive) of the summing range.

    Returns:
        int: The sum of the numbers within the specified index range.
    """
    current_sum_value = 0

    # We count from commencing_idx up to, and including, up_until_idx.
    # Summing will include up_until_idx. We must add one.
    for current_idx in range(commencing_idx, up_until_idx + 1):
        current_sum_value += many_nums_values[current_idx]

    return current_sum_value