def replace_char(any_input_string: str, which_char_to_swap: str, new_value_char: str) -> str:
    # A new collection for output.
    accumulating_new_string = ""
    # We scan any_input_string.
    for current_unit_char in any_input_string:
        # Confirm current_unit_char is which_char_to_swap.
        if current_unit_char == which_char_to_swap:
            # If so, join new_value_char.
            accumulating_new_string += new_value_char
        else:
            # If not, join current_unit_char.
            accumulating_new_string += current_unit_char
    # Output our accumulating_new_string.
    return accumulating_new_string