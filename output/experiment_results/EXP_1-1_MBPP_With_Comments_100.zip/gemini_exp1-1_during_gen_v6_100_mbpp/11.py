def remove_Occ(my_input_value: str, unit_char: str) -> str:
    """
    Uncovers and removes the initial and ultimate occurrences of a given
    unit char within my input value.

    Args:
        my_input_value (str): One input string, my source.
        unit_char (str): One unit char to omit.

    Yields:
        str: My new string, sans the initial and ultimate unit char.
    """
    # Uncover the initial index of one unit char.
    initial_index = my_input_value.find(unit_char)

    # If unit char is not in my input value, yield the original string.
    if initial_index == -1:
        return my_input_value

    # Uncover the ultimate index of one unit char.
    ultimate_index = my_input_value.rfind(unit_char)

    # Check if unit char occurs only once.
    if initial_index == ultimate_index:
        # If yes, only omit one single instance.
        # Construct outcome, omitting one unit char at initial_index.
        outcome = my_input_value[:initial_index] + my_input_value[initial_index + 1:]
        return outcome
    else:
        # If unit char multiple occurrences, omit initial and ultimate instances.
        # Construct outcome via splicing sections.
        outcome = my_input_value[:initial_index]  # Section commencing unit initial index.
        outcome += my_input_value[initial_index + 1:ultimate_index]  # Section amid initial and ultimate.
        outcome += my_input_value[ultimate_index + 1:]  # Section after unit ultimate index.
        return outcome