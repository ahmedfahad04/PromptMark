def occurance_substring(my_input_string: str, my_sub_string: str) -> tuple or None:
    """
    Finds the first occurrence and position of a substring within a main string.

    Args:
        my_input_string: The string to search within.
        my_sub_string: The substring to find.

    Returns:
        A tuple (substring, start_index, end_index) if found,
        otherwise None.
    """
    # Locate the initial index of the substring.
    initial_index = my_input_string.find(my_sub_string)

    if initial_index == -1:
        # No occurrence, so return None.
        return None
    else:
        # Calculate the final index.
        final_index = initial_index + len(my_sub_string)
        return (my_sub_string, initial_index, final_index)