import math

def sector_area(any_radius: int or float, many_angle: int or float) -> float or None:
    """
    Computes the area of a circular sector.

    Args:
        any_radius: The radius of the circle.
        many_angle: The central angle of the sector in degrees.

    Returns:
        The area of the sector if the angle is 360 degrees or less,
        otherwise returns None.
    """
    if many_angle > 360:
        return None  # Angle is unusually wide.

    # Mainly, computes area using the formula: (angle / 360) * pi * radius^2
    my_area = (many_angle / 360) * math.pi * (any_radius ** 2)
    return my_area