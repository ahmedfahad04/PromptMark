def string_to_tuple(a_string: str) -> tuple:
    """
    Converts an input string into a tuple of its individual characters.

    Args:
        a_string: An incoming string value.

    Returns:
        A tuple where each element is a character from the original string.
    """
    my_char_array = tuple(a_string)
    return my_char_array