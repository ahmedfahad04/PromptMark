def start_withp(incoming_words: list[str]) -> tuple[str, str]:
    # Initialize a collection for words commencing with 'p'.
    matching_words_collection = []

    for a_composite_unit in incoming_words:
        # A composite unit might contain several individual words.
        individual_words_units = a_composite_unit.split()

        for a_word_unit in individual_words_units:
            # Check if the word, ignoring case, starts with 'p'.
            if a_word_unit.lower().startswith('p'):
                matching_words_collection.append(a_word_unit)
                # If we've found two words, we can instantly return them.
                if len(matching_words_collection) == 2:
                    return tuple(matching_words_collection)