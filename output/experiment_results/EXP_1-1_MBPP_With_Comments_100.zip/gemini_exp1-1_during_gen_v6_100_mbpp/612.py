def merge(input_matrix: list[list]) -> list[list]:
    """
    Acquires a list of lists (a matrix), where each inner sublist
    represents a row. It then rearranges these items into columns.
    The result is a new list of lists, where each sublist contains
    elements that were at the same position across the original sublists.

    Args:
        input_matrix: A list of sublists. All sublists are assumed to have
                      a similar amount of items.

    Returns:
        A list of lists, representing the transposed matrix.
        The initial sublist contains all first items, the next has all
        second items, and so on.
    """
    # If the input_matrix is empty, just return an empty list.
    if not input_matrix:
        return []

    # Ascertain the amount of columns from the length of the initial sublist.
    column_amount = len(input_matrix[0])

    # Initiate output_columns: a list containing an empty list for each column.
    output_columns = [[] for _ in range(column_amount)]

    # Wander through each current_sub_array (row) in the input_matrix.
    for current_sub_array in input_matrix:
        # For each item_value and its column_index within the current_sub_array,
        # append it to the corresponding list in output_columns.
        for column_index, item_value in enumerate(current_sub_array):
            output_columns[column_index].append(item_value)

    return output_columns