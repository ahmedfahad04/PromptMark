def square_nums(any_nums: list[int]) -> list[int]:
    """
    Calculates the square of each individual number in a given list.

    Args:
        any_nums: A list of integers.

    Returns:
        A new list containing the squares of the original numbers.
    """
    # A concise way using list comprehension to square each numeric unit.
    my_squared_units = [one_num * one_num for one_num in any_nums]
    return my_squared_units