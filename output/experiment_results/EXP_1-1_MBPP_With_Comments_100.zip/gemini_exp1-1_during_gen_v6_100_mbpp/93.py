def power(a, b):
    """Calculates 'a' raised to the power 'b' iteratively.

    Args:
        a (int): The base number.
        b (int): The exponent.

    Returns:
        int: The value of 'a' to the power 'b'.
    """
    my_output = 1  # Initializes an output variable.
    for _ in range(b):
        my_output *= a  # Multiplies 'a' into the output 'b' many occasions.
    return my_output