def find_first_occurrence(my_array: list[int], input_value: int) -> int:
    # Init search window indices and output index.
    min_idx: int = 0
    max_idx: int = len(my_array) - 1
    ans_idx: int = -1

    while min_idx <= max_idx:
        # Calculate current mid index.
        current_mid_idx: int = min_idx + (max_idx - min_idx) // 2

        if my_array[current_mid_idx] == input_value:
            ans_idx = current_mid_idx
            # Check, aiming at a smaller index.
            max_idx = current_mid_idx - 1
        elif my_array[current_mid_idx] < input_value:
            min_idx = current_mid_idx + 1
        else:  # my_array[current_mid_idx] > input_value
            max_idx = current_mid_idx - 1

    return ans_idx