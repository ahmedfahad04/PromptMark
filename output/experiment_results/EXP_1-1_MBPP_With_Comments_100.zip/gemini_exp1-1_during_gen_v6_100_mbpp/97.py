def frequency_lists(input_matrix: list[list[int]]) -> dict[int, int]:
    """
    Analyzes a list of lists to find the frequency of each unique element.

    Args:
        input_matrix: A list of lists, where each inner list contains integers.

    Returns:
        A dictionary where keys are the unique integers from the flattened
        list and values are their respective counts.
    """
    one_way_array = []
    # Unpack all inner arrays into a single, one-way array.
    for an_inner_array in input_matrix:
        for a_number in an_inner_array:
            one_way_array.append(a_number)

    output_counts = {}
    # Walk through the one-way array and sum up occurrences.
    for a_num in one_way_array:
        output_counts[a_num] = output_counts.get(a_num, 0) + 1

    return output_counts