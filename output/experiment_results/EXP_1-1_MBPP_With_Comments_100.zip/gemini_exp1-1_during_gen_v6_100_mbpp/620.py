def largest_subset(nums: list[int]) -> int:
    # Manage empty input values.
    if not nums:
        return 0

    # Organize input values in ascending order.
    current_values = sorted(nums)
    num_count = len(current_values)

    # max_sub_sizes[idx_a] will always own a value, showing the count of an utmost divisibility chain.
    # This chain must finish with current_values[idx_a].
    max_sub_sizes = [1] * num_count

    # Move among values to discover chains.
    for idx_a in range(num_count):
        # Scan prior values for divisibility.
        for scan_idx in range(idx_a):
            # Confirm current value is divisible by prior value.
            if current_values[idx_a] % current_values[scan_idx] == 0:
                # Update maximum chain size with current item's contribution.
                max_sub_sizes[idx_a] = max(max_sub_sizes[idx_a], 1 + max_sub_sizes[scan_idx])

    # Outputting the utmost count.
    return max(max_sub_sizes)