def find_First_Missing(my_nums: list[int]) -> int:
    """
    A way of uncovering missing value within my_nums (a sorted array).
    Its workings involve a savvy inquiry (via scan) of values.
    """
    if not my_nums:
        # When my_nums is vacant, 0 is my smallest missing value.
        return 0

    origin_idx = 0
    win_idx = len(my_nums) - 1
    # Missing num value is initially assumed as my_nums count, if all unseen values show up.
    missing_num_value = len(my_nums)

    while origin_idx <= win_idx:
        mid_idx = (origin_idx + win_idx) // 2

        if my_nums[mid_idx] == mid_idx:
            # All current values show up. Scan in upper window.
            origin_idx = mid_idx + 1
        else:
            # A value is missing at or prior to mid_idx.
            # Update current missing_num_value. Now, search in win_idx window.
            missing_num_value = mid_idx
            win_idx = mid_idx - 1
            
    return missing_num_value