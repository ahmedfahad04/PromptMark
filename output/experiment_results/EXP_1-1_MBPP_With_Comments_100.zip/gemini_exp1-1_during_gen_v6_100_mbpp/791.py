def remove_nested(input_units: tuple) -> tuple:
    """
    Acquires a tuple and yields a new tuple, excluding any inner tuples.

    Args:
        input_units: An input tuple, possibly containing nested tuples.

    Yields:
        A new tuple comprising only non-tuple items from the input.
    """
    my_valid_units = []
    # Inspect each item within the input tuple.
    for current_unit in input_units:
        # If the item is not a tuple, include it in our new collection.
        if not isinstance(current_unit, tuple):
            my_valid_units.append(current_unit)
    
    # Convert the collected items into a tuple for the final yield.
    return tuple(my_valid_units)