def tuple_intersection(unison_one: list[tuple], unison_two: list[tuple]) -> set[tuple]:
    """
    Finds the intersection of elements in two given tuple lists,
    irrespective of the order of elements within each tuple.

    Args:
        unison_one (list[tuple]): A primary list of tuples.
        unison_two (list[tuple]): A secondary list of tuples.

    Returns:
        set[tuple]: A set containing the common tuples in their normalized (sorted) form.
    """

    # Normalize tuples in unison_one. For each (a, b), we convert it to (min(a, b), max(a, b)).
    # This ensures that (a, b) and (b, a) are considered equivalent.
    many_one_normalized = set()
    for some_unison in unison_one:
        min_val_unison = min(some_unison[0], some_unison[1])
        max_val_unison = max(some_unison[0], some_unison[1])
        many_one_normalized.add((min_val_unison, max_val_unison))

    # Normalize tuples in unison_two using the same logic.
    many_two_normalized = set()
    for some_unison in unison_two:
        min_val_unison = min(some_unison[0], some_unison[1])
        max_val_unison = max(some_unison[0], some_unison[1])
        many_two_normalized.add((min_val_unison, max_val_unison))

    # Calculate the intersection of the two sets of normalized tuples.
    # This yields all tuples that are common to both input lists,
    # considering the order-insensitive nature.
    return many_one_normalized.intersection(many_two_normalized)