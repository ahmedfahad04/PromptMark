def perimeter_pentagon(unit_value):
    # A regular pentagon has five equal sides.
    # Its perimeter is calculated by multiplying the number of sides by the unit value of one side.
    return 5 * unit_value