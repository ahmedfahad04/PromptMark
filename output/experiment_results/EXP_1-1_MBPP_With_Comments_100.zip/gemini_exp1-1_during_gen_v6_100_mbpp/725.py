import re

def extract_quotation(input_string):
    """
    Acquires values situated within double quotation marks in a provided string.
    Only double quotes (") are considered; single quotes (') are ignored.

    Args:
        input_string (str): A string that may contain values enclosed in double quotes.

    Returns:
        list: A list of strings, each corresponding to a value found
              between double quotation marks. Returns an empty list if no such values exist.
    """
    # Construct a regular expression pattern to find content within double quotes.
    # The '\"' matches a literal double quotation mark.
    # The '([^\"]*)' is a capturing group:
    #   '[^"]' matches any character that is NOT a double quote.
    #   '*' means zero or more occurrences of the preceding character.
    # This ensures we capture the content between two double quotes.
    my_quotation_pattern = r'\"([^\"]*)\"'

    # Utilize re.findall to locate all non-overlapping matches of the pattern's
    # capturing group within the input string. This directly yields a list
    # of all strings found between the double quotes.
    found_values = re.findall(my_quotation_pattern, input_string)

    return found_values