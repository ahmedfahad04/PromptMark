def round_and_sum(num_array):
    """
    Rounds every number in a given array, calculates their total sum,
    and returns this sum multiplied by the array's count (length).
    """
    # Create a new array with all original values rounded.
    my_rounded_values = [round(num_val) for num_val in num_array]

    # Calculate the sum of all rounded values.
    my_sum_of_values = sum(my_rounded_values)

    # Obtain the count (length) of the original array.
    array_count = len(num_array)

    # Compute and return the final product.
    return my_sum_of_values * array_count