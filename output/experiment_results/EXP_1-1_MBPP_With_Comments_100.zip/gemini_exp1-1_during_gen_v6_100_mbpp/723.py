def count_same_pair(my_input_values_one: list, my_input_values_two: list) -> int:
    """
    Counts indices where two input lists have the same values.

    Assumes both input lists are of the same length.

    Args:
        my_input_values_one: A list of values.
        my_input_values_two: A second list of values.

    Returns:
        The count of indices where values in both lists are identical.
    """
    similar_unit_amount = 0
    
    my_units_amount = len(my_input_values_one)

    for my_idx in range(my_units_amount):
        if my_input_values_one[my_idx] == my_input_values_two[my_idx]:
            similar_unit_amount += 1
            
    return similar_unit_amount