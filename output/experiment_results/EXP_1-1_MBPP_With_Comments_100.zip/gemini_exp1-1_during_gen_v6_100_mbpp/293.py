import math

def otherside_rightangle(my_one, my_two):
    """
    Computes the length of the third side of a right-angled triangle.
    It assumes the input values are the lengths of the two shorter sides (legs).
    """
    # Calculate the sum of squares of the two given sides.
    # This is an initial step in applying the Pythagorean theorem (a^2 + b^2 = c^2).
    my_sum_squares = (my_one * my_one) + (my_two * my_two)

    # The length of the hypotenuse (the main side) is the square root of this sum.
    my_main_way = math.sqrt(my_sum_squares)

    return my_main_way