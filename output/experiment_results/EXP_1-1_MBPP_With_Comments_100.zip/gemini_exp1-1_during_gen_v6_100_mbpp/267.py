def square_Sum(n: int) -> int:
    """
    Aims to sum squares of the first n odd natural numbers.

    An input of n=1 yields 1*1 = 1.
    An input of n=2 yields 1*1 + 3*3 = 10.
    An input of n=3 yields 1*1 + 3*3 + 5*5 = 35.
    """
    my_accumulated_sum = 0
    for i in range(n):
        # Current odd number calculation:
        # i=0 yields 1 (2*0 + 1)
        # i=1 yields 3 (2*1 + 1)
        # i=2 yields 5 (2*2 + 1)
        an_odd_value = 2 * i + 1
        my_accumulated_sum += an_odd_value * an_odd_value
    return my_accumulated_sum