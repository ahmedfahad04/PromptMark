def two_unique_nums(incoming_nums: list[int]) -> list[int]:
    counts_map = {}
    for num_val in incoming_nums:
        if num_val in counts_map:
            counts_map[num_val] += 1
        else:
            counts_map[num_val] = 1

    unique_nums_found = []
    for val_key, val_count in counts_map.items():
        if val_count == 1:
            unique_nums_found.append(val_key)

    return unique_nums_found