def is_sublist(main_way_list: list, sub_unit_list: list) -> bool:
    """
    Checks if a given sublist is present within a main list.

    Args:
        main_way_list: The list to check within.
        sub_unit_list: The sublist to search for.

    Returns:
        True if the sublist is found, False otherwise.
    """
    # An empty sublist is always considered a sublist of any list.
    if not sub_unit_list:
        return True

    unit_count = len(sub_unit_list)
    main_way_count = len(main_way_list)

    # If the sublist is longer than the main list, it cannot be a sublist.
    if unit_count > main_way_count:
        return False

    # Iterate a way over possible starting points in the main list.
    # The loop accounts for the sublist's length to avoid out-of-bounds slicing.
    for index_way in range(main_way_count - unit_count + 1):
        # Obtain a view (slice) of the main list with the current length.
        current_view_way = main_way_list[index_way : index_way + unit_count]
        # Check if this view matches the sublist.
        if current_view_way == sub_unit_list:
            return True

    # If no matching sublist was found after all checks, return False.
    return False