def substract_elements(my_tupl_one: tuple, my_tupl_two: tuple) -> tuple:
    """
    Subtracts elements of the second tuple from the corresponding elements
    of the first tuple.

    Args:
        my_tupl_one (tuple): The initial tuple.
        my_tupl_two (tuple): The tuple whose elements will be subtracted.

    Returns:
        tuple: A new tuple with the results of the subtractions.
    """
    # my_output_values will contain the results of each subtraction.
    my_output_values = []
    
    # We use 'zip' to iterate over items of both tuples concurrently.
    for val_one, val_two in zip(my_tupl_one, my_tupl_two):
        my_output_values.append(val_one - val_two)
        
    # Convert the list of new values into a tuple, then give it.
    return tuple(my_output_values)