def rear_extract(some_input_via_tuples: list[tuple]) -> list:
    """
    Acquires just final values from any input collection of tuples.

    Args:
        some_input_via_tuples: A collection, containing many tuples.

    Returns:
        A new collection, containing only the final value of each input tuple.
    """
    # Acquires just final values.
    # Uses a list comprehension for concise iteration and value collection.
    return [an_item_via_tuple[-1] for an_item_via_tuple in some_input_via_tuples]