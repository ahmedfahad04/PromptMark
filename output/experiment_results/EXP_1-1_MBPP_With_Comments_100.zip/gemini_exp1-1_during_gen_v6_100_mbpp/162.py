def sum_series(n: int) -> int:
    """Aims sum (n minus 2*i) as i moves 0 up to n // 2."""
    my_sum = 0
    # Loop 'i' from 0 up to 'n // 2', inclusively.
    for i in range(n // 2 + 1):
        my_sum += (n - 2 * i)
    return my_sum