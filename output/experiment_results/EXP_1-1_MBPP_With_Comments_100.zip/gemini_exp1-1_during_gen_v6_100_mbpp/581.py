def surface_Area(a_unit, s_unit):
    """
    Calculates the surface area of a square pyramid.

    My understanding, based on the provided test cases, is that 's_unit'
    represents the slant height of the pyramid, not its vertical height.

    Args:
        a_unit (numeric): A numeric value, representing the length of one base edge.
        s_unit (numeric): A numeric value, representing the slant height of a pyramid.

    Returns:
        numeric: The overall surface area of the square pyramid.
    """
    # A square base's area.
    a_square_base = a_unit * a_unit

    # Area of the four triangular lateral surfaces.
    # Each triangular surface's area is (1/2 * base_edge * slant_height).
    # Since my pyramid own four such surfaces, the total lateral area is 2 * base_edge * slant_height.
    a_sides_unison = 2 * a_unit * s_unit

    # Overall surface area is the sum of the base area and the lateral area.
    overall_area = a_square_base + a_sides_unison

    return overall_area