def list_split(my_jumbo_list: list, n: int) -> list[list]:
    # Initialize an outcome list with 'n' empty sublists.
    # This will contain all the individual lists after splitting.
    my_outcome = [[] for _ in range(n)]

    # Iterate through the original jumbo list, maintaining its current index.
    for index_value, current_item in enumerate(my_jumbo_list):
        # Calculate which sublist the current item belongs to
        # using the modulo operator. This gives a cyclical assignment.
        current_sub_index = index_value % n
        # Append the current item to its designated sublist.
        my_outcome[current_sub_index].append(current_item)
    
    return my_outcome