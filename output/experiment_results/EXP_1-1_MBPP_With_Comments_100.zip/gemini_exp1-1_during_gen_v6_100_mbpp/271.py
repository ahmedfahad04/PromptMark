def even_Power_Sum(n: int) -> int:
    current_sum = 0
    for my_idx in range(1, n + 1):
        current_even_unit = 2 * my_idx
        unit_power_value = current_even_unit ** 5
        current_sum += unit_power_value
    return current_sum