def swap_List(my_input_list: list) -> list:
    # Check if the list has at least two elements for a valid swap.
    # If not, simply return the original list as is.
    my_size = len(my_input_list)
    if my_size < 2:
        return my_input_list

    # Swap the first and last elements using simultaneous assignment.
    # This directly modifies the original list.
    my_input_list[0], my_input_list[my_size - 1] = my_input_list[my_size - 1], my_input_list[0]
    
    # Return the list with its elements interchanged.
    return my_input_list