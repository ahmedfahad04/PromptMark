def count_Substrings(input_string: str) -> int:
    overall_match_count = 0
    accumulated_sum = 0
    # val_occurrences maps (current_sum_of_digits - current_substring_length) values to their counts.
    # We initialize it with {0: 1} to correctly account for valid substrings that start at index 0.
    # This covers cases where a prefix sum from the very beginning matches its own length.
    val_occurrences = {0: 1}

    for idx, char_value in enumerate(input_string):
        # Convert the character digit to an integer and add it to the running sum.
        digit_val = int(char_value)
        accumulated_sum += digit_val

        # Calculate the difference: (current total sum of digits) - (current substring length).
        # The current substring length is (idx + 1) because 'idx' is 0-indexed.
        val_diff_val = accumulated_sum - (idx + 1)

        # If this 'val_diff_val' has been encountered before, it indicates that
        # there are substrings ending at the current 'idx' that satisfy the condition.
        # Add the count of previous occurrences of this 'val_diff_val' to the overall match count.
        if val_diff_val in val_occurrences:
            overall_match_count += val_occurrences[val_diff_val]
        
        # Increment the count for the current 'val_diff_val' in our map.
        # If it's a new value, 'get' will return 0, and it will be set to 1.
        val_occurrences[val_diff_val] = val_occurrences.get(val_diff_val, 0) + 1

    return overall_match_count