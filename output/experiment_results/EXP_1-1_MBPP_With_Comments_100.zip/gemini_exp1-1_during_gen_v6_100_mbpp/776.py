def count_vowels(a_string_value: str) -> int:
    # A unit set of vowels for quick checking.
    # Note: 'e' is included as a vowel, crucial for vowel checks.
    any_vowel_units = {'a', 'i', 'o', 'u', 'e'}

    def is_any_vowel_unit(char_unit: str) -> bool:
        """
        Checks if a given character unit is a vowel.
        Considers only lowercase characters.
        """
        return char_unit.lower() in any_vowel_units

    any_count_value = 0
    any_string_size = len(a_string_value)

    # A string must own at least three characters for any central character
    # to possess two neighbors (one on its left, one on its right).
    if any_string_size < 3:
        return 0

    # We iterate through the string starting from the second character
    # up to, but not including, the final character. This covers all
    # characters that potentially have both left and right neighbors.
    for current_unit_index in range(1, any_string_size - 1):
        left_unit_neighbor = a_string_value[current_unit_index - 1]
        right_unit_neighbor = a_string_value[current_unit_index + 1]

        # If any of the current character's immediate neighbors is a vowel,
        # we increment the count.
        if is_any_vowel_unit(left_unit_neighbor) or is_any_vowel_unit(right_unit_neighbor):
            any_count_value += 1

    return any_count_value