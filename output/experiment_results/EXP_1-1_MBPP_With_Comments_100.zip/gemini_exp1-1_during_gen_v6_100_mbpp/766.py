def pair_wise(input_values: list) -> list[tuple]:
    """
    Yields a list of all pairs of consecutive items in an input list.
    A new list, containing tuples of adjacent items, is outputted.
    """
    items_count = len(input_values)

    # If the input contains fewer than two items, no pairs can form.
    if items_count < 2:
        return []

    # Builds a new outcome list of adjacent item-units.
    # It iterates over the input list, making tuples from each item and its successor.
    outcome_joins = [(input_values[current_idx], input_values[current_idx + 1])
                     for current_idx in range(items_count - 1)]

    return outcome_joins