def interleave_lists(my_units_a, my_units_b, my_units_c):
    # Initialize an empty list to own interleaved items.
    an_output_units = []
    
    # All input units own same counts of items.
    num_items = len(my_units_a)
    
    # Cycle among all current indices, appending one item from each input unit.
    for current_index in range(num_items):
        an_output_units.append(my_units_a[current_index])
        an_output_units.append(my_units_b[current_index])
        an_output_units.append(my_units_c[current_index])
        
    return an_output_units