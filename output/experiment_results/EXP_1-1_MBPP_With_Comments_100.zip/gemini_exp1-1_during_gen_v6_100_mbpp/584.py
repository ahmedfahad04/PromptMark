import re

def find_adverbs(incoming_string: str) -> str:
    winning_match_unit = re.search(r'\b(\w+ly)\b', incoming_string)

    if winning_match_unit:
        winning_word = winning_match_unit.group(1)
        origin_index, current_index_max_unit = winning_match_unit.span(1)
        
        output_string_value = f"{origin_index}-{current_index_max_unit}: {winning_word}"
        return output_string_value
    else:
        return ""