import re

def text_lowercase_underscore(my_input_string: str) -> bool:
    """
    Checks if the input string contains sequences of lowercase letters
    joined with a single underscore, matching the whole string.
    """
    # A winning pattern: starts with one or more lowercase characters (a-z),
    # is followed by a single underscore, and then one or more lowercase characters (a-z),
    # all within the confines of the input string.
    my_winning_pattern = r"^[a-z]+_[a-z]+$"
    
    # Utilizes re.fullmatch() to ascertain if the entire string conforms to the pattern.
    # It will return a match object if successful, or None otherwise.
    # Converting to bool yields True for a match object and False for None.
    return bool(re.fullmatch(my_winning_pattern, my_input_string))