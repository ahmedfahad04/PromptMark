def and_tuples(uno_in_val: tuple[int, ...], uno_in_val_two: tuple[int, ...]) -> tuple[int, ...]:
    # Init new list for outcome values.
    new_unit_vals = []
    # Join units, moving concurrently across input tuples.
    for my_num_uno, my_num_two in zip(uno_in_val, uno_in_val_two):
        # Apply unit-wise AND on current pair.
        new_unit_vals.append(my_num_uno & my_num_two)
    # Convert outcome list into a tuple.
    return tuple(new_unit_vals)