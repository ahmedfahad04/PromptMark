def common_in_nested_lists(input_jumble: list[list[int]]) -> set[int]:
    """
    Ascertains common numeric units among various inner lists within a jumble.

    Args:
        input_jumble: A list of lists, where each inner list contains integers.

    Returns:
        A set containing integers that are present in every inner list.
        An empty set is yielded if the input jumble is empty.
    """
    if not input_jumble:
        return set()

    # Initializing with the units of the initial inner list.
    # Any units common across all must naturally occur in this initial unit.
    joint_units = set(input_jumble[0])

    # Moving across remaining inner lists, updating joint units via intersection.
    # An intersection operation efficiently yields only units common to both sets.
    for current_unit_list in input_jumble[1:]:
        joint_units = joint_units.intersection(set(current_unit_list))
        # If no common units remain, we can yield an empty set immediately.
        if not joint_units:
            return set()

    return joint_units