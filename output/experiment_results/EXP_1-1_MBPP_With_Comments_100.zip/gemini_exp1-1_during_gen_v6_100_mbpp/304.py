def find_Element(in_array, rot_options, seek_index, query_amount):
    array_size = len(in_array)
    yaw_amount = 0  # A cumulative right shift amount.

    # Summing 'yaw' amounts from selected rotation options.
    # We assume '0' indicates a 'yaw' (right rotation) by a given value.
    # 'query_amount' specifies how many of the initial rotation options to use.
    for i in range(query_amount):
        # The yaw value is found at index 1 within each rotation option.
        yaw_value = rot_options[i][1]
        yaw_amount = (yaw_amount + yaw_value) % array_size

    # The element currently at 'seek_index' in the final (rotated) array
    # was originally at 'start_index' in the initial array.
    # For a right yaw by 'yaw_amount', the original position is calculated
    # by moving 'yaw_amount' positions to the left from 'seek_index'.
    # Adding 'array_size' before applying the modulo ensures a positive result
    # even if (seek_index - yaw_amount) is negative.
    start_index = (seek_index - yaw_amount + array_size) % array_size

    return in_array[start_index]