def extract_string(my_strings_array: list[str], an_inquiry_size: int) -> list[str]:
    """
    Acquires strings of a specified size from an array of string values.

    Args:
        my_strings_array: A list of input strings.
        an_inquiry_size: The exact string length to look for.

    Returns:
        A new list containing only strings whose length matches an_inquiry_size.
    """
    my_output_array = []
    for current_string_unit in my_strings_array:
        if len(current_string_unit) == an_inquiry_size:
            my_output_array.append(current_string_unit)
    return my_output_array