def find_lucas(num_n: int) -> int:
    """
    Computes the n'th Lucas number.

    The Lucas numbers are a sequence of integers named after the mathematician
    Édouard Lucas, closely related to the Fibonacci numbers.
    They are defined by the recurrence relation:
    L(0) = 2
    L(1) = 1
    L(n) = L(n-1) + L(n-2) for n > 1
    """
    if num_n == 0:
        return 2
    if num_n == 1:
        return 1

    # Initialize current and previous Lucas numbers
    # val_second_ago holds L(k-2)
    # val_one_ago holds L(k-1)
    val_second_ago: int = 2  # Corresponds to L(0)
    val_one_ago: int = 1     # Corresponds to L(1)

    # Calculate Lucas numbers iteratively up to num_n
    for _ in range(2, num_n + 1):
        current_lucas_sum: int = val_one_ago + val_second_ago
        val_second_ago = val_one_ago
        val_one_ago = current_lucas_sum
    
    # val_one_ago now holds L(num_n)
    return val_one_ago