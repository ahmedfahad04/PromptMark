def unique_product(input_values: list) -> int:
    """
    Calculates the product of all unique numbers within a given list.

    Args:
        input_values: A list of numbers.

    Returns:
        An integer representing the product of unique numbers.
        Returns 1 if the input list contains no unique numbers (or is empty).
    """
    unique_numbers_set = set(input_values) # Collects all unique values.
    current_product = 1 # Initializes product with one, multiplicative identity.

    for num_value in unique_numbers_set:
        current_product *= num_value # Multiply into current product.

    return current_product