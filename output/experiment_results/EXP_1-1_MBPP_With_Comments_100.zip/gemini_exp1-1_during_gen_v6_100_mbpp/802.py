def count_rotation(an_array: list[int]) -> int:
    """
    Counts the number of rotations required to generate a sorted array.
    Assumes the array was originally sorted in ascending order and then rotated.
    The count of rotations is found by locating the pivot point where an element
    is greater than its successor.

    Args:
        an_array: A list of integers representing a potentially rotated sorted array.

    Returns:
        An integer indicating the minimum number of rotations.
    """
    an_array_size = len(an_array)

    # An array with zero or one element is already sorted, requiring no rotations.
    if an_array_size <= 1:
        return 0

    # Journey an array from its initial to its second-to-last position.
    for current_idx in range(an_array_size - 1):
        # We are seeking the point where an element is greater than its next.
        # This signals the "break" in the sorted sequence, which is the pivot.
        if an_array[current_idx] > an_array[current_idx + 1]:
            # The count of rotations is one more than the current index,
            # as it indicates how many elements from the original end
            # have moved to the front.
            return current_idx + 1

    # If no such pivot is found, the array is already sorted, so 0 rotations.
    return 0