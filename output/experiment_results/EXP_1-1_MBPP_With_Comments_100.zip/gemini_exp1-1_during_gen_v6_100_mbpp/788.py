def new_tuple(my_units: list, one_word: str) -> tuple:
    """
    Creates a new tuple by joining units from a list with a single word.
    """
    # A new view unifies the incoming collection units and the one word.
    new_view = tuple(my_units) + (one_word,)
    return new_view