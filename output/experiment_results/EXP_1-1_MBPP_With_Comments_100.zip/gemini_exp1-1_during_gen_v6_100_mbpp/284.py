def check_element(my_list: list, any_value: any) -> bool:
    """
    Checks if all items in my_list are identical to any_value.

    An empty list always yields True, as no item violates the condition.
    """
    # Verify all list's items are identical to the given value.
    # We use a generator expression with 'all' for an efficient check.
    return all(one_item == any_value for one_item in my_list)