def capital_words_spaces(incoming_string: str) -> str:
    """
    Inserts spaces between words in a string where a new word starts with a capital letter.

    Args:
        incoming_string: The input string, possibly without spaces between capitalized words.

    Returns:
        A new string with spaces inserted before capital letters,
        except for the very first character of the string.
    """
    # Handles an empty or None input string by returning it as is.
    if not incoming_string:
        return incoming_string

    # Initializes a list to accumulate the parts of the modified string.
    # The very first character is always added as it never needs a preceding space.
    word_units = [incoming_string[0]]

    # Walks through the input string starting from the second character.
    for a_char in incoming_string[1:]:
        # If a character is uppercase, it indicates the start of a new word.
        # A space is inserted before adding the uppercase character itself.
        if a_char.isupper():
            word_units.append(' ')
            word_units.append(a_char)
        else:
            # If the character is not uppercase, it's appended directly.
            word_units.append(a_char)
    
    # Joins all the collected parts from the list into a single string and returns it.
    return "".join(word_units)