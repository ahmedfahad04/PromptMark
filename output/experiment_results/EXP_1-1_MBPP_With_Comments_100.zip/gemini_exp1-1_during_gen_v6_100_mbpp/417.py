import collections

def group_tuples(input_tuples: list[tuple]) -> list[tuple]:
    """
    Groups tuples by their common first element.

    Given a list of tuples, this function collects all second elements
    associated with a unique first element and combines them into
    a new tuple. The new tuple will start with the common first element,
    followed by all the collected second elements.

    Args:
        input_tuples: A list of tuples, where each inner tuple
                      is expected to contain at least two items.

    Returns:
        A list of new tuples, where each tuple represents a group
        from the input, starting with the common first item
        and including all associated second items.
    """
    # common_mapping will hold the first elements as keys and lists of
    # corresponding second elements as values. Using defaultdict(list)
    # makes it simple to append values without checking if the key exists.
    common_mapping = collections.defaultdict(list)

    # Walk over each input tuple.
    for current_key, current_value in input_tuples:
        common_mapping[current_key].append(current_value)

    # Now, common_mapping has all first items mapped to their lists of second items.
    # We will assemble the final output list of new tuples.
    output_collection = []
    for common_key, values_for_key in common_mapping.items():
        # Make a new tuple: start with the common_key,
        # and unpack all values_for_key after it.
        new_combined_tuple = (common_key, *values_for_key)
        output_collection.append(new_combined_tuple)

    return output_collection