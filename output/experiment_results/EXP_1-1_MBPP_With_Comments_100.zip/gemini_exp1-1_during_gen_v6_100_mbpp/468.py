def max_product(nums: list[int]) -> int:
    """
    Computes the maximum product formed by multiplying numbers
    of an increasing subsequence within the array.

    Args:
        nums: A list of integers.

    Returns:
        An integer representing the maximum product of an increasing subsequence.
        Returns 0 if the input list is empty.
    """
    array_size = len(nums)
    if array_size == 0:
        return 0

    # current_maxes[i] will own the maximum product of an increasing subsequence
    # ending with nums[i].
    current_maxes = list(nums)
    my_max_product = 0

    # Initialize my_max_product with the maximum single element,
    # as a single element is an increasing subsequence.
    # This also covers cases where no increasing subsequence of length > 1 exists
    # or all elements are decreasing.
    my_max_product = max(nums)

    for idx_i in range(1, array_size):
        current_num = nums[idx_i]
        for idx_j in range(idx_i):
            previous_num = nums[idx_j]

            # If current_num can come after previous_num in an increasing subsequence
            if current_num > previous_num:
                # Calculate potential new product for subsequence ending at current_num
                potential_product = current_maxes[idx_j] * current_num
                
                # Update current_maxes[idx_i] if this new product is larger
                # We also compare with current_num itself in case a new subsequence
                # starting with current_num yields a larger product than extending
                # any previous subsequence. This is important for correctness,
                # but already handled by initialization, so we only need to compare
                # against previous products ending at current_num.
                current_maxes[idx_i] = max(current_maxes[idx_i], potential_product)
        
        # Update the overall maximum product found so far
        my_max_product = max(my_max_product, current_maxes[idx_i])

    return my_max_product