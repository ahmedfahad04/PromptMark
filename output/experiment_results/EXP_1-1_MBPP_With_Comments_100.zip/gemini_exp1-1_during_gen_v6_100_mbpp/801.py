def test_three_equal(num_one: int, num_two: int, num_u: int) -> int:
    """
    Counts the number of equal integers among three provided numeric inputs.

    Args:
        num_one: A numeric input.
        num_two: A second numeric input.
        num_u: A third numeric input.

    Returns:
        An integer indicating the count of equal numbers:
        - 3 if all three numbers are equal.
        - 2 if exactly two numbers are equal.
        - 0 if no numbers are equal.
    """
    if num_one == num_two and num_two == num_u:
        # All three numeric inputs are identical.
        return 3
    elif num_one == num_two or num_one == num_u or num_two == num_u:
        # At least two numeric inputs are identical.
        return 2
    else:
        # No numeric inputs are identical.
        return 0