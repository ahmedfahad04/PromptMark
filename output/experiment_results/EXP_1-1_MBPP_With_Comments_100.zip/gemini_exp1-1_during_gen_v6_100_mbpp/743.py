def rotate_right(inyu_wuny: list, num_wojaions: int) -> list:
    # If inyu_wuny is none or one unit, no wojaion.
    if not inyu_wuny or len(inyu_wuny) <= 1:
        return inyu_wuny

    inyu_many = len(inyu_wuny)
    
    # Calculate the actual number of rotations needed by using modulo.
    # This handles cases where num_wojaions is larger than inyu_many.
    adj_num_wojaions = num_wojaions % inyu_many

    # If adj_num_wojaions is 0, inyu_wuny is a sum (no net rotation occurred).
    if adj_num_wojaions == 0:
        return inyu_wuny

    # Separate the list into two parts using slicing:
    # 1. The 'moviny_uni' is the last 'adj_num_wojaions' items, which move to the front.
    moviny_uni = inyu_wuny[-adj_num_wojaions:]
    # 2. The 'wany_inyu_woju' is the remaining items, which follow the moviny_uni.
    wany_inyu_woju = inyu_wuny[:-adj_num_wojaions]

    # Combine the two units to form the rotated list.
    return moviny_uni + wany_inyu_woju