def extract_singly(in_many_ways: list) -> set:
    """
    Unifies a list of lists (or tuples) into a single set of unique numbers.

    Args:
        in_many_ways: A list where each item is a list or tuple of numbers.

    Returns:
        A set containing all unique numbers found in the input.
    """
    my_uni_nums = set()  # A new set to store all unique numbers.
    for one_way_nums in in_many_ways:
        for a_num in one_way_nums:
            my_uni_nums.add(a_num)  # Add current number to the set.
    return my_uni_nums