def find_even_pair(my_array: list[int]) -> int:
    # A pair of numbers (a, b) yields an even XOR sum if a and b have the same parity.
    # This means both a and b are even, or both a and b are odd.

    count_evens: int = 0  # Current count of even numbers.
    count_odds: int = 0  # Current count of odd numbers.

    # Iterate array; count evens and odds.
    for a_num in my_array:
        if a_num % 2 == 0:
            count_evens += 1
        else:
            count_odds += 1

    # Calculate combinations of two even numbers.
    # Uses n * (n - 1) // 2 formula.
    many_even_values: int = (count_evens * (count_evens - 1)) // 2

    # Calculate combinations of two odd numbers.
    many_odd_values: int = (count_odds * (count_odds - 1)) // 2

    # Sum up valid pair counts.
    current_overall_sum: int = many_even_values + many_odd_values
    return current_overall_sum