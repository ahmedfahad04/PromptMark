def mul_even_odd(my_nums_input: list) -> int:
    """
    Computes the product of the first even and first odd numbers found in a given list.

    Args:
        my_nums_input: A list of integers. Assumes the list contains at least one
                       even and one odd number based on problem constraints.

    Returns:
        An int, which is the product of the first even and first odd numbers.
    """
    my_winnin_even_val = None
    my_winnin_odd_val = None

    for a_num in my_nums_input:
        # Assian first even val.
        if my_winnin_even_val is None and a_num % 2 == 0:
            my_winnin_even_val = a_num
        # Assian first odd val.
        elif my_winnin_odd_val is None and a_num % 2 != 0:
            my_winnin_odd_val = a_num

        # If both are available, finish and return.
        if my_winnin_even_val is not None and my_winnin_odd_val is not None:
            return my_winnin_even_val * my_winnin_odd_val

    # Under normal operation with valid inputs (containing both even and odd),
    # the function will always return inside the loop.
    # This line is a safe_guard if the list somehow ends without both.
    # Given problem, we assume both will always exist.
    return my_winnin_even_val * my_winnin_odd_val