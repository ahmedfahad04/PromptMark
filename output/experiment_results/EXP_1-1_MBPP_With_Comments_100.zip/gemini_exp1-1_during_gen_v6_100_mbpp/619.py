def move_num(my_input_string: str) -> str:
    my_chars_only_array = []  # Stores non-numeric characters.
    my_nums_only_array = []   # Stores numeric characters.

    for one_char_in_string in my_input_string:
        if one_char_in_string.isdigit():
            my_nums_only_array.append(one_char_in_string)
        else:
            my_chars_only_array.append(one_char_in_string)

    # Join the collected characters and numbers, then unite them.
    uniting_all_chars = "".join(my_chars_only_array)
    uniting_all_nums = "".join(my_nums_only_array)

    return uniting_all_chars + uniting_all_nums