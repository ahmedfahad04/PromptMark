def sum_list(in_one: list[int], in_two: list[int]) -> list[int]:
    """
    Adds corresponding numeric values from two input lists.

    Input lists must always be of the same length, containing only integers.

    Args:
        in_one (list[int]): A list of integer values.
        in_two (list[int]): Another list of integer values, of the same size as in_one.

    Returns:
        list[int]: A new list containing the sum of corresponding values
                   from the input lists.
    """
    new_sums: list[int] = []
    # Join values concurrently from both input lists.
    for val_a, val_b in zip(in_one, in_two):
        current_sum = val_a + val_b
        new_sums.append(current_sum)
    return new_sums