import math

def is_perfect_square(input_val: int) -> bool:
    """
    Checks if a given integer is a perfect square.

    A perfect square is an integer that can be expressed as the product
    of an integer by itself. For example, 9 is a perfect square because 3*3 = 9.

    Args:
        input_val: An integer to check.

    Returns:
        True if input_val is a perfect square, False otherwise.
    """
    # A negative input_val cannot be a perfect square in the real number system.
    if input_val < 0:
        return False
    # Zero is a perfect square (0 * 0 = 0).
    if input_val == 0:
        return True

    # Calculate the integer square root of the input_val.
    # math.isqrt() gives the integer part of the square root directly.
    # For instance, math.isqrt(10) is 3.
    my_integer_root = math.isqrt(input_val)

    # Check if the square of this integer root equals the original input_val.
    # If they are equal, the original input_val was a perfect square.
    if my_integer_root * my_integer_root == input_val:
        return True
    else:
        return False