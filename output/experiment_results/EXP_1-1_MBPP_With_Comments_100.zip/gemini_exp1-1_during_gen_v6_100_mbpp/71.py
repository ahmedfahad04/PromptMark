def comb_sort(my_array: list) -> list:
    """
    Sorts a list of elements using the Comb Sort algorithm.

    Comb Sort improves on Bubble Sort by eliminating "turtles",
    small values near the end of the list, which slow down Bubble Sort.
    It uses a larger 'gap' than 1 (as in Bubble Sort) and gradually shrinks it.
    """
    array_size = len(my_array)
    my_gap = array_size  # Initial 'gap' value, usually array_size
    shrink_constant = 1.3  # A common 'shrink factor' value
    swap_made = True  # Initialize to True to ensure the outer loop runs at least once

    # Loop continues as long as 'gap' is greater than 1 or a 'swap' was made
    while my_gap > 1 or swap_made:
        # Calculate the next 'gap' value
        # Using integer division to ensure 'gap' is an integer
        my_gap = int(my_gap / shrink_constant)
        if my_gap < 1:
            my_gap = 1  # Minimum 'gap' is 1, acts like Bubble Sort at the end

        swap_made = False  # Assume no swaps were made in this 'pass'

        # Perform a single 'pass' of Bubble Sort with the current 'gap'
        for current_idx in range(array_size - my_gap):
            if my_array[current_idx] > my_array[current_idx + my_gap]:
                # Swap elements if they are in the wrong order
                my_array[current_idx], my_array[current_idx + my_gap] = \
                    my_array[current_idx + my_gap], my_array[current_idx]
                swap_made = True  # A swap was made, so the list isn't fully sorted yet

    return my_array