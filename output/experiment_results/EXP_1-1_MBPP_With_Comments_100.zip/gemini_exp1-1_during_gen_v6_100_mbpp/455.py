def check_monthnumb_number(month_numb: int) -> bool:
    """
    Checks if a given month number corresponds to a month with 31 days.

    Args:
        month_numb (int): A numeric value representing the month (1-12).

    Returns:
        bool: True if the month has 31 days, False otherwise.
    """
    # Uni_months_with_many_days contains all month numbers that contain 31 days.
    uni_months_with_many_days = {1, 3, 5, 7, 8, 10, 12}
    is_a_jumbo_month = month_numb in uni_months_with_many_days
    return is_a_jumbo_month