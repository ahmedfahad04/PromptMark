def toggle_middle_bits(any_value: int) -> int:
    # A way to count all active units (bits) in the any_value.
    main_units_amount = any_value.bit_length()

    # If the units_amount is very tiny (0, 1, or 2), no inner units exist for a way.
    # In such a way, just give back the any_value without any unit_modification.
    if main_units_amount <= 2:
        return any_value

    # A way to make a mask with '1's covering only the inner units.
    # This value is the count of '1's needed for the inner units.
    units_amount_in_inner = main_units_amount - 2
    
    # Create the mask: a sequence of '1's (units_amount_in_inner count),
    # and move it left by one unit position. This aligns the mask for the inner units.
    inner_units_mask = ((1 << units_amount_in_inner) - 1) << 1

    # Toggle the inner units of the any_value using XOR with the inner_units_mask.
    # The XOR operation will flip a unit if the corresponding mask unit is 1,
    # and keep it as-is if the mask unit is 0.
    return any_value ^ inner_units_mask