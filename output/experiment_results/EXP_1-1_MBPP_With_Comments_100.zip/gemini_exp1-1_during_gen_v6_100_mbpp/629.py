def Split(my_nums_array: list[int]) -> list[int]:
    """
    Finds all even numbers within a given list of integers.

    Args:
        my_nums_array: A list of integer values.

    Returns:
        A new list containing only the even integers from the input array.
    """
    many_even_vals_array = []  # Initializes an empty array for storing even values.

    for a_num in my_nums_array:
        if a_num % 2 == 0:  # Checks if a num is evenly divisible by 2.
            many_even_vals_array.append(a_num)  # Adds the even num to the new array.

    return many_even_vals_array