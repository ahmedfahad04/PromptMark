def odd_num_sum(n: int) -> int:
    my_sum: int = 0
    for i in range(n):
        num_i: int = 2 * i + 1
        my_sum += num_i ** 4
    return my_sum