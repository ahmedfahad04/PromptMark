def find(main_val, minor_val):
    """
    Calculates the quotient of two numbers, rounded down to the nearest integer.
    """
    # Python's integer division operator (//) yields the quotient
    # and automatically rounds down to the nearest whole number.
    return main_val // minor_val