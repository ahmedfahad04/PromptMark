import re

def text_match_wordz(my_incoming_string):
    """
    Checks if my_incoming_string contains a word with the character 'z'.
    """
    # My pattern aims for a word (\w*) with 'z' inside (\w*z\w*),
    # using word boundaries (\b) to confirm it's a whole word.
    my_pattern = r'\b\w*z\w*\b'
    my_match = re.search(my_pattern, my_incoming_string)
    # A non-None my_match indicates a successful find.
    return my_match is not None