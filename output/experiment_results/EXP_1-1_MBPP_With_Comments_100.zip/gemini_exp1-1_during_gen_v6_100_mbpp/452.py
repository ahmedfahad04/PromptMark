def loss_amount(actual_cost, sale_amount):
    """
    Calculates the loss amount on a sale. If the actual cost is more than the
    sale amount, a loss occurs. Otherwise, no loss (or a profit) is made.

    Args:
        actual_cost (float or int): The initial value of the item.
        sale_amount (float or int): The money received from the item's sale.

    Returns:
        float or int: The amount of loss if a loss occurred, otherwise 0.
    """
    # Check if a cost is above current sale money.
    if actual_cost > sale_amount:
        # Missing money value.
        my_minus_amount = actual_cost - sale_amount
        return my_minus_amount
    else:
        # No missing value.
        return 0