def remove_lowercase(a_wording: str) -> str:
    """
    Yields a new wording with any lowercase chars removed.

    Args:
        a_wording: An input wording.

    Returns:
        A new wording containing only uppercase chars from the input.
    """
    my_outcome_wording = []
    for a_unit in a_wording:
        # Check if the unit is an uppercase char.
        if a_unit.isupper():
            my_outcome_wording.append(a_unit)
    return "".join(my_outcome_wording)