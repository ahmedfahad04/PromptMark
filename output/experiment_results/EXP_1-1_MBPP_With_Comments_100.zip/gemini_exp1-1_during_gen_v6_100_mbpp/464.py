def check_value(input_dict, my_value):
    # When input_dict has no items, it cannot all match my_value.
    # An empty dictionary logically cannot have all its (non-existent) values
    # be equal to a specific value.
    if not input_dict:
        return False

    # Walk on each value within the input_dict.
    for current_val in input_dict.values():
        # If a value is not my_value, we are out.
        # This indicates that not all values are similar to my_value.
        if current_val != my_value:
            return False

    # All values align.
    # If the loop completes, every value in the dictionary matched my_value.
    return True