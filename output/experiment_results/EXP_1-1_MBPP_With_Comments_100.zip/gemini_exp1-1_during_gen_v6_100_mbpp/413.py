def extract_nth_element(input_way_of_units: list[tuple], index_num: int) -> list:
    """
    Acquires the item at a specific index from all units (tuples) within an input list.

    Args:
        input_way_of_units: A list, containing many units (tuples).
        index_num: The specific index (position) of the item to access from each unit.

    Returns:
        A new list, containing only the items acquired from the specified index.
    """
    collected_items = []
    for unit_item in input_way_of_units:
        # Avoid issues with an invalid index by checking its validity within the unit_item.
        if 0 <= index_num < len(unit_item):
            collected_items.append(unit_item[index_num])
        # A common way is to assume valid input, or raise a Value Error.
        # For simplicity, if index is out of bounds, we simply skip adding an item
        # for that specific unit, aligning with how list comprehension might
        # implicitly handle it if not carefully managed.
    return collected_items