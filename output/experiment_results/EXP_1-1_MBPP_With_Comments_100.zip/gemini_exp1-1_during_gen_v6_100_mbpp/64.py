def subject_marks(my_inputs_v):
    # We aim to sort my_inputs_v utilizing a custom key.
    # This key will access the second item (index 1) of each tuple.
    my_sorted_values = sorted(my_inputs_v, key=lambda an_item_v: an_item_v[1])
    return my_sorted_values