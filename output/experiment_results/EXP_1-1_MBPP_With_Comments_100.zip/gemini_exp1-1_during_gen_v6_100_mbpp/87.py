def merge_dictionaries_three(my_one_map: dict, my_two_map: dict, my_many_map: dict) -> dict:
    """
    Unites three dictionaries into a single, new dictionary.

    When keys coincide, values from later dictionaries will overwrite
    values from earlier ones.

    Args:
        my_one_map: A primary input dictionary.
        my_two_map: A second input dictionary.
        my_many_map: A third input dictionary.

    Returns:
        A new dictionary containing all key-value pairings from the inputs.
    """
    my_unified_map = {**my_one_map, **my_two_map, **my_many_map}
    return my_unified_map