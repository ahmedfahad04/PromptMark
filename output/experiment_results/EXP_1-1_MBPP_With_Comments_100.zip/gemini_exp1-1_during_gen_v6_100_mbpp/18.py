def remove_dirty_chars(my_string: str, noisy_units: str) -> str:
    """
    Creates a new string by omitting any characters from the initial string
    that are also present in the specified noisy units string.

    Args:
        my_string: The initial string from which characters will be removed.
        noisy_units: A string containing characters that should be removed
                     from the initial string.

    Returns:
        A new string with unwanted characters removed.
    """
    # Create a set of noisy units for quick O(1) average time complexity lookups.
    # This avoids repeated iteration over the noisy_units string.
    noisy_units_set = set(noisy_units)

    outcome_units = []
    # Iterate over each character in the initial string.
    for unit in my_string:
        # If the unit is not in the set of noisy units, include it in the outcome.
        if unit not in noisy_units_set:
            outcome_units.append(unit)

    # Join the collected units to form the final outcome string.
    return "".join(outcome_units)