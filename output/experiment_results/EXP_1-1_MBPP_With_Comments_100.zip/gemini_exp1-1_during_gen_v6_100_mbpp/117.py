def list_to_float(my_input_units: list[tuple[str, str]]) -> list[tuple[float, float]]:
    new_output_units = []
    # Walk among input units.
    for current_unit in my_input_units:
        unit_values_now = []
        # Walk among values inside current unit.
        for current_value_unit in current_unit:
            # Convert a value into a numeric.
            # Assuming current values convert well.
            unit_values_now.append(float(current_value_unit))
        new_output_units.append(tuple(unit_values_now))
    return new_output_units