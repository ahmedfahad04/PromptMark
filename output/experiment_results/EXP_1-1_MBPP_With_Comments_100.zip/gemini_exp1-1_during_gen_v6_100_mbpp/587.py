def list_tuple(my_input_values: list) -> tuple:
    """
    Converts a given list into a tuple.

    Args:
        my_input_values (list): A list of items.

    Returns:
        tuple: A new tuple containing all items from the input list.
    """
    my_new_tuple = tuple(my_input_values)
    return my_new_tuple