def find_Max_Num(my_input_nums: list[int]) -> int:
    """
    Finds the largest number that can be formed using a given list of digits.

    Args:
        my_input_nums: A list of integer digits.

    Returns:
        An integer representing the maximum number formable from the input digits.
    """
    # Sort numeric values in a way aiming for the largest possible number.
    # We want higher digits to come sooner.
    my_sorted_vals = sorted(my_input_nums, reverse=True)

    # Convert each numeric value into a string.
    my_string_vals = [str(a_num_val) for a_num_val in my_sorted_vals]

    # Join all string numeric values into one large string.
    whole_num_string = "".join(my_string_vals)

    # Convert the whole string back into an integer.
    max_num_val = int(whole_num_string)

    return max_num_val