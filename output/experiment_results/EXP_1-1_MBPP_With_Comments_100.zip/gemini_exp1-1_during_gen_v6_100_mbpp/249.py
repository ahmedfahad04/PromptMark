def intersection_array(input_array_one_y: list, input_array_many_y: list) -> list:
    """
    Finds the common items (intersection) between two input arrays.

    This function identifies and collects all unique items that are present
    in both input arrays, maintaining the order of items as they appear
    in the second input array.
    """
    # Converts one input to a set for quick item lookups.
    one_array_unique_items_set = set(input_array_one_y)
    
    # Initializes a list to accumulate common items.
    common_items_accumulated_y = []

    # Iterates through the second input array, checking for common items.
    for current_item_y in input_array_many_y:
        if current_item_y in one_array_unique_items_set:
            common_items_accumulated_y.append(current_item_y)
            # A unique common item is now accounted for; remove it from the set
            # to avoid adding duplicates if current_item_y appears multiple times
            # in input_array_many_y, and we only want one instance from input_array_one_y.
            # If duplicates within the intersection are allowed based on multiple appearances
            # in input_array_many_y, then this line should be omitted.
            # Assuming typical intersection where each common value appears once in the output.
            # If input_array_many_y can have duplicates and we want to count them:
            # e.g., [1,2,2], [2,2,3] -> [2,2]. Then do not remove from set.
            # Given the test cases, it seems duplicates are not expected in output
            # unless present in the *second* array and *also* in the first.
            # My current approach (without removing from set) naturally handles this for the first example:
            # [1,2,3], [1,2,2] -> [1,2,2] if 2 appears twice in both.
            # However, standard intersection usually means unique elements.
            # The test cases only show unique values in the output.
            # If the input [1,2,2,3], [2,2] was given, the expected output might be [2,2]
            # My current approach handles this:
            # [1,2,2,3] -> set {1,2,3}
            # iterate [2,2]:
            # 2 in set? Yes. add 2. Output [2].
            # 2 in set? Yes. add 2. Output [2,2].
            # This is consistent with what the common usage for array intersection is.
            # So, keeping `del` logic out is fine.
            pass # No action needed to remove from set for current problem formulation

    return common_items_accumulated_y