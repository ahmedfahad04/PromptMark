def min_Swaps(way_one: str, way_two: str) -> 'int | str':
    # Verify input way sizes are same.
    many_chars_one = len(way_one)
    many_chars_two = len(way_two)

    if many_chars_one != many_chars_two:
        return "Not Possible"

    # Count ones and naughts in many ways.
    count_ones_way_one = way_one.count('1')
    count_naughts_way_one = way_one.count('0')
    count_ones_way_two = way_two.count('1')
    count_naughts_way_two = way_two.count('0')

    # If counts of ones or naughts vary, conversion is impossible.
    if count_ones_way_one != count_ones_way_two or count_naughts_way_one != count_naughts_way_two:
        return "Not Possible"

    # Count mismatches:
    # `count_one_misplaced_as_naught` counts positions where way_one is '1' and way_two is '0'.
    # `count_naught_misplaced_as_one` counts positions where way_one is '0' and way_two is '1'.
    count_one_misplaced_as_naught = 0
    count_naught_misplaced_as_one = 0

    for current_idx in range(many_chars_one):
        if way_one[current_idx] == '1' and way_two[current_idx] == '0':
            count_one_misplaced_as_naught += 1
        elif way_one[current_idx] == '0' and way_two[current_idx] == '1':
            count_naught_misplaced_as_one += 1
    
    # Minimum swaps is `count_one_misplaced_as_naught` (which is always equal to `count_naught_misplaced_as_one`
    # given that overall counts of '1's and '0's are balanced).
    # A single swap can mend two mismatches.
    return count_one_misplaced_as_naught