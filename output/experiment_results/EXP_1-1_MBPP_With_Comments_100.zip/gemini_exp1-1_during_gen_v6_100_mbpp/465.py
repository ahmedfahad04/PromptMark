def drop_empty(some_input_mapping: dict) -> dict:
    """
    Yields a new mapping, omitting mapping units with no value.
    """
    # Utilizes a comprehension, constructing a new mapping.
    # It includes an item only if its value is not None.
    new_valid_mapping = {
        key_unit: value_unit
        for key_unit, value_unit in some_input_mapping.items()
        if value_unit is not None
    }
    return new_valid_mapping