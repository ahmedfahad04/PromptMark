def occurance_substring(text, subtext):
  """
  This function returns the occurrence and position of the substrings within a string.
  """
  if subtext not in text:
    return None
  
  for i in range(len(text)):
    if text[i:i+len(subtext)] == subtext:
      return (subtext, i, i+len(subtext))