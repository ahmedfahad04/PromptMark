def remove_dirty_chars(str1, str2):
    """
    This function removes characters from the first string which are present in the second string.
    """
    str1_set = set(str1)
    str2_set = set(str2)
    clean_str = ''.join([char for char in str1 if char not in str2_set])
    return clean_str