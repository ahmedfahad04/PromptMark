def sum_even_and_even_index(nums):
  """
  This function returns the sum of even numbers at even positions of a list.
  """
  sum = 0
  for i, num in enumerate(nums):
    if i % 2 == 0 and num % 2 == 0:
      sum += num
  return sum