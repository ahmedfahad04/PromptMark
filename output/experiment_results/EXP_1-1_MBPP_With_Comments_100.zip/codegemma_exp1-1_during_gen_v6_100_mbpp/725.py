def extract_quotation(text):
  """
  Extracts values between quotation marks " " of the given string.

  Args:
    text: The string to extract values from.

  Returns:
    A list of values between quotation marks.
  """
  values = []
  in_quotation = False
  current_value = ""

  for char in text:
    if char == '"':
      in_quotation = not in_quotation
    elif in_quotation:
      current_value += char
    elif char == " " and current_value:
      values.append(current_value)
      current_value = ""

  if current_value:
    values.append(current_value)

  return values