def find_first_occurrence(arr, target):
  """
  Finds the index of the first occurrence of a given number in a sorted array.

  Args:
    arr: The sorted array.
    target: The number to find.

  Returns:
    The index of the first occurrence of the number, or -1 if it does not exist.
  """

  # Initialize the search range.
  low = 0
  high = len(arr) - 1

  # Binary search for the first occurrence of the number.
  while low <= high:
    mid = (low + high) // 2

    # If the middle element is the target, check if it is the first occurrence.
    if arr[mid] == target and (mid == 0 or arr[mid - 1] != target):
      return mid

    # If the middle element is less than the target, search the right half of the array.
    elif arr[mid] < target:
      low = mid + 1

    # If the middle element is greater than the target, search the left half of the array.
    else:
      high = mid - 1

  # The number was not found in the array.
  return -1