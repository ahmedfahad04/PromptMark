def find_lucas(n):
    """
    This function finds the n'th lucas number.
    """
    if n < 1:
        raise ValueError("Input must be a positive integer.")
    elif n == 1:
        return 2
    elif n == 2:
        return 1
    else:
        a, b = 2, 1
        for i in range(n - 2):
            a, b = b, a + b
        return b