from math import sqrt

def otherside_rightangle(side1, side2):
    """
    This function takes two sides of a right angled triangle and returns the length of the third side.
    """
    return sqrt(side1**2 + side2**2)