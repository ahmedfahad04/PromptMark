def empty_dit(list_of_dicts):
    """
    Checks if all dictionaries in a list are empty or not.

    Args:
    list_of_dicts: A list of dictionaries.

    Returns:
    True if all dictionaries in the list are empty, False otherwise.
    """
    for dictionary in list_of_dicts:
        if dictionary:
            return False
    return True