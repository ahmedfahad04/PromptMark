def square_nums(nums):
  """
  This function takes a list of numbers and returns a new list with the squares of the individual elements in the input list.
  """
  return [num**2 for num in nums]