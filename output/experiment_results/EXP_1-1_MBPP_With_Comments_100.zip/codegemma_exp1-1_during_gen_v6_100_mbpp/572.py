def two_unique_nums(nums):
  """
  This function removes duplicate numbers from a given number of lists.
  """
  unique_nums = set()
  for num in nums:
    unique_nums.add(num)
  return list(unique_nums)