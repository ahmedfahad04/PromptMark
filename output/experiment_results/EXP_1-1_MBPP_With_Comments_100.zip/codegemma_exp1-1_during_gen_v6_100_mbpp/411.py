def snake_to_camel(snake_str):
  """
  Converts a snake case string to camel case string.
  """
  camel_str = ''.join([word.capitalize() for word in snake_str.split('_')])
  return camel_str