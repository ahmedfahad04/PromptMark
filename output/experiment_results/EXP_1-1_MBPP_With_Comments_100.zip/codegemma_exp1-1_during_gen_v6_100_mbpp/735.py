def toggle_middle_bits(num):
    """
    This function toggles the middle bits of a number except the first and the last bit.
    """
    num = num & 0b1111110000000000
    num = num | 0b0000001111111111
    return num