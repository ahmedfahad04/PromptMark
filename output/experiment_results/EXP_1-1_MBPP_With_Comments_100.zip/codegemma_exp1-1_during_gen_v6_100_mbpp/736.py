def left_insertion(arr, val):
  """
  This function returns the left insertion point for a specified value in sorted order.
  """
  # Your code here
  return -1