def frequency_lists(list_of_lists):
    """
    This function takes a flattened list of lists and returns a dictionary of the frequency of each element.
    """
    frequency = {}
    for sublist in list_of_lists:
        for element in sublist:
            if element in frequency:
                frequency[element] += 1
            else:
                frequency[element] = 1
    return frequency