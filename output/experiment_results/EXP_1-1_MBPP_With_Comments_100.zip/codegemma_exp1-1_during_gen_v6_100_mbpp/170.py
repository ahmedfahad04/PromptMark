def sum_range_list(nums, start, end):
  """
  This function takes a list of numbers and two indices as input and returns the sum of the numbers in the list between the two indices (inclusive).
  """
  if start < 0 or end >= len(nums) or start > end:
    raise ValueError("Invalid indices")
  
  sum = 0
  for i in range(start, end + 1):
    sum += nums[i]
  
  return sum