def find_adverbs(text):
  adverbs = []
  for i, word in enumerate(text.split()):
    if word.endswith('ly') and word.isalpha():
      adverbs.append(f"{i}-{len(word):d}: {word}")
  return '\n'.join(adverbs)