def check_value(dict,value):
  for key in dict.keys():
    if dict[key]!=value:
      return False
  return True