def group_tuples(tuples):
    """
    Finds common first element in given list of tuple.
    """
    result = []
    for i in range(len(tuples)):
        if i == 0:
            result.append((tuples[i],))
        elif tuples[i][0] == tuples[i - 1][0]:
            result[-1] += (tuples[i],)
        else:
            result.append((tuples[i],))
    return result