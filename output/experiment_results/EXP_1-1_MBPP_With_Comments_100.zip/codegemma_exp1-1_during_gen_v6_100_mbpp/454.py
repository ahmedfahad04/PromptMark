def text_match_wordz(text):
    """
    Checks if a word in the given text contains 'z'.
    """
    return "z" in text