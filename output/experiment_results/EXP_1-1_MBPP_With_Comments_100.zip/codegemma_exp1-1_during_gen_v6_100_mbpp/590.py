import math

def polar_rect(rho, theta):
    """
    Converts polar coordinates to rectangular coordinates.

    Args:
        rho: The radius of the point in polar coordinates.
        theta: The angle of the point in polar coordinates.

    Returns:
        A tuple containing the rectangular coordinates of the point.
    """
    x = rho * math.cos(theta)
    y = rho * math.sin(theta)
    return (x, y), (-2+2.4492935982947064e-16j)