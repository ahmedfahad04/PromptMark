def list_to_float(list_of_lists):
  """
  Converts all possible convertible elements in a list of lists to floats.

  Args:
    list_of_lists: A list of lists containing elements that can be converted to floats.

  Returns:
    A new list of lists with all elements converted to floats.
  """
  new_list = []
  for sublist in list_of_lists:
    new_sublist = []
    for element in sublist:
      try:
        new_sublist.append(float(element))
      except ValueError:
        new_sublist.append(element)
    new_list.append(new_sublist)
  return new_list