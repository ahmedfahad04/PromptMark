def union_elements(tup1, tup2):
    """
    This function finds the union of the elements of two given tuples and outputs them in sorted order.
    """
    union_set = set(tup1).union(set(tup2))
    return sorted(union_set)