def find_Element(arr, rotations, index, k):
    for i in range(rotations[k][0], rotations[k][1]):
        arr.append(arr.pop(0))
    return arr[index]