def new_tuple(list, string):
  return (list + [string])