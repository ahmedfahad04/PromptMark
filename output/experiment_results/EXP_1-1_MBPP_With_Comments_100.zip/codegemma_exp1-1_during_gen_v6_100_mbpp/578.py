def interleave_lists(list1, list2, list3):
    """
    Interleaves three lists of the same length into a single flat list.

    Args:
        list1: The first list.
        list2: The second list.
        list3: The third list.

    Returns:
        A new list containing the interleaved elements from the three input lists.
    """
    result = []
    for i in range(len(list1)):
        result.append(list1[i])
        result.append(list2[i])
        result.append(list3[i])
    return result