def extract_string(str_list, size):
  return [str for str in str_list if len(str)>=size]