def pair_wise(list):
    """
    This function returns a list of all pairs of consecutive items in a given list.
    """
    return [(list[i], list[i + 1]) for i in range(len(list) - 1)]