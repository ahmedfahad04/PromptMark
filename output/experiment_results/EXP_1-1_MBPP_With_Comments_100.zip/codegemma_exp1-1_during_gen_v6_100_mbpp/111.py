def common_in_nested_lists(lists):
    """
    This function takes a list of lists and returns a set of common elements in all the lists.
    """
    common_elements = set()
    for lst in lists:
        for element in lst:
            if element in common_elements:
                continue
            common_elements.add(element)
    return common_elements