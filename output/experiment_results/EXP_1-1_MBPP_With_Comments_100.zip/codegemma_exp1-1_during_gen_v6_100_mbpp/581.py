def surface_Area(base, height):
    """
    This function calculates the surface area of a square pyramid with a given base edge and height.
    """
    area = (base**2 + (base**2 * (height**0.5)) + (base**2 * (height**0.5))) * 0.5
    return area