def move_num(s):
  """
  Moves all the numbers to the end of the given string.
  """
  num = []
  str_list = []
  for i in s:
    if i.isdigit():
      num.append(i)
    else:
      str_list.append(i)
  return ''.join(str_list) + ''.join(num)