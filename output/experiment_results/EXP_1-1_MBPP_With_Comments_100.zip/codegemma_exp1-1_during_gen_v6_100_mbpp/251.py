def insert_element(list, element):
    """
    This function takes in a list and an element and inserts the element before each element in the list, and returns the resulting list.
    """
    result = []
    for item in list:
        result.append(element)
        result.append(item)
    return result