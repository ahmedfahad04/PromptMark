def remove_whitespaces(text):
    """
    Removes all whitespaces from the given string.
    """
    return text.replace(' ', '')