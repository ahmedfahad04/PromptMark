def extract_singly(nested_list):
    """
    This function flattens a list of lists into a single set of numbers.
    """
    flattened_set = set()
    for sublist in nested_list:
        for number in sublist:
            flattened_set.add(number)
    return flattened_set