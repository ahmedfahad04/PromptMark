def string_to_tuple(text):
  """
  Converts a string to a tuple of characters.
  """
  return tuple(text)