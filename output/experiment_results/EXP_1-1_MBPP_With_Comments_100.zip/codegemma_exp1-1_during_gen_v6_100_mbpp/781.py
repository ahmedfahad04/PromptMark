def count_divisors(num):
  """
  This function checks whether the count of divisors of a number is even or not.
  """
  count = 0
  for i in range(1, num + 1):
    if num % i == 0:
      count += 1
  if count % 2 == 0:
    return True
  else:
    return False