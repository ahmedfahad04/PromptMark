def largest_subset(nums):
  # Your code here
  return largest_size