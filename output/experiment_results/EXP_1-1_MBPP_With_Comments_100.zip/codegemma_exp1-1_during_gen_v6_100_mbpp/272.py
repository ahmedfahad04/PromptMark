def rear_extract(data):
  """
  This function takes in a list of tuples and returns a list containing the rear element of each tuple.
  """
  return [item[-1] for item in data]