import math

def multiply_num(num_list):
  """
  This function multiplies all the numbers in a list and divides with the length of the list.
  """
  result = 1
  for num in num_list:
    result *= num
  return result / len(num_list)