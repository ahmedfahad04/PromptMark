def drop_empty(data):
    """
    Drops empty items from a dictionary.
    """
    return {key: value for key, value in data.items() if value is not None}