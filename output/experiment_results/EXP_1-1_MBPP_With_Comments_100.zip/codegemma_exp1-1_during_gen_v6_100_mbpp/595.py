def min_Swaps(num1, num2):
    """
    This function takes two binary numbers as input and returns the minimum number of swaps required to convert one to the other.
    """
    if num1 == num2:
        return "Not Possible"
    
    num1_list = list(num1)
    num2_list = list(num2)
    
    num1_list.sort()
    num2_list.sort()
    
    if num1_list == num2_list:
        return "Not Possible"
    
    num1_set = set(num1_list)
    num2_set = set(num2_list)
    
    if num1_set != num2_set:
        return "Not Possible"
    
    num1_count = num1_list.count("1")
    num2_count = num2_list.count("1")
    
    if abs(num1_count - num2_count) > 1:
        return "Not Possible"
    
    if num1_count == num2_count:
        return "Not Possible"
    
    if num1_count > num2_count:
        return num1_count - num2_count
    
    if num2_count > num1_count:
        return num2_count - num1_count