def trim_tuple(tup_list, k):
  """
  This function trims each tuple in a list by k in the given tuple list.
  """
  return '[' + ', '.join(['(' + ', '.join([str(i) for i in tup[:k]]) + ')' for tup in tup_list]) + ']'