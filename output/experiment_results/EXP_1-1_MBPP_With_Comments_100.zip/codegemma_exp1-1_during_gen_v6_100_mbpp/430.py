def parabola_directrix(a,b,c):
    """
    This function returns the directrix of a parabola given the equation of the parabola in the form of ax^2 + bx + c = 0.
    """
    if a == 0:
        raise ValueError("a cannot be zero")
    
    directrix = - (b**2 - 4*a*c)/(4*a)
    return directrix