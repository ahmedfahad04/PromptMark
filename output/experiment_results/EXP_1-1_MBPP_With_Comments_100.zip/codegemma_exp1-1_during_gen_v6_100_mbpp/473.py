def tuple_intersection(tuple_list1, tuple_list2):
  """
  This function finds the tuple intersection of elements in the given tuple list irrespective of their order.
  """
  set1 = set(tuple_list1)
  set2 = set(tuple_list2)
  return set1 & set2