def replace_char(text, char, new_char):
  """
  This function replaces all occurrences of a character in a string with a new character.
  """
  return text.replace(char, new_char)