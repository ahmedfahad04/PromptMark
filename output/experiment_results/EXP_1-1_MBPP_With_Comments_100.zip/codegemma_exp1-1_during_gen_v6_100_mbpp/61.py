def count_Substrings(num):
    count = 0
    for i in range(len(num)):
        for j in range(i + 1, len(num) + 1):
            substring = num[i:j]
            if int(substring) == len(substring):
                count += 1
    return count