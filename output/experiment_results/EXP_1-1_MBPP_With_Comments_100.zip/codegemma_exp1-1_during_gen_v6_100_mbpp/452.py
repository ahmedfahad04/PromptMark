def loss_amount(amount_in, amount_out):
    if amount_in > amount_out:
        return amount_in - amount_out
    else:
        return 0