def find_Max_Num(nums):
    nums.sort(key=str, reverse=True)
    return int("".join(nums))