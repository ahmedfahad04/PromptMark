def count_bidirectional(tuples):
    """
    Counts bidirectional tuple pairs in a list of tuples.
    """
    bidirectional_pairs = set()
    for a, b in tuples:
        if (b, a) in bidirectional_pairs:
            bidirectional_pairs.add((a, b))
        else:
            bidirectional_pairs.add((a, b))
    return len(bidirectional_pairs)