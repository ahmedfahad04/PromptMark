def list_tuple(list):
  """
  Converts a list to a tuple.
  """
  return tuple(list)