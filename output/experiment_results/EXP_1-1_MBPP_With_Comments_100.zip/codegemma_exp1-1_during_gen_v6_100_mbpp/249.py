def intersection_array(arr1, arr2):
  """
  This function finds the intersection of two arrays.
  """
  # Create a set of the first array
  set1 = set(arr1)
  # Create a set of the second array
  set2 = set(arr2)
  # Find the intersection of the two sets
  intersection = set1 & set2
  # Return the intersection as a list
  return list(intersection)