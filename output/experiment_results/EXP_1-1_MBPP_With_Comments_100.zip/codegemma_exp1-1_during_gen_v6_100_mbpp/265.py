def list_split(list_to_split, n):
    """
    Splits a list for every nth element, returning a list of the resulting lists.
    """
    result = []
    for i in range(0, len(list_to_split), n):
        result.append(list_to_split[i:i+n])
    return result