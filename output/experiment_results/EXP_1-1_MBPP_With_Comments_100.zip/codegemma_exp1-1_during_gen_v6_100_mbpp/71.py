def comb_sort(array):
    gap = len(array)
    swapped = True
    
    while gap > 0 and swapped:
        swapped = False
        for i in range(gap, len(array)):
            j = i - gap
            
            if array[j] > array[j + gap]:
                array[j], array[j + gap] = array[j + gap], array[j]
                swapped = True
        gap //= 1
    
    return array