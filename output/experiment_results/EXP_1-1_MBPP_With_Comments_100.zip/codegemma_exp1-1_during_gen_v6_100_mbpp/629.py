def Split(List):
  """
  This function takes a list of numbers and returns a new list containing only the even numbers from the input list.
  """
  Even = []
  for number in List:
    if number % 2 == 0:
      Even.append(number)
  return Even