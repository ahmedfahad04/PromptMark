def count_rotation(nums):
  """
  Counts the number of rotations required to generate a sorted array.
  """
  # Your code here
  return rotations