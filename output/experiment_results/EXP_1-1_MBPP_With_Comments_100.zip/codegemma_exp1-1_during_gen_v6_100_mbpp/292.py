def find(num1, num2):
    """
    This function finds the quotient of two numbers (rounded down to the nearest integer).
    """
    quotient = num1 // num2
    return quotient