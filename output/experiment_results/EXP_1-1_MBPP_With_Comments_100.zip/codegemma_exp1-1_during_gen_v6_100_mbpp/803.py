def is_perfect_square(num):
  """
  Checks if the given number is a perfect square or not.

  Args:
    num: The number to check.

  Returns:
    True if the number is a perfect square, False otherwise.
  """
  if num < 0:
    return False
  sqrt = int(num**0.5)
  return sqrt**2 == num