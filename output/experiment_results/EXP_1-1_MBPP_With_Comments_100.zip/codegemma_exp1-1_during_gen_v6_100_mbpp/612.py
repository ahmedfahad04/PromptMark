def merge(data):
  """
  Merges a list of lists into two lists.
  """
  list1 = []
  list2 = []
  for sublist in data:
    list1.append(sublist[0])
    list2.append(sublist[1])
  return [list1, list2]