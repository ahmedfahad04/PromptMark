def median_trapezium(a,b,c):
  """
  This function calculates the median of the trapezium with sides a, b, c.
  """
  if a + b < c or b + c < a or c + a < b:
    raise ValueError("Invalid input: a + b must be greater than c, b + c must be greater than a, and c + a must be greater than b.")
  
  median = (a + b + c) / 2
  return median