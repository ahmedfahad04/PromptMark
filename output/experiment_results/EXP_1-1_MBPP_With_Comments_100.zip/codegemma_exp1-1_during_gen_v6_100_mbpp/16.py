def text_lowercase_underscore(text):
  """
  Checks if the input string contains sequences of lowercase letters joined with an underscore.

  Args:
    text: The input string.

  Returns:
    True if the input string contains sequences of lowercase letters joined with an underscore, false otherwise.
  """
  for i in range(len(text)):
    if text[i].islower():
      if i < len(text) - 1 and text[i + 1] == "_":
        if i > 0 and text[i - 1].islower():
          return True
  return False