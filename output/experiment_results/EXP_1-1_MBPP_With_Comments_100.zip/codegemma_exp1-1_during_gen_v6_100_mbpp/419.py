def round_and_sum(num_list):
    """
    This function takes a list of numbers and returns the total sum multiplied by the length of the list after rounding each number.
    """
    sum_of_rounded_nums = 0
    for num in num_list:
        sum_of_rounded_nums += round(num)
    return sum_of_rounded_nums * len(num_list)