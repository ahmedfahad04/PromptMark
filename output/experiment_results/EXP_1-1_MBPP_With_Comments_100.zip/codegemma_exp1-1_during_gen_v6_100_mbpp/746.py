from math import pi

def sector_area(radius, angle):
  if angle > 360:
    return None
  return (pi * radius**2 * angle) / 360