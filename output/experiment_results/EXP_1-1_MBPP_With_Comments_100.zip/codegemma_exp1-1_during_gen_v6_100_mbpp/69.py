def is_sublist(list1, sublist):
  """
  This function checks whether a list contains the given sublist or not.

  Args:
    list1: The main list.
    sublist: The sublist to be checked.

  Returns:
    True if the sublist is a sublist of the main list, False otherwise.
  """
  for i in range(len(list1)):
    if list1[i:i+len(sublist)] == sublist:
      return True
  return False