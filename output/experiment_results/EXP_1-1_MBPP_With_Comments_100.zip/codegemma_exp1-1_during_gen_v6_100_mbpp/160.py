def find_solution(a, b, n):
    """
    Finds the solution to the equation ax + by = n.

    Args:
        a: The coefficient of x.
        b: The coefficient of y.
        n: The constant term.

    Returns:
        A tuple containing the values of x and y that satisfy the equation, or None if no solution exists.
    """
    if a == 0:
        if b == 0:
            if n == 0:
                return (0, 0)
            else:
                return None
        else:
            if n % b == 0:
                return (0, n // b)
            else:
                return None
    else:
        if b == 0:
            if n % a == 0:
                return (n // a, 0)
            else:
                return None
        else:
            gcd = math.gcd(a, b)
            if n % gcd != 0:
                return None
            else:
                a_prime = a // gcd
                b_prime = b // gcd
                n_prime = n // gcd
                x = n_prime * a_prime
                y = n_prime * b_prime
                return (x, y)