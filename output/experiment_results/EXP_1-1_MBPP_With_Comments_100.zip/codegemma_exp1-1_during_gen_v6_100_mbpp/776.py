def count_vowels(text):
    """Counts the number of characters that have vowels as their neighbors in the given string."""
    vowels = {'a', 'e', 'i', 'o', 'u'}
    count = 0
    for i in range(len(text)):
        if i == 0 or i == len(text) - 1:
            continue
        if text[i - 1] in vowels and text[i + 1] in vowels:
            count += 1
    return count