def left_insertion(original_list: list[int], target_number: int) -> int:
    """
    Locates the left insertion point for a specified number in sorted order.
    This finds the first position where target_number can be inserted
    to maintain sorted order.
    """
    length_of_list = len(original_list)
    low_point = 0
    top_point = length_of_list - 1
    current_position = length_of_list  # Default position if target_number is larger than all list items

    # Perform a binary search to pinpoint the insertion location.
    while low_point <= top_point:
        center_point = (low_point + top_point) // 2
        list_number = original_list[center_point]

        # If list_number is less than the target_number,
        # the target number must be on the right side.
        if list_number < target_number:
            low_point = center_point + 1
        # If list_number is greater or equal to the target_number,
        # this center_point is a potential insertion point.
        # Check for earlier positions by moving top_point to the left.
        else:
            current_position = center_point
            top_point = center_point - 1
            
    return current_position