def list_split(original_list: list, num_parts: int) -> list:
    # Prepare the result_list.
    # It contains num_parts lists, each to collect current_objects.
    result_list = [[] for _ in range(num_parts)]

    # Loop through original_list to distribute current_objects.
    for current_position, current_object in enumerate(original_list):
        # Calculate part_choice for current_object.
        # This provides the current_object's target list index.
        part_choice = current_position % num_parts
        # Place current_object into its proper list.
        result_list[part_choice].append(current_object)

    return result_list