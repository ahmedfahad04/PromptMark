def min_Swaps(original_number_string: str, target_number_string: str) -> int | str:
    # Check if the lengths of the two binary number strings are not equal.
    length_original = len(original_number_string)
    length_target = len(target_number_string)
    
    if length_original != length_target:
        return "Not Possible"

    # Count the occurrences of '1's and '0's in both original and target number strings.
    count_ones_original = original_number_string.count('1')
    count_zeros_original = original_number_string.count('0')
    
    count_ones_target = target_number_string.count('1')
    count_zeros_target = target_number_string.count('0')

    # If the counts of '1's or '0's do not match, transformation by swaps is not possible.
    if count_ones_original != count_ones_target or count_zeros_original != count_zeros_target:
        return "Not Possible"

    # Count positions where the original number string has a '1' and the target number string has a '0'.
    # These are '1's that are in a '0' position relative to the target, and need to be moved.
    count_original_one_target_zero_positions = 0
    for position in range(length_original):
        if original_number_string[position] == '1' and target_number_string[position] == '0':
            count_original_one_target_zero_positions += 1
            
    # The minimum number of swaps needed is equal to the count of '1's that are incorrectly placed
    # where a '0' should be, according to the target. Each such '1' needs to swap with a '0' that
    # is incorrectly placed where a '1' should be.
    return count_original_one_target_zero_positions