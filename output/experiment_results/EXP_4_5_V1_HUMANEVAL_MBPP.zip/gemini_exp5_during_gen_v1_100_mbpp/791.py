def remove_nested(original_tuple: tuple) -> tuple:
    # Provisional list to collect non-tuple objects.
    provisional_list = []

    # Process original_tuple to check component types.
    for current_object in original_tuple:
        # Check if current_object is not a tuple type.
        if not isinstance(current_object, tuple):
            provisional_list.append(current_object)

    # Return the new tuple, created from the provisional list.
    return tuple(provisional_list)