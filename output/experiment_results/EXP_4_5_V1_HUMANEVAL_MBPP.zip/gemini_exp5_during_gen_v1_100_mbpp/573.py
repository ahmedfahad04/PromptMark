def unique_product(original_list: list) -> int:
    # current_collection of numbers from original_list.
    numbers_collection = set(original_list)
    
    # overall_product for final calculation.
    overall_product = 1
    
    # current_number from numbers_collection.
    for current_number in numbers_collection:
        overall_product *= current_number
        
    return overall_product