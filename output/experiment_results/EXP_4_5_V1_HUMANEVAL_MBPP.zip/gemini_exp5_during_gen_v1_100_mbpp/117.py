def list_to_float(original_list):
    # Final list for processed tuples.
    result_list = []

    # Traverse each tuple in original list.
    for current_tuple in original_list:
        # Construct list for float objects of current tuple.
        current_parts_list = []

        # Process each original object.
        for original_object in current_tuple:
            # Try float conversion.
            try:
                current_float_object = float(original_object)
                current_parts_list.append(current_float_object)
            except ValueError:
                # Preserve original object.
                current_parts_list.append(original_object)
        
        # Append processed tuple.
        result_list.append(tuple(current_parts_list))

    return result_list