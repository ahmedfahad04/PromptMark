def trim_tuple(given_tuple_list, trim_position_count):
    # Collects processed tuples.
    output_list_of_tuples = []
    for original_tuple in given_tuple_list:
        # Generates current_trimmed_tuple through tuple cuts.
        current_trimmed_tuple = original_tuple[trim_position_count:-trim_position_count]
        output_list_of_tuples.append(current_trimmed_tuple)
    
    # Returns textual representation of output_list_of_tuples.
    # repr() provides correct formatting for tuples.
    return repr(output_list_of_tuples)