def sum_series(current_number: int) -> int:
    # grand_total: overall result.
    grand_total = 0
    # loop_limit: range for loop.
    loop_limit = current_number // 2

    # Process 'j' for positions.
    for j in range(loop_limit + 1):
        # Calculate position_term.
        position_term = current_number - (2 * j)
        # Post position_term to grand_total.
        grand_total += position_term

    return grand_total