def comb_sort(original_list):
    # current_list_preparation: Creates a current_list to operate upon.
    current_list = original_list[:]
    length = len(current_list)

    current_gap = length
    ordered_flag = False  # ordered_flag: Controls primary_loop operation.

    # primary_loop_operation: Continues until current_gap is one and current_list is ordered.
    while current_gap > 1 or not ordered_flag:
        # current_gap_reduction: Computes current_gap for next comparisons.
        current_gap = int(current_gap / 1.3)
        if current_gap < 1:
            current_gap = 1

        ordered_flag = True  # ordered_flag: Presumes current_list ordered for this pass.

        # current_pass_loop: Traverses current_list to compare objects with current_gap.
        for position in range(length - current_gap):
            # Check_positions_for_order: Compares current_position with current_position plus current_gap.
            if current_list[position] > current_list[position + current_gap]:
                # Perform_object_placement: Swaps current_list objects.
                temp = current_list[position]
                current_list[position] = current_list[position + current_gap]
                current_list[position + current_gap] = temp
                ordered_flag = False  # ordered_flag: Resets primary_loop control.
    
    return current_list