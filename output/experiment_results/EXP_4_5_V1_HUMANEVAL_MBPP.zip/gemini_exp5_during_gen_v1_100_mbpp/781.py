def count_divisors(num: int) -> bool:
    # Compute the number's float root.
    root_val = num ** 0.5
    # Floor of root for current check.
    floor_root = int(root_val)
    
    current_product = floor_root * floor_root
    if current_product == num:
        # Perfect root: total factor count odd.
        # Return False (not target output).
        return False
    else:
        # Non-perfect root: total factor count not odd.
        # Return True (target output).
        return True