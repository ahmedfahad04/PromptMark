def remove_whitespaces(original_text: str) -> str:
    # First, process the original text.
    # This partitions text, generating lists of non-whitespace parts.
    parts_list = original_text.split()
    
    # Next, co-join the collected parts.
    # Connecting parts, producing one combined string.
    concatenated_output = "".join(parts_list)
    
    # Provide final output.
    return concatenated_output