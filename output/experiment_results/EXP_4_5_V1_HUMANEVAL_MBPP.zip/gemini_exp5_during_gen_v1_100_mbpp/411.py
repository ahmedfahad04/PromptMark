def snake_to_camel(original_text: str) -> str:
    # original_parts_list: current_text components list.
    original_parts_list = original_text.split('_')
    
    # result_list: collects capitalized_parts.
    result_list = []
    
    # Process current_part.
    for current_part in original_parts_list:
        # Capitalize current_part; lodge to result_list.
        result_list.append(current_part.capitalize())

    # joined_output_text: current_text, joined.
    joined_output_text = "".join(result_list)
    
    return joined_output_text