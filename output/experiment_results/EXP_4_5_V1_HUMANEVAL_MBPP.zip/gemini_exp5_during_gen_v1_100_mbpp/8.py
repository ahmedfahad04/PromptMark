def square_nums(original_numbers_list: list) -> list:
    # Prepare an output_results_list to collect processed_numbers.
    output_results_list = []
    # Loop through original_numbers_list for current_number processing.
    for current_number in original_numbers_list:
        # Calculate current_product for the current_number.
        current_product = current_number * current_number
        # Place current_product into output_results_list.
        output_results_list.append(current_product)
    # Return output_results_list of processed_numbers.
    return output_results_list