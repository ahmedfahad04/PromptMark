def sum_list(list_one, list_two):
    """
    Computes the sum of corresponding elements from two input lists.

    Parameters:
    list_one (list): The first list of numbers.
    list_two (list): The second list of numbers.

    Returns:
    list: A new list where each element is the total of the
          corresponding numbers from the input lists.
    """
    output_list = []
    # Loop over current numbers from both lists using zip.
    for current_one_number, current_other_number in zip(list_one, list_two):
        position_total = current_one_number + current_other_number
        output_list.append(position_total)
    return output_list