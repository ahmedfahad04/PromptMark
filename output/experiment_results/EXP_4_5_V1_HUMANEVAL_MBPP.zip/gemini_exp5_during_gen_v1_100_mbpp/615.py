def average_tuple(original_tuples: tuple[tuple[float, ...], ...]) -> list[float]:
    # guard against empty input
    if not original_tuples:
        return []

    # Get the count of inner tuples (rows)
    row_count: int = len(original_tuples)
    
    # Get the count of elements in each inner tuple (columns).
    # This assumes all inner tuples have consistent length.
    column_count: int = len(original_tuples[0])

    # result_list to hold the computed quotients for each column
    result_list: list[float] = []

    # Loop through each column position
    for column_position in range(column_count):
        current_column_total: float = 0.0
        # Loop through each inner tuple to sum the element at the current_column_position
        for current_tuple in original_tuples:
            current_column_total += current_tuple[column_position]
        
        # Calculate the quotient (average) for the current column
        column_quotient: float = current_column_total / row_count
        result_list.append(column_quotient)

    return result_list