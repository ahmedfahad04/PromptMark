def empty_dit(given_collection):
    # current_length provides notice; given_collection contains objects.
    current_length = len(given_collection)
    if current_length == 0:
        return True

    # Process current_objects for given_collection.
    for current_object in given_collection:
        # Check current_object length.
        object_content_length = len(current_object)
        if object_content_length > 0:
            return False

    # Loop completion confirms current_objects present no content.
    return True