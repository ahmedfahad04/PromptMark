def find_first_occurrence(numbers_list: list[int], target_number: int) -> int:
    """
    Finds the index of the first occurrence of a given number in a sorted list.

    Args:
        numbers_list: A list of integers, sorted in non-decreasing order.
        target_number: The integer to find its first occurrence.

    Returns:
        The index of the first occurrence of the target number.
        Returns -1 if the target number is not present in the list.
    """
    low_position = 0
    high_position = len(numbers_list) - 1
    first_occurrence_position = -1  # Controls the current position of first occurrence

    while low_position <= high_position:
        current_mid_position = (low_position + high_position) // 2

        if numbers_list[current_mid_position] == target_number:
            # Current position could be the first occurrence
            first_occurrence_position = current_mid_position
            # Process left partition for possible earlier occurrence
            high_position = current_mid_position - 1
        elif numbers_list[current_mid_position] < target_number:
            # Target is on the right partition
            low_position = current_mid_position + 1
        else:  # numbers_list[current_mid_position] > target_number
            # Target is on the left partition
            high_position = current_mid_position - 1

    return first_occurrence_position