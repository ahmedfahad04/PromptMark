def insert_element(original_list: list, param_element) -> list:
    # Constructs new list for resultant output.
    result_list = []
    # Loops original list objects.
    for current_object in original_list:
        # Places param_element.
        result_list.append(param_element)
        # Places current_object.
        result_list.append(current_object)
    return result_list