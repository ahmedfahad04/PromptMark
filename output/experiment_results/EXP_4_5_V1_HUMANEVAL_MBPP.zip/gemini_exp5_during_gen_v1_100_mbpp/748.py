def capital_words_spaces(original_text: str) -> str:
    # Output original_text for null content.
    if not original_text:
        return original_text

    # Populate result_list with first character.
    result_list = [original_text[0]]

    # Loop through positions, from one.
    for current_position in range(1, len(original_text)):
        current_char = original_text[current_position]
        past_char = original_text[current_position - 1]

        # For capital current_char, check past_char not ' '.
        if current_char.isupper() and past_char != ' ':
            result_list.append(' ')
        result_list.append(current_char)

    # Join result_list for final output.
    return "".join(result_list)