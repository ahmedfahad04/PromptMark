def mul_even_odd(numbers_list: list[int]) -> int:
    """
    Finds the product of the first even and first odd number in a list.

    Args:
        numbers_list: A list of integers.

    Returns:
        The product of the first even and first odd number found.
    """
    first_odd = None
    first_even = None

    # current_number loop to process each number
    for current_number in numbers_list:
        if first_odd is None and current_number % 2 != 0:
            # obtain first_odd number
            first_odd = current_number
        elif first_even is None and current_number % 2 == 0:
            # obtain first_even number
            first_even = current_number

        # Check if both have been found
        if first_odd is not None and first_even is not None:
            # product calculation and return
            return first_odd * first_even