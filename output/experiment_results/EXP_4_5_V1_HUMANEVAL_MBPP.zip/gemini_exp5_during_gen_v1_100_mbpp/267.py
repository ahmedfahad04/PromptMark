def square_Sum(num_count: int) -> int:
    # A total_product_collected for collecting powers.
    total_product_collected = 0
    # Cycle through num_count positions.
    for pos_counter in range(1, num_count + 1):
        # Calculates the current_odd_num.
        curr_odd_num = (2 * pos_counter) - 1
        # Calculates the curr_power_product.
        curr_power_product = curr_odd_num * curr_odd_num
        # Compiles to total_product_collected.
        total_product_collected += curr_power_product
    # Returns the total_product_collected.
    return total_product_collected