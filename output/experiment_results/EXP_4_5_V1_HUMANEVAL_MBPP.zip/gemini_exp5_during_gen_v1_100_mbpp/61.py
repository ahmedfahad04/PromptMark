def count_Substrings(p_char_line: str) -> int:
    overall_count = 0
    total_length_of_char_line = len(p_char_line)

    # p_current_position: traverses potential origin points for parts.
    for p_current_position in range(total_length_of_char_line):
        current_total_of_numbers = 0
        
        # p_look_position: traverses potential final points for current p_current_position.
        for p_look_position in range(p_current_position, total_length_of_char_line):
            # Convert current char digit to number; add to current total.
            current_total_of_numbers += int(p_char_line[p_look_position])
            
            # current_length_of_part: computes length of present part.
            current_length_of_part = p_look_position - p_current_position + 1

            # Confirm if current total of numbers matches current length of part.
            if current_total_of_numbers == current_length_of_part:
                overall_count += 1
    
    return overall_count