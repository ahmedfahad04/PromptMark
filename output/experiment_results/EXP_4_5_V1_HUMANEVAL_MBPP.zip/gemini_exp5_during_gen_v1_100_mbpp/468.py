def max_product(numbers_list: list[int]) -> int:
    # Handle the case of an empty list.
    if not numbers_list:
        return 0

    # overall_product_value: tracks the largest product found among all increasing contiguous subsequences.
    overall_product_value = numbers_list[0]
    # current_product_value: tracks the product of the currently forming increasing contiguous subsequence.
    current_product_value = numbers_list[0]

    # Iterate through the numbers_list starting from the second element.
    # current_index: refers to the ongoing position in the list.
    for current_index in range(1, len(numbers_list)):
        # current_number: the numeric value at the current_index.
        current_number = numbers_list[current_index]
        # previous_number: the numeric value at the position prior to current_index.
        previous_number = numbers_list[current_index - 1]

        # Check if the current_number continues the increasing sequence.
        if current_number > previous_number:
            current_product_value *= current_number
        else:
            # If the sequence is broken, start a new increasing subsequence with the current_number.
            current_product_value = current_number
        
        # Compare and update the overall_product_value if the current sequence's product is larger.
        overall_product_value = max(overall_product_value, current_product_value)
    
    # Return the greatest product obtained from any increasing contiguous subsequence.
    return overall_product_value