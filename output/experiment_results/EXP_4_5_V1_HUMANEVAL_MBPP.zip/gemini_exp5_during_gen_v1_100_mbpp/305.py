def start_withp(given_list_of_phrases):
    # list_of_collected_p_tokens collects the target tokens.
    list_of_collected_p_tokens = []

    for phrase in given_list_of_phrases:
        # Partition the current phrase into current_tokens.
        for current_token in phrase.split():
            # Check if current_token commences with 'p' (case-normalized).
            if current_token.lower().startswith('p'):
                list_of_collected_p_tokens.append(current_token)
                # Present the pair once two tokens are located.
                if len(list_of_collected_p_tokens) == 2:
                    return (list_of_collected_p_tokens[0], list_of_collected_p_tokens[1])