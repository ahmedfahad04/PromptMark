def drop_empty(original_dict: dict) -> dict:
    # Creating new dictionary for result.
    filtered_dict = {}
    # Traversing original_dict items.
    for current_key, current_value in original_dict.items():
        # Checking current_value for non-None.
        if current_value is not None:
            # Placing key-value pair to filtered_dict.
            filtered_dict[current_key] = current_value
    return filtered_dict