import math

def greatest_common_divisor_process(operand_a, operand_b):
    """
    Calculates the greatest common divisor (gcd) of two numbers using the Extended Euclidean Algorithm,
    and returns corresponding coefficients 'x' and 'y' such that operand_a*x + operand_b*y = gcd(operand_a, operand_b).
    """
    if operand_a == 0:
        return operand_b, 0, 1
    
    # Recursive call to find gcd and coefficients for operand_b % operand_a and operand_a
    gcd_value, x_coefficient, y_coefficient = greatest_common_divisor_process(operand_b % operand_a, operand_a)
    
    # Calculate current x and y coefficients based on the recursive result
    current_x = y_coefficient - (operand_b // operand_a) * x_coefficient
    current_y = x_coefficient
    
    return gcd_value, current_x, current_y

def find_solution(operand_a, operand_b, target_n):
    """
    Finds integer solutions (x, y) for the linear Diophantine equation ax + by = n.
    Returns the solution as a tuple (x, y) or None if no solution exists.
    """
    # Obtain gcd and particular coefficients for operand_a*x + operand_b*y = gcd(operand_a, operand_b)
    gcd_value, x_particular_base, y_particular_base = greatest_common_divisor_process(operand_a, operand_b)

    # Check if a solution exists. A solution only exists if target_n is divisible by gcd_value.
    if target_n % gcd_value != 0:
        return None

    # Calculate the quotient_factor to scale the base particular solution to target_n
    quotient_factor = target_n // gcd_value

    # Calculate a particular solution (x_p, y_p) for operand_a*x + operand_b*y = target_n
    x_particular = x_particular_base * quotient_factor
    y_particular = y_particular_base * quotient_factor

    # Adjust the particular solution to find one that matches common positive/small integer expectation
    # The general solution is x = x_p + t * (operand_b / gcd_value) and y = y_p - t * (operand_a / gcd_value)
    
    # Calculate normalized coefficients for general solution adjustment
    # These represent (b/gcd) and (a/gcd) respectively
    coefficient_for_b_prime = operand_b // gcd_value
    coefficient_for_a_prime = operand_a // gcd_value

    # Handle the case where operand_b is zero. In this case, ax=n, so x=n/a, y can be 0.
    if coefficient_for_b_prime == 0: 
        return (x_particular, 0)
    
    # Calculate the normalized x value using modular arithmetic
    # This will find an x in the range [0, |coefficient_for_b_prime| - 1]
    # (x % m + m) % m is a common pattern to ensure positive results for modulo in Python
    normalized_x = (x_particular % coefficient_for_b_prime + coefficient_for_b_prime) % coefficient_for_b_prime
    
    # Calculate the corresponding 't' value that leads to normalized_x
    # t = (normalized_x - x_particular) / coefficient_for_b_prime
    total_factor = (normalized_x - x_particular) // coefficient_for_b_prime
    
    # Calculate the final x and y using the adjusted 't'
    final_x = x_particular + total_factor * coefficient_for_b_prime
    final_y = y_particular - total_factor * coefficient_for_a_prime
    
    return (final_x, final_y)