def remove_dirty_chars(primary_text: str, pattern_chars: str) -> str:
    # Creates a character pool for quick lookups of characters to remove.
    chars_pool = frozenset(pattern_chars)

    result_chars_list = []
    for current_char in primary_text:
        if current_char not in chars_pool:
            result_chars_list.append(current_char)
    
    # Joins collected characters to form the final result.
    return "".join(result_chars_list)