def rear_extract(current_list_of_tuples: list[tuple]) -> list:
    """
    Pulls out the rear element from each tuple in a given list.

    Parameters:
        current_list_of_tuples (list[tuple]): Original list, comprising of tuples.

    Returns:
        list: New list, comprising only the rear elements.
    """
    # Result_list collects last_position_components.
    return [current_tuple[-1] for current_tuple in current_list_of_tuples]