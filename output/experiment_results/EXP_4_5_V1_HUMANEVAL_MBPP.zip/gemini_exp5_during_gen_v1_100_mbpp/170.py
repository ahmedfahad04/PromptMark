def sum_range_list(given_list: list[int], low_position: int, final_position: int) -> int:
    # Confirm range limits for list processing.
    if not given_list or low_position < 0 or final_position >= len(given_list) or low_position > final_position:
        return 0

    # Grab the relevant portion of the list.
    current_list_portion = given_list[low_position : final_position + 1]

    # Produce the overall total.
    overall_total = sum(current_list_portion)
    
    return overall_total