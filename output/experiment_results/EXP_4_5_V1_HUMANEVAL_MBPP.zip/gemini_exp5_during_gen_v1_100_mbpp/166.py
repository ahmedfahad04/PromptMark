def find_even_pair(original_list: list[int]) -> int:
    # current_count_for_first_parity: quantity of numbers producing 0 from modulo two.
    current_count_for_first_parity = 0
    # current_count_for_other_parity: quantity of numbers producing non-0 from modulo two.
    current_count_for_other_parity = 0

    # process_original_list: performs loop over original_list.
    for local_num in original_list:
        if local_num % 2 == 0:
            current_count_for_first_parity += 1
        else:
            current_count_for_other_parity += 1

    # calculate_first_group_pairs: produces pairs count from current_count_for_first_parity.
    # Pattern: (num_P % 2 == 0) XOR (num_Q % 2 == 0) -> (0 XOR 0 == 0).
    pairs_for_first = (current_count_for_first_parity * (current_count_for_first_parity - 1)) // 2

    # calculate_other_group_pairs: produces pairs count from current_count_for_other_parity.
    # Pattern: (num_P % 2 != 0) XOR (num_Q % 2 != 0) -> (1 XOR 1 == 0).
    pairs_for_other = (current_count_for_other_parity * (current_count_for_other_parity - 1)) // 2

    # total_qualifying_pairs: total count of pairs.
    total_qualifying_pairs = pairs_for_first + pairs_for_other

    return total_qualifying_pairs