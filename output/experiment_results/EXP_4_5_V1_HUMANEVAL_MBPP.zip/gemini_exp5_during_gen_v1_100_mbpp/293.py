import math

def otherside_rightangle(first_leg_length: float, other_leg_length: float) -> float:
    """
    Calculates the length of the hypotenuse of a right-angled triangle
    given the lengths of its two legs.

    Args:
        first_leg_length (float): Length of the first leg.
        other_leg_length (float): Length of the other leg.

    Returns:
        float: The calculated length of the hypotenuse.
    """
    # Calculate the product of the first leg length with itself (squared).
    first_leg_product = first_leg_length ** 2
    # Calculate the product of the other leg length with itself (squared).
    other_leg_product = other_leg_length ** 2
    
    # Calculate the total sum of the products of the legs.
    total_sum_of_products = first_leg_product + other_leg_product
    
    # Calculate the result length by finding the square root of the total sum.
    result_length = math.sqrt(total_sum_of_products)
    
    return result_length