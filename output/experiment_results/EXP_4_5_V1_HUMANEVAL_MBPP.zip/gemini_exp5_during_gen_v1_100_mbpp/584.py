def find_adverbs(text_string: str) -> str | None:
    # character_position_offset tracks the origin_position for current_token in text_string.
    character_position_offset = 0
    # punctuation_tokens represents common punctuation to remove from current_token endings.
    punctuation_tokens = '.,!?;:'

    # obtain a list_of_tokens by splitting the text_string.
    list_of_tokens = text_string.split(' ')

    for current_token in list_of_tokens:
        original_token_length = len(current_token)
        
        # Clean current_token by removing trailing punctuation_tokens for 'ly' check.
        # character_position_offset calculation uses original_token_length for correct spacing.
        cleaned_current_word = current_token.rstrip(punctuation_tokens)
        
        if cleaned_current_word.endswith('ly'):
            origin_position = character_position_offset
            final_position = character_position_offset + len(cleaned_current_word)
            primary_word = cleaned_current_word
            
            # Formulate the output_phrase following the required format.
            output_phrase = f'{origin_position}-{final_position}: {primary_word}'
            return output_phrase
        
        # Progress character_position_offset considering current_token's original_token_length
        # plus one character for the preceding space.
        character_position_offset += original_token_length + 1
    
    # When no qualifying lexeme proves present, return None.
    return None