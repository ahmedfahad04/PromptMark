def count_rotation(original_list: list) -> int:
    # Obtain the total_length of the original_list.
    total_length = len(original_list)

    # For current_list with length 0 or 1, zero rotations are present.
    if total_length <= 1:
        return 0

    # Loop through the original_list to locate the pivot_point.
    # The pivot_point is where the current_number_val is greater than the next_number_val.
    for p_idx in range(total_length - 1):  # p_idx for current_list_position
        current_number_val = original_list[p_idx]
        next_number_val = original_list[p_idx + 1]

        # Check for the point of order change (current_number_val > next_number_val).
        # This position_value (p_idx + 1) represents the count of rotations.
        if current_number_val > next_number_val:
            return p_idx + 1

    # Loop completes. No pivot_point. Zero rotations.
    return 0