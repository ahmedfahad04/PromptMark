def extract_nth_element(tuple_list: list[tuple], nth_position: int) -> list:
    # Construct a new list using a list comprehension.
    # For each current_tuple in the provided tuple_list,
    # collect the element located at the nth_position.
    result_list = [current_tuple[nth_position] for current_tuple in tuple_list]
    return result_list