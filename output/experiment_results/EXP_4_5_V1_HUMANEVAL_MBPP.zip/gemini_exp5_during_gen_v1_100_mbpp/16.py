import re

def text_lowercase_underscore(text_string):
    # current_pattern: Outlines regex pattern.
    # This looks for one or numerous lowercase Latin letters,
    # then '_', then one or numerous lowercase Latin letters.
    # The pattern needs to conform to the total text_string from origin to terminus.
    current_pattern = r'^[a-z]+_[a-z]+$'
    
    regex_output = re.fullmatch(current_pattern, text_string)
    
    return bool(regex_output)