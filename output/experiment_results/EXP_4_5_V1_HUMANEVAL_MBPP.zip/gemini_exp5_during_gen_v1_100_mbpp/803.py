import math

def is_perfect_square(current_number: int) -> bool:
    # Check if the current_number is non-negative.
    # Negative numbers cannot be perfect squares of real numbers.
    if current_number < 0:
        return False

    # Calculate the root_number.
    # This produces a floating-point number.
    root_current = math.sqrt(current_number)

    # Convert the float root to its long part (integer part).
    # For example, if root_current is 3.0, long_part_root will be 3.
    # Long_part_root will be 3 for root_current 3.16... (floor operation).
    long_part_root = int(root_current)

    # Check if product of long_part_root with long_part_root equals the current_number.
    # This check confirms the long_part_root is the proper root.
    if long_part_root * long_part_root == current_number:
        return True
    else:
        return False