def loss_amount(current_price, original_cost):
    # current_price represents the selling price, original_cost represents the cost price.
    # Check if the selling price (current_price) is less than the cost price (original_cost).
    # This condition indicates a financial loss.
    if current_price < original_cost:
        # Calculate the total amount of the loss.
        total_loss = original_cost - current_price
        return total_loss
    else:
        # If the selling price is not less than the cost price (i.e., it's equal or greater),
        # there is no loss, so return 0.
        return 0