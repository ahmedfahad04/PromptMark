def pair_wise(original_list: list) -> list:
    """
    Produces a list of all pairs of consecutive items from the original_list.
    """
    result_list = []
    list_length = len(original_list)

    # Only process if original_list contains at least two items
    if list_length > 1:
        # Loop over original_list, current_position up to second-to-last item
        for current_position in range(list_length - 1):
            # Form a current_tuple with current and next items
            current_tuple = (original_list[current_position], original_list[current_position + 1])
            result_list.append(current_tuple)
    
    return result_list