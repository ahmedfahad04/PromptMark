def extract_singly(original_lists):
    """
    Flattens a list of lists (or tuples) into a single set of unique numbers.
    """
    result_set = set()  # output_collection to hold unique numbers

    for current_tuple in original_lists:  # parse current_tuple from original_lists
        for num_object in current_tuple:  # process num_object from current_tuple
            result_set.add(num_object)     # place num_object into result_set
            
    return result_set