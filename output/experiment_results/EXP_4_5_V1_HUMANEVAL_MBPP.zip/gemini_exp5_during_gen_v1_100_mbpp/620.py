def largest_subset(numbers_list: list[int]) -> int:
    # Check for trivial path: no length or one length list.
    list_length = len(numbers_list)
    if list_length <= 1:
        return list_length

    # First, order the given numbers_list.
    # This ordering property permits proper comparisons.
    numbers_list.sort()

    # Populate optimal_lengths list.
    # optimal_lengths[position] refers to the longest chain concluding numbers_list[position].
    optimal_lengths = [1] * list_length

    # Record overall_length for the longest path.
    overall_length = 1

    # Loop current_num for the numbers_list.
    for current_position in range(1, list_length):
        current_num = numbers_list[current_position]
        # Compare current_num, previous_num for prior positions.
        for previous_position in range(current_position):
            previous_num = numbers_list[previous_position]
            # Check for quotient property.
            if current_num % previous_num == 0:
                # Then, re-calculate optimal_lengths for current_position from previous_position's length.
                optimal_lengths[current_position] = max(
                    optimal_lengths[current_position],
                    1 + optimal_lengths[previous_position]
                )
        # Propagate overall_length from current_position's optimal_length.
        overall_length = max(overall_length, optimal_lengths[current_position])

    return overall_length