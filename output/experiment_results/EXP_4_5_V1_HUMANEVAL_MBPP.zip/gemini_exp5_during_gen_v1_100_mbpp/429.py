def and_tuples(tuple_one: tuple, tuple_other: tuple) -> tuple:
    """
    Performs an element-wise bitwise AND operation on two given tuples.

    Args:
        tuple_one (tuple): The first tuple of numbers.
        tuple_other (tuple): The second tuple of numbers.

    Returns:
        tuple: A new tuple containing the bitwise AND of corresponding elements.
    """
    output_list = []
    # Loop over pairs of numbers from both tuples.
    for num_one, num_other in zip(tuple_one, tuple_other):
        # Perform bitwise AND operation.
        current_result = num_one & num_other
        output_list.append(current_result)
    
    # Convert the list of results to a tuple.
    return tuple(output_list)