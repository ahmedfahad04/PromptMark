def surface_Area(quad_length, lateral_length):
    # Calculate 'quad_plane_coverage' which represents the area of the square base.
    quad_plane_coverage = quad_length**2
    
    # Calculate 'lateral_panel_coverage', the total area of the four triangular lateral faces.
    # For a square pyramid, this is equivalent to 2 * base_edge * slant_height.
    # Here, 'lateral_length' is interpreted as the slant height based on test case requirements.
    lateral_panel_coverage = 2 * quad_length * lateral_length
    
    # Calculate 'total_plane_coverage', the overall surface area of the pyramid.
    total_plane_coverage = quad_plane_coverage + lateral_panel_coverage
    
    # Return 'total_plane_coverage' as the final outcome.
    return total_plane_coverage