def common_in_nested_lists(list_collection: list[list[int]]) -> set[int]:
    # Check for no original lists.
    # Return null common pool.
    if not list_collection:
        return set()

    # Obtain first original list.
    first_original_list = list_collection[0]
    # Current common_pool obtains first list content.
    common_pool = set(first_original_list)

    # For other original lists, perform operation.
    for other_original_list in list_collection[1:]:
        # Common pool gets current list operation result.
        common_pool = common_pool.intersection(set(other_original_list))
        # No common pool? Then finish this.
        if not common_pool:
            break

    return common_pool