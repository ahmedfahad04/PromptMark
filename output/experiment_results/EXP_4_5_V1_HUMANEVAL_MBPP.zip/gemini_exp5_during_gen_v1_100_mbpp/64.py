def subject_marks(original_list):
    # current_tuple: The current tuple provided to the lambda function for key generation.
    # The lambda function returns the second element (index 1) of the current_tuple.
    # This value is then utilized as the primary key for sorting the original_list.
    result_list = sorted(original_list, key=lambda current_tuple: current_tuple[1])
    return result_list