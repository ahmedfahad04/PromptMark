def remove_Occ(original_plain_text, char_pattern):
    # Obtain first occurrence position for the char_pattern.
    first_occurrence_position = original_plain_text.find(char_pattern)

    # Confirm no pattern location. If not found, return original_plain_text.
    if first_occurrence_position == -1:
        return original_plain_text

    # Obtain last occurrence position for the char_pattern.
    last_occurrence_position = original_plain_text.rfind(char_pattern)

    # Only one occurrence case.
    if first_occurrence_position == last_occurrence_position:
        # Construct text, omit solo char.
        proc_plain_text = original_plain_text[:first_occurrence_position] + original_plain_text[first_occurrence_position + 1:]
        return proc_plain_text
    
    # Process for plural occurrences.
    # Construct text after removal of the first char_pattern.
    current_plain_text = original_plain_text[:first_occurrence_position] + original_plain_text[first_occurrence_position + 1:]
    
    # Obtain last char_pattern position in the current_plain_text.
    # Last occurrence position possibly changed.
    proc_last_position = current_plain_text.rfind(char_pattern)
    
    # Construct the final output, omitting the last char_pattern.
    final_output_plain_text = current_plain_text[:proc_last_position] + current_plain_text[proc_last_position + 1:]
    
    return final_output_plain_text