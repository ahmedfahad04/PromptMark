def Find_Max_Length(original_list: list[list[int]]) -> int:
    # overall_max_length tracks the longest length found.
    overall_max_length = 0

    # current_list provides each particular sublist for length checking.
    for current_list in original_list:
        current_length = len(current_list)
        # Compare current_length to overall_max_length.
        if current_length > overall_max_length:
            overall_max_length = current_length

    return overall_max_length