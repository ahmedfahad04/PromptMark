def new_tuple(original_list, plain_text):
    """
    Creates a new tuple by combining elements from a given list and a string.

    original_list: The list providing initial tuple elements.
    plain_text: The string to be appended as the last tuple element.
    """
    # Produce final_output_tuple by unpacking original_list and placing plain_text last.
    final_output_tuple = (*original_list, plain_text)
    
    return final_output_tuple