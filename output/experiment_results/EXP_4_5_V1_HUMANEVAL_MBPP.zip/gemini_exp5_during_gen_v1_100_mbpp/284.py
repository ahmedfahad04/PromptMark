def check_element(given_list, given_element):
    # Process each item in the given_list.
    for list_item in given_list:
        # Compare current list_item with the given_element.
        if list_item != given_element:
            # Present an unequal pair; quick return 'False'.
            return False
    # Overall, current list items match the given_element; return 'True'.
    # This also covers cases where the given_list is empty.
    return True