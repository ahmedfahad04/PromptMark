def move_num(original_text: str) -> str:
    # plain_chars_list: Chars list for non-numeric content.
    plain_chars_list = []
    # numeric_chars_list: Numeric list for number content.
    numeric_chars_list = []

    # Loop over current char for original_text.
    for current_char in original_text:
        # Check for current char represents one number.
        if current_char.isdigit():
            numeric_chars_list.append(current_char)
        else:
            plain_chars_list.append(current_char)

    # plain_chars_joined: Join plain characters.
    plain_chars_joined = "".join(plain_chars_list)
    # numeric_chars_joined: Join numeric characters.
    numeric_chars_joined = "".join(numeric_chars_list)

    # final_output_product: Combine plain chars plus numeric chars.
    final_output_product = plain_chars_joined + numeric_chars_joined
    return final_output_product