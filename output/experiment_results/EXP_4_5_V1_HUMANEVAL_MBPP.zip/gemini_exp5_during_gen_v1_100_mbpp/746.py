import math

def sector_area(radial_length, central_angle):
    # Consider_none_output: Central_angle larger than 360 triggers None output.
    if central_angle > 360:
        return None

    pi_constant = math.pi
    
    # Calculate_final_output: Final_output comes from (central_angle / 360) * pi_constant * radial_length^2.
    quotient_factor = central_angle / 360.0  # Quotient factor for portion of total circle.
    product_of_pi_and_radius_pow_two = pi_constant * (radial_length ** 2) # Product_calculation: pi_constant times radial_length to power two.
    final_output = quotient_factor * product_of_pi_and_radius_pow_two
    
    return final_output