def even_Power_Sum(n: int) -> int:
    # Computes the overall total of the first n even natural numbers, each raised to the fifth power.
    overall_total = 0

    # Proceeds for each of the first n even natural numbers.
    for p_position in range(1, n + 1):
        current_number = 2 * p_position  # current_number: computes the current even natural number.
        number_power = current_number ** 5 # number_power: calculates the current number raised to the fifth power.
        overall_total = overall_total + number_power # overall_total: collects the current number's power to the grand total.

    return overall_total