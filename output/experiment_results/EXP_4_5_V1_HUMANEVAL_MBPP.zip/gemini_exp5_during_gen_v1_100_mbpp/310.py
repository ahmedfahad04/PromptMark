def string_to_tuple(original_text: str) -> tuple:
    # Collects non-padding characters to form tuple.
    # Only includes characters that are not spaces.
    result_tuple = tuple(current_char for current_char in original_text if current_char != ' ')
    return result_tuple