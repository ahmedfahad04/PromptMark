import collections

def frequency_lists(original_list: list[list[int]]) -> dict[int, int]:
    """
    Calculates the frequency of each numerical element within a given
    list of lists, returning the result as a dictionary.

    The function first flattens the list of lists into a single list
    and then counts the occurrences of each unique number.

    Args:
        original_list: A list of lists, where each inner list contains numbers.

    Returns:
        A dictionary where keys are the numbers and values are their frequencies.
    """
    # Flattens the original_list into a single collection of numbers.
    collected_numbers = []
    for current_list in original_list:
        for current_number in current_list:
            collected_numbers.append(current_number)

    # Calculates the occurrence for each number.
    counts_output = collections.Counter(collected_numbers)
    
    # Could also be done manually:
    # counts_output = {}
    # for current_number in collected_numbers:
    #     counts_output[current_number] = counts_output.get(current_number, 0) + 1
    
    return counts_output