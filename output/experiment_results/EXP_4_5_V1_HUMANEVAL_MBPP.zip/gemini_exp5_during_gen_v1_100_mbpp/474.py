def replace_char(original_text: str, char_to_replace: str, char_for_placement: str) -> str:
    # Character lists provide a mutable sequence for modifications.
    output_char_list = list(original_text)
    total_length = len(output_char_list)

    for current_position in range(total_length):
        # Check current character for replacement.
        if output_char_list[current_position] == char_to_replace:
            output_char_list[current_position] = char_for_placement
    
    # Join characters back to form the final text.
    result_text = "".join(output_char_list)
    return result_text