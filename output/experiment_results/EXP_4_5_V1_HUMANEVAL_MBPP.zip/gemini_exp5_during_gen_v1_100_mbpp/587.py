def list_tuple(original_list: list) -> tuple:
    """
    Converts a Python list to a tuple.

    original_list: The list to convert.
    returns: A new tuple containing the elements from the original list.
    """
    # Performs the conversion of the current list.
    result_tuple = tuple(original_list)
    return result_tuple