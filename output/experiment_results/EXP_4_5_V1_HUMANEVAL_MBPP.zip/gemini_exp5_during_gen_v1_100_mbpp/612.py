def merge(list_of_lists: list[list]) -> list[list]:
    # Confirm list_of_lists not present, to prevent position challenges.
    if not list_of_lists:
        return []

    # Obtain column_quantity from length of first original_list.
    # column_quantity represents total number of resulting column lists.
    column_quantity = len(list_of_lists[0])
    
    # Populate result_list for column_quantity lists.
    result_list = [[] for _ in range(column_quantity)]

    # Process original_list objects.
    for original_list in list_of_lists:
        # Loop current_position plus column_object.
        for current_position, column_object in enumerate(original_list):
            # Place column_object to proper column list.
            result_list[current_position].append(column_object)
            
    # Return final transposed list of lists.
    return result_list