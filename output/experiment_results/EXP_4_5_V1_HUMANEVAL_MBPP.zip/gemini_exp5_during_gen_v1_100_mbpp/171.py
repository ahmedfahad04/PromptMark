def perimeter_pentagon(l_length: float) -> float:
    # Calculates perimeter of regular pentagon.
    # Current perimeter from product of length, constant count.
    n_count_of_lines = 5
    p_perimeter = l_length * n_count_of_lines
    return p_perimeter