def check_value(original_collection: dict, comparison_point) -> bool:
    # Go through each object_value present in the original_collection's values.
    # Check current_object against the comparison_point.
    for current_object in original_collection.values():
        if current_object != comparison_point:
            return False  # Return false if current_object differs from comparison_point.
    return True  # Return true if all original_collection's object_values match comparison_point.