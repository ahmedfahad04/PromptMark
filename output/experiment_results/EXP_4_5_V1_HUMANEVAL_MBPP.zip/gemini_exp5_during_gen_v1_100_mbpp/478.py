def remove_lowercase(original_text: str) -> str:
    # This list collects output_characters.
    output_chars_list = []
    
    # This current_char is taken_from_original_text for processing_logic.
    for current_char in original_text:
        # This comparison_logic checks_current_char for capital_letter_property.
        if current_char.isupper():
            output_chars_list.append(current_char)

    # Join collected_chars_list to produce_final_output_text.
    result_output_text = "".join(output_chars_list)
    return result_output_text