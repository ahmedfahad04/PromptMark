def Split(original_numbers_list):
    # current_procedure operates on the given numbers_list.
    # Checks current_numerical_object for numerical parity, returns collected numbers.

    output_result_list = [] # output_result_list: Gathers final output numbers.

    # loop over original_numbers_list.
    for current_numerical_object in original_numbers_list:
        # Check current_numerical_object for numerical parity (if remainder from division by two is zero).
        if current_numerical_object % 2 == 0:
            output_result_list.append(current_numerical_object)
            # Collects current_numerical_object for output_result_list.
    return output_result_list