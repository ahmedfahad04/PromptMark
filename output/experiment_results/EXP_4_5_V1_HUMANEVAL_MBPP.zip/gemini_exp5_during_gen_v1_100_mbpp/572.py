from collections import Counter

def two_unique_nums(original_list: list) -> list:
    """
    Computes a new list containing only numbers that occur precisely once
    in the original list.

    Args:
        original_list (list): The original collection of numbers.

    Returns:
        list: A new list with numbers that occur only one time.
    """
    # Counts occurrences of each number.
    occurrence_tracker = Counter(original_list)

    # Prepares the result list.
    result_list = []

    # Processes original list to preserve relative order.
    for current_number in original_list:
        # Only keeps numbers with one occurrence.
        if occurrence_tracker[current_number] == 1:
            result_list.append(current_number)
            
    return result_list