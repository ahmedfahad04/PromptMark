def Find_Min(original_list_of_lists):
    # Check for an empty list of lists.
    # No lists provided, cannot pinpoint a minimum.
    if not original_list_of_lists:
        return []

    # current_output_list: tracks the list portion found to have the current minimum length.
    current_output_list = original_list_of_lists[0]
    # current_minimum_length: records the length of the current_output_list.
    current_minimum_length = len(current_output_list)

    # loop through other list portions to pinpoint the one with the smallest length.
    for current_list_portion in original_list_of_lists[1:]:
        current_length = len(current_list_portion)
        if current_length < current_minimum_length:
            current_minimum_length = current_length
            current_output_list = current_list_portion
    
    return current_output_list