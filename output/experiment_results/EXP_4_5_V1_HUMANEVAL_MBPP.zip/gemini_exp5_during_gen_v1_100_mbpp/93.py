def power(power_base, power_ordinal):
    # Computes the value of power_base raised to power_ordinal.
    # Checks for zero ordinal conditions.
    if power_ordinal == 0:
        return 1

    negative_flag = False
    # Checks if the ordinal is negative.
    if power_ordinal < 0:
        negative_flag = True
        power_ordinal = -power_ordinal  # Operates on the positive ordinal for calculation
    
    current_product = 1
    # Loops 'power_ordinal' times to multiply the base.
    for loop_ordinal in range(power_ordinal):
        current_product *= power_base
    
    # Returns the final result, adjusting for negative ordinal if needed.
    if negative_flag:
        return 1 / current_product
    else:
        return current_product