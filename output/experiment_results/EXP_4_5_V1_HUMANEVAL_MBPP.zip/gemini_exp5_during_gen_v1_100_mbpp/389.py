def find_lucas(n: int) -> int:
    # Handle the initial cases for Lucas numbers.
    # Lucas number at position 0 (L_0) is 2.
    if n == 0:
        return 2
    # Lucas number at position 1 (L_1) is 1.
    if n == 1:
        return 1

    # For other positions, calculate iteratively.
    # Initialize the two previous lucas numbers.
    lucas_previous_two = 2  # Represents L(0)
    lucas_previous_one = 1  # Represents L(1)

    # Calculate lucas numbers from position 2 up to n.
    for current_position in range(2, n + 1):
        # The current lucas number is the sum of the two preceding ones.
        current_lucas_number = lucas_previous_one + lucas_previous_two
        
        # Prepare for the next iteration:
        # The new lucas_previous_two becomes the old lucas_previous_one.
        lucas_previous_two = lucas_previous_one
        # The new lucas_previous_one becomes the current_lucas_number.
        lucas_previous_one = current_lucas_number
    
    # After the loop, lucas_previous_one holds the N'th lucas number.
    return lucas_previous_one