def count_vowels(original_text: str) -> int:
    # pool of common vowel letters
    vowel_letters_pool = {'a', 'e', 'i', 'o', 'u'}
    total_count = 0
    current_length = len(original_text)

    # progress through each char_position in the original_text
    for char_position in range(current_length):
        current_char = original_text[char_position]

        # Only process if current_char is not a vowel
        if current_char not in vowel_letters_pool:
            left_char_is_vowel = False
            right_char_is_vowel = False

            # Check the left neighbor, if position allows
            if char_position > 0:
                left_neighbor_char = original_text[char_position - 1]
                if left_neighbor_char in vowel_letters_pool:
                    left_char_is_vowel = True

            # Check the right neighbor, if position allows
            if char_position < current_length - 1:
                right_neighbor_char = original_text[char_position + 1]
                if right_neighbor_char in vowel_letters_pool:
                    right_char_is_vowel = True

            # If the current_char (which is a consonant) has at least one vowel neighbor, count it
            if left_char_is_vowel or right_char_is_vowel:
                total_count += 1
    return total_count