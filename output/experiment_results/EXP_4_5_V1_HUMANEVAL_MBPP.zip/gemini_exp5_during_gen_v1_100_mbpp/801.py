def test_three_equal(num_one, num_two, num_tre):
    # Current count of numbers that possess common property.
    numbers_count = 0

    # Check: three numerical parameters possess common property.
    if num_one == num_two and num_two == num_tre:
        numbers_count = 3
    # Check: precisely two numerical parameters possess common property.
    elif num_one == num_two or num_one == num_tre or num_two == num_tre:
        numbers_count = 2

    return numbers_count