def occurance_substring(text_string, pattern):
    """
    Locates the first occurrence of a pattern within a text string,
    returning its origin and final positions.

    Args:
        text_string (str): The original text for processing.
        pattern (str): The pattern to locate.

    Returns:
        tuple: A tuple (pattern, origin_position, final_position) if found.
               None if the pattern is not present.
    """
    # Locate the pattern's first occurrence.
    origin_position = text_string.find(pattern)

    # Confirm no pattern found.
    if origin_position == -1:
        return None

    # Calculate the pattern's current length.
    current_length = len(pattern)

    # Calculate the pattern's final position.
    final_position = origin_position + current_length

    # Return the pattern, its origin, and final positions.
    return (pattern, origin_position, final_position)