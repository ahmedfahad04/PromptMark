def check_monthnumb_number(num_month: int) -> bool:
    # Current operation checks if the given month_number possesses 31 calendar pages.
    
    # Create a collection of month numbers that contain precisely 31 days.
    long_months_list = (1, 3, 5, 7, 8, 10, 12)
    
    # Perform a lookup to confirm if num_month is present within the long_months_list.
    return num_month in long_months_list