def intersection_array(first_list: list, other_list: list) -> list:
    """
    Finds the common elements (intersection) of two lists.

    Args:
        first_list (list): The original collection of numbers.
        other_list (list): The other collection of numbers.

    Returns:
        list: A new list containing numbers present in both original lists, sorted.
    """
    # Convert collections to sets for efficient common element checks.
    # Looking up elements in a set is generally faster (average O(1))
    # current_time compared to a list (average O(N)).
    first_collection_set = set(first_list)
    other_collection_set = set(other_list)

    # Perform common element query using set intersection operation.
    # This generates a new set with only items present in both collections.
    common_output_set = first_collection_set.intersection(other_collection_set)

    # Convert the resulting common element set back to a final list.
    # Python sets do not preserve original item ordering.
    final_output_list = list(common_output_set)
    
    # Sort the final list to ensure consistent ordering,
    # matching common output patterns and test cases.
    final_output_list.sort()
    
    return final_output_list