def tuple_intersection(list_one, list_other):
    # Collect canonical forms from the first list.
    # Canonical form means (min_component, max_component) to treat (a,b) and (b,a) as identical.
    canonical_collection_one = set()
    for current_tuple in list_one:
        first_component, other_component = current_tuple
        ordered_pair = tuple(sorted((first_component, other_component)))
        canonical_collection_one.add(ordered_pair)

    # Collect canonical forms from the other list.
    canonical_collection_other = set()
    for current_tuple in list_other:
        first_component, other_component = current_tuple
        ordered_pair = tuple(sorted((first_component, other_component)))
        canonical_collection_other.add(ordered_pair)

    # Find common (overlapping) tuples by performing a set intersection.
    common_tuples = canonical_collection_one.intersection(canonical_collection_other)
    
    return common_tuples