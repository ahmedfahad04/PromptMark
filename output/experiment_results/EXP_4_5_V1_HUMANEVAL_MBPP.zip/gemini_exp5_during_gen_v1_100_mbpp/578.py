def interleave_lists(list_one, list_two, list_thr):
    # Obtains the current_length, as all lists possess the same length.
    current_length = len(list_one)
    # Creates an output_list to collect interleaved elements.
    output_list = []

    # Loops over each position, pulling one element from each original list.
    for p in range(current_length):
        output_list.append(list_one[p])
        output_list.append(list_two[p])
        output_list.append(list_thr[p])

    return output_list