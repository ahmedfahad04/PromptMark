import re

def extract_quotation(text_string: str) -> list[str]:
    # processes the text to collect content present within double quotation marks.
    
    # pattern captures content located between double quotation marks.
    pattern = r'"([^"]*)"'
    
    # collects all occurrences matching the pattern into a list.
    quotation_list = re.findall(pattern, text_string)
    
    # provides the collected list of quotation content.
    return quotation_list