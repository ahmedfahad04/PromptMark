def rectangle_area(principal_length, cross_length):
    # Calculates the total planar region.
    # The product of two orthogonal lengths provides the total region.
    product_of_lengths = principal_length * cross_length
    return product_of_lengths