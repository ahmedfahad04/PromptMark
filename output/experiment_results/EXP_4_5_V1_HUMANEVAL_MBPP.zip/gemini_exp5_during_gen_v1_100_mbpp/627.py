def find_First_Missing(original_list: list) -> int:
    # First, check if the natural number 0 is present. If not, 0 is the smallest missing number.
    if not original_list or original_list[0] != 0:
        return 0

    # Process the original_list to find the first position where the number does not match its index.
    length = len(original_list)
    for pos in range(length):
        current_number = original_list[pos]
        # Check if the current_number matches its expected position (index).
        # For a sorted list of natural numbers, original_list[pos] should equal pos if no numbers are missing before it.
        if current_number != pos:
            # The position 'pos' is the first missing natural number.
            return pos
    
    # If the loop completes, it means all numbers from 0 to (length - 1) are present.
    # Therefore, the next natural number, which is 'length', is the smallest missing number.
    return length