def find(original_number: int, operand_for_division: int) -> int:
    # Calculate quotient per floor parting.
    quotient_result = original_number // operand_for_division
    return quotient_result