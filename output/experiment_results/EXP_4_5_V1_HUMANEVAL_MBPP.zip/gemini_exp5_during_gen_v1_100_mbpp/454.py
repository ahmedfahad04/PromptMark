import re

def text_match_wordz(text_string: str) -> bool:
    # Construct the regular pattern.
    # Pattern looks for one group of characters containing 'z'.
    # This pattern requires 'z' part of full text group.
    current_pattern = r'\b\w*z\w*\b'
    
    # Perform regex operation.
    # Obtain result from the re.search operation.
    current_result = re.search(current_pattern, text_string)
    
    # Check for presence of the pattern output.
    # Provided current_result presents, then pattern occurrence.
    if current_result:
        return True
    return False