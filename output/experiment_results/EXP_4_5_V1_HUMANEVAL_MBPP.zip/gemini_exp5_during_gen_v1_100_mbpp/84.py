def sequence(num_position: int) -> int:
    # Look for original ordinal positions (1 or 2).
    if num_position == 1 or num_position == 2:
        return 1

    # Populate list to collect conway numbers.
    # numbers_list[current_list_position] stores P(current_list_position + 1).
    numbers_list = [0] * num_position 
    numbers_list[0] = 1 # P(1)
    numbers_list[1] = 1 # P(2)

    # Calculate next ordinal numbers using the Newman-Conway recurrence.
    # current_list_position is the 0-based index for P(current_list_position + 1).
    for current_list_position in range(2, num_position):
        # The prior ordinal content: P(current_list_position).
        prior_ordinal_content = numbers_list[current_list_position - 1]

        # First term: P(P(current_list_position)).
        # Result computed from P(current_list_position) as ordinal position.
        first_term_result = numbers_list[prior_ordinal_content - 1]

        # Other term: P((current_list_position + 1) - P(current_list_position)).
        # This computes the ordinal position for P and then fetches the content.
        other_term_result = numbers_list[current_list_position - prior_ordinal_content]
        
        # current_result holds the computed P(current_list_position + 1).
        current_result = first_term_result + other_term_result
        numbers_list[current_list_position] = current_result
    
    # Return the final requested number, P(num_position).
    return numbers_list[num_position - 1]