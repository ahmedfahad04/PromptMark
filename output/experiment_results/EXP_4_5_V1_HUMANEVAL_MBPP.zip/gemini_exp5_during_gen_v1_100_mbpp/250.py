def count_X(original_tuple, object_to_count):
    # Occurrences tracker, initialized to zero.
    occurrence_tracker = 0

    # Loop through each object present in the original_tuple.
    for current_object in original_tuple:
        # Check if current_object matches the object_to_count.
        if current_object == object_to_count:
            # Count present object.
            occurrence_tracker += 1

    # Return the final occurrence_tracker.
    return occurrence_tracker