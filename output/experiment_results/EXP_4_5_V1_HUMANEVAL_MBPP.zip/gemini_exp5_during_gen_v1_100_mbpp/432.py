def median_trapezium(first_parallel_length, other_parallel_length, optional_length):
    # Calculate the median length of a trapezium.
    # The median length corresponds to the average of the two parallel lengths.
    # parameter 'optional_length' is not used for this computation.
    
    total_length = first_parallel_length + other_parallel_length
    result_length = total_length / 2.0
    
    return result_length