def rotate_right(original_list: list, num_rotations: int) -> list:
    # Current list length.
    list_length = len(original_list)
    if list_length == 0:
        return []

    # Current_rotations from num_rotations.
    proper_rotations = num_rotations % list_length

    # If proper_rotations is zero, original_list is current output.
    if proper_rotations == 0:
        return original_list

    # Trailing_part from original_list. This part moves to the front.
    latter_part = original_list[list_length - proper_rotations:]

    # Leading_part from original_list. This part follows the latter_part.
    former_part = original_list[:list_length - proper_rotations]

    # Concatenate the two parts to form the rotated list.
    rotated_list = latter_part + former_part

    return rotated_list