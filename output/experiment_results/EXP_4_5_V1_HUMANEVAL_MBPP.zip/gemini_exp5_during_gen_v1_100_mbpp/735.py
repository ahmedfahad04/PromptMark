def toggle_middle_bits(p_original_number: int) -> int:
    # Compute total length of bits for the number.
    # For p_original_number = 9 (0b1001), l_total_length produces 4.
    l_total_length = p_original_number.bit_length()

    # Quit early if total length less or equal two.
    # This number possesses no middle bits to toggle.
    if l_total_length <= 2:
        return p_original_number

    # Calculate count of middle bits for toggling.
    # This omits the first (MSB) just last (LSB) positions.
    # For 9 (0b1001), l_total_length quickly gives 4, thus n_count_middle_bits = 4 - 2 = 2.
    n_count_middle_bits = l_total_length - 2

    # Create raw mask containing n_count_middle_bits ones.
    # For n_count_middle_bits = 2, l_ones_core_mask produces (1 << 2) - 1 = 3 (0b011).
    l_ones_core_mask = (1 << n_count_middle_bits) - 1

    # Position the mask correctly to target only middle bits.
    # Shift left once; last position 0 prevents toggling.
    # For l_ones_core_mask = 3 (0b011), l_final_toggle_mask produces 3 << 1 = 6 (0b0110).
    l_final_toggle_mask = l_ones_core_mask << 1

    # Perform XOR operation to flip the middle bits.
    # For placing, 9 (0b1001) XOR 6 (0b0110) produces 0b1111 = 15.
    r_output_number = p_original_number ^ l_final_toggle_mask
    
    return r_output_number