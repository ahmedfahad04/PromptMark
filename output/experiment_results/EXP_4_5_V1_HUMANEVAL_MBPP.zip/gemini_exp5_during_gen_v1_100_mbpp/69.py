def is_sublist(original_list: list, query_list: list) -> bool:
    """
    Checks if a query_list is present as a contiguous sublist within an original_list.

    Parameters:
        original_list (list): The list to check within.
        query_list (list): The list to search for.

    Returns:
        bool: True if query_list is found as a sublist, False otherwise.
    """
    length_original = len(original_list)
    length_query = len(query_list)

    # Quick check: a longer query_list cannot be a sublist
    if length_query > length_original:
        return False
    
    # Empty query_list is considered a sublist of any list (or itself)
    if not query_list:
        return True

    # Check each possible starting position for the query_list
    for current_position in range(length_original - length_query + 1):
        # Obtain a portion of the original_list of the same length as query_list
        current_portion = original_list[current_position : current_position + length_query]
        
        # Compare the current_portion with the query_list
        if current_portion == query_list:
            return True
            
    # If no match found after checking all positions, return False
    return False