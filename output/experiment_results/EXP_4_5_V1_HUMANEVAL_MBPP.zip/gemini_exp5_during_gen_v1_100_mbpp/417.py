def group_tuples(list_of_tuples: list[tuple]) -> list[tuple]:
    # Collections by first component, holding next portions.
    collections_by_first = {}

    # Loop through each original pair in the list.
    for original_pair in list_of_tuples:
        current_primary = original_pair[0]
        next_portion = original_pair[1]

        # Check if the primary component is already present.
        if current_primary not in collections_by_first:
            # If not, create a new list for its next portions.
            collections_by_first[current_primary] = []
        
        # Append the next portion to the current primary's list.
        collections_by_first[current_primary].append(next_portion)

    # Prepare the result list.
    result_list = []

    # Convert the grouped collections into the final tuple format.
    for primary_part, current_portions in collections_by_first.items():
        # Combine the primary part with its following portions.
        combined_tuple = (primary_part,) + tuple(current_portions)
        result_list.append(combined_tuple)
    
    return result_list