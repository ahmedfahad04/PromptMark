def extract_string(original_list, target_length):
    # Creates result_list for collecting qualified texts.
    result_list = []
    
    # Proceeds through each text in the original_list.
    for current_text in original_list:
        # Compares current_text's length to the target_length.
        if len(current_text) == target_length:
            # Puts current_text into the result_list if lengths match.
            result_list.append(current_text)
            
    return result_list