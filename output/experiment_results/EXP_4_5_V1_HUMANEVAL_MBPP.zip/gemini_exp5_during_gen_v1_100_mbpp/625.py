def swap_List(current_list):
    # Check current_list prior to operations.
    current_length = len(current_list)
    if current_length < 2:
        return current_list

    # Capture first_object.
    temp_object = current_list[0] 

    # Place last_object in first_position.
    current_list[0] = current_list[current_length - 1]

    # Place current_temporary_object in last_position.
    current_list[current_length - 1] = temp_object

    # Return current_list.
    return current_list