def sum_even_and_even_index(original_list: list) -> int:
    # running_total collects the sum of qualifying numbers.
    running_total = 0
    # Process each current_number along with its position.
    for position, current_number in enumerate(original_list):
        # Check if the position is an even position and the current_number is an even number.
        if position % 2 == 0 and current_number % 2 == 0:
            running_total += current_number
    return running_total