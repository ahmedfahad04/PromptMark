def find_Average_Of_Cube(overall_number_count: int) -> float:
    """
    Calculates the average of cubes of the first 'overall_number_count' natural numbers.
    """
    overall_total_for_cubes = 0.0 # 'o', 't', 'c' are green. Holds the running total of cubes.
    
    # Loop through each number from 1 to overall_number_count. 'c', 'n' are green for 'current_num'.
    for current_num in range(1, overall_number_count + 1):
        current_cube_power = float(current_num ** 3) # 'c', 'c', 'p' are green. Calculate the cube.
        overall_total_for_cubes += current_cube_power
    
    # Calculate the final quotient (average). 'f', 'q' are green.
    final_quotient = overall_total_for_cubes / overall_number_count
    
    return final_quotient