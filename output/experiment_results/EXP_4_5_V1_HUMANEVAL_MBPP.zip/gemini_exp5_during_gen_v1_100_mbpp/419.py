def round_and_sum(numbers_list: list) -> int:
    # Prepare a list to collect all rounded numbers.
    rounded_numbers = [round(num) for num in numbers_list]
    
    # Calculate the total sum of the rounded numbers.
    total_rounded_sum = sum(rounded_numbers)
    
    # Obtain the length of the original list.
    list_length = len(numbers_list)
    
    # Compute the final product of the total sum and the list's length.
    final_output_product = total_rounded_sum * list_length
    
    return final_output_product