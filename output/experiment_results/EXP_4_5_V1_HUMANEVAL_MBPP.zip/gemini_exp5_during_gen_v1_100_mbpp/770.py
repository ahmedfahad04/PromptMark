def odd_num_sum(n: int) -> int:
    # current_total_sum, cumulative total power sum.
    current_total_sum = 0
    # Loop from the first position to the nth position.
    for current_position in range(1, n + 1):
        # Obtain current_odd_num from current_position.
        current_odd_num = (2 * current_position) - 1
        # Calculate the fourth_power of the current_odd_num.
        power_result = current_odd_num ** 4
        # Combine power_result to current_total_sum.
        current_total_sum += power_result
    return current_total_sum