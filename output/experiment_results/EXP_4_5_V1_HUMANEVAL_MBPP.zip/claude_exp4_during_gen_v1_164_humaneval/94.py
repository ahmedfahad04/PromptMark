def skjkasdkd(lst):
    def is_prime_ologic(eligible_integer):
        if eligible_integer < 2:
            return False
        if eligible_integer == 2:
            return True
        if eligible_integer % 2 == 0:
            return False
        for divisor_index in range(3, int(eligible_integer**0.5) + 1, 2):
            if eligible_integer % divisor_index == 0:
                return False
        return True
    
    largest_prime_encountered = -1
    
    for data_element in lst:
        if is_prime_ologic(data_element) and data_element > largest_prime_encountered:
            largest_prime_encountered = data_element
    
    if largest_prime_encountered == -1:
        return 0
    
    # Add up individual digits of the prime
    digit_accumulator = 0
    prime_as_positional = str(largest_prime_encountered)
    for each_digit in prime_as_positional:
        digit_accumulator += int(each_digit)
    
    return digit_accumulator