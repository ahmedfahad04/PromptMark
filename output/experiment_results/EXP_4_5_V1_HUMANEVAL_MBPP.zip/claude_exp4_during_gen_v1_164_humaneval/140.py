def fix_spaces(original_input):
    if not original_input:
        return original_input
    
    adjusted_output = []
    i = 0
    
    while i < len(original_input):
        if original_input[i] == ' ':
            # identify length of each gap
            gap_length = 0
            j = i
            while j < len(original_input) and original_input[j] == ' ':
                gap_length += 1
                j += 1
            
            if gap_length > 2:
                adjusted_output.append('-')
            else:
                adjusted_output.extend(['_'] * gap_length)
            
            i = j
        else:
            adjusted_output.append(original_input[i])
            i += 1
    
    return ''.join(adjusted_output)