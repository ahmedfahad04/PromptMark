def make_a_pile(initial_level_count):
    pile_levels = []
    
    # Initial level gets the given amount
    ongoing_level_amount = initial_level_count
    
    # Add levels equal to initial_level_count
    for i in range(initial_level_count):
        pile_levels.append(ongoing_level_amount)
        ongoing_level_amount += 2
    
    return pile_levels