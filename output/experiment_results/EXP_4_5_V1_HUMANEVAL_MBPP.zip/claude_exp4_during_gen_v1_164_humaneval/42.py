def incr_list(original_list: list):
    updated_data = []
    
    # Process each item and add one
    for element in original_list:
        incremented_element = element + 1
        updated_data.append(incremented_element)
    
    return updated_data