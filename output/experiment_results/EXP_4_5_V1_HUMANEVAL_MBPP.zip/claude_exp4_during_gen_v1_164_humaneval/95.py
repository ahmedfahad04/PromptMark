def check_dict_case(dict):
    # Early exit if dictionary is empty
    if not dict:
        return False
    
    # Initialize flags to determine key pattern
    all_lowercase = True
    all_uppercase = True
    
    for key in dict:
        # If key is not a string, immediately return False
        if not isinstance(key, str):
            return False
        
        # Update flags based on key case
        if not key.islower():
            all_lowercase = False
        if not key.isupper():
            all_uppercase = False
        
        # Early exit optimization: if both flags are False
        if not all_lowercase and not all_uppercase:
            return False
    
    # Dictionary passes if all keys are either lowercase or uppercase
    return all_lowercase or all_uppercase