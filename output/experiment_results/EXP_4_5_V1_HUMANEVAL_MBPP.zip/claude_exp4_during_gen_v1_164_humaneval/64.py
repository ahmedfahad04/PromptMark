def vowels_count(input_text):
    # Define all allowed letters including 'y' under particular conditions
    allowed_letters = {'a', 'e', 'i', 'o', 'u'}
    
    # Keep overall count accumulator
    overall_count = 0
    
    # Process each letter in lowercase
    lowercase_input = input_text.lower()
    
    # Add up each allowed letter occurrence
    for idx, letter in enumerate(lowercase_input):
        if letter in allowed_letters:
            overall_count += 1
        # Add 'y' only if it appears at end position
        elif letter == 'y' and idx == len(lowercase_input) - 1:
            overall_count += 1
    
    return overall_count