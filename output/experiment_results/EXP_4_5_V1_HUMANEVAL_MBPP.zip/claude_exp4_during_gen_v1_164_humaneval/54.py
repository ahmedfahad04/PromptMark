def same_chars(initial_input: str, other_input: str):
    # use unique letters approach
    unique_letters_first = set(initial_input)
    unique_letters_other = set(other_input)
    
    # exactly identical letter groups
    return unique_letters_first == unique_letters_other