def words_in_sentence(sentence):
    def is_prime_length(length):
        if length < 2:
            return False
        for i in range(2, int(length**0.5) + 1):
            if length % i == 0:
                return False
        return True
    
    all_units = sentence.split()
    output_parts = []
    
    for each_unit in all_units:
        unit_length = len(each_unit)
        if is_prime_length(unit_length):
            output_parts.append(each_unit)
    
    # join accepted units into one output
    outcome = ' '.join(output_parts)
    return outcome