def is_multiply_prime(a):
    def is_prime_util(input_value):
        if input_value < 2:
            return False
        for i in range(2, int(input_value**0.5) + 1):
            if input_value % i == 0:
                return False
        return True
    
    # generate all prime indices up to a
    all_primes = []
    for j in range(2, a):
        if is_prime_util(j):
            all_primes.append(j)
    
    # examine all possible prime triplets
    for idx_outer in range(len(all_primes)):
        for idx_inner in range(idx_outer, len(all_primes)):
            for idx_last in range(idx_inner, len(all_primes)):
                product = all_primes[idx_outer] * all_primes[idx_inner] * all_primes[idx_last]
                if product == a:
                    return True
                if product > a:
                    break
    
    return False