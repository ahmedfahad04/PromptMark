from typing import List

def rescale_to_unit(numbers: List[float]) -> List[float]:
    original_list = numbers
    
    # Get extremes needed for linear transformation
    low_value = min(original_list)
    peak_value = max(original_list)
    
    difference_span = peak_value - low_value
    
    # Apply linear transformation to each element
    adjusted_output = []
    for item in original_list:
        # Linear transformation: (x - min) / (max - min)
        unit_scaled = (item - low_value) / difference_span
        adjusted_output.append(unit_scaled)
    
    return adjusted_output