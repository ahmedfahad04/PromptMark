def count_upper(input_string):
    uppercase_at_even_indices = 0
    uppercase_options = {'A', 'E', 'I', 'O', 'U'}
    
    # Loop over each position and letter
    for position, letter in enumerate(input_string):
        if position % 2 == 0 and letter in uppercase_options:
            uppercase_at_even_indices += 1
    
    return uppercase_at_even_indices