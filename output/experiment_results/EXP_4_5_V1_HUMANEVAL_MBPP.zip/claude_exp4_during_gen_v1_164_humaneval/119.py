def match_parens(lst):
    def is_balanced(paren_string):
        open_count = 0
        for parenthesis in paren_string:
            if parenthesis == '(':
                open_count += 1
            else:
                open_count -= 1
                if open_count < 0:
                    return False
        return open_count == 0
    
    # Order 1: lst[0] + lst[1]
    if is_balanced(lst[0] + lst[1]):
        return 'Yes'
    
    # Order 2: lst[1] + lst[0]
    if is_balanced(lst[1] + lst[0]):
        return 'Yes'
    
    return 'No'