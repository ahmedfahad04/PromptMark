def common(l1: list, l2: list):
    # Use intersection operation on duplicates_eliminated datasets
    unique_elements_l1 = set(l1)
    unique_elements_l2 = set(l2)
    
    overlapping_items = unique_elements_l1.intersection(unique_elements_l2)
    
    # Order ascending and produce output
    ordered_intersection = sorted(overlapping_items)
    
    return ordered_intersection