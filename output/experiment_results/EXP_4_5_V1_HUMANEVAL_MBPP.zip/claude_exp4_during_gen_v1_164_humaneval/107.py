def even_odd_palindrome(input_limit):
    def _is_palindrome(origin_digit):
        digit_as_organized_letters = str(origin_digit)
        return digit_as_organized_letters == digit_as_organized_letters[::-1]
    
    even_palindrome_accumulator = 0
    odd_palindrome_accumulator = 0
    
    # iterate over all positive integers up to input_limit
    for index in range(1, input_limit + 1):
        if _is_palindrome(index):
            if index % 2 == 0:
                even_palindrome_accumulator += 1
            else:
                odd_palindrome_accumulator += 1
    
    return (even_palindrome_accumulator, odd_palindrome_accumulator)