def is_prime(input_number):
    if input_number <= 1:
        return False
    if input_number <= 3:
        return True
    if input_number % 2 == 0 or input_number % 3 == 0:
        return False
    
    # optimization: examine only odd divisors up to square root
    iterator = 5
    upper_limit = int(input_number ** 0.5) + 1
    
    while iterator <= upper_limit:
        if input_number % iterator == 0 or input_number % (iterator + 2) == 0:
            return False
        iterator += 6
    
    return True