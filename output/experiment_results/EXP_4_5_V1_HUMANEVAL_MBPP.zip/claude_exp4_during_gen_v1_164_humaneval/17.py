from typing import List

def parse_music(audio_input: str) -> List[int]:
    output_list = []
    index = 0
    
    while index < len(audio_input):
        if audio_input[index] == 'o':
            if index + 1 < len(audio_input) and audio_input[index + 1] == '|':
                output_list.append(2)  # o| produces dual pulse
                index += 2
            else:
                output_list.append(4)  # o alone produces quad pulse
                index += 1
        elif audio_input[index:index + 2] == '.|':
            output_list.append(1)  # .| produces one pulse
            index += 2
        else:
            index += 1  # ignore extra gaps
    
    return output_list