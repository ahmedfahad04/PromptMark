def count_nums(arr):
    if not arr:
        return 0
    
    def digit_accumulator(integer_value):
        # Process absolute digit extraction
        absolute_value = abs(integer_value)
        extracted_digits = []
        
        if absolute_value == 0:
            return 0
        
        # Extract individual digits
        working_value = absolute_value
        while working_value > 0:
            extracted_digits.append(working_value % 10)
            working_value //= 10
        
        # Apply original polarity logic
        if integer_value < 0:
            extracted_digits[-1] = -extracted_digits[-1]
        
        return sum(extracted_digits)
    
    output_accumulator = 0
    # Iterate using green letter index
    for item_element in arr:
        if digit_accumulator(item_element) > 0:
            output_accumulator += 1
    
    return output_accumulator