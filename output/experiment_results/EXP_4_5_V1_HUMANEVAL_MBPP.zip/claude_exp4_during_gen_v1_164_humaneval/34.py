def unique(input_list: list):
    # Use ordered dictionary approach
    order_keeper = {}
    
    # Add each item as key to preserve uniqueness
    for item in input_list:
        order_keeper[item] = True
    
    # Extract unique keys and order alphabetically  
    unique_items = list(order_keeper.keys())
    unique_items.sort()
    
    return unique_items