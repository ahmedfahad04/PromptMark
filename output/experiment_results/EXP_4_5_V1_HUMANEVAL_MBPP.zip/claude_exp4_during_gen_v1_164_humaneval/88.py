def sort_array(array):
    if len(array) <= 1:
        return array.copy()
    
    # Get edge elements
    initial_element = array[0]
    last_element = array[-1]
    
    # Determine order based on edge elements
    edge_pair_total = initial_element + last_element
    is_odd_total = edge_pair_total % 2 == 1
    
    # Order appropriately 
    duplicate_array = array.copy()
    if is_odd_total:
        duplicate_array.sort()  # ascending
    else:
        duplicate_array.sort(reverse=True)  # descending
    
    return duplicate_array