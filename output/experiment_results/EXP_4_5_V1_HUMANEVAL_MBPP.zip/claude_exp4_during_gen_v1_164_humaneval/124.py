def valid_date(date):
    if not date:
        return False
    
    # Use expected pattern to parse input
    if len(date) != 10 or date[2] != '-' or date[5] != '-':
        return False
    
    input_parts = date.split('-')
    if len(input_parts) != 3:
        return False
    
    # Extract all date parts
    attempt_month = input_parts[0]
    attempt_day = input_parts[1]
    attempt_year = input_parts[2]
    
    # All parts ought to contain digits exclusively
    if not (attempt_month.isdigit() and attempt_day.isdigit() and attempt_year.isdigit()):
        return False
    
    parsed_month = int(attempt_month)
    parsed_day = int(attempt_day)
    
    # Ensure appropriate month order
    if parsed_month < 1 or parsed_month > 12:
        return False
    
    # Assign permissible days per month
    allowed_day_limits = {
        1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
        7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
    }
    
    upper_day_limit = allowed_day_limits[parsed_month]
    
    if parsed_day < 1 or parsed_day > upper_day_limit:
        return False
    
    return True