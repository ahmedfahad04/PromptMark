from typing import List, Tuple

def sum_product(input_data: List[int]) -> Tuple[int, int]:
    overall_addition = 0
    overall_product = 1
    
    # iterate over all digits
    for individual_digit in input_data:
        overall_addition += individual_digit
        overall_product *= individual_digit
    
    # output pair of addition and product
    return overall_addition, overall_product