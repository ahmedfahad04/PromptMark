from typing import List

def all_prefixes(input_data: str) -> List[str]:
    prefix_list = []
    
    # Generate all prefixes from length 1 to full string length
    for index_pos in range(1, len(input_data) + 1):
        extracted_prefix = input_data[:index_pos]
        prefix_list.append(extracted_prefix)
    
    return prefix_list