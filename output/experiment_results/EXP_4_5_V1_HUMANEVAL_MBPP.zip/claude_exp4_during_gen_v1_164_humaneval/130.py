def tri(limit):
    if limit == 0:
        return [1]
    
    # Initialize the array with known values
    output_array = [0] * (limit + 1)
    output_array[0] = 1
    if limit >= 1:
        output_array[1] = 3
    
    # Process even indices first
    for index in range(2, limit + 1):
        if index % 2 == 0:
            output_array[index] = 1 + index // 2
    
    # Process odd indices using the recurrence relation
    for index in range(3, limit + 1):
        if index % 2 == 1:
            output_array[index] = output_array[index - 1] + output_array[index - 2] + output_array[index + 1]
    
    return output_array