def fib(position: int):
    if position <= 0:
        return 0
    elif position == 1:
        return 1
    
    # Initialize pair of adjacent elements
    previous = 0
    ongoing = 1
    
    # iterate up to desired position
    for idx in range(2, position + 1):
        latest = previous + ongoing
        previous = ongoing
        ongoing = latest
    
    return ongoing