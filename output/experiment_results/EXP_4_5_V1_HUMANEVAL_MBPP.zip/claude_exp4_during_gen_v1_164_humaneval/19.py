def sort_numbers(numbers: str) -> str:
    order_map = {
        'zero': 0, 'one': 1, 'two': 2, 'three': 3, 'four': 4,
        'five': 5, 'six': 6, 'seven': 7, 'eight': 8, 'nine': 9
    }
    
    if not numbers.strip():
        return ''
    
    parsed_input = numbers.split()
    
    # order each item using order_map lookup
    ordered_pairs = [(order_map[item], item) for item in parsed_input]
    ordered_pairs.sort(key=lambda x: x[0])
    
    # keep original items after ordering
    organized_output = [pair[1] for pair in ordered_pairs]
    
    return ' '.join(organized_output)