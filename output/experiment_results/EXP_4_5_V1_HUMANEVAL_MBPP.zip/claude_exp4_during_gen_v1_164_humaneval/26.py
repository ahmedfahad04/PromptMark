from typing import List

def remove_duplicates(numbers: List[int]) -> List[int]:
    occurrence_lookup = {}
    
    # keep occurrence of each integer
    for integer in numbers:
        occurrence_lookup[integer] = occurrence_lookup.get(integer, 0) + 1
    
    # add integers appearing exactly once
    unique_integers = []
    for integer in numbers:
        if occurrence_lookup[integer] == 1:
            unique_integers.append(integer)
    
    return unique_integers