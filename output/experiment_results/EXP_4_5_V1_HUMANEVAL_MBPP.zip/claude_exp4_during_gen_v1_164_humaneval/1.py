from typing import List

def separate_paren_groups(paren_string: str) -> List[str]:
    grouped_parens = []
    active_group = ""
    open_paren_depth = 0
    
    # iterate over each position in input
    for idx in range(len(paren_string)):
        active_char = paren_string[idx]
        
        if active_char == ' ':
            continue
            
        active_group += active_char
        
        if active_char == '(':
            open_paren_depth += 1
        elif active_char == ')':
            open_paren_depth -= 1
            
            # group is complete at depth 0
            if open_paren_depth == 0:
                grouped_parens.append(active_group)
                active_group = ""
    
    return grouped_parens