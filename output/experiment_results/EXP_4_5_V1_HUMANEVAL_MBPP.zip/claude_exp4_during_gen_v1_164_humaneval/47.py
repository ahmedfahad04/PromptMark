def median(l: list):
    ordered_list = sorted(l)
    list_length = len(ordered_list)
    
    if list_length % 2 == 1:
        # Odd length: pick middle element
        index_middle = list_length // 2
        return ordered_list[index_middle]
    else:
        # Even length: average of two middle elements
        index_left = list_length // 2 - 1
        index_right = list_length // 2
        return (ordered_list[index_left] + ordered_list[index_right]) / 2