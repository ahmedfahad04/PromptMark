def anti_shuffle(input_string):
    # Keep order of spaces and process each non-space group
    ordered_parts = []
    i = 0
    
    while i < len(input_string):
        if input_string[i] == ' ':
            ordered_parts.append(' ')
            i += 1
        else:
            # Extract non-space group
            individual_group = ''
            while i < len(input_string) and input_string[i] != ' ':
                individual_group += input_string[i]
                i += 1
            # Add ordered individual group
            ordered_parts.append(''.join(sorted(individual_group)))
    
    return ''.join(ordered_parts)