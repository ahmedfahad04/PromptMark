def get_closest_vowel(word):
    all_vowels = "aeiouAEIOU"
    
    # iterate backwards excluding edge positions
    index_position = len(word) - 2
    
    while index_position > 0:
        letter_at_index = word[index_position]
        
        if letter_at_index in all_vowels:
            left_letter = word[index_position - 1]
            opposite_letter = word[index_position + 1]
            
            # examine if vowel is between consonants
            if left_letter not in all_vowels and opposite_letter not in all_vowels:
                return letter_at_index
        
        index_position -= 1
    
    return ""