def strlen(input_string: str) -> int:
    actual_length = 0
    
    # iterate over each available letter in input
    for individual_letter in input_string:
        actual_length += 1
    
    # output accumulated length
    return actual_length