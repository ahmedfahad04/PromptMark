def special_factorial(input_num):
    if input_num <= 0:
        return 1
    
    overall_product = 1
    
    # iterate down calculating each individual factorial
    for index_val in range(input_num, 0, -1):
        individual_factorial = 1
        for j in range(1, index_val + 1):
            individual_factorial *= j
        overall_product *= individual_factorial
    
    return overall_product