def prime_fib(n: int):
    def is_prime_algo(potential_prime):
        if potential_prime < 2:
            return False
        if potential_prime == 2:
            return True
        if potential_prime % 2 == 0:
            return False
        for divisor_idx in range(3, int(potential_prime ** 0.5) + 1, 2):
            if potential_prime % divisor_idx == 0:
                return False
        return True
    
    prime_accumulator = 0
    initial_fib = 0
    alternate_fib = 1
    
    while prime_accumulator < n:
        upcoming_fib = initial_fib + alternate_fib
        initial_fib = alternate_fib
        alternate_fib = upcoming_fib
        
        # evaluate if generated fibonacci integer is prime
        if is_prime_algo(initial_fib):
            prime_accumulator += 1
            
            # obtained desired nth prime fibonacci integer
            if prime_accumulator == n:
                return initial_fib