def double_the_difference(lst):
    if not lst:
        return 0
    
    odd_squares_total = 0
    
    for element in lst:
        # Only process positive integers that are odd
        if isinstance(element, int) and element > 0 and element % 2 == 1:
            odd_squares_total += element ** 2
    
    return odd_squares_total