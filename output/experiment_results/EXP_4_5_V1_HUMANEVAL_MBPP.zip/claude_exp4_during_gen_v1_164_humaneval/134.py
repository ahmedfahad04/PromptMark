def check_if_last_char_is_a_letter(input_text):
    if not input_text:
        return False
    
    # Get the last character and check if it's alphabetical
    last_char = input_text[-1]
    if not last_char.isalpha():
        return False
    
    # If there's only one character, it's not part of a word
    if len(input_text) == 1:
        return True
    
    # Look at the character before the last one
    previous_char = input_text[-2]
    
    # If previous character is a space, last char is isolated
    if previous_char == ' ':
        return True
    
    # Otherwise, last char is part of a word
    return False