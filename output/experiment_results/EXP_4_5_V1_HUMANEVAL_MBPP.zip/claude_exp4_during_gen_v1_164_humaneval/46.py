def fib4(index: int):
    if index <= 1:
        return 0
    elif index == 2:
        return 2
    elif index == 3:
        return 0
    
    # Use iterative approach keeping last four elements
    alpha, omega, epsilon, kappa = 0, 0, 2, 0
    
    for j in range(4, index + 1):
        upcoming = alpha + omega + epsilon + kappa
        alpha, omega, epsilon, kappa = omega, epsilon, kappa, upcoming
    
    return kappa