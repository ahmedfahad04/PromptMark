def any_int(x, y, z):
    if not all(isinstance(param, int) for param in [x, y, z]):
        return False
    
    # examine if one parameter equals addition of other pair
    option_a = x == y + z
    option_b = y == x + z  
    option_c = z == x + y
    
    return option_a or option_b or option_c