def smallest_change(arr):
    operations_needed = 0
    array_length = len(arr)
    
    # iterate through array elements up to middle point
    for index in range(array_length // 2):
        opposite_index = array_length - 1 - index
        
        # if elements at opposite positions differ, increment operations
        if arr[index] != arr[opposite_index]:
            operations_needed += 1
    
    return operations_needed