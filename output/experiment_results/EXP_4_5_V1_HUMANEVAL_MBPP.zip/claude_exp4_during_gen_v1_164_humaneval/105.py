def by_length(arr):
    digit_names = {
        1: "One", 2: "Two", 3: "Three", 4: "Four", 5: "Five",
        6: "Six", 7: "Seven", 8: "Eight", 9: "Nine"
    }
    
    # Keep only digits 1-9
    valid_digits = [item for item in arr if 1 <= item <= 9]
    
    # Order digits ascending, then reverse
    ordered_digits = sorted(valid_digits, reverse=True)
    
    # Generate output list using digit names
    output_list = [digit_names[digit] for digit in ordered_digits]
    
    return output_list