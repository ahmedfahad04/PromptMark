def encrypt(input_text):
    encrypted_output = ""
    
    for letter in input_text:
        if letter.isalpha():
            # Get position in alphabet (a=0, b=1, ...)
            alphabet_position = ord(letter.lower()) - ord('a')
            
            # Apply the encryption: shift by 4 positions (2 * 2)
            new_position = (alphabet_position + 4) % 26
            
            # Generate encrypted letter
            encrypted_letter = chr(new_position + ord('a'))
            encrypted_output += encrypted_letter
        else:
            encrypted_output += letter
    
    return encrypted_output