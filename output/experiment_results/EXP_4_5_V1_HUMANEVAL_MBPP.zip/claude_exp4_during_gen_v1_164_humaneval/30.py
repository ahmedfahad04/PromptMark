def get_positive(input_list: list):
    # Initial empty list to accumulate positive items
    output_array = []
    
    # Iterate over each element in input data
    for element in input_list:
        if element > 0:
            output_array.append(element)
    
    # Output accumulated positive items
    return output_array