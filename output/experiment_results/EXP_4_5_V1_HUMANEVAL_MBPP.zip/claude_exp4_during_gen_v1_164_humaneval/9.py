from typing import List, Tuple

def rolling_max(numbers: List[int]) -> List[int]:
    outcomes = []
    present_peak = None
    
    # iterate over each element and keep peak updated
    for element in numbers:
        if present_peak is None or element > present_peak:
            present_peak = element
        outcomes.append(present_peak)
    
    return outcomes