def split_words(input_text):
    # evaluate if input contains any spaces
    if ' ' in input_text:
        output_list = input_text.split(' ')
        return output_list
    
    # if no spaces exist, examine for commas
    if ',' in input_text:
        output_list = input_text.split(',')
        return output_list
    
    # otherwise, analyze lowercase odd-order alphabet letters
    odd_position_count = 0
    for each_letter in input_text:
        letter_position = ord(each_letter) - ord('a')
        # odd positions in alphabet: a(0), c(2), e(4), etc have odd order indices
        if each_letter.islower() and letter_position % 2 == 1:
            odd_position_count += 1
    
    return odd_position_count