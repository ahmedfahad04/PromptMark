def eat(already_eaten, additional_needed, available_stock):
    # determine optimal additional eating amount
    actual_additional = min(additional_needed, available_stock)
    
    # update eating outcomes
    overall_eaten = already_eaten + actual_additional
    items_left = available_stock - actual_additional
    
    return [overall_eaten, items_left]