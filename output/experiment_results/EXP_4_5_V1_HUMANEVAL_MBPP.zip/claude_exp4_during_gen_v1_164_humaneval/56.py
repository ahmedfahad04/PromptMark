def correct_bracketing(opening_angle_list: str):
    open_angle_depth = 0
    
    for individual_angle in opening_angle_list:
        if individual_angle == "<":
            open_angle_depth += 1
        elif individual_angle == ">":
            open_angle_depth -= 1
            # Exit early if unmatched opening angle
            if open_angle_depth < 0:
                return False
    
    # All opening angles paired exactly
    return open_angle_depth == 0