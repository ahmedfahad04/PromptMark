def sort_third(input_list: list):
    if not input_list:
        return []
    
    # Extract elements at indices divisible by 3
    elements_at_divisible_indices = []
    for index in range(len(input_list)):
        if index % 3 == 0:
            elements_at_divisible_indices.append(input_list[index])
    
    # Get ordered divisible elements
    ordered_elements = sorted(elements_at_divisible_indices)
    
    # Initialize output and position keeper
    output_list = input_list.copy()
    position_keeper = 0
    
    # Place ordered elements at divisible positions
    for index in range(len(input_list)):
        if index % 3 == 0:
            output_list[index] = ordered_elements[position_keeper]
            position_keeper += 1
    
    return output_list