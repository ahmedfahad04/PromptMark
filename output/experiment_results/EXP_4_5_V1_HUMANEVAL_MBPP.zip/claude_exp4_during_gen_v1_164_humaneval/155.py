def even_odd_count(digit_input):
    absolute_digits = abs(digit_input)
    digit_string = str(absolute_digits)
    
    even_count = 0
    odd_count = 0
    
    for individual_digit in digit_string:
        digit_value = int(individual_digit)
        if digit_value % 2 == 0:
            even_count += 1
        else:
            odd_count += 1
    
    return (even_count, odd_count)