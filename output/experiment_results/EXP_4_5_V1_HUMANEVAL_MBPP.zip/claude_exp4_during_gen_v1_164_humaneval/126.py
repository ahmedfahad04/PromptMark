def is_sorted(lst):
    if len(lst) <= 1:
        return True
    
    # Keep order and duplicate info
    prev_element = lst[0]
    occurrence_data = {prev_element: 1}
    
    for index in range(1, len(lst)):
        active_element = lst[index]
        
        # Order assertion
        if active_element < prev_element:
            return False
        
        # Update occurrence data
        if active_element in occurrence_data:
            occurrence_data[active_element] += 1
            if occurrence_data[active_element] > 2:
                return False
        else:
            occurrence_data[active_element] = 1
        
        prev_element = active_element
    
    return True