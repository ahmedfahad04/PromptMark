def correct_bracketing(opening_closing_pairs: str):
    open_parentheses_depth = 0
    
    for each_character in opening_closing_pairs:
        if each_character == '(':
            open_parentheses_depth += 1
        elif each_character == ')':
            open_parentheses_depth -= 1
            # early exit if depth goes negative
            if open_parentheses_depth < 0:
                return False
    
    # all opening parentheses paired if depth is zero
    return open_parentheses_depth == 0