def largest_smallest_integers(lst):
    largest_negative = None
    odd_positive = None
    
    # Initially all extracted integers
    all_integers = [item for item in lst if isinstance(item, int) and item != 0]
    
    # Get all positive integers
    positive_integers = [item for item in all_integers if item > 0]
    if positive_integers:
        odd_positive = min(positive_integers)
    
    # Get all negative integers  
    all_negative = [item for item in all_integers if item < 0]
    if all_negative:
        largest_negative = max(all_negative)
    
    return (largest_negative, odd_positive)