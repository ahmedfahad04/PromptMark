def prime_length(input_text):
    length_of_text = len(input_text)
    
    if length_of_text < 2:
        return False
    
    # examine all divisors up to square root of length
    for divisor in range(2, int(length_of_text ** 0.5) + 1):
        if length_of_text % divisor == 0:
            return False
    
    return True