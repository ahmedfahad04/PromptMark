def add(lst):
    odd_index_even_total = 0
    
    # iterate over odd positions only
    for index_pos in range(1, len(lst), 2):
        element_at_odd_idx = lst[index_pos]
        
        # add only even elements at odd indices
        if element_at_odd_idx % 2 == 0:
            odd_index_even_total += element_at_odd_idx
    
    return odd_index_even_total