from typing import List

def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    output_list = []
    
    # iterate over each input element
    for individual_item in strings:
        if substring in individual_item:
            output_list.append(individual_item)
    
    return output_list