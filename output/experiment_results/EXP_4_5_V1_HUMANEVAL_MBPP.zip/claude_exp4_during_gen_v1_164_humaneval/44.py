def change_base(input_value: int, desired_base: int):
    if input_value == 0:
        return '0'
    
    digit_list = []
    original_input = input_value
    
    while original_input > 0:
        digit_list.append(str(original_input % desired_base))
        original_input = original_input // desired_base
    
    return ''.join(digit_list[::-1])