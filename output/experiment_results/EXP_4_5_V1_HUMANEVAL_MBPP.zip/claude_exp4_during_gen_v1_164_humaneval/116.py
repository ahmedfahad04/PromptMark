def sort_array(input_array):
    def ones_in_decimal(decimal_value):
        # Uses bin() on absolute decimal value, excluding '0b' prefix
        absolute_decimal = abs(decimal_value)
        return bin(absolute_decimal).count('1')
    
    ordered_array = sorted(input_array, key=lambda item: (ones_in_decimal(item), item))
    return ordered_array