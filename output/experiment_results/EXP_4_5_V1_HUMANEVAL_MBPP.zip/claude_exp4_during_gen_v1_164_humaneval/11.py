def string_xor(a: str, b: str) -> str:
    output_digits = []
    
    index = 0
    for digit_a, digit_b in zip(a, b):
        # XOR operation gives 1 if digits differ, 0 if identical
        xor_digit = str(int(digit_a) ^ int(digit_b))
        output_digits.append(xor_digit)
        index += 1
    
    # Join all processed digits into output
    return ''.join(output_digits)