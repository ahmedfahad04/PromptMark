import hashlib

def string_to_md5(original_text):
    if not original_text:
        return None
    
    # encode input as utf-8 and generate digest
    encoded_data = original_text.encode('utf-8')
    
    # use algorithm object to process encoded input
    algorithm_obj = hashlib.md5()
    algorithm_obj.update(encoded_data)
    
    # obtain digest as lowercase letters
    output_digest = algorithm_obj.hexdigest()
    
    return output_digest