def decimal_to_binary(input_decimal):
    if input_decimal == 0:
        return "db0db"
    
    # generate digits using division approach
    output_digits = []
    active_number = input_decimal
    
    while active_number > 0:
        output_digits.append(active_number % 2)
        active_number //= 2
    
    # assemble digits in order
    ordered_digits = output_digits[::-1]
    
    # join digits into output
    internal_part = ''.join(map(str, ordered_digits))
    
    return f"db{internal_part}db"