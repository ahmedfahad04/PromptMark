from typing import List

def concatenate(input_list: List[str]) -> str:
    output_string = ""
    
    # Iterate over each element and append
    for each_string in input_list:
        output_string += each_string
    
    return output_string