def get_odd_collatz(n):
    odd_entries = []
    present_element = n
    
    # Add initial odd if applicable
    if present_element % 2 == 1:
        odd_entries.append(present_element)
    
    # Generate sequence until reaching 1
    while present_element != 1:
        if present_element % 2 == 0:
            present_element = present_element // 2
        else:
            present_element = present_element * 3 + 1
        
        # Keep odd entries only
        if present_element % 2 == 1:
            odd_entries.append(present_element)
    
    # Order elements ascending
    return sorted(list(set(odd_entries)))