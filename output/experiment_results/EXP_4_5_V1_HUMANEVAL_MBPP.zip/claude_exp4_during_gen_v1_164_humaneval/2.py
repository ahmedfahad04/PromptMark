def truncate_number(input_value: float) -> float:
    # Get integer portion of input_value
    integer_part = int(input_value)
    # Extract decimal portion only
    decimal_output = input_value - integer_part
    return decimal_output