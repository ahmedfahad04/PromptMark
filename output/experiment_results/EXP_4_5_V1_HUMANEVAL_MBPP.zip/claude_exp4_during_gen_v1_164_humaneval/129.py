def minPath(grid, k):
    grid_size = len(grid)
    
    # Create position lookup for each value
    position_lookup = {}
    for i in range(grid_size):
        for j in range(grid_size):
            position_lookup[grid[i][j]] = (i, j)
    
    def get_adjacent_positions(pos):
        adjacent = []
        directions = [(0, 1), (0, -1), (1, 0), (-1, 0)]
        for dx, dy in directions:
            updated_x, updated_y = pos[0] + dx, pos[1] + dy
            if 0 <= updated_x < grid_size and 0 <= updated_y < grid_size:
                adjacent.append((updated_x, updated_y))
        return adjacent
    
    # Always start from position of value 1 (minimum possible)
    initial_position = position_lookup[1]
    optimal_path = [1]
    
    # Build path step by step
    current_position = initial_position
    
    for _ in range(k - 1):
        adjacent_positions = get_adjacent_positions(current_position)
        adjacent_values = [grid[pos[0]][pos[1]] for pos in adjacent_positions]
        
        # Find minimum value among neighbors
        optimal_value = min(adjacent_values)
        optimal_index = adjacent_values.index(optimal_value)
        
        # If minimum neighbor is greater than current value, alternate between 1 and current
        if optimal_value > optimal_path[0]:  # Compare with 1
            if optimal_path[-1] == 1:
                # Find neighbor with value 1 if exists, otherwise take minimum
                if 1 in adjacent_values:
                    optimal_value = 1
                    optimal_index = adjacent_values.index(1)
            else:
                # Try to go back to 1 if possible
                if 1 in adjacent_values:
                    optimal_value = 1
                    optimal_index = adjacent_values.index(1)
        
        optimal_path.append(optimal_value)
        current_position = adjacent_positions[optimal_index]
    
    return optimal_path