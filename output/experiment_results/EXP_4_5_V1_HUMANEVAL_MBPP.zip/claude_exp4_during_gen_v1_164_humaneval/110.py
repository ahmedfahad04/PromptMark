def exchange(original_list, alternate_list):
    # Get all available even digits from alternate_list
    available_evens = [digit for digit in alternate_list if digit % 2 == 0]
    
    # Get all odd digits in original_list
    odds_in_original = [digit for digit in original_list if digit % 2 == 1]
    
    # If original_list already all even, possible
    if len(odds_in_original) == 0:
        return "YES"
    
    # If enough evens available in alternate_list, possible
    if len(available_evens) >= len(odds_in_original):
        return "YES"
    else:
        return "NO"