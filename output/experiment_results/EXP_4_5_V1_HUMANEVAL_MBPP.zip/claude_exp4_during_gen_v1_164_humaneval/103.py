def rounded_avg(input_lower, input_upper):
    if input_lower > input_upper:
        return -1
    
    # Add all integers in the given interval
    element_accumulation = sum(range(input_lower, input_upper + 1))
    
    # Get average and apply integer approximation
    item_quantity = input_upper - input_lower + 1
    average_outcome = element_accumulation / item_quantity
    integer_approximated = round(average_outcome)
    
    return bin(integer_approximated)