def encode_shift(s: str):
    return "".join([chr(((ord(ch) + 5 - ord("a")) % 26) + ord("a")) for ch in s])

def decode_shift(s: str):
    decoded_chars = []
    for letter in s:
        # Get position of encoded letter
        encoded_pos = ord(letter) - ord("a")
        # Apply inverse operation: go back 5 positions
        original_pos = (encoded_pos - 5) % 26
        # Get original letter
        original_letter = chr(original_pos + ord("a"))
        decoded_chars.append(original_letter)
    
    return "".join(decoded_chars)