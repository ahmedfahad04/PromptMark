def modp(exponent: int, prime_divisor: int):
    output_value = 1
    amount = 2
    power = exponent
    
    # use exponentiation approach keeping only useful digits
    if power == 0:
        output_value = 1
    else:
        output_value = amount
        index = 1
        
        # keep doubling amount and update power iteratively
        while index < power:
            amount = (amount * 2) % prime_divisor
            index += 1
        
        output_value = amount
    
    return output_value