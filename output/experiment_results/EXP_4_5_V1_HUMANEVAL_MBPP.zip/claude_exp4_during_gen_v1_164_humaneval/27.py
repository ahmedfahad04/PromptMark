def flip_case(input_data: str) -> str:
    output_letters = []
    
    # Loop over each letter in input data
    for letter in input_data:
        if letter.islower():
            output_letters.append(letter.upper())
        elif letter.isupper():
            output_letters.append(letter.lower())
        else:
            output_letters.append(letter)
    
    assembled_output = ''.join(output_letters)
    return assembled_output