def numerical_letter_grade(grades):
    grade_outcomes = []
    
    # upper_limits define grade_point_average limits paired alongside letter_outcomes
    upper_limits = [4.0, 3.7, 3.3, 3.0, 2.7, 2.3, 2.0, 1.7, 1.3, 1.0, 0.7, 0.0]
    letter_outcomes = ['A+', 'A', 'A-', 'B+', 'B', 'B-', 'C+', 'C', 'C-', 'D+', 'D', 'D-']
    
    # iterate over all individual_gpa elements
    for individual_gpa in grades:
        if individual_gpa == 4.0:
            grade_outcomes.append('A+')
        elif individual_gpa == 0.0:
            grade_outcomes.append('E')
        else:
            # determine appropriate letter using upper_limits
            index_position = 0
            for i, limit in enumerate(upper_limits):
                if individual_gpa > limit:
                    index_position = i
                    break
            grade_outcomes.append(letter_outcomes[index_position])
    
    return grade_outcomes