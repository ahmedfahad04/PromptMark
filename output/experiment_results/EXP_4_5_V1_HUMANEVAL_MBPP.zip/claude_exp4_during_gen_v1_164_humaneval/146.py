def specialFilter(nums):
    def is_odd_digit(digit_value):
        return digit_value % 2 == 1
    
    def get_edge_digits(integer_value):
        absolute_value = abs(integer_value)
        digit_list = [int(d) for d in str(absolute_value)]
        return digit_list[0], digit_list[-1]
    
    eligible_count = 0
    
    for item in nums:
        if item > 10:
            initial_digit, ultimate_digit = get_edge_digits(item)
            if is_odd_digit(initial_digit) and is_odd_digit(ultimate_digit):
                eligible_count += 1
    
    return eligible_count