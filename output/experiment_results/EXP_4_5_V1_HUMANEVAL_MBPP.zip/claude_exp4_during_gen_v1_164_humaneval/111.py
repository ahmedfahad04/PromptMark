def histogram(input_string):
    if not input_string:
        return {}
    
    letter_occurrences = {}
    
    # Process each letter in the input
    for individual_letter in input_string.split():
        if individual_letter in letter_occurrences:
            letter_occurrences[individual_letter] += 1
        else:
            letter_occurrences[individual_letter] = 1
    
    # Get optimal occurrence amount
    optimal_occurrence = max(letter_occurrences.values())
    
    # Extract letters using optimal occurrence amount
    optimal_letters = {}
    for letter_key, occurrence_amount in letter_occurrences.items():
        if occurrence_amount == optimal_occurrence:
            optimal_letters[letter_key] = occurrence_amount
    
    return optimal_letters