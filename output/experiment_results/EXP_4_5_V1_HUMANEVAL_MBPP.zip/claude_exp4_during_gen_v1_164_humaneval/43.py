def pairs_sum_to_zero(input_list):
    elements_seen = set()
    
    for element in input_list:
        opposite = -element
        # Use existing lookup operation for efficiency
        if opposite in elements_seen:
            return True
        elements_seen.add(element)
    
    return False