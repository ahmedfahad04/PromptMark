def is_equal_to_sum_even(input_number):
    # Each positive even integer is at least 2
    # Using 4 even integers gives us a minimum of 8
    if input_number < 8:
        return False
    
    # Only even integers can be expressed as a sum of even integers
    if input_number % 2 != 0:
        return False
    
    # All even integers >= 8 can be expressed as exactly 4 positive even integers
    # One approach: use three 2's and adjust the last integer to equal input_number - 6
    adjusted_last = input_number - 6
    
    # Ensure last integer is positive and even
    if adjusted_last > 0 and adjusted_last % 2 == 0:
        return True
    
    return False