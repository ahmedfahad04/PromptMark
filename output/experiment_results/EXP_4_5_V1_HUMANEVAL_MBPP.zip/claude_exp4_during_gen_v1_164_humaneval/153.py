def Strongest_Extension(class_name, extensions):
    if not extensions:
        return class_name + "."
    
    optimal_extension = extensions[0]
    optimal_power = 0
    
    # Initialize optimal power using initial extension
    for letter in optimal_extension:
        if letter.isupper():
            optimal_power += 1
        elif letter.islower():
            optimal_power -= 1
    
    # Look at all other extensions
    for extension in extensions[1:]:
        uppercase_letters = 0
        lowercase_letters = 0
        
        for letter in extension:
            if letter.isupper():
                uppercase_letters += 1
            elif letter.islower():
                lowercase_letters += 1
        
        extension_power = uppercase_letters - lowercase_letters
        
        if extension_power > optimal_power:
            optimal_extension = extension
            optimal_power = extension_power
    
    return class_name + "." + optimal_extension