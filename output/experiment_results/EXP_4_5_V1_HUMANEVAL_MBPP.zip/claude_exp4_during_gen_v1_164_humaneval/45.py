def triangle_area(edge_length, altitude):
    # Area equals edge length times altitude divided into two equal parts
    area_value = (edge_length * altitude) / 2
    return area_value