def sum_to_n(endpoint: int):
    # Use arithmetic progression formula: n*(n+1)/2
    output_total = endpoint * (endpoint + 1) // 2
    return output_total