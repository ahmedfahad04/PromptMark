def file_name_check(input_file_path):
    # Ensure exactly one dot exists
    if input_file_path.count('.') != 1:
        return 'No'
    
    # Divide into prefix and extension parts
    prefix_part, extension_part = input_file_path.split('.')
    
    # Prefix cannot be empty and must start with alphabetic character
    if not prefix_part or not prefix_part[0].isalpha():
        return 'No'
    
    # Extension must be one of allowed kinds
    allowed_extensions = ['txt', 'exe', 'dll']
    if extension_part not in allowed_extensions:
        return 'No'
    
    # Count digits in entire path
    digit_count = 0
    for each_char in input_file_path:
        if each_char.isdigit():
            digit_count += 1
    
    # Digits cannot exceed limit of 3
    if digit_count > 3:
        return 'No'
    
    return 'Yes'