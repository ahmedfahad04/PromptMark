def is_palindrome(input_text: str) -> bool:
    return input_text == input_text[::-1]

def make_palindrome(input_text: str) -> str:
    if not input_text:
        return ''
    
    # Look for longest palindromic suffix
    for index in range(len(input_text)):
        # Extract suffix from current index to end
        ending_part = input_text[index:]
        if is_palindrome(ending_part):
            # Get prefix before palindromic suffix
            prefix_part = input_text[:index]
            # Add reversed prefix to original string
            return input_text + prefix_part[::-1]
    
    # Default case - should not reach here
    return input_text