def derivative(xs: list):
    if len(xs) <= 1:
        return []
    
    output_polynomial = []
    
    # iterate over polynomial degree indices
    for index_pos in range(1, len(xs)):
        derivative_element = xs[index_pos] * index_pos
        output_polynomial.append(derivative_element)
    
    return output_polynomial