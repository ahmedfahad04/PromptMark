def is_palindrome(input_text: str):
    # Keep only alphanumeric and put in lowercase
    processed_data = ''.join(letter for letter in input_text.lower() if letter.isalnum())
    
    # Get length and iterate up to midpoint
    data_len = len(processed_data)
    for index in range(data_len // 2):
        if processed_data[index] != processed_data[data_len - 1 - index]:
            return False
    
    return True