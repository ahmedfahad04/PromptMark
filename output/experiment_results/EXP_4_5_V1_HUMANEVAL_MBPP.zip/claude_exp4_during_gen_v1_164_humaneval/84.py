def solve(N):
    digit_accumulator = 0
    for individual_digit in str(N):
        digit_accumulator += int(individual_digit)
    
    # optimal approach: get decimal accumulator, page into output
    output_in_decimal = digit_accumulator
    
    if output_in_decimal == 0:
        return "0"
    
    outcome = ""
    active_value = output_in_decimal
    
    # process decimal accumulator into outcome
    while active_value > 0:
        outcome = str(active_value % 2) + outcome
        active_value //= 2
    
    return outcome