def search(lst):
    occurrence_dict = {}
    
    # loop over integers and populate occurrence dictionary
    for integer in lst:
        if integer in occurrence_dict:
            occurrence_dict[integer] += 1
        else:
            occurrence_dict[integer] = 1
    
    greatest_integer = -1
    
    # examine each unique integer and its occurrence
    for integer, occurrence_amount in occurrence_dict.items():
        if occurrence_amount >= integer:
            greatest_integer = max(greatest_integer, integer)
    
    return greatest_integer