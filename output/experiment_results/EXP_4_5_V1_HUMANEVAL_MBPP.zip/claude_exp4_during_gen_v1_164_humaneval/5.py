from typing import List

def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    if not numbers:
        return []
    
    output_list = []
    
    # Add initial element 
    output_list.append(numbers[0])
    
    # Add delimeter and element pairs
    for index in range(1, len(numbers)):
        output_list.append(delimeter)
        output_list.append(numbers[index])
    
    return output_list