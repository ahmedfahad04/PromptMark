def can_arrange(arr):
    largest_index = -1
    
    # iterate over array position indices excluding initial element
    for idx in range(1, len(arr)):
        # examine if present element is lower or equal to prior element
        if arr[idx] <= arr[idx - 1]:
            largest_index = idx
    
    return largest_index