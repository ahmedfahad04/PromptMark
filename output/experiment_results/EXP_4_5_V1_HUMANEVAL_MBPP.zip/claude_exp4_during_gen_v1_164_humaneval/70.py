def strange_sort_list(lst):
    if not lst:
        return []
    
    ordered_list = sorted(lst)
    output_list = []
    left_index = 0
    upper_index = len(ordered_list) - 1
    alternate_pick = True
    
    # alternate picking left and upper elements
    while left_index <= upper_index:
        if alternate_pick:
            output_list.append(ordered_list[left_index])
            left_index += 1
        else:
            output_list.append(ordered_list[upper_index])
            upper_index -= 1
        alternate_pick = not alternate_pick
    
    return output_list