def hex_key(input_digits):
    prime_alphabet = {'2', '3', '5', '7', 'B', 'D'}
    occurrence_count = 0
    
    # Iterate over each digit in input
    for alpha_digit in input_digits:
        if alpha_digit in prime_alphabet:
            occurrence_count += 1
    
    return occurrence_count