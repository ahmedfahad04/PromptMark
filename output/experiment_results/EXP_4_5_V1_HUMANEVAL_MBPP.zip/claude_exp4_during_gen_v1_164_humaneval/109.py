def move_one_ball(arr):
    if len(arr) <= 1:
        return True
    
    # Look for position where order breaks
    order_breaks = []
    for i in range(len(arr)):
        if arr[i] > arr[(i + 1) % len(arr)]:
            order_breaks.append(i)
    
    # If already sorted or at most one break point
    if len(order_breaks) == 0:
        return True
    
    if len(order_breaks) != 1:
        return False
    
    # Get the break position and check if rotation gives sorted array
    expected_start = (order_breaks[0] + 1) % len(arr)
    
    # Examine if rotating from expected_start gives sorted order
    for i in range(len(arr) - 1):
        index_current = (expected_start + i) % len(arr)
        index_next = (expected_start + i + 1) % len(arr)
        if arr[index_current] > arr[index_next]:
            return False
    
    return True