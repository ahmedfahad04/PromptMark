from typing import List

def parse_nested_parens(paren_string: str) -> List[int]:
    groups = paren_string.split()
    depth_levels = []
    
    for group in groups:
        depth_levels.append(_get_deepest_level(group))
    
    return depth_levels

def _get_deepest_level(group: str) -> int:
    open_count = 0
    deepest = 0
    
    for each_char in group:
        if each_char == '(':
            open_count += 1
            deepest = max(deepest, open_count)
        elif each_char == ')':
            open_count -= 1
    
    return deepest