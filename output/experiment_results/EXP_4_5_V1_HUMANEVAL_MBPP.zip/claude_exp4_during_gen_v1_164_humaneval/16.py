def count_distinct_characters(input_data: str) -> int:
    # Use lowercase operation to ignore letter case differences
    lowercase_input = input_data.lower()
    
    # Access unique characters using automatic deduplication
    unique_letters = set(lowercase_input)
    
    # Output exact count of distinct characters
    distinct_count = len(unique_letters)
    
    return distinct_count