def compare(game, guess):
    differences = []
    for index in range(len(game)):
        actual_outcome = game[index]
        expected_outcome = guess[index]
        
        if actual_outcome == expected_outcome:
            differences.append(0)
        else:
            # Get absolute difference
            gap = abs(actual_outcome - expected_outcome)
            differences.append(gap)
    
    return differences