def fibfib(input_value: int):
    if input_value == 0:
        return 0
    elif input_value == 1:
        return 0
    elif input_value == 2:
        return 1
    
    # Use dynamic approach keeping last three values
    oldest = 0
    earlier = 0
    latest = 1
    
    for i in range(3, input_value + 1):
        updated_value = oldest + earlier + latest
        oldest = earlier
        earlier = latest
        latest = updated_value
    
    return latest