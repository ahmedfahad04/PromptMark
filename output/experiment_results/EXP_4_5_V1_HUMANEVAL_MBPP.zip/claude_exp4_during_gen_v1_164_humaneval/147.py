def get_max_triples(n):
    # Generate array according to given formula
    array_elements = []
    for i in range(1, n + 1):
        element_value = i * i - i + 1
        array_elements.append(element_value)
    
    # Group elements by remainder when divided by 3
    groups_by_remainder = [0, 0, 0]  # index 0, 1, 2 for remainders
    for element in array_elements:
        groups_by_remainder[element % 3] += 1
    
    # Count valid triples
    def get_combinations(input_count, k):
        if input_count < k:
            return 0
        if k == 3:
            return input_count * (input_count - 1) * (input_count - 2) // 6
        return 0
    
    # All elements with remainder 0
    occupied_triples = get_combinations(groups_by_remainder[0], 3)
    
    # All elements with remainder 1  
    occupied_triples += get_combinations(groups_by_remainder[1], 3)
    
    # All elements with remainder 2
    occupied_triples += get_combinations(groups_by_remainder[2], 3)
    
    # One from each remainder group (0+1+2=3, divisible by 3)
    occupied_triples += groups_by_remainder[0] * groups_by_remainder[1] * groups_by_remainder[2]
    
    return occupied_triples