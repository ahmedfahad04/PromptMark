def bf(planet1, planet2):
    ordered_planets = ("Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune")
    
    if planet1 not in ordered_planets or planet2 not in ordered_planets:
        return ()
    
    index1 = ordered_planets.index(planet1)
    index2 = ordered_planets.index(planet2)
    
    # Determine actual order positions 
    lower_index = min(index1, index2)
    upper_index = max(index1, index2)
    
    planets_in_order = ordered_planets[lower_index + 1:upper_index]
    
    return planets_in_order