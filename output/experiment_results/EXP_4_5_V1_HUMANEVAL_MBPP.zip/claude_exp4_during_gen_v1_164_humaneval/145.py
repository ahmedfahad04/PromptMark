def order_by_points(nums):
    def digit_points_aggregate(integer_value):
        if integer_value < 0:
            digits_extracted = str(-integer_value)
            digits_aggregate = -int(digits_extracted[0]) + sum(int(digit_part) for digit_part in digits_extracted[1:])
        else:
            digits_aggregate = sum(int(digit_part) for digit_part in str(integer_value))
        return digits_aggregate
    
    # Use original position keeping logic
    ordered_pairs = sorted(enumerate(nums), key=lambda indexed_pair: (digit_points_aggregate(indexed_pair[1]), indexed_pair[0]))
    
    # Extract only integers keeping original ordering
    outcome_list = [integer_value for original_index, integer_value in ordered_pairs]
    
    return outcome_list