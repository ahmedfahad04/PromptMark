def will_it_fly(object_list, allowed_limit):
    # Individual element addition up
    aggregate_load = sum(object_list)
    
    # Object palindrome evaluation
    is_palindromic = object_list == object_list[::-1]
    
    # Additionally examine load limits alongside palindrome properties
    return is_palindromic and aggregate_load <= allowed_limit