def right_angle_triangle(a, b, c):
    edge_list = [a, b, c]
    edge_list.sort()
    
    # Using sorted order: edge_list[0] <= edge_list[1] <= edge_list[2]
    leg_one = edge_list[0]
    leg_o = edge_list[1] 
    diagonal = edge_list[2]
    
    # Apply Pythagorean theorem: a² + b² = c²
    return leg_one * leg_one + leg_o * leg_o == diagonal * diagonal