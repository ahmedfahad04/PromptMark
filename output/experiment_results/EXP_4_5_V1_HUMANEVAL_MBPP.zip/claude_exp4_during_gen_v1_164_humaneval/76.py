def is_simple_power(x, n):
    # Edge cases: x=1 is power of any positive base, invalid bases
    if x == 1:
        return n > 0
    if n <= 1:
        return False
    
    # Keep dividing x by n until we get 1 or indivisible number
    original_x = x
    while original_x > 1:
        if original_x % n != 0:
            return False
        original_x //= n
    
    return True