def greatest_common_divisor(a: int, b: int) -> int:
    def euclidean_gcd(dividend, divisor):
        # Keep dividing until divisor becomes zero
        if divisor == 0:
            return dividend
        return euclidean_gcd(divisor, dividend % divisor)
    
    # Use absolute values to handle negative inputs
    dividend = abs(a)
    divisor = abs(b)
    
    return euclidean_gcd(dividend, divisor)