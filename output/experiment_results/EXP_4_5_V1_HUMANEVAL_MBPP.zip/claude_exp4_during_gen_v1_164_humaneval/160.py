def do_algebra(operator, operand):
    expression_parts = []
    
    # alternate operands and operators into expression
    index = 0
    for op in operator:
        expression_parts.append(str(operand[index]))
        expression_parts.append(op)
        index += 1
    
    # append last operand element
    expression_parts.append(str(operand[index]))
    
    # join all parts into expression
    algebraic_expression = ' '.join(expression_parts)
    
    # evaluate and get output
    output = eval(algebraic_expression)
    
    return output