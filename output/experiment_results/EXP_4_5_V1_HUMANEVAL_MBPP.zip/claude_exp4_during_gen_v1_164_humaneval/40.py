def triples_sum_to_zero(input_list: list):
    if len(input_list) < 3:
        return False
    
    # examine all possible groups of index pairs
    for outer_index in range(len(input_list)):
        for alternate_index in range(outer_index + 1, len(input_list)):
            for end_index in range(alternate_index + 1, len(input_list)):
                # discover if elements at these positions add up
                element_one = input_list[outer_index]
                element_alternate = input_list[alternate_index]
                element_end = input_list[end_index]
                
                if element_one + element_alternate + element_end == 0:
                    return True
    
    return False