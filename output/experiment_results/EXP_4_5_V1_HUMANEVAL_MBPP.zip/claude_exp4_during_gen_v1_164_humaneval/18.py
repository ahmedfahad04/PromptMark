def how_many_times(original_text: str, pattern: str) -> int:
    if not pattern:
        return 0
    
    overlap_count = 0
    index_position = 0
    
    # Keep looking until pattern is not available in original text
    while index_position <= len(original_text) - len(pattern):
        if original_text[index_position:index_position + len(pattern)] == pattern:
            overlap_count += 1
        index_position += 1
    
    return overlap_count