def find_max(words):
    if not words:
        return ""
    
    optimal_word = ""
    optimal_unique_count = -1
    
    for each_word in words:
        unique_letters = set(each_word)
        unique_count = len(unique_letters)
        
        # Update if more unique letters or lexicographically earlier
        if (unique_count > optimal_unique_count or 
            (unique_count == optimal_unique_count and each_word < optimal_word)):
            optimal_word = each_word
            optimal_unique_count = unique_count
    
    return optimal_word