def monotonic(input_list: list):
    if len(input_list) <= 1:
        return True
    
    # examine ordering pattern using initial pair
    ascending_order = True
    descending_order = True
    
    for index in range(len(input_list) - 1):
        element_current = input_list[index]
        element_next = input_list[index + 1]
        
        if element_current > element_next:
            ascending_order = False
        if element_current < element_next:
            descending_order = False
    
    return ascending_order or descending_order