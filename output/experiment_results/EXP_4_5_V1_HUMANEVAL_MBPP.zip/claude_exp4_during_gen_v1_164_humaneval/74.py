def total_match(lst1, lst2):
    initial_list_length = sum(len(element) for element in lst1)
    alternative_list_length = sum(len(element) for element in lst2)
    
    # If equal lengths or initial list is smaller, pick initial list
    if initial_list_length <= alternative_list_length:
        optimal_list = lst1
    else:
        optimal_list = lst2
    
    return optimal_list