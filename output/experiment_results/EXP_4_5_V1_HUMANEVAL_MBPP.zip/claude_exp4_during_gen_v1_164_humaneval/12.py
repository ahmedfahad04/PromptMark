from typing import List, Optional

def longest(input_strings: List[str]) -> Optional[str]:
    if not input_strings:
        return None
    
    optimal_element = input_strings[0]
    optimal_length = len(optimal_element)
    
    # iterate over remaining elements
    for each_item in input_strings[1:]:
        item_length = len(each_item)
        if item_length > optimal_length:
            optimal_element = each_item
            optimal_length = item_length
    
    return optimal_element