def fizz_buzz(upper_limit: int):
    occurrence_total = 0
    
    # Examine all integers up to upper_limit
    for integer_value in range(upper_limit):
        # Keep only digits divisible exactly per our goal
        if integer_value % 11 == 0 or integer_value % 13 == 0:
            # Examine digits inside our eligible integer
            digit_list = str(integer_value)
            occurrence_total += digit_list.count('7')
    
    return occurrence_total