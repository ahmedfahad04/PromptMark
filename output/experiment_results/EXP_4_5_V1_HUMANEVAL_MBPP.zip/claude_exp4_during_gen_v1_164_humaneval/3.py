from typing import List

def below_zero(operations: List[int]) -> bool:
    account_balance = 0  # initial account amount
    
    # iterate over each operation in operations
    for operation in operations:
        account_balance += operation
        # if account goes under zero, exit immediately  
        if account_balance < 0:
            return True
    
    return False