def starts_one_ends(n):
    if n == 1:
        return 1
    
    # All n-digit positive integers: 9 * 10^(n-1)
    # integers ending with 1: 9 * 10^(n-2) 
    # integers starting with 1: 10^(n-1)
    # integers both starting and ending with 1: 10^(n-2)
    
    ending_ones = 9 * (10 ** (n - 2))
    opening_ones = 10 ** (n - 1) 
    overlap = 10 ** (n - 2)
    
    # inclusion-exclusion principle
    aggregate_total = ending_ones + opening_ones - overlap
    return aggregate_total