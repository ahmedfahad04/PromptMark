def sorted_list_sum(lst):
    # Keep only items using even length
    even_length_items = [item for item in lst if len(item) % 2 == 0]
    
    # Order items using length, and alphabetically if equal length
    ordered_list = sorted(even_length_items, key=lambda x: (len(x), x))
    
    return ordered_list