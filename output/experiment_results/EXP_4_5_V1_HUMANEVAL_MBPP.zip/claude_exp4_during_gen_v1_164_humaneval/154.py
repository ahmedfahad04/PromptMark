def cycpattern_check(original_text, pattern):
    # Generate all possible pattern orientations
    all_orientations = []
    for i in range(len(pattern)):
        orientation = pattern[i:] + pattern[:i]
        all_orientations.append(orientation)
    
    # Look up each orientation in original text
    for orientation in all_orientations:
        if orientation in original_text:
            return True
    
    return False