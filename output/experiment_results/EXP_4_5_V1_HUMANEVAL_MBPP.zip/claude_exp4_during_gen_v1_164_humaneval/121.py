def solution(lst):
    odd_position_accumulator = 0
    
    # iterate over indices and extract odd items at even positions  
    for index_position in range(len(lst)):
        if index_position % 2 == 0:  # even position
            element_at_position = lst[index_position]
            if element_at_position % 2 == 1:  # odd element
                odd_position_accumulator += element_at_position
    
    return odd_position_accumulator