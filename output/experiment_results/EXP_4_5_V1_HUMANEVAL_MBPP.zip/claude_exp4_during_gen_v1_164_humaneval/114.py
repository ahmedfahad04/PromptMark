def minSubArraySum(nums):
    if not nums:
        return 0
    
    # Initialize optimal_min and global_min to first element
    optimal_min = nums[0]
    global_min = nums[0]
    
    # Process each element starting from index 1
    for i in range(1, len(nums)):
        element = nums[i]
        # Keep extending existing array or just pick current element
        optimal_min = min(element, optimal_min + element)
        # Update global minimum across all possible arrays
        global_min = min(global_min, optimal_min)
    
    return global_min