def is_nested(input_string):
    opening_positions = []
    
    for index, element in enumerate(input_string):
        if element == '[':
            opening_positions.append(index)
        elif element == ']' and opening_positions:
            matched_opening = opening_positions.pop()
            
            # Look for any complete pairs within current pair
            for other_index, other_element in enumerate(input_string):
                if matched_opening < other_index < index:
                    if other_element == '[':
                        # Look for matching closing bracket
                        for inner_index in range(other_index + 1, index):
                            if input_string[inner_index] == ']':
                                return True
    
    return False