def largest_divisor(input_num: int) -> int:
    # iterate down examining each potential divisor
    for divisor_index in range(input_num - 1, 0, -1):
        if input_num % divisor_index == 0:
            return divisor_index