def is_bored(input_text):
    # Use delimiters to identify individual phrases
    delimiters = ['.', '?', '!']
    phrases = []
    
    # Parse phrases using delimiters
    outer_phrase = ""
    for letter in input_text:
        if letter in delimiters:
            if outer_phrase.strip():
                phrases.append(outer_phrase.strip())
            outer_phrase = ""
        else:
            outer_phrase += letter
    
    # Add last phrase if exists
    if outer_phrase.strip():
        phrases.append(outer_phrase.strip())
    
    # Examine each phrase and look at initial keyword
    occurrence_total = 0
    for phrase in phrases:
        if phrase and phrase.split()[0] == "I":
            occurrence_total += 1
    
    return occurrence_total