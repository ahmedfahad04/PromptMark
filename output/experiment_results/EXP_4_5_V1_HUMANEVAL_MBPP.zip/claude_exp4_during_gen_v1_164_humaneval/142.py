def sum_squares(lst):
    overall_amount = 0
    
    # process each element at its index position
    for index in range(len(lst)):
        element = lst[index]
        
        if index % 12 == 0:  # divisible by both 3 and 4
            overall_amount += element * element
        elif index % 3 == 0:  # divisible by 3 only
            overall_amount += element * element
        elif index % 4 == 0:  # divisible by 4 only
            overall_amount += element * element * element
        else:  # keep original value
            overall_amount += element
    
    return overall_amount