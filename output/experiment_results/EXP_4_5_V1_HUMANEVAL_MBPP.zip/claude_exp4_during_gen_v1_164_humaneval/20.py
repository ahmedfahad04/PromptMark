from typing import List, Tuple

def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    initial_gap = float('inf')
    optimal_duo = (0.0, 0.0)
    
    # Look at all pairs of elements
    for i in range(len(numbers)):
        for j in range(i + 1, len(numbers)):
            # Keep pair ordered as expected
            left_element = min(numbers[i], numbers[j])
            depth_element = max(numbers[i], numbers[j])
            
            # Update if gap is smaller
            actual_gap = depth_element - left_element
            if actual_gap < initial_gap:
                initial_gap = actual_gap
                optimal_duo = (left_element, depth_element)
    
    return optimal_duo