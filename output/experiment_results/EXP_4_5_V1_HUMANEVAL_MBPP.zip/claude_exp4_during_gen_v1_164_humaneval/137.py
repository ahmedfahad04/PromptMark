def compare_one(a, b):
    def parse_value(input_val):
        if isinstance(input_val, (int, float)):
            return float(input_val)
        elif isinstance(input_val, str):
            # deal_with decimal separators like comma or dot
            processed_val = input_val.replace(',', '.')
            return float(processed_val)
    
    actual_a = parse_value(a)
    actual_b = parse_value(b)
    
    if actual_a == actual_b:
        return None
    elif actual_a > actual_b:
        return a
    else:
        return b