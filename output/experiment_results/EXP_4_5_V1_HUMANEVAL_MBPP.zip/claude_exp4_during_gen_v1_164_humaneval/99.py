def closest_integer(value):
    original_value = float(value)
    
    if original_value >= 0:
        lower_integer = int(original_value)
        upper_integer = lower_integer + 1
    else:
        upper_integer = int(original_value)
        lower_integer = upper_integer - 1
    
    distance_lower = abs(original_value - lower_integer)
    distance_upper = abs(original_value - upper_integer)
    
    if distance_lower < distance_upper:
        return lower_integer
    elif distance_upper < distance_lower:
        return upper_integer
    else:
        if original_value >= 0:
            return upper_integer
        else:
            return lower_integer