from typing import List

def has_close_elements(numbers: List[float], threshold: float) -> bool:
    list_length = len(numbers)
    
    # outer loop index
    for outer_index in range(list_length):
        # inner loop index
        for inner_index in range(outer_index + 1, list_length):
            element_a = numbers[outer_index]
            element_b = numbers[inner_index]
            
            # absolute difference check
            if abs(element_a - element_b) < threshold:
                return True
    
    return False