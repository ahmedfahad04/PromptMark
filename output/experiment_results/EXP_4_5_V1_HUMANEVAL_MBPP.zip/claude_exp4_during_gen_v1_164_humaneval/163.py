def generate_integers(a, b):
    lower_edge = min(a, b)
    upper_edge = max(a, b)
    
    even_digits = []
    
    # examine each integer in order
    for integer in range(lower_edge, upper_edge + 1):
        if integer % 2 == 0 and 0 <= integer <= 9:
            even_digits.append(integer)
    
    return even_digits