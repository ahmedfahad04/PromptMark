from typing import List

def filter_by_prefix(input_list: List[str], prefix: str) -> List[str]:
    output_list = []
    
    # iterate over each item in the input list
    for item in input_list:
        if item.startswith(prefix):
            output_list.append(item)
    
    return output_list