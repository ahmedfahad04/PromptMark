def car_race_collision(automobiles_per_direction: int):
    # Each auto going left-to-right intersects each auto going right-to-left
    impacts = automobiles_per_direction * automobiles_per_direction
    return impacts