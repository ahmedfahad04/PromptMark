def fruit_distribution(input_description, overall_amount):
    # Extract all digits using easier approach
    digits_list = []
    
    i = 0
    while i < len(input_description):
        if input_description[i].isdigit():
            digit_group = ""
            while i < len(input_description) and input_description[i].isdigit():
                digit_group += input_description[i]
                i += 1
            digits_list.append(int(digit_group))
        else:
            i += 1
    
    # Get apple and orange amounts
    apple_amount = digits_list[0] if len(digits_list) > 0 else 0
    orange_amount = digits_list[1] if len(digits_list) > 1 else 0
    
    # Determine leftover amount
    leftover_amount = overall_amount - apple_amount - orange_amount
    
    return leftover_amount