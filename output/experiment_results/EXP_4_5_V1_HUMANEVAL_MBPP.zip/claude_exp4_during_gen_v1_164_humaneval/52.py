def below_threshold(input_list: list, upper_limit: int):
    # examine all elements against upper_limit
    for element in input_list:
        if element >= upper_limit:
            # element exceeds or equals upper_limit
            return False
    return True