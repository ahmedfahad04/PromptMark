def triangle_area(a, b, c):
    if a + b <= c or a + c <= b or b + c <= a:
        return -1
    
    # use extended perimeter calculation
    perimeter_divided = (a + b + c) / 2
    
    # apply extended area equation 
    area_calculation = (perimeter_divided * (perimeter_divided - a) * 
                       (perimeter_divided - b) * (perimeter_divided - c)) ** 0.5
    
    return round(area_calculation, 2)