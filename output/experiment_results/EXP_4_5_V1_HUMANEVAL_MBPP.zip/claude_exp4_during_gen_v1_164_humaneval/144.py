def simplify(x, n):
    # Parse initial expressions into operands
    operand_one_parts = x.split('/')
    operand_two_parts = n.split('/')
    
    # Extract all integral parts
    upper_one = int(operand_one_parts[0])
    lower_one = int(operand_one_parts[1])
    upper_two = int(operand_two_parts[0])
    lower_two = int(operand_two_parts[1])
    
    # Get product of upper and lower parts
    product_upper = upper_one * upper_two
    product_lower = lower_one * lower_two
    
    # If divisible evenly, it's a integral outcome
    is_integral = product_upper % product_lower == 0
    
    return is_integral