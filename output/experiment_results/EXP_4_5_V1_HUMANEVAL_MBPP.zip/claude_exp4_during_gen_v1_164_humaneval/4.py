from typing import List

def mean_absolute_deviation(numbers: List[float]) -> float:
    # Get average of all input values
    overall_average = sum(numbers) / len(numbers)
    
    # Keep all absolute differences
    absolute_differences = []
    
    # Process each element against average
    for each_value in numbers:
        absolute_diff = abs(each_value - overall_average)
        absolute_differences.append(absolute_diff)
    
    # Output average of all differences
    return sum(absolute_differences) / len(absolute_differences)