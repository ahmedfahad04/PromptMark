def multiply(alpha, delta):
    # Extract unit digits and get absolute product
    unit_alpha = abs(alpha) % 10
    unit_delta = abs(delta) % 10
    
    output = unit_alpha * unit_delta
    return output