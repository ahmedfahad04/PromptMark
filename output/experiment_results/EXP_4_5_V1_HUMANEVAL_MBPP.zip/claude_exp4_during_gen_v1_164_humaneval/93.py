def encode(message):
    alphabet = 'abcdefghijklmnopqrstuvwxyz'
    encoded_result = ''
    
    for letter in message:
        if letter == ' ':
            encoded_result += ' '
        else:
            # Interchange case
            if letter.islower():
                letter = letter.upper()
            else:
                letter = letter.lower()
            
            # Process vowel replacement
            if letter.lower() in 'aeiou':
                original_index = alphabet.index(letter.lower())
                updated_position = (original_index + 2) % 26
                encoded_letter = alphabet[updated_position]
                
                if letter.isupper():
                    encoded_result += encoded_letter.upper()
                else:
                    encoded_result += encoded_letter
            else:
                encoded_result += letter
    
    return encoded_result