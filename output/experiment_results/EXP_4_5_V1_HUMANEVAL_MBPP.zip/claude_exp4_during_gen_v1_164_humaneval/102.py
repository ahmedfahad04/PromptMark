def choose_num(x, y):
    if x > y:
        return -1
    
    # Get upper limit as our initial pick
    upper_pick = y
    
    # If upper pick is odd, get the largest even digit
    if upper_pick % 2 == 1:
        upper_pick -= 1
    
    # Ensure our even pick is in acceptable domain
    if upper_pick >= x:
        return upper_pick
    else:
        return -1