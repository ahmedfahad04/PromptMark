def largest_prime_factor(input_value: int):
    original_input = input_value
    largest_divisor = 1
    
    # divide out all even occurrences
    if input_value % 2 == 0:
        largest_divisor = 2
        while input_value % 2 == 0:
            input_value //= 2
    
    # obtain odd divisors up until integer portion of area_limit
    odd_divisor = 3
    area_limit = int(input_value ** 0.5) + 1
    
    for iterator in range(odd_divisor, area_limit, 2):
        if input_value % iterator == 0:
            largest_divisor = iterator
            while input_value % iterator == 0:
                input_value //= iterator
    
    # if original_input exceeds one after decomposition, it's a prime divisor
    if input_value > 1:
        largest_divisor = input_value
    
    return largest_divisor