def remove_vowels(original_input):
    excluded_letters = {'a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U'}
    output_data = []
    
    # iterate over each letter in original input
    for each_letter in original_input:
        if each_letter not in excluded_letters:
            output_data.append(each_letter)
    
    processed_outcome = ''.join(output_data)
    return processed_outcome