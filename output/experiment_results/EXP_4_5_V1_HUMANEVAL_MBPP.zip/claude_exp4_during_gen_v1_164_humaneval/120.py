def maximum(arr, k):
    if k == 0:
        return []
    
    # Order all elements
    ordered_elements = sorted(arr)
    
    # Extract k largest elements
    k_largest = ordered_elements[-k:]
    
    return k_largest