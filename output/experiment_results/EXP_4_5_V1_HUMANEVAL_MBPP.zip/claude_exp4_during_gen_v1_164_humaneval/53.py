def add(x: int, y: int):
    operation_output = x + y
    return operation_output