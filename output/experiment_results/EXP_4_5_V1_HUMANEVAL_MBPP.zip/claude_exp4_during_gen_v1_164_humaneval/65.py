def circular_shift(input_value, offset_amount):
    digit_list = list(str(abs(input_value)))
    digit_count = len(digit_list)
    
    if offset_amount > digit_count:
        return ''.join(digit_list[::-1])
    
    # apply offset using position adjustment
    effective_offset = offset_amount % digit_count
    adjusted_digits = digit_list[-effective_offset:] + digit_list[:-effective_offset]
    
    return ''.join(adjusted_digits)