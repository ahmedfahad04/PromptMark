def reverse_delete(input_string, delete_letters):
    # Keep only letters that are not in delete_letters
    updated_string = ""
    for letter in input_string:
        if letter not in delete_letters:
            updated_string += letter
    
    # Determine if updated_string is a palindrome
    is_palindrome = updated_string == updated_string[::-1]
    
    return (updated_string, is_palindrome)