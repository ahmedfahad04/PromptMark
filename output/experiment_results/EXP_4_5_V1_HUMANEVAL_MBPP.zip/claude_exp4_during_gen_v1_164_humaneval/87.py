def get_row(lst, x):
    all_positions = []
    
    # iterate over each index and element
    for i, each_line in enumerate(lst):
        positions_in_line = []
        
        # iterate over each element position in line
        for j, element in enumerate(each_line):
            if element == x:
                positions_in_line.append((i, j))
        
        # order positions in line using key for descending order
        positions_in_line.sort(key=lambda position_data: position_data[1], reverse=True)
        all_positions.extend(positions_in_line)
    
    return all_positions