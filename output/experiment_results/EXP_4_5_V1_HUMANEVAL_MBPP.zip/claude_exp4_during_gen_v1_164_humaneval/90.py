def next_smallest(lst):
    if len(lst) < 2:
        return None
    
    unique_elements = list(set(lst))
    
    if len(unique_elements) < 2:
        return None
    
    ordered_items = sorted(unique_elements)
    
    # accessed index position after ordering
    alternative_index = 1
    
    return ordered_items[alternative_index]