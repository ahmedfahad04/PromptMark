def pluck(arr):
    if not arr:
        return []
    
    ixmin_even_index = -1
    uvalue_min = float('inf')
    
    # Look through array to find the smallest even value
    for i, ovalue in enumerate(arr):
        if ovalue % 2 == 0 and ovalue < uvalue_min:
            uvalue_min = ovalue
            ixmin_even_index = i
    
    if ixmin_even_index == -1:
        return []
    
    return [uvalue_min, ixmin_even_index]