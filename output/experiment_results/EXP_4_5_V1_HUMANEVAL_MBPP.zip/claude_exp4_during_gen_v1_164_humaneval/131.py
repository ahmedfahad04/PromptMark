def digits(odd_digit_input):
    odd_product = 1
    odd_digits_exist = False
    
    for digit_position in str(odd_digit_input):
        digit_value = int(digit_position)
        if digit_value % 2 == 1:  # odd digit
            odd_product *= digit_value
            odd_digits_exist = True
    
    # if all digits are even
    if not odd_digits_exist:
        return 0
    
    return odd_product