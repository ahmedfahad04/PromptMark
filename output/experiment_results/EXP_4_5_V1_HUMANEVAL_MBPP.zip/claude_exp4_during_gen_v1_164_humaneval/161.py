def solve(input_string):
    letters_detected = False
    output_list = []
    
    # Process each character and detect letters
    for each_char in input_string:
        if each_char.isalpha():
            letters_detected = True
            if each_char.islower():
                output_list.append(each_char.upper())
            else:
                output_list.append(each_char.lower())
        else:
            output_list.append(each_char)
    
    # If letters exist, join processed chars; otherwise reverse original
    if letters_detected:
        return ''.join(output_list)
    else:
        return input_string[::-1]