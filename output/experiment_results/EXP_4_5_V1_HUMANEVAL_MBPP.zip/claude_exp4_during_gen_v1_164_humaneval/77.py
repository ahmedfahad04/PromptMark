def iscube(a):
    if a == 0:
        return True
    
    # Deal with negative input values
    if a < 0:
        a = -a
        is_negative = True
    else:
        is_negative = False
    
    # Use approximation to get initial guess
    approximate_root = round(a ** (1/3))
    
    # Exact integer operations for precision
    expected_cube = approximate_root ** 3
    
    if expected_cube == a:
        return True
    
    # Double check adjacent integers due to precision
    up_adjacent = (approximate_root + 1) ** 3
    down_adjacent = (approximate_root - 1) ** 3 if approximate_root > 1 else 0
    
    return up_adjacent == a or down_adjacent == a