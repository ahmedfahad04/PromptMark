from typing import List

def factorize(original_integer: int) -> List[int]:
    prime_list = []
    divider = 2
    
    # Keep dividing until original_integer equals 1
    while original_integer > 1:
        while original_integer % divider == 0:
            prime_list.append(divider)
            original_integer //= divider
        divider += 1
        
        # optimization: exit early if divider exceeds potential prime
        if divider * divider > original_integer:
            if original_integer > 1:
                prime_list.append(original_integer)
            break
    
    return prime_list