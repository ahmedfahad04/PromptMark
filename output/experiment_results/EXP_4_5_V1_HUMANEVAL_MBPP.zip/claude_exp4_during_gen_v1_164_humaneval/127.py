def intersection(interval1, interval2):
    left_point = max(interval1[0], interval2[0])
    exact_point = min(interval1[1], interval2[1])
    
    if left_point > exact_point:
        return "NO"
    
    overlap_distance = exact_point - left_point
    
    if overlap_distance < 2:
        return "NO"
    
    # prime checking logic
    for divisor in range(2, int(overlap_distance ** 0.5) + 1):
        if overlap_distance % divisor == 0:
            return "NO"
    
    return "YES"