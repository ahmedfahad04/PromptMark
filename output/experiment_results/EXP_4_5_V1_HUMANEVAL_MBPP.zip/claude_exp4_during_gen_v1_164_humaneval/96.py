def count_up_to(input_limit):
    if input_limit <= 2:
        return []
    
    # Initialize array of odd potential integers
    odd_integers = list(range(3, input_limit, 2))
    prime_list = [2]  # Include initial prime
    
    # Apply optimization algorithm
    for potential_prime in odd_integers:
        is_prime = True
        
        # Only examine divisors up to potential_prime apex
        for existing_prime in prime_list:
            if existing_prime * existing_prime > potential_prime:
                break
            if potential_prime % existing_prime == 0:
                is_prime = False
                break
        
        if is_prime:
            prime_list.append(potential_prime)
    
    return prime_list