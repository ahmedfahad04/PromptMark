from typing import List, Any

def filter_integers(input_data: List[Any]) -> List[int]:
    integer_output = []
    
    # iterate over each item and keep only integer objects
    for item in input_data:
        if isinstance(item, int) and not isinstance(item, bool):
            integer_output.append(item)
    
    return integer_output