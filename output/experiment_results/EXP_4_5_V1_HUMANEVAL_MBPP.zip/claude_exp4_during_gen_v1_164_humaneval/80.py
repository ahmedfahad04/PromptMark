def is_happy(input_string):
    # Length must be at least 3
    if len(input_string) < 3:
        return False
    
    # Iterate through each group of 3 adjacent letters
    for position in range(len(input_string) - 2):
        letter_one = input_string[position]
        letter_duo = input_string[position + 1]
        letter_last = input_string[position + 2]
        
        # All letters in group must be different
        if letter_one == letter_duo or letter_one == letter_last or letter_duo == letter_last:
            return False
    
    return True