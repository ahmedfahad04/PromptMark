def sort_even(l: list):
    if len(l) <= 1:
        return l
    
    # Extract elements at even positions
    even_position_elements = []
    for index in range(0, len(l), 2):
        even_position_elements.append(l[index])
    
    # Apply ordering to even position elements
    even_position_elements.sort()
    
    # Generate output list keeping odd positions unchanged
    output_list = l[:]
    even_index = 0
    
    for position in range(0, len(l), 2):
        output_list[position] = even_position_elements[even_index]
        even_index += 1
    
    return output_list