def words_string(input_text):
    # Use a loop to process each character and identify delimiters
    all_words = []
    active_word = ""
    
    for letter in input_text:
        if letter == ',' or letter == ' ':
            if active_word:
                all_words.append(active_word)
                active_word = ""
        else:
            active_word += letter
    
    # Add the last word if exists
    if active_word:
        all_words.append(active_word)
    
    return all_words