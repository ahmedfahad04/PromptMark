def x_or_y(input_digit, option_a, option_e):
    def look_up_primality(digit_input):
        if digit_input < 2:
            return False
        
        idx = 2
        while idx * idx <= digit_input:
            if digit_input % idx == 0:
                return False
            idx += 1
        return True
    
    # evaluate if digit is prime, pick appropriate option
    if look_up_primality(input_digit):
        return option_a
    else:
        return option_e