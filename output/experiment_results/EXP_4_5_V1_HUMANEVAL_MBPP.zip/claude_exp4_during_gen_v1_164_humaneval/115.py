def max_fill(grid, capacity):
    import math
    
    overall_drops = 0
    
    # Process each individual pool
    for pool in grid:
        # Add up all units in pool
        units_in_pool = sum(pool)
        
        # Get drops needed using division
        drops_needed = math.ceil(units_in_pool / capacity)
        overall_drops += drops_needed
    
    return overall_drops