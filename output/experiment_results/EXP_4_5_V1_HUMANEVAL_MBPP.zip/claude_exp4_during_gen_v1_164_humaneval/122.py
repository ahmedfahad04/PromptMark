def add_elements(arr, k):
    ongoing_addition = 0
    
    # Loop using index and extract digits up to k positions
    for index_position in range(k):
        element_at_index = arr[index_position]
        
        # Only add if element uses at maximum dual digits
        if -99 <= element_at_index <= 99:
            ongoing_addition += element_at_index
    
    return ongoing_addition