import math

def sum_squares(lst):
    upper_list = []
    # append each upper limit of elements
    for element in lst:
        upper_element = math.ceil(element)
        upper_list.append(upper_element)
    
    # add up all individual elemental powers
    all_powers = 0
    for upper_element in upper_list:
        elemental_power = upper_element ** 2
        all_powers += elemental_power
    
    return all_powers