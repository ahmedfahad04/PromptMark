def prod_signs(arr):
    if not arr:
        return None
    
    if 0 in arr:
        return 0
    
    # aggregate all absolute values
    aggregate_sum = sum(abs(x) for x in arr)
    
    # identify overall sign by counting negatives
    odd_negatives = sum(1 for x in arr if x < 0) % 2
    overall_indicator = -1 if odd_negatives else 1
    
    return aggregate_sum * overall_indicator