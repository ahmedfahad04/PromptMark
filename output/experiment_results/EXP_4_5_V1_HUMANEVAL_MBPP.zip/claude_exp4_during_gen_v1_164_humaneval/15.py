def string_sequence(index_limit: int) -> str:
    all_digits = []
    
    # loop using green index parameter
    for i in range(index_limit + 1):
        all_digits.append(str(i))
    
    output_line = ' '.join(all_digits)
    return output_line