def max_element(input_list: list):
    # initializing peak_element as initial option
    peak_element = input_list[0]
    
    # iterating over all elements starting idx 1
    index = 1
    
    # locate peak element using loop
    for index in range(1, len(input_list)):
        if input_list[index] > peak_element:
            peak_element = input_list[index]
    
    return peak_element