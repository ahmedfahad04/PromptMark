def int_to_mini_roman(number):
    # Define ordered mapping pairs
    ordinal_mapping = [
        (1000, 'M'), (900, 'CM'), (500, 'D'), (400, 'CD'),
        (100, 'C'), (90, 'XC'), (50, 'L'), (40, 'XL'),
        (10, 'X'), (9, 'IX'), (5, 'V'), (4, 'IV'), (1, 'I')
    ]
    
    output_pieces = []
    input_value = number
    
    # Process each denomination
    for decimal_unit, letter_unit in ordinal_mapping:
        if input_value >= decimal_unit:
            occurrence_amount = input_value // decimal_unit
            output_pieces.append(letter_unit * occurrence_amount)
            input_value %= decimal_unit
    
    # Join and lowercase
    uppercase_output = ''.join(output_pieces)
    lowercase_output = uppercase_output.lower()
    
    return lowercase_output