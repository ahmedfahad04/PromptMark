def unique_digits(x):
    odd_digit_list = []
    
    for integer_value in x:
        digits_all_odd = True
        
        # Extract each digit and examine if it's odd
        for digit_character in str(integer_value):
            digit_int = int(digit_character)
            if digit_int % 2 == 0:  # Even digit found
                digits_all_odd = False
                break
        
        if digits_all_odd:
            odd_digit_list.append(integer_value)
    
    return sorted(odd_digit_list)