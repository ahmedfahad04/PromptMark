import math

def poly(xs: list, x: float):
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])

def find_zero(xs: list):
    left_edge = -1.0
    index = 0
    
    while index < 1000:
        if poly(xs, left_edge) * poly(xs, left_edge + 1) < 0:
            break
        left_edge -= 1.0
        index += 1
    
    upper_edge = left_edge + 1.0
    
    # Use bracketing approach
    for iteration in range(100):
        point = (left_edge + upper_edge) / 2.0
        evaluation = poly(xs, point)
        
        if abs(evaluation) < 1e-10:
            return point
            
        if poly(xs, left_edge) * evaluation < 0:
            upper_edge = point
        else:
            left_edge = point
    
    return (left_edge + upper_edge) / 2.0