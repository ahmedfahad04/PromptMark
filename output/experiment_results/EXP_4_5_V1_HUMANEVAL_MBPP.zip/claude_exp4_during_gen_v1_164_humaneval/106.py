def f(index_limit):
    output_list = []
    
    for position in range(1, index_limit + 1):
        if position % 2 == 0:
            # even index: calculate product of all integers up to position
            product_accumulator = 1
            for k in range(1, position + 1):
                product_accumulator *= k
            output_list.append(product_accumulator)
        else:
            # odd index: calculate addition of all integers up to position
            addition_accumulator = 0
            for k in range(1, position + 1):
                addition_accumulator += k
            output_list.append(addition_accumulator)
    
    return output_list