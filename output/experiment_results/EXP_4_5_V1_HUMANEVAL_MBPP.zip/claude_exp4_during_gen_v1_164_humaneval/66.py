def digitSum(input_text):
    ascii_total = 0
    
    # iterate over each letter in input
    for each_letter in input_text:
        if each_letter.isupper():
            ascii_total += ord(each_letter)
    
    # output accumulated ascii total
    return ascii_total