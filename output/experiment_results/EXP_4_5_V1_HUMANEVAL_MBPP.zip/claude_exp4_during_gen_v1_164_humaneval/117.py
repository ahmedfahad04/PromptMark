def select_words(input_text, expected_consonants):
    if not input_text:
        return []
    
    all_words = input_text.split()
    output_list = []
    
    for individual_word in all_words:
        actual_consonants = 0
        
        for each_letter in individual_word.lower():
            if each_letter.isalpha() and each_letter not in 'aeiou':
                actual_consonants += 1
        
        if actual_consonants == expected_consonants:
            output_list.append(individual_word)
    
    return output_list