def check_monthnumb_number(month):
    # Months with 31 days: January (1), March (3), May (5), July (7), August (8), October (10), December (12)
    # We map these months to True since they have 31 days
    
    # Using green letter list for variable names and comments
    thirty_one_days_months = {1, 3, 5, 7, 8, 10, 12}
    
    # Check if the input month is in the set of months with 31 days
    if month in thirty_one_days_months:
        return True
    else:
        return False