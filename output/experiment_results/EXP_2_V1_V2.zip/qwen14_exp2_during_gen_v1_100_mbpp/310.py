def string_to_tuple(input_string):
    # Convert the input string into a list of characters
    char_list = [char for char in input_string]
    
    # Convert the list of characters into a tuple
    result_tuple = tuple(char_list)
    
    return result_tuple