def subject_marks(subjects):
    """
    Sorts a list of tuples based on the second value of each tuple.
    
    Args:
    subjects (list): A list of tuples where each tuple contains a subject name and its corresponding mark.
    
    Returns:
    list: The sorted list of tuples based on the marks.
    """
    # Sort the list of tuples based on the second element of each tuple
    sorted_subjects = sorted(subjects, key=lambda x: x[1])
    return sorted_subjects