def square_nums(nums):
    # This function takes a list of numbers and returns a new list containing the squares of each element.
    return [num ** 2 for num in nums]