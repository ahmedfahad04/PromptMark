import math

def surface_Area(base_edge, height):
    # Calculate the slant height using the Pythagorean theorem
    slant_height = math.sqrt((base_edge / 2)**2 + height**2)
    
    # Calculate the base area
    base_area = base_edge ** 2
    
    # Calculate the lateral area
    lateral_area = 4 * (base_edge * slant_height) / 2
    
    # Calculate the total surface area
    total_surface_area = base_area + lateral_area
    
    return total_surface_area