def gcd(a, b):
    while b != 0:
        a, b = b, a % b
    return a

def extended_gcd(a, b):
    if a == 0:
        return b, 0, 1
    gcd, x1, y1 = extended_gcd(b % a, a)
    x = y1 - (b // a) * x1
    y = x1
    return gcd, x, y

def find_solution(a, b, n):
    # Check if gcd(a, b) divides n
    if n % gcd(a, b) != 0:
        return None
    
    # Find one solution using Extended Euclidean Algorithm
    _, x, y = extended_gcd(a, b)
    
    # Scale the solution to fit the equation ax + by = n
    x *= n // gcd(a, b)
    y *= n // gcd(a, b)
    
    return (x, y)