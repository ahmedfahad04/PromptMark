def largest_subset(nums):
    # Sort the array to make it easier to find pairs
    nums.sort()
    
    # Dictionary to store the size of the largest subset ending with each number
    dp = {num: 1 for num in nums}
    
    # Iterate through each number in the sorted array
    for i in range(len(nums)):
        for j in range(i):
            # Check if nums[i] is divisible by nums[j]
            if nums[i] % nums[j] == 0:
                # Update the dp value for nums[i]
                dp[nums[i]] = max(dp[nums[i]], dp[nums[j]] + 1)
    
    # The result will be the maximum value in the dp dictionary
    return max(dp.values())