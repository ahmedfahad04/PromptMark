def extract_quotation(input_string):
    result = []
    start_index = -1
    
    for i, char in enumerate(input_string):
        if char == '"':
            if start_index == -1:
                start_index = i + 1
            elif start_index != -1 and i > start_index:
                result.append(input_string[start_index:i])
                start_index = -1
                
    return result