def count_X(tpl, elem):
    # Initialize a counter to zero
    cnt = 0
    
    # Iterate through each item in the tuple
    for item in tpl:
        # If the current item matches the element we're counting, increment the counter
        if item == elem:
            cnt += 1
            
    # Return the final count after iterating through all items
    return cnt