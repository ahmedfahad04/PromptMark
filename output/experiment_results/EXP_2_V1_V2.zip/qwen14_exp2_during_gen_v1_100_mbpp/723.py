def count_same_pair(lst1, lst2):
    # Initialize a counter to keep track of matching pairs
    match_count = 0
    
    # Iterate through each index of the lists
    for i in range(len(lst1)):
        # Check if the elements at the current index are the same
        if lst1[i] == lst2[i]:
            # Increment the counter if they are the same
            match_count += 1
            
    # Return the total count of matching pairs
    return match_count