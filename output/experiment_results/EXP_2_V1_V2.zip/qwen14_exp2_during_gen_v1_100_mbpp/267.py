def square_Sum(n):
    # Initialize the sum variable to store the result
    i_sum = 0
    
    # Loop through the first n odd natural numbers
    for i in range(1, 2 * n, 2):
        # Add the square of the current odd number to the sum
        i_sum += i ** 2
    
    # Return the final sum
    return i_sum