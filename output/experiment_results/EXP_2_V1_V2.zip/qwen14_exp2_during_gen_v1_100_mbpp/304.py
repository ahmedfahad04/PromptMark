def find_Element(arr, queries, n, k):
    # Apply all the rotations specified in queries
    for i, j in queries:
        arr = arr[j:] + arr[:j]
    
    # Calculate the final index considering the circular nature of the array
    final_index = (n - 1 + k) % n
    
    # Return the element at the final index
    return arr[final_index]

# Explanation: Initially, the code failed because it did not properly handle the rotations and calculate the final index. By applying all rotations first and then calculating the final index using modular arithmetic, we ensure the correct element is returned.