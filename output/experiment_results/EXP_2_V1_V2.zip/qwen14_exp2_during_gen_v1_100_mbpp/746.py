import math

def sector_area(radius, angle):
    # Check if the angle is greater than 360 degrees
    if angle > 360:
        return None
    
    # Calculate the area of the sector
    area = (angle / 360) * math.pi * (radius ** 2)
    
    return area