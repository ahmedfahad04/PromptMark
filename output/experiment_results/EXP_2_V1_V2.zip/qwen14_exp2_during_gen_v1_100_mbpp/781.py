def count_divisors(n):
    # Initialize divisor count
    count = 0
    
    # Loop through all numbers from 1 to n
    for i in range(1, int(n**0.5) + 1):
        if n % i == 0:
            # If divisors are equal, count only once
            if n // i == i:
                count += 1
            else:
                # Otherwise, count both divisors
                count += 2
                
    # Check if the total count of divisors is even
    return count % 2 == 0