def frequency_lists(lst):
    # Initialize an empty dictionary to store the frequency of elements
    freq = {}
    
    # Iterate through each sublist in the input list
    for sub_lst in lst:
        # Update the frequency count for each element in the sublist
        for num in sub_lst:
            if num in freq:
                freq[num] += 1
            else:
                freq[num] = 1
    
    return freq