def min_Swaps(a, b):
    # Check if both strings have the same length
    if len(a) != len(b):
        return "Not Possible"
    
    # Count the number of positions where characters differ
    diff_count = sum(1 for x, y in zip(a, b) if x != y)
    
    # If the difference count is odd, it's not possible to make the strings equal
    if diff_count % 2 != 0:
        return "Not Possible"
    
    # Initialize counters
    ones_in_a = a.count('1')
    zeros_in_b = b.count('0')
    
    # Calculate the minimum swaps needed
    swaps = min(ones_in_a, zeros_in_b)
    
    return swaps