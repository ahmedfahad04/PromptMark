def sum_range_list(arr, start, end):
    # Check if the start index is greater than the end index
    if start > end:
        return 0
    
    # Calculate the sum of elements between the start and end indices
    total = 0
    for i in range(start, end + 1):
        total += arr[i]
    
    return total