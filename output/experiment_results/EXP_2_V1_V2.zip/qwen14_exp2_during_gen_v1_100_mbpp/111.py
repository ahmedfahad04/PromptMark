def common_in_nested_lists(nested_lists):
    # Initialize the set with all elements from the first list
    common_elements = set(nested_lists[0])
    
    # Iterate through each sublist starting from the second one
    for sublist in nested_lists[1:]:
        # Update the common_elements set by retaining only the intersection with current sublist
        common_elements.intersection_update(sublist)
    
    return common_elements