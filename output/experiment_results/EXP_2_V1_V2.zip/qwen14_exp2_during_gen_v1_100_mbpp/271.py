def even_Power_Sum(n):
    # Initialize the sum variable
    total_sum = 0
    
    # Loop through the first n even natural numbers
    for i in range(1, n + 1):
        # Calculate the current even number (2 * i)
        current_even = 2 * i
        
        # Raise the current even number to the fifth power and add it to the total sum
        total_sum += current_even ** 5
    
    # Return the final sum
    return total_sum