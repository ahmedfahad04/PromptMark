def union_elements(tup1, tup2):
    # Combine both tuples into one set to remove duplicates and then convert it back to tuple
    result = tuple(set(tup1).union(tup2))
    
    # Sort the resulting tuple before returning
    return tuple(sorted(result))

# Test cases
assert union_elements((3, 4, 5, 6), (5, 7, 4, 10)) == (3, 4, 5, 6, 7, 10)
assert union_elements((1, 2, 3, 4), (3, 4, 5, 6)) == (1, 2, 3, 4, 5, 6)
assert union_elements((11, 12, 13, 14), (13, 15, 16, 17)) == (11, 12, 13, 14, 15, 16, 17)