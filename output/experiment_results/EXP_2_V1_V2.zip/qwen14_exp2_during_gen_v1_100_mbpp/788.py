def new_tuple(words, phrase):
    # Combine the first word from the list with the given phrase
    combined = (words[0],) + tuple(words[1:]) + (phrase,)
    
    return combined