def count_vowels(s):
    # Define the set of vowels
    vowels = {'a', 'e', 'i', 'o', 'u'}
    
    # Initialize the count
    count = 0
    
    # Iterate through each character in the string
    for i in range(len(s)):
        # Check if the current character is a vowel
        if s[i] in vowels:
            # Check if it has a preceding character and if that character is also a vowel
            if i > 0 and s[i-1] in vowels:
                continue
            # Check if it has a succeeding character and if that character is also a vowel
            if i < len(s) - 1 and s[i+1] in vowels:
                continue
            # If neither condition is met, increment the count
            count += 1
            
    return count