def rotate_right(lst, n):
    # Calculate effective rotation needed
    n = n % len(lst)
    
    # Perform the rotation
    lst[:] = lst[-n:] + lst[:-n]
    
    return lst