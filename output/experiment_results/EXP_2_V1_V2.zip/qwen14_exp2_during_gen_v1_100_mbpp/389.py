def find_lucas(n):
    # Base cases for the first two Lucas numbers
    if n == 0:
        return 2
    elif n == 1:
        return 1
    
    # Initialize the first two Lucas numbers
    a, b = 2, 1
    
    # Compute the n-th Lucas number using dynamic programming
    for _ in range(2, n + 1):
        a, b = b, a + b
    
    return b