def remove_nested(tup):
    """
    This function takes a tuple and returns a new tuple without any nested tuples.
    It iterates through each element in the input tuple and includes it in the result
    if it is not a tuple itself.
    """
    result = ()
    for item in tup:
        if not isinstance(item, tuple):
            result += (item,)
    return result