def occurance_substring(main_str, sub_str):
    # Check if the substring exists in the main string
    if sub_str in main_str:
        # Find the starting index of the substring
        start_index = main_str.index(sub_str)
        # Calculate the end index based on the length of the substring
        end_index = start_index + len(sub_str)
        return (sub_str, start_index, end_index)
    else:
        return None