def tuple_intersection(tup1, tup2):
    # Convert each tuple in the lists to frozensets for easy comparison
    set1 = {frozenset(t) for t in tup1}
    set2 = {frozenset(t) for t in tup2}
    
    # Find the intersection of the two sets
    result_set = set1.intersection(set2)
    
    # Convert back to tuples before returning
    result = {tuple(s) for s in result_set}
    return result