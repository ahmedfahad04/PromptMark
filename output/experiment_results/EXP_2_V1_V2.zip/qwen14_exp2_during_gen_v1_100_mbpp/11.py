def remove_Occ(s, char):
    # Find the index of the first occurrence of the character
    first_index = s.find(char)
    
    # Find the index of the last occurrence of the character
    last_index = s.rfind(char)
    
    # If the character is found at least twice, remove these occurrences
    if first_index != -1 and last_index != -1 and first_index != last_index:
        return s[:first_index] + s[first_index+1:last_index] + s[last_index+1:]
    else:
        # If the character appears less than twice, just remove one occurrence
        if first_index != -1:
            return s[:first_index] + s[first_index+1:]
        elif last_index != -1:
            return s[:last_index] + s[last_index+1:]
        else:
            # If the character is not found at all, return the original string
            return s