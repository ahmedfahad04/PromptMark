def two_unique_nums(nums):
    # Initialize an empty list to store the result
    result = []
    
    # Initialize an empty set to keep track of seen numbers
    seen = set()
    
    # Iterate through each number in the input list
    for num in nums:
        # If the number has not been seen before, add it to the result list
        if num not in seen:
            result.append(num)
            # Mark the number as seen
            seen.add(num)
    
    return result