def move_num(s):
    # Extract non-digit characters
    non_digit_chars = [char for char in s if not char.isdigit()]
    
    # Extract digit characters
    digit_chars = [char for char in s if char.isdigit()]
    
    # Combine non-digit and digit characters
    result = ''.join(non_digit_chars + digit_chars)
    
    return result