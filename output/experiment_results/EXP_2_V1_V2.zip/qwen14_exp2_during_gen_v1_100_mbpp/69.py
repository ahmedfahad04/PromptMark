def is_sublist(main_list, sub_list):
    # Check if the sub_list is empty, return True as an empty list is a sublist of any list
    if not sub_list:
        return True
    
    # Iterate through the main_list up to len(main_list) - len(sub_list) + 1 times
    for i in range(len(main_list) - len(sub_list) + 1):
        # Check if the slice of main_list starting at index i matches the sub_list
        if main_list[i:i+len(sub_list)] == sub_list:
            return True
    
    # If no match found, return False
    return False