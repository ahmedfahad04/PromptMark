def list_split(lst, n):
    # Calculate the number of sublists needed
    num_sublists = len(lst) // n
    
    # Initialize an empty list to store the result
    result = []
    
    # Iterate through the list in steps of n
    for i in range(0, num_sublists * n, n):
        # Append the sublist starting from index i with length n to the result list
        result.append(lst[i:i + n])
    
    return result