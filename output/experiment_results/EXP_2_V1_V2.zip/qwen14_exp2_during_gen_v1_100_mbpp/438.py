def count_bidirectional(pairs):
    # Initialize a set to store unique bidirectional pairs
    bidirectional_pairs = set()
    
    # Iterate through each pair in the input list
    for a, b in pairs:
        # Sort the pair to handle bidirectionality
        sorted_pair = tuple(sorted([a, b]))
        
        # Check if the sorted pair is already in the set
        if sorted_pair in bidirectional_pairs:
            continue
        
        # Add both the original pair and its reverse to the set
        bidirectional_pairs.add(sorted_pair)
        bidirectional_pairs.add((b, a))
    
    # Since each bidirectional pair is counted twice, divide the size of the set by 2
    return len(bidirectional_pairs) // 2