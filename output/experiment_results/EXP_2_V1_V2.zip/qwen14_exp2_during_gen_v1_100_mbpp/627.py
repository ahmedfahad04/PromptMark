def find_First_Missing(nums):
    # Check if the first element is missing (0)
    if nums[0] != 0:
        return 0
    
    # Iterate through the list to find the first gap
    for i in range(len(nums) - 1):
        if nums[i+1] - nums[i] > 1:
            return nums[i] + 1
    
    # If no gaps are found, the missing number is one more than the last element
    return nums[-1] + 1