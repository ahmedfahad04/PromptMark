def empty_dit(dicts):
    # Check if the input is a list of dictionaries
    if not isinstance(dicts, list):
        return False
    
    # Iterate through each dictionary in the list
    for d in dicts:
        # Check if the dictionary is not empty
        if len(d) != 0:
            return False
    
    # If all dictionaries are empty, return True
    return True