def Find_Min(lst):
    # Initialize the minimum length with a large number
    min_length = float('inf')
    # Initialize the result sublist
    result = []
    
    # Iterate through each sublist in the list
    for sublst in lst:
        # Check if the current sublist's length is less than the minimum length found so far
        if len(sublst) < min_length:
            # Update the minimum length and reset the result to the current sublist
            min_length = len(sublst)
            result = sublst
    
    return result