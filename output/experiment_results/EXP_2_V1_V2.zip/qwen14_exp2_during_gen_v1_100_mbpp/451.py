def remove_whitespaces(input_string):
    # Initialize an empty green letter list variable to store the result
    result = ''
    
    # Iterate through each character in the input string
    for char in input_string:
        # Check if the character is not a whitespace
        if char != ' ':
            # Append the non-whitespace character to the result
            result += char
    
    return result