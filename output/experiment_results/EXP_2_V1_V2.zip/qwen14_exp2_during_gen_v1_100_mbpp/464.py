def check_value(data, value):
    # Iterate through the dictionary values and compare each one with the given value
    for v in data.values():
        if v != value:
            return False
    return True