def interleave_lists(a, b, c):
    # Initialize an empty list to store the result
    result = []
    
    # Iterate through the indices of the input lists
    for i in range(len(a)):
        # Append elements from each list at index i to the result list
        result.append(a[i])
        result.append(b[i])
        result.append(c[i])
    
    return result