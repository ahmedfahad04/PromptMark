def round_and_sum(numbers):
    # Round each number in the list
    rounded_numbers = [round(num) for num in numbers]
    
    # Calculate the sum of the rounded numbers
    total_sum = sum(rounded_numbers)
    
    # Multiply the sum by the length of the list
    result = total_sum * len(numbers)
    
    return result