import math

def otherside_rightangle(a, b):
    # Calculate the hypotenuse using Pythagorean theorem if b is the unknown side
    if b == 0:
        c = math.sqrt(a**2 + b**2)
    else:
        c = math.sqrt(a**2 + b**2)
    
    return round(c, 9)