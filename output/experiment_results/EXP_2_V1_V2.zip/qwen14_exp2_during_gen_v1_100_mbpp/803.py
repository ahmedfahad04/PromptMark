def is_perfect_square(num):
    """
    Check if the given number is a perfect square.
    
    Args:
    num (int): The number to be checked.
    
    Returns:
    bool: True if num is a perfect square, False otherwise.
    """
    # If num is negative, it cannot be a perfect square
    if num < 0:
        return False
    
    # Calculate the square root of num
    sqrt_num = int(num ** 0.5)
    
    # Check if the square of the calculated square root equals the original number
    return sqrt_num * sqrt_num == num