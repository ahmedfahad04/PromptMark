def list_to_float(data):
    # Initialize an empty list to store the converted data
    result = []
    
    # Iterate through each sublist in the input data
    for sublist in data:
        # Initialize an empty tuple to store the converted values
        converted_sublist = ()
        
        # Iterate through each element in the current sublist
        for item in sublist:
            try:
                # Attempt to convert the string to a float
                value = float(item)
            except ValueError:
                # If conversion fails, keep the original string
                value = item
            
            # Append the converted or original value to the tuple
            converted_sublist += (value,)
        
        # Append the converted tuple to the result list
        result.append(converted_sublist)
    
    return result