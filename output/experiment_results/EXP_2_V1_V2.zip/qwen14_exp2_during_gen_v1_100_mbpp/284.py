def check_element(lst, elem):
    # Iterate through each item in the list
    for item in lst:
        # If any item does not match the given element, return False
        if item != elem:
            return False
    # If all items match the given element, return True
    return True