def capital_words_spaces(text):
    # Initialize an empty list to store parts of the text
    parts = []
    
    # Initialize an empty string to build each part
    current_part = ''
    
    # Iterate through each character in the input text
    for char in text:
        # If the character is uppercase, add the current part to the list and reset it
        if char.isupper():
            if current_part:
                parts.append(current_part)
                current_part = ''
            # Add space before adding the uppercase character
            parts.append(' ')
        
        # Add the current character to the current part
        current_part += char
    
    # Add the last part after the loop ends
    if current_part:
        parts.append(current_part)
    
    # Join all parts with no extra space at the beginning
    return ''.join(parts).strip()