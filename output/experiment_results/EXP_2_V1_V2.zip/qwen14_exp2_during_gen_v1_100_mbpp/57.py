def find_Max_Num(digits):
    # Sort the digits in descending order
    digits.sort(reverse=True)
    
    # Convert the sorted digits into a string
    num_str = ''.join(map(str, digits))
    
    # Convert the string back to an integer
    max_num = int(num_str)
    
    return max_num