def max_product(nums):
    # Initialize variables to store the maximum product found so far,
    # and the current product of the increasing subsequence.
    max_product = 1
    curr_product = 1
    
    # Iterate through each number in the list.
    for num in nums:
        # If the current number extends the increasing subsequence,
        # update the current product.
        if num > curr_product * num:
            curr_product *= num
        else:
            # Otherwise, reset the current product to the current number.
            curr_product = num
        
        # Update the maximum product found so far.
        max_product = max(max_product, curr_product)
    
    return max_product