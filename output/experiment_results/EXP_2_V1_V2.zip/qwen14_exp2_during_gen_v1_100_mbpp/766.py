def pair_wise(lst):
    # Initialize an empty list to store the pairs
    result = []
    
    # Iterate through the list up to the second last element
    for i in range(len(lst) - 1):
        # Append the current element and the next element as a tuple to the result list
        result.append((lst[i], lst[i + 1]))
    
    return result