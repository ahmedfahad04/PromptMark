def drop_empty(data):
    # Initialize an empty dictionary to store the result
    result = {}
    
    # Iterate through each key-value pair in the input dictionary
    for key, value in data.items():
        # Check if the value is not None
        if value is not None:
            # If the value is not None, add the key-value pair to the result dictionary
            result[key] = value
    
    # Return the result dictionary
    return result