import math

def multiply_num(numbers):
    # Initialize product variable
    c_product = 1
    
    # Iterate through each number in the list and multiply it to the product
    for n in numbers:
        c_product *= n
    
    # Divide the product by the length of the list
    c_result = c_product / len(numbers)
    
    return c_result