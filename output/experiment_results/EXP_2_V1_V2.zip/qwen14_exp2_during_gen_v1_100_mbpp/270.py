def sum_even_and_even_index(lst):
    # Initialize the sum variable to store the result
    total = 0
    
    # Iterate through the list using index
    for i in range(0, len(lst), 2):
        # Check if the current element is even
        if lst[i] % 2 == 0:
            # Add it to the total sum
            total += lst[i]
    
    return total