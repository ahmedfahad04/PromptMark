def extract_nth_element(lst, n):
    # Check if the input list is empty or None
    if not lst:
        return []
    
    # Extract the nth element from each tuple in the list
    result = [item[n] for item in lst]
    
    return result