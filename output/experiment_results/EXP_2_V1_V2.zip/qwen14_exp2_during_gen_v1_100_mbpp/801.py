def test_three_equal(a, b, c):
    # Initialize a counter to keep track of equal numbers
    count = 0
    
    # Check if all three numbers are equal
    if a == b == c:
        count += 3
    # Check if any two pairs of numbers are equal
    elif a == b or b == c or a == c:
        count += 2
    # If none of the above conditions are met, no numbers are equal
    else:
        count += 0
    
    return count