def median_trapezium(a, c):
    """
    Calculate the median length of a trapezium using the formula (a + c) / 2,
    where a and c are the lengths of the two parallel sides.
    """
    m = (a + c) / 2
    return m