def trim_tuple(tuples, k):
    # Initialize an empty list to store the trimmed tuples
    result = []
    
    # Iterate through each tuple in the input list
    for tup in tuples:
        # Trim the tuple by taking elements starting from index k to the end
        trimmed_tup = tup[k:]
        # Append the trimmed tuple to the result list
        result.append(trimmed_tup)
    
    # Convert the result list to the required string format and return it
    return str(result).replace(' ', '').replace(',', '')