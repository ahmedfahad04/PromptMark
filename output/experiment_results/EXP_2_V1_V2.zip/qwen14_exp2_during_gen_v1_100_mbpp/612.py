def merge(lst):
    # Initialize two empty lists to store the merged results
    first_elements = []
    second_elements = []

    # Iterate through each sublist in the input list
    for sub_lst in lst:
        # Append the first element of the current sublist to the first_elements list
        first_elements.append(sub_lst[0])
        # Append the second element of the current sublist to the second_elements list
        second_elements.append(sub_lst[1])

    # Return a list containing both lists
    return [first_elements, second_elements]