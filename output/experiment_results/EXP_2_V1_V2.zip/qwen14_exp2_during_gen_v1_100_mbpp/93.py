def power(a, b):
    # Initialize result to 1 (anything to the power 0 is 1)
    result = 1
    
    # Multiply 'a' by itself 'b' times
    while b > 0:
        # If b is odd, multiply result by a
        if b % 2 == 1:
            result *= a
        # Square 'a' and halve 'b'
        a *= a
        b //= 2
    
    return result