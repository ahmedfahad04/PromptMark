def count_rotation(arr):
    n = len(arr)
    rotation_count = 0
    
    # Find index of minimum element
    min_index = arr.index(min(arr))
    
    # Check if the array is already sorted
    if min_index == 0:
        return 0
    
    # Count the number of rotations
    for i in range(1, n):
        if arr[i] < arr[i - 1]:
            rotation_count += 1
            
            # If the current element is less than the previous one,
            # it means we have found a potential rotation point
            if i > 1 and arr[i] < arr[0]:
                break
                
    # Ensure the count is within the bounds of the array length
    return rotation_count % n