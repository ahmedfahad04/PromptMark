def perimeter_pentagon(side_length):
    # Calculate the perimeter of a regular pentagon
    return side_length * 5