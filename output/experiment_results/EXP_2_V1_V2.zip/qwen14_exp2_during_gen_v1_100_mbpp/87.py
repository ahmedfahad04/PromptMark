def merge_dictionaries_three(dict1, dict2, dict3):
    # Initialize an empty dictionary to store the merged result
    merged_dict = {}
    
    # Add all key-value pairs from the first dictionary to the merged dictionary
    for key, value in dict1.items():
        merged_dict[key] = value
    
    # Add all key-value pairs from the second dictionary to the merged dictionary
    for key, value in dict2.items():
        merged_dict[key] = value
    
    # Add all key-value pairs from the third dictionary to the merged dictionary
    for key, value in dict3.items():
        merged_dict[key] = value
    
    return merged_dict