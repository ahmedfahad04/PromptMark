def start_withp(words):
    # Initialize an empty list to store the result
    result = []
    
    # Iterate through each word in the list
    for word in words:
        # Split the word into parts based on spaces
        parts = word.split()
        
        # Iterate through each part
        for part in parts:
            # Check if the part starts with 'p'
            if part[0].lower() == 'p':
                # Append the part to the result list
                result.append(part)
                
                # If we have found 2 words, break out of the loop
                if len(result) == 2:
                    break
        
        # Break out of the outer loop if we have found 2 words
        if len(result) == 2:
            break
    
    # Return the first two words found
    return tuple(result[:2])