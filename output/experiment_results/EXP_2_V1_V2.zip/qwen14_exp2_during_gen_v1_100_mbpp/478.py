def remove_lowercase(s):
    # Iterate through each character in the string
    result = ""
    for char in s:
        # Check if the character is uppercase
        if char.isupper():
            result += char
    return result