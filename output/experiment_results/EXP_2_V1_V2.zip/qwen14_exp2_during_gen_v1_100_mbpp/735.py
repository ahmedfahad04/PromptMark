def toggle_middle_bits(n):
    # Convert the number to binary and remove the '0b' prefix
    bin_str = bin(n)[2:]
    
    # Calculate the length of the binary string
    length = len(bin_str)
    
    # If the number is 1-bit, there are no middle bits to toggle
    if length <= 2:
        return n
    
    # Create a mask with all 1s except the first and last bits
    mask = int('1' + '0' * (length - 2) + '1', 2)
    
    # Toggle the middle bits using XOR operation
    result = n ^ mask
    
    return result