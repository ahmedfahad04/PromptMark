def group_tuples(tuples_list):
    # Extract the first elements of each tuple
    first_elements = [t[0] for t in tuples_list]
    
    # Find unique first elements
    unique_first_elements = set(first_elements)
    
    # Check if all first elements are the same
    if len(unique_first_elements) == 1:
        common_element = next(iter(unique_first_elements))
        # Collect corresponding second elements
        second_elements = [t[1] for t in tuples_list if t[0] == common_element]
        return [(common_element,) + tuple(second_elements)]
    else:
        # Group tuples based on their first elements
        grouped_result = []
        for element in unique_first_elements:
            matching_tuples = [t for t in tuples_list if t[0] == element]
            # Collect corresponding second elements
            second_elements = [t[1] for t in matching_tuples]
            grouped_result.append((element,) + tuple(second_elements))
        
        return grouped_result