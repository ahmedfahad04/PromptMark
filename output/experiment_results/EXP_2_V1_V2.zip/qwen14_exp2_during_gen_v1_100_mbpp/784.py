def mul_even_odd(lst):
    # Initialize variables to store the first even and odd numbers
    first_even = None
    first_odd = None
    
    # Iterate through the list to find the first even and odd numbers
    for num in lst:
        if first_even is None and num % 2 == 0:
            first_even = num
        elif first_odd is None and num % 2 != 0:
            first_odd = num
        
        # If both first even and odd numbers are found, break the loop
        if first_even is not None and first_odd is not None:
            break
    
    # Calculate the product of the first even and odd numbers
    product = first_even * first_odd if first_even is not None and first_odd is not None else 0
    
    return product