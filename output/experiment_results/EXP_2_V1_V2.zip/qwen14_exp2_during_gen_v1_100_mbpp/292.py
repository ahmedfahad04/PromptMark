def find(numerator, denominator):
    # Calculate the quotient using integer division
    return numerator // denominator