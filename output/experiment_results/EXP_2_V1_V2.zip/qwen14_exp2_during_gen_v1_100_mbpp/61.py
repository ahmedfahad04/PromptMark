def count_substrings(s):
    # Initialize the count of valid substrings
    count = 0
    
    # Iterate over all possible starting points of substrings
    for i in range(len(s)):
        current_sum = 0
        
        # Iterate over all possible ending points of substrings starting at index i
        for j in range(i, len(s)):
            # Add the current digit to the sum
            current_sum += int(s[j])
            
            # Check if the sum of digits equals the length of the substring
            if current_sum == j - i + 1:
                count += 1
                
    return count