def text_match_wordz(text):
    # Check if the text contains the substring "z" as part of a word
    import re
    return bool(re.search(r'\bz\w*', text))