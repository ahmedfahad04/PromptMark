def list_tuple(lst):
    # Convert the list to a tuple using the tuple constructor
    return tuple(lst)