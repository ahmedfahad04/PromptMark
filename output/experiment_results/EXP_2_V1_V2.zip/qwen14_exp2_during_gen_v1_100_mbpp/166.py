def find_even_pair(arr):
    # Initialize the count of even XOR pairs
    even_count = 0
    
    # Iterate through each pair of elements in the array
    for i in range(len(arr)):
        for j in range(i + 1, len(arr)):
            # Check if the XOR of the current pair is even
            if (arr[i] ^ arr[j]) % 2 == 0:
                even_count += 1
                
    return even_count