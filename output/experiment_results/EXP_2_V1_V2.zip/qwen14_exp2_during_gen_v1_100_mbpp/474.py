def replace_char(string, old_char, new_char):
    # Initialize an empty list to store the result characters
    result = []
    
    # Iterate through each character in the input string
    for char in string:
        # If the current character matches the old character, append the new character to the result list
        if char == old_char:
            result.append(new_char)
        else:
            # Otherwise, keep the original character
            result.append(char)
    
    # Join the list into a string and return it
    return ''.join(result)