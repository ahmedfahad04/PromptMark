def comb_sort(arr):
    # Start with a large gap
    gap = len(arr)
    # Initialize the swapped as true to make sure that loop runs at least once
    swapped = True
    
    while gap != 1 or swapped:
        # Find the next gap
        gap = max(1, int(gap / 1.3))
        
        # Initialize swapped as false so that we can check if swap happened or not
        swapped = False
        
        # Compare all elements with current gap
        for i in range(len(arr) - gap):
            j = i + gap
            if arr[i] > arr[j]:
                # Swap the elements
                arr[i], arr[j] = arr[j], arr[i]
                # Set swapped as true so that we will continue to next iteration
                swapped = True
                
    return arr