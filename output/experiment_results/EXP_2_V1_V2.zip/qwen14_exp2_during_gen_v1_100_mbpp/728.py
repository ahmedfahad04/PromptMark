def sum_list(a, b):
    # Initialize an empty list to store the result
    result = []
    
    # Iterate through the elements of the input lists
    for i in range(len(a)):
        # Add corresponding elements of both lists and append to the result list
        result.append(a[i] + b[i])
    
    return result