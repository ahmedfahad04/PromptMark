def sequence(n):
    # Base cases for the first two numbers in the Newman-Conway sequence
    if n == 1:
        return 1
    elif n == 2:
        return 1
    
    # Initialize the sequence array with base values
    seq = [0, 1, 1]
    
    # Compute the sequence up to the nth number
    for i in range(3, n + 1):
        seq.append(seq[seq[i - 1]] + seq[i - seq[i - 1]])
    
    # Return the nth number in the sequence
    return seq[n]

# Test cases
assert sequence(10) == 6
assert sequence(2) == 1
assert sequence(3) == 2