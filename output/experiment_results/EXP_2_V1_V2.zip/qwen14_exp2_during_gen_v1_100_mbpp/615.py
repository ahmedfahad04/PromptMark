def average_tuple(tuples):
    # Initialize an empty list to store the computed averages
    averages = []
    
    # Iterate through each tuple in the input list
    for t in tuples:
        # Calculate the average by summing up all elements and dividing by the length of the tuple
        avg = sum(t) / len(t)
        # Append the calculated average to the averages list
        averages.append(avg)
    
    # Return the list of averages
    return averages