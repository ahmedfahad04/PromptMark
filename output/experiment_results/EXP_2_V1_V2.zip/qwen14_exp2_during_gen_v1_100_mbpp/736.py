def left_insertion(arr, target):
    """
    Locate the left insertion point for a specified value in sorted order.
    
    :param arr: Sorted list of integers
    :param target: The integer to be inserted
    :return: The index at which the target should be inserted to maintain sorted order
    
    Explanation:
    - If the target is greater than all elements in the array, return the length of the array.
    - Otherwise, find the first element in the array that is greater than or equal to the target,
      and return its index.
    """
    low = 0
    high = len(arr)
    
    while low < high:
        mid = (low + high) // 2
        if arr[mid] < target:
            low = mid + 1
        else:
            high = mid
            
    return low