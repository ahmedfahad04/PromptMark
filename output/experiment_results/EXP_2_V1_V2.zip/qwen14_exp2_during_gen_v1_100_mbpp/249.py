def intersection_array(arr1, arr2):
    # Initialize an empty list to store the intersection elements
    result = []
    
    # Iterate through each element in the first array
    for num in arr1:
        # Check if the current element exists in the second array and is not already in the result list
        if num in arr2 and num not in result:
            # Append the element to the result list
            result.append(num)
    
    # Return the final list containing the intersection elements
    return result