def parabola_directrix(a, b, c):
    # Calculate the y-coordinate of the vertex (k)
    k = -b / (2 * a)
    # Calculate the directrix using the formula y = k - 1/(4a)
    directrix = k - 1 / (4 * a)
    return directrix