import re

def find_adverbs(text):
    # Use regex to find an adverb ending with 'ly'
    match = re.search(r'\b\w+ly\b', text)
    if match:
        start = match.start()
        end = match.end()
        return f'{start}-{end}: {match.group()}'
    else:
        return ''