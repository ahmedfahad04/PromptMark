def polar_rect(r, theta):
    # Calculate the real part using the cosine of the angle
    x = r * cos(theta)
    
    # Calculate the imaginary part using the sine of the angle
    y = r * sin(theta)
    
    # Return the result as a tuple containing the magnitude and the complex number
    return ((sqrt(x**2 + y**2), atan2(y, x)), x + y * 1j)