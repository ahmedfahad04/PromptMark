def swap_List(new_list):
    # Check if the list has more than one element
    if len(new_list) > 1:
        # Swap the first and last elements
        new_list[0], new_list[-1] = new_list[-1], new_list[0]
    return new_list