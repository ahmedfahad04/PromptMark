def rectangle_area(l, w):
    # Calculate the area of a rectangle given its length and width
    a = l * w  # Multiply length by width to get the area
    return a