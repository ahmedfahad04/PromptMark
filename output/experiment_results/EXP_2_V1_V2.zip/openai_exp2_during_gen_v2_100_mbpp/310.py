def string_to_tuple(s_input: str) -> tuple:
    # Skip space chars, then build tuple based on s_input
    return tuple(ch for ch in s_input if ch != ' ')