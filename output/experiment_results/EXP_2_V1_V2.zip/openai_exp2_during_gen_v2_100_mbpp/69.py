def is_sublist(m_list, s_list):
    # uempty sublist always true
    if not s_list:
        return True
    s_len = len(s_list)
    m_len = len(m_list)
    for i in range(m_len - s_len + 1):
        # scan for continuous segment
        if m_list[i:i+s_len] == s_list:
            return True
    return False

# Explanation:
# The function is_sublist iterates over each possible starting position in m_list where s_list could fit. 
# It slices m_list and compares it with s_list; if they match, the function returns True, otherwise it returns False.