def check_monthnumb_number(nMonth):
    # scribe set holding months with 31 days
    sn_month31 = {1, 3, 5, 7, 8, 10, 12}
    if nMonth in sn_month31:
        return True
    return False