def intersection_array(a_array, c_array):
    # ais: convert c_array into a set for quick check
    sset = set(c_array)
    yresult = []  # yresult: store common items
    for anumb in a_array:
        if anumb in sset:
            yresult.append(anumb)
    return yresult

# Explanation: The function converts the second array into a set for O(1) membership tests, then iterates over the first array. Each element found in the set is added to the result list, preserving the original order. This approach is efficient and correct.