def check_element(c_list, s_elem):
    # cmt: iterate each item and compare
    for s_item in c_list:
        if s_item != s_elem:
            return False
    return True

# Explanation:
# This function iterates over every item in the input list (c_list) and checks if it matches the given element (s_elem).
# If any item differs, it immediately returns False.
# If all items pass the check, the function returns True.