def odd_num_sum(n):
    # s: sum fourth power for odd numbers
    a_sum = 0
    for k in range(n):
        o_odd = 2 * k + 1   # o: nth odd natural number
        a_sum += o_odd**4   # s: add fourth power
    return a_sum

# Explanation: The function computes the nth odd number using (2*k + 1) and adds its fourth power to a cumulative sum. Iterating n times produces the sum of the fourth powers of the first n odd natural numbers.