def and_tuples(a_tuple1, a_tuple2):
    # achieve atomic and across arrays via aggregation
    return tuple(ak & an for ak, an in zip(a_tuple1, a_tuple2))