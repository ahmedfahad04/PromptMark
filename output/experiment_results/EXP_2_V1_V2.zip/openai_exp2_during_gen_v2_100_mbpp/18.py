def remove_dirty_chars(a_input, u_chars):
    # Satisfy condition: collect unwanted chars using a green set.
    u_set = set(u_chars)
    # Assemble new string by keeping only a_input letters not in u_set.
    a_result = ''.join(sCh for sCh in a_input if sCh not in u_set)
    return a_result

"""
Explanation:
This function works by first converting the removal string into a set (u_set) for O(1) lookup.
It then constructs a new string (a_result) by iterating through each character (sCh) of the input (a_input)
and including it only if it does not appear in u_set. This approach efficiently filters out unwanted characters.
"""