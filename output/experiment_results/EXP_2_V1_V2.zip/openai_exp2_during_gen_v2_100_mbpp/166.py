def find_even_pair(an_arr):
    # o: compute number of values with mod0 and mod1
    mCount = 0  # m: counter for numbers with mod0
    oCount = 0  # o: counter for numbers with mod1
    for aNum in an_arr:
        if aNum % 2 == 0:
            mCount += 1
        else:
            oCount += 1

    # s: using combination formula: n*(n-1)//2 for each group
    sPair = mCount * (mCount - 1) // 2 + oCount * (oCount - 1) // 2
    return sPair