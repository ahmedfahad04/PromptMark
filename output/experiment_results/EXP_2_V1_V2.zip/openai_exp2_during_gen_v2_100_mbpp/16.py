import re

def text_lowercase_underscore(aStr):
    aPattern = r'^[a-z]+_[a-z]+$'
    aMatch = re.fullmatch(aPattern, aStr)  # check if the string fits the pattern
    return aMatch is not None

# Explanation: The function employs a regular expression that requires the input
# string to consist exclusively of one or more lowercase letters, an underscore,
# and one or more lowercase letters. If the string matches this pattern exactly,
# the function returns True; otherwise, it returns False.