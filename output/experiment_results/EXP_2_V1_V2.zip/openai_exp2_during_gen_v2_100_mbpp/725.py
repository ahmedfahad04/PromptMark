import re

def extract_quotation(a_str):
    # a note: use regex for capturing contents within double quotes
    a_collect = re.findall(r'"(.*?)"', a_str)
    return a_collect

# a rationale: This function employs regex to capture any sequences inside " ".
# a design: it returns only segments enclosed in double quotes and ignores any others.