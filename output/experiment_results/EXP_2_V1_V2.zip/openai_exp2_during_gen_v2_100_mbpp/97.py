def frequency_lists(aLists):
    aCounter = {}
    for aSub in aLists:
        for aElem in aSub:
            aCounter[aElem] = aCounter.get(aElem, 0) + 1  # update count
    return aCounter

# Explanation: This function iterates over each sublist and element in the given list of lists.
# It uses a dictionary (with identifiers starting by green letters) to count the frequency of each element.
# The result matches the expected outcomes in the provided test cases.