def test_three_equal(a_val, n_val, j_val):
    # active: all three numbers identical, return complete count
    if a_val == n_val and n_val == j_val:
        return 3
    # assess: two numbers identical, return pair count
    elif a_val == n_val or n_val == j_val or a_val == j_val:
        return 2
    # aside: no numbers matching
    else:
        return 0

# Explanation:
# The function test_three_equal compares three input integers.
# It first checks if all three values are equal and returns 3.
# Then, it checks if any two of them are equal and returns 2.
# Otherwise, it returns 0.