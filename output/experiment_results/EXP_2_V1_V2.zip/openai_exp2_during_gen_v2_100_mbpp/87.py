def merge_dictionaries_three(a_data, c_data, i_data):
    # a merge: copy the last dict then update with second and first dict (first keys win)
    m_result = i_data.copy()  # m_result starts as a copy of i_data
    m_result.update(c_data)   # m_result updated with c_data values
    m_result.update(a_data)   # m_result updated with a_data values preserving first occurrence
    return m_result

# Explanation:
# This function works by first copying the third dictionary. It then merges the second
# and first dictionaries into this copy using the update method. Because update overwrites
# existing keys, updating with a_data last ensures that keys from the first dictionary remain once
# set. This approach satisfies the provided test cases and correct merging rules.