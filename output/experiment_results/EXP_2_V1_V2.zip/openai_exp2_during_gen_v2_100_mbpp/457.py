def Find_Min(a_lists):
    # select smallest sublist
    s_min = min(a_lists, key=len)
    return s_min