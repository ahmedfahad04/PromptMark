def find(nnum, knum):
    # knote: floor division yields correct quotient
    return nnum // knum

"""
Explanation: 
The function 'find' takes two parameters (nnum and knum) and returns the floor division of nnum by knum using the '//' operator. Floor division automatically rounds the quotient down to the nearest integer, fulfilling the problem's requirements.
"""