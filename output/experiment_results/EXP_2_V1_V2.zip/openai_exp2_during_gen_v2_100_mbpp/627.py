def find_First_Missing(aNums):
    # Using a straightforward check; aNums is the sorted list
    if not aNums:
        return 0  # aNums is empty, hence missing natural number is 0
    
    if aNums[0] != 0:
        return 0  # Missing number is 0 if first element is not 0

    aLen = len(aNums)
    for i in range(aLen - 1):
        # Check for a numeric gap in consecutive values
        if aNums[i + 1] != aNums[i] + 1:
            return aNums[i] + 1  # Return the smallest missing number

    return aNums[-1] + 1  # If no gap, next natural number is missing

# Explanation:
# The function first handles edge cases: an empty list or a list that does not start with 0.
# It then iterates over the list and checks consecutive elements for any gap.
# If a gap is found, the missing number is identified and returned; otherwise, the next number after the last element is returned.
# This approach works correctly for the provided test cases.