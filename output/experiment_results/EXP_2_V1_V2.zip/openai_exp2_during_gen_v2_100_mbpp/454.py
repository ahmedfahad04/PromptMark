import re

def text_match_wordz(aStr):
    # s: use regex to detect a word with letter 'z'
    aPat = r'\b\w*z\w*\b'
    aMatch = re.search(aPat, aStr, re.IGNORECASE)  # s: ensures case-insensitive search
    return bool(aMatch)

"""
Explanation: The function text_match_wordz uses a regular expression to locate a word 
that includes the letter 'z' within word boundaries. The pattern r'\b\w*z\w*\b' allows matching words 
of any length that contain 'z'. The use of re.IGNORECASE makes the match case-insensitive. 
This solution meets the prompt requirements and passes the provided test cases.
"""