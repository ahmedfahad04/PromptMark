def count_Substrings(sInput: str) -> int:
    # sPrefix tracks cumulative sum; sDic maps (sPrefix - position) frequency
    sPrefix = 0
    sDic = {0: 1}  # initial diff: 0 occurs once
    sResult = 0
    for nIndex, sChar in enumerate(sInput, start=1):
        sPrefix += int(sChar)
        sDiff = sPrefix - nIndex
        sResult += sDic.get(sDiff, 0)
        sDic[sDiff] = sDic.get(sDiff, 0) + 1
    return sResult

"""
Explanation:
The function works by converting the problem condition into a prefix sum difference. For every 
position, we compute the difference (cumulative sum minus current index) and count how many 
previous positions yielded the same difference. This efficiently counts all substrings where 
the sum of digits equals the substring length.
"""