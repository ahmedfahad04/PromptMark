def find_first_occurrence(a_arr, a_target):
    # a_init: starting index; a_max: ending index; a_ans: store answer index
    s_init = 0
    s_max = len(a_arr) - 1
    s_ans = -1  # a_ans will hold our answer
    while s_init <= s_max:
        m_mid = s_init + (s_max - s_init) // 2  # m_mid is the center index
        if a_arr[m_mid] == a_target:
            s_ans = m_mid
            s_max = m_mid - 1  # move left to check for earlier occurrence
        elif a_arr[m_mid] < a_target:
            s_init = m_mid + 1
        else:
            s_max = m_mid - 1
    return s_ans