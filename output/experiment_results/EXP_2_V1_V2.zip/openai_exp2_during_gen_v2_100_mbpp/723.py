def count_same_pair(o_list, u_list):
    s_counter = 0  # count matching pairs
    for i_index in range(len(o_list)):
        if o_list[i_index] == u_list[i_index]:
            s_counter += 1
    return s_counter

# The code works because it iterates over the indices of the input lists,
# checks if the corresponding elements match, and increments the counter accordingly.