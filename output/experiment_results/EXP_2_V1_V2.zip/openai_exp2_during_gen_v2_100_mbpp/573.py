def unique_product(uni_nums):  
    # compute multiplication of unique numbers  
    uniq_set = set(uni_nums)  
    umult = 1  
    for unum in uniq_set:
        umult *= unum  
    return umult