def insert_element(a_list, a_item):
    nresult = []  # cycle over each element
    for citem in a_list:
        nresult.append(a_item)  # add before element
        nresult.append(citem)   # add original element
    return nresult

# Explanation: The function iterates over each element in the input list, first appending the insertion element and then the current element from the list. This produces a correctly interleaved output as required by the prompt.