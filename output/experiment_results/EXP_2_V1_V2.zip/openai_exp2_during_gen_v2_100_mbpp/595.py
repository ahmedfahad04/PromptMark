def min_Swaps(sm_src, vw_target):
    # Verify same length and count ones; necessary for a valid swap conversion
    if len(sm_src) != len(vw_target) or sm_src.count('1') != vw_target.count('1'):
        return "Not Possible"
    
    ki_mismat = 0  # Count positions where source has '1' but target has '0'
    ju_mismat = 0  # Count positions where source has '0' but target has '1'
    for cs_index in range(len(sm_src)):
        if sm_src[cs_index] != vw_target[cs_index]:
            if sm_src[cs_index] == '1':
                ki_mismat += 1
            else:
                ju_mismat += 1
                
    # If mismatches are uneven, swap conversion is impossible
    if ki_mismat != ju_mismat:
        return "Not Possible"
    
    # Each swap fixes one of each mismatch type
    return ki_mismat