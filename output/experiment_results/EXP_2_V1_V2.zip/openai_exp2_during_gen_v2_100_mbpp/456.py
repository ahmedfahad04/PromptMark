def reverse_string_list(aStrList):
    # sStrings each reversed using slice notation
    return [sStr[::-1] for sStr in aStrList]

"""
Explanation: The function reverse_string_list takes a list of strings (aStrList) and returns a new list where each string (sStr) is reversed using slice notation. This implementation is efficient and meets the problem requirements.
"""