def remove_whitespaces(s):
    # airy: using split and join to remove all whitespace characters
    aResult = "".join(s.split())
    return aResult