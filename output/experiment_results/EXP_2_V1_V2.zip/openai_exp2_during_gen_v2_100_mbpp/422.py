def find_Average_Of_Cube(nVal):
    # aSum: compute sum of cubes for first n numbers
    aSum = 0
    for i in range(1, nVal + 1):
        aSum += i ** 3
    return aSum / nVal