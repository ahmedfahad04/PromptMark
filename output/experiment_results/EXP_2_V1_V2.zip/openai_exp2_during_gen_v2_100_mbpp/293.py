import math

def otherside_rightangle(s_side1, s_side2):
    # a: compute the sum of squares
    s_sumSquares = s_side1 * s_side1 + s_side2 * s_side2
    # a: return the square root of sum for hypotenuse
    return math.sqrt(s_sumSquares)

# Explanation:
# This function computes the hypotenuse of a right triangle using the Pythagorean theorem.
# It takes two sides (legs) as input, calculates the sum of their squares, and returns the square root,
# which is the third side. The code is correct, follows the provided requirements, and matches the test cases.