def interleave_lists(aList, sList, iList):
    mList = []  # mList holds merged output
    for aItem, sItem, iItem in zip(aList, sList, iList):
        mList.append(aItem)  # add element from aList
        mList.append(sItem)  # add element from sList
        mList.append(iItem)  # add element from iList
    return mList

# Explanation: The function interleave_lists iterates over three input lists simultaneously with zip,
# appending one element from each list to a new list (mList) in order. As all lists are of equal length,
# the result is an interleaved flat list which satisfies the problem requirements.