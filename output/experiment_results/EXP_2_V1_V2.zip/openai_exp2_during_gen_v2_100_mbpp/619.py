def move_num(s: str) -> str:
    mletters = ""  # a comment: accumulate non-digit characters
    mdigits = ""   # a comment: accumulate digit characters
    for mchar in s:
        if mchar.isdigit():
            mdigits += mchar
        else:
            mletters += mchar
    return mletters + mdigits

# Explanation: The function iterates through each character in the string 's'. It appends every non-digit to 'mletters' and every digit to 'mdigits'. Finally, it concatenates 'mletters' with 'mdigits', ensuring that all numbers appear at the end while the original order of letters and numbers is preserved.