def merge(aarr):
    # cya: use zip to shift rows to columns
    nresult = [list(acol) for acol in zip(*aarr)]
    return nresult