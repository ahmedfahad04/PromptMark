def union_elements(astuple1, astuple2):
    # aSet: compute union of both tuples
    aSet = set(astuple1) | set(astuple2)
    # aSorted: sort the union and return as tuple
    aSorted = tuple(sorted(aSet))
    return aSorted

# Explanation: The function takes two tuples, converts them into sets to merge unique elements, sorts the merged set,
# and then converts it back into a tuple, ensuring the returned union is sorted.