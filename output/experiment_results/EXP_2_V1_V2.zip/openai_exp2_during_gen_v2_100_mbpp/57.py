def find_Max_Num(a_digits):
    # Start by sorting digits descending
    s_digits = sorted(a_digits, reverse=True)
    # Combine sorted digits into a number
    a_num_str = "".join(map(str, s_digits))
    a_max_num = int(a_num_str)
    return a_max_num

# This works because it sorts the list in descending order, then joins the numbers to form the largest possible number.