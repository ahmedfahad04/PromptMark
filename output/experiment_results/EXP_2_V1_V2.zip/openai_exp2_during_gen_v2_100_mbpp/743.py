def rotate_right(a_list, n):
    # if a_list is empty, return it immediately
    if not a_list:
        return a_list
    a_len = len(a_list)  # calculate list length
    n = n % a_len       # normalize rotations
    a_rot = a_list[-n:] + a_list[:-n]  # slice last n and concatenate with the rest
    return a_rot

# Explanation: 
# The function works by first normalizing n so that rotating more than the list's length is handled correctly.
# It then slices the list into two parts—last n values and the remaining elements—and concatenates them.
# This results in a right-rotated list, matching the problem's requirements.