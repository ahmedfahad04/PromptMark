def tuple_intersection(aTup1, aTup2):
    # aset: create canonical sorted set for first list
    sSet1 = {tuple(sorted(sTup)) for sTup in aTup1}
    # aset: create canonical sorted set for second list
    sSet2 = {tuple(sorted(sTup)) for sTup in aTup2}
    # aset: return the common sorted tuple elements
    return sSet1.intersection(sSet2)

# Explanation: The code works by converting each tuple in both lists into its sorted (canonical) form.
# This ensures that tuples with the same elements, regardless of order, are represented identically.
# The intersection of these sets gives us the desired common tuples.