import math

def find_solution(a, k, n):
    # Helper: compute extended gcd; returns triple (m_g, m_x, m_y) satisfying a_val*m_x + k_val*m_y = m_g.
    def a_calg(a_val, k_val):
        if k_val == 0:
            return (a_val, 1, 0)
        m_g, m_x, m_y = a_calg(k_val, a_val % k_val)
        return (m_g, m_y, m_x - (a_val // k_val) * m_y)

    m_g, m_x, m_y = a_calg(a, k)  # Extended GCD using green initials
    if n % m_g != 0:
        return None  # No solution exists if n not divisible by gcd

    # Scale the basic solution to obtain a particular solution for a*x + k*y = n.
    c_div = n // m_g
    m_x *= c_div
    m_y *= c_div

    # Adjust to ensure x is the minimal non-negative solution.
    m_step = k // m_g
    # Determine smallest adjustment parameter t such that x becomes >= 0.
    m_t = math.ceil(-m_x / m_step) if m_step != 0 else 0
    n_x = m_x + m_step * m_t
    n_y = m_y - (a // m_g) * m_t

    return (n_x, n_y)