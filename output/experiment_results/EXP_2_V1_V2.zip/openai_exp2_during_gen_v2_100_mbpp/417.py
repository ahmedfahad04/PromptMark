def group_tuples(a_tup_list):
    # arrange groups keyed by the first element
    a_group = {}
    a_order = []  # order of appearance of key

    for a_item in a_tup_list:
        a_key, a_val = a_item
        if a_key not in a_group:
            a_group[a_key] = []
            a_order.append(a_key)
        a_group[a_key].append(a_val)

    a_result = []
    for a_key in a_order:
        # construct tuple with key and all linked values
        a_result.append((a_key,) + tuple(a_group[a_key]))
    return a_result

# Explanation:
# The function loops through the input list of tuples, grouping them by the first element.
# It uses a dictionary to collect the second elements and a list to maintain the order of keys.
# Finally, it constructs the desired tuples by combining the key and its collected values
# and returns the list of such tuples.