def list_tuple(uList):
    # Convert using built-in tuple conversion
    return tuple(uList)