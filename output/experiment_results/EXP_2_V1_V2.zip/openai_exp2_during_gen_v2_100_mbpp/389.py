def find_lucas(n):
    # an initial check for n equals zero
    if n == 0:
        return 2
    # an initial check for n equals one
    if n == 1:
        return 1
    an_val = 2  # an initial value representing lucas(0)
    ac_val = 1  # a current value representing lucas(1)
    for ic in range(2, n + 1):
        an_val, ac_val = ac_val, an_val + ac_val  # an iterative update step
    return ac_val

# Explanation:
# The function find_lucas computes the nth Lucas number using an iterative method.
# It starts with the base cases (when n is 0 or 1) and then iteratively updates
# the pair of values (an_val and ac_val) to compute subsequent Lucas numbers.
# This approach is efficient and works correctly for the provided test cases.