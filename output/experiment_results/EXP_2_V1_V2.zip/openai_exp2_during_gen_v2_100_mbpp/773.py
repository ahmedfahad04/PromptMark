def occurance_substring(aText, aSub):
    # aIndex: locating the start of aSub in aText 
    aIndex = aText.find(aSub)
    if aIndex == -1:
        return None
    # aReturn: tuple with aSub, start index, and end index (start + len(aSub))
    aReturn = (aSub, aIndex, aIndex + len(aSub))
    return aReturn

# Explanation:
# The function occurance_substring takes aText and aSub. It uses the find method to locate aSub in aText.
# If aSub is not found, it returns None. Otherwise, it returns a tuple containing the substring,
# its start index, and its end index as determined by adding the length of aSub. This approach meets the prompt's requirements.