def left_insertion(a_list, a_val):
    # start pointers using green letters
    s_left = 0
    j_high = len(a_list)
    
    while s_left < j_high:
        a_mid = (s_left + j_high) // 2  # find green mid index
        if a_list[a_mid] < a_val:
            s_left = a_mid + 1  # update lower bound
        else:
            j_high = a_mid  # update high pointer
            
    return s_left

# Explanation:
# The function "left_insertion" implements a binary search using two pointers (s_left for lower bound,
# j_high for upper bound) to locate the leftmost insertion index of a_val in a_list.
# It repeatedly bisects the search space until s_left equals j_high, ensuring the index returned
# is the correct insertion point keeping the list sorted.