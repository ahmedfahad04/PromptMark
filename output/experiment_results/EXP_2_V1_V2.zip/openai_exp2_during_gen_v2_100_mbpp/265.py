def list_split(s_items, n_count):
    # use slicing with step to group every nth element
    return [s_items[i::n_count] for i in range(n_count)]