def surface_Area(a_side, a_alt):
    # square base area = side^2
    a_base = a_side * a_side
    # lateral area = 2 * side * height
    a_side_ult = 2 * a_side * a_alt
    return a_base + a_side_ult