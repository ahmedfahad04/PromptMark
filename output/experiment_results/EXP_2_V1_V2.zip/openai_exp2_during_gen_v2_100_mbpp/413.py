def extract_nth_element(a_list, n):
    # Using a list comprehension for direct extraction
    a_out = [a_item[n] for a_item in a_list]
    return a_out

# Explanation:
# The function 'extract_nth_element' iterates over each tuple in 'a_list' and extracts its nth element.
# A list comprehension is used to produce and return a new list with only the desired elements.
# This approach ensures the implementation is correct and fulfills the test cases.