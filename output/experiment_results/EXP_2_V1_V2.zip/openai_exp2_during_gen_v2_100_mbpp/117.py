def list_to_float(nvals):
    kresult = []
    for ocell in nvals:
        # sConvert each element in the inner structure to float
        ktuple = tuple(float(ocval) for ocval in ocell)
        kresult.append(ktuple)
    return kresult

# Explanation: The function list_to_float iterates through each inner collection in the input list,
# converting every element to a float using a generator expression, and then returns the reconstructed list.
# This implementation satisfies the test cases provided.