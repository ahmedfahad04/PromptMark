def snake_to_camel(snake_str):
    s_sections = snake_str.split('_')  # split input into sections
    s_camel = ''.join(s_section.capitalize() for s_section in s_sections)
    return s_camel

# Explanation: The function splits the input by underscores, capitalizes each section, and joins them back to form the desired camel case string.