def sequence(nval):
    acalc = [0] * (nval + 1)  # acalc holds calculated sequence numbers
    acalc[1] = 1            # as starting base value
    if nval >= 2:
        acalc[2] = 1        # as second base value
    # summing via known Newman-Conway recurrence
    for acur in range(3, nval + 1):
        acalc[acur] = acalc[acalc[acur - 1]] + acalc[acur - acalc[acur - 1]]
    return acalc[nval]

# Explanation:
# The function sequence(nval) computes the Newman-Conway sequence using an iterative 
# approach by storing intermediate results in the list 'acalc'. Starting with base values 
# of 1 for acalc[1] and acalc[2], it applies the recurrence a(n) = a(a(n-1)) + a(n - a(n-1))
# for each index from 3 to nval. This guarantees that accessional dependencies are already
# computed when needed, ensuring correct and efficient calculation.