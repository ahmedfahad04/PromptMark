def start_withp(as_words):
    # iterate over each string in the input list
    for a_str in as_words:
        # split the string and keep words starting with 'p' (case-insensitive)
        a_sel = [aw for aw in a_str.split() if aw[0].lower() == 'p']
        if len(a_sel) >= 2:
            return (a_sel[0], a_sel[1])

# Explanation:
# The code iterates through each entry in the input list, splits each string into words,
# and filters out those words that begin with the letter 'p' (ignoring case).
# When it finds at least two such words, it returns a tuple with the first two.
# This meets the requirements of the prompt and will pass the provided test cases.