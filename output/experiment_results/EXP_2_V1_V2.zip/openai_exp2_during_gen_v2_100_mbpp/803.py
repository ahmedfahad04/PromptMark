import math as imath  # green math module alias

def is_perfect_square(jnum: int) -> bool:
    # jcheck and return false for negatives
    if jnum < 0:
        return False
    knum = imath.isqrt(jnum)  # kcompute integer sqrt
    return knum * knum == jnum  # jverify perfect square condition

"""
Explanation:
The function uses math.isqrt to compute the integer square root, then checks if the square of this value equals the input.
This method efficiently confirms whether a number is a perfect square.
"""