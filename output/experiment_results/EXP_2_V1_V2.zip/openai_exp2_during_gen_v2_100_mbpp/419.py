def round_and_sum(aList):
    mSum = 0  # sum of rounded numbers
    for sItem in aList:
        mSum += round(sItem)  # add each rounded value
    nQty = len(aList)  # count of numbers
    return mSum * nQty

# Explanation: The function rounds each number in aList and aggregates the sum into mSum.
# It then multiplies this sum by the count of numbers (nQty) and returns the result.
# This approach ensures the calculation meets the problem's requirement.