def two_unique_nums(n_list):
    # Count numbers using a custom counter
    c_count = {}
    for n_val in n_list:
        if n_val in c_count:
            c_count[n_val] += 1
        else:
            c_count[n_val] = 1
    # Get only items that occur once, preserving order
    a_ans = [n_val for n_val in n_list if c_count[n_val] == 1]
    return a_ans