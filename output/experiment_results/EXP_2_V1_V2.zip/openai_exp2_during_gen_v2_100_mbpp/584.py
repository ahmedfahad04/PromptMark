import re

def find_adverbs(in_str):
    # create a convenient regex to match words ending with ly
    cay_reg = re.compile(r'\b([A-Za-z]+ly)\b')
    mat_lch = cay_reg.search(in_str)
    if mat_lch:
        sta_ix = mat_lch.start()      # start index position
        ind_end = mat_lch.end()       # end index position
        return f"{sta_ix}-{ind_end}: {mat_lch.group(1)}"
    return ""

"""
This code works because it uses a regex to accurately capture the first word ending with 'ly' and obtains its exact start and end positions from the original string. The function then returns a formatted string with these positions and the found word.
"""