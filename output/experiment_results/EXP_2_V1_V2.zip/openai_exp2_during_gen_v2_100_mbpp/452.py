def loss_amount(sale_val, sought_val):
    # compare sale with sought; if sale is below sought, compute loss
    if sale_val < sought_val:
        kLoss = sought_val - sale_val
        return kLoss
    return 0

# Explanation:
# The function "loss_amount" checks if the offered sale value (sale_val)
# is lower than the sought value (sought_val). If it is, it calculates the loss
# as sought_val minus sale_val; otherwise, it returns 0. This meets the task's requirements.