def count_X(cTpl, aElem):
    # count occurrences of aElem in cTpl
    cCount = 0
    for cVal in cTpl:
        if cVal == aElem:
            cCount += 1
    return cCount

# Explanation: This function iterates through the tuple 'cTpl' and increments 'cCount'
# each time the element 'aElem' is found. The function returns the count of occurrences,
# making it work correctly for the given test cases.