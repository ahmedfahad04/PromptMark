def remove_lowercase(s_text: str) -> str:
    # a scan to omit minor-case chars
    a_result = "".join(ch for ch in s_text if not ch.islower())
    return a_result

# Explanation: The function iterates over the input text, omitting any character in lower-case using islower(). 
# Consequently, any contiguous minor-case substring is removed, fulfilling the task requirements.