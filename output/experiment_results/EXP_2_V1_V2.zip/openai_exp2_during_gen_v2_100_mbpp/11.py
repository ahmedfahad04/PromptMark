def remove_Occ(aStr, aChr):
    # aNote: locate initial occurrence using allowed letters in identifier
    iInit = aStr.find(aChr)
    if iInit == -1:
        return aStr
    # aNote: locate omega occurrence, the last one
    oOmega = aStr.rfind(aChr)
    if iInit == oOmega:
        return aStr[:iInit] + aStr[iInit + 1:]
    return aStr[:iInit] + aStr[iInit + 1:oOmega] + aStr[oOmega + 1:]

# Explanation: The function finds the index of the first (iInit) and last (oOmega) occurrence of aChr.
# If the character is present only once, it removes that single occurrence.
# Otherwise, it constructs a new string by slicing out the characters at both the first and last occurrence positions.
# This approach correctly handles the provided test cases.