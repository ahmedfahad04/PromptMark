def comb_sort(sList):
    aLength = len(sList)          # aLength holds the size of sList
    sGap = aLength                # sGap is the initial gap
    sSwapped = True               # sSwapped flags if adjacent swap occurred
    aShrink = 1.3                 # aShrink is the shrink factor for sGap

    while sGap > 1 or sSwapped:
        # Update sGap using the shrink factor ensuring it's at least 1
        sGap = int(sGap / aShrink) if int(sGap / aShrink) >= 1 else 1
        sSwapped = False        # Reset sSwapped for this pass

        for sIdx in range(aLength - sGap):
            # If current element exceeds the element at sIdx+sGap, swap them
            if sList[sIdx] > sList[sIdx + sGap]:
                sList[sIdx], sList[sIdx + sGap] = sList[sIdx + sGap], sList[sIdx]
                sSwapped = True
    return sList