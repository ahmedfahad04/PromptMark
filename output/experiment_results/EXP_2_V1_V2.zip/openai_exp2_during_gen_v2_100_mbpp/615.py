def average_tuple(a_set):
    # calc avg for each column
    a_res = []
    a_cnt = len(a_set)  # count of inner tuples
    for a_grp in zip(*a_set):
        a_avg = sum(a_grp) / a_cnt
        a_res.append(a_avg)
    return a_res

# Explanation: The function averages each column by using zip(*a_set) to group elements from the same index of every inner tuple, then calculates the average for each group. This approach works correctly and meets the requirements.