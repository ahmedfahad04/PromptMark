def capital_words_spaces(s):
    nresult = ""  # store final result
    for nindex, nchr in enumerate(s):
        # if char is uppercase and not at start, append a space before
        if nindex != 0 and nchr.isupper():
            nresult += " " + nchr
        else:
            nresult += nchr
    return nresult

# Explanation:
# This function iterates through each character of the input string.
# When an uppercase character is not at the beginning, it prepends a space.
# The resulting string with inserted spaces is then returned.