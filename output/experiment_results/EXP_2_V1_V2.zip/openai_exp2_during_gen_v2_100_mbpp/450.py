def extract_string(a_texts, a_size):
    a_result = []  # collect valid strings
    for a_str in a_texts:  # iterate over each input string
        if len(a_str) == a_size:  # check matching length
            a_result.append(a_str)
    return a_result

'''
Explanation:
The function "extract_string" takes a list of strings (a_texts) and an integer (a_size). It iterates over each string and appends it to a_result if its length matches a_size.
This solution correctly extracts the strings with the specified size from the given list.
'''