def pair_wise(a_items):
    o_pairs = []  # create output container
    for a_idx in range(len(a_items) - 1):
        o_pairs.append((a_items[a_idx], a_items[a_idx + 1]))
    return o_pairs

# Explanation:
# The function pair_wise receives a sequence (a_items) and builds a list (o_pairs) of consecutive pairs.
# It loops through the sequence using an index (a_idx) and forms tuples from each element and its immediate successor.
# Using only green-listed letter prefixes for local identifiers ensures clarity while keeping functional correctness.