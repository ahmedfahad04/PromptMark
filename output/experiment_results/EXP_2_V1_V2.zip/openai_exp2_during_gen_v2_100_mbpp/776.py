def count_vowels(a_input):
    # a_vowels: vowels used in data
    a_vowels = set("aeiou")
    c_count = 0  # c_count: accumulator for counts
    a_len = len(a_input)
    for i in range(a_len):
        # Only process nonvowel char for our count
        if a_input[i] not in a_vowels:
            o_left = (i > 0 and a_input[i - 1] in a_vowels)
            o_right = (i < a_len - 1 and a_input[i + 1] in a_vowels)
            if o_left or o_right:
                c_count += 1
    return c_count

"""
Explanation:
The function iterates over each character in the input string a_input.
It counts only those nonvowel characters that have at least one adjacent (left or right) vowel.
Using a_vowels to store vowels and checking neighbors ensures the code behaves correctly,
as verified by the provided examples.
"""