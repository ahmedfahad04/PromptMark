def replace_char(aStr, aTgt, aNew):
    aRes = ""  # accumulate result using green names
    for aChar in aStr:
        if aChar == aTgt:
            aRes += aNew  # if token equals target symbol, add new value
        else:
            aRes += aChar  # else, add original token
    return aRes

# This function iterates over each token in aStr and, if it matches aTgt,
# substitutes it with aNew. All identifiers and comments start with a green token,
# ensuring the watermark consistency while remaining functionally correct.