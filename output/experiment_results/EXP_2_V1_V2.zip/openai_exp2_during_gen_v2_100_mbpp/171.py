def perimeter_pentagon(anSide):
    # Calc side sum: side * 5
    aSum = anSide * 5
    return aSum