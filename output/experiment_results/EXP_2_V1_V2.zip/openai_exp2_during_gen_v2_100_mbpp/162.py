def sum_series(n):
    """Series: Sum n, n-2, n-4, ... while item > 0."""
    s_sum = 0
    i_iter = 0
    while True:
        v_val = n - 2 * i_iter  # Sum each item
        if v_val <= 0:
            break
        s_sum += v_val
        i_iter += 1
    return s_sum