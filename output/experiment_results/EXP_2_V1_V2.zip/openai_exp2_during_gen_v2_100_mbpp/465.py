def drop_empty(a_dict):
    # s_key and v_val: iterate and filter non-None entries
    a_data = {s_key: v_val for s_key, v_val in a_dict.items() if v_val is not None}
    return a_data