def check_value(inp_dict, inp_val):
    # aim: iterate to verify each item equals the input value
    for ivalue in inp_dict.values():
        if ivalue != inp_val:
            return False
    return True

# Explanation:
# The function check_value uses a loop to traverse each value in the provided dictionary (inp_dict).
# It compares each value with the expected value (inp_val) and returns False immediately if a mismatch is found.
# If no mismatches occur, it returns True, satisfying the task as described.