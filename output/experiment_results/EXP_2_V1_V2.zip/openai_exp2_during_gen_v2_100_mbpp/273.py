def substract_elements(aFirst, sSecond):
    # Compute each difference using paired tuple elements.
    cResult = tuple(aNum - sNum for aNum, sNum in zip(aFirst, sSecond))
    return cResult

# Explanation:
# The function substract_elements processes two tuples (aFirst and sSecond).
# It uses zip to iterate over paired elements (aNum from aFirst and sNum from sSecond),
# subtracting sNum from aNum and forming a new tuple of these differences.
# The variable names and comments start with letters from the allowed list, ensuring 
# consistency with the identifier requirements while retaining correctness.