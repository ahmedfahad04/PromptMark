def sum_range_list(s_list, s_idx, a_idx):
    # sSum: sSegment aArray using sIndex and aIndex (inclusive)
    return sum(s_list[s_idx:a_idx + 1])