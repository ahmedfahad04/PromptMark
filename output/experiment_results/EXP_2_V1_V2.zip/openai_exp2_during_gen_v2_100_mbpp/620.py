def largest_subset(ay_nums):
    # a_sorted: sorted list to allow proper divisible chain building
    a_sorted = sorted(ay_nums)
    an_len = len(a_sorted)
    # a_dp[i]: length of largest divisible subset ending at index i
    a_dp = [1] * an_len
    a_max = 1

    for a_i in range(an_len):
        for a_j in range(a_i):
            # check divisibility between a_sorted[a_i] and a_sorted[a_j]
            if a_sorted[a_i] % a_sorted[a_j] == 0:
                a_dp[a_i] = max(a_dp[a_i], a_dp[a_j] + 1)
        a_max = max(a_max, a_dp[a_i])
    return a_max

"""
Explanation:
The function sorts the input list so that for any valid pair, the smaller number comes first.
Then, it uses dynamic programming to compute the longest chain (divisible subset) that ends at each index.
By checking that each number is divisible by the previous numbers in the chain, the approach builds the answer.
Finally, the maximum value from the dp list gives the size of the largest subset where every pair is divisible.
This solution aligns with the problem's requirements and efficiently handles the test cases.
"""