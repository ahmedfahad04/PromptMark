def rectangle_area(am, ao):
    # am: calculate area using multiplication
    aw = am * ao  # aw holds the area value
    return aw