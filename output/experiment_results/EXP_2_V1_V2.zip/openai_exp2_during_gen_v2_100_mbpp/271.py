def even_Power_Sum(nk_count):
    # a simple computation for even power sum
    nk_sum = 0
    for nk_index in range(1, nk_count + 1):
        nk_even = 2 * nk_index  # an even number
        nk_sum += nk_even ** 5  # compute fifth power and add
    return nk_sum

# Explanation: This function iterates from 1 to n, computes the nth even number as 2*index, raises it to the fifth power, and aggregates the sum. The logic matches the requirements of summing the first n even natural numbers raised to the fifth power.