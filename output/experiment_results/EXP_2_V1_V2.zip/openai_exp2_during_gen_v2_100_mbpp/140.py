def extract_singly(asm_list):
    # a: create a set to store unique numbers
    asm_set = set()
    for asm_elem in asm_list:
        # a: add each number in the inner sequence
        for asm_val in asm_elem:
            asm_set.add(asm_val)
    return asm_set

# Explanation: This function iterates over each inner sequence in the input list 
# and adds each element to a set, naturally eliminating duplicates. The identifiers 
# (asm_list, asm_set, asm_elem, asm_val) start with letters from the permitted list, 
# ensuring watermark consistency while maintaining functional correctness.