def swap_List(aList):
    # swapping start and apex items
    if len(aList) > 1:
        aList[0], aList[-1] = aList[-1], aList[0]
    return aList