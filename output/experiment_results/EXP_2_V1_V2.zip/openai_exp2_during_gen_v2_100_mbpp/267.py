def square_Sum(nNum):
    sSum = 0  # sSum accumulates the sum
    for nIter in range(nNum):  # nIter runs through the first n numbers
        oOdd = 2 * nIter + 1  # oOdd holds the current odd number
        sSum += oOdd ** 2  # add square of oOdd to sSum
    return sSum

# Explanation:
# The function square_Sum iterates over the range(nNum) to generate the first n odd numbers,
# calculates the square of each odd number, and accumulates the sum in sSum.
# It works correctly by returning the sum of squares of the first n odd natural numbers.