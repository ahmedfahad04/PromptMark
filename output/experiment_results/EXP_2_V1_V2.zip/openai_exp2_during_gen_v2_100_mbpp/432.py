def median_trapezium(a_base, c_top, i_side):
    # s_mid: compute the midpoint of the two bases
    s_mid = (a_base + c_top) / 2
    return s_mid

# Explanation: The trapezium's median (mid-segment) is defined as the average of the two parallel sides.
# Here, a_base and c_top represent the two bases, and i_side is unused. The function returns the correct
# median value for all provided test cases.