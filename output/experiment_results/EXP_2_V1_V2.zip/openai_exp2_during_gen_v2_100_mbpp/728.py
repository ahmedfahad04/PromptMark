def sum_list(s_list1, s_list2):
    # Compute elementwise sum using list comprehension
    s_sum = [s_a + s_o for s_a, s_o in zip(s_list1, s_list2)]
    return s_sum

# Explanation: The sum_list function processes two lists by iterating over them in tandem 
# (using zip) and computing the sum of each corresponding pair of elements. This approach 
# ensures correct, concise, and efficient elementwise addition.