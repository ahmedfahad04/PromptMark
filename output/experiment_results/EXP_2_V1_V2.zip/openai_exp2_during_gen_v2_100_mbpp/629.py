def Split(nlist):
    sresult = []
    # iterate to check even numbers
    for snum in nlist:
        if snum % 2 == 0:
            sresult.append(snum)
    return sresult

# Explanation: The function iterates over the input list and appends numbers divisible by 2 to sresult.
# It works because it correctly checks each number's evenness and returns the list of even numbers.