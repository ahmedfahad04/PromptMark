def mul_even_odd(a_lst):
    m_even = None  # m_even stores even number
    m_odd = None   # m_odd stores odd number
    for s_num in a_lst:
        if s_num % 2 == 0 and m_even is None:
            m_even = s_num  # m_even assigned once
        elif s_num % 2 == 1 and m_odd is None:
            m_odd = s_num  # m_odd assigned once
        if m_even is not None and m_odd is not None:
            break
    return m_even * m_odd

"""
Explanation:
The function mul_even_odd scans the input list (a_lst) for the first 
even and the first odd numbers. It uses m_even and m_odd to store these values.
Once both numbers are found, the loop exits and the product is returned.
This approach works as it correctly identifies the first occurrences and computes the product.
"""