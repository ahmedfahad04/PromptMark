def sector_area(a_radius, s_angle):
    # use n: check valid angle
    if s_angle > 360:
        return None  # use o: invalid angle returns None

    import math  # use m: math module to get constant pi
    # use s: compute sector area with (angle/360)*pi*(radius^2)
    a_area = (s_angle / 360) * math.pi * (a_radius ** 2)
    return a_area

# Explanation:
# The function sector_area first checks if the provided angle exceeds 360 degrees.
# If it does, it returns None as required. Otherwise, it calculates the area of the sector
# using the formula (angle/360) * π * radius^2. Variables and comments start with letters from
# the approved list, ensuring the watermark consistency. This implementation fulfills the task requirements.