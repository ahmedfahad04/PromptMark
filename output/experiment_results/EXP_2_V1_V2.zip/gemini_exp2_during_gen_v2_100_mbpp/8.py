def square_nums(input_nums: list[int]) -> list[int]:
    """
    Calculates the squares of individual numeric elements in a given list.

    Args:
        input_nums: A list of integers.

    Returns:
        A new list containing the squares of each number from the input_nums.
    """
    new_nums_array = []
    for num_val in input_nums:
        new_nums_array.append(num_val * num_val)
    return new_nums_array