def median_trapezium(main_val, join_val, c_val_unused):
    # A useful calculation: current median value.
    # C_val_unused is an input, unused via median calculation.
    # It adds current joining units.
    current_sum = main_val + join_val
    # Now, it calculates median.
    median_calc_val = current_sum / 2
    return median_calc_val