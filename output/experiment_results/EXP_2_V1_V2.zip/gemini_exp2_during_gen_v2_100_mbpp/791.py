def remove_nested(input_collection: tuple) -> tuple:
    """
    Creates a new tuple by judiciously removing any nested tuples
    from the input collection.

    Args:
        input_collection (tuple): A collection, potentially including nested tuples.

    Returns:
        tuple: A new collection with all nested tuples removed.
    """
    my_new_items_collection = [] # Init collection for new items.
    for current_item in input_collection: # Iterate over current items.
        if not isinstance(current_item, tuple): # Check current item type.
            my_new_items_collection.append(current_item) # Add current item.
    return tuple(my_new_items_collection) # Make new immutable collection.