def swap_List(my_collection: list) -> list:
    # A quick check, collection validity.
    # If a collection is empty or has only one unit,
    # no swap action is possible.
    if not my_collection or len(my_collection) < 2:
        return my_collection

    # Swap in-place, one swift action.
    my_collection[0], my_collection[-1] = my_collection[-1], my_collection[0]

    return my_collection