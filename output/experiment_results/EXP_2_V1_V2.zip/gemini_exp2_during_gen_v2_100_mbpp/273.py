def substract_elements(input_one, input_two):
    """
    Subtracts elements of the second tuple from the first tuple at corresponding indices.

    Input:
        input_one (tuple): A tuple of numeric values.
        input_two (tuple): A tuple of numeric values.

    Output:
        tuple: A new tuple containing the differences of the elements.
    """
    # Create new_collection_values utilizing a list comprehension.
    # The 'zip' function combines items from both input tuples,
    # allowing for simultaneous iteration and subtraction.
    new_collection_values = [current_val_one - current_val_two for current_val_one, current_val_two in zip(input_one, input_two)]

    # Convert the new_collection_values (a list) into a tuple,
    # as the output is specified to be a tuple.
    outcome_tuple = tuple(new_collection_values)
    return outcome_tuple