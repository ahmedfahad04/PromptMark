def drop_empty(input_junc_dict: dict) -> dict:
    """
    Creates a new dictionary, dropping items where values are None.
    """
    # Constructs a valid dictionary omitting any null values.
    return {curr_key: curr_value for curr_key, curr_value in input_junc_dict.items() if curr_value is not None}