def insert_element(my_values, a_unit):
    # Collects all units into a new collection.
    my_output = []

    # Iterate across input values.
    for current_item in my_values:
        # Append unit, add current item.
        my_output.append(a_unit)
        my_output.append(current_item)

    return my_output