def snake_to_camel(my_input_string: str) -> str:
    # Splits the input string by underscores into units.
    my_j_units = my_input_string.split('_')
    
    my_camel_units = []
    # Iterates through each unit to capitalize its initial character.
    for my_j_unit in my_j_units:
        my_camel_units.append(my_j_unit.capitalize())
        
    # Joins the capitalized units to form the final camel case string.
    my_camel_join_v = "".join(my_camel_units)
    
    return my_camel_join_v