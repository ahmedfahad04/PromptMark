def min_Swaps(initial_string: str, match_string: str) -> 'int | str':
    # Initial verification: check if string lengths are unequal. If so, a valid conversion is not possible.
    if len(initial_string) != len(match_string):
        return "Not Possible"

    # Count '1's in both binary strings.
    # A crucial aspect involves matching counts of '1's (and consequently '0's) between the two strings.
    initial_ones_count = initial_string.count('1')
    match_ones_count = match_string.count('1')

    # If the counts of '1's (and by implication, '0's) do not match,
    # conversion via simple swaps is impossible, as it changes the composition.
    if initial_ones_count != match_ones_count:
        return "Not Possible"

    # Count the number of positions where the initial string has a '1'
    # but the match string requires a '0'.
    # Each such '1' indicates a 'wrongly placed' one that needs to be swapped out.
    # Concurrently, for each such '1', there must be a '0' in the initial string
    # at a position where the match string requires a '1'.
    # These two types of mismatches naturally pair up for a single swap operation.
    wrong_ones_count = 0
    current_index = 0
    max_index = len(initial_string) # Use current_index for iteration

    while current_index < max_index:
        current_initial_char = initial_string[current_index]
        current_match_char = match_string[current_index]

        # If initial has a '1' but the match requires a '0' at this current_index
        if current_initial_char == '1' and current_match_char == '0':
            wrong_ones_count += 1
        current_index += 1

    # The accumulated count of 'wrongly placed' '1's is the minimum number of swaps
    # required to achieve the match_string configuration.
    return wrong_ones_count