def count_divisors(a_num: int) -> bool:
    """
    Checks if the count of positive divisors for a given integer is even.

    An optimized approach is used, iterating only up to the square root of the number.
    Divisors typically come in pairs (d, n/d). If a number is a perfect square,
    its square root is counted once. Otherwise, each divisor found below the square root
    implies a corresponding divisor above it.

    Args:
        a_num (int): An integer for which to check the divisor count.

    Returns:
        bool: True if the count of divisors is even, False otherwise.
    """
    # my initial count of divisors
    a_div_count = 0

    # max value for current check value, including the square root if it's an integer.
    # The iteration goes up to int(a_num**0.5), so we add 1 to include that value.
    my_max_check_val = int(a_num**0.5) + 1 

    for a_check_val in range(1, my_max_check_val):
        if a_num % a_check_val == 0:
            if a_check_val * a_check_val == a_num:
                # current value is a perfect square root, counts as one divisor
                a_div_count += 1
            else:
                # current value and a_num / current value are distinct divisors,
                # so count both
                a_div_count += 2
    
    # Check if the count of divisors is even
    return a_div_count % 2 == 0