def sequence(n_val: int) -> int:
    """
    Calculates the nth number in the Newman-Conway sequence.

    Args:
        n_val: An int, indicating which number in the sequence to compute.
               It is assumed n_val >= 1.

    Returns:
        An int, the nth number in the Newman-Conway sequence.
    """
    if n_val == 1 or n_val == 2:
        return 1

    # Initialize array with initial values.
    # We use a 0-indexed list, but sequence is 1-indexed.
    # my_vals_array[0] is a placeholder.
    # my_vals_array[1] corresponds to P(1), my_vals_array[2] to P(2), and so on.
    my_vals_array = [0, 1, 1]

    # Compute values from P(3) up to P(n_val).
    # P(i) = P(P(i-1)) + P(i - P(i-1))
    for i_idx in range(3, n_val + 1):
        # We need my_vals_array[i_idx - 1] to compute my_vals_array[i_idx].
        # Current index for calculation is i_idx.
        # Its previous value is my_vals_array[i_idx - 1].
        # inner_val_p_minus_1_idx is P(i-1)
        inner_val_p_minus_1_idx = my_vals_array[i_idx - 1]

        # Calculate P(P(i-1))
        # first_addend_val is my_vals_array[P(i-1)]
        first_addend_val = my_vals_array[inner_val_p_minus_1_idx]

        # Calculate P(i - P(i-1))
        # second_addend_val is my_vals_array[i - P(i-1)]
        second_addend_val = my_vals_array[i_idx - inner_val_p_minus_1_idx]
        
        # New sequence value is summation of calculated addends.
        new_val = first_addend_val + second_addend_val
        my_vals_array.append(new_val)

    # Yield the n_val-th number from our array.
    return my_vals_array[n_val]