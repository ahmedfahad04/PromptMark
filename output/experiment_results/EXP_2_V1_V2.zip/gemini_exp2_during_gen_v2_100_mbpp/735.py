def toggle_middle_bits(num: int) -> int:
    if num == 0:
        return 0

    # Acquire its count of binary units.
    u_numb_count_val = num.bit_length()

    # If two or less units, no middle units exist.
    if u_numb_count_val <= 2:
        return num

    # Inner units count, excluding first and last.
    u_inner_count = u_numb_count_val - 2

    # A mask of 'u_inner_count' ones.
    # Shift this mask one position up from LSB to align with middle units.
    u_mask_val = ((1 << u_inner_count) - 1) << 1

    # XOR current num with the mask to toggle its middle units.
    u_outcome_val = num ^ u_mask_val
    return u_outcome_val