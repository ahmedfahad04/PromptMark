import collections

def frequency_lists(input_collection: list[list[int]]) -> dict[int, int]:
    """
    Calculates the frequency of each unique numeric item in a flattened list of lists.

    Args:
        input_collection: A collection of lists, where each inner list contains integers.

    Returns:
        A dictionary where keys are the unique items and values are their frequencies.
    """
    # Current unit items collection: Flatten the input list of lists into a single list.
    # Uses a list comprehension for a concise flattening action.
    current_all_items = [unit_item for current_sub_list in input_collection for unit_item in current_sub_list]

    # Option 1: Manual counting using a dictionary
    items_counts_mapping = {}
    for an_item in current_all_items:
        items_counts_mapping[an_item] = items_counts_mapping.get(an_item, 0) + 1
    
    # Option 2 (Alternative using collections.Counter, often more concise):
    # This just shows an alternative approach if a utility like Counter is allowed.
    # from collections import Counter
    # items_counts_mapping = Counter(current_all_items)

    return items_counts_mapping