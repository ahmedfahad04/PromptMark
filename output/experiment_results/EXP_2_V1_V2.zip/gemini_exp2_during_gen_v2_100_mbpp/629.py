def Split(input_numeric_values: list[int]) -> list[int]:
    """
    Collects just even numbers from an input numeric collection.

    Args:
        input_numeric_values: A list of numeric values.

    Returns:
        A new list containing only the even numeric values.
    """
    current_even_values = []
    for current_numeric_value in input_numeric_values:
        # Check if current_numeric_value is even.
        # A numeric value is even if its modulo 2 is zero.
        if current_numeric_value % 2 == 0:
            current_even_values.append(current_numeric_value)
    return current_even_values