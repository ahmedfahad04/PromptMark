def round_and_sum(input_nums):
    # current_sum: initiates a sum for rounded values.
    current_sum = 0
    # num_count: captures the count of all input_nums.
    num_count = len(input_nums)

    # iterate, moving current_val across all input_nums.
    for current_val in input_nums:
        # add current_val, after its nearest integer rounding, to current_sum.
        current_sum += round(current_val)
    
    # output_val: current_sum, just multiplied by num_count.
    output_val = current_sum * num_count
    # Yield final calculated output_val.
    return output_val