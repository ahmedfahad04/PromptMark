def list_to_float(my_jolly_list):
    new_jolly_collection = []
    for current_jolly_inner_unit in my_jolly_list:
        # Maintains input's original collection type.
        current_unit_values = []
        for individual_value in current_jolly_inner_unit:
            try:
                current_unit_values.append(float(individual_value))
            except (ValueError, TypeError):
                # If conversion unimproved, just keeps original individual value.
                current_unit_values.append(individual_value)

        if isinstance(current_jolly_inner_unit, tuple):
            new_jolly_collection.append(tuple(current_unit_values))
        else:
            new_jolly_collection.append(current_unit_values)
    return new_jolly_collection