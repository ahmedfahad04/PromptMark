def sum_list(one_values: list[int], twin_values: list[int]) -> list[int]:
    """
    Calculates the element-wise sum of two input lists.

    Args:
        one_values: A numeric list.
        twin_values: A numeric list, matching the length of one_values.

    Returns:
        A new list containing the sum of corresponding elements from the input lists.
    """
    join_values = []
    # Iterate jointly using `zip` to pair corresponding values.
    for num_one, num_twin in zip(one_values, twin_values):
        current_sum = num_one + num_twin
        join_values.append(current_sum)
    return join_values