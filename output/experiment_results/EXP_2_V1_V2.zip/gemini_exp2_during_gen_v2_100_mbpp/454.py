def text_match_wordz(j_input_string):
    return 'z' in j_input_string