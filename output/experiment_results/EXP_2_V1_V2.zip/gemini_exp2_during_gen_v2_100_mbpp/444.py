def trim_tuple(input_collections, k_val):
    # Initiate a collection for new, trimmed tuples.
    many_new_collections = []
    # Iterate, working on current tuple in input collections.
    for current_collection in input_collections:
        # Construct current new collection via slicing.
        # This removes k_val elements from the start and k_val elements from the end.
        current_new_collection = current_collection[k_val : -k_val]
        many_new_collections.append(current_new_collection)
    
    # Yield output, converting it as a string to match the specified format.
    output_as_string = str(many_new_collections)
    return output_as_string