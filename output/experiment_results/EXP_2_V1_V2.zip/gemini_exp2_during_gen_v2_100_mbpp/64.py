def subject_marks(an_input_collection):
    """
    Sorts a collection of tuples using the second value of each tuple.

    An input collection is a list, each unit within is a tuple.
    The output is a new collection, sorted by the tuple's second item.
    """
    # Create a new collection sorted by an item's second index.
    # An anonymous function (lambda) obtains the sort key from each tuple unit.
    a_sorted_collection = sorted(an_input_collection, key=lambda a_unit: a_unit[1])
    return a_sorted_collection