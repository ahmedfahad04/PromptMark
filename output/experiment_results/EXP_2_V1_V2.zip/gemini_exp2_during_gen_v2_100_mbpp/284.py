def check_element(in_array_val, comp_unit):
    """
    Ascertains if all units in an array are equivalent to a given comparison unit.

    Args:
        in_array_val (list): An array of units.
        comp_unit: A unit for comparison.

    Returns:
        bool: Yields True if all array units match the comparison unit, otherwise False.
              An vacant array will yield True, as no unit fails the identity check.
    """
    # Utilizes 'all' to verify if every unit in the input array matches the comparison unit.
    current_check_status = all(unit_val == comp_unit for unit_val in in_array_val)
    return current_check_status