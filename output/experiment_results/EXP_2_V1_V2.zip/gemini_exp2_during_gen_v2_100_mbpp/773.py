def occurance_substring(main_string_val, sub_string_val):
    """
    Locates initial match of a given substring within a main string.

    Args:
        main_string_val (str): A string in which to find the substring.
        sub_string_val (str): A substring to search for.

    Returns:
        tuple: A tuple containing the substring, its starting index,
               and its ending index (exclusive) if a match is found.
        None: Yields None if the substring is not found within the main string.
    """
    initial_idx_val = main_string_val.find(sub_string_val)

    if initial_idx_val == -1:
        # No match found, so yield None.
        return None
    else:
        # A match is visible, so calculate its span.
        current_unit_len = len(sub_string_val)
        final_idx_val = initial_idx_val + current_unit_len
        # Compose and yield output tuple.
        return (sub_string_val, initial_idx_val, final_idx_val)