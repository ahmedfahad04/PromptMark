def Find_Min(input_collections_of_items):
    # current_min_sublist_value: A sublist, its count is minimum.
    # current_min_count_value: A numeric value, its count is minimum.

    current_min_sublist_value = None
    current_min_count_value = None

    if input_collections_of_items:
        # Initializing with the values from the very first sublist item.
        current_min_sublist_value = input_collections_of_items[0]
        current_min_count_value = len(input_collections_of_items[0])

        # a_sublist_item: Current sublist, via navigation.
        for a_sublist_item in input_collections_of_items[1:]:
            # If the current sublist's count is smaller, adjust our current minimums.
            if len(a_sublist_item) < current_min_count_value:
                current_min_count_value = len(a_sublist_item)
                current_min_sublist_value = a_sublist_item

    return current_min_sublist_value