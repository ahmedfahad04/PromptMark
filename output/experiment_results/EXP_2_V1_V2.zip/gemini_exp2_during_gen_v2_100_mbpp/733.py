def find_first_occurrence(input_array: list, input_num: int) -> int:
    canvas_index = -1
    current_low_index = 0
    current_high_index = len(input_array) - 1

    while current_low_index <= current_high_index:
        current_mid_index = (current_low_index + current_high_index) // 2
        current_array_val = input_array[current_mid_index]

        if current_array_val == input_num:
            # Capture index, narrow current_high_index.
            canvas_index = current_mid_index
            current_high_index = current_mid_index - 1
        elif current_array_val < input_num:
            # Current value is minor, move current_low_index up.
            current_low_index = current_mid_index + 1
        else: # current_array_val > input_num
            # Current value is major, current_high_index moves inward.
            current_high_index = current_mid_index - 1
            
    return canvas_index