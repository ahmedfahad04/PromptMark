def sum_even_and_even_index(an_input_array):
    a_current_sum = 0
    # Iterate using index and value concurrently.
    for an_index_val, a_val in enumerate(an_input_array):
        # Check if index is even and value is also even.
        if an_index_val % 2 == 0 and a_val % 2 == 0:
            a_current_sum += a_val
    return a_current_sum