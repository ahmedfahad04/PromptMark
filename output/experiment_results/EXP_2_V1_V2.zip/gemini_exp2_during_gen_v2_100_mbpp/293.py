import math

def otherside_rightangle(in_value_a, in_value_u):
    """
    A function computes the hypotenuse of a right-angled triangle.
    It assumes the two input values are the lengths of the two smaller sides (legs).
    """
    # Computes square of the first input side.
    in_a_square = in_value_a * in_value_a
    # Computes square of the second input side.
    in_u_square = in_value_u * in_value_u

    # Sums up the squares of the two input sides.
    sum_squares = in_a_square + in_u_square

    # Calculates the final value (hypotenuse) using the square root of the sum.
    main_unit_calc_val = math.sqrt(sum_squares)
    
    return main_unit_calc_val