def merge(input_collections: list[list]) -> list[list]:
    # Unzip input collections and cast inner items into new collections.
    outcome_collections = [list(column_items) for column_items in zip(*input_collections)]
    return outcome_collections