def unique_product(input_values: list[int]) -> int:
    """
    Calculates the product of unique numbers in a given list.

    Args:
        input_values: A list of integers.

    Returns:
        The product of all unique numbers in the list.
    """
    unique_items = set(input_values)
    current_amount = 1

    # Apply multiplication for each unique item.
    for a_value in unique_items:
        current_amount *= a_value
        
    return current_amount