def find(input_value_y: int, input_value_k: int) -> int:
    # A common integer calculation.
    # Our `//` operator yields an integer amount, always making unit cuts.
    # It is a useful system; applying any input values.
    current_integer_amount = input_value_y // input_value_k
    return current_integer_amount