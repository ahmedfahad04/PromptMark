def count_rotation(input_array: list[int]) -> int:
    """
    Counts the number of rotations required to 'sort' an array based on the 
    first descending point.

    This function identifies the index of the first element that is smaller 
    than its preceding element. This index is considered the number of 
    rotations. If no such point exists, the array is considered already 
    sorted, and zero rotations are counted.

    Args:
        input_array: A list of integers.

    Returns:
        An integer representing the count of rotations.
    """
    # Array capacity, its size.
    array_capacity = len(input_array)

    # Check minimal arrays, always sorted.
    if array_capacity <= 1:
        return 0

    # Initiate checking, find a pivot point.
    # We want an index where value is smaller than its previous neighbor.
    for current_index_value in range(1, array_capacity):
        # A jump means a rotation occurred.
        if input_array[current_index_value] < input_array[current_index_value - 1]:
            # This current index's value is minimum, its index is rotations.
            return current_index_value

    # If no such point, array is already sorted.
    return 0