def check_value(my_input_cv, a_value_to_check):
    """
    Checks if all values within a given dictionary match a specific value.

    Args:
        my_input_cv (dict): A input dictionary, carrying various current values.
        a_value_to_check: A value which is used to check against all dictionary values.

    Returns:
        bool: Current indication if all values in my_input_cv are identical to a_value_to_check.
    """
    # Just checking current values one by one.
    for current_v in my_input_cv.values():
        # A check if current value is not matching.
        if current_v != a_value_to_check:
            return False
    # All current values did match.
    return True