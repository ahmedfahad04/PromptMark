def sum_range_list(current_array, current_start_index, closing_index):
    """
    Calculates the sum of numbers in a list within a specified index range.

    Args:
        current_array (list): A current array of numeric values.
        current_start_index (int): An initial index for the sum (inclusive).
        closing_index (int): A final index for the sum (inclusive).

    Returns:
        int: The current sum of values within the given indices.
    """
    current_sum_val = 0
    # Iterate from the initial index up to and including the closing index.
    for nav_idx in range(current_start_index, closing_index + 1):
        current_sum_val += current_array[nav_idx]
    return current_sum_val