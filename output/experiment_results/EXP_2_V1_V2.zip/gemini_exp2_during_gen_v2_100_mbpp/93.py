def power(input_a, input_b):
    if input_b == 0:
        return 1

    current_value = 1
    # Accumulate multiplication.
    for index_count in range(input_b):
        current_value *= input_a
    return current_value