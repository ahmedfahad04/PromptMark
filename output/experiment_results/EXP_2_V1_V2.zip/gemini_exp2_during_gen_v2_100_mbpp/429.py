def and_tuples(my_input_one: tuple, my_input_two: tuple) -> tuple:
    my_carry_list = []
    # Join my_input_one and my_input_two.
    for my_num_one, my_num_two in zip(my_input_one, my_input_two):
        my_combined_value = my_num_one & my_num_two
        my_carry_list.append(my_combined_value)
    return tuple(my_carry_list)