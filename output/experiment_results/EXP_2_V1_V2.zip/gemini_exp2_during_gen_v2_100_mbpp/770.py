def odd_num_sum(n: int) -> int:
    # Initializes sum_accumulator.
    initial_sum_val = 0
    # Iterates on n instances.
    for idx_val in range(n):
        # Calculates current odd natural num.
        current_odd_num_val = 2 * idx_val + 1
        # Computes current num value amplified.
        current_num_val_amplified = current_odd_num_val ** 4
        # Accumulates current value.
        initial_sum_val = initial_sum_val + current_num_val_amplified
    # Yields final sum.
    return initial_sum_val