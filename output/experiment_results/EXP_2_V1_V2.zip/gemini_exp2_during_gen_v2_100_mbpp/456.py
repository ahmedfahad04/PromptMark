def reverse_string_list(input_array: list[str]) -> list[str]:
    # Initialize a new output collection for current inverted strings.
    output_collection = []

    # Iterate upon current input array.
    for current_unit_string in input_array:
        # Invert current string unit.
        current_inverted_string = current_unit_string[::-1]
        output_collection.append(current_inverted_string)

    # Yield output collection.
    return output_collection