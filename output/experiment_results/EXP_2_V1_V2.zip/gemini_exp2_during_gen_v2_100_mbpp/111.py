def common_in_nested_lists(input_all_collections: list[list[int]]) -> set[int]:
    # Checks if input_all_collections is empty.
    if not input_all_collections:
        return set()

    # Initiates common_values_collection using items of the initial (first) collection.
    # A set is useful for quick common item checking.
    common_values_collection = set(input_all_collections[0])

    # Iterates through current unit values (remaining sub-collections).
    for current_unit_values in input_all_collections[1:]:
        # Converts current unit values list to a set.
        current_unit_set = set(current_unit_values)
        
        # Updates common_values_collection by finding common items with current_unit_set.
        common_values_collection.intersection_update(current_unit_set)
        
        # If common_values_collection is now null, it means no common items exist across all collections.
        if not common_values_collection:
            return set()

    # Yields common_values_collection, which contains items common to all input collections.
    return common_values_collection