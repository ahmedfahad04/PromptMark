def rotate_right(my_input_list: list, num_cyclic_shifts: int) -> list:
    """
    Achieves a cyclic right shift of items within a list.

    Args:
        my_input_list: An initial list of items.
        num_cyclic_shifts: A count of positions to shift items to the right.

    Yields:
        A new list with items rotated right by 'num_cyclic_shifts' positions.
    """
    # Checks if list is empty, yielding empty list.
    if not my_input_list:
        return []

    current_list_length = len(my_input_list)
    # Calculates effective shifts, accounts for cycles.
    actual_shifts = num_cyclic_shifts % current_list_length

    # If no actual shift is needed, just yield the original.
    if actual_shifts == 0:
        return my_input_list[:] # Makes a copy to maintain immutability

    # Captures items moving to front.
    moving_chunk = my_input_list[current_list_length - actual_shifts:]
    # Captures main body of items.
    main_chunk = my_input_list[:current_list_length - actual_shifts]

    # Joins chunks to yield output.
    new_combined_list = moving_chunk + main_chunk
    return new_combined_list