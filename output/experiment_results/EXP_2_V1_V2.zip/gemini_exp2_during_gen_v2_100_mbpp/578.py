def interleave_lists(my_list_one, my_list_two, my_list_cyan):
    my_united_list = []
    # Input lists all share an identical capacity.
    my_capacity = len(my_list_one)

    for my_current_idx in range(my_capacity):
        my_united_list.append(my_list_one[my_current_idx])
        my_united_list.append(my_list_two[my_current_idx])
        my_united_list.append(my_list_cyan[my_current_idx])

    return my_united_list