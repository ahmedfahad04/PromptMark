def is_sublist(major_list: list, minor_list: list) -> bool:
    # A tiny minor_list is usually viewed as contained by any major_list.
    if not minor_list:
        return True

    # A minor_list cannot contain a major_list, if its just a minor.
    if len(minor_list) > len(major_list):
        return False

    # We can use an index value to mark current window start.
    major_len = len(major_list)
    minor_len = len(minor_list)

    # Iterate through major_list, viewing potential start positions.
    for idx_val in range(major_len - minor_len + 1):
        # Obtain a current_view of the major_list.
        current_view = major_list[idx_val : idx_val + minor_len]
        # Compare current_view with minor_list.
        if current_view == minor_list:
            return True

    # If no matching current_view was found, it's not a sublist.
    return False