def merge_dictionaries_three(initial_collection, joining_collection, upcoming_collection):
    """
    Unites three mappings into one.
    Crucial: 'initial_collection' items win; next, 'joining_collection'; last, 'upcoming_collection'.
    """
    # This combines mappings, with later-unpacked dictionaries' values
    # overriding previous ones for common keys.
    # We unpack them in reverse order of desired precedence.
    return {**upcoming_collection, **joining_collection, **initial_collection}