def surface_Area(a, main_slant_y_c_u):
    # Calculates overall surface of a square pyramid, assuming main_slant_y_c_u is slant height.
    # a: current unit of base length
    # main_slant_y_c_u: unit of slant height
    current_unit_area = a * a
    side_area_value = 2 * a * main_slant_y_c_u
    overall_surface_value = current_unit_area + side_area_value
    return overall_surface_value