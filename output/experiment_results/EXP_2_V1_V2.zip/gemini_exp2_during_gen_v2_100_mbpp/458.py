def rectangle_area(w_unit: int, y_unit: int) -> int:
    """
    Calculates current area of a rectangle.

    Args:
        w_unit: A numeric unit, commonly current width.
        y_unit: A numeric unit, commonly y-axis unit or length.

    Returns:
        An integer indicating current area.
    """
    # Computes area utilizing units.
    current_area = w_unit * y_unit
    return current_area