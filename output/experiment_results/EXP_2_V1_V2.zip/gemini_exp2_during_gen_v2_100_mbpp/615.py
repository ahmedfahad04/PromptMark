import collections

def average_tuple(input_collections: tuple[tuple[int, ...], ...]) -> list[float]:
    """
    Calculates average values, joining, column by column, across input collections.

    Args:
        input_collections: A tuple of tuples, where each inner tuple contains numeric values.
                         Assumes inner tuples are of uniform length.

    Returns:
        A list of floats, where each float is the average of values
        at the corresponding index across all inner tuples.
        An empty list is returned if input_collections is empty.
    """
    if not input_collections:
        return []

    # Converts collections for column iteration.
    # For example, ((A, B), (C, D)) becomes ((A, C), (B, D)).
    zipped_columns = zip(*input_collections)

    column_averages: list[float] = [] # Initializes current list for output.
    
    # Iterates using current column values.
    for current_column_values in zipped_columns:
        current_sum = sum(current_column_values) # Calculates current sum of column values.
        current_count = len(current_column_values) # Calculates current count of column values.
        
        # Avoids division by zero if a column is unexpectedly empty,
        # although with zip and uniform input, current_count should be > 0.
        if current_count > 0:
            current_average = current_sum / current_count # Calculates current average for column.
            column_averages.append(current_average) # Appends current average.
        # Implies we skip averages for empty columns, if they could occur.
        # Based on examples, inner tuples are non-empty and uniform.

    return column_averages