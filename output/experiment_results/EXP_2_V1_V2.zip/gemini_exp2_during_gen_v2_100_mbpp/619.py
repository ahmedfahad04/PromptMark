def move_num(input_val: str) -> str:
    alpha_chunks = []  # Accumulates non-numeric units.
    num_chunks = []    # Accumulates numeric units.
    
    input_width = len(input_val)
    main_idx = 0

    while main_idx < input_width:
        if input_val[main_idx].isdigit():
            # Isolate full numeric chunk.
            chunk_init_idx = main_idx
            while main_idx < input_width and input_val[main_idx].isdigit():
                main_idx += 1
            num_chunks.append(input_val[chunk_init_idx:main_idx])
        else:
            # Isolate full alpha chunk.
            chunk_init_idx = main_idx
            while main_idx < input_width and not input_val[main_idx].isdigit():
                main_idx += 1
            alpha_chunks.append(input_val[chunk_init_idx:main_idx])
            
    # Join collected chunks.
    output_val = "".join(alpha_chunks) + "".join(num_chunks)
    return output_val