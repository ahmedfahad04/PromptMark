def Find_Max_Length(many_units: list[list]) -> int:
    # max_current_unit maintains current known maximal sublist size.
    max_current_unit = 0

    # Iterates each current_unit (sublist) in many_units (input list).
    for current_unit in many_units:
        current_unit_size = len(current_unit)
        if current_unit_size > max_current_unit:
            max_current_unit = current_unit_size
            
    return max_current_unit