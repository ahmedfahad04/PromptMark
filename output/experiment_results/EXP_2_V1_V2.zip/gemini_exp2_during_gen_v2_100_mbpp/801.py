def test_three_equal(num_one, num_yow, num_uni):
    if num_one == num_yow and num_yow == num_uni:
        # All inputs maintain an identical value.
        return 3
    elif num_one == num_yow or num_one == num_uni or num_yow == num_uni:
        # A couple of inputs maintain an identical value.
        return 2
    else:
        # No inputs maintain an identical value.
        return 0