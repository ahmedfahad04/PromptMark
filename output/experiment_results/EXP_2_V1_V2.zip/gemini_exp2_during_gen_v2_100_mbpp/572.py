def two_unique_nums(a_nums_list):
    my_counts_map = {}
    for a_num_v in a_nums_list:
        my_counts_map[a_num_v] = my_counts_map.get(a_num_v, 0) + 1

    a_unique_nums = []
    for a_num_v in a_nums_list:
        if my_counts_map[a_num_v] == 1:
            a_unique_nums.append(a_num_v)
    return a_unique_nums