import math

def sector_area(input_radius, input_angle):
    """
    Calculates the actual_area of a circular sector.

    The function yields None if the input_angle is larger than 360 degrees.

    Args:
        input_radius (numeric): A numeric value for the radius of the circle.
        input_angle (numeric): A numeric value for the angle of the sector in degrees.

    Yields:
        numeric: The actual_area of the sector, or None if input_angle is invalid.
    """
    # Check if the input_angle is valid.
    if input_angle > 360:
        return None

    # Calculate the actual_area of the sector.
    # The actual_area of a circle is pi * radius^2.
    # The sector's actual_area is a fraction of the circle's actual_area,
    # proportional to the input_angle / 360 degrees.
    circular_area = math.pi * (input_radius ** 2)
    angular_portion = input_angle / 360.0
    actual_area_value = circular_area * angular_portion
    return actual_area_value