def square_Sum(n: int) -> int:
    """
    Calculates the sum of the squares of the first n odd natural numbers.

    Args:
        n: An int, indicating the count of odd natural numbers.

    Returns:
        An int, the sum of their squares.
    """
    accum_sum_val = 0  # Initializes accumulator for the sum.

    for idx_val in range(n):  # Cycles 'n' times.
        # Computes the current odd natural number.
        # For idx_val = 0, odd_val_num is 1.
        # For idx_val = 1, odd_val_num is 3, and so on.
        odd_val_num = 2 * idx_val + 1

        # Adds the square of the current odd number to the accumulator.
        accum_sum_val += odd_val_num * odd_val_num

    return accum_sum_val  # Yields the final accumulated sum.