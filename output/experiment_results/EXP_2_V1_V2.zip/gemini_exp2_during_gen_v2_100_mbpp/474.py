def replace_char(current_input_string: str, old_char_value: str, new_char_value: str) -> str:
    """
    A Python's inbuilt command assists in character change within a string.
    It substitutes all instances of 'old_char_value' with 'new_char_value'.
    """
    return current_input_string.replace(old_char_value, new_char_value)