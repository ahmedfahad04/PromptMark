def largest_subset(input_nums_list):
    # Confirm collection validity.
    if not input_nums_list:
        return 0

    # Sort all nums. This permits simpler divisibility checks.
    # The current_val must always be greater than or equal to minor_val,
    # simplifying the divisibility condition to `current_val % minor_val == 0`.
    sorted_nums = sorted(input_nums_list)

    num_count = len(sorted_nums)

    # max_sizes_via_indices[idx_i] indicates largest subset size ending with sorted_nums[idx_i].
    # Initial value is one, any num forms a size-one subset.
    max_sizes_via_indices = [1] * num_count

    # View nums; cumulatively adjust max sizes.
    # idx_i points to the current number we are considering as the end of a subset.
    for idx_i in range(num_count):
        current_num_val = sorted_nums[idx_i]

        # Check all prior nums (those with a smaller index).
        # idx_j points to a number that could potentially precede current_num_val in a subset.
        for idx_j in range(idx_i):
            minor_num_val = sorted_nums[idx_j]

            # If current is divisible by minor, join current's chain.
            # This means minor_num_val can be a part of a divisible subset ending with current_num_val.
            if current_num_val % minor_num_val == 0:
                # Update max_sizes_via_indices[idx_i] if current chain wins.
                # A new subset candidate would be the subset ending at minor_num_val plus current_num_val itself.
                max_sizes_via_indices[idx_i] = max(max_sizes_via_indices[idx_i], 1 + max_sizes_via_indices[idx_j])

    # Overall max value in max_sizes_via_indices is the answer.
    # This represents the size of the largest divisible subset found among all possible ending numbers.
    return max(max_sizes_via_indices)