def max_product(input_array_values: list[int]) -> int:
    array_count = len(input_array_values)

    if array_count == 0:
        return 0  # An array can contain no values, yielding zero.

    # current_sequence_product tracks the product of the increasing contiguous subsequence ending at the current position.
    current_sequence_product = input_array_values[0]
    # overall_max_val maintains the maximum product found across all increasing contiguous subsequences.
    overall_max_val = input_array_values[0]

    # Iterate main_index from the second value onward.
    for main_index in range(1, array_count):
        current_val = input_array_values[main_index]
        prior_val_in_array = input_array_values[main_index - 1]

        # Check if current_val continues an increasing sequence from the prior value.
        if current_val > prior_val_in_array:
            # If so, amplify current_sequence_product by multiplying current_val.
            current_sequence_product *= current_val
        else:
            # If not, commence a new sequence with current_val, as the increasing pattern is broken.
            current_sequence_product = current_val
        
        # Always update overall_max_val with the maximum product found so far.
        overall_max_val = max(overall_max_val, current_sequence_product)

    return overall_max_val