def list_split(input_array_val: list, in_num_val: int) -> list[list]:
    """
    Splits an input list into 'in_num_val' sub-arrays,
    distributing items based on their original index modulo 'in_num_val'.
    """
    # Makes 'in_num_val' empty sub-arrays.
    my_chunk_arrays = [[] for _ in range(in_num_val)]

    # Walks via input array using its index and value.
    for idx_val, item_val in enumerate(input_array_val):
        # Aims at which chunk array via index.
        current_array_idx = idx_val % in_num_val
        my_chunk_arrays[current_array_idx].append(item_val)

    return my_chunk_arrays