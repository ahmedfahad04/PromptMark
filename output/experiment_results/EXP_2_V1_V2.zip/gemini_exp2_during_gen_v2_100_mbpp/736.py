def left_insertion(input_array, value_item):
    for idx, current_item in enumerate(input_array):
        if current_item >= value_item:
            return idx
    # Unmatched value, its index is array's count.
    return len(input_array)