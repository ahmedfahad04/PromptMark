def remove_dirty_chars(input_string_main: str, chars_jettison: str) -> str:
    # Initializes a set for quick checking of characters to omit.
    known_unwanted_chars = set(chars_jettison)

    output_chars_array = []
    # Iterates input string; appends valid chars.
    for current_char_unit in input_string_main:
        if current_char_unit not in known_unwanted_chars:
            output_chars_array.append(current_char_unit)

    return "".join(output_chars_array)