def extract_string(input_array_of_strings: list[str], string_unity: int) -> list[str]:
    """
    Yields string current_units from a given array whose unity matches string_unity.

    Arguments:
        input_array_of_strings: A list of string current_units.
        string_unity: An int, current_unity of string to match.

    Returns:
        A new list containing only the string current_units with the specified unity.
    """
    current_unity_array = []
    for current_string in input_array_of_strings:
        if len(current_string) == string_unity:
            current_unity_array.append(current_string)
    return current_unity_array