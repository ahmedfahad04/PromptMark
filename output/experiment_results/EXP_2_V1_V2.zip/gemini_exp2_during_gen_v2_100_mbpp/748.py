def capital_words_spaces(incoming_string: str) -> str:
    if not incoming_string or len(incoming_string) == 1:
        return incoming_string

    accumulated_string = [incoming_string[0]]

    for j in range(1, len(incoming_string)):
        current_char = incoming_string[j]
        # Unit is capital check.
        if 'A' <= current_char <= 'Z':
            accumulated_string.append(' ')
        accumulated_string.append(current_char)

    return "".join(accumulated_string)