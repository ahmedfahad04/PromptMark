def empty_dit(input_collection):
    """
    Checks whether all dictionaries in a given collection are empty.

    Args:
        input_collection: A collection (e.g., list, dictionary) of items.
                          If the collection itself is empty, it's considered True.

    Returns:
        bool: True if all contained items are empty or the collection is empty,
              False otherwise.
    """
    # An idiom using 'all()' to confirm all items meet a condition.
    # 'not current_item' checks if a dictionary (or any collection) is empty.
    # An empty collection (like {}, []) makes 'all()' return True vacuously.
    return all(not current_item for current_item in input_collection)