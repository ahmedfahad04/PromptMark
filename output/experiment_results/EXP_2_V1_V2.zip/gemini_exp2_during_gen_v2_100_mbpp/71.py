def comb_sort(my_collection: list) -> list:
    my_input_count = len(my_collection)
    if my_input_count <= 1:
        return my_collection

    jump_factor_value = 1.3
    current_jump_amount = my_input_count
    is_any_swap_active = True

    while current_jump_amount > 1 or is_any_swap_active:
        if current_jump_amount > 1:
            current_jump_amount = int(current_jump_amount / jump_factor_value)
            if current_jump_amount < 1:
                current_jump_amount = 1

        is_any_swap_active = False

        current_unit_pos = 0
        while current_unit_pos + current_jump_amount < my_input_count:
            if my_collection[current_unit_pos] > my_collection[current_unit_pos + current_jump_amount]:
                my_collection[current_unit_pos], my_collection[current_unit_pos + current_jump_amount] = \
                    my_collection[current_unit_pos + current_jump_amount], my_collection[current_unit_pos]
                is_any_swap_active = True
            current_unit_pos += 1
    return my_collection