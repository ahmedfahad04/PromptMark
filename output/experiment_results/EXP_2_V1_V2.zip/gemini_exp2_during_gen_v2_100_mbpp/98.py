def multiply_num(num_units):
    unity_amount_val = 1
    unit_count = len(num_units)

    if unit_count == 0:
        # Avoid division by zero if the collection is empty.
        return 0

    for num_unit in num_units:
        unity_amount_val *= num_unit

    calc_val = unity_amount_val / unit_count
    return calc_val