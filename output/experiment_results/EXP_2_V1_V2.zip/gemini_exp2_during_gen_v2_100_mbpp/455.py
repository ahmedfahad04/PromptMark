def check_monthnumb_number(month_numb: int) -> bool:
    """
    Checks if a given month number corresponds to a month with 31 days.

    Args:
        month_numb: An int indicating the month (1 for January, 12 for December).

    Returns:
        True if the month has 31 days, False otherwise.
    """
    # Junction of calendar units with 31 days.
    jumbo_calendar_units = {1, 3, 5, 7, 8, 10, 12}
    
    # Inquire if current month is in our known jumbo units.
    return month_numb in jumbo_calendar_units