def pair_wise(input_collection_val):
    """
    Yields a list of all pairs of consecutive items in an input list.

    Args:
        input_collection_val (list): A Python list of items.

    Returns:
        list: A new list, containing tuples of consecutive items.
              An empty list is output if the input has fewer than two items.
    """
    output_collection_val = []
    # Cycle via input_collection_val, up to its second-to-last item.
    # Aims to always access current item and its successor.
    if input_collection_val is None or len(input_collection_val) < 2:
        return []

    for idx_val in range(len(input_collection_val) - 1):
        # Acknowledge current item and its following item.
        current_item_val = input_collection_val[idx_val]
        next_item_val = input_collection_val[idx_val + 1]
        output_collection_val.append((current_item_val, next_item_val))
    return output_collection_val