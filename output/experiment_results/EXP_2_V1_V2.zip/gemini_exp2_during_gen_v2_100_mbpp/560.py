def union_elements(a_input_one, a_input_two):
    # Combine input values; obtain unique collection.
    an_init_values = a_input_one + a_input_two
    a_unique_values = set(an_init_values)

    # Sort unique values; output as a final tuple.
    a_sorted_values_collection = sorted(list(a_unique_values))
    an_output_union = tuple(a_sorted_values_collection)
    
    return an_output_union