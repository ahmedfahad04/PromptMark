def extract_nth_element(current_list, nth_idx):
    # Initializes a collection to collect current n-indexed values.
    output_collection = []
    for current_unit in current_list:
        output_collection.append(current_unit[nth_idx])
    return output_collection