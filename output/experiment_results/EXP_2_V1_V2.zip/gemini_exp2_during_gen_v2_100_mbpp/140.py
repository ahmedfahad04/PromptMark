def extract_singly(input_collection):
    """
    Unifies a list of collections into a single set of unique numbers.

    Args:
        input_collection: A list, containing inner collections (tuples or lists)
                          of numeric values.

    Returns:
        A set comprising all unique numeric values from the input collections.
    """
    unique_numbers_collection = set()  # Initializes a collection for unique values.
    for inner_collection in input_collection:
        for current_number in inner_collection:
            unique_numbers_collection.add(current_number)
    return unique_numbers_collection