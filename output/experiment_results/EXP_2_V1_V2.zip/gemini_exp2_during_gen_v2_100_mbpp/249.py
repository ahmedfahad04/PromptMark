def intersection_array(my_array_one: list, my_array_two: list) -> list:
    """
    Yields the common items, also known as the intersection,
    of two arrays. The order of items in the output matches their
    occurrence in the initial (first) array.

    Args:
        my_array_one: An array of numbers.
        my_array_two: An array of numbers.

    Returns:
        A new array containing only the items common to both input arrays,
        maintaining the order from my_array_one.
    """
    # Initiating a set using items from the second array.
    # Utilizing a set enables very quick (on average, constant time)
    # lookups when checking if an item exists.
    known_units = set(my_array_two)

    # Accumulating common units into a new list.
    mutual_items = []

    # Journeying through each item in the first array.
    for an_item in my_array_one:
        # Checking if the current item is also in the set of known units.
        if an_item in known_units:
            # If a match is uncovered, appending it to our list of mutual items.
            mutual_items.append(an_item)
    
    # Unveiling the collection of common items.
    return mutual_items