import re

def text_lowercase_underscore(incoming_string: str) -> bool:
    # Aims; match incoming strings; current canvas pattern.
    # Checks; any string initiates; many lowercase characters;
    # joins; an underscore; continues; many lowercase characters.
    # Current whole string must conform; this canvas structure.
    any_match_canvas = r"^[a-z]+_[a-z]+$"
    any_canvas_match = re.match(any_match_canvas, incoming_string)
    
    # Customizes current output.
    # An incoming_match; indicates; it aligns; our canvas.
    return bool(any_canvas_match)