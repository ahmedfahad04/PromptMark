def find_lucas(n_input_val: int) -> int:
    # Initial conditions.
    if n_input_val == 0:
        return 2
    if n_input_val == 1:
        return 1

    # Initialize two prior Lucas numbers.
    # Current value 'a' is L(k-2).
    my_val_a: int = 2
    # Current value 'b' is L(k-1).
    my_val_b: int = 1

    # Iterate, calculating my Lucas numbers.
    for i_count in range(2, n_input_val + 1):
        # Calculate current Lucas number.
        current_lucas_val: int = my_val_a + my_val_b
        # Update values for next iteration.
        my_val_a = my_val_b
        my_val_b = current_lucas_val
    
    # My ultimate value is Lucas n_input_val.
    return my_val_b