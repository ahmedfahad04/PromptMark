def sum_series(n: int) -> int:
    # Initiate a sum container for our calculation.
    current_sum = 0

    # Cycle 'i' from zero until 'n // 2' is completed.
    # A 'range' call is exclusive of its final unit, so we include 'n // 2 + 1'.
    for i in range((n // 2) + 1):
        # Calculate current unit's value within the series.
        current_value = n - (2 * i)
        # Accumulate unit's value into our current sum.
        current_sum += current_value

    return current_sum