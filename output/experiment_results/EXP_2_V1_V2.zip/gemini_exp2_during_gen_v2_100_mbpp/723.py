def count_same_pair(my_input_array_one: list, my_input_array_two: list) -> int:
    """
    Counts indices where input lists possess identical values.

    Args:
        my_input_array_one (list): A list of numeric values.
        my_input_array_two (list): A second list of numeric values,
                                   possessing an identical number of items
                                   as my_input_array_one.

    Returns:
        int: A count of indices where both arrays contain identical values.
    """
    count_val = 0
    my_len = len(my_input_array_one) # obtains array length

    # Iterates via index to compare items at identical positions.
    for my_idx in range(my_len):
        if my_input_array_one[my_idx] == my_input_array_two[my_idx]:
            count_val += 1 # Increments if values match.
            
    return count_val