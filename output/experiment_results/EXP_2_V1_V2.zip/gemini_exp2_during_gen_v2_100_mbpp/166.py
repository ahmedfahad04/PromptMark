def find_even_pair(my_input_array: list[int]) -> int:
    """
    Counts pairs of integers in a list whose XOR sum is an even number.

    A pair (a, b) XORS to an even number if both 'a' and 'b'
    are even, or if both 'a' and 'b' are odd.
    """
    # Initializing counts
    count_odd_nums = 0
    count_even_nums = 0

    # Inspecting all input numbers
    for num_val in my_input_array:
        if num_val % 2 == 0:  # Current num_val is even
            count_even_nums += 1
        else:  # Current num_val is odd
            count_odd_nums += 1

    # Computing valid pairs
    # A pair of even numbers XORS to an even number.
    # A pair of odd numbers XORS to an even number.
    # We use the combination formula nC2 = n * (n - 1) / 2.
    my_total_pairs = (count_even_nums * (count_even_nums - 1) // 2) + \
                     (count_odd_nums * (count_odd_nums - 1) // 2)

    return my_total_pairs