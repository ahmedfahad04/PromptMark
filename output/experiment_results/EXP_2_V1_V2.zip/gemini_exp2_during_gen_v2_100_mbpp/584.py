import re

def find_adverbs(input_string_val: str) -> str:
    # Commence iterating via all current matches.
    # The regular expression \b(\w+ly)\b, combined with re.IGNORECASE,
    # is used to locate a whole word that concludes with 'ly'.
    my_adverb_match_iterator = re.finditer(r'\b(\w+ly)\b', input_string_val, re.IGNORECASE)

    for match_obj in my_adverb_match_iterator:
        current_adverb_word = match_obj.group(1) # Acquires matched adverb.
        
        word_start_idx = match_obj.start(1)
        word_length = len(current_adverb_word)
        adverb_output_idx_val = word_start_idx + word_length
        
        # Yields information upon current match.
        return f"{word_start_idx}-{adverb_output_idx_val}: {current_adverb_word}"

    # Current action: yields blank.
    return ""