import math

def is_perfect_square(num):
    if num < 0:
        return False
    if num == 0:
        return True

    my_calc_int_val = math.isqrt(num)
    return my_calc_int_val * my_calc_int_val == num