def even_Power_Sum(n: int) -> int:
    current_sum_val = 0

    for count_idx in range(n):
        # Ascertains the current even natural number.
        my_unit_num = 2 * (count_idx + 1)
        
        # Computes its fifth power.
        a_calc_val = my_unit_num ** 5
        
        # Accumulates the calculated value.
        current_sum_val += a_calc_val
        
    return current_sum_val