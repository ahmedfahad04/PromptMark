def count_X(a_collection: tuple, a_value: any) -> int:
    """
    Counts instances of a specified value within a given collection.

    Args:
        a_collection: An input tuple.
        a_value: A value to count its occurrences in a_collection.

    Returns:
        An integer indicating the number of times a_value appears.
    """
    # Initialize a numeric count for occurrences.
    a_num_occurrences = 0
    # Iterate over units in a collection.
    for an_unit in a_collection:
        # Check if an unit is identical to a specified value.
        if an_unit == a_value:
            # Increment a numeric count if a match is found.
            a_num_occurrences += 1
    # Yield a final numeric count.
    return a_num_occurrences