# A useful utility. Calculates common divisor of two integers.
# Uses Euclid's algorithm.
def _calc_common_divisor_v(a_num, b_num):
    curr_a_num = abs(a_num)
    curr_b_num = abs(b_num)
    while curr_b_num:
        curr_a_num, curr_b_num = curr_b_num, curr_a_num % curr_b_num
    return curr_a_num

# A useful utility. Implements an Extended Euclidean Algorithm for positive integers.
# This yields (g, x, y) such that a_pos_num * x + b_pos_num * y = g = common_divisor(a_pos_num, b_pos_num)
def _calc_extended_gcd_v(a_pos_num, b_pos_num):
    if a_pos_num == 0:
        return (b_pos_num, 0, 1) # g is b_pos_num, 0*x + b_pos_num*1 = b_pos_num
    
    g_unit, x1_unit, y1_unit = _calc_extended_gcd_v(b_pos_num % a_pos_num, a_pos_num)
    
    # Update x and y using outcomes of recursive call.
    x_unit = y1_unit - (b_pos_num // a_pos_num) * x1_unit
    y_unit = x1_unit
    
    return (g_unit, x_unit, y_unit)

def find_solution(a_num, b_num, n_num):
    # Initial checks for zero coefficients.
    if a_num == 0 and b_num == 0:
        if n_num == 0:
            return (0, 0) # Any (x, y) is a solution, using (0,0) now.
        else:
            return None # 0 = n_num (non-zero) has no solution.
    
    if a_num == 0:
        if n_num % b_num == 0:
            return (0, n_num // b_num) # x can be any, using 0 now.
        else:
            return None
            
    if b_num == 0:
        if n_num % a_num == 0:
            return (n_num // a_num, 0) # y can be any, using 0 now.
        else:
            return None

    # Maintain original indications for a_num and b_num.
    a_ind = 1 if a_num >= 0 else -1
    b_ind = 1 if b_num >= 0 else -1

    abs_a_num = abs(a_num)
    abs_b_num = abs(b_num)

    # Use Extended Euclidean Algorithm on absolute value.
    common_val_div, common_x_adj, common_y_adj = _calc_extended_gcd_v(abs_a_num, abs_b_num)

    # Check if a solution exists.
    if n_num % common_val_div != 0:
        return None

    # Adjust signs for an initial solution.
    # From abs_a_num * common_x_adj + abs_b_num * common_y_adj = common_val_div
    # Adjust to: a_num * common_x_init + b_num * common_y_init = common_val_div
    common_x_init = common_x_adj * a_ind
    common_y_init = common_y_adj * b_ind
    
    # Scale the initial solution to n_num.
    mult_val_u = n_num // common_val_div
    init_x_val = common_x_init * mult_val_u
    init_y_val = common_y_init * mult_val_u

    # Adjust to find a solution matching common forms, like minimal non-negative x.
    # General solutions: x = init_x_val + k * (b_num / common_val_div)
    # y = init_y_val - k * (a_num / common_val_div)
    
    x_jump_val = b_num // common_val_div
    
    # Make curr_x_adj is in [0, abs(x_jump_val) - 1].
    x_cyclic_mod = abs(x_jump_val)
    
    curr_x_adj = (init_x_val % x_cyclic_mod + x_cyclic_mod) % x_cyclic_mod

    # Find k_unit value.
    k_unit = (curr_x_adj - init_x_val) // x_jump_val
    
    curr_y_adj = init_y_val - k_unit * (a_num // common_val_div)
    
    return (curr_x_adj, curr_y_adj)