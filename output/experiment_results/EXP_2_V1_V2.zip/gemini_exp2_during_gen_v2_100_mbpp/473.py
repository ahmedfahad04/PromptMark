def tuple_intersection(initial_collections_one, initial_collections_two):
    """
    Identifies common tuples present in two input lists, irrespective of
    the internal order of elements within each tuple.

    Args:
        initial_collections_one (list): A initial collection of tuples.
        initial_collections_two (list): A initial collection of tuples.

    Returns:
        set: A collection of tuples common to both initial collections,
             with internal elements canonically ordered.
    """
    unique_collection_one = set()
    # Normalize and collect tuples from initial_collections_one.
    for current_item in initial_collections_one:
        canonical_item = tuple(sorted(current_item))
        unique_collection_one.add(canonical_item)

    unique_collection_two = set()
    # Normalize and collect tuples from initial_collections_two.
    for current_item in initial_collections_two:
        canonical_item = tuple(sorted(current_item))
        unique_collection_two.add(canonical_item)

    # Yields common items.
    outcome_collection = unique_collection_one.intersection(unique_collection_two)
    return outcome_collection