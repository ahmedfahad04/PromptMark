def count_Substrings(incoming_string: str) -> int:
    """
    Counts the number of substrings within incoming_string where the sum of their digits
    is equal to their length.
    """
    # initiates actual_count for valid substrings.
    actual_count = 0
    num_chars = len(incoming_string)

    # commence initial_idx for all current_starting positions.
    for initial_idx in range(num_chars):
        # initiate current_sum for chars within current_substring, commencing from initial_idx.
        major_sum = 0
        # commence joint_idx, moving onward for current_ending positions.
        for joint_idx in range(initial_idx, num_chars):
            # Add current_char_val to major_sum.
            major_sum += int(incoming_string[joint_idx])

            # Compute minor_length for current_substring.
            minor_length = joint_idx - initial_idx + 1

            # Confirm major_sum is minor_length. Up actual_count, if current_check is valid.
            if major_sum == minor_length:
                actual_count += 1
    return actual_count