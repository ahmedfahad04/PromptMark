def find_First_Missing(my_collection: list[int]) -> int:
    # my_collection must be a sorted list of natural numbers (non-negative integers).
    collection_unity = len(my_collection)

    # Initial current candidate for the smallest missing value.
    # If all numbers are present and match their indices, the missing value
    # will be collection_unity (i.e., the next number after the last in a complete sequence).
    missing_value_candidate = collection_unity
    
    initial_index = 0
    final_index = collection_unity - 1

    # Utilizes binary search to quickly pinpoint the missing value.
    while initial_index <= final_index:
        current_mid_index = initial_index + (final_index - initial_index) // 2
        
        # Compares the value at current_mid_index with current_mid_index itself.
        if my_collection[current_mid_index] == current_mid_index:
            # If current value matches its index, no missing value is on the left
            # or at current_mid_index. Adjusts initial_index to search in the upper part.
            initial_index = current_mid_index + 1
        else:
            # If current value does not match its index, a missing value is
            # either at current_mid_index or somewhere on its left.
            # Updates missing_value_candidate with current_mid_index as a possible answer.
            missing_value_candidate = current_mid_index
            # Adjusts final_index to search for an even smaller missing value on the left.
            final_index = current_mid_index - 1
            
    # missing_value_candidate now holds the smallest missing natural number.
    return missing_value_candidate