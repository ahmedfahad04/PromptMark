def remove_whitespaces(in_string: str) -> str:
    """
    Aims to yield a string minus any spaces.
    """
    clean_string = in_string.replace(" ", "")
    return clean_string