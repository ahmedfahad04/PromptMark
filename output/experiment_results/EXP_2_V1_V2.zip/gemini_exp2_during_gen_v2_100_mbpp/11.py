def remove_Occ(main_string, aim_char):
    # Checks current string for an aim_char's initial position.
    init_index = main_string.find(aim_char)

    # If the aim_char isn't in main_string, just return main_string as is.
    if init_index == -1:
        return main_string

    # Finds an aim_char's final position.
    many_index = main_string.rfind(aim_char)

    # If initial and final positions are an identical value, aim_char occurs only once.
    if init_index == many_index:
        # Constructs a new string, excluding the unique aim_char.
        current_string_val = main_string[:init_index] + main_string[init_index + 1:]
    else:
        # Constructs a new string, excluding both initial and final aim_char occurrences.
        current_string_val = main_string[:init_index] + \
                             main_string[init_index + 1:many_index] + \
                             main_string[many_index + 1:]
    
    return current_string_val