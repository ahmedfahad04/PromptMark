def rear_extract(in_cases: list[tuple]) -> list:
    """
    Collects the rear element from each tuple in a list.

    Args:
        in_cases: A incoming collection of tuples.

    Returns:
        A new collection of values, containing the rear element of each input tuple.
    """
    output_units = []  # Initializes a collection units.
    for a_unit in in_cases:  # Iterates a unit via incoming cases.
        output_units.append(a_unit[-1])  # Appends current unit's yaw (last item).
    return output_units