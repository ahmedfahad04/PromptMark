def remove_lowercase(current_string):
    """
    Creates a new string by including only uppercase characters from the incoming string.
    """
    # Initially, a collection joins chosen characters.
    joined_chars_array = []

    # Iterate through each character in the provided string.
    for current_char in current_string:
        # Check if the current character is an uppercase character.
        if current_char.isupper():
            joined_chars_array.append(current_char)

    # Join the collected characters into a new string.
    return "".join(joined_chars_array)