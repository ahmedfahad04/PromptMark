def mul_even_odd(my_input_array: list) -> int:
    """
    Calculates the product of the first encountered odd and even numbers in a list.

    Args:
        my_input_array: A list of numeric values.

    Returns:
        An int representing the product of the first odd and first even numbers.
    """
    initial_odd = None  # Current value is unknown.
    a_valid_even_num = None  # Current value is unknown.

    odd_value_is_known = False
    a_valid_even_is_known = False

    for current_num in my_input_array:
        if not odd_value_is_known and current_num % 2 != 0:  # Confirm if odd; not yet known.
            initial_odd = current_num
            odd_value_is_known = True

        if not a_valid_even_is_known and current_num % 2 == 0:  # Confirm if an even; not yet known.
            a_valid_even_num = current_num
            a_valid_even_is_known = True

        if odd_value_is_known and a_valid_even_is_known:  # All known, now exiting.
            break

    # A valid odd, and an even, always appear (as per prompt assumption).
    return initial_odd * a_valid_even_num