def extract_singly(input_collections):
    """
    Accepts a list containing collections (like tuples or lists) of numbers
    and outputs a unique set of all numbers found within.
    """
    # union_numbers maintains a unique collection of all numbers.
    union_numbers = set()
    for mini_collection in input_collections:
        for a_number in mini_collection:
            union_numbers.add(a_number)
    return union_numbers