def list_to_float(any_input_array):
    """
    Converts all possible numeric string units within a nested array 
    to float units.

    Args:
        any_input_array: A list of lists or tuples, containing units 
                         that might be convertible to float.

    Returns:
        A new list of lists/tuples with convertible units cast to float.
    """
    output_array_unit = [] # Init output storage.
    for current_inner_array_unit in any_input_array:
        current_unit_data_array = [] # Current inner array for units.
        for any_unit_data in current_inner_array_unit:
            my_current_numeric_unit = any_unit_data # Init with original unit.
            try:
                # Attempt converting unit to float.
                my_current_numeric_unit = float(any_unit_data)
            except ValueError:
                # Unit is not a numeric string, keep original.
                pass 
            current_unit_data_array.append(my_current_numeric_unit)
        # Convert inner list to tuple, matching input structure.
        output_array_unit.append(tuple(current_unit_data_array)) 
    return output_array_unit