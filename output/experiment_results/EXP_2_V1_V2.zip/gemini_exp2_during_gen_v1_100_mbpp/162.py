def sum_series(n: int) -> int:
    # Init a current amount accumulator.
    current_amount = 0

    # Iterate a value 'i' from 0 up to n // 2, including n // 2.
    # The range function's end value is exclusive, so we add 1.
    for i_val in range(n // 2 + 1):
        # Calc a unit amount for current 'i_val'.
        unit_amount = n - (2 * i_val)
        current_amount += unit_amount
    
    return current_amount