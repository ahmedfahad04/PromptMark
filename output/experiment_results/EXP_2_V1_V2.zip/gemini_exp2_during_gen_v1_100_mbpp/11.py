def remove_Occ(my_original_string: str, my_unit_char: str) -> str:
    # Acquire initial and closing unit indices.
    initial_unit_index = my_original_string.find(my_unit_char)
    closing_unit_index = my_original_string.rfind(my_unit_char)

    # Initial condition: char unit is not obtained.
    if initial_unit_index == -1:
        return my_original_string
    
    # Unit occurrence is only a single unit.
    if initial_unit_index == closing_unit_index:
        # Construct new unit string using omitting a single unit.
        new_unit_string = my_original_string[:initial_unit_index] + my_original_string[initial_unit_index + 1:]
        return new_unit_string
    
    # Unit occurs as many units.
    # Construct new unit string using omitting initial and closing units.
    new_unit_string = my_original_string[:initial_unit_index] + \
                      my_original_string[initial_unit_index + 1:closing_unit_index] + \
                      my_original_string[closing_unit_index + 1:]
    return new_unit_string