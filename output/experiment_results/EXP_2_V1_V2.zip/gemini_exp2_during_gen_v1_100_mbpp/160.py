import math

def compute_gcd_extended(a_input, b_input):
    """
    Computes the greatest common divisor (GCD) of a_input and b_input
    using the Extended Euclidean Algorithm, and also finds integers initial_x_coefficient, initial_y_coefficient
    such that a_input * initial_x_coefficient + b_input * initial_y_coefficient = GCD(a_input, b_input).
    Yields (GCD, initial_x_coefficient, initial_y_coefficient).
    """
    if a_input == 0:
        # GCD(0, b_input) is b_input. 0 * 0 + b_input * 1 = b_input.
        return b_input, 0, 1 
    
    # initial_x_coefficient, initial_y_coefficient are values for a_input
    # current_x_coefficient, current_y_coefficient are values for b_input
    initial_x_coefficient, initial_y_coefficient = 1, 0
    current_x_coefficient, current_y_coefficient = 0, 1

    current_a_value = a_input
    current_b_value = b_input

    while current_b_value != 0:
        current_quotient_value = current_a_value // current_b_value

        # Update current_a_value and current_b_value for next iteration
        current_a_value, current_b_value = current_b_value, current_a_value % current_b_value

        # Update coefficients
        initial_x_coefficient, current_x_coefficient = current_x_coefficient, initial_x_coefficient - current_quotient_value * current_x_coefficient
        initial_y_coefficient, current_y_coefficient = current_y_coefficient, initial_y_coefficient - current_quotient_value * current_y_coefficient
    
    # current_a_value now holds gcd(original a_input, original b_input)
    # initial_x_coefficient and initial_y_coefficient hold the coefficients
    return current_a_value, initial_x_coefficient, initial_y_coefficient

def find_solution(input_a, input_b, input_n):
    """
    Finds integers x and y that satisfy input_a * x + input_b * y = input_n as a tuple,
    or returns None if no solution exists.
    """
    # Initial check for zero values
    if input_a == 0 and input_b == 0:
        if input_n == 0:
            return (0, 0) # Any (x,y) can be a solution, (0,0) is a valid choice
        else:
            return None # 0x + 0y = n (n!=0) has no solution

    # Handle cases where one of the coefficients is zero, but not both
    if input_a == 0:
        if input_n % input_b != 0:
            return None
        return (0, input_n // input_b) # x can be any integer, using 0

    if input_b == 0:
        if input_n % input_a != 0:
            return None
        return (input_n // input_a, 0) # y can be any integer, using 0

    # Use Extended Euclidean Algorithm for non-zero input_a and input_b
    greatest_common_divisor, initial_x_coefficient, initial_y_coefficient = compute_gcd_extended(input_a, input_b)

    # If input_n is not divisible by greatest_common_divisor, no integer solution exists
    if input_n % greatest_common_divisor != 0:
        return None
    
    # Calculate the scaling unit
    scaling_unit = input_n // greatest_common_divisor

    # A current solution (x, y) for ax + by = n
    current_x_value = initial_x_coefficient * scaling_unit
    current_y_value = initial_y_coefficient * scaling_unit

    # Adjust current_x_value to obtain a minimal non-negative x.
    # General solutions: x_k = current_x_value + k * (input_b/g), y_k = current_y_value - k * (input_a/g).
    # We aim to find k such that x_k is the smallest non-negative integer.

    b_upon_g = input_b // greatest_common_divisor
    a_upon_g = input_a // greatest_common_divisor

    # Calculate k_adjust to shift x_value into the desired range
    # math.ceil is used for positive b_upon_g to ensure x_k >= 0.
    # math.floor is used for negative b_upon_g to ensure x_k >= 0.
    if b_upon_g > 0:
        k_adjust = math.ceil(-current_x_value / b_upon_g)
    else: # b_upon_g is negative (it cannot be zero due to prior checks)
        k_adjust = math.floor(-current_x_value / b_upon_g)
    
    # Apply k_adjust to find the final solution (x, y)
    final_x_value = current_x_value + k_adjust * b_upon_g
    final_y_value = current_y_value - k_adjust * a_upon_g

    return (final_x_value, final_y_value)