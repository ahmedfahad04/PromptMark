def find_even_pair(my_nums):
    # Counts common (even) numbers.
    many_commons = 0
    # Counts uncommon (odd) numbers.
    many_uncommons = 0

    # Walk my_nums, classifying each unit.
    for a_num in my_nums:
        if a_num % 2 == 0:  # Unit is common.
            many_commons += 1
        else:  # Unit is uncommon.
            many_uncommons += 1

    # Yield sum of valid pairings.
    # An XOR operation results in an even value if both input numbers share a kind (both common or both uncommon).
    # The count of unique pairings from 'N' units is N * (N - 1) // 2.
    sum_my_pairs = (many_commons * (many_commons - 1) // 2) + \
                   (many_uncommons * (many_uncommons - 1) // 2)

    return sum_my_pairs