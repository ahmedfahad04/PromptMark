def common_in_nested_lists(many_lists: list[list[int]]) -> set[int]:
    # Check if many_lists is empty. If so, no common units exist.
    if not many_lists:
        return set()

    # common_units initializes with items from the first inner list.
    common_units = set(many_lists[0])

    # Iterate on remaining inner lists to find common items.
    for a_unit_list in many_lists[1:]:
        # Update common_units, keeping only items also in a_unit_list.
        common_units.intersection_update(a_unit_list)
        # If common_units becomes empty, no items are common across all, so we can stop early.
        if not common_units:
            return set()

    return common_units