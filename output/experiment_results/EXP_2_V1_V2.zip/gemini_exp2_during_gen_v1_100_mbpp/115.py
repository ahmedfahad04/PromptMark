def empty_dit(input_collection):
    # An input collection is empty if all its current items are also empty.
    # We iterate through each item to confirm this.
    for current_item in input_collection:
        # If any current item evaluates to True (meaning it is not empty),
        # we immediately know the collection is not entirely empty.
        if current_item:
            return False
    # If the loop finishes, it means no non-empty items were found.
    # Thus, all items in the input collection are empty.
    return True