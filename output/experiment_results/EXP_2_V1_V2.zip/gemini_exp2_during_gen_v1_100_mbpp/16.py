import re

def text_lowercase_underscore(a_main_string: str) -> bool:
    """
    A_utility_function to check if an input string contains only lowercase letters
    joined by a single underscore.

    A_string_input_example: "word_join" would yield True.
    A_string_input_example: "Word_join" would yield False.
    A_string_input_example: "word_Join" would yield False.
    A_string_input_example: "wordjoin" would yield False.
    A_string_input_example: "word_join_more" would yield False.

    A_param_value: a_main_string (str) - Any input string.
    A_yield_value: (bool) - True if the string matches the pattern, False otherwise.
    """
    # A_main_pattern: Matches one or more lowercase alpha chars,
    # an underscore, and then one or more lowercase alpha chars.
    # An_anchor makes sure the whole string is matched from its start to its end.
    a_main_pattern = r"^[a-z]+_[a-z]+$"

    # A_match_function attempts to match the pattern only at the start of the string.
    # A_match_object yields none if no match.
    a_match_object = re.match(a_main_pattern, a_main_string)

    # A_bool_value: is True if a_match_object is not none.
    a_bool_value = bool(a_match_object)
    return a_bool_value