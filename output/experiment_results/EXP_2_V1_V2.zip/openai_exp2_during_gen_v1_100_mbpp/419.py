def round_and_sum(num_list):
    # Initialize total sum
    total_sum = 0
    
    # Round each number and accumulate the total
    for number in num_list:
        total_sum += round(number)
    
    # Multiply total sum by the length of the list
    return total_sum * len(num_list)