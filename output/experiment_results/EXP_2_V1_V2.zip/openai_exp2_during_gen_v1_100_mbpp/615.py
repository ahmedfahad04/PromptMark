def average_tuple(tuples):
    # Initialize a list to store average values
    averages = []
    
    # Iterate through each tuple in the input
    for t in tuples:
        # Calculate the average for the current tuple
        avg = sum(t) / len(t)
        # Append the average to the list
        averages.append(avg)
    
    return averages