def intersection_array(array_one, array_two):
    # Create a set for quick lookup
    set_one = set(array_one)
    # Initialize a list to hold the intersection results
    intersection_results = []
    
    # Iterate through the second array
    for item in array_two:
        # Check if the item exists in the first array's set
        if item in set_one:
            intersection_results.append(item)
    
    return intersection_results