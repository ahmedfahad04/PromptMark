def empty_dit(kit):
    # Check if all dictionaries in the list are empty
    for item in kit:
        if isinstance(item, dict) and item:  # Check if item is a non-empty dictionary
            return False
    return True