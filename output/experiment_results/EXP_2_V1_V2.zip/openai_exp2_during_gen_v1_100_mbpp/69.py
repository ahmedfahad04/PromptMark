def is_sublist(main_list, sub_list):
    # Get the length of the sublist
    sub_length = len(sub_list)
    
    # Iterate through the main list
    for index in range(len(main_list) - sub_length + 1):
        # Check if the sublist matches the slice of the main list
        if main_list[index:index + sub_length] == sub_list:
            return True
            
    return False