def Find_Min(list_of_lists):
    # Initialize minimum length and corresponding sublist
    min_length = float('inf')
    min_sublist = []

    for sublist in list_of_lists:
        # Check if current sublist is shorter than the minimum found so far
        if len(sublist) < min_length:
            min_length = len(sublist)
            min_sublist = sublist

    return min_sublist