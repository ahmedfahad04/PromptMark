def even_Power_Sum(n):
    sum_result = 0  # Initialize the sum of powers
    for index in range(1, n + 1):  # Iterate through the first n even numbers
        even_number = 2 * index  # Calculate the even number
        sum_result += even_number ** 5  # Add the fifth power of the even number to the sum
    return sum_result  # Return the final sum