def extract_quotation(input_string):
    # Initialize a list to store extracted values
    extracted_values = []
    # Variable to track if we are inside quotation marks
    in_quotes = False
    # Variable to hold the current value being built
    current_value = ""

    for char in input_string:
        if char == '"':
            # Toggle the in_quotes flag
            if in_quotes:
                # If we are closing a quote, add the current value to the list
                extracted_values.append(current_value)
                current_value = ""
            in_quotes = not in_quotes
        elif in_quotes:
            # If we are inside quotes, build the current value
            current_value += char

    return extracted_values