def tuple_intersection(given_tuples, compare_tuples):
    # Create a set for fast lookup of tuples from the first list
    green_set = {tuple(sorted(t)) for t in given_tuples}
    intersection = set()

    # Check each tuple in the second list
    for t in compare_tuples:
        sorted_tuple = tuple(sorted(t))
        if sorted_tuple in green_set:
            intersection.add(sorted_tuple)

    return intersection