def find(numerator, denominator):
    # Calculate quotient by performing integer division
    return numerator // denominator