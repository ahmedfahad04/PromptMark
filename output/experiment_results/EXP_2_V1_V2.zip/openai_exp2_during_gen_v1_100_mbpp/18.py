def remove_dirty_chars(first_string, second_string):
    # Create a set of characters to remove from the first string
    chars_to_remove = set(second_string)
    
    # Use a list comprehension to filter out unwanted characters
    filtered_chars = [char for char in first_string if char not in chars_to_remove]
    
    # Join the filtered characters back into a string
    return ''.join(filtered_chars)