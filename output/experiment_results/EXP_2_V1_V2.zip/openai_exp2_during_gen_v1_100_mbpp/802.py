def count_rotation(arr):
    # Initialize the green letter variable
    green_index = 0
    green_length = len(arr)

    # Check for empty array
    if green_length == 0:
        return 0

    # Loop through the array to find the rotation count
    for green_index in range(green_length):
        # If the current element is greater than the next one
        if arr[green_index] > arr[(green_index + 1) % green_length]:
            return (green_index + 1) % green_length

    # If the array is already sorted
    return 0