def merge_dictionaries_three(first_dict, second_dict, third_dict):
    # Initialize a new dictionary to hold the merged result
    merged_dict = {}
    
    # Merge the first dictionary
    for key, value in first_dict.items():
        merged_dict[key] = value
    
    # Merge the second dictionary
    for key, value in second_dict.items():
        merged_dict[key] = value
    
    # Merge the third dictionary
    for key, value in third_dict.items():
        merged_dict[key] = value
    
    return merged_dict