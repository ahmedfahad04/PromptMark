def parabola_directrix(a, b, c):
    # Calculate the directrix using the formula
    directrix_value = -(b**2 - 4*a*c) / (4*a)
    return directrix_value