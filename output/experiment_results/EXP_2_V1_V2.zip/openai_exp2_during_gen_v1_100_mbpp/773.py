def occurance_substring(input_string, search_substring):
    # Initialize variables to track the position
    start_index = input_string.find(search_substring)
    
    # Check if the substring is found
    if start_index == -1:
        return None
    
    # Calculate the end index of the substring
    end_index = start_index + len(search_substring)
    
    # Return the result as a tuple
    return (search_substring, start_index, end_index)