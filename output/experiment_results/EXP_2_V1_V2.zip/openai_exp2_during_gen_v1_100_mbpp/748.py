def capital_words_spaces(input_string):
    # Initialize an empty string to hold the result
    result_string = ""
    
    # Iterate through each character in the input string
    for index, char in enumerate(input_string):
        # If the character is uppercase and it's not the first character, add a space before it
        if char.isupper() and index > 0:
            result_string += " "
        # Append the current character to the result string
        result_string += char
    
    return result_string