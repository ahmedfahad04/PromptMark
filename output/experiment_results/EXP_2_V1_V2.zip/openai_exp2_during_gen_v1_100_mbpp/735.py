def toggle_middle_bits(num):
    # Convert number to binary string
    binary_str = bin(num)[2:]  # Skip the '0b' prefix
    length = len(binary_str)

    # If there are less than 3 bits, return the number as is
    if length <= 2:
        return num

    # Toggle bits except the first and last
    middle_bits = list(binary_str[1:-1])  # Get middle bits
    for index in range(len(middle_bits)):
        middle_bits[index] = '1' if middle_bits[index] == '0' else '0'  # Toggle bit

    # Construct the new binary string
    new_binary_str = binary_str[0] + ''.join(middle_bits) + binary_str[-1]
    
    # Convert back to integer
    return int(new_binary_str, 2)