def list_tuple(input_list):
    # Convert the given list to a tuple
    return tuple(input_list)