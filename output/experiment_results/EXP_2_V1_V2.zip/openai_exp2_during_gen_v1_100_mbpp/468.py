def max_product(arr):
    if not arr:
        return 0
    
    n = len(arr)
    max_prod = [0] * n
    
    for i in range(n):
        max_prod[i] = arr[i]  # Initialize with the current element
    
    for i in range(1, n):
        for j in range(i):
            if arr[i] > arr[j]:  # Check for increasing subsequence
                max_prod[i] = max(max_prod[i], max_prod[j] * arr[i])
    
    return max(max_prod)