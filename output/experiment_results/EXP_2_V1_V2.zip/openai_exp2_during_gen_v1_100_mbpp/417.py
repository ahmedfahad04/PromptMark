def group_tuples(tuples_list):
    # Initialize a dictionary to group tuples by their first element
    common_dict = {}
    
    for current_tuple in tuples_list:
        first_element = current_tuple[0]
        
        # Group tuples by their first element
        if first_element not in common_dict:
            common_dict[first_element] = []
        common_dict[first_element].append(current_tuple[1])
    
    # Create a list to hold the result
    result = []
    
    for key, values in common_dict.items():
        # Combine the first element with the grouped second elements
        combined_tuple = (key,) + tuple(values)
        result.append(combined_tuple)
    
    return result