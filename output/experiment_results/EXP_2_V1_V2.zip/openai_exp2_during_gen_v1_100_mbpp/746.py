import math

def sector_area(radius, angle):
    # Check if angle is larger than 360 degrees
    if angle > 360:
        return None
    
    # Calculate area of the sector
    area = (angle / 360) * math.pi * (radius ** 2)
    return area