import math

def surface_Area(base_edge, height):
    # Calculate the slant height
    slant_height = math.sqrt(height**2 + (base_edge / 2)**2)
    # Calculate the surface area
    surface_area = base_edge**2 + 2 * base_edge * slant_height
    return surface_area