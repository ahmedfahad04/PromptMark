def find_first_occurrence(sorted_array, target):
    index = -1  # Initialize index to -1 to indicate not found
    for current_index in range(len(sorted_array)):
        if sorted_array[current_index] == target:
            index = current_index  # Update index on first match
            break  # Exit loop after finding the first occurrence
    return index