def remove_Occ(input_string, char_to_remove):
    # Find the first and last occurrence of the character
    first_index = input_string.find(char_to_remove)
    last_index = input_string.rfind(char_to_remove)

    # If the character is not found or both indices are the same, return the string without that character
    if first_index == -1 or first_index == last_index:
        return input_string.replace(char_to_remove, "", 1)

    # Create a new string without the first and last occurrence of the character
    modified_string = input_string[:first_index] + input_string[first_index + 1:last_index] + input_string[last_index + 1:]
    
    return modified_string