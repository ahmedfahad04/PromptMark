import math

def polar_rect(radius, angle):
    # Calculate rectangular coordinates
    x = radius * math.cos(angle)
    y = radius * math.sin(angle)
    
    # Return the tuple of rectangular coordinates and complex representation
    return (x, y), complex(x, y)