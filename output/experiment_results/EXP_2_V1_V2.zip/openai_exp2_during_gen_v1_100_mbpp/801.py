def test_three_equal(num_one, num_two, num_three):
    equal_count = 0
    
    if num_one == num_two:
        equal_count += 1
    if num_one == num_three:
        equal_count += 1
    if num_two == num_three:
        equal_count += 1
    
    # If all three numbers are equal, count them as three
    if equal_count == 3:
        return 3
    # If two numbers are equal, count them as two
    elif equal_count == 1:
        return 2
    # If no numbers are equal
    return 0