def find_solution(a, b, n):
    # Iterate over possible values for x
    for x in range(n // a + 1):
        # Calculate the remaining value for y
        remaining = n - a * x
        if remaining % b == 0:
            y = remaining // b
            return (x, y)
    return None