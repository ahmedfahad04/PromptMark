def find_Max_Num(digits):
    # Convert digits to strings for sorting
    str_digits = list(map(str, digits))
    # Sort digits based on custom logic to form the largest number
    str_digits.sort(key=lambda x: x * 10, reverse=True)
    # Join sorted digits and convert back to an integer
    max_num = int(''.join(str_digits))
    return max_num