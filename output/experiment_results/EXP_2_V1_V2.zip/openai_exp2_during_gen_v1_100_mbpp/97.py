def frequency_lists(nested_list):
    # Initialize a dictionary to hold the frequency of each element
    frequency_dict = {}
    
    # Iterate through each sublist in the nested list
    for sublist in nested_list:
        # Iterate through each element in the sublist
        for element in sublist:
            # Update the frequency count for each element
            if element in frequency_dict:
                frequency_dict[element] += 1
            else:
                frequency_dict[element] = 1
                
    return frequency_dict