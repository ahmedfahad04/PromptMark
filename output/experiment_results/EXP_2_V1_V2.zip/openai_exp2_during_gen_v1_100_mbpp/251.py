def insert_element(ku_list, ku_element):
    ku_result = []  # Initialize an empty list to store the result
    for ku_item in ku_list:  # Iterate through each item in the input list
        ku_result.append(ku_element)  # Append the element before the current item
        ku_result.append(ku_item)  # Append the current item
    return ku_result  # Return the modified list