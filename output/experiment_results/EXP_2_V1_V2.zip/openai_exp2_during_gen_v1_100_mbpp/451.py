def remove_whitespaces(input_string):
    # Create a new string without whitespaces
    cleaned_string = ''
    for char in input_string:
        if char not in ' ':
            cleaned_string += char
    return cleaned_string