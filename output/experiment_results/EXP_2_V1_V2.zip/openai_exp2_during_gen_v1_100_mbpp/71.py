def comb_sort(input_list):
    gap = len(input_list)
    shrink = 1.3
    sorted_flag = False

    while not sorted_flag:
        gap = max(1, int(gap / shrink))
        sorted_flag = True
        
        for index in range(len(input_list) - gap):
            if input_list[index] > input_list[index + gap]:
                input_list[index], input_list[index + gap] = input_list[index + gap], input_list[index]
                sorted_flag = False
                
    return input_list