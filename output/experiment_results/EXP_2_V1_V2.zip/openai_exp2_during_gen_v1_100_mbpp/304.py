def find_Element(array, rotations, index, count):
    # Calculate the number of elements
    size = len(array)
    
    # Perform the rotations
    for rotation in rotations:
        start, end = rotation
        # Slice the array for rotation
        rotated_part = array[start:end + 1]
        array[start:end + 1] = rotated_part[-count:] + rotated_part[:-count]
    
    # Return the element at the specified index
    return array[index]