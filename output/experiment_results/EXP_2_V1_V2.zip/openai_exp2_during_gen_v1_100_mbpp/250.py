def count_X(input_tuple, element):
    # Initialize a counter for occurrences
    occurrence_count = 0
    
    # Iterate through each item in the tuple
    for item in input_tuple:
        # Increment count if the item matches the element
        if item == element:
            occurrence_count += 1
            
    return occurrence_count