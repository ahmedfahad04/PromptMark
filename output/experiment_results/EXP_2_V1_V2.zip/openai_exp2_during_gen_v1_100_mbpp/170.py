def sum_range_list(num_list, start_index, end_index):
    # Initialize the sum variable
    total_sum = 0
    
    # Iterate over the specified range in the list
    for index in range(start_index, end_index + 1):
        total_sum += num_list[index]
    
    return total_sum