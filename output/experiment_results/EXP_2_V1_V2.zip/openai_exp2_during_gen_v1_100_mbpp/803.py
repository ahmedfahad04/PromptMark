def is_perfect_square(num):
    if num < 0:  # Negative numbers cannot be perfect squares
        return False
    
    # Initialize the variable for the square root check
    guess = 0
    
    # Increment guess until the square exceeds num
    while guess * guess < num:
        guess += 1
    
    # Check if the square of guess equals num
    return guess * guess == num