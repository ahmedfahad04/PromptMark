def check_element(item_list, element):
    # Verify if all items in the list match the given element
    for item in item_list:
        if item != element:
            return False
    return True