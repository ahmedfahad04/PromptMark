def extract_singly(nested_list):
    unique_numbers = set()  # Initialize a set to hold unique numbers
    for inner_list in nested_list:  # Iterate through each inner list
        for number in inner_list:  # Iterate through each number in the inner list
            unique_numbers.add(number)  # Add the number to the set
    return unique_numbers  # Return the set of unique numbers