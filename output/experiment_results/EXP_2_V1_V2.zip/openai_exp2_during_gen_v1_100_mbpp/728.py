def sum_list(a_list, b_list):
    # Initialize an empty list to store the sums
    sum_list = []
    
    # Iterate through both lists using their indices
    for index in range(len(a_list)):
        # Calculate the sum of corresponding elements
        sum_value = a_list[index] + b_list[index]
        # Append the sum to the result list
        sum_list.append(sum_value)
    
    return sum_list