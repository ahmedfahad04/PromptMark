def check_value(dict_input, value_check):
    # Gather values from the dictionary
    value_list = list(dict_input.values())
    
    # Check if all values are the same as the value_check
    return all(value == value_check for value in value_list)