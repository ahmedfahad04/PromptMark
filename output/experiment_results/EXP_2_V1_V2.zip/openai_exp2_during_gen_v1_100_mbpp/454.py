def text_match_wordz(input_text):
    # Check if 'z' is present in the input text
    return 'z' in input_text