def extract_nth_element(tuples_list, n):
    # Create a list to hold the nth elements
    nth_elements = []
    
    # Iterate through each tuple in the list
    for item in tuples_list:
        # Append the nth element of the tuple to the list
        nth_elements.append(item[n])
    
    return nth_elements