def power(base, exponent):
    # Initialize result variable
    result = 1
    # Calculate base raised to the power of exponent
    for _ in range(exponent):
        result *= base
    return result