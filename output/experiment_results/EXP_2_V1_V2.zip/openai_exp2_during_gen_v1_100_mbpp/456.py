def reverse_string_list(string_list):
    # Create a list to hold reversed strings
    reversed_list = []
    
    # Iterate through each string in the input list
    for string in string_list:
        # Reverse the current string and add it to the reversed list
        reversed_list.append(string[::-1])
    
    return reversed_list