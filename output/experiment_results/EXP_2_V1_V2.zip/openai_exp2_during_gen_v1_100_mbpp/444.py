def trim_tuple(tuple_list, k):
    # Create a list to hold the trimmed tuples
    trimmed_list = []
    
    # Iterate through each tuple in the input list
    for current_tuple in tuple_list:
        # Trim the current tuple by k elements from the start
        trimmed_tuple = current_tuple[k:]  # Slice the tuple from index k to the end
        trimmed_list.append(trimmed_tuple)  # Append the trimmed tuple to the list
    
    return trimmed_list  # Return the list of trimmed tuples