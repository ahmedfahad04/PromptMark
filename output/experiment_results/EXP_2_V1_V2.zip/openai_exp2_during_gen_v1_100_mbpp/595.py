def min_Swaps(first: str, second: str) -> int or str:
    # Check if the counts of '1's and '0's are the same in both strings
    if first.count('1') != second.count('1') or first.count('0') != second.count('0'):
        return "Not Possible"

    # Initialize counters for mismatched positions
    mismatched_one = 0
    mismatched_zero = 0

    # Iterate through both strings to count mismatches
    for index in range(len(first)):
        if first[index] == '1' and second[index] == '0':
            mismatched_one += 1
        elif first[index] == '0' and second[index] == '1':
            mismatched_zero += 1

    # The minimum number of swaps needed is the maximum of the mismatches
    return max(mismatched_one, mismatched_zero)