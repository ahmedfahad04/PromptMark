def union_elements(first_tuple, second_tuple):
    # Create a set to hold unique elements from both tuples
    unique_elements = set(first_tuple) | set(second_tuple)
    # Sort the unique elements and return as a tuple
    return tuple(sorted(unique_elements))