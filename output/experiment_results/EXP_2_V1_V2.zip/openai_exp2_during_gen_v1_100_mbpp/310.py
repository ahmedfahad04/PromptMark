def string_to_tuple(input_string):
    # Create a tuple from the input string by converting each character
    char_tuple = tuple(input_string)
    return char_tuple