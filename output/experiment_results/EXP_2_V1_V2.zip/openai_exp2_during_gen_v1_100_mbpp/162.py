def sum_series(n):
    total_sum = 0  # Initialize the total sum
    for i in range(n // 2 + 1):  # Iterate from 0 to n // 2
        current_value = n - 2 * i  # Calculate the current value
        if current_value > 0:  # Only add positive values
            total_sum += current_value  # Accumulate the sum
    return total_sum  # Return the final sum