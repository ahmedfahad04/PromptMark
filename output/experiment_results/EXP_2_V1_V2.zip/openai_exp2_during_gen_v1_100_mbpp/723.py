def count_same_pair(list_a, list_b):
    same_count = 0  # Initialize count of same indices
    for index in range(len(list_a)):  # Iterate through each index
        if list_a[index] == list_b[index]:  # Check if values are the same
            same_count += 1  # Increment count if they match
    return same_count  # Return the total count