def unique_product(num_list):
    unique_nums = set(num_list)  # Create a set to hold unique numbers
    product = 1  # Initialize product variable

    for num in unique_nums:  # Iterate through unique numbers
        product *= num  # Multiply each unique number to the product

    return product  # Return the final product