def sum_even_and_even_index(num_list):
    sum_value = 0  # Initialize the sum of even numbers at even positions
    for index in range(len(num_list)):
        if index % 2 == 0 and num_list[index] % 2 == 0:  # Check for even index and even number
            sum_value += num_list[index]  # Add to sum if both conditions are met
    return sum_value  # Return the final sum