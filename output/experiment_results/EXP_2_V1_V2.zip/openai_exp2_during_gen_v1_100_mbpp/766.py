def pair_wise(input_list):
    # Initialize an empty list to store pairs
    output_pairs = []
    
    # Iterate through the input list to form pairs
    for index in range(len(input_list) - 1):
        # Create a tuple of consecutive items
        output_pairs.append((input_list[index], input_list[index + 1]))
    
    return output_pairs