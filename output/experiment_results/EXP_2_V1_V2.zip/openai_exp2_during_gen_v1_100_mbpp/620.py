def largest_subset(numbers):
    # Sort the numbers to facilitate the subset finding
    sorted_numbers = sorted(numbers)
    size = len(sorted_numbers)
    
    # Create an array to hold the maximum size of divisible subsets
    max_subset_size = [1] * size
    
    # Iterate through the sorted list to find the largest subset
    for index in range(size):
        for j in range(index):
            if sorted_numbers[index] % sorted_numbers[j] == 0:
                max_subset_size[index] = max(max_subset_size[index], max_subset_size[j] + 1)
    
    # Return the maximum size found
    return max(max_subset_size)