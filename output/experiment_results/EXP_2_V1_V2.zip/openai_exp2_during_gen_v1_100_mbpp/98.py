def multiply_num(num_list):
    # Initialize product with 1 since it's a neutral element for multiplication
    product = 1
    # Iterate through each number in the list
    for number in num_list:
        product *= number  # Multiply each number to the product
    # Calculate the length of the list
    length = len(num_list)
    # Divide the product by the length of the list
    return product / length