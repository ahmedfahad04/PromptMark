def extract_string(string_list, size):
    # Create a list to hold strings that match the specified size
    matched_strings = []
    
    # Iterate through each string in the provided list
    for string in string_list:
        # Check if the length of the string matches the specified size
        if len(string) == size:
            matched_strings.append(string)
    
    return matched_strings