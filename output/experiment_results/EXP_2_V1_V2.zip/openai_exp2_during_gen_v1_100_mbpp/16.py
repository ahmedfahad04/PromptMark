def text_lowercase_underscore(input_string):
    # Check if the string matches the pattern of lowercase letters separated by underscores
    green_pattern = input_string.replace('_', '')
    return green_pattern.islower() and '_' in input_string