def find_adverbs(input_string):
    # Initialize a list to keep track of words and their positions
    word_positions = []
    
    # Split the input string into words
    words = input_string.split()
    
    # Iterate through the words to find adverbs
    for index, word in enumerate(words):
        # Check if the word ends with 'ly'
        if word.endswith('ly'):
            # Calculate the starting position of the word in the input string
            start_position = input_string.find(word)
            # Create the result string with position and word
            result = f"{start_position}-{start_position + len(word)}: {word}"
            return result
    
    # Return None if no adverb is found
    return None