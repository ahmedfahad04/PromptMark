def mul_even_odd(num_list):
    first_even = None
    first_odd = None
    
    for number in num_list:
        if first_even is None and number % 2 == 0:
            first_even = number
        if first_odd is None and number % 2 != 0:
            first_odd = number
        
        # Break if both numbers are found
        if first_even is not None and first_odd is not None:
            break
    
    # Return the product of the first even and first odd numbers
    return first_even * first_odd if first_even is not None and first_odd is not None else None