def find_First_Missing(sorted_numbers):
    # Initialize the smallest missing number as 0
    smallest_missing = 0
    
    # Iterate through the sorted list
    for number in sorted_numbers:
        # If the current number is equal to the smallest missing number
        if number == smallest_missing:
            # Increment to check the next number
            smallest_missing += 1
            
    return smallest_missing