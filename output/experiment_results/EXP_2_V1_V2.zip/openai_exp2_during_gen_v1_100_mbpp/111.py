def common_in_nested_lists(nested_lists):
    # Initialize common set with elements from the first list
    common_set = set(nested_lists[0])
    
    # Iterate through the remaining lists
    for current_list in nested_lists[1:]:
        # Update common_set to keep only elements present in both sets
        common_set.intersection_update(current_list)
    
    return list(common_set)