def find_lucas(n):
    # Initialize the first two Lucas numbers
    if n == 0:
        return 2
    elif n == 1:
        return 1
    
    # Use variables to store previous Lucas numbers
    previous = 2
    current = 1
    
    # Calculate the nth Lucas number
    for i in range(2, n + 1):
        next_lucas = previous + current
        previous = current
        current = next_lucas
    
    return current