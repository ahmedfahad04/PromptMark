def count_divisors(num):
    count = 0  # Initialize count of divisors
    for i in range(1, num + 1):
        if num % i == 0:  # Check if i is a divisor of num
            count += 1  # Increment count for each divisor
    return count % 2 == 0  # Return True if count of divisors is even