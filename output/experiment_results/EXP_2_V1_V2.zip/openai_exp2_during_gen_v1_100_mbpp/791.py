def remove_nested(input_tuple):
    # Create a new tuple with only non-tuple elements
    output_tuple = tuple(item for item in input_tuple if not isinstance(item, tuple))
    return output_tuple