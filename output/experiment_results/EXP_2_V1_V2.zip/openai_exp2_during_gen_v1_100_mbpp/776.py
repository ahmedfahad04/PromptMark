def count_vowels(input_string):
    # Initialize the count of characters with vowel neighbors
    count = 0
    # Define a set of vowels for easy checking
    vowels = {'a', 'e', 'i', 'o', 'u'}

    # Iterate through the string, checking each character
    for index in range(len(input_string)):
        # Check if the current character has a vowel neighbor
        if (index > 0 and input_string[index - 1] in vowels) or (index < len(input_string) - 1 and input_string[index + 1] in vowels):
            count += 1
            
    return count