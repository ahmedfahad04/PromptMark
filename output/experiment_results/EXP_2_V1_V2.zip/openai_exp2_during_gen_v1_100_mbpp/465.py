def drop_empty(dict_input):
    # Create a new dictionary to hold non-empty items
    valid_dict = {}
    
    # Iterate over items in the input dictionary
    for key, value in dict_input.items():
        # Check if the value is not None
        if value is not None:
            valid_dict[key] = value
            
    return valid_dict