def and_tuples(first_tuple, second_tuple):
    # Create a list to hold the results
    result_list = []
    
    # Iterate through both tuples simultaneously
    for first_value, second_value in zip(first_tuple, second_tuple):
        # Calculate the elementwise AND operation
        result_list.append(first_value & second_value)
    
    # Convert the list to a tuple before returning
    return tuple(result_list)