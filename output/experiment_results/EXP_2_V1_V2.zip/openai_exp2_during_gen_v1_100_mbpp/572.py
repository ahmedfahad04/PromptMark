def two_unique_nums(num_list):
    unique_nums = []  # List to hold unique numbers
    count_dict = {}   # Dictionary to count occurrences of each number

    for num in num_list:
        if num in count_dict:
            count_dict[num] += 1  # Increment count if number is already seen
        else:
            count_dict[num] = 1    # Initialize count for new number

    for num in num_list:
        if count_dict[num] == 1:  # Check for unique numbers
            unique_nums.append(num)  # Add unique number to the result list

    return unique_nums  # Return the list of unique numbers