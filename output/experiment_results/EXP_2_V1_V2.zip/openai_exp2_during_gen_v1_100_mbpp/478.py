def remove_lowercase(input_string):
    # Initialize an empty string to collect uppercase characters
    upper_string = ''
    
    # Iterate through each character in the input string
    for char in input_string:
        # Check if the character is uppercase
        if char.isupper():
            upper_string += char  # Add uppercase character to the result
    
    return upper_string  # Return the final string with only uppercase characters