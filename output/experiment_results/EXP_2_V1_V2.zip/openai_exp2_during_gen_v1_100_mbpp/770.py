def odd_num_sum(n):
    # Initialize the sum variable
    sum_of_powers = 0
    
    # Iterate through the first n odd natural numbers
    for i in range(n):
        odd_number = 2 * i + 1  # Generate the i-th odd number
        sum_of_powers += odd_number ** 4  # Add the fourth power of the odd number to the sum
    
    return sum_of_powers