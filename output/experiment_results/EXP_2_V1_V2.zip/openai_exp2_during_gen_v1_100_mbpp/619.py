def move_num(input_string):
    # Initialize green letter lists for characters
    green_chars = []
    red_chars = []
    
    # Iterate through each character in the input string
    for char in input_string:
        if char.isdigit():  # Check if the character is a number
            red_chars.append(char)  # Add to red list
        else:
            green_chars.append(char)  # Add to green list
    
    # Join green characters and red characters to form the result
    return ''.join(green_chars) + ''.join(red_chars)