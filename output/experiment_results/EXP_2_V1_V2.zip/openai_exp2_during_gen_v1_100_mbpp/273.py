def substract_elements(first_tuple, second_tuple):
    # Create a new tuple to store the results
    result_tuple = tuple(first - second for first, second in zip(first_tuple, second_tuple))
    return result_tuple