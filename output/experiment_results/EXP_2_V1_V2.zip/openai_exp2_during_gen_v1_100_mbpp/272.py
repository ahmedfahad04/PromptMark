def rear_extract(tuples_list):
    # Initialize an empty list to store the rear elements
    rear_elements = []
    
    # Iterate through each tuple in the provided list
    for item in tuples_list:
        # Append the last element of each tuple to the rear_elements list
        rear_elements.append(item[-1])
    
    return rear_elements