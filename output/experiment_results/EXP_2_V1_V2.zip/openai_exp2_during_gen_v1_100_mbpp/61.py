def count_Substrings(input_string):
    count = 0  # Initialize count of valid substrings
    length = len(input_string)  # Get the length of the input string

    for start in range(length):  # Iterate over starting indices
        sum_digits = 0  # Initialize sum of digits for each starting index
        for end in range(start, length):  # Iterate over ending indices
            sum_digits += int(input_string[end])  # Add digit to sum
            if sum_digits == (end - start + 1):  # Check if sum equals length
                count += 1  # Increment count if condition is met

    return count  # Return the total count of valid substrings