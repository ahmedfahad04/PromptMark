def subject_marks(marks_list):
    # Sort the list of tuples by the second value in each tuple
    return sorted(marks_list, key=lambda item: item[1])