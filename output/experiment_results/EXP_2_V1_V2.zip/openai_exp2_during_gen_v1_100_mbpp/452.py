def loss_amount(original_price, selling_price):
    # Check if there is a loss
    if selling_price < original_price:
        return original_price - selling_price  # Calculate loss
    return 0  # No loss