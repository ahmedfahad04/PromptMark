def swap_List(input_list):
    # Check if the list has at least two elements to swap
    if len(input_list) < 2:
        return input_list
    
    # Interchange the first and last elements
    input_list[0], input_list[-1] = input_list[-1], input_list[0]
    
    return input_list