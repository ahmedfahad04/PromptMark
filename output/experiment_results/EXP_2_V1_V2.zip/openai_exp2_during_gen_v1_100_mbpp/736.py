def left_insertion(sorted_list, value):
    # Initialize index for insertion point
    index = 0
    
    # Iterate through the sorted list
    while index < len(sorted_list) and sorted_list[index] < value:
        index += 1
        
    return index