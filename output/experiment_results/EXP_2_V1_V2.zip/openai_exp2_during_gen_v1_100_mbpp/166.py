def find_even_pair(int_list):
    count = 0  # Initialize count of pairs
    length = len(int_list)  # Get the length of the list
    
    for index_a in range(length):  # Iterate through the list
        for index_b in range(index_a + 1, length):  # Check pairs
            if (int_list[index_a] ^ int_list[index_b]) % 2 == 0:  # Check if XOR is even
                count += 1  # Increment count if condition is met
                
    return count  # Return the total count of pairs