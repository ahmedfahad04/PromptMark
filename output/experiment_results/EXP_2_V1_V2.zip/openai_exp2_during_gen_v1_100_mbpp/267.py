def square_Sum(n):
    # Initialize sum variable
    sum_of_squares = 0
    # Iterate through the first n odd natural numbers
    for i in range(n):
        odd_number = 2 * i + 1  # Generate the i-th odd number
        sum_of_squares += odd_number ** 2  # Add the square of the odd number to the sum
    return sum_of_squares