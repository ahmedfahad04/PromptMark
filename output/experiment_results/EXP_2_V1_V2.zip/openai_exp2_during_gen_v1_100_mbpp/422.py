def find_Average_Of_Cube(n):
    sum_of_cubes = 0  # Initialize sum of cubes
    for i in range(1, n + 1):  # Iterate through first n natural numbers
        sum_of_cubes += i ** 3  # Calculate cube and add to sum
    average = sum_of_cubes / n  # Calculate average
    return average  # Return the average of cubes