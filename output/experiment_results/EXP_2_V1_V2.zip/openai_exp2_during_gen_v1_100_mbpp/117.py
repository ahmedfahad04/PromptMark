def list_to_float(input_list):
    # Convert each element in the list of lists to float if possible
    output_list = []
    for inner_list in input_list:
        float_tuple = tuple(float(item) for item in inner_list)
        output_list.append(float_tuple)
    return output_list