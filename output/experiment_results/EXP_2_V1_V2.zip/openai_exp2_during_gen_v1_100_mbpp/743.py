def rotate_right(item_list, n):
    # Ensure n is within the bounds of the list length
    n = n % len(item_list) if item_list else 0
    if n == 0:
        return item_list
    
    # Split and combine the list for rotation
    return item_list[-n:] + item_list[:-n]