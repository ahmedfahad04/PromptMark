def square_nums(nums):
    # Create a list to hold the squares
    squares = []
    for num in nums:
        # Calculate the square and append to the list
        squares.append(num * num)
    return squares