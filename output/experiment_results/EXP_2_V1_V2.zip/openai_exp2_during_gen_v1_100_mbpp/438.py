def count_bidirectional(pairs):
    unique_pairs = set()  # Set to track unique bidirectional pairs
    count = 0  # Initialize count of bidirectional pairs

    for pair in pairs:
        # Create a sorted tuple to ensure (a, b) and (b, a) are treated the same
        sorted_pair = tuple(sorted(pair))
        if sorted_pair not in unique_pairs:
            unique_pairs.add(sorted_pair)  # Add the sorted pair to the set
            count += 1  # Increment count for each unique pair

    return count * 2  # Each unique pair can be counted in both directions