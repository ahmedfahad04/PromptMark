def merge(list_of_lists):
    first_elements = []  # List to store the first elements
    second_elements = []  # List to store the second elements
    
    for sublist in list_of_lists:  # Iterate through each sublist
        if len(sublist) >= 2:  # Ensure the sublist has at least two elements
            first_elements.append(sublist[0])  # Append the first element
            second_elements.append(sublist[1])  # Append the second element
            
    return [first_elements, second_elements]  # Return the two lists