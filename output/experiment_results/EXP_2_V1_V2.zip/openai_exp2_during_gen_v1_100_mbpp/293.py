import math

def otherside_rightangle(side_a, side_b):
    # Calculate the length of the third side using the Pythagorean theorem
    return math.sqrt(side_a**2 + side_b**2)