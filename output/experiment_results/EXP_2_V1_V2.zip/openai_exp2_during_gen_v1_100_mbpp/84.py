def sequence(n):
    # Initialize an array to hold the sequence values
    arr = [0] * (n + 1)
    
    # Base cases
    arr[1] = 1
    if n > 1:
        arr[2] = 1
    
    # Fill the array using the Newman-Conway rule
    for i in range(3, n + 1):
        arr[i] = arr[arr[i - 1]] + arr[i - arr[i - 1]]
    
    return arr[n]