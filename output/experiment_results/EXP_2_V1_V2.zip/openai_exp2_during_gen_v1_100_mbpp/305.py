def start_withp(word_list):
    # Initialize a list to collect words starting with 'p'
    collected_words = []
    
    # Iterate through each phrase in the provided list
    for phrase in word_list:
        # Split the phrase into individual words
        words = phrase.split()
        
        # Check each word in the phrase
        for word in words:
            # If the word starts with 'P', add it to the collected list
            if word.startswith('P'):
                collected_words.append(word)
                
            # Stop if we have collected two words
            if len(collected_words) == 2:
                return tuple(collected_words)
    
    # Return an empty tuple if less than two words are found
    return ()