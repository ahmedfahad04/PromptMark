def replace_char(input_string, old_char, new_char):
    # Create a new string with replaced characters
    updated_string = ''
    for char in input_string:
        if char == old_char:
            updated_string += new_char
        else:
            updated_string += char
    return updated_string