def Find_Max_Length(nested_list):
    max_length = 0  # Initialize maximum length variable

    for sublist in nested_list:  # Iterate through each sublist
        current_length = len(sublist)  # Get the length of the current sublist
        if current_length > max_length:  # Check if current length is greater than max
            max_length = current_length  # Update max length if necessary

    return max_length  # Return the maximum length found