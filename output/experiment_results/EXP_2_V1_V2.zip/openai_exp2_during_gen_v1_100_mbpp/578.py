def interleave_lists(first_list, second_list, third_list):
    # Create an empty list to hold the interleaved result
    interleaved_list = []
    
    # Iterate through the indices of the lists
    for index in range(len(first_list)):
        # Append elements from each list in order
        interleaved_list.append(first_list[index])
        interleaved_list.append(second_list[index])
        interleaved_list.append(third_list[index])
    
    return interleaved_list