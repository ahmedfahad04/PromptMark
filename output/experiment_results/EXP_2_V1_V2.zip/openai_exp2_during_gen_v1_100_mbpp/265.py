def list_split(input_list, n):
    # Initialize a list to hold the resulting sublists
    result = []
    
    # Iterate over the range of n
    for index in range(n):
        # Create a sublist starting from the current index and stepping by n
        sublist = input_list[index::n]
        result.append(sublist)
    
    return result