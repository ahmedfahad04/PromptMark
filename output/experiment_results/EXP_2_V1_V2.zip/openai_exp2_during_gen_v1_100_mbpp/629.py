def Split(num_list):
    # Create a list to hold even numbers
    even_numbers = []
    
    # Iterate through the provided number list
    for number in num_list:
        # Check if the number is even
        if number % 2 == 0:
            even_numbers.append(number)
    
    return even_numbers