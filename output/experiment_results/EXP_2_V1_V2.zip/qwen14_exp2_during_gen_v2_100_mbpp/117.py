def list_to_float(data):
    # Initialize an empty list to store the converted data
    result = []
    
    # Iterate through each sublist in the input data
    for sublist in data:
        # Initialize an empty list to store the converted elements of the current sublist
        converted_sublist = []
        
        # Iterate through each element in the current sublist
        for item in sublist:
            try:
                # Try converting the string to a float
                converted_value = float(item)
            except ValueError:
                # If conversion fails, keep the original string value
                converted_value = item
            
            # Append the converted value to the current sublist's list
            converted_sublist.append(converted_value)
        
        # Append the fully converted sublist to the result list
        result.append(tuple(converted_sublist))
    
    return result