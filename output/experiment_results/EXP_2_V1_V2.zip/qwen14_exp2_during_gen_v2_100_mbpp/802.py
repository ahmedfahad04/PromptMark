def count_rotation(arr):
    # Find the index where the array is split between the largest and smallest elements
    min_index = arr.index(min(arr))
    
    # Check if the array needs rotation
    if arr[0] < arr[-1]:
        return 0
    
    # Count the number of rotations
    for i in range(1, len(arr)):
        if arr[i] < arr[i - 1]:
            return i
    
    # If no such point is found, the array is already sorted
    return len(arr)