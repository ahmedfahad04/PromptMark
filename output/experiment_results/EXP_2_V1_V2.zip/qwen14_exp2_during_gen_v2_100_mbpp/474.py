def replace_char(s, old_char, new_char):
    """
    Replaces all occurrences of old_char with new_char in the given string s.
    
    :param s: The input string where replacements will be made.
    :param old_char: The character to be replaced.
    :param new_char: The character to replace with.
    :return: A new string with all occurrences of old_char replaced by new_char.
    """
    result = ""
    for char in s:
        if char == old_char:
            result += new_char
        else:
            result += char
    return result