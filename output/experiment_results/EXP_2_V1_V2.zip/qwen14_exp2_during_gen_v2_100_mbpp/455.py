def check_monthnumb_number(month):
    # Months with 31 days: January (1), March (3), May (5), July (7), August (8), October (10), December (12)
    if month in {1, 3, 5, 7, 8, 10, 12}:
        return True
    else:
        return False