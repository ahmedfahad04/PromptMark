def interleave_lists(list1, list2, list3):
    # Initialize an empty list to store the result
    result = []
    
    # Iterate through the indices of the input lists
    for i in range(len(list1)):
        # Append elements from each list at index i to the result list
        result.append(list1[i])
        result.append(list2[i])
        result.append(list3[i])
    
    return result