import math

def polar_rect(r, theta):
    # Convert polar coordinates to rectangular coordinates
    x = r * math.cos(theta)
    y = r * math.sin(theta)
    
    # Return the result as a tuple of real part and imaginary part
    return ((x**2 + y**2)**0.5, complex(x, y))