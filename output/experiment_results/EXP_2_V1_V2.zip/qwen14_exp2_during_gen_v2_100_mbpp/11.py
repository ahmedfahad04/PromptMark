def remove_Occ(s, ch):
    # Find the index of the first occurrence of ch
    first_index = s.find(ch)
    
    # Find the index of the last occurrence of ch
    last_index = s.rfind(ch)
    
    # If the character is found at least twice, remove the characters at these indices
    if first_index != -1 and last_index != -1 and first_index != last_index:
        return s[:first_index] + s[first_index+1:last_index] + s[last_index+1:]
    else:
        # If the character appears less than twice, just return the original string
        return s