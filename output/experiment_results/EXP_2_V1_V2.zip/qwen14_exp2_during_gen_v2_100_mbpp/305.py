def start_withp(words):
    # Split the input string into individual words
    word_list = words.split()
    
    # Initialize an empty list to store the result
    result = []
    
    # Iterate through the list of words
    for word in word_list:
        # Check if the first character of the word is 'p'
        if word[0].lower() == 'p':
            # If it matches, add the word to the result list
            result.append(word)
            # Once we have found two matching words, break out of the loop
            if len(result) == 2:
                break
    
    # Return the first two words that match the condition
    return tuple(result[:2])