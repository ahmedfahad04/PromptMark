def find_first_occurrence(arr, target):
    # Initialize the search bounds
    left, right = 0, len(arr) - 1
    
    # Perform binary search
    while left <= right:
        mid = (left + right) // 2
        
        # Check if the middle element is the target
        if arr[mid] == target:
            # If it's the first occurrence or the previous element is not the target
            if mid == 0 or arr[mid - 1] != target:
                return mid
            else:
                # Continue searching in the left half
                right = mid - 1
        elif arr[mid] < target:
            # Target is in the right half
            left = mid + 1
        else:
            # Target is in the left half
            right = mid - 1
            
    # Return -1 if the target is not found
    return -1