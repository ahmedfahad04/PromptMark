def extract_quotation(input_string):
    # Initialize an empty list to store the extracted values
    result = []
    
    # Start index for the current substring being processed
    start_index = None
    
    # Iterate through each character in the input string
    for i, char in enumerate(input_string):
        # If we encounter the opening quote and no start index has been set
        if char == '"' and start_index is None:
            start_index = i + 1  # Set the start index after the opening quote
        
        # If we encounter the closing quote and a start index has been set
        elif char == '"' and start_index is not None:
            # Extract the substring between the quotes and add it to the result list
            result.append(input_string[start_index:i])
            start_index = None  # Reset the start index
    
    return result