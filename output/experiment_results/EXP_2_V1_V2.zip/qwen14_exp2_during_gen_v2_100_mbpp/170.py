def sum_range_list(nums, start, end):
    # Ensure the start index is less than the end index
    if start > end:
        return 0
    
    # Calculate the sum of elements between the specified range
    total = 0
    for i in range(start, end + 1):
        total += nums[i]
    
    return total