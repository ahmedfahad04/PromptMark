def remove_nested(tpl):
    result = ()
    for item in tpl:
        if not isinstance(item, tuple):
            result += (item,)
    return result