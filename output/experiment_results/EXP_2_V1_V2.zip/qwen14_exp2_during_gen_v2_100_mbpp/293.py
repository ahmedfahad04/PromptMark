import math

def otherside_rightangle(a, b):
    # Identify the hypotenuse (the longest side)
    c = max(a, b)
    # Calculate the other side using Pythagorean theorem
    other_side = math.sqrt(c**2 - min(a, b)**2)
    return round(other_side, 9)