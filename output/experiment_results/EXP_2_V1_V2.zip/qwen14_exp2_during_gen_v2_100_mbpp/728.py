def sum_list(a, b):
    # Initialize an empty list to store the result
    result = []
    
    # Iterate through the elements of both lists and add corresponding elements
    for i in range(len(a)):
        result.append(a[i] + b[i])
    
    return result