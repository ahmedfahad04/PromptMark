def check_value(data, value):
    # Check if all values in the dictionary are equal to the given value
    for key in data:
        if data[key] != value:
            return False
    return True