def rotate_right(lst, n):
    # Calculate effective rotation needed
    n = n % len(lst)
    
    # Rotate the list by slicing and concatenating
    rotated_lst = lst[-n:] + lst[:-n]
    
    return rotated_lst