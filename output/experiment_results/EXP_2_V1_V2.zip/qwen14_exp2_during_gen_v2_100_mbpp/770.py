def odd_num_sum(n):
    """
    Calculate the sum of the fourth powers of the first n odd natural numbers.
    
    Args:
        n (int): The number of initial odd natural numbers to consider.
        
    Returns:
        int: The sum of the fourth powers of the first n odd natural numbers.
    """
    total = 0
    current_odd = 1
    
    for _ in range(n):
        total += current_odd ** 4
        current_odd += 2
        
    return total