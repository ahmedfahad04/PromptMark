def loss_amount(sales_price, cost_price):
    # Check if there is a loss
    if sales_price < cost_price:
        # Calculate the loss amount
        loss = cost_price - sales_price
        return loss
    else:
        # No loss, return 0
        return 0