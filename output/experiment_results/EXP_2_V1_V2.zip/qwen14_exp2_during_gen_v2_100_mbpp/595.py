def min_Swaps(str1, str2):
    # Check if both strings have the same length
    if len(str1) != len(str2):
        return "Not Possible"
    
    # Count the number of differing bits between the two strings
    diff_count = sum(1 for bit1, bit2 in zip(str1, str2) if bit1 != bit2)
    
    # If the count of differing bits is odd, it's not possible to make the strings equal through swaps
    if diff_count % 2 != 0:
        return "Not Possible"
    
    # Otherwise, the minimum number of swaps needed is half the count of differing bits
    return diff_count // 2