def is_sublist(main_list, sub_list):
    # Check if the sub_list is empty, return True as an empty list is a sublist of any list
    if not sub_list:
        return True
    
    # Iterate through the main_list up to len(main_list) - len(sub_list) + 1 times
    for i in range(len(main_list) - len(sub_list) + 1):
        # Check if elements in sub_list match elements in main_list starting at index i
        if all(main_list[i + j] == sub_list[j] for j in range(len(sub_list))):
            return True
    
    # If no match found, return False
    return False