def rectangle_area(length, width):
    # Calculate the area of the rectangle using the formula: length * width
    area = length * width
    return area