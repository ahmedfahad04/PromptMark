def tuple_intersection(tuples1, tuples2):
    # Convert both lists of tuples into sets for efficient intersection operation
    set1 = {tuple(sorted(t)) for t in tuples1}
    set2 = {tuple(sorted(t)) for t in tuples2}
    
    # Find the intersection of the two sets
    result = set1.intersection(set2)
    
    return result