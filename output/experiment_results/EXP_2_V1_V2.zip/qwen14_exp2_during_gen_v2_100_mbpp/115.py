def empty_dit(dicts):
    """
    Check if all dictionaries in the provided list are empty.
    
    Args:
    dicts (list): A list of dictionaries.
    
    Returns:
    bool: True if all dictionaries are empty, False otherwise.
    """
    # Iterate through each dictionary in the list
    for d in dicts:
        # If any dictionary is not empty, return False
        if d:
            return False
    # If all dictionaries are empty, return True
    return True