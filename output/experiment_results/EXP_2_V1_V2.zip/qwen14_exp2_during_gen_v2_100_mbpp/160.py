def find_solution(a, b, n):
    # Check if gcd(a, b) divides n
    def gcd(x, y):
        while y:
            x, y = y, x % y
        return x
    
    if n % gcd(a, b) != 0:
        return None
    
    # Extended Euclidean Algorithm to find one solution
    def extended_gcd(x, y):
        if x == 0:
            return y, 0, 1
        else:
            g, u, v = extended_gcd(y % x, x)
            return g, v - (y // x) * u, u
    
    _, x, y = extended_gcd(a, b)
    
    # Scale the solution to match the target value n
    x *= n // gcd(a, b)
    y *= n // gcd(a, b)
    
    return (x, y)