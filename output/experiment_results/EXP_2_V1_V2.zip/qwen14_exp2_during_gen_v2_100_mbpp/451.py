def remove_whitespaces(input_string):
    # Initialize an empty string to store the result
    result = ''
    
    # Iterate through each character in the input string
    for char in input_string:
        # Check if the character is not a whitespace
        if char not in ' \t\n\r':
            # Append non-whitespace characters to the result
            result += char
    
    return result