def power(a, b):
    # Initialize result to 1 since any number to the power of 0 is 1
    result = 1
    
    # Loop b times to multiply a by itself b times
    while b > 0:
        # If b is odd, multiply result by a
        if b % 2 == 1:
            result *= a
        # Square a and halve b to reduce the number of multiplications
        a *= a
        b //= 2
    
    return result