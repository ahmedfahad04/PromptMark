def occurance_substring(main_string, sub_string):
    # Check if the substring exists in the main string
    if sub_string in main_string:
        # Find the starting index of the first occurrence
        start_index = main_string.index(sub_string)
        # Calculate the end index based on the length of the substring
        end_index = start_index + len(sub_string)
        return sub_string, start_index, end_index
    else:
        return None