def find_adverbs(text):
    # Split the text into words
    words = text.split()
    
    # Iterate through each word to check if it ends with 'ly'
    for i, word in enumerate(words):
        if word.endswith('ly'):
            # Calculate the starting index of the adverb
            start_index = sum(len(words[j]) + 1 for j in range(i)) - len(words[i])
            # Return the formatted result
            return f'{start_index}-{start_index + len(word)}: {word}'
    # If no adverb found, return an appropriate message
    return "No adverb found"