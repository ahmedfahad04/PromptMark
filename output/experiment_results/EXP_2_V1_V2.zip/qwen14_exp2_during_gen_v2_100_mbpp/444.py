def trim_tuple(tuples_list, k):
    # Initialize an empty list to store the trimmed tuples
    result = []
    
    # Iterate through each tuple in the input list
    for tup in tuples_list:
        # Trim the tuple by taking elements starting from index k to the end
        trimmed_tup = tup[k:]
        # Append the trimmed tuple to the result list
        result.append(trimmed_tup)
    
    # Convert the result list to a string representation
    return str(result)