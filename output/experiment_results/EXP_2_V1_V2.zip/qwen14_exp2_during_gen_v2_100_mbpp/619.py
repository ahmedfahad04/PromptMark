def move_num(s):
    # Separate letters and numbers into two lists
    letters = [char for char in s if char.isalpha()]
    numbers = [char for char in s if char.isdigit()]
    
    # Join the letters and numbers back together, with numbers at the end
    result = ''.join(letters + numbers)
    
    return result