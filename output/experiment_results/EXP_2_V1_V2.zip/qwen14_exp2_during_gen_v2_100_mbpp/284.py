def check_element(lst, elem):
    # Check if all elements in the list are equal to the given element
    return all(item == elem for item in lst)