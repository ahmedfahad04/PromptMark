def left_insertion(arr, val):
    """
    Locate the left insertion point for a specified value in a sorted array.
    
    :param arr: Sorted list of integers
    :param val: Value to insert
    :return: Index where the value should be inserted to maintain sorted order
    """
    low = 0
    high = len(arr)
    
    while low < high:
        mid = (low + high) // 2
        if arr[mid] < val:
            low = mid + 1
        else:
            high = mid
            
    return low