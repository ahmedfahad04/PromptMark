def max_product(nums):
    # Initialize variables to store the current subsequence and its product
    max_subseq = [nums[0]]
    max_product = nums[0]
    
    # Iterate through the array starting from the second element
    for i in range(1, len(nums)):
        # Check if the current number can be part of the increasing subsequence
        if nums[i] > max_subseq[-1]:
            # If yes, append it to the subsequence list
            max_subseq.append(nums[i])
        else:
            # Otherwise, find the position where the current number should replace an existing number
            for j in range(len(max_subseq)):
                if nums[i] <= max_subseq[j]:
                    max_subseq[j] = nums[i]
                    break
        
        # Calculate the product of the current subsequence
        current_product = 1
        for num in max_subseq:
            current_product *= num
        
        # Update the maximum product found so far
        if current_product > max_product:
            max_product = current_product
    
    return max_product