def extract_nth_element(lst, n):
    # Extract the nth element from each tuple in the list
    result = [item[n] for item in lst]
    return result