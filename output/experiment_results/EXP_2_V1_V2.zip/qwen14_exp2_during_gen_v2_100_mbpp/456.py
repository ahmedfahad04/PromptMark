def reverse_string_list(strings):
    # Reverse each string in the input list and return the new list
    reversed_strings = [s[::-1] for s in strings]
    return reversed_strings