def count_bidirectional(pairs):
    # Create a dictionary to store the occurrences of each pair and its reverse
    pair_count = {}
    
    # Iterate through each pair in the list
    for a, b in pairs:
        # Check both directions of the pair
        key1 = tuple(sorted((a, b)))
        key2 = tuple(sorted((b, a)))
        
        # Increment the count for both keys
        pair_count[key1] = pair_count.get(key1, 0) + 1
        pair_count[key2] = pair_count.get(key2, 0) + 1
    
    # Count the number of unique bidirectional pairs
    bidirectional_count = sum(1 for count in pair_count.values() if count > 1)
    
    return bidirectional_count // 2