def sector_area(radius, angle):
    """
    Calculate the area of a sector given its radius and central angle.
    
    Args:
    radius (float): The radius of the circle.
    angle (int): The central angle of the sector in degrees.
    
    Returns:
    float or None: The area of the sector if the angle is <= 360; otherwise, returns None.
    """
    import math
    
    # Check if the angle is greater than 360 degrees
    if angle > 360:
        return None
    
    # Calculate the area of the sector
    sector_area = (angle / 360) * math.pi * (radius ** 2)
    
    return sector_area