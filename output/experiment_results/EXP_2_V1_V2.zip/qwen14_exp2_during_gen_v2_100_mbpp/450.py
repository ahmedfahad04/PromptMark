def extract_string(values, size):
    # Initialize an empty list to store the result
    result = []
    
    # Iterate through each value in the input list
    for value in values:
        # Check if the length of the current value matches the specified size
        if len(value) == size:
            # If it does, add it to the result list
            result.append(value)
    
    # Return the final list containing strings of the specified size
    return result