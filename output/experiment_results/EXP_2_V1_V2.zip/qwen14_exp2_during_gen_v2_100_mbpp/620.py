def largest_subset(nums):
    # Sort the array to group potential divisible pairs together
    nums.sort()
    
    # Dictionary to store the size of the largest subset ending with each number
    dp = {}
    
    # Iterate through each number in the sorted list
    for num in nums:
        # Initialize the maximum subset size for this number
        max_size = 1
        
        # Check all previous numbers to see if they form a valid pair with the current number
        for prev_num in nums:
            if prev_num != num and num % prev_num == 0:
                # Update the maximum subset size for the current number
                max_size = max(max_size, dp.get(prev_num, 1) + 1)
        
        # Store the result in the dictionary
        dp[num] = max_size
    
    # Return the maximum value from the dictionary, which represents the size of the largest subset
    return max(dp.values())