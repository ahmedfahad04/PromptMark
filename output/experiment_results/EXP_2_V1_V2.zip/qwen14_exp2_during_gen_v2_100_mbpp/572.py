def two_unique_nums(nums):
    # Create a set to store unique numbers
    unique_nums = set()
    
    # Iterate through each number in the input list
    for num in nums:
        # If the number is already in the set, remove it; otherwise, add it
        if num in unique_nums:
            unique_nums.remove(num)
        else:
            unique_nums.add(num)
    
    # Convert the set back to a list
    result = list(unique_nums)
    
    # Return the sorted list to maintain consistent order
    return sorted(result)