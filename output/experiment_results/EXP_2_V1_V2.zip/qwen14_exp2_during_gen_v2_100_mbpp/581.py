import math

def surface_Area(base_edge, height):
    # Calculate the slant height using the Pythagorean theorem
    slant_height = math.sqrt((base_edge / 2) ** 2 + height ** 2)
    
    # Calculate the lateral area
    lateral_area = base_edge * slant_height
    
    # Calculate the base area
    base_area = base_edge ** 2
    
    # Total surface area is the sum of the base area and the lateral area
    total_surface_area = base_area + lateral_area
    
    return total_surface_area