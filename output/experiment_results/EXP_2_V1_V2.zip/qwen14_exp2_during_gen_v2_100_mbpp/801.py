def test_three_equal(a, b, c):
    # Check if all three numbers are equal
    if a == b == c:
        return 3
    # Check if exactly two numbers are equal
    elif a == b or b == c or a == c:
        return 2
    else:
        return 0