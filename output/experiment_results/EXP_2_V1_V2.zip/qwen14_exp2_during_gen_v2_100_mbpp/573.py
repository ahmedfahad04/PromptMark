def unique_product(numbers):
    """
    Calculate the product of unique numbers in the given list.
    
    Args:
    numbers (list): A list of integers.
    
    Returns:
    int: The product of unique numbers in the list.
    """
    unique_numbers = set(numbers)
    product = 1
    for number in unique_numbers:
        product *= number
    return product