def toggle_middle_bits(n):
    # Find the position of the most significant bit (MSB)
    msb = n.bit_length() - 1
    
    # Create a mask to clear the first and last bit
    mask = (1 << msb) - 1  # All bits set to 1
    mask |= 1              # Set the least significant bit to 1
    
    # Toggle all bits using XOR operation with the mask
    result = n ^ mask
    
    return result