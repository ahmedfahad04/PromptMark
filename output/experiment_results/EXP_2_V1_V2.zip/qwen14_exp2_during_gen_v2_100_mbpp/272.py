def rear_extract(tuples_list):
    """
    Extracts the last element from each tuple in the provided list of tuples.
    
    :param tuples_list: A list of tuples where each tuple contains at least one element.
    :return: A list containing the last element from each tuple in the input list.
    """
    # Initialize an empty list to store the rear elements
    rear_elements = []
    
    # Iterate through each tuple in the input list
    for tup in tuples_list:
        # Append the last element of the current tuple to the rear_elements list
        rear_elements.append(tup[-1])
    
    return rear_elements