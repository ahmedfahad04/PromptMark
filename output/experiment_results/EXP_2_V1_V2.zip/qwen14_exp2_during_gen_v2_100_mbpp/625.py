def swap_List(list):
    # Check if the list has at least one element
    if len(list) > 0:
        # Swap the first and last elements
        list[0], list[-1] = list[-1], list[0]
    return list