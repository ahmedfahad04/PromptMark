def extract_singly(nested_list):
    # Initialize an empty set to store the flattened elements
    flat_set = set()
    
    # Iterate through each sublist in the nested list
    for sublist in nested_list:
        # Iterate through each element in the current sublist
        for item in sublist:
            # Add the element to the set
            flat_set.add(item)
    
    # Return the final set containing all unique elements
    return flat_set