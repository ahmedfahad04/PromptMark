def count_vowels(s):
    # Define the set of vowels
    vowels = set('aeiouAEIOU')
    
    # Initialize the count of characters with vowel neighbors
    count = 0
    
    # Iterate through the string, except the first and last characters
    for i in range(1, len(s) - 1):
        # Check if the current character has a vowel neighbor on either side
        if s[i-1] in vowels or s[i+1] in vowels:
            count += 1
            
    # Check the first and last characters separately
    if len(s) > 1:
        if s[0] in vowels or s[-1] in vowels:
            count += 1
            
    return count