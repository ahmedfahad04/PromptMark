def find_even_pair(arr):
    """
    Counts the number of pairs of integers in the list `arr` whose XOR result is even.
    
    An XOR result is even if both numbers in the pair are either even or odd.
    We count such pairs using two counters for even and odd numbers respectively,
    and then calculate the total number of valid pairs based on these counts.
    """
    # Counters for even and odd numbers
    even_count = 0
    odd_count = 0
    
    # Iterate through the array and update counters
    for num in arr:
        if num % 2 == 0:
            even_count += 1
        else:
            odd_count += 1
    
    # Calculate the number of valid pairs
    # Pairs of even numbers + Pairs of odd numbers
    return even_count * (even_count - 1) // 2 + odd_count * (odd_count - 1) // 2

# Test cases
assert find_even_pair([5, 4, 7, 2, 1]) == 4
assert find_even_pair([7, 2, 8, 1, 0, 5, 11]) == 9
assert find_even_pair([1, 2, 3]) == 1