def string_to_tuple(input_string):
    # Convert the input string into a tuple of characters
    return tuple(input_string)