def count_same_pair(lst1, lst2):
    # Initialize a counter to keep track of matching elements
    match_count = 0
    
    # Iterate through both lists simultaneously using zip
    for i, j in zip(lst1, lst2):
        # If the elements at the current index are the same, increment the counter
        if i == j:
            match_count += 1
            
    # Return the final count of matching elements
    return match_count