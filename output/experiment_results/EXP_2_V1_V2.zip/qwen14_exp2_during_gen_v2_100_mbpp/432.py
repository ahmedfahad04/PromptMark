def median_trapezium(a, b, c):
    # Calculate the median length of the trapezium using the formula:
    # Median = (sum of the lengths of the two parallel sides) / 2
    return (a + b) / 2