def parabola_directrix(a, b, c):
    # Calculate the directrix using the formula y = k - 1/(4a)
    # For the standard form (x - h)^2 = 4a(y - k), we need to derive a and k from the given coefficients
    # Given quadratic equation in standard polynomial form: ax^2 + bx + c
    # We complete the square to get it into the form (x - h)^2 = 4a(y - k)
    
    # Completing the square:
    # ax^2 + bx + c = a(x^2 + (b/a)x) + c
    #               = a((x + b/(2a))^2 - (b/(2a))^2) + c
    #               = a(x + b/(2a))^2 - b^2/(4a) + c
    
    # So, 4a = a, and k = c - b^2 / (4a)
    k = c - b**2 / (4 * a)
    directrix = k - 1 / (4 * a)
    return directrix