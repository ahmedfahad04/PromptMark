def merge_dictionaries_three(d1, d2, d3):
    # Initialize an empty dictionary to store the merged result
    merged_dict = {}
    
    # Merge the first dictionary
    for key, value in d1.items():
        merged_dict[key] = value
    
    # Merge the second dictionary
    for key, value in d2.items():
        if key in merged_dict:
            merged_dict[key] = value
        else:
            merged_dict[key] = value
    
    # Merge the third dictionary
    for key, value in d3.items():
        if key in merged_dict:
            merged_dict[key] = value
        else:
            merged_dict[key] = value
    
    return merged_dict