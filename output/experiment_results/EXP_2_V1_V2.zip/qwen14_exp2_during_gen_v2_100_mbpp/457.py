def Find_Min(sublists):
    # Initialize the minimum length with a large number
    min_length = float('inf')
    # Initialize the result list to store the sublist with minimum length
    result = []
    
    # Iterate through each sublist in the input list
    for sublist in sublists:
        # Check if the current sublist's length is less than the minimum length found so far
        if len(sublist) < min_length:
            # Update the minimum length and reset the result list
            min_length = len(sublist)
            result = sublist
    
    # Return the sublist with the minimum length
    return result