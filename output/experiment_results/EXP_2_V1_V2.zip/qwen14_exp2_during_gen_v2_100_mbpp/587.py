def list_tuple(lst):
    # Convert the list to a tuple using the built-in tuple() function
    return tuple(lst)