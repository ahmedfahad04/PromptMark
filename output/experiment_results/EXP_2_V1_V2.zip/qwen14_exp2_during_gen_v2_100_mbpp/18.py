def remove_dirty_chars(str1, str2):
    # Initialize an empty result string
    result = ""
    
    # Iterate through each character in str1
    for char in str1:
        # If the character is not in str2, add it to the result
        if char not in str2:
            result += char
    
    return result