def frequency_lists(lst):
    # Initialize an empty dictionary to store the frequency of elements
    freq = {}
    
    # Iterate through each sublist in the input list
    for sub_lst in lst:
        # Update the frequency count for each element in the sublist
        for item in sub_lst:
            if item in freq:
                freq[item] += 1
            else:
                freq[item] = 1
    
    return freq