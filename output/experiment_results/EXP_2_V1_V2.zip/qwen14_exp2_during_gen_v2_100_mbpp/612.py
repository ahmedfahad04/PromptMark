def merge(lst_of_lsts):
    # Initialize lists to hold the first and second elements respectively
    first_elements = []
    second_elements = []

    # Iterate through each sublist in the input list
    for sublist in lst_of_lsts:
        # Append the first element of the current sublist to first_elements
        first_elements.append(sublist[0])
        # Append the second element of the current sublist to second_elements
        second_elements.append(sublist[1])

    # Return a list containing both lists
    return [first_elements, second_elements]