def comb_sort(arr):
    # Calculate the gap initially as the length of the array
    gap = len(arr)
    # Initialize the swapped as True to enter the while loop
    swapped = True
    
    # Keep running the loop until gap is 1 and no swap occurred in the last round
    while gap > 1 or swapped:
        # Update the gap value for this phase of the algorithm
        gap = max(1, int(gap / 1.3))
        
        # Initialize swapped as False so that we can check if a swap happened
        swapped = False
        
        # Compare elements at a distance of current gap and swap them if needed
        for i in range(len(arr) - gap):
            if arr[i] > arr[i + gap]:
                # Swap the elements
                arr[i], arr[i + gap] = arr[i + gap], arr[i]
                # Set swapped as True since a swap has been made
                swapped = True
                
    return arr