def find_Max_Num(digits):
    # Convert each digit to a string
    str_digits = [str(digit) for digit in digits]
    
    # Custom sort key to ensure the largest number is formed
    def sort_key(x):
        return x * 10
    
    # Sort the digits based on the custom key
    sorted_digits = sorted(str_digits, key=lambda x: (sort_key(x[0]), x), reverse=True)
    
    # Join the sorted digits to form the largest number
    max_num_str = ''.join(sorted_digits)
    
    # Remove any leading zeros (if any)
    max_num = int(max_num_str.lstrip('0'))
    
    return max_num