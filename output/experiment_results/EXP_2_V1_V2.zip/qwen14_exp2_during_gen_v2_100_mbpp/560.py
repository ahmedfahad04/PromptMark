def union_elements(tup1, tup2):
    # Combine the two tuples
    combined = tup1 + tup2
    
    # Convert the combined tuple to a set to remove duplicates and then back to a tuple
    unique_elements = tuple(set(combined))
    
    # Return the sorted tuple
    return tuple(sorted(unique_elements))

# Test cases
assert union_elements((3, 4, 5, 6), (5, 7, 4, 10)) == (3, 4, 5, 6, 7, 10)
assert union_elements((1, 2, 3, 4), (3, 4, 5, 6)) == (1, 2, 3, 4, 5, 6)
assert union_elements((11, 12, 13, 14), (13, 15, 16, 17)) == (11, 12, 13, 14, 15, 16, 17)