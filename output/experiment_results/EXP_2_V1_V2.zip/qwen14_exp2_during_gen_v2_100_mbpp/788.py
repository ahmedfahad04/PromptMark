def new_tuple(words_list, word):
    """
    Create a new tuple from the given list of words and a single word.
    
    :param words_list: List of strings
    :param word: String
    :return: Tuple containing elements from the list and the word
    """
    # Combine the list and the word into a tuple
    result = tuple(words_list + [word])
    return result