def average_tuple(tuples):
    # Initialize an empty list to store the averages
    averages = []
    
    # Iterate over each tuple in the input list
    for tup in tuples:
        # Calculate the sum of the elements in the current tuple
        total_sum = sum(tup)
        # Calculate the number of elements in the current tuple
        num_elements = len(tup)
        # Calculate the average and append it to the averages list
        averages.append(total_sum / num_elements)
    
    # Return the list of averages
    return averages