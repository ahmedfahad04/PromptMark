def drop_empty(data):
    # Create an empty dictionary to store the result
    result = {}
    
    # Iterate through each key-value pair in the input dictionary
    for key, value in data.items():
        # Check if the value is not None
        if value is not None:
            # If the value is not None, add it to the result dictionary
            result[key] = value
    
    return result