def group_tuples(tuples_list):
    # Create a dictionary to store the groups based on the first element of each tuple
    grouped_dict = {}
    
    # Iterate through each tuple in the input list
    for tup in tuples_list:
        first_element = tup[0]
        second_element = tup[1]
        
        # If the first element is already in the dictionary, append the second element to it
        if first_element in grouped_dict:
            grouped_dict[first_element].append(second_element)
        else:
            # Otherwise, create a new entry in the dictionary with the first element and its corresponding second element
            grouped_dict[first_element] = [second_element]
    
    # Convert the dictionary values into the required format
    result = []
    for key, value in grouped_dict.items():
        # Combine the first element with all its corresponding second elements
        combined_tuple = (key,) + tuple(value)
        result.append(combined_tuple)
    
    return result