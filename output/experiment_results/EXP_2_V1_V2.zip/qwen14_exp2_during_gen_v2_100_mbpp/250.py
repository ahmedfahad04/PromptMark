def count_X(tpl, elem):
    # Initialize a counter to zero
    cnt = 0
    
    # Iterate through each item in the tuple
    for i in tpl:
        # If the current item matches the element, increment the counter
        if i == elem:
            cnt += 1
            
    # Return the final count
    return cnt