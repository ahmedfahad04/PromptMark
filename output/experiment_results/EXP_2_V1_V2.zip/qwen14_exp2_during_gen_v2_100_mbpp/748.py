def capital_words_spaces(text):
    # Initialize an empty list to store the parts of the text
    parts = []
    
    # Initialize an empty string to build each part
    current_part = ''
    
    # Iterate through each character in the input text
    for char in text:
        if char.isupper():
            # If the character is uppercase and it's not the first character,
            # add the current part to the list and start a new part
            if current_part:
                parts.append(current_part)
                current_part = char
            else:
                current_part += char
        else:
            # Otherwise, just append the character to the current part
            current_part += char
    
    # Add the last part to the list if it exists
    if current_part:
        parts.append(current_part)
    
    # Join all parts with a space and return the result
    return ' '.join(parts)