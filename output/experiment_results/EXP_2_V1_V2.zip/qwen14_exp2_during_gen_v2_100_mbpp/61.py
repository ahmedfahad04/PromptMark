def count_Substrings(s):
    # Initialize result counter
    count = 0
    
    # Iterate through all possible substrings
    for i in range(len(s)):
        total = 0
        for j in range(i, len(s)):
            # Add current digit to total
            total += int(s[j])
            
            # Check if sum of digits equals substring length
            if total == j - i + 1:
                count += 1
                
    return count