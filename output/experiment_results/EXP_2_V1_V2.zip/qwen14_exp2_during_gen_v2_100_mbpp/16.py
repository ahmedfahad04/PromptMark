def text_lowercase_underscore(s):
    # Check if the string starts with a lowercase letter
    if not s[0].islower():
        return False
    
    # Iterate through each character in the string
    i = 0
    while i < len(s):
        # If the current character is an underscore
        if s[i] == '_':
            # The next character must be a lowercase letter
            if i + 1 >= len(s) or not s[i + 1].islower():
                return False
            i += 1
        elif not s[i].islower():
            return False
        i += 1
    
    return True