import re

def text_match_wordz(text):
    # Check if the text contains a word with 'z'
    pattern = r'\b\w*z\w*\b'
    match = re.search(pattern, text)
    return bool(match)