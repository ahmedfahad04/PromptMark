def is_perfect_square(num):
    # Check if num is less than 0, it cannot be a perfect square
    if num < 0:
        return False
    
    # Calculate the square root of num
    sqrt_num = int(num ** 0.5)
    
    # Check if the square of the calculated square root equals the original number
    return sqrt_num * sqrt_num == num