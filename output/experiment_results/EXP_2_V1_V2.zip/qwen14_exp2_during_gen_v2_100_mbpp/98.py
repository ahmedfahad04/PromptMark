def multiply_num(numbers):
    # Multiply all the numbers in the list
    product = 1
    for num in numbers:
        product *= num
    
    # Divide the product by the length of the list
    result = product / len(numbers)
    
    return result