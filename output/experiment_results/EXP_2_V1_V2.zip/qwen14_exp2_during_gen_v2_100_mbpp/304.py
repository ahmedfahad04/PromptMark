def find_Element(arr, queries, k, n):
    # Calculate the total number of rotations needed
    total_rotations = sum(query[1] for query in queries)
    
    # Adjust the index based on the total rotations
    adjusted_index = (k + total_rotations) % len(arr)
    
    # Return the element at the adjusted index
    return arr[adjusted_index]