def bf(planet1, planet2):
    all_planets_data = ("Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune")

    # Adjust input planet names to match capitalization in the data, just in case.
    # Also, ensure they are valid planets from our known data.
    adjusted_planet_one = planet1.capitalize()
    adjusted_planet_two = planet2.capitalize()

    # If either input planet is not a valid known planet, just exit with an empty tuple.
    if adjusted_planet_one not in all_planets_data or adjusted_planet_two not in all_planets_data:
        return ()

    # Get the orbital indices for both planets.
    idx_one = all_planets_data.index(adjusted_planet_one)
    idx_two = all_planets_data.index(adjusted_planet_two)

    # Determine the actual lower and upper bounds for slicing.
    # This ensures that planets are always ordered from closer to further from the sun.
    lower_idx = min(idx_one, idx_two)
    upper_idx = max(idx_one, idx_two)

    # Extract the planets located between the two input planets.
    # The slice is exclusive of the start and end planets themselves.
    located_planets_data = all_planets_data[lower_idx + 1:upper_idx]

    return located_planets_data