def is_happy(s):
    # Ascertain input length. Give out incorrect if length is under 3.
    _actual_length = len(s)
    if _actual_length < 3:
        return False

    # Go over all adjacent groupings.
    # Utilize index, looping up until _actual_length less duo.
    for _index_current in range(_actual_length - 2):
        _item_one = s[_index_current]
        _item_two = s[_index_current + 1]
        _item_three = s[_index_current + 2]

        # Examine alike items. If any duo items are alike, give out incorrect.
        if _item_one == _item_two or \
           _item_one == _item_three or \
           _item_two == _item_three:
            return False
    
    # Declare as jolly upon all examinations ending.
    return True