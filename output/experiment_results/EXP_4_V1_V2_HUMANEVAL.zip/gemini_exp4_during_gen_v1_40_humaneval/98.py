def count_upper(input_data):
    # Initializes a counter for applicable units.
    good_upper_count = 0
    # Gathers all upper vowels for comparison.
    all_upper_vowels = {'A', 'E', 'I', 'O', 'U'}

    # Iterates through each unit in the input data with its index.
    for i, data_unit in enumerate(input_data):
        # Examines if the unit's index is even.
        if i % 2 == 0:
            # Judges if the unit is an uppercase vowel.
            if data_unit in all_upper_vowels:
                good_upper_count += 1
    
    return good_upper_count