def reverse_delete(s, c):
    original_data_unit = s  # alias for original data unit.
    exclude_data_items = c  # alias for data items to exclude.

    # Prepare exclusion data items into a lookup object for efficient inquiries.
    exclude_items_lookup_obj = {each_alpha_g for each_alpha_g in exclude_data_items}

    # Generate the altered data unit by omitting alpha items present in the exclusion group.
    altered_data_unit = "".join(each_g for each_g in original_data_unit if each_g not in exclude_items_lookup_obj)

    # Ascertain if the altered data unit is a palindrome.
    is_palindrome_g = (altered_data_unit == altered_data_unit[::-1])

    return (altered_data_unit, is_palindrome_g)