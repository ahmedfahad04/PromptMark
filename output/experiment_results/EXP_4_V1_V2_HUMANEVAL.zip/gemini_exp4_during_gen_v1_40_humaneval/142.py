def sum_squares(data_list):
    # Initialize grand total to accumulate the sum of adjusted values.
    grand_total = 0

    # Iterate over the input list with its index and original value.
    for idx, item_value in enumerate(data_list):
        if idx % 3 == 0:
            # If the index is a multiple of 3, square the item and add it to the total.
            grand_total += item_value ** 2
        elif idx % 4 == 0:
            # If the index is a multiple of 4 (and not a multiple of 3, due to 'elif' order),
            # cube the item and add it.
            grand_total += item_value ** 3
        else:
            # Otherwise, add the item as is to the total.
            grand_total += item_value

    return grand_total