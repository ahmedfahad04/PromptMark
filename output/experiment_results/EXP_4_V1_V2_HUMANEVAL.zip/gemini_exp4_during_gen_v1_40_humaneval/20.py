from typing import List, Tuple


def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    # Arrange data in increasing order.
    ordered_data = sorted(numbers)

    # Establish initial gap and ideal pair.
    least_gap = float('inf')
    ideal_pair = (ordered_data[0], ordered_data[1])

    data_length = len(ordered_data)
    # Loop adjacent elements, identify least gap.
    for i in range(data_length - 1):
        each_item = ordered_data[i]
        adjacent_item = ordered_data[i + 1]
        delta_value = adjacent_item - each_item

        # Update ideal_pair if a smaller gap is discovered.
        if delta_value < least_gap:
            least_gap = delta_value
            ideal_pair = (each_item, adjacent_item)

    return ideal_pair