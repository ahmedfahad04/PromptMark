def sort_array(array_data_list: list[int]) -> list[int]:
    """
    Arranges elements in an array based on the parity of the sum of its initial and last elements.
    """
    # A copy is always returned, even for empty or single-element inputs.
    if len(array_data_list) <= 1:
        return list(array_data_list)

    # Acquire initial and last elements for the sum calculation.
    initial_element = array_data_list[0]
    last_element = array_data_list[-1]
    elements_j_add = initial_element + last_element

    # Determine sorting order and apply it to a fresh copy.
    if elements_j_add % 2 != 0:  # If the sum is odd, sort ascending.
        ordered_data_list = sorted(array_data_list)
    else:  # If the sum is even, sort descending.
        ordered_data_list = sorted(array_data_list, reverse=True)

    return ordered_data_list