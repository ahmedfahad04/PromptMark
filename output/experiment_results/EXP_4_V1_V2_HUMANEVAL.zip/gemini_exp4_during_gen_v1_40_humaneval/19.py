from typing import List


def sort_numbers(numbers: str) -> str:
    # A mapping from alphabetic digit names to their integer values
    alp_dig_p_map = {
        'zero': 0, 'one': 1, 'two': 2, 'three': 3, 'four': 4,
        'five': 5, 'six': 6, 'seven': 7, 'eight': 8, 'nine': 9
    }
    
    # A mapping from integer values back to their alphabetic digit names
    dig_alp_p_map = {
        0: 'zero', 1: 'one', 2: 'two', 3: 'three', 4: 'four',
        5: 'five', 6: 'six', 7: 'seven', 8: 'eight', 9: 'nine'
    }

    # Splits the input string into a list of individual digit names
    a_alp_list_get = numbers.split(' ')

    # Converts the list of digit names into their corresponding integer values
    a_dig_l_p = [alp_dig_p_map[alp_key] for alp_key in a_alp_list_get]

    # Orders the list of integer values from smallest to largest
    a_dig_l_k = sorted(a_dig_l_p)

    # Converts the sorted integer values back into their alphabetic digit names
    a_alp_l_out = [dig_alp_p_map[dig_key] for dig_key in a_dig_l_k]

    # Joins the sorted alphabetic digit names into a single space-delimited string
    j_alp_out = ' '.join(a_alp_l_out)
    
    return j_alp_out