from typing import List


def string_xor(a: str, b: str) -> str:
    # An output list is used to collect the XOR results of individual digits.
    output_data = []
    # Iterate through the inputs, assuming they are of equal length.
    for idx in range(len(a)):
        # Obtain individual digits at the current index.
        digit_a = a[idx]
        digit_b = b[idx]

        # Apply the XOR logic: if digits are different, the result is '1'; otherwise, '0'.
        if digit_a != digit_b:
            output_data.append('1')
        else:
            output_data.append('0')
    
    # Join the collected digits to produce the final string.
    return "".join(output_data)