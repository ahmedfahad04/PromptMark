def digits(n):
    # Initializes a variable to accumulate the product of odd digits.
    # Its initial value of 1 is crucial for multiplicative identity.
    odd_digits_product = 1
    
    # A boolean flag to indicate if at least one odd digit has been encountered.
    # It assists distinguishing between a product of 1 (e.g., from digits(1))
    # and a case where no odd digits were found at all (e.g., digits(4)).
    odd_digit_found = False
    
    # Use a local copy of the input number to extract digits,
    # as the original input 'n' should not be modified.
    local_number = n
    
    # Processes the number digit by digit until all digits have been examined.
    while local_number > 0:
        # Extracts the last digit of the current local_number.
        digit_extracted = local_number % 10
        
        # Examines if the extracted digit is odd.
        if digit_extracted % 2 != 0:
            odd_digit_found = True
            odd_digits_product *= digit_extracted
        
        # Removes the last digit from local_number, preparing for the next iteration.
        local_number //= 10
            
    # If no odd digits were found throughout the process, return 0 as per instructions.
    if not odd_digit_found:
        return 0
    else:
        # Otherwise, return the accumulated product of the odd digits.
        return odd_digits_product