from typing import List


def parse_music(input_data_pieces_all: str) -> List[int]:
    # A list keeping all duration integers.
    an_ad_output_pulses = []

    # Divide input pulse-data, given into individual data pieces.
    an_all_pulses_data = input_data_pieces_all.split(' ')

    # Loop over each pulse data and identify its duration.
    for each_pulse_data_unit in an_all_pulses_data:
        if each_pulse_data_unit == 'o':
            # Place an ad-quadruple pulse duration.
            an_ad_output_pulses.append(4)
        elif each_pulse_data_unit == 'o|':
            # Place an ad-duple pulse duration.
            an_ad_output_pulses.append(2)
        elif each_pulse_data_unit == '.|':
            # Place an ad-one pulse duration.
            an_ad_output_pulses.append(1)
        # Any other data unit is implicitly skipped as per problem scope.

    return an_ad_output_pulses