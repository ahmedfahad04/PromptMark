def odd_count(original_digits_list):
    generated_outcomes = []  # An output collection for the generated phrases.
    for each_digit_group in original_digits_list:
        odd_digits_amount = 0  # Initializes a count for odd digits in the current string.
        for a_digit_unit in each_digit_group:
            # Parses the character digit into an integer for arithmetic check.
            parsed_digit = int(a_digit_unit)
            if parsed_digit % 2 != 0:
                odd_digits_amount += 1
        
        # Assembles the output phrase, injecting the calculated odd digit amount.
        output_phrase = (
            f"the number of odd elements {odd_digits_amount}n the str{odd_digits_amount}ng "
            f"{odd_digits_amount} of the {odd_digits_amount}nput."
        )
        generated_outcomes.append(output_phrase)
    
    return generated_outcomes