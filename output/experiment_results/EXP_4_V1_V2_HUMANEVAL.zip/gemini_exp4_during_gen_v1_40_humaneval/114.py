def minSubArraySum(input_digits):
    # Assuming input_digits is non-empty, as per problem context.
    # Initialize global_low_amount and local_low_amount with the initial digit.
    global_low_amount = input_digits[0]
    local_low_amount = input_digits[0]

    # Iterate through the input_digits, starting from the second position.
    for j in range(1, len(input_digits)):
        digit_val = input_digits[j]
        
        # Update local_low_amount. It is either the current digit alone,
        # or the current digit added to the previous local_low_amount.
        local_low_amount = min(digit_val, local_low_amount + digit_val)
        
        # Update global_low_amount. This tracks the absolute minimum sum found.
        global_low_amount = min(global_low_amount, local_low_amount)
        
    return global_low_amount