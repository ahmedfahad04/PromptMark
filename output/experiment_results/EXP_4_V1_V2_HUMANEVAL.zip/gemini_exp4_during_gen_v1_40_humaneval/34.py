def unique(l: list):
    # Obtain unique elements.
    elements_pool = set(l)
    # Generate an ordered list.
    ordered_data = list(elements_pool)
    ordered_data.sort()
    # Deliver output.
    return ordered_data