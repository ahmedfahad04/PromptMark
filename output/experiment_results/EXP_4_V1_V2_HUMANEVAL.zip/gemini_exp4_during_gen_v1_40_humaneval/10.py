def is_palindrome(string: str) -> bool:
    return string == string[::-1]


def make_palindrome(string: str) -> str:
    given_data = string
    data_length = len(given_data)

    if data_length == 0:
        return ""

    # Iterate to identify longest palindromic end_part
    for idx_outer in range(data_length):
        end_part = given_data[idx_outer:]
        if is_palindrome(end_part):
            # Locate prefix ahead of palindromic end_part
            leading_part_to_invert = given_data[:idx_outer]
            
            # Invert leading segment
            inverted_leading_part = leading_part_to_invert[::-1]
            
            # Join original data with inverted leading segment
            final_output = given_data + inverted_leading_part
            return final_output