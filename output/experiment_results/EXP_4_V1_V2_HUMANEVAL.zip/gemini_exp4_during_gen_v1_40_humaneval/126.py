import collections

def is_sorted(input_data):
    # Assess item count limit.
    # An item allows two occurrences, at most.
    # If item occurs greater than two times, give False.
    item_counts = collections.Counter(input_data)
    for item_value, occurences in item_counts.items():
        if occurences > 2:
            return False

    # Assess increasing order.
    # An empty list, or one-item list, is considered in order.
    data_length = len(input_data)
    if data_length <= 1:
        return True

    # Go over data, comparing item pairs.
    for index_pos in range(data_length - 1):
        going_item = input_data[index_pos]
        later_item = input_data[index_pos + 1]
        if going_item > later_item:
            return False

    # If all checks pass, given list is in order.
    return True