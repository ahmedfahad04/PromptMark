def max_element(l: list):
    # Assume input list is non-empty.
    # Initialize apex_element using the initial item.
    apex_element = l[0]

    # Iterate through other list items.
    for e in l[1:]:
        # If current item is greater, update apex_element.
        if e > apex_element:
            apex_element = e
    return apex_element