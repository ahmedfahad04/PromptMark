def fizz_buzz(n: int):
    # Overall accumulator. Digests digit data.
    all_digit_occurrences = 0

    # Iterate up a given limit.
    for i in range(1, n):
        # Examine divisibility, a logic applied.
        if i % 11 == 0 or i % 13 == 0:
            # Acquire data. An integer as digits, a lookup.
            a_parsed_data = str(i)
            # Add digits. Overall data, an integer lookup.
            all_digit_occurrences += a_parsed_data.count('7')

    # Deliver overall digit occurrences.
    return all_digit_occurrences