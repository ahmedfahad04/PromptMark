def add(input_data: list[int]) -> int:
    overall_add: int = 0
    # Iterates over each element with its index.
    for idx, an_element in enumerate(input_data):
        # Examines if the current index is odd.
        if idx % 2 != 0:
            # Also examines if the element at this odd index is even.
            if an_element % 2 == 0:
                overall_add += an_element
    return overall_add