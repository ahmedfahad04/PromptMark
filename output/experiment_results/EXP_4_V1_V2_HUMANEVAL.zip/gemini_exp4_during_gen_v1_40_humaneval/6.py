from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    all_depths: List[int] = []
    # group input by spaces
    all_groups = paren_string.split(' ')

    for each_group in all_groups:
        actual_depth = 0
        deepest_level = 0
        for one_char in each_group:
            if one_char == '(':
                actual_depth += 1
                deepest_level = max(deepest_level, actual_depth)
            elif one_char == ')':
                actual_depth -= 1
        all_depths.append(deepest_level)
    return all_depths