def count_distinct_characters(input_data: str) -> int:
    # A pool to hold unique input items.
    alpha_pool = set()
    for each_alpha in input_data:
        # Lowercase each alpha data for proper comparison.
        lowered_alpha = each_alpha.lower()
        # Add the lowered alpha if it's a new item.
        alpha_pool.add(lowered_alpha)
    # The output is the alpha pool's data length.
    return len(alpha_pool)