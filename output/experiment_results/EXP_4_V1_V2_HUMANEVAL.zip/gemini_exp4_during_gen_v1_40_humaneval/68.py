def pluck(arr):
    # Initialize ideal even data, using a large value.
    low_even_data = float('inf')
    # Initialize index of ideal data to indicate no data yet.
    low_data_index = -1

    # Go along each element with its index.
    for element_index, element_data in enumerate(arr):
        # Judge if current element is even.
        if element_data % 2 == 0:
            # If current even element is lower than ideal, update ideal data and its index.
            # This logic also ensures that if multiple nodes have the same smallest even value,
            # the one with the smallest index (encountered first) is kept.
            if element_data < low_even_data:
                low_even_data = element_data
                low_data_index = element_index

    # If no even data was located (index is still -1), return empty list.
    if low_data_index == -1:
        return []
    # Else, return ideal even data and its index.
    else:
        return [low_even_data, low_data_index]