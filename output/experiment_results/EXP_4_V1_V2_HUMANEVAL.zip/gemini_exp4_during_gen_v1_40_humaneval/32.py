import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


def find_zero(xs: list):
    # Using Bisection method to locate a root.
    # Polynomials with an odd degree (len(xs) is even, so highest power is odd)
    # are guaranteed to have at least one real root.

    # Define an acceptable difference for an approximate zero.
    a_epsilon_delta = 1e-6 

    # Define an initial large interval for searching a root.
    low_limit_idx = -1000.0
    upp_limit_idx = 1000.0

    # Evaluate the polynomial at the initial limits.
    val_at_low = poly(xs, low_limit_idx)
    val_at_upp = poly(xs, upp_limit_idx)

    # If by chance, one of the limits is already a root or very close.
    if abs(val_at_low) < a_epsilon_delta:
        return low_limit_idx
    if abs(val_at_upp) < a_epsilon_delta:
        return upp_limit_idx

    # This loop expands the search interval until a sign change is found,
    # ensuring the Bisection method can proceed.
    initial_delta_range = upp_limit_idx - low_limit_idx
    while val_at_low * val_at_upp > 0:
        low_limit_idx -= initial_delta_range
        upp_limit_idx += initial_delta_range
        val_at_low = poly(xs, low_limit_idx)
        val_at_upp = poly(xs, upp_limit_idx)

        # Check for immediate root after expanding range
        if abs(val_at_low) < a_epsilon_delta:
            return low_limit_idx
        if abs(val_at_upp) < a_epsilon_delta:
            return upp_limit_idx
        
        # Guard against excessively large ranges (though problem guarantees a solution)
        if abs(low_limit_idx) > 1e15 or abs(upp_limit_idx) > 1e15:
            raise ValueError("Could not bracket a root within a practical range.")


    # Bisection iteration loop
    max_iter_limit = 1000 
    iter_idx = 0 

    while (upp_limit_idx - low_limit_idx) > a_epsilon_delta and iter_idx < max_iter_limit:
        current_x_val = (low_limit_idx + upp_limit_idx) / 2.0
        val_at_curr = poly(xs, current_x_val)

        if abs(val_at_curr) < a_epsilon_delta:
            return current_x_val

        # Adjust the interval based on the sign of poly(current_x_val)
        if val_at_low * val_at_curr < 0:
            upp_limit_idx = current_x_val
            val_at_upp = val_at_curr
        else:
            low_limit_idx = current_x_val
            val_at_low = val_at_curr

        iter_idx += 1

    # Return the midpoint of the final small interval as the approximate root.
    return (low_limit_idx + upp_limit_idx) / 2.0