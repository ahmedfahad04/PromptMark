def encrypt(original_data):
    # Alpha jump delta.
    delta_value = 2 * 2 
    
    # List of output data.
    encrypted_list = []
    
    # Loop each item in data.
    for each_letter in original_data:
        # Is item an alpha?
        if each_letter.isalpha():
            original_ordinal = ord(each_letter)
            
            if each_letter.islower():
                adjusted_ordinal = ((original_ordinal - ord('a') + delta_value) % 26) + ord('a')
            else:  # Assumed uppercase.
                adjusted_ordinal = ((original_ordinal - ord('A') + delta_value) % 26) + ord('A')
            
            encrypted_list.append(chr(adjusted_ordinal))
        else:
            encrypted_list.append(each_letter)
            
    return "".join(encrypted_list)