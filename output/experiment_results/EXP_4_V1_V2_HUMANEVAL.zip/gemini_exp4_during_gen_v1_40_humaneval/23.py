def strlen(input_data: str) -> int:
    # An easy operation.
    # Acknowledging input_data's length.
    return len(input_data)