from typing import List


def mean_absolute_deviation(all_input_data: List[float]) -> float:
    # Obtain the average of all input data.
    data_count = len(all_input_data)
    if data_count == 0:
        return 0.0

    all_data_sum = sum(all_input_data)
    data_average = all_data_sum / data_count

    # Generate all absolute differences from the average.
    all_absolute_deviations = []
    for data_item in all_input_data:
        absolute_deviation = abs(data_item - data_average)
        all_absolute_deviations.append(absolute_deviation)

    # Do average calculation of all absolute deviations.
    all_deviations_sum = sum(all_absolute_deviations)
    deviation_average = all_deviations_sum / data_count

    return deviation_average