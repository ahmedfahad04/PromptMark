def how_many_times(input_data: str, pattern_data: str) -> int:
    occurrences_amount = 0
    length_input = len(input_data)
    length_pattern = len(pattern_data)

    if length_pattern > length_input:
        return 0

    # Iterate through each potential initial point
    for idx in range(length_input - length_pattern + 1):
        # If an exact match is located
        if input_data[idx : idx + length_pattern] == pattern_data:
            occurrences_amount += 1

    return occurrences_amount