def fibfib(input_data_idx: int) -> int:
    if input_data_idx == 0:
        return 0
    if input_data_idx == 1:
        return 0
    if input_data_idx == 2:
        return 1

    # Initial elements
    oldest_data_elem = 0  # Oldest known data element.
    older_data_elem = 0   # Older known data element.
    latest_data_elem = 1  # Latest known data element.

    for local_idx_iterator in range(3, input_data_idx + 1):
        # Calculate each loop's data element
        loop_data_elem = latest_data_elem + older_data_elem + oldest_data_elem

        # Update elements
        oldest_data_elem = older_data_elem
        older_data_elem = latest_data_elem
        latest_data_elem = loop_data_elem
    
    return latest_data_elem