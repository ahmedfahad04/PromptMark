def special_factorial(an_upper_value: int) -> int:
    """Calculates the special (Brazilian) factorial of an integer.
    """

    def do_general_factorial(a_digit_value: int) -> int:
        """Aids in calculating the general factorial of a single digit."""
        a_local_product = 1
        for idx in range(1, a_digit_value + 1):
            a_local_product *= idx
        return a_local_product

    an_overall_product = 1
    # Iterates downwards from the given upper value to 1
    for idx_down in range(an_upper_value, 0, -1):
        a_partial_factorial = do_general_factorial(idx_down)
        an_overall_product *= a_partial_factorial

    return an_overall_product