from typing import List


def separate_paren_groups(input_paren_data: str) -> List[str]:
    overall_groups: List[str] = []
    active_group_data: str = ""
    group_level_indicator: int = 0

    for each_unit_parsed in input_paren_data:
        if each_unit_parsed == ' ':
            continue

        if each_unit_parsed == '(':
            group_level_indicator += 1
            active_group_data += each_unit_parsed
        elif each_unit_parsed == ')':
            group_level_indicator -= 1
            active_group_data += each_unit_parsed

        # If the indicator is zero, a complete, top-level group is identified.
        if group_level_indicator == 0:
            overall_groups.append(active_group_data)
            active_group_data = ""

    return overall_groups