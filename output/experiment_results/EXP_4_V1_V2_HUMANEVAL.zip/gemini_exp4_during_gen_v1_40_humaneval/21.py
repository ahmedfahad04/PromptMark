from typing import List


def rescale_to_unit(numbers: List[float]) -> List[float]:
    # Locate low and peak points.
    low_point = min(numbers)
    peak_point = max(numbers)

    # Ascertain gap using peak and low points.
    gap = peak_point - low_point

    adjusted_data = []

    if gap == 0:
        # Given equal elements, all are 0.0.
        for _ in numbers:
            adjusted_data.append(0.0)
    else:
        # Linear adjustment applied.
        for each_element in numbers:
            output_point = (each_element - low_point) / gap
            adjusted_data.append(output_point)

    return adjusted_data