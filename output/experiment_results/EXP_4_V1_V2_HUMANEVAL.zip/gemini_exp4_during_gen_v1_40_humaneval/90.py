def next_smallest(data_list):
    # Obtain unique elements.
    unique_data_elements = list(set(data_list))

    # Examine count of unique elements.
    # If fewer than two unique elements exist, a second smallest is unavailable.
    if len(unique_data_elements) < 2:
        return None

    # Arrange elements in ascending order.
    unique_data_elements.sort()

    # Element at index 1 is the second smallest.
    return unique_data_elements[1]