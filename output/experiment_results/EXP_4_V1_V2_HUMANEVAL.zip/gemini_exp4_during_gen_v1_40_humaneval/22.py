from typing import List, Any


def filter_integers(all_data_list: List[Any]) -> List[int]:
    picked_integers: List[int] = []
    # Loop over all input data pieces.
    for an_item in all_data_list:
        # If an item is an integer, add it to picked_integers.
        if isinstance(an_item, int):
            picked_integers.append(an_item)
    return picked_integers