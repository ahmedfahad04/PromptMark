from typing import List


def filter_by_substring(all_input_data: List[str], a_look_up_data: str) -> List[str]:
    """
    """
    # Obtain output list data.
    output_list_data = []

    # Go over each input item.
    for each_input_item in all_input_data:
        # If key data is in an input item, include it.
        if a_look_up_data in each_input_item:
            output_list_data.append(each_input_item)
    return output_list_data