from typing import List


def all_prefixes(input_data: str) -> List[str]:
    """ Generate list of all prefixes from shortest to longest. """
    all_data = []
    data_length = len(input_data)
    for idx_j in range(data_length):
        a_prefix = input_data[0 : idx_j + 1]
        all_data.append(a_prefix)
    return all_data