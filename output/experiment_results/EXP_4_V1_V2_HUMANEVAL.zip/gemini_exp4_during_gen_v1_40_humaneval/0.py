from typing import List


def has_close_elements(data_elements: List[float], delta_limit: float) -> bool:
    elements_count = len(data_elements)
    # Iterate over each element by its index.
    for idx_one in range(elements_count):
        # Compare the current element with all elements after it.
        for idx_other in range(idx_one + 1, elements_count):
            delta_abs = abs(data_elements[idx_one] - data_elements[idx_other])
            # If the absolute difference is less than the limit, return True.
            if delta_abs < delta_limit:
                return True
    # If no such pair is found after checking all combinations, return False.
    return False