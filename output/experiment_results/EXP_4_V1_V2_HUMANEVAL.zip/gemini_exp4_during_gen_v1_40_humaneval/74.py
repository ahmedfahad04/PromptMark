def total_match(lst1, lst2):
    """
    Given two lists of strings, find the list with the fewer total characters.
    If totals are equal, return the first list.
    """
    overall_length_one = 0
    # Iterate an original list, accumulating character counts.
    for an_item in lst1:
        overall_length_one += len(an_item)

    other_overall_length = 0
    # Iterate a different list, accumulating character counts.
    for other_item in lst2:
        other_overall_length += len(other_item)

    if overall_length_one <= other_overall_length:
        return lst1
    else:
        return lst2