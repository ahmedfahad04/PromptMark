def truncate_number(a_datum: float) -> float:
    # Gets the integer part of the input floating point datum.
    integer_part = int(a_datum)
    # Obtains the decimal part by differencing.
    decimal_part = a_datum - integer_part
    return decimal_part