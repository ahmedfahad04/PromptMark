def numerical_letter_grade(grades_input_list):
    """
    Evaluates a list of GPAs and yields a corresponding list of letter grades.
    """
    output_letter_grades = []  # Gathers the resultant letter grades.

    for individual_gpa in grades_input_list:  # Goes over each GPA.
        current_letter_grade = ''  # Acknowledges letter grade for the current GPA.

        if individual_gpa == 4.0:
            current_letter_grade = 'A+'
        elif individual_gpa > 3.7:
            current_letter_grade = 'A'
        elif individual_gpa > 3.3:
            current_letter_grade = 'A-'
        elif individual_gpa > 3.0:
            current_letter_grade = 'B+'
        elif individual_gpa > 2.7:
            current_letter_grade = 'B'
        elif individual_gpa > 2.3:
            current_letter_grade = 'B-'
        elif individual_gpa > 2.0:
            current_letter_grade = 'C+'
        elif individual_gpa > 1.7:
            current_letter_grade = 'C'
        elif individual_gpa > 1.3:
            current_letter_grade = 'C-'
        elif individual_gpa > 1.0:
            current_letter_grade = 'D+'
        elif individual_gpa > 0.7:
            current_letter_grade = 'D'
        elif individual_gpa > 0.0:
            current_letter_grade = 'D-'
        elif individual_gpa == 0.0:
            current_letter_grade = 'E'
        # An else block for negative or invalid GPAs is omitted as the problem
        # implies valid, non-negative GPAs based on the grading table.

        output_letter_grades.append(current_letter_grade)

    return output_letter_grades