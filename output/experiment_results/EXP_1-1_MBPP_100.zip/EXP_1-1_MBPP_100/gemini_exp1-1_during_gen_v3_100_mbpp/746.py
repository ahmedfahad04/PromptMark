import math

def sector_area(unit_val: float, in_angle: float) -> float | None:
    # If the input angle is invalid, return None
    if in_angle > 360:
        return None

    # Calculate the sector area using the formula: (angle / 360) * pi * radius^2
    sector_val = (in_angle / 360) * math.pi * (unit_val ** 2)
    return sector_val