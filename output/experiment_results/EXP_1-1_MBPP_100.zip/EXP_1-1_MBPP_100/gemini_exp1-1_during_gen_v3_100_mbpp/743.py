def rotate_right(univ_input, num_items):
    univ_len = len(univ_input)

    # Handle an empty input or zero rotations without further processing
    if univ_len == 0:
        return []

    # Calculate the effective number of rotations needed
    actual_k = num_items % univ_len

    # If actual_k is 0, no rotation is needed; return a copy of the original list.
    if actual_k == 0:
        return list(univ_input)

    # Determine the index where the list should be split
    cut_idx = univ_len - actual_k

    # Create the initial chunk (items that move to the front)
    initial_chunk = univ_input[cut_idx:]
    # Create the main chunk (items that move to the end)
    main_chunk = univ_input[:cut_idx]
    
    # Combine the chunks in the new order
    output_univ = initial_chunk + main_chunk
    return output_univ