def extract_quotation(input_string: str) -> list[str]:
    my_values = []
    current_index = 0
    input_char_count = len(input_string)

    while current_index < input_char_count:
        # Find the opening double quotation mark
        open_mark_index = input_string.find('"', current_index)

        # If no opening mark is found, all pairs have been processed or none exist
        if open_mark_index == -1:
            break

        # Find the closing double quotation mark after the opening one
        close_mark_index = input_string.find('"', open_mark_index + 1)

        # If no closing mark is found, it's an unmatched quotation, so stop
        if close_mark_index == -1:
            break

        # Extract the content between the marks
        my_item_unit = input_string[open_mark_index + 1:close_mark_index]
        my_values.append(my_item_unit)

        # Advance the search position past the current closing mark
        current_index = close_mark_index + 1

    return my_values