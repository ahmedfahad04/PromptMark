def extract_singly(input_val):
    union_set = set()
    for sub_collection in input_val:
        for num_val in sub_collection:
            union_set.add(num_val)
    return union_set