import re

def text_match_wordz(input_unit: str) -> bool:
    # This pattern identifies any word containing 'z'.
    # \b asserts a word boundary.
    # \w* matches zero or more word characters (alphanumeric + underscore).
    # z matches the literal character 'z'.
    any_pat = r'\b\w*z\w*\b'
    match_obj = re.search(any_pat, input_unit)
    # Returns True if a match is found, False otherwise.
    return bool(match_obj)