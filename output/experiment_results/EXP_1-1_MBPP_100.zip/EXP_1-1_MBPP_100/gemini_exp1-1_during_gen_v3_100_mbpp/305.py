def start_withp(word_inputs):
    chosen_words = []
    # Iterate through each input string
    for input_str in word_inputs:
        # Split the string into individual words
        many_words = input_str.split()
        for w_unit in many_words:
            # Check if the word starts with 'p' (case-insensitive)
            if w_unit.lower().startswith('p'):
                chosen_words.append(w_unit)
                # Return once two words are found
                if len(chosen_words) == 2:
                    return tuple(chosen_words)