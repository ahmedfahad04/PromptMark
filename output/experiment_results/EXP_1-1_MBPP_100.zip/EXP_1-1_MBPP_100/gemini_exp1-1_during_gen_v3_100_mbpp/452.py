def loss_amount(sale_amount, cost_amount):
    # Calculate loss if sale amount is less than cost amount
    if sale_amount < cost_amount:
        return cost_amount - sale_amount
    else:
        # No loss (or profit) occurred, so return 0
        return 0