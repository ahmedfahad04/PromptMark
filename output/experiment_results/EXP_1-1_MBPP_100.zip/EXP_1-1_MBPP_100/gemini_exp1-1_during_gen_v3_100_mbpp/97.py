def frequency_lists(input_matrix):
    output_counts = {}
    for inner_list in input_matrix:
        for item_val in inner_list:
            output_counts[item_val] = output_counts.get(item_val, 0) + 1
    return output_counts