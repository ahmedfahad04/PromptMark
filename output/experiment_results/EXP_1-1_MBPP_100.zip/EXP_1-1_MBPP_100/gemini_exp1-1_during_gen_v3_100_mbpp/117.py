def list_to_float(my_input):
    output_array = [] # A collection for all new units
    for current_unit in my_input: # Iterate over each inner unit
        new_unit_items = [] # A collection for items in the current new unit
        for an_item in current_unit: # Iterate over each item within the unit
            try:
                # Attempt to convert the item to a float
                new_unit_items.append(float(an_item))
            except ValueError:
                # If conversion fails, keep the original item
                new_unit_items.append(an_item)
        # Convert the list of new items back to a tuple and add to the main output
        output_array.append(tuple(new_unit_items))
    return output_array