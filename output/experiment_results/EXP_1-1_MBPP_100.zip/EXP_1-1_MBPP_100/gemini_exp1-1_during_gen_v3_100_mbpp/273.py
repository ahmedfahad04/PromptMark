def substract_elements(input_one, input_two):
    # Initializes a mutable list to accumulate the differences
    new_values = []
    # Iterates through corresponding elements from both input tuples
    for val_one, val_two in zip(input_one, input_two):
        # Calculates the difference and adds it to the list
        new_values.append(val_one - val_two)
    # Converts the list of differences into a new tuple and returns it
    return tuple(new_values)