def square_Sum(n: int) -> int:
    """
    Calculates the sum of the squares of the first n odd natural numbers.
    """
    accum = 0
    # Iterate 'n' times to sum squares of the first 'n' odd numbers
    for j in range(n):
        # Calculate the current odd number: 1, 3, 5, ...
        my_num = (2 * j) + 1
        # Calculate its square
        sq_num = my_num * my_num
        # Add the square to the running total
        accum = accum + sq_num
    return accum