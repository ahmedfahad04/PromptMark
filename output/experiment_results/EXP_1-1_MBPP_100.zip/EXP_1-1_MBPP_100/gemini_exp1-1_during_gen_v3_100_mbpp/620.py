def largest_subset(input_nums):
    # If the input collection is empty, the largest subset size is 0.
    if not input_nums:
        return 0

    # Sort the numbers to simplify divisibility checks.
    # If a < b < c and a divides b and b divides c, then a also divides c.
    # This ordering enables dynamic programming to build subsets incrementally.
    num_values = sorted(input_nums)
    num_count = len(num_values)

    # Initialize a DP array where each entry max_counts[i] stores the size
    # of the largest divisible subset that ends with num_values[i].
    # A single number always forms a subset of size 1.
    max_counts = [1] * num_count

    # Iterate through each number to calculate the max_counts for subsets ending with it.
    for curr_idx in range(num_count):
        for prev_idx in range(curr_idx):
            # If the current number is divisible by a previous number,
            # it means we can potentially extend the subset ending at prev_idx.
            if num_values[curr_idx] % num_values[prev_idx] == 0:
                # Update max_counts[curr_idx] if a larger subset is found.
                max_counts[curr_idx] = max(max_counts[curr_idx], 1 + max_counts[prev_idx])

    # The maximum value in the max_counts array represents the size of the largest
    # divisible subset found overall.
    overall_max = 0
    if max_counts:
        overall_max = max(max_counts)

    return overall_max