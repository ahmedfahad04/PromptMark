def median_trapezium(side_one, side_two, _junk_val):
    # Median length of a trapezium is the average of its two parallel sides.
    # The third input value (_junk_val) is not used for this calculation.
    return (side_one + side_two) / 2