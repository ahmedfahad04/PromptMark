def remove_Occ(input_way, symbol_unit):
    # Find the initial occurrence of the symbol_unit
    initial_idx = input_way.find(symbol_unit)

    current_way = input_way
    if initial_idx != -1:
        # Create a new string with the initial occurrence removed
        current_way = input_way[:initial_idx] + input_way[initial_idx+1:]

    # Find the final occurrence of the symbol_unit in the current string
    final_idx = current_way.rfind(symbol_unit)

    if final_idx != -1:
        # Create a new string with the final occurrence removed
        current_way = current_way[:final_idx] + current_way[final_idx+1:]

    return current_way