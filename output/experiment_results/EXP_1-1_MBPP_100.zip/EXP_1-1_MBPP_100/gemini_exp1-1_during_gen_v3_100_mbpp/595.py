def min_Swaps(s_val1: str, s_val2: str) -> int | str:
    # Check if string lengths are unequal
    unit_count = len(s_val1)
    if unit_count != len(s_val2):
        return "Not Possible"

    # Count '1's in both strings
    ones_count1 = s_val1.count('1')
    ones_count2 = s_val2.count('1')

    # If the counts of '1's (and thus '0's) are different, transformation is impossible.
    # This means we cannot achieve s_val2 from s_val1 by just swapping characters.
    if ones_count1 != ones_count2:
        return "Not Possible"

    # Initialize counters for specific types of mismatches
    mismatched_one_to_zero_nums = 0  # s_val1 has '1', but s_val2 has '0' at this index
    mismatched_zero_to_one_nums = 0  # s_val1 has '0', but s_val2 has '1' at this index

    # Iterate through strings to find positions where characters differ
    for j in range(unit_count):
        if s_val1[j] == '1' and s_val2[j] == '0':
            mismatched_one_to_zero_nums += 1
        elif s_val1[j] == '0' and s_val2[j] == '1':
            mismatched_zero_to_one_nums += 1

    # If the total counts of '1's and '0's are the same in both strings,
    # then the number of '1's that need to become '0's must equal
    # the number of '0's that need to become '1's.
    # Each swap can fix one '1' -> '0' mismatch and one '0' -> '1' mismatch simultaneously.
    # Thus, the minimum number of swaps required is simply this count.
    return mismatched_one_to_zero_nums