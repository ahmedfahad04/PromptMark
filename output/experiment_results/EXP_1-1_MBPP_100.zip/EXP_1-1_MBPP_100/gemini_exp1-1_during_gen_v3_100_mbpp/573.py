def unique_product(input_numbers: list[int]) -> int:
    # Obtain unique numbers using a set to handle duplicates
    unique_nums = set(input_numbers)

    # Initialize the product; start with 1 so multiplication works correctly
    curr_product = 1
    for num in unique_nums:
        curr_product *= num
        
    return curr_product