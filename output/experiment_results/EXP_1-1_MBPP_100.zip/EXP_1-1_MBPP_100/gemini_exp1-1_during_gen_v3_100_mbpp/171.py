def perimeter_pentagon(a):
    # A regular pentagon has 5 equal sides.
    # The perimeter is the sum of the lengths of all its sides.
    ans = 5 * a
    return ans