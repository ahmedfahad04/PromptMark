def check_element(input_units, main_unit):
    # Check if all units within the input_units list match the main_unit.
    # The 'all()' function returns True for an empty iterable.
    return all(a_unit == main_unit for a_unit in input_units)