def remove_lowercase(my_input_string: str) -> str:
    ans_string = ""
    for unit in my_input_string:
        if unit.isupper():
            ans_string += unit
    return ans_string