def remove_dirty_chars(input_main, input_chars):
    # Create a set of characters to be removed for efficient lookup.
    chars_to_avoid_set = set(input_chars)

    # Initialize an array to collect characters that are not "dirty".
    output_chars_array = []

    # Iterate through each character in the main input string.
    for char_item in input_main:
        # If the character is not in the set of chars to avoid, add it to our output array.
        if char_item not in chars_to_avoid_set:
            output_chars_array.append(char_item)
    
    # Join the characters in the array to form the final clean string.
    return "".join(output_chars_array)