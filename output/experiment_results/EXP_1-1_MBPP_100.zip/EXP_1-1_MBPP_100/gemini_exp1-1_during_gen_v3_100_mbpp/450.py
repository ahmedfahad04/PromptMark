def extract_string(my_strings: list[str], input_size: int) -> list[str]:
    # Collects strings matching the input size
    output_strings = []
    for a_string in my_strings:
        current_len = len(a_string)
        if current_len == input_size:
            output_strings.append(a_string)
    return output_strings