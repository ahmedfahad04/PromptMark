def count_rotation(my_array: list[int]) -> int:
    """
    Calculates the number of rotations required to obtain the current array
    from its sorted version. This is identified by the index of the first
    element that is smaller than its predecessor.

    Args:
        my_array: A list of integers.

    Returns:
        The number of rotations. Returns 0 if the array is already sorted.
    """
    num_items = len(my_array)

    # An array with 0 or 1 item is always sorted, so 0 rotations.
    if num_items <= 1:
        return 0

    # Iterate through the array to find the point where the ascending order breaks.
    # The index of this break point is the number of rotations.
    for idx in range(1, num_items):
        if my_array[idx] < my_array[idx - 1]:
            return idx

    # If no such point is found, the array is already sorted.
    return 0