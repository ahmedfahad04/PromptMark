def average_tuple(input_values):
    output_averages = []

    num_rows = len(input_values)
    if num_rows == 0:
        return []

    # Assumes all inner tuples have a consistent, non-zero length.
    num_columns = len(input_values[0])

    for col_index in range(num_columns):
        current_column_sum = 0
        for row_index in range(num_rows):
            current_column_sum += input_values[row_index][col_index]

        avg_value = current_column_sum / num_rows
        output_averages.append(avg_value)

    return output_averages