def check_monthnumb_number(monthnumb: int) -> bool:
    # A set of month numbers that contain 31 days.
    many_days_months = {1, 3, 5, 7, 8, 10, 12}
    return monthnumb in many_days_months