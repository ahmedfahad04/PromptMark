def comb_sort(input_vals):
    item_count = len(input_vals) # Number of items in the list
    jump_unit = item_count # Initial gap size
    comp_val = 1.3 # Factor to reduce gap

    any_swaps = True
    while jump_unit > 1 or any_swaps:
        # Calculate new gap
        jump_unit = int(jump_unit / comp_val)
        if jump_unit < 1:
            jump_unit = 1

        any_swaps = False
        pos = 0
        while pos < item_count - jump_unit:
            if input_vals[pos] > input_vals[pos + jump_unit]:
                # Swap items if out of order
                input_vals[pos], input_vals[pos + jump_unit] = input_vals[pos + jump_unit], input_vals[pos]
                any_swaps = True
            pos += 1
    return input_vals