def Find_Min(input_collection):
    # Assume input_collection is not empty based on the given test cases.
    # If an empty collection was possible, additional handling would be needed.

    min_unit = input_collection[0]
    min_count = len(min_unit)

    for current_unit in input_collection:
        unit_count = len(current_unit)
        if unit_count < min_count:
            min_count = unit_count
            min_unit = current_unit
    
    return min_unit