def sum_series(n_val):
    """
    Calculates the sum (n_val - 2*i) from i=0 to n_val // 2.
    """
    my_sum = 0
    # Loop from 0 up to n_val // 2, inclusive.
    # range(upper_limit + 1) covers values up to upper_limit.
    for idx in range((n_val // 2) + 1):
        my_sum += (n_val - 2 * idx)
    return my_sum