def is_sublist(main_array, mini_array):
    # An empty sublist is always considered a sublist
    if not mini_array:
        return True

    # If the sublist is longer than the main array, it cannot be a sublist
    if len(mini_array) > len(main_array):
        return False

    # Iterate through the main array to find a potential starting point
    # We only need to check up to the point where mini_array can still fit
    for idx in range(len(main_array) - len(mini_array) + 1):
        # Check if the slice of main_array matches mini_array
        if main_array[idx : idx + len(mini_array)] == mini_array:
            return True
            
    # If no match was found after checking all possibilities
    return False