def subject_marks(input_values):
    # Sorts the input list of tuples using the second value of each tuple.
    # The 'key' argument uses a lambda function to specify the sorting criteria.
    # It tells the sort function to look at the element at index 1 (the second value)
    # of each tuple for comparison.
    sorted_values = sorted(input_values, key=lambda current_item: current_item[1])
    return sorted_values