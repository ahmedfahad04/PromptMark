def find_First_Missing(input_array):
    # Check if the array is empty or if its first item is not 0.
    # If either is true, then 0 is the smallest missing natural number.
    if not input_array or input_array[0] != 0:
        return 0

    # Iterate through the array using both index and value.
    # We aim to find the first instance where the value at an index `i` is not equal to `i`.
    # For a sorted list of natural numbers starting from 0, `input_array[i]` should ideally be `i`.
    for i, val in enumerate(input_array):
        if val != i:
            # If a mismatch is found, `i` is the smallest missing number.
            return i

    # If the loop completes without finding any mismatch, it means all numbers
    # from 0 up to `len(input_array) - 1` are present in the array.
    # In this case, the smallest missing number is simply the length of the array.
    # For example, if input_array is [0, 1, 2, 3], its length is 4, and 4 is the missing number.
    return len(input_array)