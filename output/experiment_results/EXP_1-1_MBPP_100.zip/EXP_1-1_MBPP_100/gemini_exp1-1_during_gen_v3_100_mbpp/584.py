import re

def find_adverbs(input_string_val: str) -> str | None:
    # Use regular expressions to find all word-like sequences and their spans.
    # \b matches word boundaries, \w+ matches one or more word characters,
    # ensuring punctuation is not included in the matched word.
    for uni_match in re.finditer(r'\b\w+\b', input_string_val):
        word_val = uni_match.group(0)
        index_start = uni_match.start()
        index_end = uni_match.end()

        # Check if the extracted word ends with 'ly', ignoring case.
        if word_val.lower().endswith('ly'):
            # If an adverb is found, construct the output string as "start-end: word".
            return f"{index_start}-{index_end}: {word_val}"

    # If no adverb ending with 'ly' is found after checking all words, return None.
    return None