def pair_wise(input_units):
    many_couples = []
    # Iterate through the input_units list, pairing each item with its successor.
    # Using zip with a sliced list creates (item_N, item_N+1) pairs.
    for i, j in zip(input_units, input_units[1:]):
        many_couples.append((i, j))
    return many_couples