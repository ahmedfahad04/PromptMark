def square_nums(nums_in):
    # Compute the square of each number using a list comprehension.
    output_vals = [num_v * num_v for num_v in nums_in]
    return output_vals