import re

def text_lowercase_underscore(input_val):
    # This pattern checks if the entire string consists of:
    # ^   - Start of the string
    # [a-z]+ - One or more lowercase English letters
    # _   - A literal underscore character
    # [a-z]+ - One or more lowercase English letters
    # $   - End of the string
    # re.fullmatch returns a match object if the entire string matches the pattern,
    # otherwise it returns None. bool() converts the match object (or None) to True/False.
    return bool(re.fullmatch(r"^[a-z]+_[a-z]+$", input_val))