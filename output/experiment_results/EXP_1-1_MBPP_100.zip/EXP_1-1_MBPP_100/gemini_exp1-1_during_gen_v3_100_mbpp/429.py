def and_tuples(input_one, input_two):
    join_nums = []
    # Iterate through corresponding numbers from both tuples
    for my_num_a, my_num_b in zip(input_one, input_two):
        # Perform element-wise bitwise AND operation
        and_num = my_num_a & my_num_b
        join_nums.append(and_num)
    # Convert the list of results into a tuple and return
    return tuple(join_nums)