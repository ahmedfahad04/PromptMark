import math

def is_perfect_square(num_val):
    """
    Checks if a given number is a perfect square.
    A perfect square is an integer that is the square of an integer.
    For example, 9 is a perfect square because it is 3*3.
    """
    if num_val < 0:
        # Negative numbers cannot be perfect squares in integers.
        return False
    
    if num_val == 0:
        # 0 is a perfect square (0 * 0 = 0).
        return True

    # Calculate the integer square root of the number.
    # math.isqrt is efficient for large integer inputs.
    int_val = math.isqrt(num_val)

    # A number is a perfect square if the square of its integer square root
    # is equal to the original number.
    return int_val * int_val == num_val