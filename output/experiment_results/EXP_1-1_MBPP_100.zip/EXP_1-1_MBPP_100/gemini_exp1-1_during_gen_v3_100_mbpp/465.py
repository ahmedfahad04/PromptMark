def drop_empty(any_mapping: dict) -> dict:
    valid_items = {}
    for my_key, my_value in any_mapping.items():
        if my_value is not None:
            valid_items[my_key] = my_value
    return valid_items