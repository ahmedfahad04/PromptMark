def rectangle_area(width, y_dim):
    # Calculate the area by multiplying the width and y_dimension
    an_area = width * y_dim
    return an_area