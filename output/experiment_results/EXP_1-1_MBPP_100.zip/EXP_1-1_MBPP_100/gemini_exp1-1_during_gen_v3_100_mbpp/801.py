def test_three_equal(num_a, num_j, num_c):
    count = 0
    if num_a == num_j and num_j == num_c:
        count = 3
    elif num_a == num_j or num_a == num_c or num_j == num_c:
        count = 2
    return count