def mul_even_odd(main_nums):
    an_even_num = None  # Stores the first even number found.
    an_odd_num = None   # Stores the first odd number found.

    # Iterate through each number in the input collection.
    for a_num in main_nums:
        if a_num % 2 == 0:  # Check if the number is even.
            if an_even_num is None: # If an even number hasn't been found yet.
                an_even_num = a_num
        else:  # The number is odd.
            if an_odd_num is None: # If an odd number hasn't been found yet.
                an_odd_num = a_num

        # If both the first even and first odd numbers are identified,
        # exit the loop early for efficiency.
        if an_even_num is not None and an_odd_num is not None:
            break

    # Calculate and return the product of the two found numbers.
    # The problem implies that both an even and an odd number will always be present.
    return an_even_num * an_odd_num