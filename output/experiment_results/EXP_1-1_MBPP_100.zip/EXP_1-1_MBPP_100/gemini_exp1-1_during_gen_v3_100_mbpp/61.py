def count_Substrings(input_string: str) -> int:
    """
    Counts the number of substrings where the sum of digits equals their length.
    """
    count_valid = 0
    input_size = len(input_string)

    # Iterate through all possible starting positions of substrings
    for i in range(input_size):
        current_sum = 0
        # Iterate through all possible ending positions for substrings starting at 'i'
        for j in range(i, input_size):
            # Convert the current character to an integer and add to sum
            num_val = int(input_string[j])
            current_sum += num_val

            # Calculate the length of the current substring
            sub_len = j - i + 1

            # Check if the sum of digits equals the substring's length
            if current_sum == sub_len:
                count_valid += 1
    return count_valid