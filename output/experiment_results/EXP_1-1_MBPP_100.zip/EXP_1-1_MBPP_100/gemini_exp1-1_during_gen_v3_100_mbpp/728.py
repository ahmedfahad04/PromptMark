def sum_list(input_a, input_b):
    sum_array = []
    # Assumes input_a and input_b have identical lengths
    for i in range(len(input_a)):
        my_sum = input_a[i] + input_b[i]
        sum_array.append(my_sum)
    return sum_array