def group_tuples(input_tuples):
    items_mapping = {}

    for current_item in input_tuples:
        common_key, value_item = current_item # Unpack tuple elements.

        if common_key in items_mapping:
            items_mapping[common_key].append(value_item)
        else:
            items_mapping[common_key] = [value_item]

    output_collection = []

    for common_key, value_items in items_mapping.items():
        # Combine the common key with its associated values into a new tuple.
        new_tuple_item = (common_key,) + tuple(value_items)
        output_collection.append(new_tuple_item)

    return output_collection