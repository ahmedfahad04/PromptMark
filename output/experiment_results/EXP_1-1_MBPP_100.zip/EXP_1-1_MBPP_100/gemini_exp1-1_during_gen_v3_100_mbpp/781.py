import math

def count_divisors(num: int) -> bool:
    # A positive integer has an odd number of divisors if and only if it is a perfect square.
    # All other positive integers have an even number of divisors.

    # We assume 'num' is a positive integer based on the provided test cases.
    # Input validation for non-positive numbers can be added if needed,
    # but the concept of "divisor count" is typically applied to positive integers.

    # Calculate the integer part of the square root of the input number.
    val = int(math.sqrt(num))

    # Determine if the number is a perfect square.
    # If (val * val) equals num, then num is a perfect square.
    is_divisor_count_odd = (val * val) == num

    # The function should return True if the count of divisors is EVEN.
    # - If 'is_divisor_count_odd' is True (num is a perfect square, so divisor count is odd),
    #   we return False (because the count is not even).
    # - If 'is_divisor_count_odd' is False (num is not a perfect square, so divisor count is even),
    #   we return True (because the count is even).
    return not is_divisor_count_odd