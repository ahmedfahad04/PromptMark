import math

def otherside_rightangle(num_one, num_two):
    # Calculates the hypotenuse using the Pythagorean theorem (a^2 + b^2 = c^2).
    # num_one and num_two are assumed to be the lengths of the two legs.
    
    # Calculate squares of the two input sides.
    num_one_sq = num_one * num_one
    num_two_sq = num_two * num_two

    # Sum the squares.
    sum_val = num_one_sq + num_two_sq

    # Compute the square root of the sum to find the hypotenuse.
    my_ans = math.sqrt(sum_val)
    return my_ans