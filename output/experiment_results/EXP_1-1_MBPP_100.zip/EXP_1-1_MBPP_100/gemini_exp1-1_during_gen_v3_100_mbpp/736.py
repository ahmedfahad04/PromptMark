def left_insertion(input_array: list[int], val: int) -> int:
    """
    Locates the left insertion point for a specified value in sorted order.
    """
    low_idx = 0
    high_idx = len(input_array)

    while low_idx < high_idx:
        mid_idx = low_idx + (high_idx - low_idx) // 2
        if input_array[mid_idx] < val:
            low_idx = mid_idx + 1
        else:
            high_idx = mid_idx
            
    return low_idx