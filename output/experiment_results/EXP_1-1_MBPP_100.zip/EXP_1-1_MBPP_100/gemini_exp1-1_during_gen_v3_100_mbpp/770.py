def odd_num_sum(n: int) -> int:
    sum_val = 0
    num = 1  # First odd natural number
    for _ in range(n):
        sum_val += num ** 4
        num += 2  # Next odd natural number
    return sum_val