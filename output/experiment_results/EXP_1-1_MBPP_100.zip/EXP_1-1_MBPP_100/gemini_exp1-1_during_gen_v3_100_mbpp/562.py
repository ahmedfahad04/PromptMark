def Find_Max_Length(input_lists):
    """
    Finds the length of the longest sublist within a given list of lists.
    """
    max_val = 0
    for a_list in input_lists:
        current_unit_size = len(a_list)
        if current_unit_size > max_val:
            max_val = current_unit_size
    return max_val