def string_to_tuple(my_string):
    # Convert the input string into a tuple of its individual characters.
    return tuple(my_string)