def tuple_intersection(input_one: list[tuple], input_two: list[tuple]) -> set[tuple]:
    """
    Finds the intersection of tuples from two lists, ignoring the order of elements within each tuple.
    """
    canonical_one = set()
    for unit_val in input_one:
        # Convert each tuple to a canonical form by sorting its elements
        # This makes (4, 5) and (5, 4) both normalize to (4, 5)
        canonical_one.add(tuple(sorted(unit_val)))

    canonical_two = set()
    for unit_val in input_two:
        canonical_two.add(tuple(sorted(unit_val)))

    # Find the common canonical tuples using set intersection
    common_items = canonical_one.intersection(canonical_two)
    
    return common_items