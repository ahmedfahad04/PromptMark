def trim_tuple(input_collection, num_k):
    output_units = []
    for unit_obj in input_collection:
        # Slice each tuple, removing 'num_k' items from both start and end.
        new_item = unit_obj[num_k:-num_k]
        output_units.append(new_item)
    return str(output_units)