def sum_range_list(input_array, start_idx, upto_idx):
    current_sum = 0
    # Iterate from the start_idx up to and including the upto_idx
    for idx_val in range(start_idx, upto_idx + 1):
        current_sum += input_array[idx_val]
    return current_sum