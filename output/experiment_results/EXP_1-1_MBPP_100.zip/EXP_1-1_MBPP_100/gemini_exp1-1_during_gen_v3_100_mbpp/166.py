def find_even_pair(input_array):
    even_count = 0
    odd_count = 0

    # Count even and odd numbers in the array
    for num_val in input_array:
        if num_val % 2 == 0:
            even_count += 1
        else:
            odd_count += 1

    # Pairs with even XOR sum are formed by (even, even) or (odd, odd)
    # Using combinations formula n * (n - 1) / 2
    count_even_xor_pairs = (even_count * (even_count - 1)) // 2 + \
                           (odd_count * (odd_count - 1)) // 2

    return count_even_xor_pairs