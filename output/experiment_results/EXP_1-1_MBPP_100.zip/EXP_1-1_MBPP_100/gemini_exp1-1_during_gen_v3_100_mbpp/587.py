def list_tuple(input_vals):
    # Convert the input collection of values into a tuple
    return tuple(input_vals)