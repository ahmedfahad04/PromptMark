def empty_dit(input_items):
    # Checks if all items in the provided collection are empty.
    # An empty dictionary (or other empty collection) evaluates to False in a boolean context.
    # 'not any_dict' will be True if 'any_dict' is empty, and False otherwise.
    # 'all()' returns True if all elements in the iterable are True, or if the iterable is empty.
    return all(not any_dict for any_dict in input_items)