def remove_whitespaces(a_chain):
    return a_chain.replace(' ', '')