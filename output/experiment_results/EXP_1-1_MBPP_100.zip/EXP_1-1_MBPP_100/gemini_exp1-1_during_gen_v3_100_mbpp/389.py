def find_lucas(num_in: int) -> int:
    # Base cases for Lucas sequence
    if num_in == 0:
        return 2
    if num_in == 1:
        return 1

    # Initialize the first two Lucas numbers
    val_a = 2  # L(0)
    val_b = 1  # L(1)

    # Calculate subsequent Lucas numbers iteratively
    for idx in range(2, num_in + 1):
        sum_val = val_a + val_b
        val_a = val_b
        val_b = sum_val
    
    return val_b