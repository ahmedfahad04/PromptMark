import copy

def find_Element(input_ary, ops_info, ops_num, aim_idx):
    # Create a mutable copy of the input array.
    main_ary = input_ary[:]

    # Apply the specified number of rotations.
    for i_val in range(ops_num):
        op_unit = ops_info[i_val]
        pos_s = op_unit[0]  # Start position of the segment.
        pos_l = op_unit[1]  # Limit position of the segment (inclusive).

        chunk = main_ary[pos_s : pos_l + 1]
        if not chunk:
            continue
        
        # Perform a right cyclic shift on the chunk and update.
        last_val = chunk.pop()  # Remove the last value.
        chunk.insert(0, last_val)  # Insert it at the start.
        main_ary[pos_s : pos_l + 1] = chunk  # Update the main array with the rotated chunk.

    # Return the value at the queried index after all rotations.
    return main_ary[aim_idx]