def round_and_sum(num_array: list) -> int:
    curr_sum = 0
    for num_val in num_array:
        curr_sum += round(num_val)

    array_len = len(num_array)
    output_num = curr_sum * array_len
    return output_num