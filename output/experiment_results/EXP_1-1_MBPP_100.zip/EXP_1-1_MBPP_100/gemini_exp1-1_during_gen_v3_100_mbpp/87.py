def merge_dictionaries_three(one_map: dict, two_map: dict, many_map: dict) -> dict:
    # Combine the three dictionaries.
    # Later dictionaries' values will overwrite earlier ones for duplicate keys.
    univ_map = {**one_map, **two_map, **many_map}
    w_map = univ_map
    return w_map