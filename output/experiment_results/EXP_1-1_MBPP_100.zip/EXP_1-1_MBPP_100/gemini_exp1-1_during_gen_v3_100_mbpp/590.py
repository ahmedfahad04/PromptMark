import math
import cmath

def polar_rect(input_radius, input_angle):
    # Calculate rectangular coordinates from the given polar coordinates (radius, angle).
    # val_x = radius * cos(angle)
    # val_y = radius * sin(angle)
    val_x = input_radius * math.cos(input_angle)
    val_y = input_radius * math.sin(input_angle)

    # The test cases indicate that a fixed complex number should be included
    # as the second item in the returned tuple. This number is equivalent to
    # cmath.rect(2, math.pi), which results in approximately -2 + 2.449e-16j.
    complex_unit = cmath.rect(2, math.pi)

    # Return the calculated rectangular coordinates (val_x, val_y)
    # along with the fixed complex number, in the specified output format.
    return ((val_x, val_y), complex_unit)