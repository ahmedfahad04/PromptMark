def occurance_substring(input_main, sub_item):
    """
    Finds the first occurrence and position of a substring within a main string.
    Returns None if the substring is not found.
    """
    initial_pos = input_main.find(sub_item)

    if initial_pos == -1:
        return None  # No match found
    else:
        final_pos = initial_pos + len(sub_item)
        return (sub_item, initial_pos, final_pos)