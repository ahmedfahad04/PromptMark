def two_unique_nums(in_nums):
    # A mapping to count each number's occurrences
    num_counts = {}
    for a_num in in_nums:
        num_counts[a_num] = num_counts.get(a_num, 0) + 1

    # Collect numbers that appear exactly once, maintaining original order
    ans_nums = []
    for a_num in in_nums:
        if num_counts[a_num] == 1:
            ans_nums.append(a_num)

    return ans_nums