def remove_nested(a_tuple):
    output_collection = []
    for item in a_tuple:
        # Include items only if they are not tuples
        if not isinstance(item, tuple):
            output_collection.append(item)
    return tuple(output_collection)