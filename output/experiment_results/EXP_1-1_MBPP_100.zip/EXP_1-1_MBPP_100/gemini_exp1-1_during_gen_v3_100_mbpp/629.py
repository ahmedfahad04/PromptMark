def Split(num_list):
    my_nums = []
    for a_num in num_list:
        if a_num % 2 == 0:
            my_nums.append(a_num)
    return my_nums