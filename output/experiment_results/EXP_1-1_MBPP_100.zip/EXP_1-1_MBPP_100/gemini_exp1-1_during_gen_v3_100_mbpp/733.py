def find_first_occurrence(my_array, num):
    curr_low = 0
    curr_high = len(my_array) - 1
    my_ans = -1 # Initialize my_ans to -1, indicating the number is not found

    while curr_low <= curr_high:
        mid_idx = (curr_low + curr_high) // 2
        curr_val = my_array[mid_idx]

        if curr_val == num:
            my_ans = mid_idx # Found a possible first occurrence
            curr_high = mid_idx - 1 # Continue searching in the left half for an earlier occurrence
        elif curr_val < num:
            curr_low = mid_idx + 1 # The number must be in the right half
        else: # curr_val > num
            curr_high = mid_idx - 1 # The number must be in the left half

    return my_ans