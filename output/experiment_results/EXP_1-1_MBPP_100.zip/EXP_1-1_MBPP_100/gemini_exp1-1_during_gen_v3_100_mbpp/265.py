def list_split(input_array, input_num):
    # Initialize a collection to hold all resulting chunks.
    output_collection = []

    # Iterate 'input_num' times, once for each chunk we want to create.
    # 'idx_val' represents the initial index for each chunk.
    for idx_val in range(input_num):
        current_chunk = []  # Initialize an empty list for the current chunk.
        
        # Start at 'idx_val' and pick every 'input_num'-th element.
        current_index = idx_val
        while current_index < len(input_array):
            current_chunk.append(input_array[current_index])
            current_index += input_num # Move to the next element for this chunk.
        
        output_collection.append(current_chunk) # Add the completed chunk to the output.
    
    return output_collection