def count_same_pair(input_one, input_two):
    count_val = 0
    for i in range(len(input_one)):
        if input_one[i] == input_two[i]:
            count_val += 1
    return count_val