def intersection_array(main_ary: list, second_ary: list) -> list:
    # Use a set for the values of the first array for efficient O(1) average time lookups.
    main_vals = set(main_ary)
    
    # Initialize a list to store values common to both arrays.
    common_items = []
    
    # Iterate through each item in the second array.
    for item_val in second_ary:
        # Check if the current value from the second array exists in the set of the first array.
        if item_val in main_vals:
            # If it exists, add it to the list of common items.
            common_items.append(item_val)
            
    return common_items