def sequence(input_num: int) -> int:
    # The sequence starts with P(1) = 1 and P(2) = 1.
    if input_num == 1 or input_num == 2:
        return 1

    # Initialize an array to store the computed sequence values.
    # We use 1-based indexing, so the array size is input_num + 1.
    num_array = [0] * (input_num + 1)
    num_array[1] = 1
    num_array[2] = 1

    # Compute the sequence values from the 3rd number up to input_num.
    for curr_idx in range(3, input_num + 1):
        # Apply the Newman-Conway recurrence relation: P(n) = P(P(n-1)) + P(n-P(n-1))
        val_for_idx_minus_one = num_array[curr_idx - 1]
        
        # Calculate P(P(n-1))
        val_a_part = num_array[val_for_idx_minus_one]
        
        # Calculate P(n-P(n-1))
        val_b_part = num_array[curr_idx - val_for_idx_minus_one]
        
        num_array[curr_idx] = val_a_part + val_b_part

    # Return the nth value in the sequence.
    return num_array[input_num]