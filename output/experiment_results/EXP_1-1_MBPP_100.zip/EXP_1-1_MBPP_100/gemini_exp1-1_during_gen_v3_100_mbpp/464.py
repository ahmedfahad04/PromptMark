def check_value(a_map, n):
    # Iterate through each value in the input map
    for a_val in a_map.values():
        # If any value is not equal to 'n', return False
        if a_val != n:
            return False
    # If all values match 'n', return True
    return True