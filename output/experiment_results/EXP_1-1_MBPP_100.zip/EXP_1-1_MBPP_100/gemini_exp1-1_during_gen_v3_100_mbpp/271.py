def even_Power_Sum(n: int) -> int:
    acum_sum = 0
    # Iterate through the first 'n' natural numbers
    for idx in range(1, n + 1):
        # Calculate the current even natural number
        curr_val = 2 * idx
        # Add its fifth power to the total sum
        acum_sum += curr_val ** 5
    return acum_sum