def reverse_string_list(string_values):
    output_strings = []
    for a_string in string_values:
        # Reverse each individual string using slicing
        output_strings.append(a_string[::-1])
    return output_strings