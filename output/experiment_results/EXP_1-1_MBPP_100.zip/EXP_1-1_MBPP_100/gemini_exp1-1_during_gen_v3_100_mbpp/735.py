def toggle_middle_bits(input_val: int) -> int:
    # Get the number of bits in the input value's binary representation.
    # For example, 9 (1001) has 4 bits.
    count_of_bits = input_val.bit_length()

    # If the number has 2 or fewer bits, there are no "middle" bits to toggle.
    # In this case, the original value is returned unchanged.
    if count_of_bits <= 2:
        return input_val

    # Construct a key (mask) where '1's correspond to the middle bit positions
    # and '0's correspond to the first (most significant) and last (least significant) bits.
    # 1. `(1 << (count_of_bits - 2)) - 1`: This creates a sequence of (count_of_bits - 2)
    #    ones, starting from the least significant bit. For example, if count_of_bits is 4,
    #    (1 << 2) - 1 = 3, which is 011 in binary.
    # 2. `<< 1`: This shifts the sequence of ones one position to the left.
    #    This aligns the '1's to cover the middle bits, ensuring the least significant bit
    #    and the most significant bit remain '0' in the key.
    #    Example (count_of_bits=4): 011 << 1 becomes 110. This key correctly identifies
    #    the middle bits for a 4-bit number like 1001.
    invert_val_key = ((1 << (count_of_bits - 2)) - 1) << 1

    # Toggle the middle bits of the input value using the XOR operation with the key.
    # Bits XORed with 1 will flip (0 becomes 1, 1 becomes 0).
    # Bits XORed with 0 will remain unchanged.
    output_val = input_val ^ invert_val_key
    
    return output_val