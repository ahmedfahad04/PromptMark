def find_Max_Num(num_array):
    # Convert each digit to its string representation
    num_strings = [str(a_num) for a_num in num_array]

    # Sort the string digits in descending order
    # This ensures that when joined, the largest possible number is formed
    num_strings.sort(reverse=True)

    # Join the sorted string digits to form a single string
    joined_string = "".join(num_strings)

    # Convert the joined string back to an integer
    max_num_value = int(joined_string)

    return max_num_value