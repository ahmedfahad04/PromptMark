def capital_words_spaces(input_string: str) -> str:
    # Initialize a list of characters to build the new string.
    output_chars = []
    
    # Iterate through the input_string with an index.
    for curr_index, char_unit in enumerate(input_string):
        # If the current character is an uppercase letter and it's not the very first character,
        # it indicates the start of a new word. Add a space before it.
        if char_unit.isupper() and curr_index > 0:
            output_chars.append(' ')
        
        # Add the current character to the list.
        output_chars.append(char_unit)
    
    # Join all characters in the list to form the final string.
    return "".join(output_chars)