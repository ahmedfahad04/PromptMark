def union_elements(input_one, input_two):
    # Convert tuples to sets to find unique elements and perform union
    set_one = set(input_one)
    set_two = set(input_two)

    # Perform the union operation
    union_items = set_one.union(set_two)

    # Convert the union set to a list for sorting
    items_as_list = list(union_items)

    # Sort the elements
    items_as_list.sort()

    # Convert the sorted list back to a tuple for the final output
    return tuple(items_as_list)