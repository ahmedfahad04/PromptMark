def new_tuple(my_items, my_word):
    # Concatenate the input items (converted to a tuple) with the single input word
    return tuple(my_items) + (my_word,)