def rear_extract(input_collection):
    output_values = []
    # Iterate through each tuple in the input collection
    for a_tuple in input_collection:
        # Append the last element of the current tuple to the output list
        output_values.append(a_tuple[-1])
    return output_values