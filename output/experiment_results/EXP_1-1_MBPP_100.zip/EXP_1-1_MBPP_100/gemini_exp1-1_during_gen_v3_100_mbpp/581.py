def surface_Area(a_base_edge, s_height):
    # Calculate the area of the square base
    a_base_area = a_base_edge * a_base_edge

    # Based on the provided test cases, the 's_height' parameter
    # is interpreted as the slant height of the pyramid, not the perpendicular height.
    # Calculate the lateral surface area (sum of the areas of the four triangular faces).
    # Each triangular face has an area of (1/2) * base_edge * slant_height.
    # For four faces: 4 * (1/2) * base_edge * slant_height = 2 * base_edge * slant_height.
    a_lateral_area = 2 * a_base_edge * s_height

    # Sum the base area and lateral area for the total surface area
    my_total_area = a_base_area + a_lateral_area
    return my_total_area