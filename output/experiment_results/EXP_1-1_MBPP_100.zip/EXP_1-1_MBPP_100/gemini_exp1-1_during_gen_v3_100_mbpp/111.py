def common_in_nested_lists(input_many_lists):
    # If the input collection is empty, no common items exist.
    if not input_many_lists:
        return set()

    # Initialize the set of common items with the items from the very first list.
    # Convert the first list to a set for efficient intersection operations.
    common_items_now = set(input_many_lists[0])

    # Iterate through the remaining lists in the collection.
    # We start from the second list (index 1) since the first one is already processed.
    for unit_list in input_many_lists[1:]:
        # Find the intersection of current common items with the items of the unit list.
        # This updates 'common_items_now' to only include items present in both.
        common_items_now = common_items_now.intersection(unit_list)

        # Optimization: If the set of common items becomes empty,
        # it means there are no items common to all lists,
        # so we can stop early and return an empty set.
        if not common_items_now:
            return set()

    # After checking all lists, 'common_items_now' contains items present in every list.
    return common_items_now