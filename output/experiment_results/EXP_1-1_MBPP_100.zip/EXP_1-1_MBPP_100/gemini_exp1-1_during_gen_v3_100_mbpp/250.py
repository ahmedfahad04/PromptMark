def count_X(input_tuple, my_item):
    num_occurs = 0  # Initialize count of occurrences
    for unit in input_tuple:
        if unit == my_item:
            num_occurs += 1 # Increment if item matches
    return num_occurs