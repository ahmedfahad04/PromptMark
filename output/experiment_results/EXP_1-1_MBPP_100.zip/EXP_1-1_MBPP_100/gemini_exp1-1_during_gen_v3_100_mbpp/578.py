def interleave_lists(my_in_a, my_in_u, my_in_c):
    # Determine the count of elements, as all input lists own same count.
    count = len(my_in_a)
    my_output = []

    # Iterate a number of times equal to count, adding one item from each input list.
    for index in range(count):
        my_output.append(my_in_a[index])
        my_output.append(my_in_u[index])
        my_output.append(my_in_c[index])

    return my_output