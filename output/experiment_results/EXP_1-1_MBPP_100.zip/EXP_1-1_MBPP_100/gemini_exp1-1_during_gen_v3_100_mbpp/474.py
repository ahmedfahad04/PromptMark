def replace_char(input_string, old_sym, new_sym):
    """
    Replaces all occurrences of a specified character with another character in a string.
    """
    output_array = []
    for sym in input_string:
        if sym == old_sym:
            output_array.append(new_sym)
        else:
            output_array.append(sym)
    return "".join(output_array)