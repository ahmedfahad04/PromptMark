def snake_to_camel(snake_input: str) -> str:
    # Split the input string by underscore to get individual words
    word_units = snake_input.split('_')
    
    camel_units = []
    for unit_item in word_units:
        # Capitalize the first letter of each word and add to a new list
        camel_units.append(unit_item.capitalize())
    
    # Join the capitalized words to form the camel case string
    output_val = ''.join(camel_units)
    return output_val