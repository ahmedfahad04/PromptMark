def extract_nth_element(unit_collection, index_pos):
    output_values = []
    # Iterate through each tuple in the collection
    for a_unit in unit_collection:
        # Append the element at the specified index from the current tuple
        output_values.append(a_unit[index_pos])
    return output_values