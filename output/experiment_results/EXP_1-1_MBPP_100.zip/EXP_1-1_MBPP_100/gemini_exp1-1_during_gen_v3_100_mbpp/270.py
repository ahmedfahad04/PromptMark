def sum_even_and_even_index(num_array: list) -> int:
    current_sum = 0
    for idx, val in enumerate(num_array):
        # Check if the current position (index) is even
        # and if the number at that position is also even.
        if idx % 2 == 0 and val % 2 == 0:
            current_sum += val
    return current_sum