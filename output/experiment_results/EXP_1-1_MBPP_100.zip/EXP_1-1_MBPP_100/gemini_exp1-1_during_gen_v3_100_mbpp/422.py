def find_Average_Of_Cube(n: int) -> float:
    # Calculate the term (n + 1) / 2.0
    unit_sum = (n + 1) / 2.0
    
    # Apply the formula: n * ((n + 1) / 2)^2
    avg_val = n * (unit_sum ** 2)
    
    return avg_val