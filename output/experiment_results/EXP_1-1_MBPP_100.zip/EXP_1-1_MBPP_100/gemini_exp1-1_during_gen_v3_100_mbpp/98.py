import math 

def multiply_num(many_nums):
    # Initialize an accumulator for the product with a float value.
    acc_val = 1.0

    # Multiply all numbers in the collection.
    for num in many_nums:
        acc_val *= num

    # Get the count of numbers in the collection.
    num_count = len(many_nums)

    # Handle the case of an empty collection to avoid division by zero.
    if num_count == 0:
        return 0.0
    
    # Divide the accumulated product by the count of numbers.
    calc_val = acc_val / num_count
    
    return calc_val