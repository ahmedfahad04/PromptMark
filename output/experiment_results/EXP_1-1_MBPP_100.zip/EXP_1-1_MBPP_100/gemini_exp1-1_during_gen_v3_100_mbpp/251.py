def insert_element(input_coll, input_val):
    new_array = []
    for an_obj in input_coll:
        new_array.append(input_val)
        new_array.append(an_obj)
    return new_array