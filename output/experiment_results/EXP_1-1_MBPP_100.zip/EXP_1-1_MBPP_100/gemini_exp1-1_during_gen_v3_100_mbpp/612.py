def merge(input_many_arrays):
    # Unpack and zip to transpose the arrays.
    output_many_units = [list(chunk_items) for chunk_items in zip(*input_many_arrays)]
    return output_many_units