def swap_List(input_vals):
    # Obtain the total count of items in the list.
    num_items = len(input_vals)

    # A swap is only possible if there are at least two items.
    if num_items < 2:
        return input_vals

    # Pythonic way to swap the first and last elements.
    input_vals[0], input_vals[num_items - 1] = input_vals[num_items - 1], input_vals[0]

    return input_vals