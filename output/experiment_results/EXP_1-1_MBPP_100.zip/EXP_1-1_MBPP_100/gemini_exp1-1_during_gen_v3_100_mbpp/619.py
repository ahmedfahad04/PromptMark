def move_num(input_str: str) -> str:
    non_numeric_chars = []
    numeric_chars = []

    for char_val in input_str:
        if char_val.isdigit():
            numeric_chars.append(char_val)
        else:
            non_numeric_chars.append(char_val)
            
    # Combine the non-numeric characters first, then the numeric ones.
    output_val = "".join(non_numeric_chars) + "".join(numeric_chars)
    return output_val