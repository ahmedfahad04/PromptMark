def Find_Max_Length(input_uni):
    # Initialize maximum count to zero
    max_count = 0

    # Iterate through each sub-unit in the input collection
    for sub_uni in input_uni:
        # Get the count of items in the current sub-unit
        curr_count = len(sub_uni)
        # Update max_count if current sub-unit is longer
        if curr_count > max_count:
            max_count = curr_count

    # Return the maximum count found
    return max_count