def two_unique_nums(nums_array: list[int]) -> list[int]:
    # Counts occurrences of each num.
    num_counts = {}
    for num in nums_array:
        num_counts[num] = num_counts.get(num, 0) + 1

    # Collects nums that appear only once.
    unique_items = []
    for num in nums_array: # Iterate original array to maintain output order as in test cases
        if num_counts[num] == 1:
            unique_items.append(num)
            # Mark as processed to avoid adding duplicates if the same unique num appears again in num_array
            # For this problem, it's not strictly needed as num_counts[num] == 1 implies it appears only once.
            # But a robust way might mark it as seen or simply rely on the unique count.
            # Simpler: just append, as `num_counts[num] == 1` means it won't be added twice.

    return unique_items