def intersection_array(nums_one, nums_any):
    # Convert the first array to a set for efficient O(1) average time complexity lookups.
    univ_nums = set(nums_one)
    common_nums = []

    # Iterate through items in the second array.
    for a_num in nums_any:
        # If the current item is present in the set, add it to the common_nums list.
        if a_num in univ_nums:
            common_nums.append(a_num)
            
    return common_nums