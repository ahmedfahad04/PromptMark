def capital_words_spaces(input_way: str) -> str:
    # Use a list of characters to build the output string efficiently
    output_chars = []
    # Iterate with an index to check if it's the first character
    for idx, a_char in enumerate(input_way):
        # If the character is uppercase and not the very first character of the input,
        # add a space before appending it.
        if a_char.isupper() and idx > 0:
            output_chars.append(' ')
        output_chars.append(a_char)
    # Join the list of characters to form the final string
    return "".join(output_chars)