def square_nums(input_nums):
    output_vals = []
    for num in input_nums:
        output_vals.append(num * num)
    return output_vals