def count_X(input_tuple: tuple, item: any) -> int:
    # Initialize a counter for occurrences
    num_occs = 0
    # Iterate through each value in the input tuple
    for val_in_tuple in input_tuple:
        # If the current value matches the item, increment the counter
        if val_in_tuple == item:
            num_occs += 1
    return num_occs