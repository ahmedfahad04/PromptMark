def and_tuples(input_one: tuple[int, ...], input_two: tuple[int, ...]) -> tuple[int, ...]:
    """
    Computes the element-wise bitwise AND of two tuples of integers.

    Assumes both input tuples have the same length.
    """
    # Create a new tuple by applying bitwise AND to corresponding elements
    # from input_one and input_two.
    output_values = (num_one & num_two for num_one, num_two in zip(input_one, input_two))
    return tuple(output_values)