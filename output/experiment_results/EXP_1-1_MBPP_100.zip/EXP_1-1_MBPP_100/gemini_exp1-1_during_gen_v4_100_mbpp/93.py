def power(a, b):
    # Initialize accumulator for the output value
    my_output = 1
    # Iterate 'b' times to multiply 'a' by itself
    for idx in range(b):
        my_output = my_output * a
    return my_output