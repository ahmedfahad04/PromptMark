import math

def sector_area(input_radius, input_angle):
    # Check if the input angle is invalid
    if input_angle > 360:
        return None

    # Calculate the area using the formula: (angle / 360) * pi * radius^2
    my_area = (input_angle / 360) * math.pi * (input_radius ** 2)
    return my_area