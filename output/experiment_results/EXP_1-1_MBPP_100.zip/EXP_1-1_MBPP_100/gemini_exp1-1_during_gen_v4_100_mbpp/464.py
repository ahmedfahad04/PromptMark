def check_value(a_map: dict, n: int) -> bool:
    # Iterate through each value in the input dictionary
    for curr_val in a_map.values():
        # If any value is not equal to n, return False
        if curr_val != n:
            return False
    # If all values match n (or dictionary is empty), return True
    return True