def rotate_right(input_array: list, k_amount: int) -> list:
    # If the input array is empty, it cannot be rotated.
    array_size = len(input_array)
    if array_size == 0:
        return []

    # Calculate the actual number of positions to shift right.
    # This handles cases where k_amount is larger than the array's size.
    actual_k = k_amount % array_size

    # Determine the cut-off index. Items from this index onwards
    # will move to the front of the array.
    cut_index = array_size - actual_k

    # Extract the items that will form the suffix (moving to the front).
    suffix_items = input_array[cut_index:]
    # Extract the remaining items that will form the main part.
    main_items = input_array[:cut_index]

    # Combine the two parts to form the new, rotated array.
    new_array = suffix_items + main_items

    return new_array