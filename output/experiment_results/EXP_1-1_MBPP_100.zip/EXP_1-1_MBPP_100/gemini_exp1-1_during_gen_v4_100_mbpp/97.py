from collections import Counter

def frequency_lists(input_arrays):
    """
    Finds the frequency of each element in a flattened list of lists.

    Collects all numeric values from the nested input into a single sequence,
    then counts the occurrences of each unique value.
    """
    all_values = []
    for current_array in input_arrays:
        all_values.extend(current_array) # Unpack values from sub-arrays

    # Counter automatically counts occurrences of each item in an iterable
    value_counts = Counter(all_values)
    return value_counts