def subject_marks(input_marks):
    # Sorts the input list of tuples based on the second element (mark) of each tuple.
    # The 'key' parameter uses a lambda function to specify that the sorting should
    # be done using the element at index 1 of each tuple.
    sorted_marks = sorted(input_marks, key=lambda current_mark: current_mark[1])
    return sorted_marks