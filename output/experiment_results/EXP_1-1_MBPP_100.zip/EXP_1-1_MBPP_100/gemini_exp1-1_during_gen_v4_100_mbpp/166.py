def find_even_pair(num_array: list[int]) -> int:
    # Initialize counts for even and odd numbers
    count_even = 0
    count_odd = 0

    # Iterate through the input array to count even and odd numbers
    for val in num_array:
        if val % 2 == 0:
            count_even += 1
        else:
            count_odd += 1

    # A pair of numbers XORs to an even number if both numbers have the same parity.
    # We count pairs of even numbers and pairs of odd numbers.
    # The number of pairs for 'n' items is n * (n - 1) / 2.
    num_even_pairs = (count_even * (count_even - 1)) // 2
    num_odd_pairs = (count_odd * (count_odd - 1)) // 2
    
    # Sum the counts of these pairs
    sum_pairs = num_even_pairs + num_odd_pairs
    
    return sum_pairs