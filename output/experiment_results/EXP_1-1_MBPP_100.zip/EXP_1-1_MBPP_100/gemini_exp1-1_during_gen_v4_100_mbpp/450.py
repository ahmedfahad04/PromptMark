def extract_string(a_strings: list[str], size_val: int) -> list[str]:
    matching_strings = []
    for a_string in a_strings:
        if len(a_string) == size_val:
            matching_strings.append(a_string)
    return matching_strings