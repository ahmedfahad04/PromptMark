def surface_Area(my_a_unit, my_slant_val):
    # my_a_unit: base edge of the square pyramid
    # my_slant_val: slant height of the pyramid

    # Calculate the area of the square base
    my_base_area = my_a_unit * my_a_unit

    # Calculate the area of the four triangular lateral faces.
    # Each triangle's area is (1/2) * base_edge * slant_height.
    # Total lateral area is 4 * (1/2) * base_edge * slant_height, which simplifies to 2 * base_edge * slant_height.
    my_side_area = 2 * my_a_unit * my_slant_val

    # The total surface area is the sum of the base area and the lateral area.
    my_total_area = my_base_area + my_side_area
    
    return my_total_area