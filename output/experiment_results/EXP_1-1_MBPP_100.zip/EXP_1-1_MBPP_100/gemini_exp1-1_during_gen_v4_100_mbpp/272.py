def rear_extract(input_tuples):
    # Collect the last element of each tuple using a list comprehension
    return [an_obj[-1] for an_obj in input_tuples]