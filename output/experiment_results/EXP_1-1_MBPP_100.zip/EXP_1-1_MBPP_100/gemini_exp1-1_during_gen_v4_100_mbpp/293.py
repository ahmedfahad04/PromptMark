import math

def otherside_rightangle(input_a: float, input_b: float) -> float:
    # Use Pythagorean theorem to find the hypotenuse, assuming input_a and input_b are the two shorter sides.
    sum_of_squares = (input_a * input_a) + (input_b * input_b)
    final_value = math.sqrt(sum_of_squares)
    return final_value