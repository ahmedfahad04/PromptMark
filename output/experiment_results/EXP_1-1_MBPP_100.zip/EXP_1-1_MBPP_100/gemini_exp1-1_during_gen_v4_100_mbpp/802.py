def count_rotation(any_array: list[int]) -> int:
    """
    Counts the number of left rotations applied to a sorted array
    to obtain the current array configuration.

    The number of rotations is determined by finding the index of
    the first element that is greater than its successor. This point
    marks where the ascending order was broken by the rotation.
    """
    array_len = len(any_array)

    # An empty or single-element array is considered sorted with 0 rotations.
    if array_len <= 1:
        return 0

    # Iterate through the array to find the point where the increasing order breaks.
    for idx_val in range(array_len - 1):
        # If the current value is greater than the next value,
        # this indicates the "pivot" or rotation point.
        if any_array[idx_val] > any_array[idx_val + 1]:
            # The number of rotations is the index of the smallest element,
            # which is (idx_val + 1) in this scenario.
            return idx_val + 1

    # If the loop completes without finding a breaking point,
    # the array is already sorted, so 0 rotations are needed.
    return 0