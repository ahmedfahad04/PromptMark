def trim_tuple(input_collection: list[tuple], k_val: int) -> str:
    """
    Trims each tuple in a list of tuples by removing k_val elements from both ends.
    """
    outcome_collection = []
    for a_tuple in input_collection:
        unit_count = len(a_tuple)
        # Calculate the start and end indices for slicing
        # Elements are kept from index k_val up to (but not including) unit_count - k_val
        start_idx = k_val
        end_idx = unit_count - k_val
        
        # Perform the slicing. If start_idx >= end_idx, an empty tuple will naturally be produced.
        a_new_unit = a_tuple[start_idx:end_idx]
        outcome_collection.append(a_new_unit)
    
    # Convert the final list of tuples to a string representation
    return str(outcome_collection)