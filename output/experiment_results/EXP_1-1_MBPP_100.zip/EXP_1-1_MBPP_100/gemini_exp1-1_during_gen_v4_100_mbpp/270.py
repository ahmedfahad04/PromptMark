def sum_even_and_even_index(num_array: list) -> int:
    # Initialize accumulator for the sum.
    count_sum = 0
    # Iterate through the input array using index and value.
    for idx, num_val in enumerate(num_array):
        # Check if the current index is even AND the number at this index is even.
        if idx % 2 == 0 and num_val % 2 == 0:
            count_sum += num_val
    return count_sum