def is_sublist(main_array: list, sub_array: list) -> bool:
    """
    Checks if a sub_array is contained within a main_array.
    """
    main_count = len(main_array)
    sub_count = len(sub_array)

    if sub_count == 0:
        # An empty sub_array is always considered a sub_array of any array.
        return True

    if sub_count > main_count:
        # A sub_array cannot be longer than the main_array.
        return False

    # Check all possible windows within the main_array.
    for idx in range(main_count - sub_count + 1):
        if main_array[idx : idx + sub_count] == sub_array:
            return True

    return False