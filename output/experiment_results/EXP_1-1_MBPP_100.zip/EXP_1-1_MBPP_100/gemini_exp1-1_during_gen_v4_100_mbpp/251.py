def insert_element(input_array: list, item_value: any) -> list:
    # Initialize a new collection to store the output.
    new_collection = []
    # Iterate through each item in the original input array.
    for an_item in input_array:
        # For each item, add the specified item_value before it.
        new_collection.append(item_value)
        # Then, add the current item from the input array.
        new_collection.append(an_item)
    # Return the new collection with elements inserted.
    return new_collection