def test_three_equal(num1, num2, num3):
    # Collect the input numbers into a set to find unique values.
    # A set automatically stores only distinct items.
    unique_values = {num1, num2, num3}

    # The count of unique values helps determine how many numbers are equal.
    num_unique = len(unique_values)

    if num_unique == 1:
        # If there's only one unique value, it means all three numbers are identical.
        return 3
    elif num_unique == 2:
        # If there are two unique values, it means two numbers are identical
        # and the third one is different.
        return 2
    else: # num_unique == 3
        # If there are three unique values, all numbers are different.
        return 0