def sequence(n: int) -> int:
    # Initial checks. The first two numbers in the Newman-Conway sequence are 1.
    if n <= 2:
        return 1

    # Initialize a cache to store computed sequence values.
    # `output_values[i]` will store the i-th number in the sequence.
    # Index 0 is unused for easier 1-based indexing for P(i).
    output_values = [0, 1, 1]  # P(0) (unused), P(1), P(2)

    # Calculate output values from P(3) up to P(n)
    for idx in range(3, n + 1):
        # The Newman-Conway recurrence relation: P(idx) = P(P(idx - 1)) + P(idx - P(idx - 1))
        
        # Retrieve P(idx-1), which acts as an index for the first component.
        val_for_index_one = output_values[idx - 1]
        
        # Compute the index for the second component: idx - P(idx-1).
        val_for_index_aux = idx - val_for_index_one
        
        # Calculate the current sequence value P(idx).
        current_output_value = output_values[val_for_index_one] + output_values[val_for_index_aux]
        
        # Add the newly computed value to our cache.
        output_values.append(current_output_value)

    # Output P(n).
    return output_values[n]