def remove_Occ(my_input: str, char_to_cut: str) -> str:
    # Find the index of the first occurrence of the character
    # If the character is not found, 'find' returns -1
    first_idx = my_input.find(char_to_cut)

    # If the character is not in the input string, return the original string
    if first_idx == -1:
        return my_input

    # Find the index of the last occurrence of the character
    # 'rfind' returns -1 if the character is not found (though 'find' would catch this first)
    last_idx = my_input.rfind(char_to_cut)

    # Build a new string by including only characters that are not at first_idx or last_idx
    new_chars_collection = []
    for idx, unit_char in enumerate(my_input):
        if idx != first_idx and idx != last_idx:
            new_chars_collection.append(unit_char)

    return "".join(new_chars_collection)