def new_tuple(input_way: list, input_word: str) -> tuple:
    # Unpack the items from the input list and append the new word to form a new tuple.
    output_unit = (*input_way, input_word)
    return output_unit