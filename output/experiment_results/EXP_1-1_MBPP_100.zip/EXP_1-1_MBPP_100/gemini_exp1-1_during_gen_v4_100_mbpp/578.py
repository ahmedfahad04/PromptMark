def interleave_lists(a_input_one, a_input_two, a_input_three):
    a_union = []
    # All lists are of the same length, so we can use the length of any input.
    # Using 'len(a_input_one)' as an example.
    for an_idx in range(len(a_input_one)):
        a_union.append(a_input_one[an_idx])
        a_union.append(a_input_two[an_idx])
        a_union.append(a_input_three[an_idx])
    anum_output = a_union
    return anum_output