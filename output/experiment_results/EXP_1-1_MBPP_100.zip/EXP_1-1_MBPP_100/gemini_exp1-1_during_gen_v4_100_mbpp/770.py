def odd_num_sum(n: int) -> int:
    # Initialize a variable to accumulate the sum of fourth powers
    sum_val = 0
    # Iterate 'n' times to process the first 'n' odd natural numbers
    for idx in range(n):
        # Calculate the current odd number
        # For idx = 0, odd_num = 1
        # For idx = 1, odd_num = 3
        # And so on...
        odd_num = 2 * idx + 1
        # Calculate the fourth power of the current odd number
        curr_pow = odd_num ** 4
        # Add the fourth power to the running sum
        sum_val += curr_pow
    # Return the final sum
    return sum_val