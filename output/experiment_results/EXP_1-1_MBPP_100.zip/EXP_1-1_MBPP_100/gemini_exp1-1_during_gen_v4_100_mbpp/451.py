def remove_whitespaces(input_string: str) -> str:
    # The str.split() method, when called without arguments, splits a string
    # by any whitespace character (space, tab, newline, etc.) and
    # discards empty strings, effectively treating multiple whitespaces
    # as a single separator.
    # The "".join() method then concatenates all the resulting
    # non-whitespace parts back together without any spaces.
    return "".join(input_string.split())