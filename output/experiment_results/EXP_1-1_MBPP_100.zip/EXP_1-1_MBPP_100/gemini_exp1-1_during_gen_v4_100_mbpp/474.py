def replace_char(input_val, old_char_val, new_char_val):
    # Initializes a list to accumulate the characters of the new string.
    output_units = []
    # Iterates through each character in the input string.
    for char_unit in input_val:
        # Checks if the current character matches the character to be replaced.
        if char_unit == old_char_val:
            # If it matches, appends the new character.
            output_units.append(new_char_val)
        else:
            # If it doesn't match, appends the original character.
            output_units.append(char_unit)
    # Joins the characters in the list to form the final string and returns it.
    return "".join(output_units)