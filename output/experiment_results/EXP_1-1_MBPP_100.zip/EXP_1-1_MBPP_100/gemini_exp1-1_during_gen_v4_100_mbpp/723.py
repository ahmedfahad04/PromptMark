def count_same_pair(input_one, input_two):
    same_count = 0
    # Assuming both input lists always have the same length.
    num_items = len(input_one)
    for idx in range(num_items):
        if input_one[idx] == input_two[idx]:
            same_count += 1
    return same_count