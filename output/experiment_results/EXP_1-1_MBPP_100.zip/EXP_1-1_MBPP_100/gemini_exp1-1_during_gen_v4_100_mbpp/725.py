import re

def extract_quotation(source_input: str) -> list[str]:
    # Define a regex pattern to find content within double quotation marks.
    # The pattern r'"([^"]*)"' works as follows:
    #   - '"': Matches a literal double quotation mark.
    #   - '([^"]*)': This is the capturing group.
    #     - '[^"]': Matches any character that is NOT a double quotation mark.
    #     - '*': Matches the preceding character zero or more times.
    #   - '"': Matches the closing literal double quotation mark.
    _match_val = r'"([^"]*)"'

    # Use re.findall to return all non-overlapping matches of the pattern.
    # Since there is one capturing group in _match_val, re.findall returns
    # a list of the strings captured by that group.
    match_units = re.findall(_match_val, source_input)

    return match_units