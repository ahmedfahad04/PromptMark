def remove_nested(input_collection_val: tuple) -> tuple:
    # Accumulate values that are not tuples
    output_values_accu = []
    for current_unit in input_collection_val:
        # Include the unit if it's not a tuple
        if not isinstance(current_unit, tuple):
            output_values_accu.append(current_unit)
    # Convert the accumulated values into a new tuple
    return tuple(output_values_accu)