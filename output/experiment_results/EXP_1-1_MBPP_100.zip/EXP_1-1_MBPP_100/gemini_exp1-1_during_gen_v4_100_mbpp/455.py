def check_monthnumb_number(month_numb: int) -> bool:
    # A collection of month numbers that contain 31 days
    many_day_months = {1, 3, 5, 7, 8, 10, 12}
    return month_numb in many_day_months