import re

def text_match_wordz(input_val: str) -> bool:
    # Compile a regular expression pattern to find a word containing 'z'.
    # \b asserts a word boundary.
    # \w* matches zero or more word characters (alphanumeric and underscore).
    # 'z' matches the literal character 'z'.
    comp_obj = re.compile(r'\b\w*z\w*\b')
    
    # Search for the pattern within the input string.
    comp_scan = comp_obj.search(input_val)
    
    # Return True if a match is found, False otherwise.
    if comp_scan:
        return True
    return False