def string_to_tuple(my_val: str) -> tuple:
    # Converts an input string into a tuple of its individual characters.
    return tuple(my_val)