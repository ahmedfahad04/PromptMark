def Find_Min(input_coll):
    # If the collection is empty, an empty list might be a reasonable default,
    # or an error could be raised depending on problem specifics.
    # For now, assuming non-empty input as per test cases.
    if not input_coll:
        return []

    # Find the sublist with the minimum length using the 'min' function
    # with 'len' as the key for comparison.
    min_sub_arr = min(input_coll, key=len)
    return min_sub_arr