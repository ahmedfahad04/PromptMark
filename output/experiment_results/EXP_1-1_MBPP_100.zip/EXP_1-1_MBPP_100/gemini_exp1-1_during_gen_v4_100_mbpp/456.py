def reverse_string_list(input_strings):
    # Initialize an output list to contain the new, inverted strings.
    new_strings = []
    for a_string in input_strings:
        # Invert each string using slicing and add it to the output list.
        inverted_string = a_string[::-1]
        new_strings.append(inverted_string)
    # Return the list of inverted strings.
    return new_strings