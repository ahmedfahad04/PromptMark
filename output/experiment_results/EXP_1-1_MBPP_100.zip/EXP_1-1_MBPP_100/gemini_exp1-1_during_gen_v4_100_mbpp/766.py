def pair_wise(input_array):
    output_pairs = []
    # Iterate from the first item up to the second-to-last item
    # This allows forming a pair with the current item and the one next to it
    for idx in range(len(input_array) - 1):
        current_item = input_array[idx]
        next_item = input_array[idx + 1]
        output_pairs.append((current_item, next_item))
    unify_input = output_pairs
    return unify_input