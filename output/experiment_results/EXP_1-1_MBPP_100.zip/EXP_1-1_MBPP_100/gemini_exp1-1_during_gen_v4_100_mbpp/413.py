def extract_nth_element(input_data, n):
    output_values = []
    for item in input_data:
        output_values.append(item[n])
    return output_values