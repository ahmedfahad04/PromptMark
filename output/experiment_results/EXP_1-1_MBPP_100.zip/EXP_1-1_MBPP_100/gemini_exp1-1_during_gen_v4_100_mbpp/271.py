def even_Power_Sum(n: int) -> int:
    my_sum = 0
    # Iterate from 1 up to n to generate the first n even natural numbers
    for idx in range(1, n + 1):
        my_num = 2 * idx  # Calculate the current even number
        my_sum += my_num ** 5  # Add its fifth power to the sum
    return my_sum