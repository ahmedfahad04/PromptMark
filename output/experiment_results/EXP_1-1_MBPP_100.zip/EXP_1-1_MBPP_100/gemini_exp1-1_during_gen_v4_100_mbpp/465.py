def drop_empty(a_dict: dict) -> dict:
    clean_dict = {}
    for key, val in a_dict.items():
        if val is not None:
            clean_dict[key] = val
    return clean_dict