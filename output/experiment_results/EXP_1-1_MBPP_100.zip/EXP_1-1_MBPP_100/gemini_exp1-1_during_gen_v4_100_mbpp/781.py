def count_divisors(num: int) -> bool:
    # A number has an odd count of divisors if and only if it is a perfect square.
    # Consequently, a number has an even count of divisors if and only if it is NOT a perfect square.

    # Calculate the integer part of the square root of the input number.
    val_sqrt = int(num ** 0.5)
    
    # Check if the number is a perfect square.
    # If 'val_sqrt' squared equals 'num', then 'num' is a perfect square.
    is_a_sq_val = (val_sqrt * val_sqrt == num)
    
    # We want to know if the count of divisors is even.
    # If 'num' is a perfect square (is_a_sq_val is True), its divisor count is odd.
    # If 'num' is not a perfect square (is_a_sq_val is False), its divisor count is even.
    # Thus, we return the negation of 'is_a_sq_val'.
    return not is_a_sq_val