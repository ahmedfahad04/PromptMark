def average_tuple(input_collections):
    output_averages = []
    for inner_collection in input_collections:
        # Calculate sum and count for the current inner tuple
        current_sum = sum(inner_collection)
        item_count = len(inner_collection)
        
        # Calculate average if the inner tuple is not empty
        if item_count > 0:
            avg_val = current_sum / item_count
            output_averages.append(avg_val)
        # Assuming inner tuples are always non-empty based on the problem examples,
        # otherwise, specific handling for empty tuples might be needed.
        
    return output_averages