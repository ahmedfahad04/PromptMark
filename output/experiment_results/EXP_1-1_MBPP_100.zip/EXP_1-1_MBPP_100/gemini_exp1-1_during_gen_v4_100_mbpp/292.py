def find(num_one: int, num_two: int) -> int:
    # Use integer division (//) to get the quotient,
    # which is automatically rounded down to the nearest integer.
    return num_one // num_two