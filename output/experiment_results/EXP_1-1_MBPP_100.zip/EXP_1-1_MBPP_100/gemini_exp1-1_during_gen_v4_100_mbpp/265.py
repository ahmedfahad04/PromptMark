def list_split(input_values, n_value):
    # Initialize 'n_value' empty lists to contain the split items
    output_arrays = [[] for _ in range(n_value)]

    # Iterate through each item along with its original index
    for an_index, an_item in enumerate(input_values):
        # Determine which sub-array the current item should be placed into
        which_array_idx = an_index % n_value
        # Append the item to its corresponding sub-array
        output_arrays[which_array_idx].append(an_item)
        
    return output_arrays