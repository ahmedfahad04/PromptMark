def find_lucas(n: int) -> int:
    # Lucas sequence: L(0) = 2, L(1) = 1, L(n) = L(n-1) + L(n-2)
    if n == 0:
        return 2
    if n == 1:
        return 1

    # Initialize the first two Lucas numbers
    # val_a holds L(idx-2)
    val_a = 2
    # val_b holds L(idx-1)
    val_b = 1

    # Calculate Lucas numbers iteratively up to n
    for idx in range(2, n + 1):
        # Current Lucas number is the sum of the previous two
        sum_val = val_a + val_b
        # Update val_a to be the old val_b (which was L(idx-1))
        val_a = val_b
        # Update val_b to be the new sum_val (which is L(idx))
        val_b = sum_val

    # val_b now holds the n'th Lucas number
    return val_b