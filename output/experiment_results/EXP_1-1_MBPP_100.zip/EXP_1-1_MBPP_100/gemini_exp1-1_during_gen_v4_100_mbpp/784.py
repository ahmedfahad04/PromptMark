def mul_even_odd(in_nums: list[int]) -> int:
    a_even_val = None
    a_odd_val = None

    for a_num in in_nums:
        # Assign first even number found
        if a_even_val is None and a_num % 2 == 0:
            a_even_val = a_num
        
        # Assign first odd number found
        if a_odd_val is None and a_num % 2 != 0:
            a_odd_val = a_num
            
        # Stop once both values are known
        if a_even_val is not None and a_odd_val is not None:
            break
            
    # Assuming valid input where both an even and an odd number exist.
    return a_even_val * a_odd_val