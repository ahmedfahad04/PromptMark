def sum_list(array_one, array_two):
    # Create a new array to accumulate the sums
    sum_values = []
    # Iterate through items of both arrays simultaneously
    for num_one, num_two in zip(array_one, array_two):
        # Add the sum of current numbers to the output array
        sum_values.append(num_one + num_two)
    # Return the array of sums
    return sum_values