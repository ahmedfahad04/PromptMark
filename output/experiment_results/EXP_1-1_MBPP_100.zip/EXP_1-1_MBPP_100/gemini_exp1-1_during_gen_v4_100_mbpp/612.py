def merge(collections):
    # Unpack the collections and transpose them using zip(*).
    # Convert each resulting tuple (representing a column) into a list.
    output_collections = [list(column_items) for column_items in zip(*collections)]
    return output_collections