def square_Sum(n: int) -> int:
    sum_val = 0  # Accumulator for the total sum of squares
    # Iterate 'n' times, where 'num_val' represents the position of the odd number
    for num_val in range(1, n + 1):
        # Calculate the current odd natural number based on its position
        # For num_val=1, it's 1; for num_val=2, it's 3, and so on.
        an_num = (2 * num_val) - 1
        # Add the square of this odd number to the sum
        sum_val += (an_num * an_num)
    return sum_val