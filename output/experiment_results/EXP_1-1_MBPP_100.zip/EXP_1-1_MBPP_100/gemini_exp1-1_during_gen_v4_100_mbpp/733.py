def find_first_occurrence(input_array: list[int], input_num: int) -> int:
    # Initialize pointers for the binary search window.
    low_idx = 0
    high_idx = len(input_array) - 1
    # Initialize occurrence_idx to -1, indicating the number hasn't been found yet.
    occurrence_idx = -1

    while low_idx <= high_idx:
        mid_idx = low_idx + (high_idx - low_idx) // 2
        current_value = input_array[mid_idx]

        if current_value == input_num:
            # We found a match. This might be the first occurrence.
            # Store this index and try to find an earlier one in the left half.
            occurrence_idx = mid_idx
            high_idx = mid_idx - 1
        elif current_value < input_num:
            # The input_num must be in the right half.
            low_idx = mid_idx + 1
        else:  # current_value > input_num
            # The input_num must be in the left half.
            high_idx = mid_idx - 1

    # Return the index of the first occurrence, or -1 if not found.
    return occurrence_idx