def sum_series(num: int) -> int:
    my_sum = 0
    # Loop from 0 up to num // 2, inclusive
    for an_ix in range(num // 2 + 1):
        a_num = num - 2 * an_ix
        my_sum += a_num
    return my_sum