def occurance_substring(main_string: str, sub_string: str):
    """
    Finds the first occurrence and position of a substring within a main string.
    """
    idx = main_string.find(sub_string)

    if idx == -1:
        # If substring is not found, return None
        return None
    else:
        # Calculate the end index of the substring
        end_idx = idx + len(sub_string)
        # Return a tuple containing the substring, start index, and end index
        return (sub_string, idx, end_idx)