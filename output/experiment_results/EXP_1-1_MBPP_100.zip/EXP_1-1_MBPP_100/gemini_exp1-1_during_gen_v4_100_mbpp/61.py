def count_Substrings(input_string: str) -> int:
    # Initialize a counter for substrings that satisfy the condition.
    sub_count = 0
    # Get the length of the input string for convenient iteration.
    input_len = len(input_string)

    # Iterate through all possible starting positions of a substring.
    for idx_i in range(input_len):
        current_sum = 0
        # Iterate through all possible ending positions for the current starting position.
        # This inner loop effectively builds substrings starting at idx_i and growing.
        for idx_j in range(idx_i, input_len):
            # Convert the character digit to an integer and add it to the running sum.
            current_sum += int(input_string[idx_j])
            
            # Calculate the length of the current substring.
            # A substring from idx_i to idx_j (inclusive) has length (idx_j - idx_i + 1).
            current_sub_len = idx_j - idx_i + 1
            
            # Check if the sum of digits in the current substring equals its length.
            if current_sum == current_sub_len:
                sub_count += 1
                
    return sub_count