def swap_List(input_array: list) -> list:
    # Check if the array has at least two elements for swapping
    if len(input_array) < 2:
        return input_array

    # Store the first element in a temporary variable
    aux_value = input_array[0]

    # Replace the first element with the last element
    input_array[0] = input_array[len(input_array) - 1]

    # Replace the last element with the stored auxiliary value
    input_array[len(input_array) - 1] = aux_value

    return input_array