def sum_range_list(many_nums, start_index, upper_index):
    acum_sum = 0  # Initialize accumulator for the sum
    # Iterate from the start_index up to and including the upper_index
    for current_index in range(start_index, upper_index + 1):
        acum_sum += many_nums[current_index]
    return acum_sum