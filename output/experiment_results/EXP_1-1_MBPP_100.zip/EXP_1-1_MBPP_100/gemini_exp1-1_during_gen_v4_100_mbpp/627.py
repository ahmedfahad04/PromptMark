def find_First_Missing(nums):
    for i, num in enumerate(nums):
        # If the current number is not equal to its expected index,
        # then 'i' is the smallest missing natural number.
        if num != i:
            return i
    # If all numbers from 0 up to len(nums)-1 are present,
    # the smallest missing number is len(nums) itself.
    return len(nums)