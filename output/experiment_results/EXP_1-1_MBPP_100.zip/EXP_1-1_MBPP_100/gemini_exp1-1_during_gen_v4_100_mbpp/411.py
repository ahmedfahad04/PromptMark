def snake_to_camel(input_val: str) -> str:
    # Splits the input string by '_' into units.
    name_units = input_val.split('_')
    
    # Capitalizes the first letter of each unit.
    camel_units = [a_unit.capitalize() for a_unit in name_units]
    
    # Joins the capitalized units to form the camel case string.
    camel_join = "".join(camel_units)
    
    return camel_join