def move_num(input_string: str) -> str:
    # Initialize two containers, one for non-numeric characters and one for numeric characters.
    alpha_chars_accum = []
    num_chars_accum = []

    # Iterate through each character in the input string.
    for char_val in input_string:
        # Check if the character is a digit.
        if char_val.isdigit():
            num_chars_accum.append(char_val)
        else:
            alpha_chars_accum.append(char_val)

    # Join the collected non-numeric characters to form the alpha string.
    alpha_string = "".join(alpha_chars_accum)
    # Join the collected numeric characters to form the numeric string.
    num_string = "".join(num_chars_accum)

    # Concatenate the alpha string and the numeric string, with numbers at the end.
    return alpha_string + num_string