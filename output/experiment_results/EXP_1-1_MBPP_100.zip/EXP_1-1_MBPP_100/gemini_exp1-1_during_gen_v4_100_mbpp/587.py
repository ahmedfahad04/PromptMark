def list_tuple(input_array):
    # Convert the input array (list) into a new tuple
    new_combo = tuple(input_array)
    return new_combo