def comb_sort(input_vals: list) -> list:
    num_items = len(input_vals)
    gap = num_items
    # Factor used to shrink the gap
    skip_val = 1.3
    # Tracks if any items moved in a pass
    any_moves = True

    # Continue until gap is 1 and no swaps occur
    while gap > 1 or any_moves:
        if gap > 1:
            gap = int(gap / skip_val)
            # Ensure gap is at least 1
            if gap < 1:
                gap = 1

        any_moves = False
        i = 0
        # Compare and swap items with the current gap
        while i + gap < num_items:
            if input_vals[i] > input_vals[i + gap]:
                # Perform the swap
                input_vals[i], input_vals[i + gap] = input_vals[i + gap], input_vals[i]
                any_moves = True
            i += 1
    return input_vals