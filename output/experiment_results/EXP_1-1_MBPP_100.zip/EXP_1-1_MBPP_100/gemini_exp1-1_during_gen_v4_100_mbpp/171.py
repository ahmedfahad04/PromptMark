def perimeter_pentagon(s_val):
    # Calculate the perimeter of a regular pentagon
    # A regular pentagon has 5 equal sides
    return 5 * s_val