import re

def text_lowercase_underscore(input_string_to_check: str) -> bool:
    # Utilize re.fullmatch to check if the entire string conforms to the pattern.
    # The pattern matches one or more lowercase letters, followed by an underscore,
    # and then one or more lowercase letters.
    # '^' anchors the match to the start of the string, '$' to the end.
    match_val = re.fullmatch(r"^[a-z]+_[a-z]+$", input_string_to_check)
    
    # Return True if a match is found, False otherwise.
    return match_val is not None