def round_and_sum(input_nums):
    # Initialize a sum accumulator
    current_sum = 0
    # Obtain the count of numbers in the input
    num_count = len(input_nums)

    # Iterate through each number, round it, and add to the sum
    for a_num in input_nums:
        current_sum += round(a_num)
    
    # Calculate the final product
    output_val = current_sum * num_count
    return output_val