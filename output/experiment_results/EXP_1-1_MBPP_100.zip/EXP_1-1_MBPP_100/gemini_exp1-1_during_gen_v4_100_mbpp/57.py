def find_Max_Num(input_nums: list[int]) -> int:
    # Convert each digit to its string representation for sorting
    char_nums = [str(num) for num in input_nums]

    # Sort the string digits in descending order
    # This places larger digits at the more significant positions
    sorted_chars = sorted(char_nums, reverse=True)

    # Join the sorted characters to form a single number string
    combined_chars = "".join(sorted_chars)

    # Convert the combined string back to an integer
    max_num_val = int(combined_chars)

    return max_num_val