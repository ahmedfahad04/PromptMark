def common_in_nested_lists(input_lists):
    # If the input list of lists is empty, there are no common elements.
    if not input_lists:
        return set()

    # Initialize a set with the elements of the first inner list.
    # This set will store the currently common elements.
    common_items = set(input_lists[0])

    # Iterate through the remaining inner lists, starting from the second one.
    # We update the 'common_items' set by finding the intersection with each subsequent list.
    for current_inner_list in input_lists[1:]:
        common_items.intersection_update(current_inner_list)
        # If common_items becomes empty, it means there are no elements common to all lists,
        # so we can stop processing further.
        if not common_items:
            break

    return common_items