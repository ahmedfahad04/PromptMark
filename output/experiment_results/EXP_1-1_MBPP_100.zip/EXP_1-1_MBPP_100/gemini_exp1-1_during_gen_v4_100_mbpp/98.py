import math

def multiply_num(num_collection):
    # Handle empty collection to avoid division by zero
    num_count = len(num_collection)
    if num_count == 0:
        return 0.0

    accum_product = 1.0
    for a_num in num_collection:
        accum_product *= a_num
    
    output_val = accum_product / num_count
    return output_val