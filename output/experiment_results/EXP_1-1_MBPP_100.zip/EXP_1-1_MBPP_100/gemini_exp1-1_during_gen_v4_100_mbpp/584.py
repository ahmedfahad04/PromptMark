import re

def find_adverbs(input_unit: str) -> str:
    # Utilize a pattern to find words.
    # \b matches word boundaries, (\w+) captures one or more word characters.
    my_word_way = r'\b(\w+)\b'

    # Iterate on each word match found in the input unit.
    for my_match in re.finditer(my_word_way, input_unit):
        my_word = my_match.group(1) # Obtain the matched word from the capturing group.
        way_start = my_match.start(1) # Word's initial index in the original string.
        way_end = my_match.end(1) # Word's final index in the original string.

        # Check if the extracted word ends with 'ly'.
        if my_word.endswith('ly'):
            # Output the initial match in the specified format.
            return f"{way_start}-{way_end}: {my_word}"

    # If no adverb ending with 'ly' is found after checking all words, return an empty string.
    return ""