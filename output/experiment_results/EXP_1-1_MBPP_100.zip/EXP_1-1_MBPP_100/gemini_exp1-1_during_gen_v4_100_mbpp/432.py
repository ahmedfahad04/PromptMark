def median_trapezium(a_side: float, c_side: float, n_value: float) -> float:
    # The median length of a trapezium is the average of its two parallel sides.
    # We assume 'a_side' and 'c_side' are the lengths of the parallel sides.
    # 'n_value' is an additional value provided but not used in this calculation.
    sum_of_sides = a_side + c_side
    actual_median = sum_of_sides / 2.0
    return actual_median