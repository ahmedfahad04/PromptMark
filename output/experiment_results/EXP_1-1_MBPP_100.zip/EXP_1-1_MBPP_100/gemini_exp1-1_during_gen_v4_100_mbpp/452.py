def loss_amount(income_val: int, my_cost_val: int) -> int:
    # income_val represents the sale price.
    # my_cost_val represents the actual cost price.
    
    # Check if a loss occurred (sale price is less than cost price).
    if income_val < my_cost_val:
        # Calculate the actual loss value.
        loss_val = my_cost_val - income_val
        return loss_val
    else:
        # No loss (profit or break-even), so return 0.
        return 0