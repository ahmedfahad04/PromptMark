def remove_lowercase(input_string):
    # Initialize an empty string to accumulate uppercase characters.
    output_val = ""
    # Iterate over each character in the input string.
    for char_val in input_string:
        # Check if the current character is an uppercase character.
        if char_val.isupper():
            # If it's uppercase, add it to our output string.
            output_val += char_val
    # Return the new string containing only uppercase characters.
    return output_val