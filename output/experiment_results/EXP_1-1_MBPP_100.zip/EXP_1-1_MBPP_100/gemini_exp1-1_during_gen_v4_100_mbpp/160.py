def find_ext_gcd(alpha_val, bravo_val):
    """
    Computes gcd(alpha_val, bravo_val) and integers x, y such that 
    alpha_val*x + bravo_val*y = gcd(alpha_val, bravo_val).
    Returns a tuple (g, x, y).
    """
    if alpha_val == 0:
        return (bravo_val, 0, 1) # Base case: gcd(0, b) = b, with 0*x + b*y = b implies x=0, y=1
    
    # Recursive call for extended Euclidean algorithm
    val_g, val_x1, val_y1 = find_ext_gcd(bravo_val % alpha_val, alpha_val)
    
    # Update x and y using results from recursive call
    val_x = val_y1 - (bravo_val // alpha_val) * val_x1
    val_y = val_x1
    
    return (val_g, val_x, val_y)

def find_solution(alpha, bravo, num_n):
    # Handle special cases where alpha or bravo (or both) are zero
    if alpha == 0 and bravo == 0:
        if num_n == 0:
            return (0, 0) # 0x + 0y = 0; any (x, y) works, choose (0,0)
        else:
            return None # 0x + 0y = num_n (num_n != 0) has no solution

    if alpha == 0: # Equation is bravo*y = num_n
        if num_n % bravo == 0:
            return (0, num_n // bravo) # Choose x=0
        else:
            return None

    if bravo == 0: # Equation is alpha*x = num_n
        if num_n % alpha == 0:
            return (num_n // alpha, 0) # Choose y=0
        else:
            return None

    # For non-zero alpha and bravo, use the extended Euclidean algorithm
    cmn_div, one_x, one_y = find_ext_gcd(alpha, bravo)

    # A solution exists if and only if num_n is divisible by cmn_div (gcd(alpha, bravo))
    if num_n % cmn_div != 0:
        return None
    
    # Calculate a particular solution (x_p, y_p)
    my_k = num_n // cmn_div
    x_p = one_x * my_k
    y_p = one_y * my_k

    # Adjust the particular solution to find the smallest non-negative x
    # General solution: x = x_p + t * (bravo/cmn_div), y = y_p - t * (alpha/cmn_div)
    # We want x in the range [0, bravo/cmn_div - 1]
    
    # Calculate the modulus for x adjustment
    # bravo_over_g is always positive here since bravo != 0 and cmn_div > 0.
    bravo_over_g = bravo // cmn_div 
    
    x_final = x_p % bravo_over_g
    
    # Python's % operator handles negative numbers correctly for this purpose (e.g., -7 % 3 = 2)
    # If x_final was negative (e.g., if bravo_over_g was negative, which is not the case here)
    # if x_final < 0:
    #     x_final += bravo_over_g

    # Calculate the corresponding y for the adjusted x
    y_final = (num_n - alpha * x_final) // bravo
    
    return (x_final, y_final)