def extract_singly(input_collection):
    """
    Flattens a list of collections (like tuples or lists) into a single set of unique numbers.
    """
    output_unique_nums = set()
    for current_collection in input_collection:
        for a_num_value in current_collection:
            output_unique_nums.add(a_num_value)
    return output_unique_nums