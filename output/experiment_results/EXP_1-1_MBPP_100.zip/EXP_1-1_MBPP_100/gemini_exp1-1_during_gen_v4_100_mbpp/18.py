def remove_dirty_chars(input_string: str, skip_chars: str) -> str:
    # Convert the characters to skip into a set for efficient O(1) lookups.
    junk_set = set(skip_chars)

    ans_chars = []
    for char_item in input_string:
        # If the character is not in the set of characters to skip, add it to our list.
        if char_item not in junk_set:
            ans_chars.append(char_item)

    # Join the collected characters to form the new string.
    return "".join(ans_chars)