def toggle_middle_bits(num_val: int) -> int:
    # Determine the number of bits in the input value.
    # For instance, 9 (0b1001) has 4 bits.
    count_bits = num_val.bit_length()

    # If a number has fewer than 3 bits (e.g., 0, 1, 0b10, 0b11),
    # there are no "middle" bits to toggle, as the first and last bits
    # are the only bits, or there are fewer than two bits.
    # In these cases, the original number is simply returned.
    if count_bits < 3:
        return num_val

    # Create an initial mask where all `count_bits` positions are set to 1.
    # Example: if count_bits is 4, this creates 0b1111.
    one_mask = (1 << count_bits) - 1

    # Create a mask to isolate the least significant bit (LSB).
    # This is always 1 (0b0...01).
    low_mask = 1

    # Create a mask to isolate the most significant bit (MSB).
    # This is achieved by shifting 1 to the (count_bits - 1)-th position.
    # Example: if count_bits is 4, MSB is at index 3, so 1 << 3 results in 0b1000.
    high_mask = 1 << (count_bits - 1)

    # Construct the middle bits mask.
    # By XORing the all-ones mask with the LSB mask and the MSB mask,
    # we effectively unset the LSB and MSB positions in the all-ones mask,
    # leaving only the middle bits set to 1.
    # Example: 0b1111 ^ 0b0001 ^ 0b1000 = 0b0110.
    middle_mask_val = one_mask ^ low_mask ^ high_mask

    # Toggle the middle bits of the original number.
    # The XOR operation flips bits where the mask has a 1, and leaves bits
    # unchanged where the mask has a 0.
    outcome = num_val ^ middle_mask_val
    return outcome