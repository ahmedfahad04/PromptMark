def Split(input_nums: list[int]) -> list[int]:
    """
    Finds all even numbers from a list of integers.

    Args:
        input_nums: A list of integers.

    Returns:
        A new list containing only the even numbers from the input list.
    """
    # Use a list comprehension to efficiently collect even numbers
    output_nums = [num for num in input_nums if num % 2 == 0]
    return output_nums