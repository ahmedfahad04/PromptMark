def rectangle_area(one_num, any_num):
    # Calculate the product of the two input numbers for area
    return one_num * any_num