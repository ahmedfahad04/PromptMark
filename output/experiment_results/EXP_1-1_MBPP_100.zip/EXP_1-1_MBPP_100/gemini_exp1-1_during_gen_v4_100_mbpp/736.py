def left_insertion(input_array: list, input_value: int) -> int:
    """
    Locates the left insertion point for a specified value in a sorted array.
    This implementation uses a binary search approach.
    """
    array_count = len(input_array)
    low_idx = 0
    up_idx = array_count

    while low_idx < up_idx:
        mid_idx = (low_idx + up_idx) // 2
        # If the value at mid_idx is less than the input_value,
        # the insertion point must be in the upper half.
        if input_array[mid_idx] < input_value:
            low_idx = mid_idx + 1
        # Otherwise, the insertion point is at or before mid_idx.
        else:
            up_idx = mid_idx
            
    # low_idx now points to the insertion point.
    return low_idx