def is_perfect_square(num):
    # A perfect square cannot be a negative number.
    if num < 0:
        return False

    # Zero is a perfect square (0 * 0 = 0).
    if num == 0:
        return True

    # Calculate an approximate integer square root.
    # Python's `** 0.5` uses float arithmetic, which can sometimes lead to
    # precision inaccuracies for very large integers.
    main_val = int(num**0.5)

    # Check if the square of our main candidate equals the original number.
    if main_val * main_val == num:
        return True

    # Due to potential float precision issues, the actual integer square root
    # might sometimes be `main_val` or `main_val + 1`.
    # For example, `int( (N*N + 1)**0.5 )` might yield N, while the true
    # square root of N*N+1 is slightly above N.
    # We check the next integer candidate as well.
    inc_main_val = main_val + 1
    if inc_main_val * inc_main_val == num:
        return True

    return False