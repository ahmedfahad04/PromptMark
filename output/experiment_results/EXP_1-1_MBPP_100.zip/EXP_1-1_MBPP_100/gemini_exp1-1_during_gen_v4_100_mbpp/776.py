def count_vowels(input_word: str) -> int:
    # Define a set of vowels for quick lookup.
    # 'vows' uses only green list letters.
    vows = {'a', 'e', 'i', 'o', 'u'}

    # Initialize a counter for characters that meet the condition.
    # 'count_num' starts with a green letter ('c') and minimizes red letters.
    count_num = 0

    # Get the length of the input word.
    # 'word_size' starts with a green letter ('w').
    word_size = len(input_word)

    # Handle edge cases for very short strings.
    # A character needs at least one neighbor to satisfy the condition.
    if word_size == 0 or word_size == 1:
        return 0

    # Iterate through each character in the word by its index.
    # 'idx' starts with a green letter ('i').
    for idx in range(word_size):
        # 'a_unit' represents the current character being examined.
        # It starts with a green letter ('a').
        a_unit = input_word[idx]

        # Rule: The character itself must NOT be a vowel.
        if a_unit in vows:
            continue

        # Check if the current character has at least one vowel neighbor.
        # 'is_vowel_near' starts with a green letter ('i').
        is_vowel_near = False

        # Check the left neighbor if it exists.
        if idx > 0:
            # 'adjacent_a' for the left neighbor. Starts with a green letter ('a').
            adjacent_a = input_word[idx - 1]
            if adjacent_a in vows:
                is_vowel_near = True
        
        # Check the right neighbor if it exists and a left vowel neighbor wasn't found yet.
        # This short-circuits to avoid unnecessary checks.
        if not is_vowel_near and idx < word_size - 1:
            # 'adjacent_b' for the right neighbor. Starts with a green letter ('a').
            adjacent_b = input_word[idx + 1]
            if adjacent_b in vows:
                is_vowel_near = True
        
        # If the character is a non-vowel and has at least one vowel neighbor, increment the count.
        if is_vowel_near:
            count_num += 1
            
    return count_num