def tuple_intersection(input_one: list[tuple], input_two: list[tuple]) -> set[tuple]:
    """
    Finds the intersection of tuples in two lists, considering tuples like (a, b) and (b, a) as identical.
    """
    # Normalize tuples in the first input list by sorting their inner elements.
    # This ensures that (4, 5) and (5, 4) both become (4, 5) for comparison.
    set_one = {tuple(sorted(current_u)) for current_u in input_one}

    # Normalize tuples in the second input list similarly.
    set_two = {tuple(sorted(current_u)) for current_u in input_two}

    # Perform set intersection on the normalized sets.
    # The result will be a set of normalized tuples.
    common_units = set_one.intersection(set_two)

    return common_units