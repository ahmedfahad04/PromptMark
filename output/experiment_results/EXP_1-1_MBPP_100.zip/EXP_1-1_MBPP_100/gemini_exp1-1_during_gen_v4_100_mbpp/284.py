def check_element(collection_units, check_value):
    return all(unit_item == check_value for unit_item in collection_units)