def merge_dictionaries_three(one_map: dict, two_map: dict, many_map: dict) -> dict:
    # Merge dictionaries. Keys from later arguments in the unpacking
    # will overwrite values from earlier arguments if keys overlap.
    # This means one_map's values take precedence, then two_map's, then many_map's.
    out_map = {**many_map, **two_map, **one_map}
    return out_map