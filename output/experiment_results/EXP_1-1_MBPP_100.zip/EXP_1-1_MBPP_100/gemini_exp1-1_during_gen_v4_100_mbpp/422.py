def find_Average_Of_Cube(n: int) -> float:
    # Initialize a variable to accumulate the sum of cubes
    cube_sum = 0.0

    # Iterate through the first 'n' natural numbers
    for i in range(1, n + 1):
        # Add the cube of the current number to the sum
        cube_sum += i ** 3

    # Calculate the average by dividing the total sum by 'n'
    # 'n' is always a positive natural number here, so no division by zero occurs.
    avg_num = cube_sum / n
    return avg_num