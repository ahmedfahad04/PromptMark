def largest_subset(input_nums: list[int]) -> int:
    # Handle the case of an empty input list
    if not input_nums:
        return 0

    # Sort the input numbers to simplify divisibility checks.
    # If a % b == 0, then a must be >= b.
    sorted_nums = sorted(input_nums)
    num_count = len(sorted_nums)

    # current_max_counts[i] will store the size of the largest divisible subset
    # ending with sorted_nums[i].
    # Initialize each number as a subset of size 1.
    current_max_counts = [1] * num_count

    # Initialize the overall maximum subset size found so far.
    max_count = 1

    # Iterate through each number in the sorted list, starting from the second one.
    for idx_i in range(1, num_count):
        val_i = sorted_nums[idx_i]

        # For current_num, check all previous numbers.
        for idx_j in range(idx_i):
            val_j = sorted_nums[idx_j]

            # If current_num is divisible by prev_num, it means we can potentially
            # extend the divisible subset ending with prev_num.
            if val_i % val_j == 0:
                # Update current_max_counts[idx_i] if adding val_i to the subset
                # ending at val_j creates a larger subset.
                current_max_counts[idx_i] = max(
                    current_max_counts[idx_i],
                    current_max_counts[idx_j] + 1
                )

        # Update the overall maximum count found.
        max_count = max(max_count, current_max_counts[idx_i])

    return max_count