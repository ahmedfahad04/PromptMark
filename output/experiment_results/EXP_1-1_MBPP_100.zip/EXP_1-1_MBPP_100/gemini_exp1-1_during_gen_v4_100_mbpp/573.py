def unique_product(input_nums: list) -> int:
    # Obtain only the unique numbers from the input list.
    unique_nums = set(input_nums)

    # Initialize the product. Multiplying by 1 ensures the correct product,
    # especially if unique_nums is empty (product of an empty set is 1).
    accum_product = 1

    # Iterate through each unique number and multiply it into the accumulator.
    for num_val in unique_nums:
        accum_product *= num_val

    return accum_product