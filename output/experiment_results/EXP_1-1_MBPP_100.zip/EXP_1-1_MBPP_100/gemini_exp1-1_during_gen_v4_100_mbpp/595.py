def min_Swaps(val_a: str, val_b: str) -> int | str:
    # Check if the input binary strings have the same length
    if len(val_a) != len(val_b):
        return "Not Possible"

    array_count = len(val_a)

    # Count the occurrences of '0' and '1' in both binary strings
    num_ones_a = val_a.count('1')
    num_zeros_a = val_a.count('0')
    num_ones_b = val_b.count('1')
    num_zeros_b = val_b.count('0')

    # If the counts of '0's or '1's do not match, conversion is not possible
    if num_ones_a != num_ones_b or num_zeros_a != num_zeros_b:
        return "Not Possible"

    # Count the number of positions where val_a has a '1' and val_b has a '0'.
    # Each such '1' needs to be swapped with a '0' from a position where val_a has '0' and val_b has '1'.
    # The minimum number of swaps is this count.
    swap_unit_count = 0
    for idx in range(array_count):
        if val_a[idx] == '1' and val_b[idx] == '0':
            swap_unit_count += 1

    return swap_unit_count