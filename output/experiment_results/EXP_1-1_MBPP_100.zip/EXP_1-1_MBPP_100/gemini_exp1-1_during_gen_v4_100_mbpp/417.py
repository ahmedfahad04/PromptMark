import collections

def group_tuples(input_uni):
    # Group second items by first item.
    common_map = collections.defaultdict(list)

    # Populate map with values.
    for uni_item in input_uni:
        initial_val, content_val = uni_item
        common_map[initial_val].append(content_val)

    # Accumulate final tuples.
    output_uni = []

    # Construct final tuples from the map.
    for initial_val, content_items in common_map.items():
        output_uni.append((initial_val,) + tuple(content_items))

    return output_uni