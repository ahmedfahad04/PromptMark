def find_Element(nums, rotations, k, ind):
  """
  This function returns the element at a given index after number of rotations.
  """
  for r in rotations:
    nums = nums[r[0]:] + nums[:r[0]]
  if k >= len(nums):
    k = k % len(nums)
  return nums[ind-1]