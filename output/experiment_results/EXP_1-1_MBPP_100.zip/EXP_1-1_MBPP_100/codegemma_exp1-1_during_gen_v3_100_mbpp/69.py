def is_sublist(list, sublist):
  """
  Checks if a sublist is a sublist of a list.
  """
  for i in range(len(list)):
    if list[i] == sublist[0]:
      for j in range(len(sublist)):
        if i + j >= len(list):
          return False
        if list[i + j] != sublist[j]:
          break
      return True
  return False