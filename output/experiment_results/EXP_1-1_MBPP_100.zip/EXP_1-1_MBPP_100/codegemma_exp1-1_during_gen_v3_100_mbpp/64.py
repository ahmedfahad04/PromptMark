def subject_marks(marks):
    """
    This function sorts a list of tuples using the second value of each tuple.
    """
    return sorted(marks, key=lambda x: x[1])