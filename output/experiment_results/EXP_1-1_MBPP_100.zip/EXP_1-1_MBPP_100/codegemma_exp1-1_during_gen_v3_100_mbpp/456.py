def reverse_string_list(str_list):
  """
  Reverses each string in a list of string values.

  Args:
    str_list: A list of string values.

  Returns:
    A new list of strings with each string reversed.
  """
  reversed_str_list = []
  for string in str_list:
    reversed_str_list.append(string[::-1])
  return reversed_str_list