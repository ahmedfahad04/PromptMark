def remove_lowercase(text):
    """
    This function removes all lowercase substrings from a given string.
    """
    return ''.join([char for char in text if not char.islower()])