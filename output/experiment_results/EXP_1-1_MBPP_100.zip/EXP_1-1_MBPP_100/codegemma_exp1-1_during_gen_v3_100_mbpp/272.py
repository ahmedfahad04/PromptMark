def rear_extract(tuple_list):
    """
    This function takes in a list of tuples and returns a list containing the rear element of each tuple.
    """
    return [tup[-1] for tup in tuple_list]