def drop_empty(dict):
    """
    Drops empty items from a given dictionary.
    """
    return {key: value for key, value in dict.items() if value is not None}