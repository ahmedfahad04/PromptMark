from math import sqrt

def otherside_rightangle(side1, side2):
    """
    This function finds the third side of a right angled triangle given the other two sides.
    """
    return sqrt(side1**2 + side2**2)