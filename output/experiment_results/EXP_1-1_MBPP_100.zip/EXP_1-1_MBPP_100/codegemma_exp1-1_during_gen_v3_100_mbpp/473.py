def tuple_intersection(list1, list2):
    """
    This function takes two lists of tuples and returns a set of tuples that are present in both lists.
    """
    set1 = set(list1)
    set2 = set(list2)
    return set1 & set2