def extract_nth_element(list_of_tuples, n):
    """
    This function extracts the nth element from a given list of tuples.

    Args:
        list_of_tuples: A list of tuples.
        n: The index of the element to extract.

    Returns:
        The nth element from the list of tuples.
    """
    return [tup[n] for tup in list_of_tuples]