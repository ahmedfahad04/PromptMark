def find(a, b):
    """
    This function finds the quotient of two numbers (rounded down to the nearest integer).
    """
    return a // b