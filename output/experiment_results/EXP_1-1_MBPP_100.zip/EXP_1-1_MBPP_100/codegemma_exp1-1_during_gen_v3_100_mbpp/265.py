def list_split(list, n):
    """
    Splits a list for every nth element, returning a list of the resulting lists.
    """
    result = []
    for i in range(0, len(list), n):
        result.append(list[i:i + n])
    return result