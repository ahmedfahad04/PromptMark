def text_match_wordz(text):
    """
    Checks if a word in the given text contains the letter 'z'.
    """
    if "z" in text:
        return True
    else:
        return False