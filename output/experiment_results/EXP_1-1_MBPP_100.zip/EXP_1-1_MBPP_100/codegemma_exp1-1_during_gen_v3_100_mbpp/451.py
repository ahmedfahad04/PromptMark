def remove_whitespaces(text):
    return text.replace(" ", "")