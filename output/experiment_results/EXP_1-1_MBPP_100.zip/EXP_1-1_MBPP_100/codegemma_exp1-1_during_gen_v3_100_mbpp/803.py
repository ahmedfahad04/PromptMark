def is_perfect_square(num):
  """
  Checks if the given number is a perfect square or not.
  """
  if num < 0:
    return False
  
  sqrt = num ** 0.5
  return sqrt == int(sqrt)