def count_vowels(text):
    count = 0
    vowels = {'a', 'e', 'i', 'o', 'u'}
    for i in range(len(text)):
        if text[i] in vowels and (i == 0 or text[i - 1] not in vowels) and (i == len(text) - 1 or text[i + 1] not in vowels):
            count += 1
    return count