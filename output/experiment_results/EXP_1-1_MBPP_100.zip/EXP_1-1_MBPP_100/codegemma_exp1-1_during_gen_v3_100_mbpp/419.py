def round_and_sum(num_list):
  """
  This function rounds every number of a given list of numbers and prints the total sum multiplied by the length of the list.
  """
  rounded_list = [round(num) for num in num_list]
  sum_of_rounded_list = sum(rounded_list)
  print(sum_of_rounded_list * len(num_list))