def check_value(dict, val):
  for k, v in dict.items():
    if v != val:
      return False
  return True