def min_Swaps(num1, num2):
    """
    This function takes two binary numbers as input and returns the minimum number of swaps required to convert one to the other.
    """
    if num1 == num2:
        return "Not Possible"
    
    num1_list = list(num1)
    num2_list = list(num2)
    
    num1_set = set(num1_list)
    num2_set = set(num2_list)
    
    if num1_set != num2_set:
        return "Not Possible"
    
    num1_dict = {}
    num2_dict = {}
    
    for i in range(len(num1_list)):
        num1_dict[num1_list[i]] = i
        num2_dict[num2_list[i]] = i
    
    num1_list.sort()
    num2_list.sort()
    
    swaps = 0
    
    for i in range(len(num1_list)):
        if num1_list[i] != num2_list[i]:
            num1_index = num1_dict[num2_list[i]]
            num2_index = num2_dict[num1_list[i]]
            num1_list[num1_index], num1_list[i] = num1_list[i], num1_list[num1_index]
            num2_list[num2_index], num2_list[i] = num2_list[i], num2_list[num2_index]
            swaps += 1
    
    return swaps