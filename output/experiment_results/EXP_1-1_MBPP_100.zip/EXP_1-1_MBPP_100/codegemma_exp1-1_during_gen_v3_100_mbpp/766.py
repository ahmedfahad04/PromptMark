def pair_wise(lst):
  """
  Returns a list of all pairs of consecutive items in a given list.
  """
  return [(lst[i], lst[i + 1]) for i in range(len(lst) - 1)]