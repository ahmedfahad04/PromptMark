def extract_singly(nested_list):
  """
  Extracts a flattened set of numbers from a nested list of lists.
  """
  flattened_set = set()
  for sublist in nested_list:
    for number in sublist:
      flattened_set.add(number)
  return flattened_set