def find_lucas(n):
    """
    This function finds the n'th lucas number.
    """
    if n == 1:
        return 2
    elif n == 2:
        return 1
    else:
        num1, num2 = 2, 1
        for i in range(n - 2):
            num1, num2 = num2, num1 + num2
        return num2