def list_tuple(list):
    return tuple(list)