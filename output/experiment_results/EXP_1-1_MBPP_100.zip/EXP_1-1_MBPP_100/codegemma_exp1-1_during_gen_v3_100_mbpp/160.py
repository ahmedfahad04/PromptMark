def find_solution(a, b, n):
    """
    Finds the solution to ax + by = n as a tuple (x, y), or None if no solution exists.
    """
    if a == 0 and b == 0:
        if n == 0:
            return (0, 0)
        else:
            return None
    elif a == 0:
        if b * n % a == 0:
            return (0, n // b)
        else:
            return None
    elif b == 0:
        if a * n % b == 0:
            return (n // a, 0)
        else:
            return None
    else:
        gcd = math.gcd(a, b)
        if n % gcd != 0:
            return None
        else:
            a_prime = a // gcd
            b_prime = b // gcd
            n_prime = n // gcd
            x = find_solution(a_prime, b_prime, n_prime)
            if x is None:
                return None
            else:
                return (x[0] * b_prime + n_prime, x[1] * a_prime)