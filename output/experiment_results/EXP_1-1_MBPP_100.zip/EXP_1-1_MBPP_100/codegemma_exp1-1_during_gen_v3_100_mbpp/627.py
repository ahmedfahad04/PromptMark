def find_First_Missing(nums):
  """
  This function takes a sorted list of natural numbers and returns the smallest missing number.
  """
  if not nums or nums[-1] < 1:
    return 0
  if nums[0] > 1:
    return 1
  for i in range(1, len(nums)):
    if nums[i] - nums[i - 1] > 1:
      return nums[i - 1] + 1
  return nums[-1] + 1