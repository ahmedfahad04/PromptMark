def find_adverbs(text):
    adverbs = []
    for i, word in enumerate(text.split()):
        if word.endswith("ly") and word.istitle():
            adverbs.append(f"{i}-{i + len(word):}: {word}")
    return "\n".join(adverbs)