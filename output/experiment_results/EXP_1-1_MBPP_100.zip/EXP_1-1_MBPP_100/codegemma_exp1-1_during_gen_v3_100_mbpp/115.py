def empty_dit(list_of_dict):
    for d in list_of_dict:
        if d:
            return False
    return True