def square_Sum(n):
    """
    This function takes in an integer n and returns the sum of the squares of the first n odd natural numbers.
    """
    sum = 0
    for i in range(1, n + 1):
        sum += i ** 2
    return sum