def largest_subset(nums):
  """
  Finds the size of the largest subset of a list of numbers so that every pair is divisible.

  Args:
    nums: A list of numbers.

  Returns:
    The size of the largest subset.
  """

  # Sort the list in ascending order.
  nums.sort()

  # Initialize the size of the largest subset to 1.
  max_size = 1

  # Iterate over the list of numbers.
  for i in range(1, len(nums)):
    # Check if the current number is divisible by the previous number.
    if nums[i] % nums[i - 1] == 0 or nums[i - 1] % nums[i] == 0:
      # If the current number is divisible by the previous number, increment the size of the largest subset by 1.
      max_size += 1

  # Return the size of the largest subset.
  return max_size