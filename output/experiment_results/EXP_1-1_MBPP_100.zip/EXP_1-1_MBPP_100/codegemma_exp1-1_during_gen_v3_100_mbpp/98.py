import math

def multiply_num(num_list):
    """
    This function multiplies all the numbers in a list and divides with the length of the list.
    """
    product = 1
    for num in num_list:
        product *= num
    return product / len(num_list)