def new_tuple(list_of_words, str_to_add):
    """
    Creates a new tuple from the given string and list.

    Args:
    list_of_words: A list of words.
    str_to_add: A string to add to the tuple.

    Returns:
    A new tuple with the string and list appended.
    """

    new_tuple = tuple(list_of_words + [str_to_add])
    return new_tuple