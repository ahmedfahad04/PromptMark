def merge(list_of_lists):
  """
  Merges a list of lists into two lists.
  The first list contains the first element of each sublist,
  and the second list contains the second element of each sublist.
  """
  list1 = []
  list2 = []
  for sublist in list_of_lists:
    list1.append(sublist[0])
    list2.append(sublist[1])
  return [list1, list2]