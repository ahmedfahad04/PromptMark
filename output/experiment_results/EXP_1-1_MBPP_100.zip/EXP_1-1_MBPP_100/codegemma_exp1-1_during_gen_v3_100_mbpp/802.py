def count_rotation(nums):
    """
    Counts the number of rotations required to generate a sorted array.
    """
    # Find the minimum element in the array
    min_element = min(nums)
    
    # Get the index of the minimum element
    min_index = nums.index(min_element)
    
    # Calculate the number of rotations
    rotations = min_index + 1
    
    return rotations