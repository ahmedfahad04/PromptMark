def median_trapezium(a,b,c):
    """
    Calculates the median length of a trapezium given the lengths of its two parallel sides and the length of the perpendicular from the top side to the line containing the two parallel sides.
    """
    # Calculate the area of the trapezium using the formula: area = (a + b) * c / 2
    area = (a + b) * c / 2

    # Calculate the length of the median using the formula: median = (area * 2) / a
    median = (area * 2) / a

    return median