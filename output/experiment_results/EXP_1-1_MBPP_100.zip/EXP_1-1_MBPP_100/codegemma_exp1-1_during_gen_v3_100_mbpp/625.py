def swap_List(list):
  if len(list) < 2:
    return list
  else:
    list[0], list[-1] = list[-1], list[0]
    return list