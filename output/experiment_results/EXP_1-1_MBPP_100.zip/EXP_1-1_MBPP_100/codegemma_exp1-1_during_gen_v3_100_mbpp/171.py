def perimeter_pentagon(side):
    """
    Calculates the perimeter of a regular pentagon from the length of its sides.

    Args:
        side: The length of one side of the pentagon.

    Returns:
        The perimeter of the pentagon.
    """
    return 5 * side