import math

def polar_rect(rho, theta):
    """
    Converts polar coordinates to rectangular coordinates.

    Args:
    rho: The distance from the origin to the point.
    theta: The angle of the line connecting the origin to the point.

    Returns:
    A tuple containing the rectangular coordinates (x, y) and the complex number representation of the point.
    """

    x = rho * math.cos(theta)
    y = rho * math.sin(theta)
    return (x, y), complex(x, y)