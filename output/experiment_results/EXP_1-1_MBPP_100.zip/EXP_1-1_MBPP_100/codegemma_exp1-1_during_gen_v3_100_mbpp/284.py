def check_element(list, element):
  for item in list:
    if item != element:
      return False
  return True