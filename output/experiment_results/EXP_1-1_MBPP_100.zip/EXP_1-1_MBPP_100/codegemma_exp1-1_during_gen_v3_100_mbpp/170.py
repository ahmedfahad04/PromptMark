def sum_range_list(nums, start, end):
    """
    This function takes a list of numbers and two indices as input and returns the sum of numbers in the range between the two indices (inclusive).
    """
    sum = 0
    for i in range(start, end + 1):
        sum += nums[i]
    return sum