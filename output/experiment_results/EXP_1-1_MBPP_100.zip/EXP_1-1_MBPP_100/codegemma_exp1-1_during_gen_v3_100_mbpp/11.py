def remove_Occ(str, char):
  """
  This function removes the first and last occurrence of a given character from a string.
  """
  # Remove the first occurrence of the character.
  str = str.replace(char, "", 1)
  # Remove the last occurrence of the character.
  str = str.replace(char, "", 1)
  return str