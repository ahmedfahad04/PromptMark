def square_nums(nums):
  """
  This function takes a list of numbers and returns a new list with the squares of the individual elements in the input list.
  """
  squares = []
  for num in nums:
    squares.append(num**2)
  return squares