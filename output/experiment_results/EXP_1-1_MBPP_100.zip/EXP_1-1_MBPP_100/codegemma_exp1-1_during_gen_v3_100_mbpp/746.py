import math

def sector_area(radius, angle):
  """
  This function calculates the area of a sector given the radius and angle.
  """
  if angle > 360:
    return None
  return (math.pi * radius**2 * angle) / 360