def mul_even_odd(nums):
    """
    This function takes a list of numbers and returns the product of the first even and odd number in the list.
    """
    for num in nums:
        if num % 2 == 0:
            even = num
        if num % 2 != 0:
            odd = num
    return even * odd