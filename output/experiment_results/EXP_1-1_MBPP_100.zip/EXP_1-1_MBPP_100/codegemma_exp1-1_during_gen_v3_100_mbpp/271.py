def even_Power_Sum(n):
    """
    This function takes in an integer n and returns the sum of the first n even natural numbers that are raised to the fifth power.
    """
    sum = 0
    for i in range(1, n + 1):
        sum += i ** 5
    return sum