def count_X(tup, x):
  count = 0
  for item in tup:
    if item == x:
      count += 1
  return count