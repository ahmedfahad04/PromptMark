def odd_num_sum(n):
  """
  This function calculates the sum of fourth power of first n odd natural numbers.
  """
  sum_of_fourth_power = 0
  for i in range(1, n + 1):
    sum_of_fourth_power += i ** 4
  return sum_of_fourth_power