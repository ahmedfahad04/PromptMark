def frequency_lists(lists):
    """
    This function takes a flattened list of lists and returns a dictionary of the frequency of each element in the flattened list.
    """
    frequency = {}
    for sublist in lists:
        for element in sublist:
            if element not in frequency:
                frequency[element] = 0
            frequency[element] += 1
    return frequency