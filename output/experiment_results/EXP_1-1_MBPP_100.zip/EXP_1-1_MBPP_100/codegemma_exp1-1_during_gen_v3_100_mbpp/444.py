def trim_tuple(tuple_list, k):
    """
    Trims each tuple by k in the given tuple list.

    Args:
    tuple_list: A list of tuples.
    k: The number of elements to trim from each tuple.

    Returns:
    A list of trimmed tuples.
    """
    trimmed_tuples = []
    for tup in tuple_list:
        trimmed_tuples.append(tup[k:])
    return trimmed_tuples