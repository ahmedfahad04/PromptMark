def remove_nested(tuple_in):
    """
    This function removes nested tuples from a given tuple.
    """
    return tuple(item for item in tuple_in if not isinstance(item, tuple))