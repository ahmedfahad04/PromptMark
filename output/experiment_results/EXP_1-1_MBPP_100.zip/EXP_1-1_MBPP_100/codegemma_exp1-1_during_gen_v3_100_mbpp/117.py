def list_to_float(list_of_lists):
  """
  Converts all possible convertible elements in a list of lists to floats.
  """
  for sublist in list_of_lists:
    for i, element in enumerate(sublist):
      if isinstance(element, str):
        try:
          sublist[i] = float(element)
        except ValueError:
          pass
  return list_of_lists