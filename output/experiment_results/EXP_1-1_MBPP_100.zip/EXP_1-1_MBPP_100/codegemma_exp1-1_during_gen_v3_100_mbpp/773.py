def occurance_substring(text, substring):
    """
    This function takes two arguments: text and substring.
    It returns a tuple containing the substring and its position in the text.
    """
    if substring in text:
        return (substring, text.index(substring), text.index(substring) + len(substring))
    else:
        return None