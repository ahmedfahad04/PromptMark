def intersection_array(arr1, arr2):
  """
  This function takes two arrays and returns the intersection of the two arrays.
  The intersection of two arrays is the set of elements that are common to both arrays.
  """
  # Create a set of the first array
  set1 = set(arr1)
  # Create a set of the second array
  set2 = set(arr2)
  # Find the intersection of the two sets
  intersection = set1 & set2
  # Convert the intersection set to a list
  intersection_list = list(intersection)
  # Return the intersection list
  return intersection_list