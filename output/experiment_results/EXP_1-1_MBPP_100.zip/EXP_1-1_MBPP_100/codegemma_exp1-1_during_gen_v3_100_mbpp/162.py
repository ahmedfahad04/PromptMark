def sum_series(n):
  """
  Calculates the sum (n - 2*i) from i=0 to n // 2.

  Args:
    n: The number to start the series from.

  Returns:
    The sum of the series.
  """
  sum = 0
  for i in range(n // 2 + 1):
    sum += n - 2 * i
    n -= 2
  return sum