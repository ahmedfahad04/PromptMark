def parabola_directrix(a, b, c):
    """
    This function returns the directrix of a parabola given the equation of the parabola.
    The equation of the parabola is y = ax^2 + bx + c.
    The directrix of a parabola is a horizontal line that is equidistant from the focus and the vertex of the parabola.
    The directrix of a parabola is given by the equation y = -a / 4.
    """
    return -a / 4