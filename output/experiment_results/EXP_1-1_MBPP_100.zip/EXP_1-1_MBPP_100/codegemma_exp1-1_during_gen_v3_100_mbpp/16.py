def text_lowercase_underscore(text):
  """
  Checks if the input string contains sequences of lowercase letters joined with an underscore.
  """
  if not text or not text.lower() == text:
    return False
  if "_" not in text:
    return True
  if text.split("_")[-1].islower():
    return True
  return False