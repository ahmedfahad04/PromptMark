def move_num(s):
    """
    Moves all the numbers to the end of the given string.
    """
    nums = [ch for ch in s if ch.isdigit()]
    res = ''.join([ch for ch in s if not ch.isdigit()])
    res += ''.join(nums)
    return res