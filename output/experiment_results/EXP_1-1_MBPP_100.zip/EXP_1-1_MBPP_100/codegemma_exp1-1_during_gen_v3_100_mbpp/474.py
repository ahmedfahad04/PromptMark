def replace_char(text, char, new_char):
    """
    Replaces all occurrences of a character in a string with another character.

    Args:
    text: The string to replace characters in.
    char: The character to replace.
    new_char: The new character to replace with.

    Returns:
    The string with all occurrences of the character replaced.
    """
    return text.replace(char, new_char)