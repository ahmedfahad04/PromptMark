def extract_string(str_list, size):
  return [str_ for str_ in str_list if len(str_) == size]