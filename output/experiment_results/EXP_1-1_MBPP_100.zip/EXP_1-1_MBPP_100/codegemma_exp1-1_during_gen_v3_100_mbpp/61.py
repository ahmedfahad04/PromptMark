def count_Substrings(num):
    count = 0
    for i in range(len(num)):
        for j in range(i, len(num)):
            substring = num[i:j+1]
            if sum(int(digit) for digit in substring) == len(substring):
                count += 1
    return count