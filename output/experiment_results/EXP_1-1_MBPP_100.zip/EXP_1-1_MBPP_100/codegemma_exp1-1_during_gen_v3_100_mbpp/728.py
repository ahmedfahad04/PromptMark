def sum_list(a, b):
  """
  This function takes as input two lists [a_1,...,a_n], [b_1,...,b_n] and returns [a_1+b_1,...,a_n+b_n].
  """
  return [a_i + b_i for a_i, b_i in zip(a, b)]