def remove_dirty_chars(str1, str2):
    """
    This function removes characters from the first string which are present in the second string.
    """
    # Create a set of characters to remove
    remove_set = set(str2)

    # Remove the characters from the first string
    clean_str = ''.join([char for char in str1 if char not in remove_set])

    return clean_str