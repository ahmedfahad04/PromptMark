def count_bidirectional(tuples):
    """
    Counts bidirectional tuple pairs in a list of tuples.
    """
    bidirectional_pairs = set()
    for (first, second) in tuples:
        if (second, first) in bidirectional_pairs:
            bidirectional_pairs.remove((second, first))
        else:
            bidirectional_pairs.add((first, second))
    return len(bidirectional_pairs)