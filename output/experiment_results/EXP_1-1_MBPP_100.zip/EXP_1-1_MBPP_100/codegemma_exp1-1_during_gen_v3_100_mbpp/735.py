def toggle_middle_bits(num):
  """
  This function toggles the middle bits of a number except the first and the last bit.
  """
  num = num & ((1 << (int(math.log2(num)) - 1)) - 1)
  num = num ^ ((1 << (int(math.log2(num)) - 1)) - 1)
  return num