def find_Max_Num(nums):
    """
    This function takes a list of digits and returns the largest number that can be formed with them.
    """
    nums = [str(num) for num in nums]
    nums.sort(key=lambda x: x*3, reverse=True)
    return int(''.join(nums))