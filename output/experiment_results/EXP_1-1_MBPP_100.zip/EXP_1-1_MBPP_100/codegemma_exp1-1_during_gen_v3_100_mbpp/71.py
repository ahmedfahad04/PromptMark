def comb_sort(arr):
    gap = len(arr)
    swapped = True
    
    while gap > 0 and swapped:
        swapped = False
        for i in range(gap, len(arr)):
            j = i - gap
            if arr[j] > arr[j + gap]:
                arr[j], arr[j + gap] = arr[j + gap], arr[j]
                swapped = True
        gap = int(gap / 1.3)
    
    return arr