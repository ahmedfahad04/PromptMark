def common_in_nested_lists(nested_lists):
  """
  Finds the common elements in given nested lists.

  Args:
    nested_lists: A list of lists.

  Returns:
    A set of common elements in the nested lists.
  """

  common_elements = set()
  for lst in nested_lists:
    for element in lst:
      if element in common_elements:
        continue
      common_elements.add(element)
  return common_elements