def capital_words_spaces(text):
  """
  This function adds spaces between words starting with capital letters in a given string.
  """
  new_text = []
  for i in range(len(text)):
    if i == 0 or text[i - 1].islower() and text[i].isupper():
      new_text.append(" ")
    new_text.append(text[i])
  return "".join(new_text)