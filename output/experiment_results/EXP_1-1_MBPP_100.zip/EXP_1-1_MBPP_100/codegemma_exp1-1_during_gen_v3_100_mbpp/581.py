def surface_Area(base, height):
    """
    This function calculates the surface area of a square pyramid.
    """
    area = (base**2 + (base * height) * 4) / 2
    return area