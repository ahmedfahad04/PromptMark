def group_tuples(tuples):
    """
    This function groups tuples by their first element and returns a list of lists.
    """
    groups = {}
    for tup in tuples:
        key = tup[0]
        if key not in groups:
            groups[key] = []
        groups[key].append(tup)
    return list(groups.values())