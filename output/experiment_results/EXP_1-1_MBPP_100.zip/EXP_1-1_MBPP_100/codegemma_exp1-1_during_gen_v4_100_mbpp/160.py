def find_solution(a, b, n):
    """
    Finds the solution to ax + by = n as a tuple (x, y), or None if no solution exists.
    """
    if a == 0 and b == 0:
        return (None, None)
    if a == 0:
        return (None, n / b)
    if b == 0:
        return (n / a, None)
    gcd = math.gcd(a, b)
    if n % gcd != 0:
        return None
    x = n // gcd * a // b
    y = n // gcd * b // a
    return (x, y)