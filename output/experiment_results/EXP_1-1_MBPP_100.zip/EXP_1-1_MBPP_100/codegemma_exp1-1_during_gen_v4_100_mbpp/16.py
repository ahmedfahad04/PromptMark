def text_lowercase_underscore(text):
  """
  Checks if the input string contains sequences of lowercase letters joined with an underscore.
  """
  if not text or not text.lower() == text:
    return False
  for i in range(len(text)):
    if text[i] == '_':
      if i == 0 or i == len(text) - 1 or not text[i - 1].islower() or not text[i + 1].islower():
        return False
  return True