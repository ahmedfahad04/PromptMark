def list_to_float(list_of_lists):
    """
    Converts all possible convertible elements in a list of lists to floats.

    Args:
    list_of_lists: A list of lists containing elements that can be converted to floats.

    Returns:
    A list of lists with all convertible elements converted to floats.
    """

    for i, sublist in enumerate(list_of_lists):
        for j, element in enumerate(sublist):
            if isinstance(element, (int, float)):
                list_of_lists[i][j] = float(element)

    return list_of_lists