def empty_dit(list_of_dicts):
  """
  This function checks whether all dictionaries in a list are empty or not.
  """
  for dictionary in list_of_dicts:
    if dictionary:
      return False
  return True