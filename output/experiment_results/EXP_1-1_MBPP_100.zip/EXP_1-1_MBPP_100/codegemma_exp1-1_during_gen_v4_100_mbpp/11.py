def remove_Occ(str, char):
    """
    This function removes the first and last occurrence of a given character from the string.
    """
    # Check if the character is present in the string
    if char not in str:
        return str
    
    # Remove the first occurrence of the character
    str = str.replace(char, "", 1)
    
    # Remove the last occurrence of the character
    str = str.replace(char, "", 1)
    
    return str