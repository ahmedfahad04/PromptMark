def remove_whitespaces(input_str):
    # Replace all whitespace characters with no character
    return ''.join([char for char in input_str if char != ' '])

# Test cases
print(remove_whitespaces(' Google    Flutter '))
print(remove_whitespaces(' Google    Dart '))
print(remove_whitespaces(' iOS    Swift '))