def find(numerator, denominator):
    # Calculate the quotient using floor division
    return numerator // denominator

# Test cases
print(find(10, 3))  # Output: 3
print(find(4, 2))   # Output: 2
print(find(20, 5))  # Output: 4