def union_elements(tup1, tup2):
    # Convert tuples to sets to find unique elements and then take their union
    set_union = set(tup1).union(set(tup2))
    # Convert the resulting set back to a tuple and sort it
    sorted_tuple = tuple(sorted(set_union))
    return sorted_tuple