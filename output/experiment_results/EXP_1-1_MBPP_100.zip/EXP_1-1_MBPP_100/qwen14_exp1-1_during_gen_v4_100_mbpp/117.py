def list_to_float(lst):
    # Convert each element in the sublists to float if possible, otherwise keep it as is
    converted_list = [tuple(float(item) if item.replace('.', '', 1).isdigit() else item for item in sublist) for sublist in lst]
    return converted_list