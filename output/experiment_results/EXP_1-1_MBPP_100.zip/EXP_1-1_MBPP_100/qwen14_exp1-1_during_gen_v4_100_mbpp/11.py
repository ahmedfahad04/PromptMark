def remove_Occ(input_str, char):
    # Find the first occurrence of the character
    first_occurrence = input_str.find(char)
    
    # If the character is not found, return the original string
    if first_occurrence == -1:
        return input_str
    
    # Remove the first occurrence
    after_first_removal = input_str[:first_occurrence] + input_str[first_occurrence + 1:]
    
    # Find the new last occurrence after removing the first one
    last_occurrence = after_first_removal.rfind(char)
    
    # Remove the last occurrence
    result = after_first_removal[:last_occurrence] + after_first_removal[last_occurrence + 1:]
    
    return result