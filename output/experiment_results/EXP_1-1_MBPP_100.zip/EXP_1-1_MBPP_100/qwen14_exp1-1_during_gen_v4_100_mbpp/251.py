def insert_element(items, element):
    # Initialize an empty list to store the result
    result = []
    # Iterate through each item in the input list
    for item in items:
        # Insert the element before the current item
        result.append(element)
        result.append(item)
    return result