import math

def otherside_rightangle(side_a, side_b):
    # Calculate the square of the hypotenuse using Pythagorean theorem
    hypotenuse_squared = side_a**2 + side_b**2
    # Return the square root of the hypotenuse squared to get the actual length
    return math.sqrt(hypotenuse_squared)

# Test cases
print(otherside_rightangle(7, 8))  # Expected output: 10.63014581273465
print(otherside_rightangle(3, 4))  # Expected output: 5
print(otherside_rightangle(7, 15)) # Expected output: 16.55294535724685