def remove_nested(tup):
    # Initialize an empty tuple to store non-nested elements
    clean_tup = ()
    
    # Iterate through each element in the input tuple
    for item in tup:
        # Check if the current item is not a tuple
        if not isinstance(item, tuple):
            # If not a tuple, add it to the clean_tup
            clean_tup += (item,)
    
    return clean_tup