def average_tuple(tup):
    # Initialize an empty list to store the averages
    averages = []
    # Iterate through each tuple in the main tuple
    for t in tup:
        # Calculate the average by summing the tuple elements and dividing by its length
        avg = sum(t) / len(t)
        # Append the calculated average to the averages list
        averages.append(avg)
    # Return the list of averages
    return averages