def count_bidirectional(items):
    # Create a dictionary to store the counts of each tuple
    count_map = {}
    
    # Iterate through the list to populate the count_map
    for x, y in items:
        if (x, y) in count_map:
            count_map[(x, y)] += 1
        else:
            count_map[(x, y)] = 1
    
    # Initialize the count of bidirectional pairs
    pair_count = 0
    
    # Check for corresponding reverse tuples and increment the count
    for x, y in count_map:
        if (y, x) in count_map:
            pair_count += min(count_map[(x, y)], count_map[(y, x)])
    
    return pair_count