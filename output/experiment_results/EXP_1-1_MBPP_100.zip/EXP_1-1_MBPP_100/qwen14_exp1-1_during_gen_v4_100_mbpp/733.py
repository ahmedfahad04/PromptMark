def find_first_occurrence(arr, target):
    # Initialize left and right pointers
    left = 0
    right = len(arr) - 1
    
    # Find the first occurrence of the target
    while left <= right:
        mid = left + (right - left) // 2
        if arr[mid] < target:
            left = mid + 1
        elif arr[mid] > target:
            right = mid - 1
        else:
            # If mid is the first element or the element before mid is not target
            if mid == 0 or arr[mid - 1] != target:
                return mid
            else:
                right = mid - 1
    return -1

# Test cases
print(find_first_occurrence([2, 5, 5, 5, 6, 6, 8, 9, 9, 9], 5))
print(find_first_occurrence([2, 3, 5, 5, 6, 6, 8, 9, 9, 9], 5))
print(find_first_occurrence([2, 4, 1, 5, 6, 6, 8, 9, 9, 9], 6))