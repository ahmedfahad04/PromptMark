def count_rotation(arr):
    # Find the index where if we split the array, both parts would be sorted individually
    # and also when combined, they would form a sorted array.
    n = len(arr)
    for i in range(1, n):
        if arr[i] < arr[i - 1]:
            return i
    return 0

# Test cases
print(count_rotation([3, 2, 1]))  # Output: 1
print(count_rotation([4, 5, 1, 2, 3]))  # Output: 2
print(count_rotation([7, 8, 9, 1, 2, 3]))  # Output: 3
print(count_rotation([1, 2, 3]))  # Output: 0
print(count_rotation([1, 3, 2]))  # Output: 2