def count_vowels(word):
    # Initialize count variable to keep track of characters with vowel neighbors
    count = 0
    # Define vowels
    vowels = 'aeiou'
    # Iterate through the string, excluding the first and last character since they cannot have two neighbors
    for i in range(1, len(word) - 1):
        # Check if the current character has a vowel as either of its neighbors
        if word[i - 1] in vowels or word[i + 1] in vowels:
            # Increment count if condition is met
            count += 1
    # Check edge cases for the first and last character separately
    if len(word) > 1:
        if word[0] in vowels:
            count += 1
        if word[-1] in vowels:
            count += 1
    return count