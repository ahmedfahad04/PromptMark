def text_lowercase_underscore(input_str):
    # Check if the input string matches the pattern of lowercase letters joined by underscores
    import re
    pattern = r'^[a-z]+(_[a-z]+)*$'
    if re.search(pattern, input_str):
        return True
    else:
        return False

# Test cases
assert text_lowercase_underscore("aab_cbbbc") == True
assert text_lowercase_underscore("aab_Abbbc") == False
assert text_lowercase_underscore("Aaab_abbbc") == False