def unique_product(nums):
    # Create a set to store unique elements
    unique_nums = set(nums)
    
    # Calculate the product of unique elements
    product = 1
    for num in unique_nums:
        product *= num
    
    return product