def empty_dit(lst):
    # Check if all dictionaries in the list are empty
    for dic in lst:
        if not isinstance(dic, dict) or dic:
            return False
    return True

# Test cases
print(empty_dit([{},{},{}]))  # Expected output: True
print(empty_dit([{1,2},{},{}]))  # Expected output: False
print(empty_dit({}))  # Expected output: True