def sum_range_list(numbers, start_index, end_index):
    # Initialize sum variable to accumulate the sum of elements
    total = 0
    # Iterate through the list using the provided indices
    for i in range(start_index, end_index + 1):
        # Add the current element to the total sum
        total += numbers[i]
    # Return the calculated sum
    return total