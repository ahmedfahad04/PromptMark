def capital_words_spaces(s):
    import re
    return re.sub(r'([A-Z])', r' \1', s).strip()

# The function uses regular expressions to find capital letters and insert spaces before them.
# The strip() method removes any leading/trailing spaces that might be introduced by the regex substitution.