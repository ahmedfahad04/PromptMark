def check_monthnumb_number(month):
    # Months with 31 days are January, March, May, July, August, October, December
    if month in {1, 3, 5, 7, 8, 10, 12}:
        return True
    else:
        return False

# Test cases
print(check_monthnumb_number(5))  # Expected: True
print(check_monthnumb_number(2))  # Expected: False
print(check_monthnumb_number(6))  # Expected: False