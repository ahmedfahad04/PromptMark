def count_divisors(n):
    # Initialize a set to store unique divisors
    divisors = set()
    
    # Iterate through possible divisors
    for i in range(1, int(n**0.5) + 1):
        if n % i == 0:
            # If divisor found, add both divisors to the set
            divisors.add(i)
            divisors.add(n // i)
    
    # Check if the number of divisors is even
    return len(divisors) % 2 == 0

# Test cases
assert count_divisors(10)  # True
assert not count_divisors(100)  # False
assert count_divisors(125)  # True