def check_value(input_dict, target_value):
    # Iterate through each value in the dictionary
    for value in input_dict.values():
        # If any value does not match the target value, return False
        if value != target_value:
            return False
    # If all values matched, return True
    return True