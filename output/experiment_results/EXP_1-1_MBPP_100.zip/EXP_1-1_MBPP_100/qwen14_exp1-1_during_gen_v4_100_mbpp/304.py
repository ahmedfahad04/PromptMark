def find_Element(arr, queries, n, index):
    # Initialize the original position of the element at given index
    original_pos = index
    
    # Process each query to rotate the array
    for query in queries:
        direction, k = query
        if direction == 0:
            # Left rotation
            original_pos -= k
        else:
            # Right rotation
            original_pos += k
    
    # Adjust the position considering the array size
    adjusted_pos = (original_pos % n + n) % n
    
    # Return the element at the adjusted position
    return arr[adjusted_pos]

# Test cases
print(find_Element([1,2,3,4,5], [[0,2],[0,3]], 5, 1))
print(find_Element([1,2,3,4], [[0,1],[0,2]], 4, 2))
print(find_Element([1,2,3,4,5,6], [[0,1],[0,2]], 6, 1))