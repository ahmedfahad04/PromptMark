def is_perfect_square(num):
    # Calculate the square root of num and round it to the nearest integer
    sqrt_num = round(num ** 0.5)
    
    # Check if the square of the rounded square root equals the original number
    return sqrt_num * sqrt_num == num

# Test cases
print(is_perfect_square(10))      # False
print(is_perfect_square(36))      # True
print(is_perfect_square(14))      # False
print(is_perfect_square(14*14))   # True
print(is_perfect_square(125))     # False
print(is_perfect_square(125*125)) # True