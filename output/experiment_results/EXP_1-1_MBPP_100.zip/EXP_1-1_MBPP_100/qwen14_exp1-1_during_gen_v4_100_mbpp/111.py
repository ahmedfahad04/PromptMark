def common_in_nested_lists(nested_lists):
    # Convert each sublist into a set to remove duplicates and allow set operations
    sets = [set(lst) for lst in nested_lists]
    
    # Initialize the common elements with the first set
    common_elements = sets[0] if sets else set()
    
    # Intersect with each subsequent set to find common elements
    for s in sets[1:]:
        common_elements &= s
    
    return list(common_elements)