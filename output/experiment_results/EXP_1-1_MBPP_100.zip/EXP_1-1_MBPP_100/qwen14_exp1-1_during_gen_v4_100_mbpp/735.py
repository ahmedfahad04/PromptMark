def toggle_middle_bits(n):
    # Calculate the mask to exclude the first and last bit
    mask = (1 << (n.bit_length() - 2)) - 1
    # Shift the mask two positions to the left to align with the middle bits
    mask <<= 2
    # XOR the number with the mask to toggle the middle bits
    return n ^ mask

# Test cases
print(toggle_middle_bits(9))  # Output: 15
print(toggle_middle_bits(10))  # Output: 12
print(toggle_middle_bits(11))  # Output: 13
print(toggle_middle_bits(0b1000001))  # Output: 0b1111111
print(toggle_middle_bits(0b1001101))  # Output: 0b1110011