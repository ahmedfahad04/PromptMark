def tuple_intersection(tup_list1, tup_list2):
    # Convert each tuple list into sets of frozensets to ignore order within tuples
    set1 = {frozenset(item) for item in tup_list1}
    set2 = {frozenset(item) for item in tup_list2}
    
    # Find common elements between the two sets
    common_sets = set1.intersection(set2)
    
    # Convert frozensets back to regular tuples
    return {tuple(item) for item in common_sets}

# Test cases
print(tuple_intersection([(3, 4), (5, 6), (9, 10), (4, 5)], [(5, 4), (3, 4), (6, 5), (9, 11)]))
print(tuple_intersection([(4, 1), (7, 4), (11, 13), (17, 14)], [(1, 4), (7, 4), (16, 12), (10, 13)]))
print(tuple_intersection([(2, 1), (3, 2), (1, 3), (1, 4)], [(11, 2), (2, 3), (6, 2), (1, 3)]))