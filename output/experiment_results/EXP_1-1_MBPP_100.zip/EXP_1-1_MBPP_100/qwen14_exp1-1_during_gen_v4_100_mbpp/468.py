def max_product(nums):
    n = len(nums)
    # Initialize the dp array with 1s
    dp = [1] * n
    
    # Iterate through the array to fill the dp array
    for i in range(n):
        for j in range(i):
            if nums[i] > nums[j]:
                dp[i] = max(dp[i], dp[j] * nums[i])
    
    # Return the maximum value found in the dp array
    return max(dp)

# Test cases
assert max_product([3, 100, 4, 5, 150, 6]) == 3000
assert max_product([4, 42, 55, 68, 80]) == 50265600
assert max_product([10, 22, 9, 33, 21, 50, 41, 60]) == 2460