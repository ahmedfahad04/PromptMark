def extract_string(strings, size):
    # Filter out strings that match the specified size
    return [word for word in strings if len(word) == size]

# Test cases
print(extract_string(['Python', 'list', 'exercises', 'practice', 'solution'], 8))
print(extract_string(['Python', 'list', 'exercises', 'practice', 'solution'], 6))
print(extract_string(['Python', 'list', 'exercises', 'practice', 'solution'], 9))