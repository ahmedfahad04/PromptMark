def power(a, b):
    # Initialize the base value
    value = 1
    
    # Loop through to multiply 'a' by itself 'b' times
    while b > 0:
        if b % 2 == 1:  # If b is odd
            value *= a
        a *= a  # Square the base
        b //= 2  # Halve the exponent
    
    return value

# Test cases
assert power(3, 4) == 81
assert power(2, 3) == 8
assert power(5, 5) == 3125