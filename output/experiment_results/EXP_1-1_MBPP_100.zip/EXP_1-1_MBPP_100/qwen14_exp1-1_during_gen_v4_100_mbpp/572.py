def two_unique_nums(nums):
    # Use a set to track seen numbers
    seen = set()
    # Initialize an empty list for unique numbers
    unique_nums = []
    
    # Iterate through each number in the input list
    for num in nums:
        # If the number is not in the seen set, it's unique
        if num not in seen:
            # Add the number to the unique list
            unique_nums.append(num)
            # Also add the number to the seen set
            seen.add(num)
    
    return unique_nums