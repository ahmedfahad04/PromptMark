def rectangle_area(length, width):
    # Calculate the area by multiplying length and width
    area = length * width
    return area