def find_Average_Of_Cube(n):
    # Calculate the sum of cubes of first n natural numbers
    cube_sum = sum(i**3 for i in range(1, n + 1))
    # Return the average by dividing the sum by n
    return cube_sum / n

# Test cases
print(find_Average_Of_Cube(2))  # Output: 4.5
print(find_Average_Of_Cube(3))  # Output: 12.0
print(find_Average_Of_Cube(1))  # Output: 1.0