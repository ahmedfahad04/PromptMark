def and_tuples(tup1, tup2):
    # Use map to apply the bitwise AND operation on each pair of elements from the tuples
    result = tuple(map(lambda x, y: x & y, tup1, tup2))
    return result