def parabola_directrix(a, b, c):
    # Calculate the directrix using the formula derived from the standard form of a parabola
    directrix = -((b ** 2) - (1 + 4 * a * c)) / (4 * a)
    return directrix

# Test cases
print(parabola_directrix(5, 3, 2))
print(parabola_directrix(9, 8, 4))
print(parabola_directrix(2, 4, 6))