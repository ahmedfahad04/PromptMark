def even_Power_Sum(n):
    total = 0
    for i in range(n):
        even_num = (i + 1) * 2
        total += even_num ** 5
    return total