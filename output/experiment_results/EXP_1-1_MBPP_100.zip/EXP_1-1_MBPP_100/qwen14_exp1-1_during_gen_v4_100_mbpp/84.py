def sequence(n):
    if n == 1 or n == 2:
        return 1
    
    seq = [0] * (n + 1)
    seq[1], seq[2] = 1, 1
    
    for i in range(3, n + 1):
        seq[i] = seq[seq[i - 1]] + seq[i - seq[i - 1]]
    
    return seq[n]

# Test cases
print(sequence(10))  # Expected output: 6
print(sequence(2))   # Expected output: 1
print(sequence(3))   # Expected output: 2