def comb_sort(arr):
    # Initialize gap size to the length of the array
    gap = len(arr)
    # Set shrink factor to 1.3
    shrink_factor = 1.3
    sorted_flag = False
    
    while not sorted_flag:
        # Update gap value for a next comb
        gap = int(gap / shrink_factor)
        
        if gap <= 1:
            sorted_flag = True
        
        index = 0
        # Iterate over elements in the current comb
        while index + gap < len(arr):
            if arr[index] > arr[index + gap]:
                # Swap elements
                arr[index], arr[index + gap] = arr[index + gap], arr[index]
                sorted_flag = False
            index += 1
    
    return arr