def start_withp(words):
    # Split the input string into a list of words
    words_list = words[0].split()
    # Filter words that start with 'p' or 'P'
    p_words = [word for word in words_list if word.lower().startswith('p')]
    # Return the first two words that meet the condition
    return tuple(p_words[:2])