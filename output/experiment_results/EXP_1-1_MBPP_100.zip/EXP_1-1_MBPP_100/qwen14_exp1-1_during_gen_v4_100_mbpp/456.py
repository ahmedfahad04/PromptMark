def reverse_string_list(items):
    # Initialize an empty list to store reversed strings
    reversed_items = []
    # Iterate through each string in the input list
    for item in items:
        # Reverse the current string and append it to the reversed_items list
        reversed_items.append(item[::-1])
    return reversed_items

# Test cases
assert reverse_string_list(['Red', 'Green', 'Blue', 'White', 'Black']) == ['deR', 'neerG', 'eulB', 'etihW', 'kcalB']
assert reverse_string_list(['john','amal','joel','george']) == ['nhoj','lama','leoj','egroeg']
assert reverse_string_list(['jack','john','mary']) == ['kcaj','nhoj','yram']