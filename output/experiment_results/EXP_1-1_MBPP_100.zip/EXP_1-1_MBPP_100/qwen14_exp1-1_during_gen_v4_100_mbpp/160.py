def find_solution(a, b, n):
    # Check if n is non-negative
    if n < 0:
        return None
    
    # Iterate through possible values of x
    for x in range(n // a + 1):
        # Calculate the remaining value needed to reach n
        remainder = n - a * x
        
        # Check if the remainder can be exactly divided by b
        if remainder % b == 0:
            # If yes, calculate y
            y = remainder // b
            return (x, y)
    
    # If no solution is found, return None
    return None

# Test cases
print(find_solution(2, 3, 7))  # Output: (2, 1)
print(find_solution(4, 2, 7))  # Output: None
print(find_solution(1, 13, 17))  # Output: (4, 1)