def drop_empty(input_dict):
    # Create a new dictionary that includes only items where the value is not None
    return {key: value for key, value in input_dict.items() if value is not None}

# Test cases
print(drop_empty({'c1': 'Red', 'c2': 'Green', 'c3': None}))
print(drop_empty({'c1': 'Red', 'c2': None, 'c3': None}))
print(drop_empty({'c1': None, 'c2': 'Green', 'c3': None}))