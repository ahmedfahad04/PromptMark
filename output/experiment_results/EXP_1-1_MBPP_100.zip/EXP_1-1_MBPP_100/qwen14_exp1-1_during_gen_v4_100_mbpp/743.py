def rotate_right(lst, k):
    # Calculate effective rotations needed
    k = k % len(lst)
    # Split the list into two parts and concatenate them in reversed order
    return lst[-k:] + lst[:-k]