import cmath
import math

def polar_rect(radius, angle):
    # Convert angle from degrees to radians
    angle_rad = math.radians(angle)
    
    # Calculate rectangular coordinates
    x = radius * math.cos(angle_rad)
    y = radius * math.sin(angle_rad)
    
    # Return tuple of (x, y) and complex number representation
    return ((x, y), complex(x, y))

# Test cases
print(polar_rect(3, 4))
print(polar_rect(4, 7))
print(polar_rect(15, 17))