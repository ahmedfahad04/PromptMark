def remove_dirty_chars(s1, s2):
    # Convert s2 into a set of characters to improve lookup time
    dirty_chars = set(s2)
    
    # Use a list comprehension to build the result string excluding characters in dirty_chars
    clean_string = ''.join([char for char in s1 if char not in dirty_chars])
    
    return clean_string

# Test cases
print(remove_dirty_chars("probasscurve", "pros"))
print(remove_dirty_chars("digitalindia", "talent"))
print(remove_dirty_chars("exoticmiles", "toxic"))