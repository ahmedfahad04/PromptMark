def odd_num_sum(n):
    total = 0
    for i in range(n):
        # Calculate the ith odd number and raise it to the fourth power
        odd_number = 2 * i + 1
        total += odd_number ** 4
    return total

# Test cases
assert odd_num_sum(2) == 82
assert odd_num_sum(3) == 707
assert odd_num_sum(4) == 3108