def square_nums(input_list):
    # Initialize an empty list to store squared values
    squared_values = []
    
    # Iterate through each element in the input list
    for item in input_list:
        # Calculate the square of the current element and append it to the squared_values list
        squared_values.append(item * item)
    
    # Return the list of squared values
    return squared_values