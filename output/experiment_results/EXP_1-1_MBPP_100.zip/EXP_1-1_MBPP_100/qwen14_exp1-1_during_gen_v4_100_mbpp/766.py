def pair_wise(items):
    # Initialize an empty list to store the pairs
    pairs = []
    # Iterate through the list, stopping one item before the end
    for i in range(len(items) - 1):
        # Append each pair of consecutive items as a tuple
        pairs.append((items[i], items[i + 1]))
    return pairs