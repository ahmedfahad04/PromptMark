def string_to_tuple(input_str):
    # Convert the input string into a tuple of characters
    return tuple(char for char in input_str)

# Test cases
print(string_to_tuple("python 3.0"))
print(string_to_tuple("item1"))
print(string_to_tuple("15.10"))