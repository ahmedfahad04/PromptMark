def find_Max_Num(digits):
    # Convert each digit to string to facilitate sorting
    str_digits = [str(digit) for digit in digits]
    
    # Custom sort to get the largest number combination
    str_digits.sort(reverse=True, key=lambda x: ''.join(sorted([x[i] + x[j] for i in range(len(x)) for j in range(i + 1, len(x))], reverse=True)))
    
    # Join sorted strings back into an integer
    max_num = int(''.join(str_digits))
    
    return max_num