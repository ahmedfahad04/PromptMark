def test_three_equal(x, y, z):
    # Count the occurrences of each number
    count_x = x == y + z
    count_y = y == x + z
    count_z = z == x + y
    
    # Calculate the total count of equal numbers
    if count_x:
        return 2 + count_z
    elif count_y:
        return 2 + count_x
    elif count_z:
        return 2 + count_y
    else:
        return 3 if x == y == z else 0