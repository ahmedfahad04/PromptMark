def find_First_Missing(arr):
    # Initialize the expected first missing number as 0
    expected = 0
    
    # Iterate through the array
    for num in arr:
        # If the current number matches the expected one, increment the expected value
        if num == expected:
            expected += 1
        # If a mismatch is found, break the loop
        else:
            break
    
    # Return the first missing number
    return expected

# Test cases
print(find_First_Missing([0,1,2,3]))  # Output: 4
print(find_First_Missing([0,1,2,6,9]))  # Output: 3
print(find_First_Missing([2,3,5,8,9]))  # Output: 0