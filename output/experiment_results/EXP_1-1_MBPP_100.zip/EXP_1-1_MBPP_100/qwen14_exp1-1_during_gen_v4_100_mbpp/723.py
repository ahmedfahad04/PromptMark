def count_same_pair(list1, list2):
    # Initialize a counter for matching pairs
    match_count = 0
    
    # Iterate through both lists simultaneously
    for i in range(len(list1)):
        # Increment counter if elements at current index are equal
        if list1[i] == list2[i]:
            match_count += 1
            
    return match_count