def swap_List(input_list):
    # Swap the first and last element
    input_list[0], input_list[-1] = input_list[-1], input_list[0]
    return input_list