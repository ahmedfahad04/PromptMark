def group_tuples(tuples):
    # Dictionary to hold lists of second elements grouped by their first elements
    grouped = {}
    
    # Iterate through each tuple in the input list
    for tup in tuples:
        # If the first element of the tuple is not already a key in the dictionary, add it
        if tup[0] not in grouped:
            grouped[tup[0]] = []
        # Append the second element of the tuple to the corresponding list in the dictionary
        grouped[tup[0]].append(tup[1])
    
    # Create a list of tuples from the dictionary values
    result = [(key,) + tuple(value) for key, value in grouped.items()]
    
    return result