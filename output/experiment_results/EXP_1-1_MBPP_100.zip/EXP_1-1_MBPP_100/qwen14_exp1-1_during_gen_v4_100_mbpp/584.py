import re

def find_adverbs(sentence):
    # Regular expression to find words ending with 'ly'
    match = re.search(r'\b\w+ly\b', sentence)
    if match:
        start, end = match.span()
        return f'{start}-{end}:{match.group()}'
    else:
        return None

# Test cases
print(find_adverbs("Clearly, he has no excuse for such behavior."))
print(find_adverbs("Please handle the situation carefuly"))
print(find_adverbs("Complete the task quickly"))