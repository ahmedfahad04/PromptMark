def largest_subset(nums):
    nums.sort()  # Sort the array to make it easier to check divisibility
    n = len(nums)
    dp = [1] * n  # Initialize DP array where dp[i] represents the size of the largest subset ending at i
    
    # Iterate through each number in the sorted list
    for i in range(1, n):
        for j in range(i):
            # Check if nums[i] is divisible by nums[j]
            if nums[i] % nums[j] == 0:
                # Update dp[i] if a larger subset is found
                dp[i] = max(dp[i], dp[j] + 1)
    
    # Return the maximum value in dp which represents the size of the largest subset
    return max(dp)

# Test cases
print(largest_subset([1, 3, 6, 13, 17, 18]))  # Output: 4
print(largest_subset([10, 5, 3, 15, 20]))     # Output: 3
print(largest_subset([18, 1, 3, 6, 13, 17]))  # Output: 4