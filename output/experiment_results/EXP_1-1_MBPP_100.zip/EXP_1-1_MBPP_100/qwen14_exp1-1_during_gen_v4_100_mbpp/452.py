def loss_amount(cost_price, selling_price):
    # Calculate loss if selling price is less than cost price
    if selling_price < cost_price:
        return cost_price - selling_price
    else:
        return 0

# Test cases
print(loss_amount(1500, 1200))  # Expected output: 0
print(loss_amount(100, 200))    # Expected output: 0
print(loss_amount(2000, 5000))  # Expected output: 0
print(loss_amount(100, 50))     # Expected output: 50