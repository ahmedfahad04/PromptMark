def sum_list(input_a, input_b):
    # Initialize an empty list to store the results
    output = []
    # Iterate through both lists simultaneously
    for index in range(len(input_a)):
        # Sum corresponding elements from both lists and append to the output list
        output.append(input_a[index] + input_b[index])
    return output