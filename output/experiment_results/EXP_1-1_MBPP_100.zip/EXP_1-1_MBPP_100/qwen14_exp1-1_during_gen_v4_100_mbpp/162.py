def sum_series(n):
    total = 0
    for i in range(n // 2 + 1):
        total += n - 2 * i
    return total

# Test cases
print(sum_series(6))  # Output: 12
print(sum_series(10)) # Output: 30
print(sum_series(9))  # Output: 25