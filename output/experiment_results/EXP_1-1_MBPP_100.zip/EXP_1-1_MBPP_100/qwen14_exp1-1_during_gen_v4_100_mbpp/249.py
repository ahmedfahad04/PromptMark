def intersection_array(arr1, arr2):
    # Convert both lists to sets to remove duplicates and allow set operations
    set1 = set(arr1)
    set2 = set(arr2)
    
    # Find common elements between the two sets
    common_elements = set1.intersection(set2)
    
    # Convert the set back to a sorted list
    return sorted(list(common_elements))