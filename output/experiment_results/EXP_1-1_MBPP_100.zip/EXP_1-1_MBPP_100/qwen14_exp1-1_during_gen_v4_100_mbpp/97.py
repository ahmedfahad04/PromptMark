def frequency_lists(lst):
    # Flatten the list of lists into a single list
    flat_list = [item for sublist in lst for item in sublist]
    
    # Create a dictionary to store the frequency of each element
    freq_dict = {}
    
    # Iterate through the flattened list and count occurrences
    for item in flat_list:
        if item in freq_dict:
            freq_dict[item] += 1
        else:
            freq_dict[item] = 1
    
    return freq_dict