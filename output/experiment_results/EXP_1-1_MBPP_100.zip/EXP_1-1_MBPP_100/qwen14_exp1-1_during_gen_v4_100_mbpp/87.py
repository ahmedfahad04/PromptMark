def merge_dictionaries_three(dict1, dict2, dict3):
    # Combine all dictionaries into one using the update method iteratively
    merged_dict = {}
    merged_dict.update(dict1)
    merged_dict.update(dict2)
    merged_dict.update(dict3)
    return merged_dict