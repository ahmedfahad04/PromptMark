def sum_even_and_even_index(lst):
    # Initialize sum variable to accumulate the sum of even numbers at even indices
    sum_var = 0
    
    # Iterate through the list with index
    for i, val in enumerate(lst):
        # Check if the index is even and the value at that index is even
        if i % 2 == 0 and val % 2 == 0:
            # Add the value to the sum
            sum_var += val
            
    return sum_var