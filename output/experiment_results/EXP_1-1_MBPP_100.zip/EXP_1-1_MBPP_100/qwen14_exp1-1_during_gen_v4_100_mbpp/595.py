def min_Swaps(bin1, bin2):
    # Convert binary strings to lists of integers
    b1 = [int(i) for i in bin1]
    b2 = [int(i) for i in bin2]
    
    # Count mismatches and check if they are even
    mismatch_count = sum([b1[i] != b2[i] for i in range(len(b1))])
    if mismatch_count % 2 != 0:
        return "Not Possible"
    
    # If both strings are identical, no swap needed
    if mismatch_count == 0:
        return 0
    
    # Calculate swaps needed
    swaps_needed = mismatch_count // 2
    return swaps_needed

# Test cases
print(min_Swaps("1101", "1110"))
print(min_Swaps("111", "000"))
print(min_Swaps("111", "110"))