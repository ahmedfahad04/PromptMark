def count_X(tupl, elem):
    # Initialize a counter to keep track of occurrences
    count = 0
    # Iterate through each item in the tuple
    for item in tupl:
        # If the item matches the element, increment the counter
        if item == elem:
            count += 1
    # Return the final count
    return count