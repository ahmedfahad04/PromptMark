def occurance_substring(input_str, sub):
    # Find the start index of the substring
    index = input_str.find(sub)
    
    # Check if the substring was found
    if index == -1:
        return None
    
    # Calculate the end index of the substring
    end_index = index + len(sub)
    
    # Return the tuple with the found substring and its positions
    return (sub, index, end_index)

# Test cases
print(occurance_substring('python programming, python language','python'))
print(occurance_substring('python programming,programming language','programming'))
print(occurance_substring('python programming,programming language','language'))
print(occurance_substring('c++ programming, c++ language','python'))