def trim_tuple(tup_list, k):
    # Trim each tuple by keeping elements from k to len(tuple) - k
    trimmed = [t[k:len(t) - k] for t in tup_list]
    # Convert the list of tuples to a string representation
    return str(trimmed)