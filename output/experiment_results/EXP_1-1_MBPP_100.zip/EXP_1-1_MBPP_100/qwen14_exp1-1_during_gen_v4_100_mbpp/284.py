def check_element(lst, target):
    # Iterate through each item in the list
    for item in lst:
        # If any item does not match the target, return False
        if item != target:
            return False
    # If all items matched the target, return True
    return True

# Test cases
print(check_element(["green", "orange", "black", "white"], 'blue'))  # Output: False
print(check_element([1, 2, 3, 4], 7))  # Output: False
print(check_element(["green", "green", "green", "green"], 'green'))  # Output: True