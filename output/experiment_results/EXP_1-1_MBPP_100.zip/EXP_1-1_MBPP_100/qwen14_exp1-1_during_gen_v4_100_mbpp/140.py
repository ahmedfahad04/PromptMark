def extract_singly(lst):
    # Initialize an empty set to store unique elements
    singly_set = set()
    
    # Iterate through each tuple in the list
    for tup in lst:
        # Add all elements from the tuple to the set
        for num in tup:
            singly_set.add(num)
    
    return singly_set