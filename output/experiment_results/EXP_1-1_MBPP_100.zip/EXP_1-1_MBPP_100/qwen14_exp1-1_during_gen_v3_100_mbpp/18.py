def remove_dirty_chars(s1, s2):
    # Convert s2 into a set of characters to improve lookup time
    dirty_chars = set(s2)
    
    # Build a new string without characters from s1 that are in dirty_chars
    clean_str = ''.join([char for char in s1 if char not in dirty_chars])
    
    return clean_str