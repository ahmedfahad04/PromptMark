def check_value(input_dict, expected_value):
    # Iterate through each value in the dictionary
    for value in input_dict.values():
        # If any value does not match the expected value, return False
        if value != expected_value:
            return False
    # If all values matched, return True
    return True