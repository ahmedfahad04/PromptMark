def odd_num_sum(n):
    total = 0
    for i in range(n):
        # Calculate the ith odd number and raise it to the fourth power
        odd_number = 2 * i + 1
        total += odd_number ** 4
    return total

# Test cases
print(odd_num_sum(2))  # Output: 82
print(odd_num_sum(3))  # Output: 707
print(odd_num_sum(4))  # Output: 3108