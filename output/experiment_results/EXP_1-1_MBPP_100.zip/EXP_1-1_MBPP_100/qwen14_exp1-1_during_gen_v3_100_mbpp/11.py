def remove_Occ(s, char):
    # Find the first occurrence of the character
    first_occurrence = s.find(char)
    
    # If the character is not found, return the original string
    if first_occurrence == -1:
        return s
    
    # Find the last occurrence of the character
    last_occurrence = s.rfind(char)
    
    # Remove the first occurrence
    s = s[:first_occurrence] + s[first_occurrence + 1:]
    
    # Remove the last occurrence
    s = s[:last_occurrence] + s[last_occurrence + 1:]
    
    return s