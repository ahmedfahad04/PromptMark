def loss_amount(cost_price, selling_price):
    # Check if there's a loss
    if cost_price > selling_price:
        return cost_price - selling_price
    else:
        return 0