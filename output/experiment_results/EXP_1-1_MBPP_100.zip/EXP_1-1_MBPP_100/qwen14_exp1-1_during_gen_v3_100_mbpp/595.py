def min_Swaps(bin1, bin2):
    # Convert binary strings into lists of integers for easier manipulation
    bin1_list = [int(i) for i in bin1]
    bin2_list = [int(i) for i in bin2]

    # Check if lengths of both binary numbers are equal
    if len(bin1_list) != len(bin2_list):
        return "Not Possible"

    # Count mismatches between the two binary lists
    mismatch_count = sum([bin1_list[i] != bin2_list[i] for i in range(len(bin1_list))])

    # If the number of mismatches is odd, conversion is not possible
    if mismatch_count % 2 != 0:
        return "Not Possible"

    # Calculate the number of swaps needed, which is half the number of mismatches
    swap_count = mismatch_count // 2

    return swap_count

# Test cases
print(min_Swaps("1101", "1110"))
print(min_Swaps("111", "000"))
print(min_Swaps("111", "110"))