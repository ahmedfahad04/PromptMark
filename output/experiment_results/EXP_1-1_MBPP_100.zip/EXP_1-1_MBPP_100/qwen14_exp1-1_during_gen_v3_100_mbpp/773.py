def occurance_substring(main_str, sub_str):
    # Find the start index of the substring in the main string
    index = main_str.find(sub_str)
    
    # Check if the substring was found
    if index != -1:
        # Calculate the length of the substring
        length = len(sub_str)
        return (sub_str, index, index + length - 1)
    else:
        return None

# Test cases
assert occurance_substring('python programming, python language','python') == ('python', 0, 6)
assert occurance_substring('python programming,programming language','programming') == ('programming', 7, 18)
assert occurance_substring('python programming,programming language','language') == ('language', 31, 39)
assert occurance_substring('c++ programming, c++ language','python') == None