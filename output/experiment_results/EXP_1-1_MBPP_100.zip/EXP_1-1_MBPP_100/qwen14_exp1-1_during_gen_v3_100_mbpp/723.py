def count_same_pair(lst1, lst2):
    # Initialize a counter for matching pairs
    match_count = 0
    
    # Iterate through both lists simultaneously
    for i in range(len(lst1)):
        # Increment counter if elements at the current index are equal
        if lst1[i] == lst2[i]:
            match_count += 1
            
    return match_count