import math

def multiply_num(numbers):
    # Calculate the product of all numbers in the list
    product = math.prod(numbers)
    # Divide the product by the length of the list
    division_result = product / len(numbers)
    return division_result