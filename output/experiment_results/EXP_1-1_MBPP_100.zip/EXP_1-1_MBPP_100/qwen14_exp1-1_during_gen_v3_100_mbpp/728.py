def sum_list(input_a, input_b):
    # Ensure both lists have the same length
    if len(input_a) != len(input_b):
        raise ValueError("Both lists must be of the same length")
    
    # Sum corresponding elements from both lists
    output = [x + y for x, y in zip(input_a, input_b)]
    return output