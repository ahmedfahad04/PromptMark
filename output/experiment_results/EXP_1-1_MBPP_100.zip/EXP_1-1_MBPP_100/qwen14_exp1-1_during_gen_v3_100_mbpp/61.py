def count_Substrings(s):
    count = 0
    n = len(s)
    
    # Iterate over all possible starting points of substrings
    for i in range(n):
        num_sum = 0
        # Iterate over all possible ending points of substrings starting at i
        for j in range(i, n):
            num_sum += int(s[j])
            # Check if the sum of digits equals the length of the substring
            if num_sum == j - i + 1:
                count += 1
                
    return count