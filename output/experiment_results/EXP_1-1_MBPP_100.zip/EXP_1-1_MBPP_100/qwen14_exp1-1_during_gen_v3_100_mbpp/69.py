def is_sublist(main_list, sub_list):
    # Check if the sublist is empty, which is always a sublist
    if not sub_list:
        return True
    
    # Iterate through main_list with an index
    for i in range(len(main_list) - len(sub_list) + 1):
        # Check if the slice of main_list matches sub_list
        if main_list[i:i+len(sub_list)] == sub_list:
            return True
    return False

# Test cases
print(is_sublist([2,4,3,5,7], [3,7]))  # Output: False
print(is_sublist([2,4,3,5,7], [4,3]))  # Output: True
print(is_sublist([2,4,3,5,7], [1,6]))  # Output: False