def test_three_equal(x, y, z):
    # Count the occurrences of each number
    count_x = x == y + z
    count_y = y == x + z
    count_z = z == x + y
    
    # Calculate the total count of equal numbers
    if count_x:
        return 2 + count_z
    elif count_y:
        return 2 + count_x
    elif count_z:
        return 2 + count_y
    else:
        return 3 if x == y == z else 0

# The above solution is incorrect and needs to be revised.
# A simpler approach would be to directly compare the values.

def test_three_equal(x, y, z):
    # Directly compare the values
    if x == y == z:
        return 3
    elif x == y or y == z or x == z:
        return 2
    else:
        return 0

# Test cases
print(test_three_equal(1, 1, 1))  # Expected output: 3
print(test_three_equal(-1, -2, -3))  # Expected output: 0
print(test_three_equal(1, 2, 2))  # Expected output: 2