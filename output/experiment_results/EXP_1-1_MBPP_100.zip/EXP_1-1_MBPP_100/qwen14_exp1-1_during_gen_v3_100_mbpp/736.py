def left_insertion(arr, x):
    low = 0
    high = len(arr)
    
    while low < high:
        mid = (low + high) // 2
        if arr[mid] < x:
            low = mid + 1
        else:
            high = mid
    return low

# Test cases
assert left_insertion([1, 2, 4, 5], 6) == 4
assert left_insertion([1, 2, 4, 5], 3) == 2
assert left_insertion([1, 2, 4, 5], 7) == 4