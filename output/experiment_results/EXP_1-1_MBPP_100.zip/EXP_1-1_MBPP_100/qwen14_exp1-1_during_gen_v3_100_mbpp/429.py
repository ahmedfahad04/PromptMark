def and_tuples(tup1, tup2):
    # Use map to apply the bitwise AND operation on each pair of elements from the two tuples
    return tuple(map(lambda x, y: x & y, tup1, tup2))

# This function takes two tuples as input and returns a new tuple where each element is the result of
# applying the bitwise AND operation to the corresponding elements of the input tuples.