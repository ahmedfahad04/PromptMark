def find_adverbs(sentence):
    # Import regular expression module
    import re
    
    # Define pattern to match adverbs ending with 'ly'
    pattern = r'\w+ly'
    
    # Search for the first occurrence of an adverb in the sentence
    match = re.search(pattern, sentence)
    
    # If an adverb is found, return it along with its start and end positions
    if match:
        start, end = match.start(), match.end()
        return f'{start}-{end - 1}: {match.group()}'
    else:
        return 'No adverb found'

# Test cases
print(find_adverbs("Clearly, he has no excuse for such behavior."))
print(find_adverbs("Please handle the situation carefuly"))
print(find_adverbs("Complete the task quickly"))