def find_first_occurrence(arr, target):
    # Initialize left and right pointers
    left = 0
    right = len(arr) - 1
    
    # Set the result to -1 indicating no occurrence found initially
    result = -1
    
    # Perform binary search
    while left <= right:
        mid = (left + right) // 2
        
        if arr[mid] == target:
            result = mid  # Update result to current mid
            right = mid - 1  # Continue searching in the left subarray
        elif arr[mid] < target:
            left = mid + 1  # Search in the right subarray
        else:
            right = mid - 1  # Search in the left subarray
    
    return result

# Test cases
assert find_first_occurrence([2, 5, 5, 5, 6, 6, 8, 9, 9, 9], 5) == 1
assert find_first_occurrence([2, 3, 5, 5, 6, 6, 8, 9, 9, 9], 5) == 2
assert find_first_occurrence([2, 4, 1, 5, 6, 6, 8, 9, 9, 9], 6) == 4