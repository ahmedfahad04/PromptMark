def comb_sort(arr):
    # Calculate the shrink factor
    shrink_factor = 1.3
    n = len(arr)
    
    # Initialize gap size
    gap = n
    
    # Flag to check if another pass is needed
    swapped = True
    
    while gap > 1 or swapped:
        # Update the gap value for a next comb
        gap = max(1, int(gap / shrink_factor))
        
        # Initialize swapped as false so that we can check if swap happened
        swapped = False
        
        # Compare all elements with current gap
        for i in range(n - gap):
            if arr[i] > arr[i + gap]:
                # Swap elements
                arr[i], arr[i + gap] = arr[i + gap], arr[i]
                swapped = True
                
    return arr