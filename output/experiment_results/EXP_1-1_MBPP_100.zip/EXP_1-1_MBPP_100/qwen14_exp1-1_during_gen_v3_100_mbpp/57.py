def find_Max_Num(nums):
    # Convert all integers in the list to strings to facilitate sorting
    nums = [str(num) for num in nums]
    
    # Sort the list with a custom comparator that compares numbers based on their concatenated values
    nums.sort(key=lambda x: x*len(str(min(nums))), reverse=True)
    
    # Join the sorted list into a single string and convert it back to an integer
    return int("".join(nums))

# Test cases
print(find_Max_Num([1,2,3]))  # Output: 321
print(find_Max_Num([4,5,6,1]))  # Output: 6541
print(find_Max_Num([1,2,3,9]))  # Output: 9321