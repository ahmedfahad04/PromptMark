def max_product(nums):
    n = len(nums)
    if n < 2:
        return 0
    
    # Initialize a list to store the maximum product up to each index
    max_product_up_to = [nums[0]]
    
    # Fill the max_product_up_to list
    for i in range(1, n):
        if nums[i] > nums[i - 1]:
            max_product_up_to.append(max_product_up_to[-1] * nums[i])
        else:
            max_product_up_to.append(nums[i])
    
    # Return the maximum value found in max_product_up_to
    return max(max_product_up_to)

# Test cases
print(max_product([3, 100, 4, 5, 150, 6]))  # Output: 3000
print(max_product([4, 42, 55, 68, 80]))     # Output: 50265600
print(max_product([10, 22, 9, 33, 21, 50, 41, 60]))  # Output: 2460