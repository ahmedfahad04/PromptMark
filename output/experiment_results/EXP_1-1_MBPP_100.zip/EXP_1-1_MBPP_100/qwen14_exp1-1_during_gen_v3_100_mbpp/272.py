def rear_extract(tuples_list):
    # Extract the last element from each tuple in the list
    return [item[-1] for item in tuples_list]