def power(base, exponent):
    # Initialize the result variable to 1
    result = 1
    
    # Loop until the exponent becomes 0
    while exponent != 0:
        # Multiply the result by the base
        result *= base
        
        # Decrease the exponent by 1
        exponent -= 1
    
    return result

# Test cases
assert power(3, 4) == 81
assert power(2, 3) == 8
assert power(5, 5) == 3125