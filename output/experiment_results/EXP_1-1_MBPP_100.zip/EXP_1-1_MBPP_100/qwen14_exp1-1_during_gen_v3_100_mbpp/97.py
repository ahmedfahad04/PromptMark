def frequency_lists(list_of_lists):
    # Flatten the list of lists into a single list
    flat_list = [item for sublist in list_of_lists for item in sublist]
    
    # Create a dictionary to store the frequency of each element
    freq_dict = {}
    
    # Count the frequency of each element in the flattened list
    for item in flat_list:
        if item in freq_dict:
            freq_dict[item] += 1
        else:
            freq_dict[item] = 1
    
    return freq_dict