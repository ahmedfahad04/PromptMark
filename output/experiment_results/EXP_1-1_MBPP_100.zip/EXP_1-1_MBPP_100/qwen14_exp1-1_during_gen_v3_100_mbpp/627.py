def find_First_Missing(arr):
    # Initialize the expected number to 0
    expected = 0
    
    # Iterate through the array
    for num in arr:
        # If the current number is the expected one, increment the expected value
        if num == expected:
            expected += 1
        # If a gap is found, return the expected value
        elif num > expected:
            return expected
    
    # If no gaps were found within the array, return the next number after the last element
    return expected

# Test cases
print(find_First_Missing([0,1,2,3]))  # Output: 4
print(find_First_Missing([0,1,2,6,9]))  # Output: 3
print(find_First_Missing([2,3,5,8,9]))  # Output: 0