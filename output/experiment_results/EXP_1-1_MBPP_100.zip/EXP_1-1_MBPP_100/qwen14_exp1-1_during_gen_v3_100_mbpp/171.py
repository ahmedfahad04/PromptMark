def perimeter_pentagon(side_length):
    # Calculate the perimeter by multiplying the side length by 5
    return side_length * 5

# Test cases
assert perimeter_pentagon(5) == 25
assert perimeter_pentagon(10) == 50
assert perimeter_pentagon(15) == 75