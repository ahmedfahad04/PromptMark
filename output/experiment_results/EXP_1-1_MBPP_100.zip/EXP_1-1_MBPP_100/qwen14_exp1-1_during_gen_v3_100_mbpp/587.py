def list_tuple(input_list):
    # Convert the input list to a tuple
    return tuple(input_list)