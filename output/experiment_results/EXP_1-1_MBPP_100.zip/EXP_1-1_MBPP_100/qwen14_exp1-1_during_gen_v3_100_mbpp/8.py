def square_nums(input_list):
    # Initialize an empty list to store squared numbers
    squared_values = []
    
    # Iterate through each number in the input list
    for num in input_list:
        # Calculate the square of the current number and append it to the squared_values list
        squared_values.append(num * num)
    
    # Return the list of squared values
    return squared_values