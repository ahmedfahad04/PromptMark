def average_tuple(tup):
    # Initialize an empty list to store the averages
    averages = []
    
    # Iterate through each tuple in the main tuple
    for t in tup:
        # Calculate the average by summing the elements and dividing by the number of elements
        avg = sum(t) / len(t)
        # Append the calculated average to the averages list
        averages.append(avg)
    
    # Return the list of averages
    return averages