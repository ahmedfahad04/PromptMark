def trim_tuple(tup_list, k):
    # Trim each tuple by keeping elements from k to the end of each tuple
    trimmed = [t[k:] for t in tup_list]
    # Convert the list of tuples into a string representation
    return str(trimmed)