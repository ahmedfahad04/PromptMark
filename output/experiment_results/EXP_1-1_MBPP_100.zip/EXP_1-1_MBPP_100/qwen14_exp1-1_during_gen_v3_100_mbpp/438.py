def count_bidirectional(items):
    seen = set()
    count_var = 0
    for x, y in items:
        if (y, x) in seen:
            count_var += 1
            seen.remove((y, x))
        else:
            seen.add((x, y))
    return count_var