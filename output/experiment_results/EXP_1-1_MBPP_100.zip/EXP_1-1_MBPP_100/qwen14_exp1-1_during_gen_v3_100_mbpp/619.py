def move_num(s):
    # Separate characters into letters and numbers
    letters = [char for char in s if not char.isdigit()]
    numbers = [char for char in s if char.isdigit()]
    
    # Join letters and numbers back together
    return ''.join(letters) + ''.join(numbers)

# Test cases
assert move_num('I1love143you55three3000thousand') == 'Iloveyouthreethousand1143553000'
assert move_num('Avengers124Assemble') == 'AvengersAssemble124'
assert move_num('Its11our12path13to14see15things16do17things') == 'Itsourpathtoseethingsdothings11121314151617'