import re

def text_lowercase_underscore(input_str):
    # Check if the string contains one or more sequences of lowercase letters joined by an underscore
    if re.search(r'^[a-z]+(_[a-z]+)*$', input_str):
        return True
    else:
        return False