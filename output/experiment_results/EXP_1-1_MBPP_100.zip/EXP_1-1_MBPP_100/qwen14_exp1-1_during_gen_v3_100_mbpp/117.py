def list_to_float(lst):
    # Iterate through each sublist in the main list
    for index, sublst in enumerate(lst):
        # Convert each element in the sublist to float if possible
        lst[index] = tuple(float(item) for item in sublst)
    return lst