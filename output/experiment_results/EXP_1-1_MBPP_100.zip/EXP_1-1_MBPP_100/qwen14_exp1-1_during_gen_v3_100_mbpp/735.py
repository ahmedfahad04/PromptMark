def toggle_middle_bits(n):
    # Calculate the mask to exclude the first and last bit
    mask = (1 << (n.bit_length() - 2)) - 1
    # Shift the mask two positions to the left to align with the middle bits
    mask <<= 2
    # XOR the number with the mask to toggle the middle bits
    return n ^ mask