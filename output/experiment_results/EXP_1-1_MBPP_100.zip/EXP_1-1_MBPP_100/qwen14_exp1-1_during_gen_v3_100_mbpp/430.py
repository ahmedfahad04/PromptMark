def parabola_directrix(a, b, c):
    # Calculate the directrix using the formula derived from the standard form of a parabola
    directrix = -(c + (b * b - 1) / (4 * a))
    return directrix

# Test cases
print(parabola_directrix(5, 3, 2))  # Expected output: -198
print(parabola_directrix(9, 8, 4))  # Expected output: -2336
print(parabola_directrix(2, 4, 6))  # Expected output: -130