def reverse_string_list(words):
    # Initialize an empty list to store reversed strings
    reversed_words = []
    # Iterate through each word in the input list
    for word in words:
        # Reverse the current word and append it to the reversed_words list
        reversed_words.append(word[::-1])
    return reversed_words