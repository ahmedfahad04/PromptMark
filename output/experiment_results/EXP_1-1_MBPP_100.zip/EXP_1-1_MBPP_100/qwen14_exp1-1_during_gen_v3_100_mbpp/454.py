import re

def text_match_wordz(text):
    # Define a pattern to match words containing 'z'
    pattern = '\\bz\\b'
    
    # Search for the pattern in the provided text
    if re.search(pattern, text):
        return True
    else:
        return False