def find_even_pair(lst):
    # Initialize the counter for pairs that xor to an even number
    count = 0
    
    # Iterate through each pair of elements in the list
    for i in range(len(lst)):
        for j in range(i + 1, len(lst)):
            # Check if the xor of the pair is even
            if (lst[i] ^ lst[j]) % 2 == 0:
                count += 1
                
    return count

# Test cases
assert find_even_pair([5, 4, 7, 2, 1]) == 4
assert find_even_pair([7, 2, 8, 1, 0, 5, 11]) == 9
assert find_even_pair([1, 2, 3]) == 1