def group_tuples(lst):
    # Dictionary to hold lists of second elements grouped by their first element
    grouped = {}
    
    # Iterate through each tuple in the list
    for tup in lst:
        # If the first element is not a key in the dictionary, add it
        if tup[0] not in grouped:
            grouped[tup[0]] = []
        
        # Append the second element to the list corresponding to its first element
        grouped[tup[0]].append(tup[1])
    
    # Create the result list by combining the first element with all second elements
    result = [(key,) + tuple(value) for key, value in grouped.items()]
    
    return result