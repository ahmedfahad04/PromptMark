def median_trapezium(base1, base2, height):
    # Calculate the median length using the formula for the median of a trapezium
    median = (base1 + base2) / 2
    return median

# Test cases
print(median_trapezium(15, 25, 35))  # Expected output: 20
print(median_trapezium(10, 20, 30))  # Expected output: 15
print(median_trapezium(6, 9, 4))     # Expected output: 7.5