def remove_lowercase(input_str):
    # Initialize an empty string to store uppercase characters
    upper_str = ""
    
    # Iterate through each character in the input string
    for char in input_str:
        # Check if the character is uppercase
        if char.isupper():
            # Append the uppercase character to the result string
            upper_str += char
    
    # Return the resulting string containing only uppercase characters
    return upper_str