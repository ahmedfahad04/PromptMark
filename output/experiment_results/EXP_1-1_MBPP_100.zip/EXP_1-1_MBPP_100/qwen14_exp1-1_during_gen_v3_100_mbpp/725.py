import re

def extract_quotation(input_str):
    # Find all substrings enclosed in double quotes using regex
    matches = re.findall(r'"(.*?)"', input_str)
    return matches