def list_split(lst, n):
    # Initialize a list to hold the split lists
    split_lists = [[] for _ in range(n)]
    
    # Iterate through the input list and distribute elements into split_lists
    for index, value in enumerate(lst):
        split_lists[index % n].append(value)
    
    return split_lists

# Test cases
print(list_split(['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n'], 3))
print(list_split([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14], 3))
print(list_split(['python', 'java', 'C', 'C++', 'DBMS', 'SQL'], 2))