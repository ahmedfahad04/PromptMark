def sequence(n):
    if n <= 0:
        return None
    elif n == 1 or n == 2:
        return 1
    
    # Initialize a list to store the sequence values
    seq = [0] * (n + 1)
    seq[1], seq[2] = 1, 1
    
    # Fill the sequence list based on Newman-Conway rule
    for i in range(3, n + 1):
        seq[i] = seq[seq[i - 1]] + seq[i - seq[i - 1]]
    
    return seq[n]

# Test cases
print(sequence(10))  # Output: 6
print(sequence(2))   # Output: 1
print(sequence(3))   # Output: 2