def find(num1, num2):
    # Calculate the quotient of num1 divided by num2, rounded down
    return num1 // num2

# Test cases
print(find(10, 3))  # Output: 3
print(find(4, 2))   # Output: 2
print(find(20, 5))  # Output: 4