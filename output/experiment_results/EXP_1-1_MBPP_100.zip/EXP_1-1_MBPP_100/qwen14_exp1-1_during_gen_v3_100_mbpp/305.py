def start_withp(words):
    # Initialize an empty list to store words starting with 'p'
    p_words = []
    
    # Split the input string into individual words
    for word in words.split():
        # Check if the word starts with 'p' or 'P'
        if word[0].lower() == 'p':
            p_words.append(word)
    
    # Return the first two words that start with 'p'
    return tuple(p_words[:2])