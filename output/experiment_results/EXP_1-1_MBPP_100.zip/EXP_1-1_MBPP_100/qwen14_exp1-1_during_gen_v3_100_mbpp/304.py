def find_Element(arr, queries, n, index):
    # Initialize the initial value at the given index
    value = arr[index]
    
    # Process each query
    for query in queries:
        direction, rotations = query
        
        # Calculate effective rotations by taking modulo with array length
        effective_rotations = rotations % len(arr)
        
        # If rotating left, adjust index by adding effective rotations
        if direction == 0:
            new_index = (index + effective_rotations) % len(arr)
        # If rotating right, adjust index by subtracting effective rotations
        else:
            new_index = (index - effective_rotations) % len(arr)
        
        # Update the current index
        index = new_index
    
    # Return the element at the final adjusted index
    return arr[index]

# Test cases
print(find_Element([1,2,3,4,5],[[0,2],[0,3]],2,1))
print(find_Element([1,2,3,4],[[0,1],[0,2]],1,2))
print(find_Element([1,2,3,4,5,6],[[0,1],[0,2]],1,1))