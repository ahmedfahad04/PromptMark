def sum_range_list(numbers, start_index, end_index):
    # Sum elements in the specified range
    return sum(numbers[start_index:end_index + 1])

# Test cases
print(sum_range_list([2,1,5,6,8,3,4,9,10,11,8,12], 8, 10))
print(sum_range_list([2,1,5,6,8,3,4,9,10,11,8,12], 5, 7))
print(sum_range_list([2,1,5,6,8,3,4,9,10,11,8,12], 7, 10))