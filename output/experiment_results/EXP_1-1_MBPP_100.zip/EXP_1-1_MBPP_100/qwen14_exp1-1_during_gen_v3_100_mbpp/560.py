def union_elements(tup1, tup2):
    # Combine both tuples into one set to remove duplicates and get union
    combined_set = set(tup1 + tup2)
    # Convert the set back to a tuple and sort it
    sorted_tuple = tuple(sorted(combined_set))
    return sorted_tuple