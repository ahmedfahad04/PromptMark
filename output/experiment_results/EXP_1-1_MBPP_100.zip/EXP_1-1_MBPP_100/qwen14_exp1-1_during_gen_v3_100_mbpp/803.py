def is_perfect_square(num):
    if num < 0:
        return False
    
    # Calculate the square root of the number
    root = int(num ** 0.5)
    
    # Check if the square of the root equals the original number
    return root * root == num

# Test cases
print(is_perfect_square(10))      # Output: False
print(is_perfect_square(36))      # Output: True
print(is_perfect_square(14))      # Output: False
print(is_perfect_square(14*14))   # Output: True
print(is_perfect_square(125))     # Output: False
print(is_perfect_square(125*125)) # Output: True