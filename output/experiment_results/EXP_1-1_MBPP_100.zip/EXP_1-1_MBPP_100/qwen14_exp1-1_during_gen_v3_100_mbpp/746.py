import math

def sector_area(radius, angle):
    # Check if the angle is greater than 360 degrees
    if angle > 360:
        return None
    else:
        # Calculate the area of the sector
        area = (math.pi * radius ** 2) * (angle / 360)
        return area

# Test cases
print(sector_area(4, 45))  # Expected output: 6.283185307179586
print(sector_area(9, 45))  # Expected output: 31.808625617596654
print(sector_area(9, 361))  # Expected output: None