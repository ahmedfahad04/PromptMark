def tuple_intersection(tup_list1, tup_list2):
    # Convert each tuple list into sets of frozensets to ignore order within tuples
    set1 = {frozenset(item) for item in tup_list1}
    set2 = {frozenset(item) for item in tup_list2}
    
    # Find common frozensets between both sets
    common_sets = set1.intersection(set2)
    
    # Convert frozensets back to regular sets and then to sorted tuples
    result = {tuple(sorted(fset)) for fset in common_sets}
    
    return result