def count_rotation(arr):
    # Find the index where if we split the array, both parts would be sorted individually
    # and also when combined, the last element of the first part is smaller than the first element of the second part
    n = len(arr)
    for i in range(1, n):
        if arr[i] < arr[i - 1]:
            return i
    return 0