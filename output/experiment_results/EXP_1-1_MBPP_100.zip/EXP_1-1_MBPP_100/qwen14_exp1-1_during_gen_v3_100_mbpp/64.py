def subject_marks(marks_list):
    # Sort the list of tuples based on the second element of each tuple
    marks_list.sort(key=lambda x: x[1])
    return marks_list