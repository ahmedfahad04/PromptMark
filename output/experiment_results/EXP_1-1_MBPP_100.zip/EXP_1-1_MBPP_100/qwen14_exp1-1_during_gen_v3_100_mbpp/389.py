def find_lucas(n):
    if n == 0:
        return 2
    elif n == 1:
        return 1
    else:
        a, b = 2, 1
        for _ in range(2, n + 1):
            a, b = b, a + b
        return b

# Test cases
print(find_lucas(9))  # Output: 76
print(find_lucas(4))  # Output: 7
print(find_lucas(3))  # Output: 4