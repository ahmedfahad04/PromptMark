def even_Power_Sum(n):
    total = 0
    for i in range(1, n + 1):
        # Calculate the ith even number
        even_num = 2 * i
        # Raise it to the fifth power and add to the total
        total += even_num ** 5
    return total

# Test cases
assert even_Power_Sum(2) == 1056
assert even_Power_Sum(3) == 8832
assert even_Power_Sum(1) == 32