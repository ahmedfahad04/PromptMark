def string_to_tuple(input_str):
    # Convert the input string into a tuple of characters
    char_tuple = tuple(char for char in input_str)
    return char_tuple