def two_unique_nums(lst):
    seen = set()
    unique = []
    for num in lst:
        if num not in seen:
            seen.add(num)
            unique.append(num)
    return unique