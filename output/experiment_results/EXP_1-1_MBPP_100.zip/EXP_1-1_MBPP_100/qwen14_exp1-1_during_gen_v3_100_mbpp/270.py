def sum_even_and_even_index(arr):
    # Initialize sum variable
    total = 0
    
    # Iterate through the array considering only even indices
    for i in range(0, len(arr), 2):
        # Check if the element at the current even index is even
        if arr[i] % 2 == 0:
            # Add it to the total sum
            total += arr[i]
    
    return total