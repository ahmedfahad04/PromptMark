def rectangle_area(length, width):
    # Calculate the area of a rectangle
    area = length * width
    return area