def largest_subset(nums):
    nums.sort()  # Sort the list to make sure smaller numbers come first
    n = len(nums)
    dp = [1] * n  # Initialize DP array where dp[i] represents the size of the largest subset ending at index i
    
    for i in range(1, n):
        for j in range(i):
            if nums[i] % nums[j] == 0:
                dp[i] = max(dp[i], dp[j] + 1)  # Update dp[i] if a valid subset is found
    
    return max(dp)  # The maximum value in dp[] is the size of the largest subset

# Test cases
print(largest_subset([1, 3, 6, 13, 17, 18]))  # Output: 4
print(largest_subset([10, 5, 3, 15, 20]))     # Output: 3
print(largest_subset([18, 1, 3, 6, 13, 17]))  # Output: 4