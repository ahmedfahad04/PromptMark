def check_element(lst, element):
    # Iterate through each item in the list
    for item in lst:
        # If any item does not match the given element, return False
        if item != element:
            return False
    # If all items matched, return True
    return True

# Test cases
print(check_element(["green", "orange", "black", "white"], 'blue'))  # Output: False
print(check_element([1, 2, 3, 4], 7))  # Output: False
print(check_element(["green", "green", "green", "green"], 'green'))  # Output: True