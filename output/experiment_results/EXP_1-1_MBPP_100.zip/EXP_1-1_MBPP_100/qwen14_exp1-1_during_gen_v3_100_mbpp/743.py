def rotate_right(lst, k):
    # Calculate effective rotations needed
    k = k % len(lst)
    # Rotate the list by slicing and concatenating parts
    return lst[-k:] + lst[:-k]