def extract_string(words, size):
    # Filter words that have exactly the specified size
    filtered_words = [word for word in words if len(word) == size]
    return filtered_words

# Test cases
print(extract_string(['Python', 'list', 'exercises', 'practice', 'solution'], 8))
print(extract_string(['Python', 'list', 'exercises', 'practice', 'solution'], 6))
print(extract_string(['Python', 'list', 'exercises', 'practice', 'solution'], 9))