import cmath
import math

def polar_rect(radius, angle):
    # Convert angle from degrees to radians
    angle_rad = math.radians(angle)
    
    # Calculate rectangular coordinates
    real_part = radius * math.cos(angle_rad)
    imag_part = radius * math.sin(angle_rad)
    
    # Return as tuple of the coordinate pair and complex number
    return ((real_part, angle_rad), complex(real_part, imag_part))