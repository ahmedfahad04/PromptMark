def interleave_lists(list1, list2, list3):
    # Initialize an empty list to store the interleaved elements
    interleaved = []
    
    # Iterate through the indices of the lists
    for i in range(len(list1)):
        # Append elements from each list at the current index to the interleaved list
        interleaved.append(list1[i])
        interleaved.append(list2[i])
        interleaved.append(list3[i])
    
    return interleaved