def capital_words_spaces(s):
    import re
    # Split the string by uppercase letters followed by any characters
    return ' '.join(re.findall('[A-Z][^A-Z]*', s))

# This function uses regular expressions to find sequences starting with an uppercase letter
# followed by zero or more non-uppercase letters, effectively identifying words that start
# with a capital letter and separating them with spaces.