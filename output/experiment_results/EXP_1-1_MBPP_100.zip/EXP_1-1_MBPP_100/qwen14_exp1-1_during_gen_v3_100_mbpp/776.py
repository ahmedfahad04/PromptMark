def count_vowels(word):
    # Convert the word into a list of characters for easier manipulation
    chars = list(word)
    count = 0
    
    # Iterate through the characters, checking both previous and next character for vowels
    for i in range(1, len(chars) - 1):
        if (chars[i-1] in 'aeiou' or chars[i+1] in 'aeiou'):
            count += 1
            
    # Check the first character separately
    if len(chars) > 1 and chars[1] in 'aeiou':
        count += 1
        
    # Check the last character separately
    if len(chars) > 1 and chars[-2] in 'aeiou':
        count += 1
        
    return count