def Find_Min(lst):
    # Initialize min_length to a large number and min_sublist as None
    min_length = float('inf')
    min_sublist = None
    
    # Iterate through each sublist in the given list
    for sublst in lst:
        # Check if the current sublist's length is less than the current minimum length
        if len(sublst) < min_length:
            min_length = len(sublst)
            min_sublist = sublst
            
    return min_sublist

# Test cases
print(Find_Min([[1],[1,2],[1,2,3]]))  # Output: [1]
print(Find_Min([[1,1],[1,1,1],[1,2,7,8]]))  # Output: [1,1]
print(Find_Min([['x'],['x','y'],['x','y','z']]))  # Output: ['x']