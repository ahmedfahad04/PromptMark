def remove_whitespaces(input_str):
    # Replace all whitespace characters with no character
    return ''.join([char for char in input_str if char != ' '])

# Example usage:
# result = remove_whitespaces(' Google    Flutter ')