def drop_empty(input_dict):
    # Create a new dictionary that includes only items where the value is not None
    return {key: value for key, value in input_dict.items() if value is not None}