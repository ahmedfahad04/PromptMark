def merge(items):
    first_elements = []
    second_elements = []
    for pair in items:
        first_elements.append(pair[0])
        second_elements.append(pair[1])
    return [first_elements, second_elements]