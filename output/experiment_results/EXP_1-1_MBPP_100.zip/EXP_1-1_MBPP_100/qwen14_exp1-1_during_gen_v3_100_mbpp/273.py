def substract_elements(k, l):
    # Subtract corresponding elements of the two tuples
    return tuple(x - y for x, y in zip(k, l))