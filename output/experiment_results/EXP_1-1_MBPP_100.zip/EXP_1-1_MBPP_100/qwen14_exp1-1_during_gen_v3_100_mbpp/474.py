def replace_char(word, old_char, new_char):
    # Replace occurrences of old_char with new_char in the word
    return word.replace(old_char, new_char)