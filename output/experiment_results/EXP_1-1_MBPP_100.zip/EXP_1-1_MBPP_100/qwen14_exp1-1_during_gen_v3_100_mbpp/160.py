def find_solution(a, b, n):
    # Iterate through possible values of x
    for x in range(n + 1):
        # Calculate the corresponding value of y
        if (n - a * x) % b == 0:
            y = (n - a * x) // b
            return (x, y)
    # Return None if no solution is found
    return None

# Test cases
print(find_solution(2, 3, 7))  # Expected output: (2, 1)
print(find_solution(4, 2, 7))  # Expected output: None
print(find_solution(1, 13, 17))  # Expected output: (4, 1)