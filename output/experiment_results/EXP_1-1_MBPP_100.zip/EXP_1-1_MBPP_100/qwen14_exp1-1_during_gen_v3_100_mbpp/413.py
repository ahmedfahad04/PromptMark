def extract_nth_element(tuples_list, index):
    # Extract the nth element from each tuple in the list
    return [item[index] for item in tuples_list]