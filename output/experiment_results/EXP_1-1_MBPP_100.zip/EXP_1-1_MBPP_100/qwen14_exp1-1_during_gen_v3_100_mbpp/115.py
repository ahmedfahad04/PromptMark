def empty_dit(lst):
    # Check if all dictionaries in the list are empty
    return all(not d for d in lst)

# Test cases
print(empty_dit([{},{},{}]))  # Expected output: True
print(empty_dit([{1,2},{},{}]))  # Expected output: False
print(empty_dit([]))  # Expected output: True