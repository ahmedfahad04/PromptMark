def smallest_num(input_values):
    # Current usage assumes valid, non-vacant arrays. Yields None for vacant array input.
    if not input_values:
        return None

    # Initial current minimum value.
    current_min_value = input_values[0]

    # Iterate commencing with second value.
    # Check individual scan_num vs current_min_value.
    # Update current_min_value if scan_num is smaller.
    for scan_num in input_values[1:]:
        if scan_num < current_min_value:
            current_min_value = scan_num

    # Yields smallest value.
    return current_min_value