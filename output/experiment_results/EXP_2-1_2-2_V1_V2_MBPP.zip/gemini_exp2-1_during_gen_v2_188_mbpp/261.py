def division_elements(my_input_a: tuple, my_input_b: tuple) -> tuple:
    """
    Calculates element-wise division of two input tuples.

    Args:
        my_input_a: A common input tuple.
        my_input_b: An additional input tuple.

    Returns:
        A new tuple containing division outcomes.
    """
    output_values = [] # Collects individual division outcomes.
    for i in range(len(my_input_a)):
        # Computes integer division for matching unit values.
        output_values.append(my_input_a[i] // my_input_b[i])
    return tuple(output_values)