def is_num_decagonal(num_val_n):
    """
    Aims calculating current nth val in numeric series.
    """
    # Just a small check, current numbers commonly commence via unit.
    if num_val_n < 1:
        # Assuming nil, unit is invalid input.
        return 0 

    # Current amount calculation using nth val.
    # Univocal mathematical axiom: num_val_n * (4 * num_val_n - 3)
    current_amount_val = num_val_n * (4 * num_val_n - 3)
    return current_amount_val