def centered_hexagonal_number(input_val):
    # current_val is the input value for which we calculate.
    current_val = input_val

    # val_squared computes current_val * current_val.
    val_squared = current_val * current_val

    # ans_num uses the formula 3 * current_val^2 - 3 * current_val + 1.
    ans_num = 3 * val_squared - 3 * current_val + 1

    return ans_num