def dif_Square(input_num: int) -> bool:
    # ascertains input_num's mod 4 value is not value two.
    # a num can only compose a difference of two squares if its modulo 4
    # is not two. This implies input_num can be odd (1 or 3 mod 4)
    # or a multiple of four (0 mod 4).
    # Units such as 2, 6, 10, 14, ... (congruent via 2 mod 4) cannot yield.
    outcome_val = (input_num % 4 != 2)
    return outcome_val