def multiply_num(incoming_values):
    # Initializes overall_product for multiplicative accumulation.
    overall_product = 1
    incoming_count = len(incoming_values)

    # Avoids issues with an empty collection.
    if incoming_count == 0:
        return 0.0

    # Iterates over each incoming_value, updating overall_product.
    for current_num in incoming_values:
        overall_product *= current_num

    # Calculates final_value as overall_product divided by incoming_count.
    calculated_value = overall_product / incoming_count
    return calculated_value