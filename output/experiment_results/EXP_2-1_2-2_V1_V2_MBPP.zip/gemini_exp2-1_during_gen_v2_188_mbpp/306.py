def max_sum_increasing_subseq(nums_array, num_count, index_i, index_k):
    # K's initial value. Always a component.
    initial_k_val = nums_array[index_k]
    # Current overall maximum sum value. Initialize with k's unit value.
    max_current_sum_val = initial_k_val

    # A unit array for IS sum, up to i-prefix.
    array_wis_sums = [0] * (index_i + 1)

    # Walk units until index_i.
    for j_idx in range(index_i + 1):
        # Current unit's maximum sum is its own value initially.
        array_wis_sums[j_idx] = nums_array[j_idx]

        # Compare j_idx unit with units at j_unit_idx.
        for j_unit_idx in range(j_idx):
            if nums_array[j_idx] > nums_array[j_unit_idx]:
                array_wis_sums[j_idx] = max(array_wis_sums[j_idx], array_wis_sums[j_unit_idx] + nums_array[j_idx])
        
        # If j_idx's unit value is under k's unit value, connect with k's unit.
        if nums_array[j_idx] < initial_k_val:
            # Update overall max sum, join k's unit to current subsequence sum.
            max_current_sum_val = max(max_current_sum_val, array_wis_sums[j_idx] + initial_k_val)
    
    return max_current_sum_val