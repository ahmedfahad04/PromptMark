def bitwise_xor(input_one: tuple, input_two: tuple) -> tuple:
    # Computes individual XOR operations across input units.
    computed_values_collection = [
        current_val_one ^ current_val_two
        for current_val_one, current_val_two in zip(input_one, input_two)
    ]

    # Converts collection into a unified output.
    output_computed_units = tuple(computed_values_collection)
    return output_computed_units