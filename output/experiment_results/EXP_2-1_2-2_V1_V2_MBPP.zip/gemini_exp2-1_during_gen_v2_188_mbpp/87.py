def merge_dictionaries_three(one_input_map, another_input_map, usual_input_map):
    """
    Unites three input maps into a single map.
    If common keys exist, values from the first input map ('one_input_map') will apply.
    """
    overall_combined_map = {**usual_input_map, **another_input_map, **one_input_map}
    return overall_combined_map