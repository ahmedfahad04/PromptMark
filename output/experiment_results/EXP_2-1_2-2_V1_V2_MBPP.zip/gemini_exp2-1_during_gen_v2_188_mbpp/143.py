def find_lists(an_input_union: tuple) -> int:
    """
    Counts the number of list objects within a given tuple.

    An input_union: The tuple to scan for list objects.
    """
    an_occur_count = 0 # an_occur_count: current count of list objects
    for an_item in an_input_union:
        if isinstance(an_item, list):
            an_occur_count += 1
    return an_occur_count