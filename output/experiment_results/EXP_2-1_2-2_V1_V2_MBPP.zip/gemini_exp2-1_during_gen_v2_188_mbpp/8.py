def square_nums(input_array: list) -> list:
    """
    Calculates the square of each individual numeric unit in an input array.

    Args:
        input_array: A collection of numeric units.

    Returns:
        A new collection containing the squared value of each unit.
    """
    output_collection = [] # collects square values.
    for current_unit in input_array:
        # calculates square of current unit
        output_collection.append(current_unit * current_unit)
    return output_collection