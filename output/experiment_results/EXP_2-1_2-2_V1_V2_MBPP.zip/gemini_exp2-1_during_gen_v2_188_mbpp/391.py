def convert_list_dictionary(unique_id_keys, user_names, numeric_values):
    # Initialize an output collection.
    output_collection = []

    # Iterate jointly over all input lists using zip.
    # unique_id_unit: Individual unique ID key.
    # user_name_unit: Individual user name.
    # numeric_value_unit: Individual numeric value.
    for unique_id_unit, user_name_unit, numeric_value_unit in zip(unique_id_keys, user_names, numeric_values):
        # Create an inner unit map with the user name as key and numeric value as its value.
        item_unit_map = {user_name_unit: numeric_value_unit}
        
        # Create an outer unit map using the unique ID as key and the inner unit map as its value.
        outer_unit_map = {unique_id_unit: item_unit_map}
        
        # Include outer unit map in output collection.
        output_collection.append(outer_unit_map)
    
    # Complete collection of nested unit maps is output.
    return output_collection