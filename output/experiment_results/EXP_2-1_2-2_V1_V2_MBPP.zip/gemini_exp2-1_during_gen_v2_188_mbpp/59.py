def is_octagonal(num_val: int) -> int:
    """
    Calculates the nth octagonal number.

    An octagonal number is a figurate number that represents points
    arranged in the shape of a regular octagon.

    Args:
        num_val: An int, indicating which octagonal number to find (n).

    Returns:
        An int, the nth octagonal number.
    """
    # Computes octagonal value using its direct formula.
    oct_num_val = num_val * (3 * num_val - 2)
    return oct_num_val