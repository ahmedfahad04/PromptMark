def add_string(input_collection: list, input_command_string: str) -> list:
    """
    Applies a given format string to all units in a collection.

    Arguments:
        input_collection: A list of units.
        input_command_string: A format command string.

    Returns:
        A new collection with all units formatted.
    """
    output_collection = [] # Creates a new collection.
    for an_unit in input_collection:
        # Applies the command string using current unit.
        current_formatted_string = input_command_string.format(an_unit)
        output_collection.append(current_formatted_string)
    return output_collection