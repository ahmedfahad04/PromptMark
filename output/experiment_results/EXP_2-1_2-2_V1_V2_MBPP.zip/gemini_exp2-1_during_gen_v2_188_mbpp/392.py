def get_max_sum(n_input, known_sums=None):
    # known_sums is an argument. A memoization unit.
    if known_sums is None:
        # A new cache. Memoization unit.
        known_sums = {}

    # Initial condition: If n_input is small, its own value may yield maximal.
    if n_input <= 1:
        return n_input

    # If n_input is a known_sums key, just use it.
    if n_input in known_sums:
        return known_sums[n_input]

    # current_sum_amount is a sum via calls.
    current_sum_amount = (get_max_sum(n_input // 2, known_sums) +
                          get_max_sum(n_input // 3, known_sums) +
                          get_max_sum(n_input // 4, known_sums) +
                          get_max_sum(n_input // 5, known_sums))

    # A chosen sum is current_sum_amount or n_input.
    a_chosen_sum = max(current_sum_amount, n_input)

    known_sums[n_input] = a_chosen_sum
    return a_chosen_sum