def comb_sort(an_array: list) -> list:
    """
    Sorts a list of items using the Comb Sort algorithm.

    Comb Sort is an improvement over Bubble Sort. It eliminates 'turtles'
    (small values near the end of the list) which slow down Bubble Sort.
    It uses a shrinking gap to compare elements.
    """
    array_units = len(an_array)
    if array_units <= 1:
        return an_array

    current_gap = array_units
    is_an_operation_made = True # Controls the outer while loop

    while current_gap > 1 or is_an_operation_made:
        # Update current_gap value for next comb pass
        current_gap = int(current_gap / 1.3)
        if current_gap < 1:
            current_gap = 1

        is_an_operation_made = False
        # A single pass similar to bubble sort, but with the current_gap
        for unit_index in range(array_units - current_gap):
            if an_array[unit_index] > an_array[unit_index + current_gap]:
                an_array[unit_index], an_array[unit_index + current_gap] = \
                    an_array[unit_index + current_gap], an_array[unit_index]
                is_an_operation_made = True
    return an_array