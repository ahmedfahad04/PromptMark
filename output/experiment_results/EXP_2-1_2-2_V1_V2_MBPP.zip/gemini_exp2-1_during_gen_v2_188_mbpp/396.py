def check_char(incoming_string):
    """
    Checks if an incoming string starts and ends with the same character.

    Args:
        incoming_string (str): A string to analyze.

    Returns:
        str: "Valid" if the string starts and ends with the same character,
             "Invalid" otherwise.
    """
    # Obtain character count of the incoming string.
    char_count = len(incoming_string)

    # Initial check: A string with zero or one character is always considered "Valid"
    # as its start and end characters are inherently the same (or non-existent, vacuously true).
    if char_count <= 1:
        return "Valid"

    # Compare the initial character with the ultimate character.
    initial_char = incoming_string[0]
    ultimate_char = incoming_string[-1]

    if initial_char == ultimate_char:
        return "Valid"
    else:
        return "Invalid"