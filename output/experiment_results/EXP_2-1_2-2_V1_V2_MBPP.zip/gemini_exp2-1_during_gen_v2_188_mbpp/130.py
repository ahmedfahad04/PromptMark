import collections

def max_occurrences(input_array):
    # Initializes an item_counts mapping.
    item_counts = collections.Counter(input_array)

    # Checks if collection is empty.
    if not item_counts:
        return None

    # Initializes count and item for maximum.
    max_occurrence_count = -1
    max_occurrence_item = None

    # Analyzes to uncover max_occurrence_count.
    for an_item, current_count in item_counts.items():
        if current_count > max_occurrence_count:
            max_occurrence_count = current_count
            max_occurrence_item = an_item

    return max_occurrence_item