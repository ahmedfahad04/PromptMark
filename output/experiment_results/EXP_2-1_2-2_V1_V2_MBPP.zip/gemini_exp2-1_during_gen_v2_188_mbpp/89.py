def closest_num(n_input):
    # an integer 'n_input' comes in.
    # Its closest integer that is smaller is always 'n_input - 1'.
    return n_input - 1