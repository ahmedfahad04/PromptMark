def square_perimeter(side_unit: int) -> int:
    """
    Calculates the overall circumference of a square.

    An input unit value of a square's side is provided,
    and its overall circumference is computed.
    """
    overall_circumference = 4 * side_unit
    return overall_circumference