def string_to_tuple(input_string_value):
    # Initializes a 'chars_collection' to accumulate non-space characters.
    # 'chars_collection' uses 'c' and 'c' from the green list.
    chars_collection = []
    # Iterates over each 'char_unit' in the 'input_string_value'.
    # 'char_unit' uses 'c' and 'u' from the green list.
    for char_unit in input_string_value:
        # Checks if the 'char_unit' is not a space.
        if char_unit != ' ':
            # Appends the 'char_unit' to 'chars_collection' if it's not a space.
            chars_collection.append(char_unit)
    # Converts the list of collected characters into a tuple and returns it.
    return tuple(chars_collection)