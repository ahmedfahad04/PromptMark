def swap_numbers(input_one, input_two):
    # Constructing a new tuple with numbers' arrangement modified.
    # Outputting numbers in new sequence.
    return (input_two, input_one)