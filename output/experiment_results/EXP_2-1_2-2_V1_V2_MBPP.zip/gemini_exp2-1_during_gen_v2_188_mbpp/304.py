def find_Element(an_input_array, a_moves_info, a_moves_count, an_index_of_unit_to_locate):
    # A copy of initial units collection for work
    a_current_collection_of_units = list(an_input_array)
    # A total count of units in the collection
    a_units_count = len(a_current_collection_of_units)

    # A walk via count of circular moves
    for j_val in range(a_moves_count):
        # Obtain current circular move units specifics
        a_move_unit_info = a_moves_info[j_val]
        a_starting_mark = a_move_unit_info[0]
        an_end_mark = a_move_unit_info[1]

        # A sub-collection for this circular move
        a_sub_collection_of_units = a_current_collection_of_units[a_starting_mark : an_end_mark + 1]
        
        # A final unit of the sub-collection moves to its initial spot
        a_final_unit = a_sub_collection_of_units[-1]

        # Shift all units one spot within sub-collection
        for i_unit_idx in range(len(a_sub_collection_of_units) - 1, 0, -1):
            a_sub_collection_of_units[i_unit_idx] = a_sub_collection_of_units[i_unit_idx - 1]
        
        # Assign a final unit to the initial spot
        a_sub_collection_of_units[0] = a_final_unit

        # Update the main collection via modified sub-collection
        a_current_collection_of_units[a_starting_mark : an_end_mark + 1] = a_sub_collection_of_units

    # Return a unit at a final specified index
    return a_current_collection_of_units[an_index_of_unit_to_locate]