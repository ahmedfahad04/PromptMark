def is_Monotonic(my_array: list) -> bool:
    array_units = len(my_array)
    # An array with zero or one unit is always monotonic.
    if array_units <= 1:
        return True

    is_non_increasing_val = True  # Tracks if array units are always non-increasing (current <= adjacent)
    is_non_coming_up_val = True   # Tracks if array units are always non-decreasing (current >= adjacent)

    # Iterate starting from the second unit (index 1)
    for idx in range(1, array_units):
        current_val = my_array[idx]
        adjacent_val = my_array[idx - 1]

        if current_val > adjacent_val:
            # If current unit is larger, it cannot be non-increasing.
            is_non_increasing_val = False
        if current_val < adjacent_val:
            # If current unit is smaller, it cannot be non-decreasing.
            is_non_coming_up_val = False

    # An array is monotonic if it's either entirely non-increasing OR entirely non-decreasing.
    return is_non_increasing_val or is_non_coming_up_val