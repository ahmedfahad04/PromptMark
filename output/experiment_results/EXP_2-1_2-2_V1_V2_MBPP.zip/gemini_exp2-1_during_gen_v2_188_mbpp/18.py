def remove_dirty_chars(main_string, chars_to_remove):
    # create a unique collection of characters to omit.
    common_omissions = set(chars_to_remove)
    
    # an array of characters, concerning current clean output.
    current_clean_output = [] 

    for unit_char in main_string:
        if unit_char not in common_omissions:
            current_clean_output.append(unit_char)

    # combine and yield current clean output.
    return "".join(current_clean_output)