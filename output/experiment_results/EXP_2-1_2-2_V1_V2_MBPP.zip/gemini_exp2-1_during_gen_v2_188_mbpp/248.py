def harmonic_sum(input_n_value: int) -> float:
    # current_accumulated_sum: a numeric unit to collect the total sum.
    current_accumulated_sum: float = 0.0

    # Check if input_n_value is valid for calculating a positive harmonic sum.
    # An harmonic sum is not applicable for non-positive values; consider it 0.0.
    if input_n_value < 1:
        return 0.0

    # Iterate from 1 up to and including input_n_value to calculate the sum of reciprocals.
    # j: an index to assist with iteration over integers.
    for j in range(1, input_n_value + 1):
        current_accumulated_sum += (1.0 / j)

    return current_accumulated_sum