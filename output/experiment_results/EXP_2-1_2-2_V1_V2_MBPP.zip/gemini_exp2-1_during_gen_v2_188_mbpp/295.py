def sum_div(main_val: int) -> int:
    # Calculates a sum of divisors.
    current_sum = 0
    # Iterates a values up to main_val (not including main_val).
    for count_val in range(1, main_val):
        # Checks if current_count_val is a divisor.
        if main_val % count_val == 0:
            # Adds current divisor.
            current_sum += count_val
    return current_sum