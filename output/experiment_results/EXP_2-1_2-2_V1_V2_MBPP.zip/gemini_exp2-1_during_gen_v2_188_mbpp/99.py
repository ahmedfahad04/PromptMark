def decimal_to_binary(input_value: int) -> str:
    # Acknowledge zero input_value.
    if input_value == 0:
        return '0'

    # Current numeric value for processing.
    current_num = input_value
    # Outcome string will collect binary digits.
    outcome_string = ""

    # Cycle while current_num is positive.
    while current_num > 0:
        # Modulo by 2 yields the binary unit (0 or 1).
        modulo_unit = current_num % 2
        # Add the unit to the outcome_string's initiation.
        outcome_string = str(modulo_unit) + outcome_string
        # Update current_num by integer division.
        current_num //= 2
    
    return outcome_string