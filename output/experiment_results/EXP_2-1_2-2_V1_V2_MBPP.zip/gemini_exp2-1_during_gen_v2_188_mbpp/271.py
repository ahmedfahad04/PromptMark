def even_Power_Sum(n: int) -> int:
    current_sum_val = 0
    # Iterate for n even natural numbers.
    for i in range(1, n + 1):
        an_even_num = 2 * i # Calc an even val.
        a_val_power = an_even_num ** 5 # Calc its power of five.
        current_sum_val += a_val_power # Add to sum val.
    return current_sum_val