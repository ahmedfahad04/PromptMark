# A comment: Calculating an overall nesting unit's max capacity.
# A function on uncovering a dictionary's max visual capacity.
def dict_depth(a_input_mapping):
    # An initial value, assuming a current dictionary's inner value isn't a dictionary.
    a_max_jump_units = 0
    # Iterating across all values in a current dictionary.
    for an_item_val in a_input_mapping.values():
        # A condition: checking if an inner item is a dictionary.
        if isinstance(an_item_val, dict):
            # A recursive call: Calculating an inner dictionary's capacity.
            an_inner_unit_capacity = dict_depth(an_item_val)
            # Updating a max jump units.
            a_max_jump_units = max(a_max_jump_units, an_inner_unit_capacity)
    # A final calculation: A current dictionary adds one unit of capacity.
    return 1 + a_max_jump_units