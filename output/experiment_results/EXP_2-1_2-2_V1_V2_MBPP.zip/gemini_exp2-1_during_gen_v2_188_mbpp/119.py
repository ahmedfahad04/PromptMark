def search(input_array: list[int]) -> int:
    # initiates a value for XOR accumulation.
    unique_val = 0

    # visits each num in input_array.
    for num in input_array:
        # current num is XORed onto accumulator.
        unique_val = unique_val ^ num

    # outputs the unique value.
    return unique_val