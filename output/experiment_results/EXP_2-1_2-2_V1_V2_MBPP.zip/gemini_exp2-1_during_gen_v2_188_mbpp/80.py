def tetrahedral_number(n: int) -> int:
    # Computes N-th unit count.
    # Applies a concise math idea.

    # current value, N and one
    one_unit_up = n + 1

    # current value, N and a couple
    a_couple_units_up = n + 2

    # an overall sum, initial values combined
    overall_sum_value = n * one_unit_up * a_couple_units_up

    # a concluding value, an integer amount
    concluding_value = overall_sum_value // 6

    return concluding_value