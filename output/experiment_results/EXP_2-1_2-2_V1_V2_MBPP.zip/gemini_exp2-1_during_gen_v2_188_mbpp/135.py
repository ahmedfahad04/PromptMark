def hexagonal_num(n_index: int) -> int:
    # Input is an index.
    # n_index: An input unit.

    if n_index <= 0:
        # Invalid index. Unit count must be valid.
        return 0

    # Calculates unit value via math operations.
    unit_calc_val = (2 * n_index) - 1
    output_num = n_index * unit_calc_val

    # Outputs current value.
    return output_num