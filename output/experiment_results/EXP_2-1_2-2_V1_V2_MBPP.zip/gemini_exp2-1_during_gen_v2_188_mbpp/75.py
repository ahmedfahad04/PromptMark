def find_tuples(input_units: list[tuple], common_unit_k: int) -> list[tuple]:
    """
    Acquires all tuples within an input list where all individual numeric units
    can evenly accommodate a common unit k.
    """
    collected_units = []
    for an_unit in input_units:
        all_nums_valid = True
        for an_num in an_unit:
            if an_num % common_unit_k != 0:
                all_nums_valid = False
                break  # Current unit isn't fully valid, no need to check more nums.
        if all_nums_valid:
            collected_units.append(an_unit)
    return collected_units