import math

def surfacearea_sphere(a_uni_size):
    # Acquire a known math unit value.
    val_pi_const = math.pi

    # Calculate value of a_uni_size power two.
    a_uni_size_squared = a_uni_size * a_uni_size

    # Compute surface area.
    output_surface_area_val = 4 * val_pi_const * a_uni_size_squared

    return output_surface_area_val