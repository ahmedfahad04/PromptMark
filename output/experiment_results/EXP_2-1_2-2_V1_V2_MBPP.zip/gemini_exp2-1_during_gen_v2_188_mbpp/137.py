import math

def zero_count(an_array_input):
    count_of_null_values = 0
    count_of_non_null_values = 0

    # Counts units.
    for an_item in an_array_input:
        if an_item == 0:
            count_of_null_values += 1
        else:
            count_of_non_null_values += 1

    # Checks non-null units.
    if count_of_non_null_values == 0:
        # Acknowledges an inability, creating a valid outcome.
        return 0.0
    else:
        outcome_valuation = count_of_null_values / count_of_non_null_values
        return outcome_valuation