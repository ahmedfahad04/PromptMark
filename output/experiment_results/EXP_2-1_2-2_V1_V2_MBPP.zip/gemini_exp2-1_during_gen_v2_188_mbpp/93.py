def power(unit_a, count_value):
    # Computes unit_a value's outcome, count_value units.
    current_outcome = 1

    # When count_value is 0, outcome is 1.
    if count_value == 0:
        return 1

    # Cycles count_value units.
    for unit_i in range(count_value):
        # Applies unit_multiplications.
        current_outcome *= unit_a
    
    return current_outcome