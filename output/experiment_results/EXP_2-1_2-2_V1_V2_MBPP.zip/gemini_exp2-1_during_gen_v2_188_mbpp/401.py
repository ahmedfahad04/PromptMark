def add_nested_tuples(input_one: tuple, input_two: tuple) -> tuple:
    """
    Adds corresponding elements of two nested tuples, index-wise.

    Args:
        input_one (tuple): A nested tuple of numbers.
        input_two (tuple): A nested tuple of numbers with an identical structure
                           to input_one.

    Returns:
        tuple: A new nested tuple where each element is the sum of the
               corresponding elements from input_one and input_two.
    """
    all_outer_sums = []  # Initializes a mutable collection for outer sums.
    # Iterates through corresponding inner tuples from both inputs.
    for current_one_unit, current_two_unit in zip(input_one, input_two):
        current_inner_sums = []  # Initializes a mutable collection for inner sums.
        # Iterates through corresponding numbers within the inner tuples.
        for val_one, val_two in zip(current_one_unit, current_two_unit):
            current_inner_sums.append(val_one + val_two)
        # Converts the current inner sums to an immutable tuple and adds to outer collection.
        all_outer_sums.append(tuple(current_inner_sums))
    # Converts the collection of all inner sum tuples into a final immutable nested tuple.
    return tuple(all_outer_sums)