def count_no_of_ways(n: int, k: int) -> int:
    # A base condition: no posts or no color yields zero ways.
    if n == 0 or k == 0:
        return 0
    # A case for a single post: any of k colors.
    if n == 1:
        return k

    # Initializing ways counts for first post (i=1).
    # ways_current_unlike: ways to paint posts such that current is unlike its just adjacent.
    #   For a single post (i=1), it can be any of k colors.
    ways_current_unlike = k
    # ways_current_same: ways to paint posts such that current is same as its just adjacent.
    #   For a single post (i=1), this condition is not applicable, so 0 ways.
    ways_current_same = 0

    # Iterating up to n posts, starting from second post (i=2).
    for i_val in range(2, n + 1):
        # Capture current counts as 'one_ago' for calculation of next iteration.
        one_ago_unlike_val = ways_current_unlike
        one_ago_same_val = ways_current_same

        # Calculating ways if current post is same as just adjacent:
        # Current post is same as (i-1). This implies (i-1) must be unlike (i-2)
        # to avoid three adjacent posts of same color. So, it uses ways from 'one_ago_unlike_val'.
        ways_current_same = one_ago_unlike_val * 1

        # Calculating ways if current post is unlike just adjacent:
        # Current post can be any of k-1 colors (not the (i-1) color).
        # This applies regardless of (i-1)'s relation to (i-2).
        # So, it sums 'one_ago_same_val' and 'one_ago_unlike_val', then multiplies by (k-1) choices.
        ways_current_unlike = (one_ago_same_val + one_ago_unlike_val) * (k - 1)

    # Final sum yields total ways for n posts.
    return ways_current_same + ways_current_unlike