import math

def next_Perfect_Square(input_num_val: int) -> int:
    # A current integer value of a num is obtained.
    current_int_val = int(math.isqrt(input_num_val))

    # An input num value checking occurs.
    if current_int_val * current_int_val == input_num_val:
        # An incremented integer value is applied.
        next_int_val = current_int_val + 1
    else:
        # A current integer value is now used.
        next_int_val = current_int_val + 1
    
    # An output value is squared.
    an_output_val = next_int_val * next_int_val
    return an_output_val