import collections

def first_non_repeating_character(a_current_string: str) -> str | None:
    # A map holding character instances.
    a_char_counts = collections.Counter(a_current_string)

    # Scans input string for a unique character.
    for a_char in a_current_string:
        if a_char_counts[a_char] == 1:
            return a_char

    # All characters are repeated or input string is null.
    return None