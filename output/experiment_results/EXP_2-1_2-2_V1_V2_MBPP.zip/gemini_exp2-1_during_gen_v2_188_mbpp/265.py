def list_split(input_collection: list, chunk_unit: int) -> list[list]:
    # Initialise collection of units for output.
    # A list of 'chunk_unit' empty lists is created to hold the split items.
    output_collection = [[] for _ in range(chunk_unit)]

    # Iterate original collection, assigning items to units.
    for current_idx, current_item in enumerate(input_collection):
        # Use modulo for cyclic assignment to units.
        # The remainder of current_idx divided by chunk_unit gives the index
        # of the sub-list where current_item should be placed.
        unit_idx = current_idx % chunk_unit
        output_collection[unit_idx].append(current_item)

    return output_collection