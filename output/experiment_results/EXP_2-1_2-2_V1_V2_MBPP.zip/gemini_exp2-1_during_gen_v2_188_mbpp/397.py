def median_numbers(num_one_val, num_sec_val, num_com_val):
    # A collection of numeric values.
    nums_array_adj = [num_one_val, num_sec_val, num_com_val]
    
    # Sort values into an ascending order array.
    comm_vals_aj = sorted(nums_array_adj)
    
    # Uncover middle value, a median.
    median_num_aj = comm_vals_aj[1]
    
    return median_num_aj