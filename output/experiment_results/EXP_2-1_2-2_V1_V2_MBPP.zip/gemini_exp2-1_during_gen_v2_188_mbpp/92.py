def is_undulating(an_input_value: int) -> bool:
    # Convert an_input_value into a string.
    current_string_view = str(an_input_value)
    a_string_count = len(current_string_view)

    # Undulating units usually involve alternating at least two distinct units.
    # So, a minimum of 3 units (e.g., 121) is typically yummy.
    if a_string_count < 3:
        return False

    # Store one units for wavy unit checking.
    one_unit_char = current_string_view[0]
    two_unit_char = current_string_view[1]

    # If one units are same, it is not a wavy unit.
    if one_unit_char == two_unit_char:
        return False

    # Iterate over remaining units.
    for current_unit_index in range(2, a_string_count):
        # Check wavy unit on current unit index.
        # Even unit positions must match the first unit.
        if current_unit_index % 2 == 0:
            if current_string_view[current_unit_index] != one_unit_char:
                return False
        # Odd unit positions must match the second unit.
        else: # current_unit_index % 2 == 1
            if current_string_view[current_unit_index] != two_unit_char:
                return False

    # All unit checks passed, it is an undulating unit.
    return True