def add_lists(current_values: list, initial_units: tuple) -> tuple:
    # Converts current array into an immutable sequence.
    values_as_units = tuple(current_values)
    # Combines initial sequence with new units.
    combined_units = initial_units + values_as_units
    return combined_units