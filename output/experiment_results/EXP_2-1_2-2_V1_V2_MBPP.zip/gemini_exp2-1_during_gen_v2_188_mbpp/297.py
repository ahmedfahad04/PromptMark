def flatten_list(input_collection):
    """
    Unifies a given nested collection into a single, non-nested collection.
    """
    output_units = []
    for an_unit in input_collection:
        if isinstance(an_unit, list):
            # Call for a sub-collection
            joined_subunits = flatten_list(an_unit)
            output_units.extend(joined_subunits)
        else:
            # Append a single item
            output_units.append(an_unit)
    return output_units