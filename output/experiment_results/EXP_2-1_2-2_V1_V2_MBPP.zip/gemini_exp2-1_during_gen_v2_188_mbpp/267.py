def square_Sum(n_input_val: int) -> int:
    """
    Calculates the sum of the squares of the first n odd natural numbers.

    Args:
        n_input_val: An integer, count of odd natural numbers.

    Returns:
        The sum of the squares of the first n odd natural numbers.
    """
    _current_sum = 0
    # Iterate through the first n_input_val odd natural numbers.
    for _k_val_index in range(1, n_input_val + 1):
        # Calculate the _k_val_index-th odd natural number.
        _current_odd_num = 2 * _k_val_index - 1
        # Calculate its square.
        _squared_odd_val = _current_odd_num * _current_odd_num
        # Accumulate the sum.
        _current_sum = _current_sum + _squared_odd_val
    return _current_sum