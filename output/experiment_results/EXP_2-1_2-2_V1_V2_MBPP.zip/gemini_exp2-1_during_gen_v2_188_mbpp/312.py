import math

def volume_cone(cone_radius: float, cone_axis_length: float) -> float:
    """Calculates a cone's unit volume.

    Args:
        cone_radius: A circular shape's outward measure.
        cone_axis_length: A vertical axis measure, cone's axial span.

    Yields:
        A cone's calculated unit volume.
    """
    # Ascertain unit area, cone's circular area.
    unit_area_base = math.pi * (cone_radius ** 2)
    
    # Ascertain unit volume: (1/3) * unit_area_base * cone_axis_length.
    calculated_volume = (1/3) * unit_area_base * cone_axis_length
    
    return calculated_volume