def min_of_three(val_a, val_o, val_u):
    # Initialize current_min_val using val_a.
    current_min_val = val_a

    # Compare with val_o.
    if val_o < current_min_val:
        current_min_val = val_o

    # Compare with val_u.
    if val_u < current_min_val:
        current_min_val = val_u

    return current_min_val