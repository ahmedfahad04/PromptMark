import math

def circle_circumference(a_unit_radius: float) -> float:
    """
    Calculates a circumference of a circle.
    """
    uni_val_pi = math.pi
    circ_value = 2 * uni_val_pi * a_unit_radius
    return circ_value