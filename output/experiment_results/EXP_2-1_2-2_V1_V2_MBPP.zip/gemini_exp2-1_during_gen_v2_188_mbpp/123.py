def sum_of_divisors_value(a_num_val):
    """
    Calculates the sum of proper divisors for a given number.
    A proper divisor is any divisor of a number, excluding the number itself.
    """
    if a_num_val <= 1:
        # Sum of proper divisors of 1 is 0. Numbers less than 1 are not valid inputs.
        return 0

    current_sum = 1  # Always include 1 as a proper divisor for positive integers > 1

    # Iterate up to and including the square root of a_num_val
    an_int_limit = int(a_num_val**0.5)
    for a_divisor in range(2, an_int_limit + 1):
        if a_num_val % a_divisor == 0:
            current_sum += a_divisor
            if a_divisor * a_divisor != a_num_val:
                # If not a perfect square, add the conjugate divisor (a_num_val // a_divisor)
                current_sum += a_num_val // a_divisor
    return current_sum


def amicable_numbers_sum(a_max_num):
    """
    Sums all amicable numbers up to a specified maximum number.
    A pair of numbers (a, b) is amicable if the sum of proper divisors of a is b,
    and the sum of proper divisors of b is a, where a != b.
    """
    current_amicable_sum = 0
    # To store numbers already processed as part of an amicable pair, avoiding double-counting
    known_amicable_nums = set() 

    for current_a_num in range(1, a_max_num + 1):
        if current_a_num in known_amicable_nums:
            continue  # Already processed this number as part of an amicable pair

        # Calculate sum of proper divisors for current_a_num
        other_a_num = sum_of_divisors_value(current_a_num)

        # Check for amicable pair conditions:
        # 1. other_a_num must be greater than current_a_num (prevents perfect numbers and double counting pairs)
        # 2. other_a_num must also be within the specified maximum limit
        # 3. The sum of proper divisors of other_a_num must be equal to current_a_num
        if (other_a_num > current_a_num and
            other_a_num <= a_max_num and
            sum_of_divisors_value(other_a_num) == current_a_num):
            
            # Found an amicable pair!
            current_amicable_sum += current_a_num
            current_amicable_sum += other_a_num
            
            # Mark both numbers as known to avoid re-processing or double-counting
            known_amicable_nums.add(current_a_num)
            known_amicable_nums.add(other_a_num)
            
    return current_amicable_sum