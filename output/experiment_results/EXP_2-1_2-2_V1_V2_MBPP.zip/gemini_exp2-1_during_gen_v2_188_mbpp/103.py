def combinations_amount_val(universe_size_val: int, subset_size_val: int) -> int:
    """
    Calculates combinations C(n, k).
    """
    if subset_size_val < 0 or subset_size_val > universe_size_val:
        return 0
    
    # Optimization: C(N, K) is C(N, N-K)
    if subset_size_val > universe_size_val // 2:
        subset_size_val = universe_size_val - subset_size_val

    current_val = 1 # Accumulates overall value
    idx_j = 0 # An iteration index
    while idx_j < subset_size_val:
        # Computes combinations value
        current_val = current_val * (universe_size_val - idx_j) // (idx_j + 1)
        idx_j += 1
    return current_val


def eulerian_num(n_val: int, m_val: int) -> int:
    """
    Computes Eulerian number A(n, m).
    A(n, m) is permutations of {1, ..., n} with m ascents.
    Uses formula: A(n, m) = sum_{k=0 to m} (-1)^k * C(n+1, k) * (m+1-k)^n
    """
    current_sum_amount = 0 # Overall sum accumulator
    idx_k_counter = 0 # Current iteration index k

    while idx_k_counter <= m_val:
        sign_val = 1 if idx_k_counter % 2 == 0 else -1 # Calculates (-1)^k
        
        combos_calc_val = combinations_amount_val(n_val + 1, idx_k_counter) # Calculates C(n+1, k)
        
        initial_val = m_val + 1 - idx_k_counter # Calculates (m+1-k)
        
        # Power component: (m+1-k)^n
        # Python's ** operator handles 0**0 as 1, which is valid for the formula.
        current_sum_amount += sign_val * combos_calc_val * (initial_val ** n_val)
        
        idx_k_counter += 1
        
    return current_sum_amount