def odd_Equivalent(input_string_value, amount_cycles):
    count_odd_values = 0
    current_units_vision = input_string_value

    # Iterating amount_cycles times to simulate rotations.
    for current_index_value in range(amount_cycles):
        # A cyclic unit is odd if its final symbol is '1'.
        if current_units_vision[-1] == '1':
            count_odd_values += 1
        
        # Cyclic shift, advancing the initial symbol.
        current_units_vision = current_units_vision[1:] + current_units_vision[0]
        
    return count_odd_values