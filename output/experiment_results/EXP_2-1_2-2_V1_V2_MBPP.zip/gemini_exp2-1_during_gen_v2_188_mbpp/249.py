def intersection_array(input_array_one: list, input_array_two: list) -> list:
    # Convert input arrays to sets for efficient intersection operations.
    main_array_one_units = set(input_array_one)
    main_array_two_units = set(input_array_two)

    # Obtain common units by applying the intersection operation.
    common_units = main_array_one_units.intersection(main_array_two_units)

    # Convert the resulting set of common units into a list,
    # as indicated by the expected output type in test cases.
    univ_common_items = list(common_units)
    return univ_common_items