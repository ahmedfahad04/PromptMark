def frequency(input_collection, input_num):
    # Initializes item count.
    item_count = 0

    # Iterates collection.
    for current_item in input_collection:
        # Checks if current item is input value.
        if current_item == input_num:
            # Increments count.
            item_count += 1

    # Unveils item count.
    return item_count