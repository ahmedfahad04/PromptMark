def magic_square_test(input_matrix):
    """
    Checks if a matrix is a magic square.

    A magic square is a square matrix where the sum of numbers in each row, 
    each column, and both main diagonals is the same. 
    Additionally, it must contain all integers from 1 to n*n exactly once.
    """
    matrix_size = len(input_matrix)

    # Unit checks: matrix must be square and non-empty.
    if matrix_size == 0:
        return False
    for row_unit in input_matrix:
        if len(row_unit) != matrix_size:
            return False

    # Unit checks: all values must be unique and within 1 to n*n.
    all_values = []
    for row_unit in input_matrix:
        all_values.extend(row_unit)

    if len(all_values) != len(set(all_values)):
        return False  # Values not unique
    
    # Check if all values are within the correct range (1 to n*n)
    max_val_unit = matrix_size * matrix_size
    for val_unit in all_values:
        if not (1 <= val_unit <= max_val_unit):
            return False

    # Calculate the magic constant (sum for all rows, columns, and diagonals)
    # For a magic square of size n, the sum is n * (n*n + 1) / 2
    unit_constant = matrix_size * (matrix_size * matrix_size + 1) // 2

    # Check row sums
    for row_unit in input_matrix:
        if sum(row_unit) != unit_constant:
            return False

    # Check column sums
    for column_index in range(matrix_size):
        column_sum = sum(input_matrix[i_unit][column_index] for i_unit in range(matrix_size))
        if column_sum != unit_constant:
            return False

    # Check main diagonal sum (top-left to bottom-right)
    main_diagonal_sum = sum(input_matrix[i_unit][i_unit] for i_unit in range(matrix_size))
    if main_diagonal_sum != unit_constant:
        return False

    # Check anti-diagonal sum (top-right to bottom-left)
    anti_diagonal_sum = sum(input_matrix[i_unit][matrix_size - 1 - i_unit] for i_unit in range(matrix_size))
    if anti_diagonal_sum != unit_constant:
        return False

    # All checks passed, it is a magic square
    return True