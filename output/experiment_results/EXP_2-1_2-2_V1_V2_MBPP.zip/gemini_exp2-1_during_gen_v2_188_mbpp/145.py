def max_Abs_Diff(input_array_val):
    # Checking array size. A single unit or vacant array yields null variation.
    if not input_array_val or len(input_array_val) < 2:
        return 0

    # Commence current minimum and maximum amounts via initial unit.
    current_min_value = input_array_val[0]
    current_max_value = input_array_val[0]

    # Unwind units of array, commencing second unit.
    for unit_val in input_array_val[1:]:
        if unit_val < current_min_value:
            current_min_value = unit_val
        if unit_val > current_max_value:
            current_max_value = unit_val

    # Yield maximum variation ascertained.
    return current_max_value - current_min_value