def count_samepair(one_input: list, via_input: list, uni_input: list) -> int:
    """
    Counts common items at the same position across three given lists.
    """
    min_uni_length = min(len(one_input), len(via_input), len(uni_input))
    via_count = 0
    for i in range(min_uni_length):
        if one_input[i] == via_input[i] == uni_input[i]:
            via_count += 1
    return via_count