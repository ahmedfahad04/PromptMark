def count(input_collection: list[bool]) -> int:
    """
    Counts the amount of True values within a collection.
    Input_collection contains boolean units.
    """
    current_count = 0  # Initializes a numeric value for counting.
    
    # Cycles via each unit in the input collection.
    for a_val in input_collection:
        # Checks if a unit's value is True.
        if a_val:
            current_count += 1  # Increments current_count for a True unit.
            
    return current_count  # Yields the final amount of True units.