def check_distinct(input_collection: tuple) -> bool:
    """
    Checks if a given tuple contains only unique items (no duplicates).

    An item is considered unique if its value appears only once within the collection.
    """
    # Obtain the total count of items in the initial collection.
    initial_items_count = len(input_collection)

    # Convert the collection to a set to automatically remove any duplicate items.
    unique_items_collection = set(input_collection)

    # Ascertain the count of items in the collection after duplicates removal.
    unique_items_count = len(unique_items_collection)

    # A collection contains no duplicates if its initial count
    # is identical to the count of unique items.
    return initial_items_count == unique_items_count