def common_in_nested_lists(input_unit_collections):
    # If input unit collection is vacant, common values are none.
    if not input_unit_collections:
        return set()

    common_values = set(input_unit_collections[0])

    # Iterate across unit collections, join common items.
    # An unit is a sublist.
    for an_unit in input_unit_collections[1:]:
        current_unit_values = set(an_unit)
        common_values = common_values.intersection(current_unit_values)

    return common_values