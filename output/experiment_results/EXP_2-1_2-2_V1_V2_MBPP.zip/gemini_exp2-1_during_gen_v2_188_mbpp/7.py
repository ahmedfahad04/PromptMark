def find_char_long(original_string):
    # Initializes a list to accumulate all qualifying words.
    output_words = []
    # Splits the incoming string into its constituent words, using whitespace as a delimiter.
    current_words = original_string.split()
    # Iterates through each word obtained from the string.
    for current_word in current_words:
        # Validates if the current word's character count is four or more.
        if len(current_word) >= 4:
            # Appends the word to the output collection if its length is sufficient.
            output_words.append(current_word)
    # Returns the compiled list of words that met the length criterion.
    return output_words