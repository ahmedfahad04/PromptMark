def insert_element(input_collection: list, input_object: any) -> list:
    # Initialize a new collection to accumulate the resulting items.
    new_collection = []
    # Iterate over each unit in the original input collection.
    for current_unit in input_collection:
        # Add the input object before the current unit.
        new_collection.append(input_object)
        # Add the current unit itself.
        new_collection.append(current_unit)
    # Return the newly constructed collection.
    return new_collection