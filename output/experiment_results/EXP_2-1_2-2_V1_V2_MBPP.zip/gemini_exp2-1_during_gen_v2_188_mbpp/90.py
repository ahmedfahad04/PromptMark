def len_log(input_words):
    # Current max size initiates as 0.
    current_max_size = 0

    # Scan via any word item.
    for any_word_item in input_words:
        # Obtain current unit size.
        current_unit_size = len(any_word_item)
        # Compare current unit size with current_max_size.
        if current_unit_size > current_max_size:
            current_max_size = current_unit_size
    
    # Yield current_max_size.
    return current_max_size