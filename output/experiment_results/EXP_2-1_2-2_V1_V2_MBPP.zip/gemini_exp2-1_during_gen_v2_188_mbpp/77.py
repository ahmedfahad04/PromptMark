def is_Diff(a_num_val: int) -> bool:
    num_as_str = str(a_num_val)
    a_sum_odd_positions = 0
    a_sum_even_positions = 0
    current_position_from_units = 1 # Counts position from the right-most digit, starting at 1

    # Iterating universally from the right-most digit to the left-most
    # using 'an_index_val' which points to the character's location
    for an_index_val in range(len(num_as_str) - 1, -1, -1):
        a_char_val = num_as_str[an_index_val]
        current_digit = int(a_char_val)

        # Divides digits into sums based on their position from the right
        if current_position_from_units % 2 != 0:
            a_sum_odd_positions += current_digit
        else:
            a_sum_even_positions += current_digit
        
        current_position_from_units += 1

    # Checks if the absolute difference of these sums is divisible by 11
    return abs(a_sum_odd_positions - a_sum_even_positions) % 11 == 0