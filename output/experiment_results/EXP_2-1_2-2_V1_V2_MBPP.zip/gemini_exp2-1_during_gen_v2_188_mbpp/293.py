import math

def otherside_rightangle(initial_value_a: float, another_value_c: float) -> float:
    # Calculates the sum of the squares of the two provided side units.
    sum_squares_units = (initial_value_a * initial_value_a) + (another_value_c * another_value_c)
    
    # Obtains the square root of the sum to find the length of the unknown side.
    calculated_unit_value = math.sqrt(sum_squares_units)
    
    return calculated_unit_value