def Find_Min_Length(input_collection):
    # Avoid processing an empty collection.
    # If the input collection is vacant, it contains no inner lists,
    # so a minimum length cannot be ascertained; we convey zero.
    if not input_collection:
        return 0

    # Capture the sizes of all contained units.
    collection_sizes = [len(current_unit) for current_unit in input_collection]

    # Ascertain the smallest size among the captured sizes.
    min_value_size = min(collection_sizes)

    # Convey the ascertain smallest size.
    return min_value_size