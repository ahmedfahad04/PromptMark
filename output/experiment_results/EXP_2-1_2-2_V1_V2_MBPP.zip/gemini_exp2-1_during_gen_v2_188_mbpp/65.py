import collections.abc

def recursive_list_sum(input_collection):
    """
    Computes a cumulative sum of all numeric values within a possibly nested list.
    """
    current_sum = 0
    for unit_item in input_collection:
        # Checks if unit_item is a collection (like a list or tuple) but not a string.
        # Strings are also iterable but we don't want to sum their characters.
        if isinstance(unit_item, collections.abc.Iterable) and not isinstance(unit_item, (str, bytes)):
            current_sum += recursive_list_sum(unit_item)
        else:
            # Assumes the item is a number if not a collection.
            current_sum += unit_item
    return current_sum