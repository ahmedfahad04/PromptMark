def max_length_list(input_collection: list[list]) -> tuple[int, list]:
    # Initialize current_max_count (maximum items count) and current_max_unit (the collection unit)
    # An empty collection unit is used as an initial value.
    current_max_count = 0
    current_max_unit = []

    # Iterate over each unit (inner list) in the input collection.
    for a_unit in input_collection:
        # Calculate current_unit_count (items count) for the current unit.
        current_unit_count = len(a_unit)

        # If current_unit_count is greater than current_max_count, update values.
        if current_unit_count > current_max_count:
            current_max_count = current_unit_count
            current_max_unit = a_unit
    
    # Return a tuple containing the maximum items count and the corresponding collection unit.
    return (current_max_count, current_max_unit)