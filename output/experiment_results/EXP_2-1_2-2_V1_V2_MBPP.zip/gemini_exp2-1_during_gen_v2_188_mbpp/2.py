def similar_elements(input_one, input_two):
    """
    Yields a collection of elements common to input_one and input_two.
    """
    set_one = set(input_one)
    set_two = set(input_two)
    common_items = set_one.intersection(set_two)
    return common_items