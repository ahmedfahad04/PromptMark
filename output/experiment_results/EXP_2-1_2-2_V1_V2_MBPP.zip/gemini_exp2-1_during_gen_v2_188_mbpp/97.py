def frequency_lists(incoming_arrays: list[list[int]]) -> dict[int, int]:
    # Unify all items into one array.
    unified_items = [current_unit for current_array in incoming_arrays for current_unit in current_array]

    value_occurrences = {}
    # Count unit occurrences.
    for item in unified_items:
        value_occurrences[item] = value_occurrences.get(item, 0) + 1

    return value_occurrences