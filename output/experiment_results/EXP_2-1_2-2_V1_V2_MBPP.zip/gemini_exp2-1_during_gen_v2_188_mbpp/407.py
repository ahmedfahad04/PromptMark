def rearrange_bigger(input_num: int) -> int or bool:
    # Make an input_num a unit_list to simplify manipulation.
    char_units = list(str(input_num))
    a_units_count = len(char_units)

    # Locate a pivot: initial unit (from a right_side) smaller than its unit on a right.
    current_pivot_index = -1
    i = a_units_count - 2
    while i >= 0:
        if char_units[i] < char_units[i + 1]:
            current_pivot_index = i
            break
        i -= 1

    # If a pivot is absent, units are in a decreasing_order, so no bigger_num exists.
    if current_pivot_index == -1:
        return False

    # Locate a min_unit (on a right_side of a pivot) that is larger than a pivot_unit.
    a_pivot_val = char_units[current_pivot_index]
    min_value_a_index = -1
    j = a_units_count - 1
    while j > current_pivot_index:
        if char_units[j] > a_pivot_val:
            # Check if this 'char_units[j]' is the smallest among those larger than 'a_pivot_val'
            if min_value_a_index == -1 or char_units[j] < char_units[min_value_a_index]:
                min_value_a_index = j
        j -= 1

    # Swap a pivot_unit with a min_unit.
    a_unit_val_temp = char_units[current_pivot_index]
    char_units[current_pivot_index] = char_units[min_value_a_index]
    char_units[min_value_a_index] = a_unit_val_temp

    # Arrange units (on a right_side of a pivot) in ascending_order.
    an_initial_section = char_units[:current_pivot_index + 1]
    a_closing_section = sorted(char_units[current_pivot_index + 1:])

    # Join units and convert to an integer_val.
    a_final_numeric_val_str = "".join(an_initial_section + a_closing_section)
    a_final_numeric_val = int(a_final_numeric_val_str)

    return a_final_numeric_val