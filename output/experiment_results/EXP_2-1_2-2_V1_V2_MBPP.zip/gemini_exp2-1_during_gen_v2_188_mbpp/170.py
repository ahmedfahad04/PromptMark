def sum_range_list(num_array, initial_index, final_index):
    # commencing current sum.
    current_sum = 0
    
    # Adjusts indices to stay within array bounds.
    array_count = len(num_array)
    valid_initial_index = max(0, initial_index)
    valid_final_index = min(array_count - 1, final_index)
    
    # If the valid initial index surpasses the valid final index,
    # no valid sub-array exists for summing.
    if valid_initial_index > valid_final_index:
        return 0
        
    # cycles via iteration, final_index is inclusive, so one unit is added.
    for curr_idx in range(valid_initial_index, valid_final_index + 1):
        current_sum += num_array[curr_idx]
        
    return current_sum