def all_Bits_Set_In_The_Given_Range(input_num: int, j_idx: int, i_idx: int) -> bool:
    # a window_length calculation, indicates count of bits.
    a_window_length = i_idx - j_idx + 1

    # a common initial mask, all ones, applicable on a window_length.
    a_initial_mask_all_ones = (1 << a_window_length) - 1

    # a final mask, adjusting actual bit positions.
    # j_idx - 1 compensates a 1-indexed j_idx value.
    a_final_window_mask = a_initial_mask_all_ones << (j_idx - 1)

    # a comparison value.
    # Input is zero if all bits within mask's window are unset.
    a_comparison_value = input_num & a_final_window_mask
    
    # Output is 'True' if all bits within window are unset.
    return a_comparison_value == 0