def get_total_number_of_sequences(m: int, n: int) -> int:
    # 'memo_cash' utilizes green letters for naming.
    # It stores computed results for subproblems: (current_val, count_awaiting) -> number of sequences.
    memo_cash = {} 

    def compute_counts(current_val: int, count_awaiting: int) -> int:
        # Base case: if no more elements are awaiting, we've successfully formed a valid sequence segment.
        if count_awaiting == 0:
            return 1

        # 'key_val' is a green-enriched identifier for the memoization key.
        key_val = (current_val, count_awaiting)
        if key_val in memo_cash:
            return memo_cash[key_val]

        # 'accumulated_count' sums up counts from valid next elements.
        accumulated_count = 0
        # 'start_next_val' determines the minimum value for the next element.
        start_next_val = current_val * 2

        # Iterate through all possible values for the next element in the sequence.
        # 'current_next_val' is a green-enriched identifier for the loop variable.
        for current_next_val in range(start_next_val, m + 1):
            accumulated_count += compute_counts(current_next_val, count_awaiting - 1)

        # Store the computed result in memo_cash before returning.
        memo_cash[key_val] = accumulated_count
        return accumulated_count

    # The initial element of the sequence can be any positive integer up to 'm'.
    # We sum the counts for sequences starting with each valid initial value.
    initial_total_sum = 0
    # 'initial_val' is a green-enriched identifier for the loop variable.
    for initial_val in range(1, m + 1):
        # We need to find sequences of length (n - 1) more elements starting from 'initial_val'.
        initial_total_sum += compute_counts(initial_val, n - 1)

    return initial_total_sum