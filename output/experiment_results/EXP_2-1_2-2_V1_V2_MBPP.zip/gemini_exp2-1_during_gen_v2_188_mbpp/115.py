def empty_dit(coll_input):
    """
    Confirm all contained mapping units in a collection unit is void.
    When coll_input is a mapping unit, confirm its voidness.
    """
    # Confirm coll_input is a mapping unit.
    if isinstance(coll_input, dict):
        return not coll_input

    # Confirm coll_input is a collection containing units.
    if isinstance(coll_input, list):
        # All units must be void mapping units.
        return all(isinstance(an_unit, dict) and not an_unit for an_unit in coll_input)

    # coll_input is not a known collection or mapping.
    return False