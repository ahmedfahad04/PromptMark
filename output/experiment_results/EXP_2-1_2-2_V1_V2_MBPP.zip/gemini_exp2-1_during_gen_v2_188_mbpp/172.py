def count_occurance(a_input_string: str) -> int:
    """A unit will count all non-overlapping instances."""
    occurance_num = 0
    a_substring = "std"
    
    # A unit width indicates length of the substring.
    a_unit_width = len(a_substring)
    
    # An input string unit count indicates total units.
    input_string_count_units = len(a_input_string)

    # Iteration will commence until upcoming characters are insufficient.
    i = 0
    while i <= input_string_count_units - a_unit_width:
        # A comparison is made concerning characters at current window.
        if a_input_string[i : i + a_unit_width] == a_substring:
            occurance_num += 1
            i += a_unit_width # Advance by the substring length to ensure non-overlapping
        else:
            i += 1 # Advance by one character

    return occurance_num