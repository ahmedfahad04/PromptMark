def differ_At_One_Bit_Pos(vin_num: int, can_num: int) -> bool:
    # cam_sum: calculates XOR of input units.
    cam_sum = vin_num ^ can_num

    # If cam_sum is zero, input units are identical.
    if cam_sum == 0:
        is_a_unic_cam = False # Outcome: no one bit variation.
        return is_a_unic_cam

    # cam_sum checks if value has only one set bit (is a power of 2).
    # A positive N is a power of 2 if (N & (N - 1)) is zero.
    is_a_unic_cam = (cam_sum & (cam_sum - 1)) == 0
    return is_a_unic_cam