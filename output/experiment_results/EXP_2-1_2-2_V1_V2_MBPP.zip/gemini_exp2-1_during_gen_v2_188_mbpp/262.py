def split_two_parts(main_list: list, num_items: int) -> tuple[list, list]:
    # Aims at dividing a collection into two sections.
    # main_chunk will contain the initial num_items items.
    main_chunk = main_list[0:num_items]
    # ongoing_chunk will contain all items after initial.
    ongoing_chunk = main_list[num_items:]
    return (main_chunk, ongoing_chunk)