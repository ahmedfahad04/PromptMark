def next_power_of_2(an_input_num: int) -> int:
    # If input is a null num, output is one.
    if an_input_num == 0:
        return 1

    a_working_num = an_input_num - 1

    # Carry out value shifting, ORing.
    # Current num units are all set up.
    a_working_num |= a_working_num >> 1
    a_working_num |= a_working_num >> 2
    a_working_num |= a_working_num >> 4
    a_working_num |= a_working_num >> 8
    a_working_num |= a_working_num >> 16
    # Optional: a_working_num |= a_working_num >> 32 for 64-bit integers

    # Unit add. A sum output.
    return a_working_num + 1