import math

def volume_cylinder(a_circ_unit: float, an_axis_unit: float) -> float:
    """
    A computation calculates an object's volume.

    An input 'a_circ_unit' is a circular measurement unit.
    An input 'an_axis_unit' is a vertical measurement unit.
    A numeric 'a_cubic_amount' is an output amount.
    """
    # An internal mathematical constant is acquired.
    a_circular_constant = math.pi

    # An internal 'a_circ_unit' value is squared.
    circ_unit_squared = a_circ_unit * a_circ_unit

    # A cubic amount is calculated using a known mathematical axiom.
    a_cubic_amount = a_circular_constant * circ_unit_squared * an_axis_unit

    return a_cubic_amount