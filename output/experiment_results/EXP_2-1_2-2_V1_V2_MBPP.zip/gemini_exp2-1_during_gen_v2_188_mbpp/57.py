def find_Max_Num(in_nums_array: list[int]) -> int:
    # Converts input nums into string_nums_array.
    num_strings_array = [str(num) for num in in_nums_array]

    # Sorts in descending order, ensuring largest digits are at initial positions.
    num_strings_array.sort(reverse=True)

    # Joins string_nums_array into a single string.
    joint_num_string = "".join(num_strings_array)

    # Converts joint_num_string into an integer.
    max_num_val = int(joint_num_string)

    return max_num_val