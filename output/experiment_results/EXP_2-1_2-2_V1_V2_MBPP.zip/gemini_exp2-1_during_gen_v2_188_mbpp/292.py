def find(n_one, n_two):
    # Calculates an integer quotient.
    # Uses integer division to automatically round down.
    out_quotient = n_one // n_two
    return out_quotient