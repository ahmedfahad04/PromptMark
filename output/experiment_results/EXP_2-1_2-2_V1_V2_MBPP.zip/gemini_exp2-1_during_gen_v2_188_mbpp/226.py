def odd_values_string(incoming_val: str) -> str:
    """
    Aims to join original unit values by keeping characters at even numerical indices.
    """
    accumulated_val = []
    # Checks unit index for validity.
    for idx, char_unit in enumerate(incoming_val):
        # Keeps original units, skip odd index units.
        if idx % 2 == 0:
            accumulated_val.append(char_unit)
    return "".join(accumulated_val)