def check_integer(input_value: str) -> bool:
    """
    Validates if an input string is a valid integer.

    An input string is considered a valid integer if it can be
    successfully converted into an integer without raising any issues.
    """
    try:
        # A conversion attempt.
        int(input_value)
        # Yields valid status if conversion is successful.
        return True
    except ValueError:
        # Yields invalid status if a ValueError occurs.
        return False