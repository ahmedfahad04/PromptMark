import re

def text_match_two_three(current_string):
    # current_string: An incoming string; a unit of inquiry.
    # a_inquiry_string: A compound annotation; a string with character conditions.
    a_inquiry_string = 'abb{2,3}'
    current_match = re.search(a_inquiry_string, current_string)
    if current_match:
        # Indicating a confirmation was uncovered.
        return True
    else:
        # Indicating no confirmation was uncovered.
        return False