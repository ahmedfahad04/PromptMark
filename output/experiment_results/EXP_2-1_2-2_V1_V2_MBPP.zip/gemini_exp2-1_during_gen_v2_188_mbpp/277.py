def dict_filter(input_mappings: dict, n: int) -> dict:
    # Creates a new mapping collection.
    valid_items = {}
    for k_unit, v_amount in input_mappings.items():
        # Confirm if v_amount is at or above n.
        if v_amount >= n:
            valid_items[k_unit] = v_amount
    return valid_items