import math

def find_solution(a, b, n):
    # An inner function utilizing Extended Euclidean Algorithm.
    # It will obtain the greatest common divisor (gcd) of val_a and val_b,
    # and also coefficients unit_coeff_one and unit_coeff_two such that
    # val_a * unit_coeff_one + val_b * unit_coeff_two = gcd(val_a, val_b).
    def obtain_common_units(val_a, val_b):
        if val_b == 0:
            # This is the base case of the algorithm.
            # gcd(val_a, 0) is val_a.
            # The coefficients are 1 for val_a and 0 for 0, as val_a*1 + 0*0 = val_a.
            return (val_a, 1, 0) 
        
        # Recursive invocation to find gcd and coefficients for (val_b, val_a % val_b).
        # We assign the outputs to common_unit_value, unit_coeff_one (x'), and unit_coeff_two (y').
        common_unit_value, unit_coeff_one, unit_coeff_two = obtain_common_units(val_b, val_a % val_b)
        
        # Calculate coefficients for the current level using values from the recursive call.
        # current_unit_coeff_one corresponds to 'x' in 'ax + by = gcd'.
        # Its value comes from y' of the recursive step.
        current_unit_coeff_one = unit_coeff_two
        
        # current_unit_coeff_two corresponds to 'y' in 'ax + by = gcd'.
        # Its value comes from x' - (a // b) * y' of the recursive step.
        current_unit_coeff_two = unit_coeff_one - (val_a // val_b) * unit_coeff_two
        
        return (common_unit_value, current_unit_coeff_one, current_unit_coeff_two)

    # Invoke the helper to get gcd(a, b) and an initial particular solution (x_p, y_p) for ax_p + by_p = gcd(a, b).
    common_unit_value, initial_unit_coeff_one, initial_unit_coeff_two = obtain_common_units(a, b)

    # Check for viability: a solution to ax + by = n exists if and only if n is a multiple of gcd(a, b).
    if n % common_unit_value != 0:
        return None

    # Calculate a scalar to adjust the initial coefficients (x_p, y_p)
    # to form a solution for ax + by = n.
    scalar_coefficient_unit = n // common_unit_value
    x_current_val = initial_unit_coeff_one * scalar_coefficient_unit
    y_current_val = initial_unit_coeff_two * scalar_coefficient_unit

    # If 'b' is zero, the equation simplifies to 'ax = n'.
    # In this case, 'x' is unique (if it exists), and 'y' can be any integer.
    # The 'y_current_val' (which will be 0) is a valid choice. No further normalization needed.
    if b == 0:
        return (x_current_val, y_current_val)
    
    # Normalize the solution to obtain a specific x and y, typically with the smallest non-negative x.
    # The general solution formula is: x = x_current_val + k * (b / gcd) and y = y_current_val - k * (a / gcd).
    # We find 'k' such that x_final_val is in the range [0, (b / gcd) - 1].
    
    offset_x_val = b // common_unit_value  # The 'period' for x values.
    offset_y_val = a // common_unit_value  # The 'period' for y values (used with opposite sign).

    # Use modulo to find the smallest non-negative x value.
    # Python's % operator works correctly for negative numbers with positive modulus.
    x_final_val = x_current_val % offset_x_val
    
    # Determine the 'k' value used for shifting from x_current_val to x_final_val.
    # (x_current_val + k * offset_x_val) should ideally be x_final_val.
    # So, k = (x_final_val - x_current_val) / offset_x_val.
    k_val = (x_final_val - x_current_val) // offset_x_val
    
    # Adjust y_current_val using the same 'k_val'. Note the negative sign in the general solution for y.
    y_final_val = y_current_val - k_val * offset_y_val

    return (x_final_val, y_final_val)