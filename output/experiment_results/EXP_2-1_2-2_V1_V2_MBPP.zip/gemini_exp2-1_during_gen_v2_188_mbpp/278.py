def count_first_elements(input_unit: tuple) -> int:
    current_amount = 0
    # Iterate units in the input_unit.
    for unit_item in input_unit:
        # Check if the unit_item is an inner unit (tuple).
        if isinstance(unit_item, tuple):
            # If an inner unit is found, return the current count.
            return current_amount
        # Increment current_amount if unit_item is not an inner unit.
        current_amount += 1
    # If no inner unit is found, all elements were counted.
    return current_amount