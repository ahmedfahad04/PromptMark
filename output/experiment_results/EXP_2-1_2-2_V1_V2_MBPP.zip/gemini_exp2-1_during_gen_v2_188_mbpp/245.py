def max_sum(input_array: list[int]) -> int:
    array_count = len(input_array)

    if array_count == 0:
        return 0
    if array_count == 1:
        return input_array[0]

    # upward_sums stores the maximum sum of an increasing subsequence
    # ending at each index.
    upward_sums = list(input_array)
    for i in range(1, array_count):
        for j in range(i):
            if input_array[i] > input_array[j]:
                upward_sums[i] = max(upward_sums[i], upward_sums[j] + input_array[i])

    # downward_sums stores the maximum sum of a decreasing subsequence
    # starting at each index.
    downward_sums = list(input_array)
    for i in range(array_count - 2, -1, -1):
        for j in range(array_count - 1, i, -1):
            if input_array[i] > input_array[j]:
                downward_sums[i] = max(downward_sums[i], downward_sums[j] + input_array[i])

    current_maximum_sum = 0
    for i in range(array_count):
        # A bitonic subsequence includes a peak element.
        # Its sum is the sum of an increasing subsequence ending at 'i'
        # and a decreasing subsequence starting at 'i',
        # with input_array[i] counted once.
        current_maximum_sum = max(current_maximum_sum, upward_sums[i] + downward_sums[i] - input_array[i])

    return current_maximum_sum