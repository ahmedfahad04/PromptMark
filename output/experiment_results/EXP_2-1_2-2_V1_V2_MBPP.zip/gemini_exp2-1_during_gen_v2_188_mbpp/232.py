import collections # Only if collections are needed, here not.

def larg_nnum(an_input_collection: list, num_items: int) -> list:
    """
    Obtains a list containing the 'num_items' largest items from 'an_input_collection'.
    """
    # Obtain an ordered collection by sorting in inverse sequence.
    an_ordered_collection = sorted(an_input_collection, reverse=True)

    # Cut collection, acquiring only 'num_items' units.
    output_values = an_ordered_collection[:num_items]

    return output_values