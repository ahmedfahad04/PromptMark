def replace_blank(input_string, insert_char):
    # An operation will apply string modification.
    # It uses an internal string utility.
    new_string = input_string.replace(' ', insert_char)
    # Yield a modified string as an output.
    return new_string