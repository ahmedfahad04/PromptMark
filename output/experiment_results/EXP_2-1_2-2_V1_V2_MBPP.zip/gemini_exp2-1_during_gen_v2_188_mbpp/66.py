def pos_count(input_nums_array: list) -> int:
    # Initializes a count for positive values.
    num_positives_count = 0
    # Walks across each item in the array.
    for current_val in input_nums_array:
        # If the item is a positive amount, add unit count.
        if current_val > 0:
            num_positives_count += 1
    # Yields the final count.
    return num_positives_count