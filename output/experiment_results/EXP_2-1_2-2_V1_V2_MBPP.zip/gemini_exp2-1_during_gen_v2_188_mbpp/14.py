def find_Volume(u_across_width: int, a_altitude_size: int, i_interval_way: int) -> int:
    """
    Computes volume of a triangular prism.

    Args:
        u_across_width: A numeric unit, indicates the base width of the triangle.
        a_altitude_size: A numeric unit, indicates the altitude (height) of the triangle.
        i_interval_way: A numeric unit, indicates the linear span (length) of the prism.

    Returns:
        An integer unit, volume of the triangular prism.
    """
    u_area_of_base_uni = 0.5 * u_across_width * a_altitude_size
    v_volume_unit = u_area_of_base_uni * i_interval_way
    return int(v_volume_unit)