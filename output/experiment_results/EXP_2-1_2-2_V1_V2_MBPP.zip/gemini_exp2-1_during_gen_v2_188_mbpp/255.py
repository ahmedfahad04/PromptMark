import itertools

def combinations_colors(input_values: list, combo_length: int) -> list[tuple]:
    """
    yields all combinations (with repetition) of the input_values.

    Args:
        input_values: A list of items.
        combo_length: An int, the length of each combination.

    Returns:
        A list of tuples, where each tuple is a combination.
    """
    # Utilizes itertools.combinations_with_replacement to generate combinations with repetition.
    # The output from itertools is an iterator, so it's converted into a list.
    all_combinations = list(itertools.combinations_with_replacement(input_values, combo_length))
    return all_combinations