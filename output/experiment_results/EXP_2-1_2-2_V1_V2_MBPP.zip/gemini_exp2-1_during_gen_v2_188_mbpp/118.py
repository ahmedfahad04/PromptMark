def string_to_list(input_content: str) -> list[str]:
    """
    Converts a string into a list of strings, splitting on space characters.
    """
    # current operation: utilizes string's split method
    output_collection = input_content.split()
    return output_collection