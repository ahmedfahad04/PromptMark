def find_length(input_binary_string: str) -> int:
    # Initialize overall_maximum_sum to 0. This accounts for cases where no '0' is present,
    # or the maximum difference (count of 0s minus count of 1s) is 0.
    # An empty substring effectively yields a 0 difference.
    overall_maximum_sum = 0

    # Initialize current_window_sum to track the sum of differences within the current contiguous substring.
    current_window_sum = 0

    for current_unit_char in input_binary_string:
        # Assign a numeric_value_of_char: '0' contributes +1 to the sum, '1' contributes -1.
        if current_unit_char == '0':
            numeric_value_of_char = 1
        else:  # current_unit_char == '1'
            numeric_value_of_char = -1

        # Add the numeric_value_of_char to the current_window_sum.
        current_window_sum += numeric_value_of_char

        # If current_window_sum becomes negative, reset it to 0.
        # A negative sum indicates that the count of '1's has outweighed '0's in the current substring,
        # making this prefix detrimental to achieving a maximum positive difference.
        # It's optimal to start a new contiguous substring from the next position.
        if current_window_sum < 0:
            current_window_sum = 0
        
        # Update overall_maximum_sum if the current_window_sum is greater.
        overall_maximum_sum = max(overall_maximum_sum, current_window_sum)
    
    return overall_maximum_sum