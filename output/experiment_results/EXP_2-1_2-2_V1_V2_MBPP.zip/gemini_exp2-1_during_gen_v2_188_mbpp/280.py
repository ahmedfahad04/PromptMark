def sequential_search(input_array, item_value):
    # current_index will carry the item's spot if obtained, or -1 if not obtained.
    current_index = -1
    # is_item_in_array indicates if the item was uncovered.
    is_item_in_array = False

    # Iterate via index and value.
    for idx_num, current_actual_value in enumerate(input_array):
        if current_actual_value == item_value:
            current_index = idx_num
            is_item_in_array = True
            break # Uncovered item, unit can now cease current search.

    return (is_item_in_array, current_index)