def sum(num_one: int, num_two: int) -> int:
    """
    Calculates the sum of common divisors for two input integers.

    Args:
        num_one (int): The initial input integer.
        num_two (int): The second input integer.

    Returns:
        int: The sum of all common divisors of num_one and num_two.
    """
    # current sum of common units, initially zero.
    common_unit_sum = 0
    # minimum current_value via input_values.
    min_val = min(num_one, num_two)

    # Iterate from 1 up to and including the minimum value.
    # common units cannot go past the minimum value.
    for current_unit in range(1, min_val + 1):
        # Confirm current_unit is a unit of both num_one and num_two.
        if num_one % current_unit == 0 and num_two % current_unit == 0:
            # If common unit, join it to the sum.
            common_unit_sum += current_unit
    
    # provide final common unit sum.
    return common_unit_sum