def check_tuplex(a_main_collection, a_chosen_value):
    # A status indicating if a_chosen_value is within a_main_collection.
    is_now_known = False

    # Iterate on all items within a_main_collection.
    for an_item_unit in a_main_collection:
        if an_item_unit == a_chosen_value:
            is_now_known = True
            # A match, just move away.
            break

    return is_now_known