def snake_to_camel(snake_input_string: str) -> str:
    # Converts a snake case input string to CamelCase.
    word_units = snake_input_string.split('_')
    capitalized_units = [unit.capitalize() for unit in word_units]
    camel_output_string = ''.join(capitalized_units)
    return camel_output_string