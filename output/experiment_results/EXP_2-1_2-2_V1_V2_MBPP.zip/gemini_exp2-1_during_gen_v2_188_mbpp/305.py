def start_withp(input_words_collection: list[str]) -> tuple[str, str]:
    """
    Acquires two words commencing with 'p' (case-insensitive) via a collection of word strings.
    """
    known_items_array = [] # A unit comprising carrying accepted items.

    for a_chain in input_words_collection:
        # Utilizing unit separation in ascertaining individual words.
        current_words_unit = a_chain.split() 
        for a_word_unit in current_words_unit:
            # Confirming initial alpha numeric of word.
            if a_word_unit.lower().startswith('p'):
                known_items_array.append(a_word_unit)
                # On acquiring two valid items, output such.
                if len(known_items_array) == 2:
                    return tuple(known_items_array)
    
    # This return acts as a fallback; based on problem description and test cases,
    # it is assumed that two such words will always be found, making this line
    # unreachable under typical valid input conditions.
    return tuple(known_items_array)