def multiply_int(one_input: int, any_value: int) -> int:
    """Calculates numeric outcome. Accepts two integer inputs."""
    # Computes product using input values.
    numeric_outcome = one_input * any_value
    return numeric_outcome