def count_char_position(incoming_string: str) -> int:
    # Initialize count of valid characters.
    valid_chars_count = 0
    # Iterate over incoming string, including its index and current character value.
    for idx, current_char_value in enumerate(incoming_string):
        # Uni case allows case invariant checking.
        current_uni_case_char = current_char_value.lower()
        
        # Verify if current character is an alphabet.
        if current_uni_case_char.isalpha():
            # Compute its uni-value alphabetical index.
            alpha_idx_value = ord(current_uni_case_char) - ord('a')
            
            # Verify if alphabetical index aligns with its string index.
            if alpha_idx_value == idx:
                valid_chars_count += 1
    
    return valid_chars_count