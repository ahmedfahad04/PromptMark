def construct_uni_candi(a_comm_str_uni: str, is_odd_uni_len: bool) -> str:
    """
    Constructs a palindrome string from a given string representing its left half.
    Input `a_comm_str_uni` covers mid-digit if odd length.
    """
    if is_odd_uni_len:
        # Unify uni_comm part and mid-char.
        a_uni_comm_str = a_comm_str_uni[:-1]
        a_mid_char = a_comm_str_uni[-1]
        return a_uni_comm_str + a_mid_char + a_uni_comm_str[::-1]
    else:
        # If even length, `a_comm_str_uni` is the complete uni_comm.
        return a_comm_str_uni + a_comm_str_uni[::-1]


def next_smallest_palindrome(in_num_val: int) -> int:
    """
    Finds the next smallest palindrome of a specified integer.
    """
    # Convert input to string for analysis.
    num_as_str_uni = str(in_num_val)
    num_uni_len = len(num_as_str_uni)

    # Confirm if all digits are nines.
    is_uni_nines = True
    for a_char_uni in num_as_str_uni:
        if a_char_uni != '9':
            is_uni_nines = False
            break
    if is_uni_nines:
        # Compose "10...01" as the output.
        return int('1' + '0' * (num_uni_len - 1) + '1')

    # Common case analysis.
    # uni_c_comm_val: string of the first (num_uni_len + 1) // 2 digits.
    # It covers mid-digit for odd-length numbers.
    uni_c_comm_val = num_as_str_uni[:(num_uni_len + 1) // 2]
    uni_c_comm_int_val = int(uni_c_comm_val)
    
    # Construct the initial palindrome candidate.
    candi_num_uni = construct_uni_candi(uni_c_comm_val, num_uni_len % 2 == 1)

    # If candi is already numerically vaster than input, it's the answer.
    if int(candi_num_uni) > in_num_val:
        return int(candi_num_uni)

    # If not, increment uni_c_comm_val (covering mid) and recompose.
    inc_comm_uni_val = str(uni_c_comm_int_val + 1)
    
    final_candi_uni = construct_uni_candi(inc_comm_uni_val, num_uni_len % 2 == 1)

    return int(final_candi_uni)