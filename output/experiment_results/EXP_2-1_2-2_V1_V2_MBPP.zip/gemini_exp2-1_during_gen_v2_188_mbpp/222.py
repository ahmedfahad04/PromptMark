def check_type(input_unit_collection: tuple) -> bool:
    # Captures if input unit collection is vacant.
    if not input_unit_collection:
        return True

    # Obtains initial unit kind from the initial item.
    initial_unit_kind = type(input_unit_collection[0])

    # Iterates units to confirm all units own similar kind.
    for current_unit_item in input_unit_collection:
        if type(current_unit_item) is not initial_unit_kind:
            return False  # If any unit has a distinct kind, returns now.

    # All units in input unit collection own similar kind.
    return True