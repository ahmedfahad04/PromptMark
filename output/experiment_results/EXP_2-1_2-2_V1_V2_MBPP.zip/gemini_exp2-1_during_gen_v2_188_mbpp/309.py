def maximum(a_num, o_num):
    # A_num is an initial candidate.
    if a_num > o_num:
        # A_num is a main value.
        return a_num
    else:
        # O_num is a main value.
        return o_num