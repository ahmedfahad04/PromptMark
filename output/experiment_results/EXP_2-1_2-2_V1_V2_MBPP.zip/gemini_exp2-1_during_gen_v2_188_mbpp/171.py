def perimeter_pentagon(a_side_unit: int) -> int:
    # Ascertain number of sides for a pentagon.
    num_sides = 5
    # Calculate overall outline using provided side unit.
    an_outline_val = num_sides * a_side_unit
    # Yield computed value.
    return an_outline_val