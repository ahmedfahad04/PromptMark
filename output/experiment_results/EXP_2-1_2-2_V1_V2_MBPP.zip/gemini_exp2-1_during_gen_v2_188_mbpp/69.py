def is_sublist(u_container_array, i_mini_array):
    u_main_count = len(u_container_array)
    i_mini_count = len(i_mini_array)

    # A void list is a sublist of any list
    if i_mini_count == 0:
        return True

    # If sublist is wider, it cannot be a sublist
    if i_mini_count > u_main_count:
        return False

    # Check for i_mini_array occurrence via moving window
    for i_index in range(u_main_count - i_mini_count + 1):
        j_current_view = u_container_array[i_index : i_index + i_mini_count]
        if j_current_view == i_mini_array:
            return True

    return False