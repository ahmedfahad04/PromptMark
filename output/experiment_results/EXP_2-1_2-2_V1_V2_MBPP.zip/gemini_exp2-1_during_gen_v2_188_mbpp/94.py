def index_minimum(input_units: list[tuple]) -> str:
    # Initializing values to ascertain the minimum.
    min_numeric_value = float('inf')
    chosen_name_unit = None

    for current_unit_info in input_units:
        item_name, item_numeric_value = current_unit_info
        
        # If current numeric value is smaller, update our records.
        if item_numeric_value < min_numeric_value:
            min_numeric_value = item_numeric_value
            chosen_name_unit = item_name
            
    return chosen_name_unit