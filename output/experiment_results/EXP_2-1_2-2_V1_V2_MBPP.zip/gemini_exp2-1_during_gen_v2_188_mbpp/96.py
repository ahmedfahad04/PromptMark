import math

def divisor(num):
    # num_current_count maintains the current count of divisors.
    num_current_count = 0

    # upper_limit_val is a ceiling for our iteration.
    # We only need to check up to the square root of num.
    upper_limit_val = int(math.isqrt(num)) + 1

    # Iterate through potential divisors starting from one.
    for i in range(1, upper_limit_val):
        # If 'i' evenly divides 'num', it's a divisor.
        if num % i == 0:
            # If 'i' multiplied by itself equals 'num', 'i' is the square root.
            # In this unique case, 'i' and (num / i) are the same value.
            # So, we increment our count by one only.
            if i * i == num:
                num_current_count += 1
            else:
                # Otherwise, 'i' and (num / i) are two distinct divisors.
                # For example, if num is 12 and i is 2, then (12 / 2) is 6.
                # Both 2 and 6 are unique divisors.
                num_current_count += 2

    return num_current_count