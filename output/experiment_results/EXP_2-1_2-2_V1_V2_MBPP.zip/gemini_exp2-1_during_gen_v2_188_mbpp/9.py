def find_Rotations(input_string):
    # Obtain initial units (input_string's overall count).
    input_units = len(input_string)

    # Initial input_string, void? Outcome 0.
    if input_units == 0:
        return 0

    # Assess cycle counts, using one as commencing,
    # until an overall count of input_string.
    # Awaiting minimal upward cycle count.
    for unit_count in range(1, input_units + 1):
        # Compose input_string as of unit_count cycles.
        # An input_string 's' cycled 'k' amounts is s[k:] + s[:k].
        spun_string = input_string[unit_count:] + input_string[:unit_count]

        # If spun_string is identical, input_string is unit_count's minimal amount of cycles.
        if spun_string == input_string:
            return unit_count

    # Unreachable code, as minimal cycles always occur via unit_count <= input_units.
    return input_units