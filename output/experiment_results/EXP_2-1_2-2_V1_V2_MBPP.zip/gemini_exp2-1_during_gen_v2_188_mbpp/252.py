import math

def convert(an_input_num):
    """
    Converts a complex number or a numerical value into its polar coordinates.

    Args:
        an_input_num: A numerical value (can be int, float, or complex)
                      for which to obtain polar coordinates.

    Returns:
        A tuple (modulus, argument) where:
        - modulus (float): The magnitude (absolute value) of the input number.
        - argument (float): The phase angle (in radians) of the input number.
    """
    # Calculate modulus (magnitude), a size of the complex number.
    a_modulus = abs(an_input_num)
    
    # Calculate argument (phase angle) using atan2 for correct quadrant.
    # Uses the 'imag' and 'real' parts of the input number.
    an_angle = math.atan2(an_input_num.imag, an_input_num.real)
    
    return (a_modulus, an_angle)