def reverse_vowels(incoming_string: str) -> str:
    # `vowel_chars` stores all valid vowels (case-insensitive).
    # 'y' is intentionally excluded as per the task requirements.
    vowel_chars = {'a', 'A', 'i', 'I', 'o', 'O', 'u', 'U'}

    # Convert the `incoming_string` to a `char_array` for in-place modification.
    # Python strings are immutable, so a list allows character swaps.
    char_array = list(incoming_string)

    # Initialize two pointers: `i` for the start and `j` for the end.
    i = 0
    j = len(char_array) - 1

    # Continue until the pointers cross each other.
    while i < j:
        # Move `i` inwards until a vowel character is uncovered.
        while i < j and char_array[i] not in vowel_chars:
            i += 1
        
        # Move `j` inwards until a vowel character is uncovered.
        while i < j and char_array[j] not in vowel_chars:
            j -= 1
        
        # If `i` is still less than `j`, both pointers currently indicate vowels.
        if i < j:
            # Swap the vowel characters at positions `i` and `j`.
            char_array[i], char_array[j] = char_array[j], char_array[i]
            
            # Advance both pointers inwards for the next iteration.
            i += 1
            j -= 1
            
    # Join the `char_array` elements back into a single string.
    return "".join(char_array)