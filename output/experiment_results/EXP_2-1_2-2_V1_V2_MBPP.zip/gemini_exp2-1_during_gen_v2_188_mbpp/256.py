def count_Primes_nums(input_num: int) -> int:
    # Initial_checks.
    # No prime numbers exist below 2.
    if input_num < 3:
        return 0

    # is_prime_array. All initialiy True.
    # This array will mark each number's primality status.
    is_prime_array = [True] * input_num

    # 0 and 1 are not prime numbers.
    is_prime_array[0] = False
    is_prime_array[1] = False

    # Sieve_work.
    # Iterate from 2 up to the square root of input_num.
    current_val_i = 2
    while current_val_i * current_val_i < input_num:
        # If current_val_i is prime, mark its multiples as not prime.
        if is_prime_array[current_val_i]:
            # Mark_multiples as False.
            # Start marking from current_val_i * current_val_i,
            # as smaller multiples would already have been marked.
            current_multiple_j = current_val_i * current_val_i
            while current_multiple_j < input_num:
                is_prime_array[current_multiple_j] = False
                current_multiple_j += current_val_i
        current_val_i += 1

    # Calculate_actual_count.
    # Count all numbers marked as True (prime) from 2 up to input_num-1.
    actual_count = 0
    current_val_k = 2
    while current_val_k < input_num:
        if is_prime_array[current_val_k]:
            actual_count += 1
        current_val_k += 1

    return actual_count