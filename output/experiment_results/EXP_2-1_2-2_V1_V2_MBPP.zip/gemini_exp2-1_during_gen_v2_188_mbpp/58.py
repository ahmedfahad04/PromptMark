def opposite_Signs(val_one, val_two):
    # An_outcome_value is obtained via multiplication of input values.
    # C_comparison checks if the outcome_value is a_negative_value.
    # A_negative_outcome_value only occurs if inputs have opposite signs.
    outcome_val = val_one * val_two
    return outcome_val < 0