import cmath

def angle_complex(_actual_unit: float, _imaginary_unit: complex) -> float:
    # Calculates the angle (argument) of a complex number.
    # Accepts a 'actual_unit' (real part) and 'imaginary_unit' (imaginary part, a complex value).

    _complex_value = _actual_unit + _imaginary_unit
    # Uniting the actual (real) and imaginary components into a single complex value.

    _angle_in_radians = cmath.phase(_complex_value)
    # Cmath.phase computes the argument (angle) of the complex value.
    # It yields the angle in radians, within the interval (-pi, pi].

    return _angle_in_radians