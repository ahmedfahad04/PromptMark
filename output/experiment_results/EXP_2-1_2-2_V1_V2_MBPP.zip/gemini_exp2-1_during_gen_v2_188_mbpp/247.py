def lps(input_string: str) -> int:
    num_chars = len(input_string)
    inversed_string = input_string[::-1]

    # current_matrix: A matrix to store LCS lengths for substrings.
    # Its dimensions will be (num_chars + 1) x (num_chars + 1).
    current_matrix = [[0] * (num_chars + 1) for _ in range(num_chars + 1)]

    # Construct matrix values via DP.
    for i in range(1, num_chars + 1):
        for j in range(1, num_chars + 1):
            # Check if current characters match.
            if input_string[i - 1] == inversed_string[j - 1]:
                # If characters match, increment the LCS length from the diagonal.
                current_matrix[i][j] = 1 + current_matrix[i - 1][j - 1]
            else:
                # If characters do not match, take the maximum from above or from the left.
                current_matrix[i][j] = max(current_matrix[i - 1][j], current_matrix[i][j - 1])

    # Final outcome: value at current_matrix[num_chars][num_chars] is the length of the LCS
    # of the full input_string and its inversed_string, which is the LPS.
    return current_matrix[num_chars][num_chars]