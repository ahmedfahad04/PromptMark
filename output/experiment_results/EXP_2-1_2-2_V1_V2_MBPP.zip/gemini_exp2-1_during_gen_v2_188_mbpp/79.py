def word_len(a_word: str) -> bool:
    # Counts word units.
    uni_count = len(a_word)
    # Ascertains if uni_count is an odd value.
    is_odd = (uni_count % 2 != 0)
    # Outputs an answer.
    return is_odd