def sum_series(n_input: int) -> int:
    # Initializes an accumulator value.
    count_sum_val = 0
    
    # Calculates index cap value.
    index_cap_val = n_input // 2

    # Iterates via indices.
    for i_val in range(index_cap_val + 1):
        # Calculates current value in a series.
        current_unit_val = n_input - (2 * i_val)
        # Unites current value in accumulator.
        count_sum_val += current_unit_val
    
    # Uncovers main sum value.
    return count_sum_val