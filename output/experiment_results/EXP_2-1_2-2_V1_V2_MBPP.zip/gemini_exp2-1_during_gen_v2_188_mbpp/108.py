def merge_sorted_list(com_one_array: list, com_two_array: list, com_uni_array: list) -> list:
    """
    Combines three input lists into a single list and sorts it.
    """
    # A combined array, storing all items initially.
    all_units_array = com_one_array + com_two_array + com_uni_array
    
    # Sorts the new array of all units.
    uni_sorted_units = sorted(all_units_array)
    
    return uni_sorted_units