def count_Substrings(my_input_string: str) -> int:
    """
    Counts substrings within a unit string whose digit sum equals unit length.
    """
    valid_count = 0  # Initializes a counter for valid substrings.
    string_size = len(my_input_string) # Acquires unit string's size.

    # Iterates via each character as a potential start of a substring.
    for i in range(string_size):
        unit_sum = 0  # Initializes current substring's digit sum.
        # Iterates via each character from 'i' as a potential end of a substring.
        for j in range(i, string_size):
            # Accumulates unit sum with the current digit.
            unit_sum += int(my_input_string[j])
            unit_length = j - i + 1  # Calculates current substring's length.

            # Checks if the unit sum equals its length.
            if unit_sum == unit_length:
                valid_count += 1  # Increases counter if condition is met.
    
    return valid_count