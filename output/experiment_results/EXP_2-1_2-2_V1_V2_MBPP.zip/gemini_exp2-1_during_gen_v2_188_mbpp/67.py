def bell_number(input_val: int) -> int:
    """
    Computes ways count via a unit value.
    A ways count notes ways via cut a unit of items into non-void sub-units.
    """
    if input_val == 0:
        return 1

    # All ways counts up, input_val.
    ways_count_options = [0] * (input_val + 1)
    ways_count_options[0] = 1 # Ways count, unit 0, is one.

    # current_stirling_values is a cache of Stirling counts.
    # S(n, k) = S(n-1, k-1) + k * S(n-1, k)
    current_stirling_values = [0] * (input_val + 1)
    current_stirling_values[0] = 1 # S(0,0) is one.

    # Iterate upwards, via one, input_val.
    for idx_i in range(1, input_val + 1):
        # new_stirling_values contains Stirling counts, current idx_i.
        new_stirling_values = [0] * (input_val + 1)
        new_stirling_values[0] = 0 # S(idx_i,0) is a null count, idx_i onwards.

        current_sum_count = 0 # Accumulates S(idx_i, j) (j, one, idx_i). Sum is Ways count (idx_i).

        # Iterate via columns, compute Stirling counts S(idx_i, idx_j).
        for idx_j in range(1, idx_i + 1):
            # Uses S(idx_i-1, idx_j-1) and idx_j * S(idx_i-1, idx_j).
            current_value = current_stirling_values[idx_j - 1] + idx_j * current_stirling_values[idx_j]
            new_stirling_values[idx_j] = current_value
            current_sum_count += current_value

        # Update current_stirling_values via new_stirling_values, upcoming iteration.
        current_stirling_values = new_stirling_values
        # Sum S(idx_i, k) (k from 0, idx_i) is Ways count (idx_i).
        ways_count_options[idx_i] = current_sum_count

    # Will output computed ways count via input_val.
    return ways_count_options[input_val]