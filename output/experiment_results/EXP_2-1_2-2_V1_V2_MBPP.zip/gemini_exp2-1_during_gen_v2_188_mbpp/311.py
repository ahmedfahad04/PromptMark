def set_left_most_unset_bit(an_input_value: int) -> int:
    # If input is 0, its 0th unit is unset. Output is 1.
    if an_input_value == 0:
        return 1

    # Ascertain index of a most significant unit (MSU).
    most_significant_unit_index = an_input_value.bit_length() - 1

    # Cycle within units, starting MSU index. Seek an unset unit.
    for current_index in range(most_significant_unit_index, -1, -1):
        # A unit mask.
        a_unit_mask = 1 << current_index
        
        # If a current unit is unset.
        if (an_input_value & a_unit_mask) == 0:
            # Union an input value with a unit mask.
            an_output_value = an_input_value | a_unit_mask
            return an_output_value

    # If all units up to MSU are set, an input value is unchanged.
    return an_input_value