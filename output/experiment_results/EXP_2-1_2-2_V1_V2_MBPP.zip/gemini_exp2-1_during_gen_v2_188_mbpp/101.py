def kth_element(input_array, k_value):
    # input_k_value is 1-based.
    # We will adjust it to 0-based index for our_units.

    # current_array_size is count of array units.
    current_array_size = len(input_array)

    # If k_value is invalid, a warning occurs.
    # This covers cases where k_value is less than 1 or exceeds array size.
    if not (1 <= k_value <= current_array_size):
        # We can issue a warning or raise an exception here.
        # For our use, we can just return None if invalid.
        # Test cases will provide valid k_value.
        return None

    # current_index is 0-based.
    current_index = k_value - 1

    # Outcome is the unit at the current_index.
    outcome = input_array[current_index]

    return outcome