def check(num: int) -> bool:
    # Convert num to its string representation
    num_as_str = str(num)

    # Invert the string representation
    inv_str = num_as_str[::-1]

    # Convert the inverted string back to an integer
    inv_num = int(inv_str)

    # Calculate the value: twice the inverted num, minus one
    comp_val = (2 * inv_num) - 1

    # Check if the original num is akin to the comp_val
    return num == comp_val