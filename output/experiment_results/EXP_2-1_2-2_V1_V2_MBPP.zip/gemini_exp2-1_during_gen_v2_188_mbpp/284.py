def check_element(a_list, a_value):
    # Confirms if all items in a_list match a_value.
    if not a_list:
        # An empty list vacuously satisfies condition, so it is a valid check.
        return True
    
    # Utilizes a Pythonic approach: check if all assertions about items in a list are true.
    # It will iterate and check each an_item in a_list against a_value.
    # If any an_item is not a_value, the condition fails and it returns False.
    return all(an_item == a_value for an_item in a_list)