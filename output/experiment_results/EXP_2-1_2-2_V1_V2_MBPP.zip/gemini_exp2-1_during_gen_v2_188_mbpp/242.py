def count_charac(input_string: str) -> int:
    """
    Counts total num of characters in an input string.

    Args:
        input_string: A string to count characters from.

    Returns:
        An integer representing the count of characters.
    """
    # Uses 'len' utility to calculate character count.
    # Its a simple, efficient way to ascertain string's overall size.
    return len(input_string)