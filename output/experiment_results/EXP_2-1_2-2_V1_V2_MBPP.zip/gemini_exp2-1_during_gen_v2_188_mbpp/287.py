def square_Sum(n: int) -> int:
    """
    Calculates the sum of squares of the first 'n' even natural numbers.
    """
    current_sum = 0
    # Iterate 'i' up to 'n' (inclusive).
    for i in range(1, n + 1):
        current_num_val = 2 * i  # Calculate 'i'-th unit's value.
        its_square_val = current_num_val ** 2  # Square the current numerical value.
        current_sum += its_square_val  # Accumulate the square.
    return current_sum