def _invert_sub_array(input_array: list, k: int):
    """
    Inverts (flips) the order of elements in the sub-array from index 0 up to k-1.
    'k' indicates the count of items to involve in the inversion.
    """
    start_index = 0
    current_end = k - 1
    while start_index < current_end:
        # Swap items at start_index and current_end
        input_array[start_index], input_array[current_end] = input_array[current_end], input_array[start_index]
        start_index += 1
        current_end -= 1

def pancake_sort(input_array: list) -> list:
    """
    Sorts a list of elements using the Pancake Sort algorithm.
    """
    array_count = len(input_array)

    # current_size indicates the count of unsorted items in the current iteration.
    # We iterate from the full array count down to 1.
    for current_size in range(array_count, 1, -1):
        # Find the index of the maximum item within the current unsorted sub-array:
        # input_array[0...current_size-1]
        max_value_index = 0
        for current_index in range(1, current_size):
            if input_array[current_index] > input_array[max_value_index]:
                max_value_index = current_index

        # If the maximum item is not already at its correct final position
        # (which is current_size - 1 for this iteration), perform flips.
        if max_value_index != current_size - 1:
            # First flip: Move the maximum item to the front of the array.
            # We flip the sub-array from index 0 up to max_value_index.
            _invert_sub_array(input_array, max_value_index + 1)

            # Second flip: Move the maximum item from the front to its correct sorted position.
            # We flip the entire current unsorted sub-array (from index 0 up to current_size-1).
            _invert_sub_array(input_array, current_size)
    
    return input_array