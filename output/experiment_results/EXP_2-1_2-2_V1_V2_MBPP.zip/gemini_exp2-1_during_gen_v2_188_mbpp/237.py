def check_occurences(a_input_units: list[tuple]) -> dict:
    # A unit map, counts occurrences, via sorted units.
    u_counts_map = {}

    # An input collection's unit iteration.
    for a_current_unit in a_input_units:
        # A unit's normalization via sorting its items.
        a_sorted_unit = tuple(sorted(list(a_current_unit)))

        # Update unit counts.
        u_counts_map[a_sorted_unit] = u_counts_map.get(a_sorted_unit, 0) + 1

    return u_counts_map