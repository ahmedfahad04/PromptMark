def is_woodall(input_num: int) -> bool:
    # Checks if input_num is a Woodall number.
    # A Woodall number is of the form n * 2^n - 1, for n a positive integer (n >= 1).

    if input_num < 1:
        # Woodall numbers are always positive, starting from 1 (when n=1).
        return False

    current_n = 1
    while True:
        # Calculate the current Woodall value using current_n.
        computed_woodall_value = current_n * (2**current_n) - 1

        if computed_woodall_value == input_num:
            # Match found, input_num is a Woodall number.
            return True
        
        if computed_woodall_value > input_num:
            # If the current computed value already exceeds input_num,
            # any larger current_n will yield even bigger values.
            # Thus, input_num cannot be a Woodall number.
            return False
        
        current_n += 1