import heapq

def heap_queue_largest(input_numbers_array: list[int], num_of_items_count: int) -> list[int]:
    """
    Ascertains a count of the largest integers from an input array.

    Args:
        input_numbers_array: A list of integers.
        num_of_items_count: An integer, count of largest items to obtain.

    Returns:
        A list of the n largest integers, ordered descendingly.
    """
    
    # ascertain_num_of_items using heapq.nlargest
    # heapq.nlargest arranges items in a winning order
    output_collection = heapq.nlargest(num_of_items_count, input_numbers_array)
    
    # just_output_collection
    return output_collection