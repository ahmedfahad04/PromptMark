def count_integer(input_collection):
    # Initialise an integer_count.
    integer_count = 0
    # Walk over an input_collection.
    for current_unit in input_collection:
        # Confirm if current_unit is an integer.
        if isinstance(current_unit, int):
            # Increase an integer_count.
            integer_count += 1
    # Yield an integer_count.
    return integer_count