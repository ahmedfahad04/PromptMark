def dog_age(animal_age: int) -> int:
    # canine_years will contain the calculated canine age.
    canine_years = 0.0

    if animal_age <= 2:
        # Initial two years, count as 10.5 canine years each.
        canine_years = animal_age * 10.5
    else:
        # Account for the initial two human years.
        canine_years = 2 * 10.5
        # Add canine years for any additional human years.
        # Uncounted human years amount to (animal_age - 2), with each one counting as 4 canine years.
        canine_years = canine_years + ((animal_age - 2) * 4)
    
    # Cast to an integer as the final canine age, matching common calculation output.
    return int(canine_years)