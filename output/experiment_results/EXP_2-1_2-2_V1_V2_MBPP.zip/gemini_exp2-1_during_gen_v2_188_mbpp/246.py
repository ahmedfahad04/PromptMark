def babylonian_squareroot(a_num: float) -> float:
    # Input validation: Square roots of negative numbers are not real numbers.
    if a_num < 0:
        raise ValueError("Input must be a non-negative number.")
    # Special case: The square root of zero is zero.
    if a_num == 0:
        return 0.0

    # Initial approximation for the square root.
    # Using max(1.0, a_num / 2.0) offers a sound starting point for both small and large numbers.
    current_approx = max(1.0, a_num / 2.0)

    # A minimal accuracy value to determine when the approximation is sufficient.
    a_min_accuracy = 1e-7 # A small value for comparison.

    # Iterate until the approximation converges within the specified accuracy.
    # The condition checks if the square of our current approximation is sufficiently close to the original number.
    while abs(current_approx * current_approx - a_num) > a_min_accuracy:
        # Apply the Babylonian formula to calculate an improved approximation.
        a_coming_value = 0.5 * (current_approx + (a_num / current_approx))
        current_approx = a_coming_value

    return current_approx