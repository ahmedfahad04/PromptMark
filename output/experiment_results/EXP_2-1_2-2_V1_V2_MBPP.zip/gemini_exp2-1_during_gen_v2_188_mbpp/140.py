def extract_singly(incoming_collection: list) -> set:
    """
    Unifies a collection of collections into a single set of unic values.
    """
    overall_unic_nums = set()
    # Initiates iterating across outer incoming_collection.
    for inner_collection in incoming_collection:
        # Initiates iterating across current inner_collection.
        for num_val in inner_collection:
            overall_unic_nums.add(num_val)
    return overall_unic_nums