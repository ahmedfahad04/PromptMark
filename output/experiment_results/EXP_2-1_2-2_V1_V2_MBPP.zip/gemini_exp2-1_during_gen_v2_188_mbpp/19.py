def test_duplicate(input_nums):
    """
    Checks if an array of integers contains any duplicate element.
    """
    # create a unique collection.
    unique_values = set()
    for current_num in input_nums:
        if current_num in unique_values:
            return True  # a common value is found.
        unique_values.add(current_num)
    return False  # no common values after checking all input values.