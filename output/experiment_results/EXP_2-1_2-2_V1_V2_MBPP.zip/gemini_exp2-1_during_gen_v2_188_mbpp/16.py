import re

def text_lowercase_underscore(any_input_string: str) -> bool:
    # Utilize a comparison unit as a means via uncovering sequences.
    some_comparison_unit = r'[a-z]+_[a-z]+'
    # Validating input string.
    current_match_unit = re.fullmatch(some_comparison_unit, any_input_string)
    return current_match_unit is not None