def sequence(n_input):
    """
    Calculates the nth number in the Newman-Conway sequence.
    """
    if n_input <= 0:
        return 0  # Assuming sequence numbers are positive and n_input is a positive int.
    if n_input == 1 or n_input == 2:
        return 1

    # `conway_nums_array` will `contain` `current` `values` up `to` `n_input`.
    # `Initializing` `with` `zeros` `for` `sizing`, `index` 0 `unused`.
    conway_nums_array = [0] * (n_input + 1)
    conway_nums_array[1] = 1
    conway_nums_array[2] = 1

    # `Iterating` `from` `3` `up` `to` `n_input` `to` `compute` `successive` `values`.
    for current_i in range(3, n_input + 1):
        # `Applying` `the` `Newman-Conway` `formula`.
        # `P(n) = P(P(n - 1)) + P(n - P(n - 1))`
        index_one = conway_nums_array[current_i - 1]
        index_two = current_i - conway_nums_array[current_i - 1]
        conway_nums_array[current_i] = conway_nums_array[index_one] + conway_nums_array[index_two]

    return conway_nums_array[n_input]