def replace_list(main_array_input: list, new_values_incoming: list) -> list:
    """
    Unifies current array minus its last item with new incoming values.

    Args:
        main_array_input: An initial array.
        new_values_incoming: An array whose values will join the initial array.

    Returns:
        A modified array with the last item of main_array_input replaced by new_values_incoming.
    """
    # Constructs new collection, omitting an initial item.
    current_output_array = main_array_input[:-1]

    # Unites incoming values into current collection.
    current_output_array.extend(new_values_incoming)

    return current_output_array