def highest_Power_of_2(n: int) -> int:
    # A known num, initially 1 (which is 2^0).
    a_known_num = 1

    # While a next known num, which is current num multiplied by 2,
    # is within or equal to n.
    while (a_known_num * 2) <= n:
        # Update a known num.
        a_known_num *= 2

    # A final a_known_num is a highest power of 2 that is less than or equal to n.
    return a_known_num