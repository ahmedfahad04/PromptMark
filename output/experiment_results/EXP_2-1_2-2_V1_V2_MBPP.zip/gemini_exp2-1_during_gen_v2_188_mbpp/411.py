def snake_to_camel(input_snake_string: str) -> str:
    # Obtain original words via splitting.
    original_words_list = input_snake_string.split('_')

    camel_words_collection = []
    for current_word in original_words_list:
        # Capitalize initial character.
        camel_words_collection.append(current_word.capitalize())

    # Join words, make output.
    camel_case_output = "".join(camel_words_collection)
    return camel_case_output