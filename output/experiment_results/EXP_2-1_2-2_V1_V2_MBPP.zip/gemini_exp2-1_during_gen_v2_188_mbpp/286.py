def max_sub_array_sum_repeated(i_n_i_t_i_a_l_array, _a_n_y_o_t_h_e_r_val, n_u_m_c_o_p_i_e_s):
    # This helper function applies Kadane's algorithm to find the maximum
    # contiguous subarray sum in a given list of numeric values.
    def _c_a_l_c_u_l_a_t_e_max_contiguous_sum_internal(v_a_l_u_e_s_l_i_s_t):
        if not v_a_l_u_e_s_l_i_s_t:
            return 0  # Assuming an empty array sum is 0

        c_u_r_r_e_n_t_max_sum = v_a_l_u_e_s_l_i_s_t[0]
        o_v_e_r_a_l_l_max_sum = v_a_l_u_e_s_l_i_s_t[0]

        for a_c_u_r_r_e_n_t_value in v_a_l_u_e_s_l_i_s_t[1:]:
            c_u_r_r_e_n_t_max_sum = max(a_c_u_r_r_e_n_t_value, c_u_r_r_e_n_t_max_sum + a_c_u_r_r_e_n_t_value)
            o_v_e_r_a_l_l_max_sum = max(o_v_e_r_a_l_l_max_sum, c_u_r_r_e_n_t_max_sum)
        
        return o_v_e_r_a_l_l_max_sum

    if not i_n_i_t_i_a_l_array or n_u_m_c_o_p_i_e_s == 0:
        return 0

    # Case 1: Only one copy of the array.
    if n_u_m_c_o_p_i_e_s == 1:
        return _c_a_l_c_u_l_a_t_e_max_contiguous_sum_internal(i_n_i_t_i_a_l_array)

    # For two or more copies, we first evaluate the maximum sum within two concatenated copies.
    # This covers subarrays fully within one copy and those spanning one boundary.
    a_u_g_m_e_n_t_e_d_array = i_n_i_t_i_a_l_array + i_n_i_t_i_a_l_array
    m_a_x_s_u_m_o_f_c_o_p_i_e_s = _c_a_l_c_u_l_a_t_e_max_contiguous_sum_internal(a_u_g_m_e_n_t_e_d_array)

    # If it's exactly two copies, this is our answer.
    if n_u_m_c_o_p_i_e_s == 2:
        return m_a_x_s_u_m_o_f_c_o_p_i_e_s
    
    # Case 3: More than two copies.
    # We check the total sum of the original array.
    o_r_i_g_i_n_a_l_sum_val = sum(i_n_i_t_i_a_l_array)

    if o_r_i_g_i_n_a_l_sum_val > 0:
        # If the original array sum is positive, repeating it further adds to the maximum sum.
        # This accounts for a maximal subarray that includes a prefix,
        # (n_u_m_c_o_p_i_e_s - 2) full arrays, and a suffix.
        return m_a_x_s_u_m_o_f_c_o_p_i_e_s + (n_u_m_c_o_p_i_e_s - 2) * o_r_i_g_i_n_a_l_sum_val
    else:
        # If the original array sum is zero or negative, additional repetitions
        # beyond two copies will not yield a greater maximum sum.
        return m_a_x_s_u_m_o_f_c_o_p_i_e_s