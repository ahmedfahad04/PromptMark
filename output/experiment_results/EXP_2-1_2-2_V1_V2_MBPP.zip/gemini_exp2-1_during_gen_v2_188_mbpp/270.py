def sum_even_and_even_index(input_array: list[int]) -> int:
    """
    Calculates sum of even numbers at even positions.
    """
    # Initializes current sum accumulator.
    current_sum = 0

    # Iterates input_array, accessing index_val and num_val.
    for index_val, num_val in enumerate(input_array):
        # Checks if index_val is an even position.
        if index_val % 2 == 0:
            # Checks if num_val is an even number.
            if num_val % 2 == 0:
                # Adds num_val to current_sum.
                current_sum += num_val
    
    # Outputs final sum.
    return current_sum