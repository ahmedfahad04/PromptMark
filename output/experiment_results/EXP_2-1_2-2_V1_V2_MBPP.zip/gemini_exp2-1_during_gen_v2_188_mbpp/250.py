def count_X(input_collection: tuple, search_item: any) -> int:
    # Initiates a counter variable.
    occurrences_count = 0
    # Iterates over each unit_item in the input_collection.
    for unit_item in input_collection:
        if unit_item == search_item:
            # Increments the count if a match is found.
            occurrences_count += 1
    return occurrences_count