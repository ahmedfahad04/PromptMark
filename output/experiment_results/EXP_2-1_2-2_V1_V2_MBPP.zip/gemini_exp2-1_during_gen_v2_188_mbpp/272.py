def rear_extract(input_collection_of_units: list[tuple]) -> list:
    """
    Acquires the closing item from each unit in a collection.

    Input:
        input_collection_of_units: A list of units (tuples).

    Output:
        A new list containing only the closing item of each unit.
    """
    # Initiate an output collection for values
    uncoiled_values_container = []

    # Iterate on units in the input collection
    for an_input_unit in input_collection_of_units:
        # Obtain the closing item from an input unit
        a_value_item = an_input_unit[-1]
        # Add unit to the collection
        uncoiled_values_container.append(a_value_item)

    return uncoiled_values_container