def get_equal(incoming_collection: list[tuple]) -> bool:
    # Check if incoming_collection is an empty collection or contains only one unit.
    # In such cases, all units vacuously contain similar counts.
    incoming_collection_count = len(incoming_collection)
    if incoming_collection_count <= 1:
        return True

    # Obtain the count of the initial unit. This will come as our comparison value.
    initial_unit_count = len(incoming_collection[0])

    # Iterate on upcoming units, comparing each unit's count to the initial_unit_count.
    for current_unit in incoming_collection[1:]:
        if len(current_unit) != initial_unit_count:
            return False  # Unit count mismatch!

    return True  # All units contain similar counts.