def sum_negativenum(any_nums: list) -> int:
    # A main_count sum.
    main_count = 0
    # Via num in any_nums.
    for num in any_nums:
        # Num is in minus.
        if num < 0:
            # Add num on main_count.
            main_count += num
    # Via main_count.
    return main_count