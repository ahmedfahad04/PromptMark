def even_position(input_values: list) -> bool:
    """
    Checks if all numbers at even indices within a given list are even.
    """
    for idx, val in enumerate(input_values):
        # Verify if current index is even
        is_current_idx_even = (idx % 2 == 0)
        # Verify if current value is odd
        is_current_val_odd = (val % 2 != 0)

        # If an even index contains an odd number, condition is unmet
        if is_current_idx_even and is_current_val_odd:
            return False
    return True