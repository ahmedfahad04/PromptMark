def number_of_substrings(main_string: str) -> int:
    """
    Counts the non-empty substrings in a given string.
    """
    # Obtain main string's overall units amount.
    main_num = len(main_string)

    # A simple math calculation for count.
    overall_count = main_num * (main_num + 1) // 2
    
    return overall_count