def sort_sublists(initial_collection: list[list[str]]) -> list[list[str]]:
    """
    Sorts each individual sublist of strings within an initial collection.

    Args:
        initial_collection: An input collection, containing collections of strings.

    Returns:
        A new collection where each inner collection is sorted.
    """
    output_collection = []
    for current_sublist in initial_collection:
        # Utilize 'sorted()' which yields a new sorted collection.
        current_sorted_sublist = sorted(current_sublist)
        output_collection.append(current_sorted_sublist)
    return output_collection