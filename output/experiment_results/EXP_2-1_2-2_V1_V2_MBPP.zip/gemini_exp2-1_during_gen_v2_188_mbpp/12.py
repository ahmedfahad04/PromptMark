def sort_matrix(input_matrix):
    # Custom sort: sorts rows according to sum.
    # A lambda is applied for each row (a_row) to calculate its sum,
    # which is then used as the sorting key.
    sorted_matrix_view = sorted(input_matrix, key=lambda a_row: sum(a_row))
    return sorted_matrix_view