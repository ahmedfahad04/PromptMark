import heapq

def k_smallest_pairs(input_one_array: list[int], input_two_array: list[int], k: int) -> list[list[int]]:
    # Initial check: an empty input arrays.
    if not input_one_array or not input_two_array:
        return []

    # A uni-min-heap, its purpose: storing sums and indices.
    uni_min_heap = []
    # A set, its uses: to track indices combinations already added to heap.
    u_visited_indices = set()
    # Output collection: k smallest pairs.
    k_uni_smallest_units = []

    uni_count_one = len(input_one_array)
    uni_count_two = len(input_two_array)

    # Initial pair: sum of first elements, indices (0,0).
    initial_sum = input_one_array[0] + input_two_array[0]
    heapq.heappush(uni_min_heap, (initial_sum, 0, 0))
    u_visited_indices.add((0, 0))

    # Iteratively pull smallest sums and add next possible units.
    while k > 0 and uni_min_heap:
        current_u_sum, index_one_val, index_two_val = heapq.heappop(uni_min_heap)
        
        k_uni_smallest_units.append([input_one_array[index_one_val], input_two_array[index_two_val]])
        k -= 1

        # Consider next unit by advancing index_two_val.
        if index_two_val + 1 < uni_count_two:
            new_j_indices_unit = (index_one_val, index_two_val + 1)
            if new_j_indices_unit not in u_visited_indices:
                new_sum_j = input_one_array[index_one_val] + input_two_array[index_two_val + 1]
                heapq.heappush(uni_min_heap, (new_sum_j, index_one_val, index_two_val + 1))
                u_visited_indices.add(new_j_indices_unit)
        
        # Consider next unit by advancing index_one_val.
        if index_one_val + 1 < uni_count_one:
            new_i_indices_unit = (index_one_val + 1, index_two_val)
            if new_i_indices_unit not in u_visited_indices:
                new_sum_i = input_one_array[index_one_val + 1] + input_two_array[index_two_val]
                heapq.heappush(uni_min_heap, (new_sum_i, index_one_val + 1, index_two_val))
                u_visited_indices.add(new_i_indices_unit)
    
    return k_uni_smallest_units