import operator

def subject_marks(input_units: list[tuple[str, int]]) -> list[tuple[str, int]]:
    # Sorts input units.
    # It will custom sort units via an index.
    # Uses operator.itemgetter.
    sorted_units = sorted(input_units, key=operator.itemgetter(1))
    # Yields sorted units.
    return sorted_units