def large_product(input_one_values, input_two_values, count_of_max_products):
    all_products_via_multiplication = []

    # Iterate on input_one_values
    for an_item_a in input_one_values:
        # Iterate on input_two_values
        for an_item_b in input_two_values:
            # Calculating product and adding to list.
            current_value_multiplied = an_item_a * an_item_b
            all_products_via_multiplication.append(current_value_multiplied)

    # Ordering all products in a descending way.
    all_products_via_multiplication.sort(reverse=True)

    # Capturing outcome with count_of_max_products.
    return all_products_via_multiplication[:count_of_max_products]