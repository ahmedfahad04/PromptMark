def ascii_value(one_char: str) -> int:
    """
    Acquires the ASCII (American Standard Code for Information Interchange)
    numerical value of a given character.

    Args:
        one_char: A single character string.

    Returns:
        An integer representing the ASCII value of the input character.
    """
    # Utilizes Python's in-built function to convert a character to its ASCII value.
    an_integer_value = ord(one_char)
    return an_integer_value