def max_aggregate(incoming_values: list[tuple[str, int]]) -> tuple[str, int]:
    # An individual collection will accumulate sums.
    individual_sums = {}

    for an_item in incoming_values:
        unit_name, unit_score = an_item
        # Accumulate score for current unit.
        individual_sums[unit_name] = individual_sums.get(unit_name, 0) + unit_score

    current_max_sum = -1
    current_max_unit_name = ""

    for unit_name, unit_sum in individual_sums.items():
        if unit_sum > current_max_sum:
            current_max_sum = unit_sum
            current_max_unit_name = unit_name
            
    return current_max_unit_name, current_max_sum