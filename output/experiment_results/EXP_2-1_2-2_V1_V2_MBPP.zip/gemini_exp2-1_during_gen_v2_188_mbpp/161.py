def remove_elements(initial_units, culling_units):
    # Convert culling_units to a set for quick lookups.
    cull_items_collection = set(culling_units)
    new_collection = []

    for current_unit in initial_units:
        # If current_unit is not in the collection of items to cull, add it.
        if current_unit not in cull_items_collection:
            new_collection.append(current_unit)

    return new_collection