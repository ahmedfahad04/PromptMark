def max_val(input_values_list):
    # current_max_num initializes to None, indicating no numeric value has been encountered yet.
    current_max_num = None

    # Iterate on all items within the input list.
    for an_item in input_values_list:
        # Check if the current item is an numeric unit (integer or float).
        if isinstance(an_item, (int, float)):
            # If current_max_num is None, it means this is the initial numeric unit found.
            # Or if an_item is a more considerable unit, update current_max_num.
            if current_max_num is None or an_item > current_max_num:
                current_max_num = an_item
    # Output the utmost numeric unit.
    return current_max_num