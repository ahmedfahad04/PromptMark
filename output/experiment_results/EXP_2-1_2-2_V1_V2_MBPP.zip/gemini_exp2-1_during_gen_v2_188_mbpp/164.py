# A utility method for summing common divisors, not including the value itself.
# In: incoming_numeric_value (an int)
# Out: integer sum of common divisors.
def _compute_values_sum(incoming_numeric_value: int) -> int:
    current_sum = 0
    # Common divisors are all divisors of a value, excluding the value itself.
    # Value 1 is a unique situation. It has no common divisors, so sum is 0.
    if incoming_numeric_value <= 1:
        return 0

    # Iterate from 1 up to half of the incoming_numeric_value (inclusive).
    # Any divisor above incoming_numeric_value // 2
    # would carry a co-divisor under incoming_numeric_value // 2.
    # Since we are only seeking common divisors, we just go up to half.
    # The value itself is not included in common divisors sum.
    unit_limit = incoming_numeric_value // 2 + 1
    for current_divisor_candidate in range(1, unit_limit):
        if incoming_numeric_value % current_divisor_candidate == 0:
            current_sum += current_divisor_candidate
    return current_sum

# Main function to check if two values have an equivalent sum of common divisors.
def are_equivalent(num_one: int, num_two: int) -> bool:
    sum_one = _compute_values_sum(num_one)
    sum_two = _compute_values_sum(num_two)
    return sum_one == sum_two