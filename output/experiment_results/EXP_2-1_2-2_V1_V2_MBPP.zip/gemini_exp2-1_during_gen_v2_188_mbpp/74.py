def is_samepatterns(words_array, patterns_array):
    """
    Checks if a sequence of words follows a given pattern.

    Args:
        words_array (list): A list of words.
        patterns_array (list): A list of pattern symbols (characters or strings).

    Returns:
        bool: True if the words_array follows the patterns_array sequence, False otherwise.
    """
    items_count_words = len(words_array)
    items_count_symbols = len(patterns_array)

    # Initial check: If counts mismatch, patterns cannot align.
    if items_count_words != items_count_symbols:
        return False

    # Create two-way mappings to ensure consistency:
    # 1. Maps pattern symbols to words.
    symbol_to_word_mapping = {}
    # 2. Maps words to pattern symbols.
    word_to_symbol_mapping = {}

    # Iterate jointly over both arrays.
    for unit_word, unit_symbol in zip(words_array, patterns_array):
        # Checking consistency for symbol to word mapping.
        if unit_symbol in symbol_to_word_mapping:
            # If symbol exists, associated word must match the current word.
            if symbol_to_word_mapping[unit_symbol] != unit_word:
                return False
        else:
            # If symbol is new, assign its word.
            symbol_to_word_mapping[unit_symbol] = unit_word

        # Checking consistency for word to symbol mapping.
        if unit_word in word_to_symbol_mapping:
            # If word exists, associated symbol must match the current symbol.
            if word_to_symbol_mapping[unit_word] != unit_symbol:
                return False
        else:
            # If word is new, assign its symbol.
            word_to_symbol_mapping[unit_word] = unit_symbol

    # If all items are processed without conflicts, the pattern is valid.
    return True