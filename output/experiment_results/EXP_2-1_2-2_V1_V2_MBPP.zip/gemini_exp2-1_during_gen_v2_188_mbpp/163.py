import math

def area_polygon(count_sides_many: int, s_uni: float) -> float:
    # uni_circular_constant_value: math.pi's uni constant.
    uni_circular_constant_value = math.pi
    
    # common angle measure unit. Uni_circular_constant_value divided by count_sides_many.
    common_angle_measure_uni = uni_circular_constant_value / count_sides_many
    
    # common one over cotangent value. Output from math.tan(common_angle_measure_uni).
    common_one_over_cotangent_val = math.tan(common_angle_measure_uni)
    
    # common underlying value. 4 X common_one_over_cotangent_val.
    common_underlying_value = 4 * common_one_over_cotangent_val
    
    # uni_side_sq_val: s_uni multiplied by s_uni.
    uni_side_sq_val = s_uni * s_uni 
    
    # common numerator value. count_sides_many multiplied by uni_side_sq_val.
    common_numerator_val = count_sides_many * uni_side_sq_val
    
    # Output area value.
    calc_output_area = common_numerator_val / common_underlying_value
    
    return calc_output_area