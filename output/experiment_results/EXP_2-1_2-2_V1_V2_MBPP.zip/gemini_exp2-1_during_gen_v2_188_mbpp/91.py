def find_substring(input_collection, inquiry_substring):
    # Iterate via each string unit within the input collection.
    for current_string_item in input_collection:
        # Check if the inquiry substring is a unit of the current string item.
        if inquiry_substring in current_string_item:
            # Substring is present, return confirmation.
            return True
    # No matches found, return no confirmation.
    return False