def sum_of_digits(input_collection):
    current_overall_sum = 0
    # Iterate over each item in the input collection.
    for current_item in input_collection:
        # Check if the current item is an integer.
        if isinstance(current_item, int):
            # Convert the number to its absolute value to allow handling negative numeric values.
            abs_numeric_value = abs(current_item)
            # Convert the absolute numeric value to a string to access individual unit digits.
            numeric_value_in_string = str(abs_numeric_value)
            # Iterate through each character (digit) in the numeric string.
            for unit_digit_char in numeric_value_in_string:
                # Convert the digit character back to an integer and add to the overall sum.
                current_overall_sum += int(unit_digit_char)
        # Check if the current item is a list.
        elif isinstance(current_item, list):
            # If it's a list, recursively call this function to sum digits within the nested list.
            current_overall_sum += sum_of_digits(current_item)
        # If the item is neither an integer nor a list (e.g., a string), it is implicitly ignored.
    return current_overall_sum