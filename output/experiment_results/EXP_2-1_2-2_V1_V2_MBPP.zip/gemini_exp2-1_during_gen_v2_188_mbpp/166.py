def find_even_pair(input_values):
    odd_count = 0
    via_two_count = 0  # Counts numbers yielding zero modulo two

    for current_numeric_value in input_values:
        if current_numeric_value % 2 == 0:
            via_two_count += 1
        else:
            odd_count += 1

    # A pair of numbers (A, B) will have an even XOR sum if:
    # 1. Both A and B are even (Even ^ Even = Even)
    # 2. Both A and B are odd (Odd ^ Odd = Even)
    
    # Calculate combinations of via_two_count numbers (nC2)
    via_two_pairs_count = via_two_count * (via_two_count - 1) // 2
    
    # Calculate combinations of odd_count numbers (nC2)
    odd_pairs_count = odd_count * (odd_count - 1) // 2
    
    # Summing up valid pairs from both categories.
    sum_valid_pairs = via_two_pairs_count + odd_pairs_count
    
    return sum_valid_pairs