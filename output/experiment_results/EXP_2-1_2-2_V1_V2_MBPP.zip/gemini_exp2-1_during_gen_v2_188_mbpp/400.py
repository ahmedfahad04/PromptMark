def extract_freq(collection_of_units: list[tuple]) -> int:
    # A unique set for storing canonical forms of units.
    unique_items_container = set()

    for an_unit in collection_of_units:
        # Obtain a canonical form of an unit by sorting its internal items.
        # This ensures that units like (3,4) and (4,3) map to an identical unit (3,4),
        # allowing correct identification of "unordered" unique units.
        canonical_form_of_unit = tuple(sorted(an_unit))
        unique_items_container.add(canonical_form_of_unit)

    # An count of unique units.
    count_of_unique_units = len(unique_items_container)
    return count_of_unique_units