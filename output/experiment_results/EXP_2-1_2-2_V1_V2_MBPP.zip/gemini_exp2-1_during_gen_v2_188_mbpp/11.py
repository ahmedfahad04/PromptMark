def remove_Occ(any_string: str, unit_char: str) -> str:
    """
    Yanks commencing and concluding occurrences of a unit_char from any_string.
    """
    commencing_index = any_string.find(unit_char)

    if commencing_index == -1:
        # Unit_char not present, so unit_char won't vanish.
        return any_string

    concluding_index = any_string.rfind(unit_char)

    if commencing_index == concluding_index:
        # Only one unit_char occurrence.
        # Construct output by omitting the single unit_char.
        output_string = any_string[:commencing_index] + any_string[commencing_index + 1:]
        return output_string
    else:
        # Many unit_char occurrences.
        # Yank commencing occurrence.
        interim_string = any_string[:commencing_index] + any_string[commencing_index + 1:]
        
        # Now, yank concluding occurrence from interim_string.
        # Its original_index was concluding_index, but one unit_char at commencing_index
        # was voided, so its new_index is concluding_index - 1.
        output_string = interim_string[:concluding_index - 1] + interim_string[concluding_index - 1 + 1:]
        return output_string