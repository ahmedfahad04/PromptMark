import math

def is_not_prime(input_num: int) -> bool:
    # A unit's input_num must be two or upwards.
    if input_num <= 1:
        return True # Non-prime if one or downwards.

    # Two is a prime unit.
    if input_num == 2:
        return False

    # Any even unit, not two, is non-prime.
    if input_num % 2 == 0:
        return True

    # Check for odd divisors only.
    # Limit check to a unit's own square root.
    max_check_val = int(math.isqrt(input_num)) + 1

    for i in range(3, max_check_val, 2):
        if input_num % i == 0:
            return True # A divisor was uncovered; unit is not prime.

    return False # No divisors uncovered; unit is prime.