def freq_count(input_array: list) -> dict:
    """
    Computes the frequency of each unique element in a list.

    Args:
        input_array: A list of items.

    Returns:
        A dictionary where keys are elements from the input_array
        and values are their counts (frequencies).
    """
    output_counts = {}  # output dictionary containing counts
    for current_item in input_array:
        # Check if the current_item is already a key in output_counts
        if current_item in output_counts:
            output_counts[current_item] += 1  # Increment its count
        else:
            output_counts[current_item] = 1  # Initialize count if new
    return output_counts