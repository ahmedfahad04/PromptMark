def min_val(in_collection):
    # Initializes minimum numeric value.
    min_numeric_val = None

    # Walks over units in the collection.
    for current_unit in in_collection:
        # Confirms if current unit is a numeric unit.
        # Avoids string comparison issues.
        if isinstance(current_unit, (int, float)):
            # If min_numeric_val is None (a new numeric unit encountered)
            # or if current_unit is smaller, updates min_numeric_val.
            if min_numeric_val is None or current_unit < min_numeric_val:
                min_numeric_val = current_unit

    # Outputs the smallest numeric value.
    return min_numeric_val