def split_list(input_list, interval):
    """
    Splits the input list into sublists every nth element based on the provided interval.
    
    :param input_list: The list to be split.
    :param interval: The interval at which to split the list.
    :return: A list of sublists where each sublist contains elements from the original list spaced by the interval.
    """
    result = []
    current_sublist = []
    index = 0
    
    # Iterate through the input list
    for item in input_list:
        current_sublist.append(item)
        index += 1
        if index % interval == 0:
            result.append(current_sublist)
            current_sublist = []
            
    # Append any remaining items
    if current_sublist:
        result.append(current_sublist)
        
    return result

# Test cases
assert split_list(['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n'], 3) == [['a', 'd', 'g', 'j', 'm'], ['b', 'e', 'h', 'k', 'n'], ['c', 'f', 'i', 'l']]
assert split_list([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14], 3) == [[1, 4, 7, 10, 13], [2, 5, 8, 11, 14], [3, 6, 9, 12]]
assert split_list(['python', 'java', 'C', 'C++', 'DBMS', 'SQL'], 2) == [['python', 'C', 'DBMS'], ['java', 'C++', 'SQL']]