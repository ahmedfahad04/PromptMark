def calculate_quotient(dividend, divisor):
    """
    Calculate the quotient of two numbers (dividend and divisor) and round it down to the nearest integer.
    
    :param dividend: The number to be divided.
    :param divisor: The number by which to divide.
    :return: The quotient rounded down to the nearest integer.
    """
    return dividend // divisor

# Test cases
assert calculate_quotient(10, 3) == 3
assert calculate_quotient(4, 2) == 2
assert calculate_quotient(20, 5) == 4