def rear_extract(tuples_list):
    # Initialize an empty list to store the last elements
    result = []
    
    # Iterate through each tuple in the input list
    for current_tuple in tuples_list:
        # Append the last element of the current tuple to the result list
        result.append(current_tuple[-1])
    
    # Return the final list containing the last elements of each tuple
    return result

# Test cases to verify the correctness of the function
assert rear_extract([(1, 'Rash', 21), (2, 'Varsha', 20), (3, 'Kil', 19)]) == [21, 20, 19]
assert rear_extract([(1, 'Sai', 36), (2, 'Ayesha', 25), (3, 'Salman', 45)]) == [36, 25, 45]
assert rear_extract([(1, 'Sudeep', 14), (2, 'Vandana', 36), (3, 'Dawood', 56)]) == [14, 36, 56]

# Explanation: The original code was missing the definition of the function `rear_extract`. By defining the function and using negative indexing to extract the last element of each tuple, we ensure that the function works as intended. The test cases confirm that the function passes all provided assertions.