def calculate_third_side(adjacent, opposite):
    """
    Calculate the length of the third side (hypotenuse) of a right-angled triangle
    given the lengths of the other two sides.
    
    Parameters:
    adjacent (float): Length of the side adjacent to the right angle.
    opposite (float): Length of the side opposite to the right angle.
    
    Returns:
    float: Length of the hypotenuse.
    """
    import math
    hypotenuse = math.sqrt(adjacent**2 + opposite**2)
    return round(hypotenuse, 10)

# Test cases
assert calculate_third_side(7, 8) == 10.63014581273465
assert calculate_third_side(3, 4) == 5
assert calculate_third_side(7, 15) == 16.55294535724685