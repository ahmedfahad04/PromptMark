def add_before_each(input_list, element):
    # Initialize an empty list to store the result
    result = []
    
    # Iterate through each item in the input list
    for item in input_list:
        # Append the specified element before the current item
        result.append(element)
        result.append(item)
        
    return result

# Test cases to verify the correctness of the function
assert add_before_each(['Red', 'Green', 'Black'], 'c') == ['c', 'Red', 'c', 'Green', 'c', 'Black']
assert add_before_each(['python', 'java'], 'program') == ['program', 'python', 'program', 'java']
assert add_before_each(['happy', 'sad'], 'laugh') == ['laugh', 'happy', 'laugh', 'sad']