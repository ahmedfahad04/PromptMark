def extract_singly(data):
    # Initialize an empty set to store the flattened elements
    result_set = set()
    
    # Iterate through each sublist in the input data
    for sub_list in data:
        # Iterate through each element in the current sublist
        for item in sub_list:
            # Add the element to the result set
            result_set.add(item)
    
    return result_set

# Explanation: The function iterates through each sublist and then through each element within those sublists,
# adding them to a set which automatically handles duplicates. This ensures all unique elements are collected.
# Since sets inherently contain unique elements, the final result is guaranteed to be a set of unique values.