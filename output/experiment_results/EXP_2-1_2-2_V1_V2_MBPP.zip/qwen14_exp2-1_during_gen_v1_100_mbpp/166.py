def count_even_xor_pairs(numbers):
    # Initialize counters for even and odd numbers
    even_count = 0
    odd_count = 0
    
    # Count the number of even and odd numbers in the list
    for num in numbers:
        if num % 2 == 0:
            even_count += 1
        else:
            odd_count += 1
    
    # Calculate the number of valid pairs
    # Pairs with two even numbers or two odd numbers will have an even XOR result
    return (even_count * (even_count - 1)) // 2 + (odd_count * (odd_count - 1)) // 2

# Rename the function to match the required name
find_even_pair = count_even_xor_pairs

# Test cases
assert find_even_pair([5, 4, 7, 2, 1]) == 4
assert find_even_pair([7, 2, 8, 1, 0, 5, 11]) == 9
assert find_even_pair([1, 2, 3]) == 1