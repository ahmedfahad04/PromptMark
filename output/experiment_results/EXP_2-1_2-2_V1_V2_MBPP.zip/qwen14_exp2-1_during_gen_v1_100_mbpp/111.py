def find_common_elements(nested_lists):
    # Initialize the result set with all elements from the first list
    common_elements = set(nested_lists[0])
    
    # Iterate through each sublist starting from the second one
    for lst in nested_lists[1:]:
        # Update the common_elements set by retaining only those present in current list
        common_elements.intersection_update(lst)
        
    return common_elements

# Test cases
assert set(find_common_elements([[12, 18, 23, 25, 45], [7, 12, 18, 24, 28], [1, 5, 8, 12, 15, 16, 18]])) == set([18, 12])
assert set(find_common_elements([[12, 5, 23, 25, 45], [7, 11, 5, 23, 28], [1, 5, 8, 18, 23, 16]])) == set([5, 23])
assert set(find_common_elements([[2, 3, 4, 1], [4, 5], [6, 4, 8], [4, 5], [6, 8, 4]])) == set([4])