def calculate_subarray_sum(numbers, start_index, end_index):
    # Initialize total to store the sum of the subarray
    total = 0
    
    # Iterate through the specified range and add each element to total
    for i in range(start_index, end_index + 1):
        total += numbers[i]
    
    return total

# Test cases to verify the correctness of the function
assert calculate_subarray_sum([2,1,5,6,8,3,4,9,10,11,8,12], 8, 10) == 29
assert calculate_subarray_sum([2,1,5,6,8,3,4,9,10,11,8,12], 5, 7) == 16
assert calculate_subarray_sum([2,1,5,6,8,3,4,9,10,11,8,12], 7, 10) == 38