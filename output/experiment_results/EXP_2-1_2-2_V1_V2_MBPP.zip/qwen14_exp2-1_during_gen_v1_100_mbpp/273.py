def substract_elements(a, b):
    # Initialize an empty list to store the result
    result = []
    
    # Iterate through the elements of both tuples simultaneously
    for i in range(len(a)):
        # Subtract the corresponding elements and append the result to the list
        result.append(a[i] - b[i])
    
    return tuple(result)

# Test cases to verify the correctness of the function
assert substract_elements((10, 4, 5), (2, 5, 18)) == (8, -1, -13)
assert substract_elements((11, 2, 3), (24, 45, 16)) == (-13, -43, -13)
assert substract_elements((7, 18, 9), (10, 11, 12)) == (-3, 7, -3)