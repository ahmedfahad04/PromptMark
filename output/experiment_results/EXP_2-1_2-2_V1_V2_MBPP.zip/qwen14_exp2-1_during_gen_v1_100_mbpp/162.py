def sum_series(n):
    # Initialize the result variable with the value of n
    current_sum = n
    
    # Loop until the current value becomes less than or equal to 0
    while n > 0:
        # Subtract 2 from n each iteration and add the new value to the current sum
        current_sum += n
        n -= 2
    
    return current_sum

# Test the function with provided test cases
assert sum_series(6) == 12
assert sum_series(10) == 30
assert sum_series(9) == 25