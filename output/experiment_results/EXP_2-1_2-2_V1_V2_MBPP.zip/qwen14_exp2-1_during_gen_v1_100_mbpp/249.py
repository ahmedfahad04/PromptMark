def intersection_array(arr1, arr2):
    # Convert both arrays to sets to remove duplicates and allow for set operations
    set1 = set(arr1)
    set2 = set(arr2)
    
    # Find the intersection of the two sets
    common_elements = set1.intersection(set2)
    
    # Convert the resulting set back to a sorted list
    result = sorted(list(common_elements))
    
    return result

# Test cases
assert intersection_array([1, 2, 3, 5, 7, 8, 9, 10], [1, 2, 4, 8, 9]) == [1, 2, 8, 9]
assert intersection_array([1, 2, 3, 5, 7, 8, 9, 10], [3, 5, 7, 9]) == [3, 5, 7, 9]
assert intersection_array([1, 2, 3, 5, 7, 8, 9, 10], [10, 20, 30, 40]) == [10]