def clean_string(source_str, filter_str):
    # Initialize an empty list to store characters that are not in filter_str
    cleaned_list = []
    
    # Iterate through each character in source_str
    for char in source_str:
        # Check if the character is not in filter_str
        if char not in filter_str:
            # Append the character to cleaned_list if it's not in filter_str
            cleaned_list.append(char)
    
    # Join the list into a string and return it
    cleaned_str = ''.join(cleaned_list)
    return cleaned_str

# Test cases
assert clean_string("probasscurve", "pros") == 'bacuve'
assert clean_string("digitalindia", "talent") == 'digiidi'
assert clean_string("exoticmiles", "toxic") == 'emles'