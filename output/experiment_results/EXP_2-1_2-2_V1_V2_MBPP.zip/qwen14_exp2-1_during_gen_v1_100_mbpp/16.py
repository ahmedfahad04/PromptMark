def check_text_lowercase_underscore(input_str):
    # Check if the first character is lowercase letter
    if not input_str[0].islower():
        return False
    
    # Iterate through each character in the string
    for index in range(len(input_str)):
        char = input_str[index]
        
        # Check if the character is not a lowercase letter or an underscore
        if not char.islower() and char != '_':
            return False
        
        # Check if the character before an underscore is not lowercase
        if char == '_' and (index - 1 >= 0 and not input_str[index - 1].islower()):
            return False
    
    return True

# Test cases
assert check_text_lowercase_underscore("aab_cbbbc") == True
assert check_text_lowercase_underscore("aab_Abbbc") == False
assert check_text_lowercase_underscore("Aaab_abbbc") == False