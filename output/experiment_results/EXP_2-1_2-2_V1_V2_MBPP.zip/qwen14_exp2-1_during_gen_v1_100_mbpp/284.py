def check_element(items, target):
    # Initialize a counter to keep track of matching elements
    count = 0
    
    # Iterate through each item in the list
    for item in items:
        # Increment the counter if the current item matches the target
        if item == target:
            count += 1
            
    # Check if all items match the target by comparing the counter with the length of the list
    return count == len(items)

# Explanation: The function iterates through each item in the input list and counts how many items match the target element.
# If the count equals the length of the list, it means every item in the list is equal to the target, hence returns True.
# Otherwise, it returns False. This approach ensures the function works correctly for any list and target value provided.