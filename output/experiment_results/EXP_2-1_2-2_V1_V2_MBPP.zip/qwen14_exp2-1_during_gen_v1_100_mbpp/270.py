def sum_even_and_even_index(numbers):
    # Initialize total sum to zero
    total = 0
    
    # Iterate through the list using index
    for index in range(0, len(numbers), 2):
        # Check if the number at the current even index is even
        if numbers[index] % 2 == 0:
            # Add the even number to the total sum
            total += numbers[index]
    
    # Return the final sum
    return total

# Test cases to verify the correctness of the function
assert sum_even_and_even_index([5, 6, 12, 1, 18, 8]) == 30
assert sum_even_and_even_index([3, 20, 17, 9, 2, 10, 18, 13, 6, 18]) == 26
assert sum_even_and_even_index([5, 6, 12, 1]) == 12