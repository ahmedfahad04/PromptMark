def square_Sum(n):
    # Initialize total_sum to store the sum of squares
    total_sum = 0
    
    # Loop through the first n odd numbers
    current_odd = 1
    for _ in range(n):
        # Square the current odd number and add it to total_sum
        total_sum += current_odd ** 2
        # Move to the next odd number
        current_odd += 2
    
    return total_sum

# Test cases
assert square_Sum(2) == 10
assert square_Sum(3) == 35
assert square_Sum(4) == 84