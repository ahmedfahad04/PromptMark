def calculate_perimeter_pentagon(side_length):
    # Calculate the perimeter of a regular pentagon by multiplying the side length by 5
    return side_length * 5

# Test cases to verify the correctness of the function
assert calculate_perimeter_pentagon(5) == 25
assert calculate_perimeter_pentagon(10) == 50
assert calculate_perimeter_pentagon(15) == 75