def gcd(a, b):
    """Compute the greatest common divisor of a and b."""
    while b != 0:
        a, b = b, a % b
    return a

def extended_gcd(a, b):
    """Find coefficients x and y such that ax + by = gcd(a, b)."""
    if a == 0:
        return b, 0, 1
    else:
        g, x, y = extended_gcd(b % a, a)
        return g, y - (b // a) * x, x

def find_solution(a, b, n):
    """
    Find integers x and y that satisfy ax + by = n.
    
    Returns:
        A tuple (x, y) if a solution exists, otherwise None.
    """
    # Compute the GCD of a and b
    d = gcd(a, b)
    
    # Check if n is divisible by the GCD
    if n % d != 0:
        return None
    
    # Solve the equation using the Extended Euclidean Algorithm
    _, x, y = extended_gcd(a, b)
    
    # Scale the solution to match the required value of n
    x *= n // d
    y *= n // d
    
    return (x, y)

# Test cases
assert find_solution(2, 3, 7) == (2, 1)
assert find_solution(4, 2, 7) == None
assert find_solution(1, 13, 17) == (17, 0)