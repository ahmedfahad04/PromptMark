def all_dicts_empty(dicts_list):
    """
    Check if all dictionaries in the provided list are empty.
    
    Args:
    dicts_list (list): A list of dictionaries to be checked.
    
    Returns:
    bool: True if all dictionaries are empty, False otherwise.
    """
    for dictionary in dicts_list:
        if dictionary:  # Check if the dictionary is not empty
            return False
    return True

# Test cases
assert all_dicts_empty([{}, {}, {}]) == True
assert all_dicts_empty([{1, 2}, {}, {}]) == False
assert all_dicts_empty({}) == True