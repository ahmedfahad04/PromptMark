def count_occurrences(tup, elem):
    # Initialize a counter to keep track of occurrences
    occurrence_count = 0
    
    # Iterate through each item in the tuple
    for item in tup:
        # Check if the current item matches the specified element
        if item == elem:
            # Increment the counter if there's a match
            occurrence_count += 1
            
    # Return the final count of occurrences
    return occurrence_count

# Test cases to verify the correctness of the function
assert count_occurrences((10, 8, 5, 2, 10, 15, 10, 8, 5, 8, 8, 2), 4) == 0
assert count_occurrences((10, 8, 5, 2, 10, 15, 10, 8, 5, 8, 8, 2), 10) == 3
assert count_occurrences((10, 8, 5, 2, 10, 15, 10, 8, 5, 8, 8, 2), 8) == 4