def calculate_even_power_sum(n):
    """
    Calculate the sum of the first n even natural numbers raised to the fifth power.
    
    Args:
    n (int): The number of initial even natural numbers to consider.
    
    Returns:
    int: The sum of the first n even natural numbers each raised to the fifth power.
    """
    total_sum = 0
    current_even_number = 2
    
    for _ in range(n):
        total_sum += current_even_number ** 5
        current_even_number += 2
    
    return total_sum

# Test cases
assert calculate_even_power_sum(2) == 1056
assert calculate_even_power_sum(3) == 8832
assert calculate_even_power_sum(1) == 32