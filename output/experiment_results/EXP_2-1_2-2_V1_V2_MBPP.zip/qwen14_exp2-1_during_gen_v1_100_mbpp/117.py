def convert_to_float(data):
    # Iterate through each sublist in the main list
    result = []
    for items in data:
        # Initialize an empty tuple to store converted float values
        converted_items = ()
        for item in items:
            try:
                # Attempt to convert the string to a float
                value = float(item)
            except ValueError:
                # If conversion fails, keep the original string
                value = item
            # Append the converted or original value to the tuple
            converted_items += (value,)
        # Append the converted tuple to the result list
        result.append(converted_items)
    return result

# Explanation: The function iterates through each sublist and attempts to convert each element to a float.
# If the conversion fails due to a ValueError, the original string is kept. This ensures that all convertible elements
# are correctly converted while non-convertible ones remain unchanged. The function returns the modified list of tuples.