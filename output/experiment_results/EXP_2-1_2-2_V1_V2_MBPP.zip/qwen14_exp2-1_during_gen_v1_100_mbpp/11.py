def remove_Occ(input_str, char_to_strip):
    # Find the index of the first occurrence of the character
    first_index = input_str.find(char_to_strip)
    
    # Find the index of the last occurrence of the character
    last_index = input_str.rfind(char_to_strip)
    
    # Check if the character exists in the string
    if first_index != -1 and last_index != -1:
        # Remove the first occurrence
        modified_str = input_str[:first_index] + input_str[first_index+1:last_index] + input_str[last_index+1:]
    else:
        # Handle the case where the character is not found or appears only once
        modified_str = input_str
    
    return modified_str

# Test cases
assert remove_Occ("hello", "l") == "heo"
assert remove_Occ("abcda", "a") == "bcd"
assert remove_Occ("PHP", "P") == "H"
assert remove_Occ("test", "z") == "test"  # Character not present
assert remove_Occ("a", "a") == ""         # Single occurrence