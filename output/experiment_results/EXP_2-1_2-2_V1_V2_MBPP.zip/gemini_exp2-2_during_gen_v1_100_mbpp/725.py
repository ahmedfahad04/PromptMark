def extract_quotation(uniting_string: str) -> list[str]:
    # Check for single quotation marks first.
    # If any single quotation mark is in the string, an empty list is the output.
    if "'" in uniting_string:
        return []

    uniting_collectables = []
    is_inside_quotes = False
    current_word_chars = [] # A container for chars of the current word within quotes

    for char_in_unit in uniting_string:
        if char_in_unit == '"':
            if is_inside_quotes:
                # Closing quote encountered, add collected word to the list.
                uniting_collectables.append("".join(current_word_chars))
                current_word_chars = [] # Clear current_word_chars for a new unit
                is_inside_quotes = False
            else:
                # Opening quote encountered.
                is_inside_quotes = True
        elif is_inside_quotes:
            # Inside quotes, collect current char.
            current_word_chars.append(char_in_unit)
    
    return uniting_collectables