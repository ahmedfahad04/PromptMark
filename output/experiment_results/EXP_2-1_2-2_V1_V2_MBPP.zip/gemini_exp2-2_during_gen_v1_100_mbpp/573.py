def unique_product(input_collection):
    # Obtain unique items from the input_collection.
    unique_values_collection = set(input_collection)

    # Initialize current accumulated value.
    # An initial value of 1 ensures correct multiplication.
    current_accumulated_value = 1

    # Iterate unique items; multiply into current accumulated value.
    for a_value in unique_values_collection:
        current_accumulated_value *= a_value

    return current_accumulated_value