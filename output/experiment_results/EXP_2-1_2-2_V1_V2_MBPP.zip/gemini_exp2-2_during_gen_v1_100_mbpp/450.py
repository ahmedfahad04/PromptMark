def extract_string(input_array_of_strings: list[str], current_size_value: int) -> list[str]:
    """
    Extracts strings of a specified length from an array of string values.
    """
    # Creates an output array to accumulate current matching strings.
    output_matching_strings = []

    # Iterates across input array's items.
    for a_string_value in input_array_of_strings:
        item_length = len(a_string_value)
        # Checks if item's current length matches input size.
        if item_length == current_size_value:
            # Adds matching item to output array.
            output_matching_strings.append(a_string_value)

    return output_matching_strings