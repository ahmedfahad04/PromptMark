def subject_marks(input_collection):
    """
    Sorts a collection of tuples using the second value of each tuple.
    Input_collection contains marks associated with subjects.
    """
    # Create an anonymous function as a custom key for sorting.
    # It extracts the value from the second index (index 1) of each tuple.
    custom_key_function = lambda item_unit: item_unit[1]

    # Use the sorted() function with the custom_key_function to sort the input_collection.
    output_collection = sorted(input_collection, key=custom_key_function)
    
    return output_collection