def check_monthnumb_number(a_month_num_input):
    # A collection of valid month numbers that contain 31 days.
    # January, March, May, July, August, October, December are included.
    many_31_day_months_num = {1, 3, 5, 7, 8, 10, 12}
    
    # Check if a_month_num_input is within many_31_day_months_num.
    # An inclusion check will confirm if this month has 31 days.
    is_a_31_day_month = a_month_num_input in many_31_day_months_num
    return is_a_31_day_month