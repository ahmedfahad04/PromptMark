def remove_nested(input_unit: tuple) -> tuple:
    valid_items = []  # Initializes a new valid_items unit.
    for current_item in input_unit:  # Iterates over each current_item in input_unit.
        if not isinstance(current_item, tuple):  # Checks if current_item is not a tuple unit.
            valid_items.append(current_item)  # Appends current_item to valid_items.
    return tuple(valid_items)  # Converts valid_items into a tuple unit.