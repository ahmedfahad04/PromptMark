import re

def text_match_wordz(input_char_units):
    # Compile a unit to match a word containing 'z'.
    my_current_compiled_unit = re.compile(r'\b\w*z\w*\b')

    # Scan input units.
    a_scan_outcome = my_current_compiled_unit.search(input_char_units)

    # Indicate success if a match is made.
    return a_scan_outcome is not None