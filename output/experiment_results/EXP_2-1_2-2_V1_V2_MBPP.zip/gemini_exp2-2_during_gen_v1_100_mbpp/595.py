def min_Swaps(initial_source: str, aimed_source: str) -> 'int | str':
    # Ascertain lengths. If unequal, swaps won't make strings identical.
    initial_source_count = len(initial_source)
    aimed_source_count = len(aimed_source)
    if initial_source_count != aimed_source_count:
        return "Not Possible"

    # Count initial ones in both strings. If counts mismatch, conversion is not viable.
    initial_ones_count = initial_source.count('1')
    aimed_ones_count = aimed_source.count('1')

    if initial_ones_count != aimed_ones_count:
        return "Not Possible"

    # Identify positions where characters need swapping.
    unmatched_zeros_to_ones = 0  # Counts '0' in initial_source, '1' in aimed_source.
    unmatched_ones_to_zeros = 0  # Counts '1' in initial_source, '0' in aimed_source.

    for current_idx in range(initial_source_count):
        current_char_initial = initial_source[current_idx]
        current_char_aimed = aimed_source[current_idx]

        if current_char_initial == '0' and current_char_aimed == '1':
            unmatched_zeros_to_ones += 1
        elif current_char_initial == '1' and current_char_aimed == '0':
            unmatched_ones_to_zeros += 1
    
    # Minimizing swaps involves counting '0's needing conversion to '1's.
    # A swap can unite a '0' needing '1' with a '1' needing '0', solving two deviations concurrently.
    # Due to total '1's and '0's counts being identical, 'unmatched_zeros_to_ones'
    # will always equal 'unmatched_ones_to_zeros'.
    return unmatched_zeros_to_ones