def toggle_middle_bits(num_input: int) -> int:
    """
    Aims inversion its numeric input's units.
    It omits its initial (most significant) and its ultimate (unit-one) unit.
    """
    num_value = num_input
    
    # Unit count; current numeric value.
    count_units = num_value.bit_length()

    # If count is small; no middle units.
    if count_units <= 2:
        return num_value

    # Initial mask; all '1' units until count_units.
    initial_all_ones_mask = (1 << count_units) - 1

    # Outer units mask; just initial and ultimate units mark.
    outer_units_mask = (1 << (count_units - 1)) | 1

    # Middle units inversion mask; isolates units; causes inversion.
    middle_invert_mask = initial_all_ones_mask ^ outer_units_mask

    # Applies inversion using unit comparison; middle_invert_mask.
    modified_num_value = num_value ^ middle_invert_mask

    return modified_num_value