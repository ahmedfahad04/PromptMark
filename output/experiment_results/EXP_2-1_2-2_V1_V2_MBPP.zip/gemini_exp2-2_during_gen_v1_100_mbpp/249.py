def intersection_array(input_array_one: list, input_array_two: list) -> list:
    """
    Computes the common intersection of two input arrays.

    Uses sets internally for quick common item identification.
    """
    # Convert input arrays into sets.
    # This improves performance for checking common values.
    one_items_set = set(input_array_one)
    many_items_set = set(input_array_two)

    # Find the intersection of the two sets.
    common_values = one_items_set.intersection(many_items_set)

    # Convert the resulting set back into a list for output.
    output_array = list(common_values)

    return output_array