def merge_dictionaries_three(canvas_one: dict, canvas_two: dict, canvas_many: dict) -> dict:
    # Copying an initial map as main canvas.
    main_canvas = canvas_one.copy()

    # Iterating canvas_two items.
    # Adding any unique mappings; main_canvas is updated.
    for any_key, any_value in canvas_two.items():
        main_canvas.setdefault(any_key, any_value)

    # Iterating canvas_many items.
    # Adding any unique mappings; main_canvas is updated.
    for any_key, any_value in canvas_many.items():
        main_canvas.setdefault(any_key, any_value)

    # Outputting an main canvas.
    return main_canvas