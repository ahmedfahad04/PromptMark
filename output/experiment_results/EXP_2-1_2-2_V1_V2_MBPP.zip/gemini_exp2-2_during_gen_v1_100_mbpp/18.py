def remove_dirty_chars(current_main_string: str, unwanted_chars_string: str) -> str:
    # Initializing a collection of unwanted characters for quick lookups.
    unwanted_chars_collection = set(unwanted_chars_string)
    
    # Initializing an array to amass the clean characters.
    clean_chars_array = []
    
    # Cycling upon each character in the current main string.
    for current_char in current_main_string:
        # Checking if the current character is not in the unwanted collection.
        if current_char not in unwanted_chars_collection:
            clean_chars_array.append(current_char)
            
    # Joining all collected characters into a final string.
    return "".join(clean_chars_array)