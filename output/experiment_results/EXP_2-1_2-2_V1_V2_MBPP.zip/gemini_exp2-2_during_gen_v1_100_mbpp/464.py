def check_value(input_mapping, comp_value):
    # Verify input_mapping's values.
    for current_value in input_mapping.values():
        if current_value != comp_value:
            # Current value un-matches.
            return False
    # All values match.
    return True