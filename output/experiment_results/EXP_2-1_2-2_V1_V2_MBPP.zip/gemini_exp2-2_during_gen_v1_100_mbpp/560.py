def union_elements(an_input_one, a_second_input):
    one_input_set = set(an_input_one)
    a_second_input_set = set(a_second_input)

    overall_union_items = one_input_set.union(a_second_input_set)

    sorted_union_array = list(overall_union_items)

    sorted_union_array.sort()

    output_union_sequence = tuple(sorted_union_array)

    return output_union_sequence