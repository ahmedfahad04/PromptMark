def count_Substrings(input_string: str) -> int:
    """
    Counts substrings where the sum of their digits equals their length.
    """
    num_chars = len(input_string)
    count_instances = 0

    for i in range(num_chars):
        current_sum_values = 0
        for j in range(i, num_chars):
            current_sum_values += int(input_string[j])
            current_unit_count = j - i + 1

            if current_sum_values == current_unit_count:
                count_instances += 1

    return count_instances