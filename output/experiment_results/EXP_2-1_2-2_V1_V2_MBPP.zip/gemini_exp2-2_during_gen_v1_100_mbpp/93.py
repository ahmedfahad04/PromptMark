def power(input_value_a, count_multiplications_u):
    # Initializes an accumulated value with 1.
    current_accumulated_value_c = 1
    # Iterates for the specified count of multiplications.
    for iteration_index_i in range(count_multiplications_u):
        # Multiplies the input value into the current accumulated value.
        current_accumulated_value_c *= input_value_a
    return current_accumulated_value_c