def rectangle_area(a_width_unit, a_current_measure):
    # Calculates an area of a current rectangle.
    an_area_calc = a_width_unit * a_current_measure
    # Outputs an area.
    return an_area_calc