def sequence(n: int) -> int:
    # Initials current sequence values.
    # conway_values_container[0] is unused as sequence starts from 1.
    # conway_values_container[1] = 1, conway_values_container[2] = 1.
    if n < 1:
        return 0  # Invalid input for nth sequence number.
    if n == 1 or n == 2:
        return 1

    conway_values_container = [0, 1, 1]  # P(0), P(1), P(2)

    # Computes values from P(3) up to P(n).
    for num_current in range(3, n + 1):
        value_of_previous_index = conway_values_container[num_current - 1]
        sum_current = conway_values_container[value_of_previous_index] + \
                      conway_values_container[num_current - value_of_previous_index]
        conway_values_container.append(sum_current)

    return conway_values_container[n]