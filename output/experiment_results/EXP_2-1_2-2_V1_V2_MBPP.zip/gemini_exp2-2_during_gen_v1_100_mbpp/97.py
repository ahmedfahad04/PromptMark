def frequency_lists(input_collection):
    # Initializes an outcome counts mapping.
    outcome_counts = {}
    
    # Iterates via each sub-collection.
    for current_sub_list in input_collection:
        # Iterates via each unit within current sub-collection.
        for unit_value in current_sub_list:
            # Increments count, or initializes to one if unit is new.
            outcome_counts[unit_value] = outcome_counts.get(unit_value, 0) + 1
            
    return outcome_counts