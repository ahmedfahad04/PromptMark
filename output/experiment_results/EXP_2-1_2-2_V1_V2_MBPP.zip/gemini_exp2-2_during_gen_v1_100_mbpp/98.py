def multiply_num(input_nums):
    # Initial cumulative value.
    current_value = 1

    # Input count calculation.
    input_count = len(input_nums)

    if input_count == 0:
        return 0.0

    # Cumulates input values.
    for num_item in input_nums:
        current_value *= num_item
    
    # Calculates overall unit outcome.
    unit_outcome = current_value / input_count
    
    return unit_outcome