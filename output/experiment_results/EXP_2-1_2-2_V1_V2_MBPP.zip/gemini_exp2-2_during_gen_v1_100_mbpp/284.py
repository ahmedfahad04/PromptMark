def check_element(input_items: list, known_item: any) -> bool:
    # A unit on iteration.
    for current_item_value in input_items:
        # A unit is not matching.
        if current_item_value != known_item:
            return False
    # All units confirm.
    return True