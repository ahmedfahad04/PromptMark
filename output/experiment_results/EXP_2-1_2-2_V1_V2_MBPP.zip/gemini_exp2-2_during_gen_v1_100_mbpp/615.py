def average_tuple(main_collection: tuple) -> list:
    output_averages = []
    # Accumulates average values.
    for inner_unit in main_collection:
        unit_sum = sum(inner_unit)
        unit_count = len(inner_unit)
        current_average = unit_sum / unit_count
        output_averages.append(current_average)
    return output_averages