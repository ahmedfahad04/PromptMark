def extract_nth_element(a_collection_of_units: list[tuple], input_index: int) -> list:
    # Initializes an output collection to accumulate selected values.
    output_collection_values = [] 

    # Iterates current unit items from input collection.
    for current_unit_item in a_collection_of_units:
        # Confirms input_index is valid within current_unit_item.
        if input_index < len(current_unit_item):
            output_collection_values.append(current_unit_item[input_index])
    
    # Yields a new collection comprising selected values.
    return output_collection_values