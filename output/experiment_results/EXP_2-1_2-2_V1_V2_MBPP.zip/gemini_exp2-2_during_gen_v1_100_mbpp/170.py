def sum_range_list(initial_collection_of_nums: list[int], commencing_unit_index: int, culminating_unit_index: int) -> int:
    # Acknowledging current sum for accumulation.
    current_accumulated_sum = 0

    # Iterating across units within the specified range, inclusive of culminating_unit_index.
    for current_unit_index in range(commencing_unit_index, culminating_unit_index + 1):
        # Accumulating numeric unit value.
        current_accumulated_sum += initial_collection_of_nums[current_unit_index]

    # Unveiling the total cumulative sum.
    return current_accumulated_sum