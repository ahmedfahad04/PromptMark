def count_rotation(an_array: list) -> int:
    """
    Counts the number of circular moves needed for a sorted array.
    Assumes an array created via circular moves of a sorted array.
    """
    units_count = len(an_array)
    if units_count == 0:
        return 0

    # Checks units in an array.
    for i in range(1, units_count):
        # Checks if current unit is smaller comparing previous unit.
        # A check indicates an array's pivot.
        if an_array[i] < an_array[i - 1]:
            # An array's index of the pivot implies current rotation count.
            return i
    
    # All units are sorted, no array shifts arise.
    return 0