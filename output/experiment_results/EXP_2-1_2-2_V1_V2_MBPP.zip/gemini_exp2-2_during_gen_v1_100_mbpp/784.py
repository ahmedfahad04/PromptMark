def mul_even_odd(_nums_array_in: list) -> int:
    _initial_even_num = None
    _initial_odd_num = None

    for _current_num in _nums_array_in:
        # Check if current number is even and if initial even number is not yet assigned.
        if _current_num % 2 == 0:
            if _initial_even_num is None:
                _initial_even_num = _current_num
        # Current number is odd; check if initial odd number is not yet assigned.
        else:
            if _initial_odd_num is None:
                _initial_odd_num = _current_num

        # If we have found both initial even and odd numbers, we can stop iterating.
        if _initial_even_num is not None and _initial_odd_num is not None:
            break
    
    # Calculate and return the product of the first even and first odd numbers found.
    return _initial_even_num * _initial_odd_num