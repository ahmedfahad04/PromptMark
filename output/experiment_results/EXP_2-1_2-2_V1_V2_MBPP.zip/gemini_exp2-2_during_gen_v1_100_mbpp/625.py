def swap_List(input_collection):
    # Aims to interchange initial and concluding units of an input collection.
    current_count = len(input_collection) # Calculates current count of items.

    if current_count < 2:
        # Condition: input collection contains one or zero items.
        # Implies no swapping action is needed; yields current collection.
        return input_collection

    # Updates item at index 0 with concluding item, and concluding item with initial item.
    input_collection[0], input_collection[-1] = input_collection[-1], input_collection[0]

    return input_collection