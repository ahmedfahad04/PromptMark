def sum_series(n: int) -> int:
    # current accumulating sum value
    current_overall_sum: int = 0
    # max iteration index value
    max_idx_val: int = n // 2

    # current iteration index
    current_idx: int = 0
    while current_idx <= max_idx_val:
        # current item value
        current_item_val: int = n - 2 * current_idx
        current_overall_sum = current_overall_sum + current_item_val
        # increment current index value
        current_idx = current_idx + 1

    # overall sum value
    return current_overall_sum