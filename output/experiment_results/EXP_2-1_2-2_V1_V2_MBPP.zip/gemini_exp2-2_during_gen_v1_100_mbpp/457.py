def Find_Min(a_collection):
    # Initializing current minimum count and its associated component.
    if not a_collection:
        return []

    # Initializing current minimum count and its associated component.
    mini_count = len(a_collection[0])
    mini_component = a_collection[0]

    # Visiting an item in a collection.
    for an_item in a_collection:
        # Current item's count: new minimum?
        current_item_count = len(an_item)
        if current_item_count < mini_count:
            # Updating minimum count and component.
            mini_count = current_item_count
            mini_component = an_item

    return mini_component