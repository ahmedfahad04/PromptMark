def list_split(input_array, num_chunks):
    # Initializes an array of vacant arrays.
    all_units = [[] for _ in range(num_chunks)]

    # Iterates over input array with index and unit value.
    for current_idx, unit_val in enumerate(input_array):
        # Ascertains collection index using modulo current_idx.
        collection_idx = current_idx % num_chunks
        
        # Adds unit value into its current collection.
        all_units[collection_idx].append(unit_val)
    
    # Yields collection of all created arrays.
    return all_units