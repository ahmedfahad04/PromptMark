def max_multi_value(input_array_nums: list[int]) -> int:
    num_items = len(input_array_nums)
    if num_items == 0:
        return 0

    # current_max_multi_values_array[i_index] will contain the maximum multi-value of an
    # increasing subsequence ending with input_array_nums[i_index].
    # Initially, each item itself forms an increasing subsequence with its own value as the multi-value.
    current_max_multi_values_array = list(input_array_nums)

    # Iterate over array items, starting from the second unit.
    for i_index in range(1, num_items):
        # Consider all items before i_index.
        for j_index in range(i_index):
            # If the current item (input_array_nums[i_index]) is greater than a previous item
            # (input_array_nums[j_index]), it can extend an increasing subsequence.
            if input_array_nums[i_index] > input_array_nums[j_index]:
                # Calculate new multi-value if extended by multiplying the previous maximum
                # multi-value ending at j_index with the current item.
                current_unit_multi_value = current_max_multi_values_array[j_index] * input_array_nums[i_index]
                # Update maximum multi-value ending at i_index, choosing between its
                # current value (as a single item subsequence) or an extended one.
                current_max_multi_values_array[i_index] = max(current_max_multi_values_array[i_index], current_unit_multi_value)

    # The maximum value in current_max_multi_values_array is the overall max multi-value
    # among all increasing subsequences.
    overall_max_unit_multi_value = max(current_max_multi_values_array)

    return overall_max_unit_multi_value