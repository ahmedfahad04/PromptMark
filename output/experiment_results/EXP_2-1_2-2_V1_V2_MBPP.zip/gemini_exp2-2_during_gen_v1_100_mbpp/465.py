def vacuous_mapping_culler(a_source_mapping: dict) -> dict:
    """
    A function to acquire a new dictionary omitting vacuous (None) values.
    """
    a_current_clean_mapping = {}  # A mapping unit to amass valid entries.
    for a_key, a_value in a_source_mapping.items():
        if a_value is not None:  # A check: is a_value vacuous?
            a_current_clean_mapping[a_key] = a_value
    return a_current_clean_mapping