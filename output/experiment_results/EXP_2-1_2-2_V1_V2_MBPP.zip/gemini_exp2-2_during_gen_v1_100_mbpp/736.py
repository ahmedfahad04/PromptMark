def left_insertion(an_array: list, a_value: int) -> int:
    # A starting index for the search window.
    start_index = 0
    # A max index for the search window, initially array's full count.
    max_index = len(an_array)

    # Continue scanning while the current window is valid.
    while start_index < max_index:
        # Compute a central index within the current window.
        current_index = (start_index + max_index) // 2
        
        # If the array's value at current_index is smaller than a_value,
        # move the start_index past it.
        if an_array[current_index] < a_value:
            start_index = current_index + 1
        # If the array's value is greater than or equal to a_value,
        # narrow the max_index to current_index.
        else:
            max_index = current_index
    
    # The start_index now points to the appropriate insertion point.
    return start_index