def remove_whitespaces(input_string):
    # Creates a collection of strings using any whitespace as a separator.
    an_initial_chunks = input_string.split()
    # Joins all chunks into a single string without separators.
    a_combined_units = "".join(an_initial_chunks)
    return a_combined_units