def sum_even_and_even_index(input_array: list[int]) -> int:
    current_sum = 0
    num_items = len(input_array)
    for idx in range(num_items):
        # Verify index is even
        if idx % 2 == 0:
            current_num = input_array[idx]
            # Verify number is even
            if current_num % 2 == 0:
                current_sum += current_num
    return current_sum