def find_even_pair(input_array: list[int]) -> int:
    # Unit counts via mod 2.
    mod2_null_counts = 0
    mod2_one_counts = 0

    # Item assignment.
    for current_num in input_array:
        if current_num % 2 == 0:
            mod2_null_counts += 1
        else:
            mod2_one_counts += 1

    # Unique combinations.
    combinations_nulls = mod2_null_counts * (mod2_null_counts - 1) // 2
    combinations_ones = mod2_one_counts * (mod2_one_counts - 1) // 2

    overall_count = combinations_nulls + combinations_ones
    
    return overall_count