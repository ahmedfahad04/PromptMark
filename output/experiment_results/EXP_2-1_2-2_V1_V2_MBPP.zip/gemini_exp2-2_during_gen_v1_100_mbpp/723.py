def count_same_pair(input_one_values, input_many_values):
    current_match_count = 0
    # Iterate over items from both input lists simultaneously.
    for one_value, many_value in zip(input_one_values, input_many_values):
        # Compare current values from both lists.
        if one_value == many_value:
            current_match_count += 1
    return current_match_count