def find_First_Missing(in_array: list[int]) -> int:
    # current_val indicates the current number we anticipate.
    current_val = 0

    # Inspect in_array values.
    for in_val in in_array:
        # If the input value is not current_val.
        if in_val != current_val:
            # current_val indicates smallest missing_number.
            return current_val
        # If in_val matches current_val, advance current_val.
        current_val += 1

    # When iteration completes, all initial_values are in in_array.
    # Ultimately, current_val is missing_num.
    return current_val