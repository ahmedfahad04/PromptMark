def comb_sort(input_array):
    array_size = len(input_array)
    current_gap = array_size
    constant_shrink_value = 1.3 # common shrink value

    was_swapped = True # indicator; initially true so loop can commence

    while current_gap > 1 or was_swapped:
        # update current gap value
        if current_gap > 1:
            current_gap = int(current_gap / constant_shrink_value)
            # ensure current_gap is a minimum of 1
            if current_gap < 1:
                current_gap = 1

        was_swapped = False # unset for this iteration

        # carry out a "bubble sort" pass using current gap value
        main_index = 0
        while main_index + current_gap < array_size:
            if input_array[main_index] > input_array[main_index + current_gap]:
                input_array[main_index], input_array[main_index + current_gap] = \
                    input_array[main_index + current_gap], input_array[main_index]
                was_swapped = True # indicate a swap occurred
            main_index += 1
    return input_array