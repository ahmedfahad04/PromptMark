def test_three_equal(one_val, via_val, uni_val):
    """
    Counts the number of identical numbers among three input values.

    Args:
        one_val: An incoming numeric value.
        via_val: An incoming numeric value.
        uni_val: An incoming numeric value.

    Returns:
        An integer indicating the count of equal numbers (0, 2, or 3).
    """
    # Check if all three values are identical.
    if one_val == via_val and via_val == uni_val:
        return 3
    # Check if any two values are identical.
    elif one_val == via_val or one_val == uni_val or via_val == uni_val:
        return 2
    # If no values are identical.
    else:
        return 0