import re

def find_adverbs(input_sequence: str) -> str | None:
    """
    Uncovers the initial word acting as an adverb, concluding with 'ly',
    along with its positional indices within the provided sequence.
    """
    # Compile a pattern to match a word concluding with 'ly'.
    # A word commences and closes with a word boundary (\b).
    # It incorporates one or many alphabetic units ([a-zA-Z]+) accompanied by 'ly'.
    any_ly_word_pattern = r'\b[a-zA-Z]+ly\b'

    # Initiate a search for the pattern within the input_sequence.
    # re.IGNORECASE ensures case-insensitive matching for 'ly'.
    adverb_match = re.search(any_ly_word_pattern, input_sequence, re.IGNORECASE)

    # Check if a matching adverb was uncovered.
    if adverb_match:
        commence_index = adverb_match.start()
        closing_index = adverb_match.end()
        uncovered_adverb_word = adverb_match.group(0)

        # Compose and convey the output string.
        output_string = (
            f"{commence_index}-{closing_index}: {uncovered_adverb_word}"
        )
        return output_string
    else:
        # In case no adverb concluding with 'ly' is uncovered.
        return None