def find_first_occurrence(input_array: list, input_num: int) -> int:
    """
    Locates the initial index of a chosen value in a sorted array.
    Uses a modified binary search approach.
    """
    imin_index = 0
    imax_index = len(input_array) - 1
    ans_index = -1  # Accumulates initial occurrence index

    while imin_index <= imax_index:
        mid_index = imin_index + (imax_index - imin_index) // 2
        current_value = input_array[mid_index]

        if current_value == input_num:
            ans_index = mid_index  # Assign current index as a potential initial occurrence
            imax_index = mid_index - 1  # Move to check in the left half for an even earlier occurrence
        elif current_value < input_num:
            imin_index = mid_index + 1  # Input value is on the right side
        else:  # current_value > input_num
            imax_index = mid_index - 1  # Input value is on the left side

    return ans_index