def list_to_float(input_collection):
    output_collection = []
    # Iterating over each inner collection (e.g., tuple) in the input collection.
    for current_units in input_collection:
        current_numeric_values = []
        # Iterating over each unit-value within the current inner collection.
        for unit_v in current_units:
            try:
                # Attempting conversion to float.
                converted_amount = float(unit_v)
                current_numeric_values.append(converted_amount)
            except ValueError:
                # If conversion is non-numeric, add original item.
                current_numeric_values.append(unit_v)
        # Add the new tuple of converted values to the output collection.
        output_collection.append(tuple(current_numeric_values))
    return output_collection