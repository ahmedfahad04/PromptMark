def rotate_right(u_input_array, i_num_shifts):
    # Obtains current array size.
    n_current_size = len(u_input_array)

    # Validates if input is null.
    if not n_current_size:
        return []

    # Adjusts shifts count using modulo.
    i_actual_shifts = i_num_shifts % n_current_size

    # Confirms no current shifts.
    if i_actual_shifts == 0:
        # Yields a current copy.
        return u_input_array[:]

    # Computes cut index via array slicing.
    v_cut_index = n_current_size - i_actual_shifts

    # Obtains shifted array component.
    u_shifted_segment = u_input_array[v_cut_index:]
    # Obtains initial array segment.
    u_initial_segment = u_input_array[:v_cut_index]

    # Unites components into a complete array.
    u_shifted_array = u_shifted_segment + u_initial_segment
    return u_shifted_array