def trim_tuple(input_collection_units: list[tuple], cut_units: int) -> str:
    # A collection: updated units.
    updated_couples_union = []

    # An iteration occurs over input_collection_units.
    for current_unit in input_collection_units:
        # Cuts items out of cut_units at start and ultimate.
        current_unit_sliced = current_unit[cut_units : -cut_units]
        updated_couples_union.append(current_unit_sliced)

    # Cast collection_union into string.
    return str(updated_couples_union)