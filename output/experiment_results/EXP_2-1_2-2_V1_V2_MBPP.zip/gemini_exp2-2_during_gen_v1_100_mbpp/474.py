def replace_char(input_string, old_char, new_char):
    # An initial action converts the input string into a modifiable array of characters.
    current_char_array = list(input_string)

    # Cycle across character items, updating an item if its value matches the old character.
    item_index = 0
    while item_index < len(current_char_array):
        if current_char_array[item_index] == old_char:
            current_char_array[item_index] = new_char
        item_index += 1
    
    # Unite modified character items into a new output string.
    output_string = "".join(current_char_array)
    return output_string