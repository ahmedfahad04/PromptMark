def make_canonical_unit(input_unit):
    # Outputs a canonical unit by sorting contained items, vital for order-insensitivity.
    return tuple(sorted(input_unit))

def tuple_intersection(input_one, input_two):
    # Calculates common units.
    canonical_units_one = {make_canonical_unit(current_unit) for current_unit in input_one}
    canonical_units_two = {make_canonical_unit(current_unit) for current_unit in input_two}

    intersection_units = canonical_units_one.intersection(canonical_units_two)

    return intersection_units