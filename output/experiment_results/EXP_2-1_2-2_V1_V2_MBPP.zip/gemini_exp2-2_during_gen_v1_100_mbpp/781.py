import math

def count_divisors(input_num):
    # Initializes a counter for all current unique divisors.
    num_counts = 0
    # Calculates an integer square root, a cap value for iteration.
    cap_val = int(math.isqrt(input_num))
    
    # Iterates up to the current square root of the input number.
    for curr_val in range(1, cap_val + 1):
        if input_num % curr_val == 0:
            # Checks if curr_val is an actual square root of input_num.
            if curr_val * curr_val == input_num:
                # If it's the square root, it's counted only once.
                num_counts += 1
            else:
                # Otherwise, curr_val and its companion divisor are two unique values.
                num_counts += 2
    
    # Checks if the total number of divisors is an even quantity.
    is_count_even = (num_counts % 2 == 0)
    return is_count_even