def largest_subset(input_values: list[int]) -> int:
    current_values_sorted = sorted(input_values)
    current_array_count = len(current_values_sorted)

    if current_array_count == 0:
        return 0

    # subset_sizes_array: Stores current count of members in compatibility chains.
    subset_sizes_array = [1] * current_array_count
    max_subset_current_size = 1

    # outer_index: Main index, current value.
    for outer_index in range(current_array_count):
        # inner_index: Initial index, smaller value.
        for inner_index in range(outer_index):
            # Check current_values_sorted[outer_index] % current_values_sorted[inner_index] == 0.
            if current_values_sorted[outer_index] % current_values_sorted[inner_index] == 0:
                # Update subset_sizes_array; using current or new via inner_index.
                subset_sizes_array[outer_index] = max(
                    subset_sizes_array[outer_index], 1 + subset_sizes_array[inner_index]
                )
        # Update overall maximum.
        max_subset_current_size = max(max_subset_current_size, subset_sizes_array[outer_index])

    return max_subset_current_size