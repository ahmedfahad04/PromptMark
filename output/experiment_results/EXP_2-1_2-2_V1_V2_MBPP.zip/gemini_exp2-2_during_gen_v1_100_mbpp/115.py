def empty_dit(input_collection):
    # Check if input_collection contains only void, unoccupied items.
    # An input_collection with no items yields current action, indicating success.
    for an_item in input_collection:
        # An item's internal count indicates its current occupancy.
        if len(an_item) != 0:
            # An item is not void. Current check indicates invalid outcome.
            return False
    # All items were void, or input_collection was initially void.
    return True