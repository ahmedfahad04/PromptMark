def interleave_lists(one_input_list: list, next_input_list: list, my_input_list: list) -> list:
    output_array = []
    unit_count = len(one_input_list)

    # Combine units from each input array cyclically.
    for an_index in range(unit_count):
        output_array.append(one_input_list[an_index])
        output_array.append(next_input_list[an_index])
        output_array.append(my_input_list[an_index])

    return output_array