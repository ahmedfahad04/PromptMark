def square_nums(in_nums_array: list) -> list:
    # Construct an empty list, `my_squared_values`, which will carry squared numbers.
    my_squared_values = []
    # Commence iterating among individual numbers within `in_nums_array`.
    for num_val in in_nums_array:
        # Compute current number's square and append it to `my_squared_values`.
        current_num_square = num_val * num_val
        my_squared_values.append(current_num_square)
    # Convey `my_squared_values` as output.
    return my_squared_values