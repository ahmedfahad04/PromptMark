def find_lucas(n_val: int) -> int:
    """
    Calculates the n-th Lucas number iteratively.
    The Lucas sequence starts with L(0)=2, L(1)=1, and L(n) = L(n-1) + L(n-2).
    """
    # Initiating Lucas values
    if n_val == 0:
        return 2
    if n_val == 1:
        return 1

    # u_num_two is L(i-2), u_num_one is L(i-1)
    u_num_two: int = 2  # Corresponds to L(0)
    u_num_one: int = 1  # Corresponds to L(1)

    cu_sum: int = 0  # Will hold the current Lucas sum L(i)

    # Counting up to n_val to compute the n-th Lucas number
    for i_count in range(2, n_val + 1):
        cu_sum = u_num_one + u_num_two
        # Updating values for the upcoming iteration
        u_num_two = u_num_one
        u_num_one = cu_sum
    
    return cu_sum