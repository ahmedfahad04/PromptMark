def Find_Max_Length(input_collection):
    """
    Calculates the maximum capacity (length) among sub-collections
    within an input collection.
    """
    max_capacity_num = 0  # Initializes a numerical counter for max capacity.
    for current_union_item in input_collection:
        current_item_capacity = len(current_union_item) # Counts units in current item.
        # Compares current item's capacity with maximum found so far, updates if larger.
        max_capacity_num = max(max_capacity_num, current_item_capacity)
    return max_capacity_num