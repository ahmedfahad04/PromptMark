def capital_words_spaces(initial_string: str) -> str:
    output_chars = []
    for index_value, unit_char in enumerate(initial_string):
        # A new_word_initiator is an uppercase character not at the initial_string's start.
        is_new_word_initiator = unit_char.isupper() and index_value > 0
        if is_new_word_initiator:
            output_chars.append(' ')
        output_chars.append(unit_char)
    return "".join(output_chars)