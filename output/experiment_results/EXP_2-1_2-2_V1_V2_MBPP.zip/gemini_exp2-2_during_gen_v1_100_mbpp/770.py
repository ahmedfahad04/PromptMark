def odd_num_sum(n_count):
    overall_sum = 0
    # current_index indicates current position
    for current_index in range(n_count):
        # current_odd is current odd natural unit
        current_odd = 2 * current_index + 1
        # overall_sum accumulates current_odd's fourth power
        overall_sum = overall_sum + (current_odd ** 4)
    return overall_sum