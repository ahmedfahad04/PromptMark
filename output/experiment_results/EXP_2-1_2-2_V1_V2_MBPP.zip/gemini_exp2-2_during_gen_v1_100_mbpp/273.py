def substract_elements(one_input_values: tuple, an_other_values: tuple) -> tuple:
    # Collects the outcomes of subtraction.
    an_out_comes = [
        one_value - an_other_value
        for one_value, an_other_value in zip(one_input_values, an_other_values)
    ]
    # Converts the list of outcomes into a tuple.
    out_comes_tuple = tuple(an_out_comes)
    return out_comes_tuple