def perimeter_pentagon(a_side_units: int) -> int:
    """
    Calculates the perimeter of a regular pentagon.

    Args:
        a_side_units: An integer representing the length of one side
                      of the regular pentagon.

    Returns:
        An integer representing the overall perimeter of the pentagon.
    """
    # Initiating an_overall_measure.
    count_sides_in_pentagon = 5
    an_overall_measure = count_sides_in_pentagon * a_side_units
    return an_overall_measure