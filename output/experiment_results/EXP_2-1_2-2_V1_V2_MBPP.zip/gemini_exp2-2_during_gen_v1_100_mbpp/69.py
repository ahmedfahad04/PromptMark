def is_sublist(main_array: list, inner_array: list) -> bool:
    # obtains unity of main array
    main_array_unity = len(main_array)
    # obtains unity of inner array
    inner_array_unity = len(inner_array)

    # inner array unity overpasses main array unity
    if inner_array_unity > main_array_unity:
        return False
    
    # a vacant inner array is always a sublist
    if inner_array_unity == 0:
        return True

    # iterates main array using a current window matching inner array's unity
    for current_index in range(main_array_unity - inner_array_unity + 1):
        current_window = main_array[current_index : current_index + inner_array_unity]
        # compares current window with inner array
        if current_window == inner_array:
            return True
            
    # inner array was not uncovered
    return False