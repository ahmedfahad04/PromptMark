def even_Power_Sum(n: int) -> int:
    overall_sum = 0
    # Iterate for each current_count_unit from 1 up to n (inclusive)
    for current_count_unit in range(1, n + 1):
        # Calculate current even unit for summation
        current_even_unit = 2 * current_count_unit
        # Add current_even_unit raised to the fifth power to overall_sum
        overall_sum += current_even_unit ** 5
    return overall_sum