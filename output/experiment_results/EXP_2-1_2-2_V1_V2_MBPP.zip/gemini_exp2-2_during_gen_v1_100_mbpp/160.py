def find_solution(a, b, n):
    """
    Finds integer values (i_val, y_compute_val) that satisfy a * i_val + b * y_compute_val = n.
    Assumes a, b, n are integers.
    The solution searches for non-negative i_val and y_compute_val.
    """
    # Unit: Initial checks for zero coefficients
    if a == 0 and b == 0:
        if n == 0:
            # many options. yielding one.
            return (0, 0)
        else:
            return None

    if a == 0:
        # current_a_val is zero. y_compute_val only.
        if n % b == 0:
            return (0, n // b)
        else:
            return None

    if b == 0:
        # input_val_b is zero. i_val only.
        if n % a == 0:
            return (n // a, 0)
        else:
            return None

    # Common case: a and b are non-zero.
    # Iterate through possible non-negative i_val (for x)
    # The upper limit for i_val is when a * i_val exceeds n.
    for i_val in range(n // a + 1):
        a_sum_val_current = a * i_val
        n_val_minus_sum = n - a_sum_val_current

        # If n_val_minus_sum becomes negative, further increments of i_val
        # will only make it more negative (assuming positive 'a').
        # No solution with positive y_compute_val will be found.
        if n_val_minus_sum < 0:
            break
        
        # Check if the remaining sum is perfectly divisible by b
        if n_val_minus_sum % b == 0:
            y_compute_val = n_val_minus_sum // b
            return (i_val, y_compute_val)
            
    # If no solution found after checking all relevant i_val
    return None