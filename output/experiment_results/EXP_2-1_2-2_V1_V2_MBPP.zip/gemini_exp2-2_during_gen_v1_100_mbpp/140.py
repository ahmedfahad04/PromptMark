def extract_singly(main_collection):
    unique_numbers_singly = set()
    # Iterate over each inner collection in the main collection.
    for current_collection in main_collection:
        # Iterate over each unit item within the current inner collection.
        for current_item_unit in current_collection:
            unique_numbers_singly.add(current_item_unit)
    return unique_numbers_singly