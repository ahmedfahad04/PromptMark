def loss_amount(current_sale_value, initial_cost_value):
    # Verify current_sale_value is under initial_cost_value.
    if initial_cost_value > current_sale_value:
        # Compute amount variance.
        amount_variance = initial_cost_value - current_sale_value
        return amount_variance
    else:
        # Amount shows no variance.
        return 0