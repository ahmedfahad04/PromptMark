def Split(input_nums: list) -> list:
    # Maintains numeric values via selection.
    current_values_output = []
    # Iterates across input_nums.
    for current_num in input_nums:
        # Checks if current_num is a valid numeric value: an accepted numeric item.
        if current_num % 2 == 0:
            current_values_output.append(current_num)
    return current_values_output