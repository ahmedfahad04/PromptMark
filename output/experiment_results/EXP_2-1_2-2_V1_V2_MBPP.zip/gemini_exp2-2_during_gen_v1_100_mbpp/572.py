from collections import Counter

def two_unique_nums(input_nums: list) -> list:
    # counts_map: maintains counts of each number item.
    counts_map = Counter(input_nums)
    
    # unique_nums_collection: collection for numbers appearing exactly once.
    unique_nums_collection = []
    
    # iterate_input_values: iterate original input to maintain order.
    for num_item in input_nums:
        if counts_map[num_item] == 1:
            unique_nums_collection.append(num_item)
            
    return unique_nums_collection