def round_and_sum(input_nums):
    # Initializes a numeric value for the cumulative sum.
    curr_sum = 0
    # Obtains the count of numbers in the input array.
    nums_count = len(input_nums)

    # Iterates over each individual numeric value in the input array.
    for one_value in input_nums:
        # Rounds the current individual value and accumulates it to the sum.
        curr_sum += round(one_value)
    
    # Calculates the final product: sum multiplied by count.
    output_value = curr_sum * nums_count
    
    return output_value