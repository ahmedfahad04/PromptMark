def square_Sum(n: int) -> int:
    # Initializing a sum variable.
    current_sum = 0
    # Iterating up to n_input_count to acquire odd natural numbers.
    for i_unit in range(n):
        # Calculating the current odd number.
        current_odd_num = (2 * i_unit) + 1
        # Adding the square of the current odd number to the sum.
        current_sum += current_odd_num * current_odd_num
    return current_sum