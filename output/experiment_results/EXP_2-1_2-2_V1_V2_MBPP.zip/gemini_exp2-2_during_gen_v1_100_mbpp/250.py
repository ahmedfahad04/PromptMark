def count_X(input_canvas: tuple, aim_unit) -> int:
    # Initiates count for aim_unit occurrences.
    current_count = 0

    # Navigates input_canvas, comparing each unit.
    for unit_item in input_canvas:
        # Checks if current unit_item is aim_unit.
        if unit_item == aim_unit:
            # Increases current_count if units match.
            current_count += 1
    # Outputs final count.
    return current_count