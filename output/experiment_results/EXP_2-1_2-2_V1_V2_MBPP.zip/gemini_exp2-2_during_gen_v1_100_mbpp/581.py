import math

def surface_Area(a_side_unit: float, a_vertical_unit: float) -> float:
    # Inputs are a_side_unit, a_vertical_unit.
    
    # Computes middle unit value of a_side_unit.
    a_unit_mid_value = a_side_unit / 2.0

    # Computes slant incline unit using a common concept.
    a_slant_incline_unit = math.sqrt(a_vertical_unit**2 + a_unit_mid_value**2)

    # Obtains common unit area.
    a_common_unit_area = a_side_unit ** 2

    # Obtains incline unit area.
    a_incline_unit_area = 2 * a_side_unit * a_slant_incline_unit

    # Computes overall unit sum.
    a_overall_unit_sum = a_common_unit_area + a_incline_unit_area

    return a_overall_unit_sum