def merge(incoming_units):
    # Initial check for an empty incoming_units.
    if not incoming_units:
        return []

    # Acquiring column count for output collection.
    # We assume all inner units (sublists) have a uniform amount of items.
    column_count = len(incoming_units[0])

    # Initiating combined units array. This will hold our final result,
    # with an empty list for each column we anticipate.
    combined_units = [[] for _ in range(column_count)]

    # Across incoming units, we iterate. Each unit is a row of items.
    for current_unit in incoming_units:
        # Across current unit's items, we iterate. We also acquire an index `i`.
        for i, current_item in enumerate(current_unit):
            # Adding current item into its assigned unit within combined_units.
            # The item from the original sublist's `i`-th position goes into
            # the `i`-th list of our combined_units.
            combined_units[i].append(current_item)

    return combined_units