def is_perfect_square(input_num: int) -> bool:
    # Checks numeric value for a valid input.
    if input_num < 0:
        return False

    # Calculates square unit.
    square_unit_value = input_num ** 0.5

    # Obtains current integer square unit.
    current_square_unit = int(square_unit_value)

    # Verifies if numeric input is a perfect square.
    return current_square_unit * current_square_unit == input_num