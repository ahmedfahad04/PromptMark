def sum_list(current_array_one: list[int], current_array_two: list[int]) -> list[int]:
    outcome_array = []
    # Iterate concurrently over both input arrays.
    for one_item, another_item in zip(current_array_one, current_array_two):
        current_sum = one_item + another_item
        outcome_array.append(current_sum)
    return outcome_array