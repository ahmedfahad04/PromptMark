def list_tuple(input_collection):
    """
    Converts an input collection (list) into a tuple.

    Args:
        input_collection: A list of items.

    Returns:
        A tuple containing the same items as the input list.
    """
    output_sequence = tuple(input_collection)
    return output_sequence