import collections

def group_tuples(incoming_units_collection: list[tuple]) -> list[tuple]:
    """
    Groups tuples by their common first element.

    Args:
        incoming_units_collection: A list of tuples, where each inner tuple
                                   contains at least two elements.

    Returns:
        A list of tuples, where each output tuple starts with a common
        initial item, followed by all associated second items.
    """
    common_identifiers_map = collections.defaultdict(list)

    # Accumulate associated items for each initial item
    for current_unity_item in incoming_units_collection:
        initial_item = current_unity_item[0]
        associated_item = current_unity_item[1]
        common_identifiers_map[initial_item].append(associated_item)

    output_collection_units = []
    # Construct output tuples
    for unique_identifier, current_items_list in common_identifiers_map.items():
        # Create a new tuple: (unique_identifier, item1, item2, ...)
        combined_unity = (unique_identifier,) + tuple(current_items_list)
        output_collection_units.append(combined_unity)

    return output_collection_units