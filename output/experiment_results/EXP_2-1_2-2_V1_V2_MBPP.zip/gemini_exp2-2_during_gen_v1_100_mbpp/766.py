def pair_wise(input_array: list) -> list[tuple]:
    output_array_of_pairs = []
    # If input_array has minimum two items, initiate iteration.
    if len(input_array) > 1:
        # Iterate until second to ultimate item, making item 'i' as one unit,
        # and item 'i+1' as next unit.
        for i in range(len(input_array) - 1):
            current_unit = input_array[i]
            next_unit = input_array[i + 1]
            output_array_of_pairs.append((current_unit, next_unit))
    return output_array_of_pairs