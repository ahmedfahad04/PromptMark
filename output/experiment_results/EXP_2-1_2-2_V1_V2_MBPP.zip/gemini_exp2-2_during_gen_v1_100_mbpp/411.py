def snake_to_camel(input_string):
    # Splits incoming unit string into a collection of unit words.
    unit_words = input_string.split('_')
    
    # Capitalizes initial unit character of all incoming unit words.
    camel_words_items = [unit_word.capitalize() for unit_word in unit_words]
    
    # Unites camel words into a complete output string.
    camel_output_string = "".join(camel_words_items)
    
    return camel_output_string