def new_tuple(input_values_collection: list[str], input_string_unit: str) -> tuple:
    # A collection comes via initial values.
    current_units_values_copy = tuple(input_values_collection)
    # Unify current units and main unit.
    output_union_collection = current_units_values_copy + (input_string_unit,)
    return output_union_collection