def remove_lowercase(coming_string: str) -> str:
    # Aims to accumulate non-lowercase characters.
    clean_chars = []
    # Iterates on individual characters within the input.
    for current_char in coming_string:
        # Checks if current_char is lowercase.
        # It adds to clean_chars only if not lowercase.
        if not current_char.islower():
            clean_chars.append(current_char)
    # Joins the collected characters to form a new string.
    new_string = "".join(clean_chars)
    return new_string