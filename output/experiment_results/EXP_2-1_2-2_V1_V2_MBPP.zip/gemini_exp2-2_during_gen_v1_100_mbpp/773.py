def occurance_substring(main_string: str, sub_string: str) -> (str, int, int) | None:
    # Use str.find() to ascertain the initial index of the sub_string.
    commencing_index = main_string.find(sub_string)

    # A sub_string un-found indicates -1.
    if commencing_index == -1:
        return None
    else:
        # Calculate the up_to_index. Its value is un-inclusive, indicating a vicinity upon sub_string's closing character.
        up_to_index = commencing_index + len(sub_string)
        return (sub_string, commencing_index, up_to_index)