def start_withp(source_units: list[str]) -> tuple[str, str]:
    commencing_items = [] # Collects words commencing with 'p'

    # Iterate over input items provided
    for current_unit_string in source_units:
        # Split each string into individual units (words)
        units_array = current_unit_string.split()
        for individual_unit in units_array:
            # Check if the individual unit commences with 'p' (case-insensitive)
            if individual_unit.lower().startswith('p'):
                commencing_items.append(individual_unit)
                # If two commencing items are found, immediately return them
                if len(commencing_items) == 2:
                    return tuple(commencing_items)
    
    # This part is typically not reached if the problem guarantees two words are always present.
    # It will return whatever was collected if fewer than two words are found.
    return tuple(commencing_items)