def common_in_nested_lists(nested_lists: list[list[int]]) -> set[int]:
    # initial_check: If the input collection is empty, an empty collection is common.
    if not nested_lists:
        return set()

    # common_items_init: Start with the elements of the initial inner collection.
    # Convert it into a set for efficient intersection operations.
    common_items: set[int] = set(nested_lists[0])

    # Iterate through the remaining inner collections.
    for inner_collection in nested_lists[1:]:
        # current_collection_as_set: Convert the current inner collection into a set.
        current_collection_as_set: set[int] = set(inner_collection)
        
        # Update common_items by finding the intersection with the current collection.
        # This keeps only elements present in all collections examined so far.
        common_items = common_items.intersection(current_collection_as_set)
        
        # early_exit_check: If at any point common_items becomes empty,
        # it indicates no elements are common to all collections,
        # so we can immediately return an empty set.
        if not common_items:
            return set()

    return common_items