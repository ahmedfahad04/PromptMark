def string_to_tuple(incoming_string):
    """
    Converts an incoming string into a tuple of its characters,
    omitting any space characters.
    """
    current_char_units = []
    for a_char_item in incoming_string:
        # A unit is included only if it is not a space.
        if a_char_item != ' ':
            current_char_units.append(a_char_item)

    # Convert the collected units into an immutable sequence.
    a_output_collection = tuple(current_char_units)
    return a_output_collection