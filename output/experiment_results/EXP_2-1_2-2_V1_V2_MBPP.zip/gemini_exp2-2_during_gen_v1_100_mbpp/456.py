def reverse_string_list(an_input_strings_list: list) -> list:
    """
    Creates a new list with each string from the input list individually reversed.
    """
    a_new_current_array = []
    for a_current_string in an_input_strings_list:
        # Using slicing for current string inversion
        current_inverted_value = a_current_string[::-1]
        a_new_current_array.append(current_inverted_value)
    return a_new_current_array