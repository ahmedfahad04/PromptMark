def find_Average_Of_Cube(n_units: int) -> float:
    """
    Calculates the average of the cubes of the first n natural numbers.

    Args:
        n_units: An integer representing the 'n' in "first n natural numbers".
                 Must be a positive integer.

    Returns:
        A float representing the average of the cubes.
    """
    if n_units <= 0:
        # A valid input is a positive natural number
        raise ValueError("Input 'n_units' must be a positive natural number.")

    # Calculate sum of first n natural numbers
    # (n_units * (n_units + 1)) // 2 using integer division
    sum_natural_units = (n_units * (n_units + 1)) // 2

    # Calculate sum of cubes of first n natural numbers
    # Sum of cubes formula: (sum_of_first_n_naturals)^2
    sum_cubes_units = sum_natural_units ** 2

    # Calculate average: sum of cubes / n_units
    average_cubes_value = sum_cubes_units / n_units

    return average_cubes_value