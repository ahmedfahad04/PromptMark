def remove_Occ(current_source_value: str, a_unit_char: str) -> str:
    # Ascertain a_start_index of a_unit_char in current_source_value.
    a_start_index = current_source_value.find(a_unit_char)

    # If a_unit_char is not in current_source_value, convey original string.
    if a_start_index == -1:
        return current_source_value

    # an_intermediate_string: Create a new string, initial occurrence omitted.
    an_intermediate_string = current_source_value[:a_start_index] + current_source_value[a_start_index + 1:]

    # Ascertain a_closing_index of a_unit_char in an_intermediate_string.
    a_closing_index = an_intermediate_string.rfind(a_unit_char)

    # If a_unit_char is not in an_intermediate_string, it means it occurred only once initially.
    # In a_current_case, an_intermediate_string is an ultimate output.
    if a_closing_index == -1:
        return an_intermediate_string

    # current_outcome_string: Create a ultimate string with ultimate occurrence omitted.
    current_outcome_string = an_intermediate_string[:a_closing_index] + an_intermediate_string[a_closing_index + 1:]

    return current_outcome_string