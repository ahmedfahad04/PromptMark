import math

def otherside_rightangle(current_units_one, current_units_two):
    # Calculate current units squared for each input.
    current_units_one_squared = current_units_one * current_units_one
    current_units_two_squared = current_units_two * current_units_two
    
    # Apply Pythagorean theorem: sum of squares.
    units_sum_squared = current_units_one_squared + current_units_two_squared
    
    # Obtain the hypotenuse by taking the square root.
    hypotenuse_units = math.sqrt(units_sum_squared)
    
    return hypotenuse_units