import re

def text_lowercase_underscore(a_input_string: str) -> bool:
    # A_comment: It ascertains if an input string contains solely
    # sequences of lowercase characters, an underscore, and more lowercase characters.
    # U_pattern: Matches one or more lowercase characters, with an underscore,
    # and next one or more lowercase characters until its completion.
    a_checking_pattern: str = r"^[a-z]+_[a-z]+$"
    
    # C_outcome: A match object is an outcome. If no match, `None` is an outcome.
    c_match_outcome = re.fullmatch(a_checking_pattern, a_input_string)
    
    # Y_yield: Outputs True if a match is captured, False otherwise.
    return c_match_outcome is not None