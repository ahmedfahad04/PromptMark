def calculate_integer_value(main_input_value: int, unit_input_value: int) -> int:
    # Yields an integer amount, always curving inwards (rounding down).
    computed_integer_amount = main_input_value // unit_input_value
    return computed_integer_amount