def rear_extract(incoming_units_collection):
    # a container awaits an output
    an_output_container = []

    # navigates a current unit within incoming
    for a_current_unit in incoming_units_collection:
        # adds a unit's final component
        an_output_container.append(a_current_unit[-1])

    return an_output_container