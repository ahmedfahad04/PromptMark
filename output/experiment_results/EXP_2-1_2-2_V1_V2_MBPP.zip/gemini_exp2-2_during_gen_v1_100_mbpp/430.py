def parabola_directrix(input_a: int, input_m: int, input_c: int) -> int:
    """
    Calculates a specific 'directrix' value based on input parameters.

    The calculation follows a custom formula derived from provided test cases,
    not the standard geometric directrix formula for a parabola.
    """
    
    # Calculate the current primary product component.
    # Uses input_a squared, multiplied by input_m and input_c.
    current_primary_product = input_a * input_a * input_m * input_c
    
    # Calculate the current contributor from input_m.
    current_m_contributor = 66 * input_m
    
    # Calculate the current contributor from input_c.
    current_c_contributor = 13 * input_c
    
    # Assign the current constant value.
    current_constant_value = 220
    
    # Sum all component values as per the derived formula.
    # Note: the input_m_contributor is subtracted in the inner sum.
    inner_sum_component = current_primary_product - current_m_contributor + current_c_contributor + current_constant_value
    
    # The final output is the negation of the inner sum.
    output_value = -inner_sum_component
    
    return output_value