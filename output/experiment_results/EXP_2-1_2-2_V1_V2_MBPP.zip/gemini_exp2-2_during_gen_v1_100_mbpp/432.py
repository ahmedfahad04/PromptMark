def median_trapezium(a_val, o_val, u_ignored_val):
    # Calculates median of a trapezium.
    # Assumes a_val and o_val are parallel side lengths.
    # u_ignored_val is not used in median calculation.
    
    sum_of_sides = a_val + o_val
    median_is = sum_of_sides / 2.0
    return median_is