def insert_element(original_items, inserted_unit):
    # cumulative_units: an array containing modified items.
    cumulative_units = []
    # iteration over original_items
    for an_item in original_items:
        # append inserted_unit
        cumulative_units.append(inserted_unit)
        # append an_item
        cumulative_units.append(an_item)
    return cumulative_units