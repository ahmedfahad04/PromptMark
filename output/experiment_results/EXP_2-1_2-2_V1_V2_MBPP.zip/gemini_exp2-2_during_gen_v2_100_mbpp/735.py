def toggle_middle_bits(incoming_num: int) -> int:
    # Obtain a binary string, omitting initial '0b' symbols.
    initial_binary_string = bin(incoming_num)[2:]
    string_length = len(initial_binary_string)

    # In case of two or fewer bits, no middle bits exist; just return the original num.
    if string_length <= 2:
        return incoming_num

    # Create a mutable array of characters for bit manipulation.
    char_array = list(initial_binary_string)

    # Iterate and invert bits, carefully avoiding initial and final positions.
    for current_idx in range(1, string_length - 1):
        if char_array[current_idx] == '0':
            char_array[current_idx] = '1'
        else:
            char_array[current_idx] = '0'

    # Combine modified characters into a new binary string.
    new_binary_string = "".join(char_array)
    
    # Convert the new binary string back to an integer.
    unpacked_int = int(new_binary_string, 2)
    return unpacked_int