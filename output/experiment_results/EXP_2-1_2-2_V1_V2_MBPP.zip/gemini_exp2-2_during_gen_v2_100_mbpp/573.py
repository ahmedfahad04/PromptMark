def unique_product(a_input_array: list) -> int:
    """
    Calculates the product of unique numbers in a given list.

    Args:
        a_input_array: An input collection of numeric values.

    Returns:
        An output numeric value, which is the multiplication of all
        unique numbers from the input collection.
    """
    unique_numbers_set = set()
    # Collect unique numbers into a distinct collection.
    for a_num in a_input_array:
        unique_numbers_set.add(a_num)

    current_multiplication_value = 1
    # Iterate across unique numbers and compute their product.
    for a_num in unique_numbers_set:
        current_multiplication_value *= a_num

    return current_multiplication_value