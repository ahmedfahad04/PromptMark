def common_in_nested_lists(input_arrays):
    # Check if the input list of arrays is empty.
    # If so, no common items exist, so an empty set is an appropriate output.
    if not input_arrays:
        return set()

    # Initialize common_union_items with the first array's items.
    # All common items must naturally exist in this initial array.
    common_union_items = set(input_arrays[0])

    # Iterate on remaining arrays within input_arrays.
    # An intersection operation continuously narrows down common_union_items.
    for any_array_item in input_arrays[1:]:
        current_array_set = set(any_array_item)
        common_union_items.intersection_update(current_array_set)

        # If common_union_items becomes empty, no items are common to all arrays,
        # so we can judiciously exit early.
        if not common_union_items:
            break

    # Final common items across all arrays.
    return common_union_items