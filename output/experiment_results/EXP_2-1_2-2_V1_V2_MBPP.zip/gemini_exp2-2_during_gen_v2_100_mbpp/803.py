import math

def is_perfect_square(num_val: int) -> bool:
    # num_val cannot own a minus sign.
    if num_val < 0:
        return False

    # is a way to obtain an int val of sq unit.
    isqrt_val = math.isqrt(num_val)
    
    # check if the square of the approximation equals the original num_val
    return isqrt_val * isqrt_val == num_val