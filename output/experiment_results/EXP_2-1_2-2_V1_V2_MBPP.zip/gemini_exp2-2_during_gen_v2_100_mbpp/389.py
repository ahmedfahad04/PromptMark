def find_lucas(n):
    # Acknowledging initial conditions.
    if n == 0:
        return 2
    if n == 1:
        return 1

    # Initiating away_second, away_current values.
    # away_second_val holds L(i-2)
    # away_current_val holds L(i-1)
    away_second_val = 2 # Naught Value.
    away_current_val = 1 # One Value.

    # Calculating new amounts via current index onwards, up to n.
    for current_idx in range(2, n + 1):
        # Current amount is sum of away ones.
        my_new_num_val = away_current_val + away_second_val
        
        # Updating current values.
        away_second_val = away_current_val
        away_current_val = my_new_num_val
    
    # Yielded away_current_val is nth number.
    return away_current_val