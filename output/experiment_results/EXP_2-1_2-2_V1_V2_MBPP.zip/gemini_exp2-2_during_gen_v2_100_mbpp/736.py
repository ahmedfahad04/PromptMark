def left_insertion(a_canvas_array: list[int], a_check_unit: int) -> int:
    min_index = 0
    max_index = len(a_canvas_array)

    # Maintain invariant: a_canvas_array[i] < a_check_unit for i < min_index,
    # and a_canvas_array[i] >= a_check_unit for i >= max_index.
    # The insertion point will be min_index.
    while min_index < max_index:
        way_index = (min_index + max_index) // 2
        # If current unit is smaller as check unit,
        # scan on unit's upward way.
        if a_canvas_array[way_index] < a_check_unit:
            min_index = way_index + 1
        # If current unit is no way smaller,
        # scan on unit's inward way.
        else:
            max_index = way_index
    # Final min_index shows point.
    return min_index