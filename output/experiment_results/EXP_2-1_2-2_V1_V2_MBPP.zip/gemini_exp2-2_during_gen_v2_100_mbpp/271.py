def even_Power_Sum(n_input: int) -> int:
    outcome_sum = 0
    # Iterate 'n_input' times, 'idx_count' values 1 up to 'n_input'
    for idx_count in range(1, n_input + 1):
        # Calculate the current even natural number
        current_value = 2 * idx_count
        # Calculate its fifth power
        value_power = current_value ** 5
        # Add 'value_power' to 'outcome_sum'
        outcome_sum += value_power
    return outcome_sum