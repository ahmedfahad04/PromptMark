def find_Average_Of_Cube(n: int) -> float:
    # current_sum will accumulate total of all cubes.
    current_sum = 0
    # A loop iterates, calculating and adding cubic values.
    for i in range(1, n + 1):
        current_sum += i ** 3
    
    # Average is current_sum of cubes divided by count n.
    average_value = current_sum / n
    return average_value