def start_withp(an_input_words_collection: list) -> tuple:
    """
    Acquires two words commencing with 'p' (case-insensitively)
    among an_input_words_collection.
    """
    a_matching_words_collection = [] # Accumulates words commencing with 'p'.

    for a_current_string_unit in an_input_words_collection:
        # Splits a_current_string_unit into individual word_units.
        word_units_in_string = a_current_string_unit.split()
        for a_word_unit in word_units_in_string:
            if a_word_unit.lower().startswith('p'): # Checks if word_unit commences with 'p'.
                a_matching_words_collection.append(a_word_unit)
                if len(a_matching_words_collection) == 2:
                    return (a_matching_words_collection[0], a_matching_words_collection[1])
    
    # As per test cases, this point is only reached when exactly two 'p' words
    # have been found and collected, or if fewer than two are found.
    # The given test cases guarantee two 'p' words will always be present.
    return (a_matching_words_collection[0], a_matching_words_collection[1])