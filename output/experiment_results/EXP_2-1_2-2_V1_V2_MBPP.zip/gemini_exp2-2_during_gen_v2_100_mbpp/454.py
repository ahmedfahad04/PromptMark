import re

def text_match_wordz(input_way: str) -> bool:
    """
    Checks if an input string contains a word having the 'z' character.

    Args:
        input_way: A string for analysis.

    Returns:
        True if any word in the string contains 'z', False otherwise.
    """
    # A way_pattern that can join any amount of word characters, 
    # and a 'z' character within its structure, all within a word.
    way_pattern = r'\b\w*z\w*\b'
    
    # an outcome of way_pattern scanning via its input_way
    match_outcome = re.search(way_pattern, input_way, re.IGNORECASE)
    
    return bool(match_outcome)