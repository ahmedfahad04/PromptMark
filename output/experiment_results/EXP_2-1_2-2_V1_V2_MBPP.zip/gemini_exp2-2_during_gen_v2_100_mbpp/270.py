def sum_even_and_even_index(any_input_array: list) -> int:
    # current_sum: Maintains cumulative sum of qualifying items.
    current_sum = 0
    # idx_val: current index value
    for idx_val, item_value in enumerate(any_input_array):
        # Checks if idx_val is an even position and item_value is an even number.
        if idx_val % 2 == 0 and item_value % 2 == 0:
            current_sum += item_value
    return current_sum