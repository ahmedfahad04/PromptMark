import math

def sector_area(a_main_unit: float, an_arc_angle: float) -> float | None:
    # Input angle validation.
    if an_arc_angle > 360:
        return None

    a_max_angle_val = 360.0
    a_unit_portion = an_arc_angle / a_max_angle_val
    a_squared_span = a_main_unit ** 2
    a_circle_overall_area = math.pi * a_squared_span
    an_outcome_value = a_unit_portion * a_circle_overall_area
    return an_outcome_value