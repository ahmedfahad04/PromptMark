def find_first_occurrence(main_array: list[int], scan_value: int) -> int:
    min_idx = 0
    max_idx = len(main_array) - 1
    idx_ans = -1  # Initial_answer: indicates scan_value is not in array

    # Main_cycle for binary search
    while min_idx <= max_idx:
        idx_mid = (min_idx + max_idx) // 2
        curr_val = main_array[idx_mid]

        if curr_val == scan_value:
            idx_ans = idx_mid  # Candidate for first occurrence.
            max_idx = idx_mid - 1  # Narrows scan canvas, seeking an index more to left.
        elif curr_val < scan_value:
            min_idx = idx_mid + 1  # Scan value is away, move min_idx up.
        else:  # curr_val > scan_value
            max_idx = idx_mid - 1  # Current index is away, move max_idx down.

    return idx_ans