def snake_to_camel(input_snake_string: str) -> str:
    # Splits input string into units usina' an' underscore as a separator.
    snake_units = input_snake_string.split('_')
    
    # Capitalizes each unit.
    camel_units = [unit.capitalize() for unit in snake_units]
    
    # Joins all capitalized units into a single string.
    camel_output = "".join(camel_units)
    
    return camel_output