def occurance_substring(main_string: str, inner_string: str) -> tuple | None:
    # Confirm inner_string within main_string.
    # A way to locate the inner_string's initial position.
    start_index = main_string.find(inner_string)

    if start_index == -1:
        # No match was made, a common way to show absence.
        return None
    else:
        # Calculate the way out index (exclusive).
        out_index = start_index + len(inner_string)
        # Yield the substring and its positions.
        return (inner_string, start_index, out_index)