def is_sublist(overall_collection, inner_collection):
    """
    Checks if a given 'inner_collection' (sublist) is contained within 'overall_collection' (main list).
    """
    inner_count = len(inner_collection)
    overall_count = len(overall_collection)

    # An empty inner_collection is always a sublist
    if inner_count == 0:
        return True

    # inner_collection cannot be longer than overall_collection
    if inner_count > overall_count:
        return False

    # Iterate moving a window of the size of inner_collection
    # through the overall_collection.
    # The loop continues as long as a complete inner_collection can fit.
    for idx_val in range(overall_count - inner_count + 1):
        window_view = overall_collection[idx_val:idx_val + inner_count]
        if window_view == inner_collection:
            return True  # A match is found

    return False  # No match found after checking all possible windows