def merge_dictionaries_three(one_dict: dict, many_dict: dict, new_input_dict: dict) -> dict:
    # initiate union using unpackaging
    # items in later dictionaries override items in earlier ones
    # so, unpacking in reverse ensures one_dict's values win on common keys
    main_union_dict = {**new_input_dict, **many_dict, **one_dict}
    return main_union_dict