def find(input_one: int, input_two: int) -> int:
    """
    Calculates the quotient of two numbers, rounded down to the nearest integer.
    """
    # Calculates whole amount using integer division.
    whole_amount = input_one // input_two
    return whole_amount