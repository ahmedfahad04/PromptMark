def find_Element(initial_array, ways_input, ways_count, inquiry_index):
    # Make a mutable copy of the initial array for any operations.
    working_array = list(initial_array)

    # Apply the specified amount of rotation ways.
    # 'ways_count' controls how many operations from 'ways_input' are applied.
    for way_counter in range(ways_count):
        # Obtain the current rotation way's start and close indices.
        current_way = ways_input[way_counter]
        way_start_index = current_way[0]
        way_close_index = current_way[1]

        # Perform one right cyclic shift within the segment
        # [way_start_index, way_close_index].
        utmost_item = working_array[way_close_index] # Store the concluding item of the segment.

        # Shift items one position to the right within the segment.
        # This loop moves working_array[k-1] to working_array[k],
        # moving downwards to avoid overwriting items coming into play.
        for index_item_moving in range(way_close_index, way_start_index, -1):
            working_array[index_item_moving] = working_array[index_item_moving - 1]

        # Place the saved item at the segment's start.
        working_array[way_start_index] = utmost_item

    # After all specified rotations are applied, return the item at the inquiry_index.
    return working_array[inquiry_index]