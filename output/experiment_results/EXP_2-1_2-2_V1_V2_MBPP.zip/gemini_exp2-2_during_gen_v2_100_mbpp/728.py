def sum_list(initial_values_collection, additional_values_collection):
    # Initializes a new collection, containing computed values.
    computed_values_collection = []

    # Walks over collection items in unison.
    for one_value, additional_value in zip(initial_values_collection, additional_values_collection):
        current_sum_value = one_value + additional_value
        computed_values_collection.append(current_sum_value)

    return computed_values_collection