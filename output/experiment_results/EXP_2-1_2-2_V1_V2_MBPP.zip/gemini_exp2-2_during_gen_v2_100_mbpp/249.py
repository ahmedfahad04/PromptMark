def intersection_array(array_one, array_companion):
    # Utilize 'array_companion' for quick item identification.
    # Creating a set allows for average O(1) time complexity during lookups.
    unique_values_companion = set(array_companion)

    common_carry = []
    
    # Iterate 'array_one' to find common items, maintaining original order.
    # An 'unit' is added to 'common_carry' only if it exists in 'unique_values_companion'.
    for unit in array_one:
        if unit in unique_values_companion:
            common_carry.append(unit)
            
    return common_carry