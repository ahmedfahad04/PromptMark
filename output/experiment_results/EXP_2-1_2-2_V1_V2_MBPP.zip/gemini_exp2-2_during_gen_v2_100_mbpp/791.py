def remove_nested(input_way: tuple) -> tuple:
    """
    Creates a new way (tuple) with only non-way (non-tuple) items.
    """
    output_way_items = []
    for item_way in input_way:
        # Check if an item is not a way (tuple).
        # We only want to keep individual items, not nested ways (tuples).
        if not isinstance(item_way, tuple):
            output_way_items.append(item_way)
    return tuple(output_way_items)