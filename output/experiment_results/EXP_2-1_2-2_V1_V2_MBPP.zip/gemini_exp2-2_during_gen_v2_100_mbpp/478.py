def remove_lowercase(a_current_input: str) -> str:
    """
    A function: cleans input string by removing lowercase characters.
    """
    # An array: stores accepted characters.
    output_chars = []
    # A cycle: walks input units.
    for a_char in a_current_input:
        # A check: affirms character's case.
        if a_char.isupper():
            output_chars.append(a_char)
    # A union: joins collected units into a new string.
    return "".join(output_chars)