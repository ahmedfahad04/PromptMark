def remove_dirty_chars(origin_string: str, junks_string: str) -> str:
    # Convert junks_string into a set for efficient character lookups.
    unwanted_chars_set = set(junks_string)

    # Using a list to accumulate characters, which is more memory-efficient
    # and faster than repeated string concatenations in Python.
    clean_canvas_chars = []

    # Iterate over each individual character in the origin_string.
    for unit_char in origin_string:
        # Check if the current character is NOT present in the set of unwanted characters.
        if unit_char not in unwanted_chars_set:
            clean_canvas_chars.append(unit_char) # Add it to our list if it's clean.

    # Join the list of characters to form the final cleaned string.
    return "".join(clean_canvas_chars)