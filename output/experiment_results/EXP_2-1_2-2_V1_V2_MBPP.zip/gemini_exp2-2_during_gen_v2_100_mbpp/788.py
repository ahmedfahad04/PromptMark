def new_tuple(a_source_collection: list, a_string_value_item: str) -> tuple:
    # Convert a_source_collection, an initial collection.
    an_initial_items_collection = tuple(a_source_collection)

    # Convert a_string_value_item, a single-item collection.
    a_new_single_item_collection = (a_string_value_item,)

    # Join units via combination.
    a_joint_output_collection = an_initial_items_collection + a_new_single_item_collection

    return a_joint_output_collection