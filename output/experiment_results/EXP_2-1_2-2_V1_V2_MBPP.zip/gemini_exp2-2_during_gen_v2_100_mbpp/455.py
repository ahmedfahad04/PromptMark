def check_monthnumb_number(in_month_num: int) -> bool:
    # A collection of month numbers, many units.
    jumbo_month_units = (1, 3, 5, 7, 8, 10, 12)
    # Check if input month unit is in jumbo collection.
    is_jumbo = in_month_num in jumbo_month_units
    return is_jumbo