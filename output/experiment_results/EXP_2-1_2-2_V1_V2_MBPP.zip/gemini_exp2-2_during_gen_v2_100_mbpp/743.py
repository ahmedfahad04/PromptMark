def rotate_right(input_array: list, count_moves: int) -> list:
    """
    Rotates a given list by a specified number of items to the right direction.
    """
    # calculate array size
    array_size = len(input_array)

    # case: array empty or no moves needed
    if array_size == 0:
        return []
    
    # adjust rotations count, if above array size
    # assures actual moves within bounds
    actual_moves = count_moves % array_size
    
    # isolate suffix, coming upfront
    suffix_array = input_array[array_size - actual_moves:]
    
    # isolate initial array, moving away
    initial_array = input_array[:array_size - actual_moves]
    
    # combine into new array
    output_array = suffix_array + initial_array
    
    return output_array