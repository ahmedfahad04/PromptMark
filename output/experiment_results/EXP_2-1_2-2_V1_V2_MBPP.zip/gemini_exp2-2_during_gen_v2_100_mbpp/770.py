def odd_num_sum(n_input: int) -> int:
    # Overall sum, initial unit is nil.
    current_sum = 0

    # Walk n_input many, obtaining initial odd numbers.
    for i_count in range(1, n_input + 1):
        # Ascertain current odd number.
        current_odd_num = 2 * i_count - 1
        
        odd_val_calc = current_odd_num ** 4 
        
        # Accumulate into overall sum.
        current_sum += odd_val_calc
    
    return current_sum