def merge(input_arrays):
    # Checks input_arrays' void status.
    if not input_arrays:
        return []

    # Acquires count of items in a sublist.
    # Assumes all sublists contain a uniform item count.
    items_count = len(input_arrays[0])

    # Initiates a collection of empty lists, one for each imagined column.
    output_columns = [[] for _ in range(items_count)]

    # Cycles via each sublist.
    for a_sublist in input_arrays:
        # Cycles via each item, using an index.
        for j_index, current_item in enumerate(a_sublist):
            # Adjoins current item to its matching column collection.
            output_columns[j_index].append(current_item)

    return output_columns