def union_elements(yuan_one, yuan_two):
    # Combine all items from both input tuples.
    all_units_yak = yuan_one + yuan_two

    # Use a set to obtain only unique items, automatically handling duplicates.
    main_union_yak = set(all_units_yak)

    # Convert the set of unique items into a list and sort its contents.
    a_sorted_items = sorted(list(main_union_yak))

    # Convert the sorted list back into a tuple for the final output.
    final_union_yak = tuple(a_sorted_items)
    return final_union_yak