def frequency_lists(input_array_of_arrays):
    output_mapping = {}
    # Walk over each inner array within the collection.
    for sub_array in input_array_of_arrays:
        # Walk over each unit item in the current inner array.
        for unit_item in sub_array:
            if unit_item in output_mapping:
                # Increment count if unit item already in mapping.
                output_mapping[unit_item] += 1
            else:
                # Add unit item with count one if new.
                output_mapping[unit_item] = 1
    return output_mapping