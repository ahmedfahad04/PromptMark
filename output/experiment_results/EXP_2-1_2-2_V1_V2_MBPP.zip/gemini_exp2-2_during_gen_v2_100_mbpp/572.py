import collections

def two_unique_nums(input_array: list[int]) -> list[int]:
    """
    Yields a new array containing only numbers that occur one time
    in the input array, maintaining their original order.
    """
    # Acquiring item counts within the input array.
    counts_map = collections.Counter(input_array)
    
    # Initializing an array for unique items.
    output_array = []
    
    # Adding one-occurrence items to the output array.
    # Checks each number in its original order.
    for current_num in input_array:
        if counts_map[current_num] == 1:
            output_array.append(current_num)
            
    return output_array