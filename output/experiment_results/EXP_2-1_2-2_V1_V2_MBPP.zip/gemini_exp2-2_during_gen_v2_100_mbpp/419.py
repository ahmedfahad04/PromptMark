def round_and_sum(many_nums_in):
    # Collects all input numbers, converting each to its nearest whole value.
    a_whole_nums_yay = [round(a_num) for a_num in many_nums_in]

    # Calculates a sum of the whole numbers.
    a_sum_many_nums_yay = sum(a_whole_nums_yay)

    # Counts items within the input.
    many_nums_count = len(many_nums_in)

    # Computes the main output value.
    main_output_value_yay = a_sum_many_nums_yay * many_nums_count

    return main_output_value_yay