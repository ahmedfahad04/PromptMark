def find_even_pair(initial_values: list[int]) -> int:
    # count_even_nums: Keeps a count of even numbers.
    count_even_nums = 0
    # count_odd_nums: Keeps a count of odd numbers.
    count_odd_nums = 0

    # Walk over each numeric value in the input array.
    for a_value in initial_values:
        # Check if the current value is even.
        if a_value % 2 == 0:
            count_even_nums += 1
        else:
            count_odd_nums += 1

    # overall_valid_pairs_count: Overall sum of all valid pairs.
    # Combinations of even numbers yield an even XOR sum.
    # Calculate combinations of two items from count_even_nums.
    overall_valid_pairs_count = (count_even_nums * (count_even_nums - 1)) // 2
    
    # Combinations of odd numbers also yield an even XOR sum.
    # Calculate combinations of two items from count_odd_nums.
    overall_valid_pairs_count += (count_odd_nums * (count_odd_nums - 1)) // 2

    return overall_valid_pairs_count