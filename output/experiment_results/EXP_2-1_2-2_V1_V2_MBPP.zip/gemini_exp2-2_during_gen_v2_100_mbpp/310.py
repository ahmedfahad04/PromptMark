def string_to_tuple(any_input_value):
    # yields an output collection of chars, omitting spaces
    output_char_values = tuple(a_char for a_char in any_input_value if a_char != ' ')
    return output_char_values