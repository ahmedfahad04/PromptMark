def find_solution(an_a, an_b, an_n):
    # This utility aims to identify non-negative integer solutions (x, y)
    # for the equation ax + by = n.

    # Option 1: an_a is 0.
    if an_a == 0:
        if an_b == 0:
            if an_n == 0:
                # 0*x + 0*y = 0 yields infinite solutions. (0,0) is a valid option.
                return (0, 0)
            else:
                # 0*x + 0*y = n (n != 0) yields no solution.
                return None
        else: # an_b is not 0
            if an_n % an_b == 0:
                # 0*x + an_b*y = an_n. We can pick x = 0.
                an_y_output = an_n // an_b
                if an_y_output >= 0: # Check for non-negative y.
                    return (0, an_y_output)
            return None
    
    # Option 2: an_b is 0 (an_a is not 0, as handled above).
    if an_b == 0:
        if an_n % an_a == 0:
            # an_a*x + 0*y = an_n. We can pick y = 0.
            an_x_output = an_n // an_a
            if an_x_output >= 0: # Check for non-negative x.
                return (an_x_output, 0)
        return None

    # Option 3: Both an_a and an_b are non-zero.
    # We look for non-negative integer solutions.
    # Max x is when y=0, so ax <= n implies x <= n/a.
    
    an_max_x_input = an_n // an_a 

    for an_current_x_input in range(an_max_x_input + 1):
        # Calculate 'n - ax' value
        an_current_sum_val = an_n - (an_a * an_current_x_input)

        # Check if 'an_current_sum_val' is non-negative and divisible by 'an_b'.
        if an_current_sum_val >= 0 and an_current_sum_val % an_b == 0:
            an_y_option = an_current_sum_val // an_b
            # an_y_option is non-negative if an_current_sum_val is non-negative
            # and an_b is positive, as is customary with input checks.
            return (an_current_x_input, an_y_option)

    # If no solution is found after checking all valid 'x' values.
    return None