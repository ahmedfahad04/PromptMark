def subject_marks(input_units_collection):
    """
    Sorts a collection of units (tuples) using the numeric unit value.
    Input units collection is a list of tuples, where each tuple
    contains an item name and its associated numeric value.
    """
    # Obtain a sorted collection of units, using the second value (index 1)
    # of each current unit for comparison.
    sorted_units_output = sorted(input_units_collection, key=lambda current_unit: current_unit[1])
    return sorted_units_output