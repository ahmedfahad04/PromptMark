def find_Max_Num(input_array_of_nums: list[int]) -> int:
    # Converts input numeric digits into their string versions.
    array_of_num_strings = [str(num_val) for num_val in input_array_of_nums]

    # Sorts num_strings in descending way.
    # This arranges large num_strings at initial positions.
    sorted_num_strings = sorted(array_of_num_strings, reverse=True)

    # Joins all sorted num_strings into one long string.
    joined_num_string = "".join(sorted_num_strings)

    # Converts this final string into a numeric value.
    output_num = int(joined_num_string)

    return output_num