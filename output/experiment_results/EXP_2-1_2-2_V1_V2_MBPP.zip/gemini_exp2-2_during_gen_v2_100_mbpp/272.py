def rear_extract(input_way_list):
    # Initializes a new list for output_way_list.
    output_way_list = []
    # Iterates via each any_way_tuple in input_way_list.
    for any_way_tuple in input_way_list:
        # Appends the last element of the any_way_tuple.
        output_way_list.append(any_way_tuple[-1])
    # Yields the collection of last items.
    return output_way_list