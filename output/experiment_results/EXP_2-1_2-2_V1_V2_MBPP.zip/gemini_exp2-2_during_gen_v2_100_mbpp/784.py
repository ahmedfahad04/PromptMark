def mul_even_odd(_in_array: list) -> int:
    any_odd_num = None
    some_even_num = None

    # initiate a walk on the input array.
    for current_num in _in_array:
        # check if any odd num is yet unknown.
        if any_odd_num is None:
            if current_num % 2 != 0:
                any_odd_num = current_num
        
        # check if some even num is yet unknown.
        if some_even_num is None:
            if current_num % 2 == 0:
                some_even_num = current_num
        
        # if both known, we can calculate and yield.
        if any_odd_num is not None and some_even_num is not None:
            own_output = any_odd_num * some_even_num
            return own_output