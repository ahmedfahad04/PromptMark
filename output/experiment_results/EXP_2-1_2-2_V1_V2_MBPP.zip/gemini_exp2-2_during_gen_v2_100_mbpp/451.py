def remove_whitespaces(input_string: str) -> str:
    """
    Creates a new string, removing all whitespace characters.
    It splits the original string by any whitespace and joins the resulting parts
    without any separator, effectively consolidating multiple spaces, tabs,
    and newlines into nothing.
    """
    output_clean_string = "".join(input_string.split())
    return output_clean_string