def extract_singly(incoming_array_collection: list[tuple]) -> set[int]:
    """
    Unifies a list of arrays (tuples) into a single collection of unique numbers.
    """
    output_unique_items_storage = set()  # initiate an empty set
    for current_array_slice in incoming_array_collection:  # navigate among each array unit
        for current_item_value in current_array_slice:  # analyze individual numeric item
            output_unique_items_storage.add(current_item_value) # add current item value to set
    return output_unique_items_storage