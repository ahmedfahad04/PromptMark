def list_split(any_array, n):
    """
    Splits an incoming array into n sub-arrays, assigning items cyclically.
    """
    # Make a collection of n new arrays.
    output_collection = [[] for _ in range(n)]

    for current_index, item_value in enumerate(any_array):
        # Index of sub-array.
        sublist_index = current_index % n
        output_collection[sublist_index].append(item_value)
    
    return output_collection