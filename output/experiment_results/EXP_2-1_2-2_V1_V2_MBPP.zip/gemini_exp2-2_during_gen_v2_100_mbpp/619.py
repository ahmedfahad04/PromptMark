def move_num(incoming_string: str) -> str:
    # Composes two separate lists: one for alphabetic chars, one for numeric chars.
    alpha_units = []
    numeric_units = []

    # Walks over incoming string, categorizing each char.
    for a_char in incoming_string:
        if a_char.isdigit():
            numeric_units.append(a_char)
        else:
            alpha_units.append(a_char)
    
    # Unites the alpha chars with numeric chars appended at the end.
    return "".join(alpha_units) + "".join(numeric_units)