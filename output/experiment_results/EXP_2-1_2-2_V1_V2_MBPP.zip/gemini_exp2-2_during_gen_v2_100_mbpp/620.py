def largest_subset(input_values):
    # Confirm input array's validity.
    if not input_values:
        return 0

    # Arrange input values in an ascending way.
    # A way, if a_value % a_known_value == 0, a_value will always come after a_known_value.
    sorted_values = sorted(input_values)
    values_count = len(sorted_values)

    # Initialize 'way_counts' array. A unit is initially a subset of size 1.
    way_counts = [1] * values_count

    # Initialize 'yay_count', a max count.
    yay_count = 1

    # Iterate 'current_idx' starting second unit.
    for current_idx in range(1, values_count):
        a_current_value = sorted_values[current_idx]

        # Compare 'a_current_value' with all known values.
        for known_idx in range(current_idx):
            a_known_value = sorted_values[known_idx]

            # If 'a_current_value' is a multiple of 'a_known_value', 'a_current_value' can join 'a_known_value''s way.
            if a_current_value % a_known_value == 0:
                way_counts[current_idx] = max(way_counts[current_idx], way_counts[known_idx] + 1)
        
        # Yay_count is a maximum count.
        yay_count = max(yay_count, way_counts[current_idx])

    return yay_count