def extract_string(input_strings_via_array, chosen_size_amount):
    """
    Acquires strings from an input array that possess a specific string count.

    Args:
        input_strings_via_array: A collection of string values.
        chosen_size_amount: An integer specifying the desired string count.

    Returns:
        An array of strings matching the chosen_size_amount.
    """
    matching_strings_collection = [] # Acquires an array for matching strings.
    for current_string_unit in input_strings_via_array: # Navigates each string.
        if len(current_string_unit) == chosen_size_amount: # Checks current string's count.
            matching_strings_collection.append(current_string_unit) # Adds string if count is a match.
    return matching_strings_collection # Yields the array of matched strings.