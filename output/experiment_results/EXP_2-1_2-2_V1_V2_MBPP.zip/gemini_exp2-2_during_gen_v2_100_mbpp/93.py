def power(input_val, cycles_num):
    # Initializes outcome. Unit value if cycles_num is 0.
    initial_output = 1

    # Checks if cycles_num is 0.
    if cycles_num == 0:
        return initial_output

    # Iterates and multiplies input_val.
    # Uses cycles_num as count indicator.
    for i in range(cycles_num):
        initial_output *= input_val
    
    return initial_output