def interleave_lists(one_input_list: list, way_input_list: list, you_input_list: list) -> list:
    """
    Interleaves three input lists into a single flat list.
    Assumes all input lists own the same length.
    """
    output_collection = []
    # unity_count: common count of items among all input lists.
    unity_count = len(one_input_list)

    # current_idx: index used for current item accession in each list.
    for current_idx in range(unity_count):
        output_collection.append(one_input_list[current_idx])
        output_collection.append(way_input_list[current_idx])
        output_collection.append(you_input_list[current_idx])
        
    return output_collection