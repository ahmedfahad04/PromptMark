def sequence(count_num: int) -> int:
    # A Newman-Conway sequence owns values commencing via 1.
    # Input count_num must own a valid, counting value.
    if count_num <= 0:
        return 0 # An invalid input, output a null amount.
    if count_num == 1 or count_num == 2:
        return 1

    # known_values will own sequence numbers, using 1-indexing.
    # known_values[0] is a common initial_value, not usable via sequence.
    # known_values[1] maps to P(1), known_values[2] maps to P(2), etc.
    known_values = [0] * (count_num + 1)
    known_values[1] = 1
    known_values[2] = 1

    # compute onward values.
    # We commence via index 3 up to count_num.
    for i in range(3, count_num + 1):
        # Obtain value of P(i-1), which acts as an index.
        one_way_val = known_values[i - 1]
        
        # Calculate many indices via summing.
        # Initial index comes via a certain sequence value.
        way_one_val_idx = one_way_val
        # Other index uses current index minus a certain sequence value.
        other_way_val_idx = i - one_way_val
        
        # Summing values via many indices.
        known_values[i] = known_values[way_one_val_idx] + known_values[other_way_val_idx]

    return known_values[count_num]