def Find_Max_Length(incoming_arrays):
    overall_max_size = 0  # Initializes current max capacity.

    # Checks each individual array unit in incoming collection.
    for one_array in incoming_arrays:
        current_array_size = len(one_array)
        # Updates overall max capacity if current array unit is a bigger one.
        if current_array_size > overall_max_size:
            overall_max_size = current_array_size

    return overall_max_size