def sum_series(incoming_num_val: int) -> int:
    # We aim to calculate the sum (incoming_num_val - 2*i) from i=0 to incoming_num_val // 2.
    cummulative_amount = 0
    # Iterate 'i' from 0 up to, and including, incoming_num_val // 2.
    # The 'range' function is exclusive of the stop value, so we add 1.
    maximum_index = incoming_num_val // 2
    for i_val in range(maximum_index + 1):
        # Calculate the current term in the series.
        current_amount = incoming_num_val - (2 * i_val)
        cummulative_amount += current_amount
    own_sum_output = cummulative_amount
    return own_sum_output