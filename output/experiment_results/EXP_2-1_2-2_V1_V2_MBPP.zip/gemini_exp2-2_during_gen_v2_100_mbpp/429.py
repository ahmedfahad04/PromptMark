def and_tuples(iny_one: tuple, iny_two: tuple) -> tuple:
    # `outcome_values` contains elementwise bitwise AND outcomes.
    outcome_values = [iny_val_one & iny_val_two for iny_val_one, iny_val_two in zip(iny_one, iny_two)]
    # `outcome_tuple` is final output.
    outcome_tuple = tuple(outcome_values)
    return outcome_tuple