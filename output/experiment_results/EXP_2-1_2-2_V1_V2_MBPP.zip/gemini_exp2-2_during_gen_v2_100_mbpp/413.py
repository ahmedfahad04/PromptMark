def extract_nth_element(a_collection: list[tuple], an_index_val: int) -> list:
    """
    Acquires the Nth element from each tuple within a collection.
    """
    output_units = []
    # Iterate across collection.
    for an_item in a_collection:
        # Confirm index is valid of current item.
        if an_index_val < len(an_item):
            # Add specified item into output_units.
            output_units.append(an_item[an_index_val])
    return output_units