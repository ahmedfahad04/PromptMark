def list_to_float(input_array_of_arrays):
    """
    Converts all numeric-like items in a list of lists/tuples to floats.
    Items that cannot be converted remain in their original type.
    """
    outcome_array = []
    for current_inner_array in input_array_of_arrays:
        new_inner_array = []
        for current_item in current_inner_array:
            try:
                # Attempt conversion to float.
                new_inner_array.append(float(current_item))
            except ValueError:
                # If conversion fails, keep original item.
                new_inner_array.append(current_item)
        # Convert inner list back to a tuple to match input/output structure.
        outcome_array.append(tuple(new_inner_array))
    return outcome_array