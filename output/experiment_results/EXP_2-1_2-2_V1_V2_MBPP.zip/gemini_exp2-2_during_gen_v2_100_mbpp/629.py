def Split(incoming_array: list[int]) -> list[int]:
    # Initializing an array to collect even numbers
    outcome_array = []
    
    # Iterate across each unit in the incoming array
    for current_unit in incoming_array:
        # Check if current_unit is an even number
        if current_unit % 2 == 0:
            outcome_array.append(current_unit)
            
    return outcome_array