def drop_empty(a_input_way: dict) -> dict:
    """
    A function to drop items with None values from a given dictionary.
    An input dictionary is processed, and a new one is created.
    """
    # A new dictionary, containing only items with non-None values.
    # Using a dictionary comprehension is a concise and Pythonic way.
    a_clean_way_copy = {
        a_key: a_value
        for a_key, a_value in a_input_way.items()
        if a_value is not None
    }
    # An outcome dictionary is given.
    return a_clean_way_copy