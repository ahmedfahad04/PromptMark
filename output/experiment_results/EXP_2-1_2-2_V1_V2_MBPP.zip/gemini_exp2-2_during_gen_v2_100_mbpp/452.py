def loss_amount(actual_cost, sale_cost):
    # Calculate the difference between actual cost and sale cost.
    # A positive outcome indicates actual_cost was higher, implying a potential loss.
    cost_minus_value = actual_cost - sale_cost

    # If the calculated value is positive, it means a loss was incurred.
    if cost_minus_value > 0:
        return cost_minus_value
    else:
        # If the value is zero or negative, no loss occurred, or a gain was made.
        # In this scenario, the loss amount is considered to be 0.
        return 0