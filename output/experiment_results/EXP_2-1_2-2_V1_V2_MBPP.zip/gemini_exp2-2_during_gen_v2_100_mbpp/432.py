def median_trapezium(one_way_side: float, any_way_side: float, an_unused_input: float) -> float:
    # compute sum of ways
    ways_sum_amount = one_way_side + any_way_side
    
    # calculate average value
    calculated_median = ways_sum_amount / 2.0
    
    return calculated_median