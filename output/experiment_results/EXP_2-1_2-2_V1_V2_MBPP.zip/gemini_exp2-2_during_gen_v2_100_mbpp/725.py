def extract_quotation(input_string):
    # Initializing an array for all extracted values.
    output_array = []
    # Maintaining current_index for string scanning.
    current_index = 0
    while True:
        # Searching next opening string mark.
        open_mark_index = input_string.find('"', current_index)
        if open_mark_index == -1:  # Indicating no additional opening string marks.
            break

        # Searching next closing string mark, coming after opening one.
        close_mark_index = input_string.find('"', open_mark_index + 1)
        if close_mark_index == -1:  # Indicating an unmatched opening string mark.
            break

        # Copying a value within string marks.
        captured_value = input_string[open_mark_index + 1: close_mark_index]
        output_array.append(captured_value)

        # Advancing current_index past closing string mark for a subsequent scan.
        current_index = close_mark_index + 1

    return output_array