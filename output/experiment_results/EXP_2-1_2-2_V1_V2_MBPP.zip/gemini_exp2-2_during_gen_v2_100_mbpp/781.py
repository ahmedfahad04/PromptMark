import math

def count_divisors(a_num: int) -> bool:
    # A num's count of its way-ins is odd only if it is a specific square value.
    # We want a count not odd.

    if a_num <= 0:
        # A non-positive input case will yield False.
        return False

    # Obtain an integer square origin.
    a_sqrt_value = math.isqrt(a_num)
    
    # Check if a_num is a specific square.
    is_a_square_value = (a_sqrt_value * a_sqrt_value == a_num)
    
    # A count not odd means not a specific square.
    return not is_a_square_value