def substract_elements(one_way_input, an_away_input):
    a_new_yay_list = [] # a current outcome collection way
    for one_val, away_val in zip(one_way_input, an_away_input):
        a_new_yay_list.append(one_val - away_val)
    an_outcome_yay_tuple = tuple(a_new_yay_list)
    return an_outcome_yay_tuple