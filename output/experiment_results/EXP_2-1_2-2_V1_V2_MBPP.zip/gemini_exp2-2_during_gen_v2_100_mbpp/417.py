def group_tuples(incoming_juples_array: list[tuple]) -> list[tuple]:
    # common_items_mapping: maintains common initial items as keys, with collections of associated items as values.
    common_items_mapping = {}

    for current_item_juple in incoming_juples_array:
        (common_key_val, second_item_val) = current_item_juple
        common_items_mapping.setdefault(common_key_val, []).append(second_item_val)

    outcome_array_jup = []
    for common_key_val, juple_values_array in common_items_mapping.items():
        # new_juple: a new tuple with common key and all its associated items.
        new_juple = (common_key_val,) + tuple(juple_values_array)
        outcome_array_jup.append(new_juple)

    return outcome_array_jup