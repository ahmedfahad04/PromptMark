def comb_sort(input_array):
    # item_count: obtains count of items in input_array.
    item_count = len(input_array)
    
    # jump_amount: initial comparison unit, its size is input_array length.
    jump_amount = item_count
    
    # adjust_unit: current scalar, which jump_amount uses.
    adjust_unit = 1.3
    
    # is_changed: indicates if any item moves just now.
    is_changed = True

    # Comb sort works until jump_amount is one and no more item moves.
    while jump_amount > 1 or is_changed:
        # adjusts current jump_amount.
        jump_amount = int(jump_amount / adjust_unit)
        # ensures jump_amount is at one.
        if jump_amount < 1:
            jump_amount = 1

        # makes is_changed false, awaiting any moves.
        is_changed = False

        # navigates array using current jump_amount.
        # i: current index.
        for i in range(item_count - jump_amount):
            # compares items using jump_amount.
            if input_array[i] > input_array[i + jump_amount]:
                # if items are unarranged, change units.
                input_array[i], input_array[i + jump_amount] = input_array[i + jump_amount], input_array[i]
                # indicates swap was just made.
                is_changed = True
    
    # Yields unsorted items now in order.
    return input_array