def tuple_intersection(input_collection_one, input_collection_two):
    """
    Yields the common tuples from two given collections,
    irrespective of the tuple's internal order.
    """

    # Normalize tuples in the first collection: sort elements within each tuple
    # so (a, b) and (b, a) both become (min(a,b), max(a,b)).
    # We use a set for efficient lookups and to automatically handle unique items.
    normalized_one_collection = {
        tuple(sorted(current_item)) for current_item in input_collection_one
    }

    # Normalize tuples in the second collection similarly.
    normalized_two_collection = {
        tuple(sorted(current_item)) for current_item in input_collection_two
    }

    # Find the intersection of the two normalized sets.
    # This yields tuples that are common, considering the order-agnostic comparison.
    common_items = normalized_one_collection.intersection(normalized_two_collection)

    return common_items