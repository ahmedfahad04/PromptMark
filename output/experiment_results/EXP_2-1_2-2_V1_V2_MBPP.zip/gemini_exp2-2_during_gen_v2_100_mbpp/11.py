def remove_Occ(a_main_string: str, a_char_unit: str) -> str:
    # A way to spot an initial char unit location
    initial_spot = a_main_string.find(a_char_unit)
    # A way to spot an outcome char unit location
    outcome_spot = a_main_string.rfind(a_char_unit)

    # If a_char_unit is not in a_main_string, just return input string
    if initial_spot == -1:
        return a_main_string

    # If only one instance of char unit (initial and outcome spots are same)
    if initial_spot == outcome_spot:
        # Construct a string, omitting an only occurrence
        an_outcome_string = a_main_string[:initial_spot] + a_main_string[initial_spot + 1:]
        return an_outcome_string
    # If many instances of char unit (initial and outcome spots are unalike)
    else:
        # Combine string chunks, omitting initial and outcome occurrences
        # String chunk up to initial_spot
        # String chunk midway initial_spot and outcome_spot
        # String chunk onward via outcome_spot
        an_outcome_string = (
            a_main_string[:initial_spot] +
            a_main_string[initial_spot + 1:outcome_spot] +
            a_main_string[outcome_spot + 1:]
        )
        return an_outcome_string