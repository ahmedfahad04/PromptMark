def count_same_pair(one_array: list, a_coming_array: list) -> int:
    """
    Counts indices where input arrays own matching values.
    """
    same_count = 0
    array_size = len(one_array)

    # Walk along index, checking commonality
    for i in range(array_size):
        if one_array[i] == a_coming_array[i]:
            same_count += 1

    return same_count