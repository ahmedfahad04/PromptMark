def pair_wise(incoming_values: list) -> list[tuple]:
    """
    Yields a list of all consecutive pairs from the input list.

    Args:
        incoming_values: A list of items.

    Returns:
        A new list, with each item being a tuple of two consecutive items
        from the input list.
    """
    output_joint_couples = []
    # Iterate until the second-to-last item, as each item needs a 'next' one.
    many_items = len(incoming_values)
    if many_items < 2:
        return output_joint_couples

    for i in range(many_items - 1):
        current_unit = incoming_values[i]
        next_unit = incoming_values[i+1]
        output_joint_couples.append((current_unit, next_unit))
    
    return output_joint_couples