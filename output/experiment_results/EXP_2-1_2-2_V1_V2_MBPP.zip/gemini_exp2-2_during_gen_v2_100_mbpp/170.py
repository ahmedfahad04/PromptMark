def sum_range_list(a_collection_items, an_initial_index, an_ultimate_index):
    current_sum = 0
    # Walk among indices, involving an ultimate index.
    for an_index in range(an_initial_index, an_ultimate_index + 1):
        # Add value into current sum.
        current_sum = current_sum + a_collection_items[an_index]
    return current_sum