def test_three_equal(one_num, any_num, some_num):
    # Initializing count for similar values.
    count_val = 0

    if one_num == any_num and any_num == some_num:
        # All three values are identical.
        count_val = 3
    elif one_num == any_num or one_num == some_num or any_num == some_num:
        # Just two values are identical.
        count_val = 2
    # current value is 0 if no matches.

    return count_val