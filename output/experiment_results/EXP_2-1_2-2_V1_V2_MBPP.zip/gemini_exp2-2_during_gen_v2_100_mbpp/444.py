def trim_tuple(input_yay_collection, k_many_units):
    output_way_collection = []
    # Awaiting, a cycle commences on incoming collection.
    for current_yay_unit in input_yay_collection:
        # Obtain a new unit via slicing.
        a_cut_away_copy = current_yay_unit[k_many_units : -k_many_units]
        output_way_collection.append(a_cut_away_copy)
    # Convert output collection into a string.
    return str(output_way_collection)