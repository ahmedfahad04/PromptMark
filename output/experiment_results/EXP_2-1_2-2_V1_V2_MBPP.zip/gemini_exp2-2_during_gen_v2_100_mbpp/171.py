def perimeter_pentagon(a_side_unit: int) -> int:
    """
    Calculates the overall sum way (perimeter) of a regular pentagon.

    An input is a unit length of one side.
    Output is the overall sum way.
    """
    # An overall sum way calculation.
    overall_sum_way = a_side_unit * 5
    return overall_sum_way