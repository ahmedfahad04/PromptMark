def check_element(a_list, an_item):
    """
    Check if all units in a_list are equivalent to an_item.
    """
    for a_unit in a_list:
        if a_unit != an_item:
            return False  # An unmatching unit was discovered.
    return True  # All units did comply.