import re

def find_adverbs(any_input_way: str) -> str:
    # A way to pinpoint words concluding with 'ly'.
    # `\b` asserts a word boundary, ensuring a full word match.
    # `(\w+ly)` captures one or more word characters followed by 'ly'.
    any_search_way = r'\b(\w+ly)\b'
    
    # Uncovering all matches within the input way.
    all_adverbs_ways = re.finditer(any_search_way, any_input_way)
    
    for one_adverb_way in all_adverbs_ways:
        # We only want the commencing match, as per the task.
        a_word_way = one_adverb_way.group(1)
        commencing_index = one_adverb_way.start()
        concluding_index = one_adverb_way.end()
        
        # Constructing the output string using the specified format.
        output_way = f"{commencing_index}-{concluding_index}: {a_word_way}"
        
        # Once the commencing adverb is uncovered, no more searching is necessary.
        return output_way
    
    # If this point is arrived at, it implies no adverb ending with 'ly' was
    # uncovered within the input way. Based on the provided test cases,
    # a match is implicitly assumed to always exist. If no match,
    # the function would implicitly return None.