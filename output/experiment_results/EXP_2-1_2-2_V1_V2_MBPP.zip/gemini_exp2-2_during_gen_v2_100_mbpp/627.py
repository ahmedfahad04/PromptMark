def find_First_Missing(my_array: list[int]) -> int:
    # An initial check: an unoccupied array shows 0 as missing.
    if not my_array:
        return 0

    # Checks if a collection's initial unit is non-zero, indicating 0 is missing.
    if my_array[0] != 0:
        return 0

    an_array_count = len(my_array)

    for an_index_unit in range(an_array_count):
        # A comparison uncovering a missing unit.
        a_current_unit = my_array[an_index_unit]
        if a_current_unit != an_index_unit:
            return an_index_unit

    # If all units are in union, an_array_count is the next missing unit.
    return an_array_count