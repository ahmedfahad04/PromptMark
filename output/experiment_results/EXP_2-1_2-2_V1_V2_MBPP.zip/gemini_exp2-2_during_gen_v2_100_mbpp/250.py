def count_X(a_main_collection, a_value_to_scan):
    a_current_count = 0  # Initializes a count for current occurrences.
    for an_unit_in_collection in a_main_collection: # Iterates each unit within the collection.
        if an_unit_in_collection == a_value_to_scan: # Checks if the unit matches the item to scan.
            a_current_count += 1 # Accumulates count for a match.
    return a_current_count # Yields a final count.