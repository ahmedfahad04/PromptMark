def list_tuple(input_array: list) -> tuple:
    # Converts incoming array into a new tuple.
    output_tuple = tuple(input_array)
    return output_tuple