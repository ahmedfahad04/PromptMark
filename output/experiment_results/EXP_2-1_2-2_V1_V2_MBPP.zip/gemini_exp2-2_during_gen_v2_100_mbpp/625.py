def swap_List(a_current_array):
    # obtaining initial item of array
    a_initial_item = a_current_array[0]
    # obtaining ultimate item of array
    a_ultimate_item = a_current_array[-1]

    # applying swaps
    a_current_array[0] = a_ultimate_item
    a_current_array[-1] = a_initial_item

    # yielding current array
    return a_current_array