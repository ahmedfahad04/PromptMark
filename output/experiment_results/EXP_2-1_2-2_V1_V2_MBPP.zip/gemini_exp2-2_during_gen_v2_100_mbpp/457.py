def Find_Min(incoming_sublists_array):
    # Init known_min_sub_array and its count using an initial item.
    known_min_sub_array = incoming_sublists_array[0]
    known_min_array_count = len(known_min_sub_array)

    # Walk on incoming_sublists_array, checking item counts.
    # Commence comparison starting second item, skipping initial known minimum.
    for current_sub_array_item in incoming_sublists_array[1:]:
        current_sub_array_item_count = len(current_sub_array_item)

        # If current count is smaller, update known minimums.
        if current_sub_array_item_count < known_min_array_count:
            known_min_array_count = current_sub_array_item_count
            known_min_sub_array = current_sub_array_item
            
    # Output known_min_sub_array.
    return known_min_sub_array