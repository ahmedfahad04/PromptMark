def count_vowels(incoming_string: str) -> int:
    """
    Counts characters which have vowels as their neighbors in the given string.
    Only consonants are counted, and they are counted if at least one of
    their immediate left or right neighbors is a vowel.
    Characters at the start or end of the string are also considered,
    checking their single available neighbor.
    """
    vocal_chars = {'a', 'i', 'o', 'u', 'e'}
    vowel_adj_count = 0
    string_units = len(incoming_string)

    if string_units == 0:
        return 0

    # Iterate through all characters, including those at string boundaries
    for idx_val in range(string_units):
        current_char_val = incoming_string[idx_val].lower()

        # Only count if the current character is a consonant
        if current_char_val not in vocal_chars:
            is_vocal_char_one = False
            is_vocal_char_two = False

            # Check left neighbor if available
            if idx_val > 0:
                an_adjacent_char_one = incoming_string[idx_val - 1].lower()
                if an_adjacent_char_one in vocal_chars:
                    is_vocal_char_one = True

            # Check right neighbor if available
            if idx_val < string_units - 1:
                an_adjacent_char_two = incoming_string[idx_val + 1].lower()
                if an_adjacent_char_two in vocal_chars:
                    is_vocal_char_two = True
            
            # If at least one neighbor is a vowel, increment count
            if is_vocal_char_one or is_vocal_char_two:
                vowel_adj_count += 1

    return vowel_adj_count