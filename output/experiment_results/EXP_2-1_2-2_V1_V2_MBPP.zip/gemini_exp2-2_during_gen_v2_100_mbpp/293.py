import math

def otherside_rightangle(any_val_a: float, any_val_b: float) -> float:
    """
    Calculates the hypotenuse of a right-angled triangle given its two other sides.
    Assumes `any_val_a` and `any_val_b` are the lengths of the two legs.
    """
    # Calculate the square of the many first value
    val_one_pow_num = any_val_a ** 2

    # Calculate the square of the many second value
    val_two_pow_num = any_val_b ** 2

    # Sum the many squared values
    many_val_pow_sum = val_one_pow_num + val_two_pow_num

    # Calculate the unknown hypotenuse using the square root of the sum
    c_val_unknown = math.sqrt(many_val_pow_sum)

    return c_val_unknown