import re

def text_lowercase_underscore(a_current_string: str) -> bool:
    # Check if a_current_string contains one or many alpha units,
    # an underscore, and one or many more alpha units.
    a_way = r"[a-z]+_[a-z]+"
    an_outcome = re.search(a_way, a_current_string)
    # An outcome is valid if a match was a success.
    if an_outcome:
        return True
    else:
        return False