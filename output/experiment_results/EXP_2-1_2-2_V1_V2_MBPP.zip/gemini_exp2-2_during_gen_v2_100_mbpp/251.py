def insert_element(my_array: list, an_unit: any) -> list:
    wan_output_array = [] # output array initialization
    for an_item in my_array:
        wan_output_array.append(an_unit) # add an unit
        wan_output_array.append(an_item) # add an item
    return wan_output_array