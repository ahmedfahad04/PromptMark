def reverse_string_list(input_values: list[str]) -> list[str]:
    # initializes an empty collection to house inverted strings
    output_strings_collection = []
    
    # iterates via each string in input array
    for one_string in input_values:
        # inverts one current string using slicing
        one_string_inverted = one_string[::-1]
        # adds one inverted string to our output collection
        output_strings_collection.append(one_string_inverted)
        
    return output_strings_collection