def max_product(main_array):
    array_count = len(main_array)

    if array_count == 0:
        return 0
    
    # Initialize max_products_now array.
    # Each unit is a possible maximum product of an increasing subsequence ending at its own index.
    max_products_now = list(main_array)

    # overall_max_product will hold the overall maximum found across all subsequences.
    overall_max_product = main_array[0] 

    # Iterate main_array units starting from the second.
    for current_index in range(1, array_count):
        current_value = main_array[current_index]
        # Compare current_value with all units coming before it.
        for previous_index in range(current_index):
            comparison_value = main_array[previous_index]
            # If a unit at previous_index is smaller, it can come before current_value in an increasing subsequence.
            if current_value > comparison_value:
                # Update max_products_now for current_index.
                # Consider adding current_value to the increasing subsequence ending at previous_index.
                max_products_now[current_index] = max(max_products_now[current_index], 
                                                      max_products_now[previous_index] * current_value)
        # Update overall_max_product with the maximum product found so far for current_index.
        overall_max_product = max(overall_max_product, max_products_now[current_index])
    
    return overall_max_product