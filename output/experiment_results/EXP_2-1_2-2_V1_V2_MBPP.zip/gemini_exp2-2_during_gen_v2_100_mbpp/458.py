def rectangle_area(a_width, y_size):
    # Obtaining area value.
    area_value = a_width * y_size
    return area_value