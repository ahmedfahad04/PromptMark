def count_rotation(input_array: list) -> int:
    """
    Counts the number of rotations an array underwent to become sorted.
    This is equivalent to finding the index of the minimum element.
    """
    array_len = len(input_array)

    # An array with no elements or one element is considered sorted with 0 rotations.
    if array_len == 0 or array_len == 1:
        return 0

    min_val = input_array[0]
    min_index = 0

    # Navigates via all elements to pinpoint the minimum.
    for i_val in range(array_len):
        current_val = input_array[i_val]
        if current_val < min_val:
            min_val = current_val
            min_index = i_val

    return min_index