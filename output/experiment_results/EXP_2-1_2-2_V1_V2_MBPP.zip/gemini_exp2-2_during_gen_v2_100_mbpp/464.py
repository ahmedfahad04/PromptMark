def check_value(input_map: dict, known_value: any) -> bool:
    # Check on individual map values.
    for a_value in input_map.values():
        # Confirm if a_value is not matching known_value.
        if a_value != known_value:
            # A mismatch confirms not all values comply.
            return False
    # All map values confirm match.
    return True