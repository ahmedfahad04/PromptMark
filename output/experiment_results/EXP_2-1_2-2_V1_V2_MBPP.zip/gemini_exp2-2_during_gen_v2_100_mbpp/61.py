def count_Substrings(input_string):
    amount_count = 0  # Initializes count of valid substrings.
    string_size = len(input_string) # Acquires input string's overall size.

    # Iterates over all possible starting positions (index 'i').
    for i in range(string_size):
        a_chunk_sum = 0 # Initializes sum for current substring, starting anew for each 'i'.

        # Iterates over all possible ending positions (index 'j') from 'i' onwards.
        for j in range(i, string_size):
            # Accumulates digit value for the character at current position 'j'.
            # Current digit value is converted to an integer from its string form.
            a_chunk_sum += int(input_string[j])

            # Calculates the current substring's length (size).
            a_chunk_size = j - i + 1

            # Compares the acquired sum of digits with the substring's size.
            if a_chunk_sum == a_chunk_size:
                amount_count += 1 # Increments the count if the condition is met.

    return amount_count