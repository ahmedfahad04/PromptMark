def square_nums(many_input_values: list[int]) -> list[int]:
    # Constructing a new container for outcomes.
    many_output_units = []

    # Cycling across many input units.
    for a_current_num in many_input_values:
        # Computing a unit's square.
        a_calculated_square = a_current_num * a_current_num
        many_output_units.append(a_calculated_square)

    return many_output_units