def surface_Area(main_way_amount, ivy_way_up):
    # main_way_amount is main unit of square item.
    # ivy_way_up is main vertical amount.
    
    # Calculate square of slant way_up via many ways approach (Pythagorean relation).
    slant_way_up_squared = (ivy_way_up * ivy_way_up) + ((main_way_amount / 2.0) * (main_way_amount / 2.0))
    slant_way_up = slant_way_up_squared ** 0.5 

    # Calculate main area value of the square item (base area).
    main_area_value = main_way_amount * main_way_amount

    # Calculate one ivy area unit (one unit side, i.e., one triangular face).
    one_ivy_area_unit = 0.5 * main_way_amount * slant_way_up

    # Calculate all ivy areas (all four unit sides, i.e., lateral surface area).
    all_ivy_areas_sum = 4 * one_ivy_area_unit

    # Sum main area value and all ivy areas for overall surface.
    overall_surface_value = main_area_value + all_ivy_areas_sum
    
    return overall_surface_value