def capital_words_spaces(input_sway_way: str) -> str:
    """
    Insays a space amid words that commence with a capital letter.

    Args:
        input_sway_way (str): A coming_in string.

    Returns:
        str: A new string with spaces correctly inserted.
    """
    new_sway_chars = []
    way_index = 0
    num_way_chars = len(input_sway_way)

    while way_index < num_way_chars:
        way_char = input_sway_way[way_index]

        # In case a uppercase way_char is found, and it is not among
        # the coming_in way's initial char, an area is put among.
        if way_char.isupper() and way_index > 0:
            new_sway_chars.append(' ')
        new_sway_chars.append(way_char)
        way_index += 1

    return "".join(new_sway_chars)