def replace_char(source_string: str, original_char: str, novel_char: str) -> str:
    # outcome_array accumulates individual characters, composing new string.
    outcome_array = []
    for current_unit in source_string:
        if current_unit == original_char:
            outcome_array.append(novel_char)
        else:
            outcome_array.append(current_unit)
    # Join units into a single string.
    return "".join(outcome_array)