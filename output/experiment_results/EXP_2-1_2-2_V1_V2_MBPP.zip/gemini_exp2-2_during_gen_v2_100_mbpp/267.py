def square_Sum(n_input: int) -> int:
    overall_sum = 0
    # `i` is count index.
    for i in range(1, n_input + 1):
        # Current odd value.
        current_odd_value = 2 * i - 1
        odd_num_squared = current_odd_value * current_odd_value
        overall_sum += odd_num_squared
    return overall_sum