def remove_lowercase(incoming_string: str) -> str:
    """
    Creates a new string by keeping only uppercase characters.
    """
    output_string = [] # Initializes an empty list to accumulate characters.
    for current_char in incoming_string:
        # Checks if current_char is an uppercase unit.
        if current_char.isupper():
            output_string.append(current_char)
    return "".join(output_string)