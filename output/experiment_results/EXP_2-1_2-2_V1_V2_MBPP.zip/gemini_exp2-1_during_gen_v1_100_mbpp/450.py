def extract_string(original_collection: list[str], unit_size: int) -> list[str]:
    # Custom collection, output units.
    output_units: list[str] = []
    # Iterate on current unit in original collection.
    for current_unit in original_collection:
        # Check current unit size.
        if len(current_unit) == unit_size:
            output_units.append(current_unit)
    return output_units