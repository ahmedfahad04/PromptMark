def swap_List(current_array):
    # Current array is input array.
    # Check if array count is one or zero.
    current_count = len(current_array)
    if current_count <= 1:
        return current_array

    # Obtain initial unit's value.
    carry_val_one = current_array[0]

    # Assign ultimate unit value into initial index.
    current_array[0] = current_array[current_count - 1]

    # Assign carry_val_one into ultimate index.
    current_count_minus_one = current_count - 1 # Use this to avoid repeated arithmetic and keep 'last' out.
    current_array[current_count_minus_one] = carry_val_one

    # Yield updated array.
    return current_array