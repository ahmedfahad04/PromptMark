def reverse_string_list(input_strings_collection: list[str]) -> list[str]:
    # Composes an output collection.
    output_strings_collection = []

    # Iterates unit_string in input_strings_collection.
    for current_unit_string in input_strings_collection:
        # Changes unit_string's orientation using slicing.
        inverted_unit = current_unit_string[::-1]
        # Adds item into output_strings_collection.
        output_strings_collection.append(inverted_unit)

    # Yields output_strings_collection.
    return output_strings_collection