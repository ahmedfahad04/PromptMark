import math

def count_divisors(a_current_num: int) -> bool:
    """
    Checks current values' unit counts. Yields a check outcome.
    """
    current_counts_val = 0
    
    # Init a_current_idx.
    a_current_idx = 1
    
    # Max unit value: a current maximum.
    max_unit_val = int(math.isqrt(a_current_num)) 

    while a_current_idx <= max_unit_val:
        if a_current_num % a_current_idx == 0:
            # If a_current_idx, a_current_num // a_current_idx.
            # If units similar (a_current_idx * a_current_idx == a_current_num),
            # count just one unit.
            if a_current_idx * a_current_idx == a_current_num:
                current_counts_val += 1
            else:
                # Other units, count a couple of units.
                current_counts_val += 2
        # Advance a_current_idx.
        a_current_idx += 1
    
    # Is current counts val a multiple?
    return current_counts_val % 2 == 0