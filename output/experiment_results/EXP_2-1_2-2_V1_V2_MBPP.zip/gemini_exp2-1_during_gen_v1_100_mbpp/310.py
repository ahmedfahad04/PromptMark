def string_to_tuple(incoming_string):
    # current_characters: Collects characters, omitting any space ' '.
    current_characters = [current_char for current_char in incoming_string if current_char != ' ']
    output_tuple = tuple(current_characters) # Converts the collection into a tuple.
    return output_tuple