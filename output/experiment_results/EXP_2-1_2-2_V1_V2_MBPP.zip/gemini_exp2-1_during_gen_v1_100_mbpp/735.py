def toggle_middle_bits(current_value: int) -> int:
    # Ascertain current_value's count of numeric_units.
    k_num_values = current_value.bit_length()

    # If current_value holds one or two numeric_units, no middle numeric_units exist.
    # Yield current_value unchanged.
    if k_num_values <= 2:
        return current_value

    # Calculate count of middle numeric_units.
    k_num_middle_values = k_num_values - 2

    # Construct middle numeric_units' current_mask.
    # This involves creating a sequence of '1's (count: k_num_middle_values)
    # and shifting them one position left to correctly align with middle numeric_units.
    k_middle_mask = ((1 << k_num_middle_values) - 1) << 1

    # Utilize current_value ^ k_middle_mask, impacting only middle numeric_units.
    current_outcome = current_value ^ k_middle_mask
    return current_outcome