def rectangle_area(a_width: int, a_height: int) -> int:
    """
    Calculates the area of a rectangle.

    An input 'a_width' defines the width of the rectangle.
    An input 'a_height' defines the height of the rectangle.
    """
    a_area = a_width * a_height
    return a_area