import sys

def Find_Min(collection_of_units: list[list]) -> list:
    # Check if the input collection is empty.
    # An empty collection yields an empty list as its minimal unit.
    if not collection_of_units:
        return []

    # Initialize the outcome's minimal unit with the initial unit.
    # Its length is also saved as the current minimal length.
    outcome_minimal_unit = collection_of_units[0]
    current_minimal_unit_length = len(outcome_minimal_unit)

    # Iterate units starting from the second one.
    # Compare each unit's length with the current minimal length.
    for current_unit in collection_of_units[1:]:
        current_unit_length = len(current_unit)
        if current_unit_length < current_minimal_unit_length:
            # Update if a unit with a smaller length is found.
            current_minimal_unit_length = current_unit_length
            outcome_minimal_unit = current_unit
            
    return outcome_minimal_unit