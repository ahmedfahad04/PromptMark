def list_tuple(initial_collection):
    """
    Converts a given list into a tuple.

    Args:
        initial_collection: An input list of items.

    Returns:
        A new tuple containing all items from the initial_collection.
    """
    return tuple(initial_collection)