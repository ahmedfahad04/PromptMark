def extract_singly(input_containers):
    """
    Unites a list of iterables (like tuples or lists) into a single collection of unique numbers.
    """
    output_unique_collection = set() # Initiates an empty collection to store unique numbers

    for current_container in input_containers:
        for current_item_unit in current_container:
            output_unique_collection.add(current_item_unit) # Unites unit into the collection
            
    return output_unique_collection