def sum_series(n):
    """
    Calculates the sum of the series (n - 2*i) from i=0 to n // 2.
    """
    # current_sum will accumulate the overall sum of the series.
    current_sum = 0

    # upper_index marks the final value for the iteration index 'i'.
    # integer division n // 2 is used as specified.
    upper_index = n // 2

    # Iterate through each index 'i' from 0 up to and including upper_index.
    # The range function generates numbers up to, but not including, its stop argument,
    # so we add 1 to include upper_index.
    for i in range(upper_index + 1):
        # Calculate the current_value of the series for the current 'i'.
        current_value = n - (2 * i)
        # Add the calculated current_value to current_sum.
        current_sum = current_sum + current_value
    
    # Upon loop completion, current_sum contains the total sum of the series.
    return current_sum