def check_value(input_map: dict, known_value) -> bool:
    # Check if input_map is vacant.
    # If so, output False as no items occur.
    if not input_map:
        return False

    # Iterate upon all items in input_map.
    for current_item in input_map.values():
        # If any current_item is unequal to known_value, immediately return False.
        if current_item != known_value:
            return False

    # If inner cycle completes, all items match known_value.
    return True