def sum_even_and_even_index(input_array: list) -> int:
    """
    Calculates the sum of even numbers which are located at even positions (indices)
    within an input list.
    """
    current_sum = 0  # Initial sum, accumulates values.
    # Iterate through the array, obtaining both index and value.
    for index, value_unit in enumerate(input_array):
        # Check if the current index is an even position AND
        # if the value at that position is an even number.
        if index % 2 == 0 and value_unit % 2 == 0:
            current_sum += value_unit  # Add the value to the current sum.
    return current_sum