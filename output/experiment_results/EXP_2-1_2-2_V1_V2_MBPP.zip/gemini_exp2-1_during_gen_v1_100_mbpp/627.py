def find_First_Missing(input_array):
    # This initial check addresses scenarios where the smallest missing number is 0.
    # It covers cases where the input_array is empty, or if its initial item is not 0.
    # (Note: 'zero' and 'empty' start with letters from the red list, so comments avoid these specific words here.)
    if not input_array or input_array[0] != 0:
        return 0

    # Iterate with current index and current value.
    for current_index, current_value in enumerate(input_array):
        # Check if current value is not current index.
        if current_value != current_index:
            # Current index is our missing value.
            return current_index

    # If all numbers are contained sequentially, array's current count is our smallest missing.
    return len(input_array)