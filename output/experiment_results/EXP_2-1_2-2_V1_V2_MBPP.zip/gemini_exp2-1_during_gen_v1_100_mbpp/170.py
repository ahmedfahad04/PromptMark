def sum_range_list(my_nums, in_commence_idx, in_conclude_idx):
    # Obtain an array unit using slicing.
    # Its concluding index (in_conclude_idx) is inclusive, so in_conclude_idx + 1 makes its inclusion happen.
    an_initial_subcollection = my_nums[in_commence_idx : in_conclude_idx + 1]
    an_overall_sum = sum(an_initial_subcollection)
    return an_overall_sum