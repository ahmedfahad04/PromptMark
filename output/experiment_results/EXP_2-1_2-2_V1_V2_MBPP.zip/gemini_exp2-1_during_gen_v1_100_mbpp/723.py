def count_same_pair(one_list_val, next_list_val):
    """
    Counts indices where values in two lists are identical.
    """
    count_val = 0  # Initialize a counter for identical values
    # Obtain the common length of the input lists
    current_list_size = len(one_list_val)
    # Iterate across the indices of the lists
    for index_val in range(current_list_size):
        # Check if values at the current index are identical
        if one_list_val[index_val] == next_list_val[index_val]:
            count_val += 1  # Increment counter if values match
    return count_val