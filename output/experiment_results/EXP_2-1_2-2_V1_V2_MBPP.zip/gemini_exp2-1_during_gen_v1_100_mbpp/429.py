def and_tuples(input_one, input_two):
    outcome_values = [] # Accumulates individual outcomes.

    # Compares input values unit by unit.
    for current_val_one, current_val_two in zip(input_one, input_two):
        and_outcome = current_val_one & current_val_two # Computes AND on current values.
        outcome_values.append(and_outcome)

    output_tuple = tuple(outcome_values) # Converts outcomes into a unit.
    return output_tuple