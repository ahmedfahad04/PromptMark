def sum_list(_input_array_one, _input_array_two):
    """
    Calculates the sum of corresponding elements from two input arrays.
    """
    # A concise way using list comprehension and zip to combine items
    # We iterate over corresponding items (_num_one, _num_two) from each array.
    _new_output_array = [_num_one + _num_two for _num_one, _num_two in zip(_input_array_one, _input_array_two)]
    return _new_output_array