def comb_sort(current_array):
    """
    Implements the Comb Sort algorithm to sort a list of elements.
    """
    array_size = len(current_array)
    current_gap = array_size
    shrink_constant = 1.3 # Common constant for reducing gap.
    is_array_sorted = False

    while not is_array_sorted or current_gap > 1:
        # current_gap calculation.
        current_gap = int(current_gap / shrink_constant)
        if current_gap < 1:
            current_gap = 1

        is_array_sorted = True
        current_idx = 0
        while current_idx < array_size - current_gap:
            if current_array[current_idx] > current_array[current_idx + current_gap]:
                # Swap current elements.
                current_array[current_idx], current_array[current_idx + current_gap] = \
                    current_array[current_idx + current_gap], current_array[current_idx]
                is_array_sorted = False
            current_idx += 1
    return current_array