def largest_subset(collection_of_numbers: list) -> int:
    # Check if the collection is empty. An empty collection has a subset of size 0.
    if not collection_of_numbers:
        return 0

    # Obtain a sorted collection of numbers.
    # Sorting simplifies the divisibility check: if an earlier number (A)
    # divides a later number (B), then A must come before B in the sorted list.
    sorted_numbers_collection = sorted(collection_of_numbers)
    
    # Initialize an array (dynamic programming table) to store the length of the
    # largest divisible subset ending with the number at each respective index.
    # Each number initially forms a divisible subset of size 1 (itself).
    count_of_subsets_up_to_index = [1] * len(sorted_numbers_collection)
    
    # Initialize the maximum overall subset size found so far.
    current_max_overall_size = 1

    # Iterate through each number in the sorted collection.
    for idx_current in range(len(sorted_numbers_collection)):
        current_number = sorted_numbers_collection[idx_current]
        
        # Compare the current number with all previous numbers in the collection.
        for idx_previous in range(idx_current):
            previous_number = sorted_numbers_collection[idx_previous]
            
            # If the current number is divisible by a previous number,
            # it means we can potentially extend the subset ending at 'previous_number'.
            if current_number % previous_number == 0:
                # Update the length for the subset ending at 'current_number'.
                # We choose the maximum of its current length or 1 plus the length
                # of the subset ending at 'previous_number'.
                count_of_subsets_up_to_index[idx_current] = max(
                    count_of_subsets_up_to_index[idx_current],
                    1 + count_of_subsets_up_to_index[idx_previous]
                )
        
        # Update the overall maximum subset size found across all numbers.
        current_max_overall_size = max(current_max_overall_size, count_of_subsets_up_to_index[idx_current])
            
    # Return the maximum size found.
    return current_max_overall_size