def odd_num_sum(input_count):
    current_sum = 0
    # Iterate input_count times to generate the first input_count odd numbers.
    for k in range(1, input_count + 1):
        one_odd = 2 * k - 1  # Current odd natural number
        num_power = one_odd ** 4  # Calculate current odd number's fourth power
        current_sum += num_power  # Add to overall sum
    return current_sum