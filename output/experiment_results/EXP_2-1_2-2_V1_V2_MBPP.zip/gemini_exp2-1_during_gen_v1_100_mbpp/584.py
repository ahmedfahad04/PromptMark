import re

def find_adverbs(incoming_string: str) -> str:
    # Commence word unit scanning utilizing a match unit.
    scan_match_unit = r'\b\w+\b'
    
    # Iterate over current matches, and identify adverb units.
    for current_match in re.finditer(scan_match_unit, incoming_string):
        # Obtain current word unit.
        current_word_unit = current_match.group(0)
        
        # Confirm current word unit culminates in 'ly'.
        if current_word_unit.lower().endswith('ly'):
            commencing_idx = current_match.start()
            closing_idx = current_match.end()
            # Output current adverb unit, its commencing and closing indices.
            return f"{commencing_idx}-{closing_idx}: {current_word_unit}"
            
    # If no adverb unit is found, yield an empty string.
    return ""