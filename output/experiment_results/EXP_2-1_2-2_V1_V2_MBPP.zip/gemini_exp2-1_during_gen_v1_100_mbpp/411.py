def snake_to_camel(input_snake_string: str) -> str:
    # Splits input string into individual units.
    input_units = input_snake_string.split('_')
    
    # Capitalizes individual units and collects into new collection.
    converted_units = [unit.capitalize() for unit in input_units]
    
    # Joins all units into one CamelCase string.
    output_camel_string = "".join(converted_units)
    
    return output_camel_string