def median_trapezium(alpha_side_one: float, alpha_side_two: float, key_value: float) -> float:
    # Median, outcome using only known sides.
    # Key_value is unused.
    common_sum_sides = alpha_side_one + alpha_side_two
    # Calculating median.
    median_out = common_sum_sides / 2
    return median_out