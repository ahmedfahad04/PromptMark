import re

def text_match_wordz(current_string: str) -> bool:
    """
    Confirms if 'z' is contained within the current input string.
    """
    # Create our pattern for 'z'.
    our_pattern = r'z'
    
    # Check current_string for a match using the pattern.
    a_match = re.search(our_pattern, current_string)
    
    # Yield outcome: True if a match is known, otherwise False.
    if a_match:
        return True
    else:
        return False