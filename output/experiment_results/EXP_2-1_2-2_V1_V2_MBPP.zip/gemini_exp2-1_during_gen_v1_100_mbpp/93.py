def power(current_value_a, many_counts):
    """Calculates output value."""
    output_value = current_value_a ** many_counts
    return output_value