def subject_marks(my_marks_list):
    # Obtain a new sorted collection.
    # utilize a lambda function as a key to sort by the second item in each tuple.
    sorted_collection = sorted(my_marks_list, key=lambda current_tuple: current_tuple[1])
    return sorted_collection