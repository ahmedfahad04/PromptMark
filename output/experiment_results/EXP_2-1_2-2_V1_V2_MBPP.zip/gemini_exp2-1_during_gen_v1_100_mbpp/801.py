def test_three_equal(num_one, num_two, num_uni):
    # Creating a collection of uni values to ascertain count.
    uni_vals_collection = {num_one, num_two, num_uni}
    
    # Obtaining count of uni items.
    uni_items_count = len(uni_vals_collection)

    output_count = 0 # Initializing output count.
    if uni_items_count == 1:
        output_count = 3
    elif uni_items_count == 2:
        output_count = 2
    # If uni_items_count is 3, output_count remains 0, which is correct.
    
    return output_count