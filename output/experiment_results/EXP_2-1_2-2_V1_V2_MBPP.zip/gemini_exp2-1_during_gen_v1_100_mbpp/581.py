def surface_Area(a_unit_val, i_slant_val):
    """
    Calculates the surface area of a square pyramid.

    Assumes i_slant_val is the slant height of the pyramid,
    as indicated by the provided test cases.

    Args:
        a_unit_val (numeric): A numeric value for the base edge of the square pyramid.
        i_slant_val (numeric): A numeric value for the slant height of the pyramid.

    Returns:
        numeric: The overall surface area of the square pyramid.
    """
    # Calculate a_square_area_val (base area)
    # This accounts for the area of the square base.
    a_square_area_val = a_unit_val * a_unit_val

    # Calculate a_side_canvas_val (lateral surface area)
    # This covers the area of the four triangular faces.
    # One such triangular face's area is (0.5 * a_unit_val * i_slant_val).
    # Cumulatively, for four faces, it is 4 * 0.5 * a_unit_val * i_slant_val,
    # which simplifies to 2 * a_unit_val * i_slant_val.
    a_side_canvas_val = 2 * a_unit_val * i_slant_val

    # Calculate a_overall_sum (total surface area)
    # This is a combination of the base area and the lateral surface area.
    a_overall_sum = a_square_area_val + a_side_canvas_val
    
    return a_overall_sum