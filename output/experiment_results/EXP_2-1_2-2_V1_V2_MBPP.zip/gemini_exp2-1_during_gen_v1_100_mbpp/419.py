def round_and_sum(input_numbers_array):
    # Collects whole values from input numbers.
    all_current_whole_nums = [round(an_input_num) for an_input_num in input_numbers_array]

    # Calculates sum of all collected whole values.
    current_sum_value = sum(all_current_whole_nums)

    # Obtains count of input array items.
    input_array_count = len(input_numbers_array)

    # Computes overall output value.
    overall_output_value = current_sum_value * input_array_count
    return overall_output_value