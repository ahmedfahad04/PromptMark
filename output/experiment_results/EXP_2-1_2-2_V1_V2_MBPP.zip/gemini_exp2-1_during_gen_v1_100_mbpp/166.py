def find_even_pair(input_array: list[int]) -> int:
    # current_even_nums counts numbers with even parity.
    count_even_nums = 0
    # current_odd_nums counts numbers with odd parity.
    count_odd_nums = 0

    for current_num in input_array:
        if current_num % 2 == 0:
            count_even_nums += 1
        else:
            count_odd_nums += 1

    # num_even_combinations counts pairs of even numbers.
    # A pair of even numbers XORs to an even number.
    num_even_combinations = count_even_nums * (count_even_nums - 1) // 2
    # num_odd_combinations counts pairs of odd numbers.
    # A pair of odd numbers XORs to an even number.
    num_odd_combinations = count_odd_nums * (count_odd_nums - 1) // 2

    # overall_pairs_count is the sum of both types of combinations.
    overall_pairs_count = num_even_combinations + num_odd_combinations
    return overall_pairs_count