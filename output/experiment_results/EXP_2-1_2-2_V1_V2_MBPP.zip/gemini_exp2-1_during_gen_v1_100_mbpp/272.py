def rear_extract(collection_of_units):
    """
    Creates a new list containing only the rear element of each tuple
    within the input collection.
    """
    # Customizes a container for new units.
    collected_units = []
    # Iterates over each unit in the input collection.
    for current_unit in collection_of_units:
        # Appends the last item of the current unit.
        collected_units.append(current_unit[-1])
    return collected_units