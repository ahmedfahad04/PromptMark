def list_to_float(input_collection):
    """
    Converts all string items within inner collections (tuples/lists) to floats.

    Args:
        input_collection: A collection of collections, where inner items are
                          strings convertible to floats.

    Returns:
        A new collection of collections with all convertible items as floats.
    """
    # Converts each string item in incoming collection units into a numeric value.
    output_collection = [
        tuple(float(current_item_value) for current_item_value in current_unit)
        for current_unit in input_collection
    ]
    return output_collection