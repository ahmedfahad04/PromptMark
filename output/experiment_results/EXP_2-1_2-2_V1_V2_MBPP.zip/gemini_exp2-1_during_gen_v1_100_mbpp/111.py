def common_in_nested_lists(nested_lists):
    # Confirm input collection yields nothing
    if not nested_lists:
        return set() # Yield an unset if no collections are provided

    # Initialise with initial collection's unique items
    # common_items_unit will contain items as current common unit
    common_items_unit = set(nested_lists[0])

    # Iterate on additional collections
    # Compare with common_items_unit
    for current_collection_items in nested_lists[1:]:
        # current_unique_set: current collection's unique items
        current_unique_set = set(current_collection_items)
        # Keep only items which are in both common_items_unit AND current_unique_set
        common_items_unit.intersection_update(current_unique_set)
        
        # If common_items_unit is unset, no additional common items can be found
        if not common_items_unit:
            break

    return common_items_unit