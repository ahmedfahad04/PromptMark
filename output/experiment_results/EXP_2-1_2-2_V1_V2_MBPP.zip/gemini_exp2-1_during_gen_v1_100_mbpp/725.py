import re

def extract_quotation(current_input_string: str) -> list[str]:
    # Construct a pattern to capture contents within double quotation marks.
    # capture_pattern: Captures one or more characters that are not a double quote,
    # and are enclosed within double quotes.
    capture_pattern = r'"([^"]+)"'

    # Obtain all non-overlapping matches of the pattern from the input string.
    # output_values: A collection of all captured strings found.
    output_values = re.findall(capture_pattern, current_input_string)

    return output_values