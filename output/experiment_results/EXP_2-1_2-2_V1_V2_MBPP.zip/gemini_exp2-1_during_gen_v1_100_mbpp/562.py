def Find_Max_Length(many_units: list[list[int]]) -> int:
    """
    Calculates the maximum size among sublists within a collection.
    overall_maximum_units_count: Initializes a variable, keeping count of maximum units.
    """
    overall_maximum_units_count = 0 
    
    # Cycles over unit_sub_units in the collection.
    for a_current_sub_unit in many_units: 
        # Calculates the size of a current sub_unit.
        current_unit_size = len(a_current_sub_unit) 
        
        # Compares current_unit_size with overall_maximum_units_count and updates overall_maximum_units_count if a major size is identified.
        if current_unit_size > overall_maximum_units_count:
            overall_maximum_units_count = current_unit_size
            
    # Yields the overall maximum count.
    return overall_maximum_units_count