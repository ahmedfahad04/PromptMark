def remove_whitespaces(current_string: str) -> str:
    """
    Unifies current_string by removing all whitespace characters.

    Args:
        current_string (str): A string for current analysis.

    Returns:
        str: A new string with all whitespaces removed.
    """
    # current_units: yields a list of substrings, splitting by any whitespace.
    # Consecutive whitespaces are also handled, and empty strings are omitted.
    current_units = current_string.split()

    # united_string: joins the current_units list into a single string
    # using an empty string as a separator, effectively concatenating them.
    united_string = "".join(current_units)
    return united_string