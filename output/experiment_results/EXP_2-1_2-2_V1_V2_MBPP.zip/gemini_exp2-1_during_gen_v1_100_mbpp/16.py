import re

def text_lowercase_underscore(a_candidate_unit: str) -> bool:
    """
    Confirms if the input string contains sequences of lowercase letters 
    joined with an underscore. The entire string must conform to this pattern.

    Args:
        a_candidate_unit: A string for analysis.

    Returns:
        A boolean indicating if the string matches the specified pattern.
    """
    # A custom match unit, using verification.
    # Confirms only alpha characters (lowercase), joining with an underscore.
    a_match_unit = r"^[a-z]+_[a-z]+$"
    
    # Confirms 'a_candidate_unit' wholly matches 'a_match_unit'.
    # Its utility confirms 'a_candidate_unit' wholly.
    scan_outcome = bool(re.fullmatch(a_match_unit, a_candidate_unit))
    
    # Yield outcome of unit analysis.
    return scan_outcome