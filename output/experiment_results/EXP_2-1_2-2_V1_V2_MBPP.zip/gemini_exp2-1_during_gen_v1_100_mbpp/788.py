def new_tuple(current_items, one_string):
    # Creates a new collection.
    # current_items: A initial collection of items.
    # one_string: A single string item.
    # Yields: A new collection.

    unified_collection = (*current_items, one_string)
    return unified_collection