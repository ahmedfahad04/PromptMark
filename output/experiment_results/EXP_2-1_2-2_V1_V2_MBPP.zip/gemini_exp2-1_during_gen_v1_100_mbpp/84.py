def sequence(u_input_n: int) -> int:
    """
    Computes a specified item in the Newman-Conway sequence.
    """
    # Invalid input check
    if u_input_n <= 0:
        raise ValueError("Input must be a positive integer.")

    # Initial cases for the sequence
    if u_input_n == 1:
        return 1
    if u_input_n == 2:
        return 1

    # Utilizes an array for memoization, storing previously calculated values.
    # Array is initialized with a size of u_input_n + 1 to use 1-based indexing.
    u_array_storage = [0] * (u_input_n + 1)
    u_array_storage[1] = 1
    u_array_storage[2] = 1

    # Iteratively computes sequence values starting with a third item up to u_input_n.
    # The Newman-Conway sequence formula is P(n) = P(P(n-1)) + P(n-P(n-1)).
    for u_current_val in range(3, u_input_n + 1):
        # Obtain a value of P(n-1) from storage.
        u_val_prev_one = u_array_storage[u_current_val - 1]

        # Compute a first component for sum: P(P(n-1)).
        # Current logic implicitly handles valid indices given problem definition; P(n-1) always >= 1.
        u_val_sum_component_one = u_array_storage[u_val_prev_one]

        # Compute a second component of sum: P(n-P(n-1)).
        u_val_sum_component_two = u_array_storage[u_current_val - u_val_prev_one]

        # Summing current components yields P(n), and stores it.
        u_array_storage[u_current_val] = u_val_sum_component_one + u_val_sum_component_two

    # Yields a specified value from sequence.
    return u_array_storage[u_input_n]