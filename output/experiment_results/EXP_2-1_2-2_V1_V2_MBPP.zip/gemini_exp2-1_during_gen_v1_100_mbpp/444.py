def trim_tuple(input_collection, k_count):
    # Yields new list, containing trimmed units.
    current_collection_of_trimmed_units = []

    # Iterates over input collection to yield trimmed units.
    for current_input_unit in input_collection:
        current_unit_count = len(current_input_unit)
        
        # Computes indices, aiding slicing.
        # k_count indicates count of units to cut, inwards.
        current_sliced_unit = current_input_unit[k_count : current_unit_count - k_count]
        
        current_collection_of_trimmed_units.append(current_sliced_unit)
    
    # Converts collection of trimmed units into string image.
    output_string_image = str(current_collection_of_trimmed_units)
    return output_string_image