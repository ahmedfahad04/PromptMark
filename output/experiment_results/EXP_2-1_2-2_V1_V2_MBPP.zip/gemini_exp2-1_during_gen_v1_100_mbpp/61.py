def count_Substrings(input_values: str) -> int:
    """
    Counts the number of substrings where the sum of their digits equals their length.
    """
    overall_units_count = len(input_values)
    matching_units_count = 0

    # Iterates through all possible starting positions for a substring.
    for i in range(overall_units_count):
        current_units_sum = 0
        # Iterates through all possible ending positions for a substring,
        # starting from the current 'i'.
        for j in range(i, overall_units_count):
            current_unit_value = int(input_values[j])
            current_units_sum += current_unit_value
            unit_window_size = j - i + 1

            # Compares the accumulated sum of digits with the substring's length.
            if current_units_sum == unit_window_size:
                matching_units_count += 1
    
    return matching_units_count