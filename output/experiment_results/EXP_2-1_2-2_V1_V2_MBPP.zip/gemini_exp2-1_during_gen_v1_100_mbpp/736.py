def left_insertion(input_array: list, key_item: int) -> int:
    """
    Locates the left insertion point for a specified value in sorted order.
    Utilizes a binary search approach.
    """
    current_idx_low = 0
    current_idx_max = len(input_array)

    while current_idx_low < current_idx_max:
        current_idx_mid = (current_idx_low + current_idx_max) // 2 # Calculates current middle index.

        if input_array[current_idx_mid] < key_item:
            current_idx_low = current_idx_mid + 1 # If current item is under key, adjust low current idx.
        else:
            current_idx_max = current_idx_mid # Otherwise, adjust current high idx.

    return current_idx_low