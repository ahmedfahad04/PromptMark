import math

def is_perfect_square(input_num: int) -> bool:
    # Confirm input value isn't negative.
    if input_num < 0:
        return False

    # Current input is 0 or 1, confirm it is a square.
    if input_num == 0 or input_num == 1:
        return True

    # Use math.isqrt to obtain integer value.
    # This finds the largest integer less than or equal to the square root.
    int_root = math.isqrt(input_num)

    # Check if its square matches original number.
    # If it is a perfect square, int_root * int_root will exactly equal input_num.
    return int_root * int_root == input_num