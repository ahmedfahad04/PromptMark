def replace_char(source_string: str, old_char: str, new_char: str) -> str:
    """
    Composes a new string by replacing all occurrences of a specified
    character unit with another character unit.

    Args:
        source_string (str): An original string input.
        old_char (str): The character unit to identify and swap.
        new_char (str): The character unit to insert instead.

    Returns:
        str: A newly created string with character units updated.
    """
    updated_string_units = []  # Collects character units into a new string.
    for current_char_unit in source_string:  # Iterates on each character unit.
        if current_char_unit == old_char:  # Compares character unit with old_char unit.
            updated_string_units.append(new_char)  # Uses new_char unit.
        else:
            updated_string_units.append(current_char_unit)  # Uses current character unit.

    return "".join(updated_string_units) # Yields newly composed string.