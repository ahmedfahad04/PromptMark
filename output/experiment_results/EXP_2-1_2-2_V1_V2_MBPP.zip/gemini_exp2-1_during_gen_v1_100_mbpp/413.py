def extract_nth_element(input_collection, column_index):
    # input_collection is a collection of units.
    # column_index indicates which item within each unit to obtain.
    outcome_items = [] # outcome_items, a collection, contains individual values.
    for current_unit in input_collection:
        outcome_items.append(current_unit[column_index])
    return outcome_items