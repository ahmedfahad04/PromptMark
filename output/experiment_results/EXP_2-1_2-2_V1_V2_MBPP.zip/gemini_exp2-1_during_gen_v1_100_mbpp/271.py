def even_Power_Sum(n: int) -> int:
    current_sum = 0
    # Sum of numbers uplifted.
    for i in range(1, n + 1):
        # Current number val; 2, 4, 6, ...
        current_num_val = 2 * i
        uplift_val = current_num_val ** 5
        current_sum += uplift_val
    return current_sum