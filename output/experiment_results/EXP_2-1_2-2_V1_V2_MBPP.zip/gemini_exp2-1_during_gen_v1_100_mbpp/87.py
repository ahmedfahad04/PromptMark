def merge_dictionaries_three(initial_input_map: dict, central_input_map: dict, outer_input_map: dict) -> dict:
    """
    Unites multiple mapping collections into one, new mapping.
    When common keys occur, initial_input_map's value wins;
    central_input_map's is next, outer_input_map's contributes initially.
    """
    # Create a new combined mapping.
    # outer_input_map's items come in as a base.
    # Central_input_map's items join, overwriting common key values.
    # initial_input_map items also add, overwriting any existing common key values.
    # Yielding initial_input_map's ultimate key values.
    combined_unity = {**outer_input_map, **central_input_map, **initial_input_map}
    return combined_unity