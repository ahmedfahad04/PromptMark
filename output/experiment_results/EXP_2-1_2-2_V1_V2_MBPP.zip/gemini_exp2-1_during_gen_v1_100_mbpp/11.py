def remove_Occ(original_canvas_string: str, occurrence_key_char: str) -> str:
    # obtains initial key index of the character.
    initial_key_index = original_canvas_string.find(occurrence_key_char)

    # if key character is not in canvas string, return original.
    if initial_key_index == -1:
        return original_canvas_string

    # obtains closing key index of the character.
    closing_key_index = original_canvas_string.rfind(occurrence_key_char)

    # if initial and closing indexes are the same, character occurs only once.
    # only one occurrence is cut.
    if initial_key_index == closing_key_index:
        canvas_output_string = original_canvas_string[0:initial_key_index] + \
                               original_canvas_string[initial_key_index + 1:]
        return canvas_output_string
    else:
        # multiple occurrences, cut initial and closing occurrences.
        canvas_output_string = original_canvas_string[0:initial_key_index] + \
                               original_canvas_string[initial_key_index + 1:closing_key_index] + \
                               original_canvas_string[closing_key_index + 1:]
        return canvas_output_string