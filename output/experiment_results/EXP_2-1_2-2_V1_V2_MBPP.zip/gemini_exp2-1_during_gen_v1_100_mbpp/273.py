def substract_elements(initial_collection, other_collection):
    # Create a list to accumulate the current outcome units.
    computed_outcome_units = []
    # Join the initial and other collections, iterating over unit values concurrently.
    for one_unit_value, other_unit_value in zip(initial_collection, other_collection):
        current_unit_outcome = one_unit_value - other_unit_value
        computed_outcome_units.append(current_unit_outcome)
    # Convert the collected units into a tuple and yield it.
    return tuple(computed_outcome_units)