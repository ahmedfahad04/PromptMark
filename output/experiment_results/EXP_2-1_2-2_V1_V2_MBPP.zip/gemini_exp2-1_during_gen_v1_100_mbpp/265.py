def list_split(a_collection, count_n):
    # Initialize a list of empty collections to contain the results.
    # Its capacity is `count_n` as we need `count_n` distinct output collections.
    output_collections = [[] for _ in range(count_n)]

    # Iterate over the input a_collection along with its current_index.
    # Current_index will help us calculate which output collection an item belongs to.
    for current_index, current_item in enumerate(a_collection):
        # Calculate the destination output collection index using the modulo operator.
        # This ensures items are distributed cyclically across the `count_n` collections.
        sublist_index = current_index % count_n
        output_collections[sublist_index].append(current_item)

    return output_collections