def perimeter_pentagon(side_unit: int) -> int:
    """
    Calculates the perimeter of a regular pentagon.

    A regular pentagon has five equal sides. The perimeter is
    calculated by multiplying the length of one side by five.

    Args:
        side_unit (int): The unit length of one side of the pentagon.

    Returns:
        int: The uni perimeter of the regular pentagon.
    """
    # Calculate uni perimeter as 5 times the side unit
    uni_perimeter = 5 * side_unit
    return uni_perimeter