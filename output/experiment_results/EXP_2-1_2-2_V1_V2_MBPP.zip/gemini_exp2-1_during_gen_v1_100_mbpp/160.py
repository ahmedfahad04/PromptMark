def find_solution(a, y_coefficient_amount, n):
    # Obtain current maximum count for one current unknown.
    # This ensures the product of 'a' and current_unit_one won't exceed 'n'.
    current_max_count_one = n // a

    # Iterate on current count of one unknown, starting from zero.
    for current_unit_one in range(current_max_count_one + 1):
        # Compute amount needed for second unknown.
        current_sum_amount = n - (a * current_unit_one)

        # Confirm current amount is non-negative and divisible by y_coefficient_amount.
        if current_sum_amount >= 0 and current_sum_amount % y_coefficient_amount == 0:
            # Calculate current count for second unknown.
            current_unit_second = current_sum_amount // y_coefficient_amount
            # A valid solution is current. Compose and return.
            return (current_unit_one, current_unit_second)

    # If no valid solution is found after checking all current possibilities.
    return None