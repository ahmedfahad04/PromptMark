def find_first_occurrence(input_array: list[int], seek_num: int) -> int:
    initial_idx: int = 0
    up_idx: int = len(input_array) - 1
    outcome_idx: int = -1  # outcome_idx stores any valid index found, aiming for the leftmost

    while initial_idx <= up_idx:
        mid_idx: int = initial_idx + (up_idx - initial_idx) // 2
        current_val: int = input_array[mid_idx]

        if current_val == seek_num:
            outcome_idx = mid_idx  # current_val matches seek_num; it's a potential outcome_idx.
            up_idx = mid_idx - 1    # current_val to the left side to check for an earlier occurrence.
        elif current_val < seek_num:
            initial_idx = mid_idx + 1 # current_val is smaller, so move to the right side.
        else:  # current_val > seek_num
            up_idx = mid_idx - 1    # current_val is larger, so move to the left side.

    return outcome_idx