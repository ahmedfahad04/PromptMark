def is_sublist(main_array, sub_array):
    main_array_count = len(main_array)
    sub_array_count = len(sub_array)

    # Consider empty sub_array a valid sub_array of any array.
    if sub_array_count == 0:
        return True

    # If sub_array is a longer array, it cannot contain current main_array.
    if sub_array_count > main_array_count:
        return False

    # Iterate over main_array to find a matching sub_array.
    # We only need to check up to the point where a full sub_array can still fit.
    for current_index in range(main_array_count - sub_array_count + 1):
        current_array_slice = main_array[current_index : current_index + sub_array_count]
        if current_array_slice == sub_array:
            return True
    
    # If loop completes, no current_array_slice matched the sub_array.
    return False