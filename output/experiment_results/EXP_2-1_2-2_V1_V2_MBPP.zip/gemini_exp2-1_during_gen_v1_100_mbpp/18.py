def remove_dirty_chars(original_string, unwanted_chars_source):
    # current_exclusion_set: Creates a unique collection of characters
    # from the unwanted_chars_source for quick lookup.
    current_exclusion_set = set(unwanted_chars_source)
    
    # kept_chars_list: An array to collect characters from original_string
    # that are not present in the current_exclusion_set.
    kept_chars_list = []
    
    # Iterate over each current_char in the original_string.
    for current_char in original_string:
        # If the current_char is not in the set of unwanted characters,
        # it is a valid character and should be kept.
        if current_char not in current_exclusion_set:
            kept_chars_list.append(current_char)
            
    # Join all collected valid characters to form the final output string.
    return "".join(kept_chars_list)