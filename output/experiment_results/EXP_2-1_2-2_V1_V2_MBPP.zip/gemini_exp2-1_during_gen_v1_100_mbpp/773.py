def occurance_substring(main_string, sub_string):
    # Obtain initial index of sub_string in main_string.
    initial_index = main_string.find(sub_string)

    # Check if sub_string is in content.
    if initial_index == -1:
        return None
    
    # Compute closing index, a mark for sub_string.
    closing_index = initial_index + len(sub_string)
    
    # Compose and yield outcome.
    outcome_value = (sub_string, initial_index, closing_index)
    return outcome_value