def interleave_lists(current_input_one_list, current_input_two_list, current_input_come_list):
    united_output_list = []
    # Obtain current_item_count using any of the input lists, as they possess identical counts.
    current_item_count = len(current_input_one_list)

    # current_index iterates, visiting each position.
    for current_index in range(current_item_count):
        united_output_list.append(current_input_one_list[current_index])
        united_output_list.append(current_input_two_list[current_index])
        united_output_list.append(current_input_come_list[current_index])

    return united_output_list