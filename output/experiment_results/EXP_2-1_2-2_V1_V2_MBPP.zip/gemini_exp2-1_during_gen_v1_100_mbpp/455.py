def check_monthnumb_number(current_month_num: int) -> bool:
    """
    Confirms if current_month_num is among months known to carry 31 days.
    """
    # Common months having 31 calendar units
    common_january_months_num = {1, 3, 5, 7, 8, 10, 12}
    
    # Check if current_month_num is in the collection of 31-day months
    is_month_with_many_units = current_month_num in common_january_months_num
    
    return is_month_with_many_units