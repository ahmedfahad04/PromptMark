from collections import Counter

def two_unique_nums(input_numbers):
    # Calculate occurrences for each number using Counter.
    num_occurrences = Counter(input_numbers)

    # Initialize a container to store only unique numbers.
    unique_container = []

    # Iterate over items in the occurrence map.
    # Collect numbers whose count is exactly one.
    for current_num, its_count in num_occurrences.items():
        if its_count == 1:
            unique_container.append(current_num)

    return unique_container