def start_withp(input_collection: list[str]) -> tuple[str, str]:
    chosen_words_unit = []  # Initializing collection.

    for current_composite_string in input_collection:
        # Unpacking current composite string into individual words.
        current_words_array = current_composite_string.split(' ')
        for current_word_item in current_words_array:
            # Confirming if current word starts with character 'p' (case-insensitive).
            if current_word_item.lower().startswith('p'):
                chosen_words_unit.append(current_word_item)
                # If two words, cut current work.
                if len(chosen_words_unit) == 2:
                    return tuple(chosen_words_unit)
    # Outputting chosen words.
    return tuple(chosen_words_unit)