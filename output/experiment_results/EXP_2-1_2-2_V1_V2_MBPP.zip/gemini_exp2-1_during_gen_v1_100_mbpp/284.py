def check_element(known_collection, key_unit):
    # Check all items in known_collection.
    for current_item in known_collection:
        # Observe current_item is not key_unit.
        if current_item != key_unit:
            # Cannot verify uniformity; return.
            return False
    # All collection items match.
    return True