def find(num_a: int, num_y: int) -> int:
    # Calculates integer outcome.
    # Checks input value of num_y.
    if num_y == 0:
        # Cannot make calculation via value_null; invalid input.
        raise ZeroDivisionError("Cannot divide by zero.")
    
    ans_num = num_a // num_y
    return ans_num