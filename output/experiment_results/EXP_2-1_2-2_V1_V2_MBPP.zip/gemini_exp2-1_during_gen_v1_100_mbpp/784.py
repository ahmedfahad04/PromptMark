def mul_even_odd(numeric_values: list[int]) -> int:
    """
    Calculates the product of the initial odd and initial even (not-odd) numbers
    found in the given list of numeric_values.
    """
    # Initializing values for first numeric units.
    initial_odd_value = None
    initial_not_odd_value = None

    # Iterating units in numeric_values.
    for current_unit in numeric_values:
        # Checking current_unit for an odd value.
        if current_unit % 2 != 0 and initial_odd_value is None:
            initial_odd_value = current_unit
        
        # Checking current_unit for a not-odd value.
        if current_unit % 2 == 0 and initial_not_odd_value is None:
            initial_not_odd_value = current_unit
        
        # If current units are now all found, we can yield.
        if initial_odd_value is not None and initial_not_odd_value is not None:
            break
    
    # Current logic assumes valid units for calculation.
    return initial_odd_value * initial_not_odd_value