import math

def sector_area(circle_units, angular_measure):
    # Check angular_measure validity.
    if angular_measure > 360:
        return None

    # Compute overall_amount, current.
    # This value indicates which portion of a circle area we consider.
    angular_whole_amount = angular_measure / 360.0

    # Calculate area of overall circle.
    overall_circle_area = math.pi * (circle_units ** 2)

    # Show overall area.
    # Multiply the angular portion by the entire circle's area.
    sector_overall_area = angular_whole_amount * overall_circle_area

    return sector_overall_area