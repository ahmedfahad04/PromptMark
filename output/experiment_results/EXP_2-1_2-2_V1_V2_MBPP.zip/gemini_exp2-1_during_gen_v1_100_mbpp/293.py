import math

def otherside_rightangle(one_known_side: float, any_known_side: float) -> float:
    # Calculate the square of the first known side.
    val_one_square = one_known_side * one_known_side
    # Calculate the square of the other known side.
    val_any_square = any_known_side * any_known_side
    
    # Obtain the sum of the squares of the two known sides.
    current_sum_of_squares = val_one_square + val_any_square
    
    # Calculate the square root of the sum to yield the length of the unknown side.
    calculated_outcome = math.sqrt(current_sum_of_squares)
    
    return calculated_outcome