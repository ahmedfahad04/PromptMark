def find_Average_Of_Cube(input_count: int) -> float:
    # Confirms input_count is valid for natural numbers.
    # Utilizes input_count as 'n' for the calculations.
    if input_count <= 0:
        # Yields zero if no natural numbers are involved.
        return 0.0

    # Applies sum of cubes formula: (n * (n + 1) / 2)^2
    # And then divides by n for the average.
    # This simplifies to n * (n + 1)^2 / 4.
    
    current_value_plus_one = input_count + 1
    numerator_value = input_count * (current_value_plus_one ** 2)
    output_average = numerator_value / 4.0

    return output_average