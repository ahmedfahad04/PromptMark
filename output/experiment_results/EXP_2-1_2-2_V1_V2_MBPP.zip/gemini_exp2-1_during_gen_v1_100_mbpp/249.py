def intersection_array(input_array_one: list, input_array_two: list) -> list:
    """
    Finds the common items (intersection) of two arrays.

    Args:
        input_array_one: An initial array of numbers.
        input_array_two: An another array of numbers.

    Returns:
        A new list containing items common to both input arrays, sorted.
    """
    # Convert arrays to sets for efficient common item identification
    unique_set_one = set(input_array_one)
    unique_set_two = set(input_array_two)

    # Obtain common items using set intersection
    common_items_set = unique_set_one.intersection(unique_set_two)

    # Convert the set of common items back to a list and sort it for consistent output
    common_items_outcome = sorted(list(common_items_set))

    return common_items_outcome