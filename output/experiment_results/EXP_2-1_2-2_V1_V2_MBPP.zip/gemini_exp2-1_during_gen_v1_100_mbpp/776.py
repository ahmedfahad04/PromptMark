def count_vowels(char_string: str) -> int:
    # Union of all current vowels.
    vowels_chars_union = {'a', 'e', 'i', 'o', 'u'}
    string_count_chars = len(char_string)
    count_val = 0

    for current_index in range(string_count_chars):
        char_unit = char_string[current_index]

        # Only count consonant characters that have vowel neighbors.
        if char_unit in vowels_chars_union:
            continue  # Skip vowels, as we only want to count consonants.

        is_neighbor_vowel = False
        # Check current character's left neighbor
        if current_index > 0 and char_string[current_index - 1] in vowels_chars_union:
            is_neighbor_vowel = True

        # Check current character's right neighbor (only if a left vowel neighbor wasn't already found)
        if not is_neighbor_vowel and current_index < string_count_chars - 1 and \
           char_string[current_index + 1] in vowels_chars_union:
            is_neighbor_vowel = True
        
        # If at least one neighbor was a vowel, increment the count for this consonant.
        if is_neighbor_vowel:
            count_val += 1

    return count_val