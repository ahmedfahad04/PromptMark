def capital_words_spaces(input_string: str) -> str:
    """
    Inserts spaces between words starting with capital letters in a given string.
    """
    string_length = len(input_string)
    output_chars = []

    # Iterate on each character using its index.
    for char_index in range(string_length):
        current_char = input_string[char_index]
        is_uppercase = 'A' <= current_char <= 'Z'

        # If current character is uppercase AND not the very first character of the string,
        # it indicates a new word, so insert a space.
        if is_uppercase and char_index > 0:
            output_chars.append(' ')
        output_chars.append(current_char)

    # Unite all characters into a new string.
    new_string = "".join(output_chars)
    return new_string