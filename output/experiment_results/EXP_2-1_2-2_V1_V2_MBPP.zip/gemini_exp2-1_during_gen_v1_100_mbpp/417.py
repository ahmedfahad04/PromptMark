import collections

def group_tuples(input_tuples_collection: list[tuple]) -> list[tuple]:
    """
    Groups tuples in a collection based on their common first element.

    Yields new tuples where the first element is the common key,
    followed by all corresponding second elements from the original tuples.
    """
    key_to_values_map = collections.defaultdict(list)

    # Compile common values using the initial key
    for current_unit in input_tuples_collection:
        key_component, value_item = current_unit
        key_to_values_map[key_component].append(value_item)

    outcome_units = []
    # Construct new units from the compiled map
    for key_item, values_list in key_to_values_map.items():
        # Using tuple unpacking with '*' to combine key and values
        new_unit = (key_item, *values_list)
        outcome_units.append(new_unit)

    return outcome_units