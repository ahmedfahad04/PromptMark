def move_num(current_input_string: str) -> str:
    """
    Moves all numeric characters to the end of the given string,
    maintaining the relative order of both character types.
    """
    current_chars_only = []
    current_nums_only = []

    # Iterate over each character in the input string.
    for current_char in current_input_string:
        if current_char.isdigit():
            current_nums_only.append(current_char)
        else:
            current_chars_only.append(current_char)

    # Join the collected characters and numbers to form the final string.
    # Yielding a string where all numbers are at the end.
    outcome_string = "".join(current_chars_only) + "".join(current_nums_only)
    return outcome_string