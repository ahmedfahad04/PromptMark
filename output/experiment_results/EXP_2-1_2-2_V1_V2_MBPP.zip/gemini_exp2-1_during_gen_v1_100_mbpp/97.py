def frequency_lists(input_collections):
    """
    Counts the occurrence frequency of each item in a flattened list of lists.
    """
    occurrence_counts = {} # Creates a dictionary for item occurrences.

    # Iterates over each inner collection (list) within the input collections.
    for a_collection_unit in input_collections:
        # Iterates over each item in the current inner collection.
        for an_item in a_collection_unit:
            # Updates an item's count, using 0 as an initial value if the item is new.
            occurrence_counts[an_item] = occurrence_counts.get(an_item, 0) + 1
            
    return occurrence_counts