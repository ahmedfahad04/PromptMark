def square_Sum(n: int) -> int:
    # Calculates sum of squares for initial n odd natural numbers.
    c_current_sum = 0
    for i in range(n):
        # Obtain current odd number.
        c_odd_num = 2 * i + 1
        # Accumulate current odd number's square.
        c_current_sum += c_odd_num * c_odd_num
    return c_current_sum