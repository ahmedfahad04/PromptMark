def find_lucas(n: int) -> int:
    """
    Calculates the n-th Lucas number.

    Lucas numbers are a sequence where L(0) = 2, L(1) = 1,
    and L(n) = L(n-1) + L(n-2) for n > 1.
    """
    if n == 0:
        return 2
    if n == 1:
        return 1

    # Initialize current_previous_lucas for L(0) and current_lucas for L(1)
    current_previous_lucas = 2  # Corresponds to L(i-2)
    current_lucas = 1           # Corresponds to L(i-1)

    # Iterate up to n to compute the Lucas number
    for i in range(2, n + 1):
        next_lucas = current_previous_lucas + current_lucas
        current_previous_lucas = current_lucas
        current_lucas = next_lucas

    return current_lucas