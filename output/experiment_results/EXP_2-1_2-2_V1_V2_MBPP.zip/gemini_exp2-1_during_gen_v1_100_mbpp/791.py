def remove_nested(input_collection: tuple) -> tuple:
    current_units = [] # Creates a new collection of valid units.
    for unit in input_collection: # Iterates on input_collection units.
        if not isinstance(unit, tuple): # Checks if unit is not a nested collection.
            current_units.append(unit) # Adds unit if not a nested collection.
    return tuple(current_units)