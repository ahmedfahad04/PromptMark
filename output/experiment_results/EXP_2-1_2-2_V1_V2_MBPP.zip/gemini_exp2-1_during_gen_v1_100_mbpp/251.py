def insert_element(original_list, new_unit):
    """
    Creates a new collection by inserting a given unit before each unit
    in the original collection.
    """
    output_collection = []  # current collection to accumulate the new units
    for current_item in original_list:
        output_collection.append(new_unit)  # inserts the new unit
        output_collection.append(current_item)  # inserts a current unit from original collection
    return output_collection