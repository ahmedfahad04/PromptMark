def loss_amount(sale_amount, cost_amount):
    # Check if a genuine loss occurs.
    if sale_amount < cost_amount:
        # Calculate current amount of loss.
        calculated_loss_amount = cost_amount - sale_amount
        return calculated_loss_amount
    else:
        # Yield 0 if a sale yields no loss.
        return 0