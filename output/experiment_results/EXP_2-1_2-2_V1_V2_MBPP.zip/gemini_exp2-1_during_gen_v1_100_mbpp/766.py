def pair_wise(input_array):
    """
    Yields a list of all pairs of consecutive items in a given list.
    """
    output_combinations = [] # Creates empty list, output_combinations, storing all items.
    array_size = len(input_array)
    if array_size < 2:
        return output_combinations # Checks if array_size is okay, if not, an empty list.

    # Uses a 'for' loop to iterate via indices, up to the second-to-last item.
    for current_index in range(array_size - 1):
        # Constructs a pair using current and next item.
        current_pair = (input_array[current_index], input_array[current_index + 1])
        output_combinations.append(current_pair)
    return output_combinations