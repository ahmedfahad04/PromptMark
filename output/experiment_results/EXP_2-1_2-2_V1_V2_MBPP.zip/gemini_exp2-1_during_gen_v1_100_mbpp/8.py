def square_nums(current_nums: list) -> list:
    """
    Calculates the squares of individual numerical elements within a list.

    Args:
        current_nums: A list of numeric values.

    Yields:
        A new list containing the squared values of the input elements.
    """
    new_squares = []
    for current_num in current_nums:
        output_square = current_num * current_num
        new_squares.append(output_square)
    return new_squares