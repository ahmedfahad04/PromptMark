def Split(incoming_numbers_array):
    # Creates an output collection for even numbers.
    collected_even_numbers = []
    # Iterates over all numbers within the incoming array.
    for a_number in incoming_numbers_array:
        # Checks if current number is an even number.
        if a_number % 2 == 0:
            # Inserts the even number into the collection.
            collected_even_numbers.append(a_number)
    # Yields the array containing only even numbers.
    return collected_even_numbers