def count_X(current_collection: tuple, item_value: any) -> int:
    # Commence occurrence count.
    occur_count = 0

    # Unroll current_collection's individual units.
    for unit_item in current_collection:
        # Confirm unit_item's identity with item_value.
        if unit_item == item_value:
            # Uplift occur_count if match.
            occur_count += 1
            
    return occur_count