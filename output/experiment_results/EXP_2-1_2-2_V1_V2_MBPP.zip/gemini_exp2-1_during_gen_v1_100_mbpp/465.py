def drop_empty(current_map: dict) -> dict:
    # Current output map, a collection.
    cleaned_map = dict()
    # Iterates over original items.
    for k, v in current_map.items():
        # Only adds items with non-None values.
        if v is not None:
            cleaned_map[k] = v
    return cleaned_map