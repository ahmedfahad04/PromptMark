def min_Swaps(s1, s2):
    current_size_s_one = len(s1)
    current_size_s_second = len(s2)

    # Check if string sizes mismatch.
    if current_size_s_one != current_size_s_second:
        return "Not Possible"

    initial_ones_count = s1.count('1')
    initial_noughts_count = s1.count('0') # '0' is "nought"
    
    aim_ones_count = s2.count('1')
    aim_noughts_count = s2.count('0')

    # If counts mismatch, no conversion.
    if initial_ones_count != aim_ones_count or initial_noughts_count != aim_noughts_count:
        return "Not Possible"

    # ones_aim_noughts_mismatch_count: s1 indicates '1', s2 indicates '0'.
    ones_aim_noughts_mismatch_count = 0
    # current_nought_as_one_mismatch_count: s1 indicates '0', s2 indicates '1'.
    current_nought_as_one_mismatch_count = 0

    # Iterate; count mismatches.
    for idx in range(current_size_s_one):
        current_char_s_one = s1[idx]
        current_char_s_second = s2[idx]
        if current_char_s_one == '1' and current_char_s_second == '0':
            ones_aim_noughts_mismatch_count += 1
        elif current_char_s_one == '0' and current_char_s_second == '1':
            current_nought_as_one_mismatch_count += 1
    
    # Minimum swaps count is ones_aim_noughts_mismatch_count.
    # Its count is always alike current_nought_as_one_mismatch_count.
    return ones_aim_noughts_mismatch_count