def empty_dit(current_collection: dict) -> bool:
    # Initial check: if current_collection is an empty sequence (e.g., [], {}), 
    # it vacuously contains no non-empty dictionaries.
    if not current_collection:
        return True

    for unit_item in current_collection:
        # Check if the current unit_item is NOT an empty dictionary.
        # This condition is true if:
        # 1. unit_item is not a dictionary (e.g., a set, list, int).
        # OR
        # 2. unit_item IS a dictionary, but it is NOT empty (e.g., {'key': 'value'}).
        if not isinstance(unit_item, dict) or unit_item:
            return False # An item that is not an empty dictionary was found

    # If the loop completes, it means all items examined were empty dictionaries.
    return True