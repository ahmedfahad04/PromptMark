def rotate_right(original_array, k_moves):
    array_size = len(original_array)

    if array_size == 0:
        return []

    # Calculates actual moves. Uses modulo to handle k_moves larger than array_size.
    actual_moves = k_moves % array_size

    # Suffix units: These are the items that move from the end to the start.
    suffix_units = original_array[array_size - actual_moves:]
    # Commencing units: These are the items that remain in their relative order.
    commencing_units = original_array[:array_size - actual_moves]

    # Joins suffix and commencing units, creating new rotated array.
    rotated_array = suffix_units + commencing_units
    
    return rotated_array