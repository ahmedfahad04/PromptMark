def text_lowercase_underscore(text):
    """
    Checks if the input string contains sequences of lowercase letters 
    joined with an underscore.

    Args:
        text (str): The input string to check.

    Returns:
        bool: True if the string contains the specified pattern, False otherwise.
    """
    pattern = '[a-z]+_[a-z]+'
    return bool(re.search(pattern, text))
