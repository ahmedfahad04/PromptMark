def drop_empty(input_dict: dict) -> dict:
    """
    Drops items from a dictionary where the value is None.

    Args:
        input_dict: The dictionary from which to drop empty items.

    Returns:
        A new dictionary with all items whose value was None removed.
    """
    filtered_dict = {key: value for key, value in input_dict.items() if value is not None}
    return filtered_dict
