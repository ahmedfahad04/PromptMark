def group_tuples(list_of_tuples):
    """
    Groups a list of 2-element tuples by their first element.

    Args:
        list_of_tuples: A list of tuples, where each tuple has at least two elements.
                        e.g., [('x', 'y'), ('x', 'z'), ('w', 't')]

    Returns:
        A list of tuples, where each tuple starts with a common first element
        followed by all the second elements associated with that first element.
        e.g., [('x', 'y', 'z'), ('w', 't')]
    """
    grouped_data = defaultdict(list)
    for first_element, second_element in list_of_tuples:
        grouped_data[first_element].append(second_element)
    result_list = []
    for first_element, second_elements_list in grouped_data.items():
        new_combined_tuple = (first_element,) + tuple(second_elements_list)
        result_list.append(new_combined_tuple)
    return result_list
