def power(base, exponent):
    """
  Calculates the value of a 'base' number raised to the power of an 'exponent'.

  Args:
    base: The base number (e.g., 3 in 3^4).
    exponent: The power to which the base is raised (e.g., 4 in 3^4).

  Returns:
    The result of base raised to the power of exponent.
  """
    return base ** exponent
