def extract_quotation(text: str) -> list[str]:
    """
    Extracts all substrings enclosed within double quotation marks (" ")
    from the given string. It ignores single quotation marks (' ').

    Args:
        text: The input string from which to extract quoted values.

    Returns:
        A list of strings, where each string is a value found between
        double quotation marks. Returns an empty list if no such values are found.
    """
    return re.findall('"([^"]*)"', text)
