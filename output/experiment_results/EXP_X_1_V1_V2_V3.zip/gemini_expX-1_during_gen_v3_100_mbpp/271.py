def even_Power_Sum(n: int) -> int:
    """
    Calculates the sum of the first n even natural numbers, each raised to the fifth power.

    Args:
        n (int): The number of even natural numbers to consider.
                 Assumes n is a positive integer.

    Returns:
        int: The sum of the first n even natural numbers raised to the fifth power.
    """
    total_sum = 0
    for i in range(1, n + 1):
        current_even_number = 2 * i
        fifth_power = current_even_number ** 5
        total_sum += fifth_power
    return total_sum
