def start_withp(words_list):
    """
    Finds and returns the first two words starting with 'p' (case-insensitive)
    from a list of strings.

    Args:
        words_list: A list of strings, where each string might contain
                    one or more words separated by spaces.

    Returns:
        A tuple containing the first two words found that start with 'p'.
    """
    p_words = []
    for sentence in words_list:
        for word in sentence.split():
            if word.lower().startswith('p'):
                p_words.append(word)
                if len(p_words) == 2:
                    return (p_words[0], p_words[1])
    return (p_words[0], p_words[1])
