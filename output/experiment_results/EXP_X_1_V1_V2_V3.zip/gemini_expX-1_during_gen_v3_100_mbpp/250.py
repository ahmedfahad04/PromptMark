def count_X(input_tuple: tuple, element_to_count) -> int:
    """
    Counts the occurrences of a specific element within a given tuple.

    This function leverages Python's built-in tuple.count() method,
    which provides an efficient way to find how many times an element
    appears in the tuple.

    Args:
        input_tuple (tuple): The tuple to search within.
        element_to_count: The element whose occurrences need to be counted.
                          It can be of any type present in the tuple.

    Returns:
        int: The number of times 'element_to_count' appears in 'input_tuple'.
    """
    return input_tuple.count(element_to_count)
