def interleave_lists(list1, list2, list3):
    """
    Interleaves elements from three lists of the same length into a single flat list.

    This function iterates through the lists simultaneously, taking one element
    from each list in order and appending them to a new result list.

    Args:
        list1 (list): The first input list.
        list2 (list): The second input list.
        list3 (list): The third input list.

    Returns:
        list: A new list containing elements interleaved from the three input lists.

    Examples:
        >>> interleave_lists([1,2], [10,20], [100,200])
        [1, 10, 100, 2, 20, 200]
    """
    interleaved_result = []
    for item1, item2, item3 in zip(list1, list2, list3):
        interleaved_result.append(item1)
        interleaved_result.append(item2)
        interleaved_result.append(item3)
    return interleaved_result
