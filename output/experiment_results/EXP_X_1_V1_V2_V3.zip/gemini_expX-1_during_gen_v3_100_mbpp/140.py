def extract_singly(list_of_lists):
    """
    Flattens a list of lists (or tuples) into a single set of unique numbers.

    Args:
        list_of_lists: A list where each element is another list or tuple of numbers.
                       Example: [(3, 4, 5), (4, 5, 7), (1, 4)]

    Returns:
        A set containing all unique numbers extracted from the nested lists/tuples.
        Example: {1, 3, 4, 5, 7}
    """
    unique_numbers = set()
    for inner_list in list_of_lists:
        for number in inner_list:
            unique_numbers.add(number)
    return unique_numbers
