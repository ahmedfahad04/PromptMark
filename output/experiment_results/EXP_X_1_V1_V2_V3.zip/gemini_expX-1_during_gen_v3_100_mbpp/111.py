def common_in_nested_lists(nested_lists):
    """
    Finds the common elements in a given list of nested lists.

    Args:
        nested_lists: A list containing multiple inner lists.

    Returns:
        A set containing elements that are present in all inner lists.
        Returns an empty set if the input nested_lists is empty.
    """
    if not nested_lists:
        return set()
    common_elements = set(nested_lists[0])
    for i in range(1, len(nested_lists)):
        common_elements = common_elements.intersection(set(nested_lists[i]))
        if not common_elements:
            break
    return common_elements
