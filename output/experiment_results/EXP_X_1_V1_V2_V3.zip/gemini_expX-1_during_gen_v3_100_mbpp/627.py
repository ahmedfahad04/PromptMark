def find_First_Missing(nums: list) -> int:
    """
    Finds the smallest missing number from a sorted list of natural numbers.
    Assumes natural numbers include 0 based on the provided test cases.

    Args:
        nums: A sorted list of natural numbers.

    Returns:
        The smallest natural number that is missing from the list.
    """
    if not nums or nums[0] != 0:
        return 0
    expected_num = 0
    for num in nums:
        if num != expected_num:
            return expected_num
        expected_num += 1
    return expected_num
