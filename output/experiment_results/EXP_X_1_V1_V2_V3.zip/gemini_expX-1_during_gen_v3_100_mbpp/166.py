def find_even_pair(arr: list[int]) -> int:
    """
    Counts the number of pairs of integers in a list that XOR to an even number.

    The XOR (^) of two integers results in an even number if and only if
    both integers have the same parity (both are even or both are odd).

    This function counts the number of pairs (a, b) from the input list
    such that 'a' and 'b' are either both even or both odd.
    The order of elements in a pair does not matter (e.g., (a, b) is the same as (b, a)).

    Args:
        arr: A list of integers.

    Returns:
        The total count of pairs whose XOR sum is an even number.
    """
    count_even = 0
    count_odd = 0
    for num in arr:
        if num % 2 == 0:
            count_even += 1
        else:
            count_odd += 1
    pairs_from_even = count_even * (count_even - 1) // 2
    pairs_from_odd = count_odd * (count_odd - 1) // 2
    return pairs_from_even + pairs_from_odd
