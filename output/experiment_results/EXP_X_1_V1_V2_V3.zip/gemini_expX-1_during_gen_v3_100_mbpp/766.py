def pair_wise(input_list: list) -> list[tuple]:
    """
    Returns a list of all pairs of consecutive items in a given list.

    For example:
    pair_wise([1, 2, 3, 4]) would return [(1, 2), (2, 3), (3, 4)]

    Args:
        input_list: The list from which to extract consecutive pairs.

    Returns:
        A list of tuples, where each tuple contains two consecutive items
        from the input_list. If the input list has fewer than two elements,
        an empty list is returned.
    """
    pairs = []
    for i in range(len(input_list) - 1):
        pair = (input_list[i], input_list[i + 1])
        pairs.append(pair)
    return pairs
