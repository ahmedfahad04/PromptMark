def count_bidirectional(tuples_list):
    """
    Counts the number of bidirectional tuple pairs in a list.

    A bidirectional tuple pair consists of two tuples (a, b) and (b, a).
    For instance, if the list contains (1, 2) and (2, 1), they form one pair.
    If the list contains one (1, 2) and two instances of (2, 1), this forms two pairs:
    (1, 2) with the first (2, 1), and (1, 2) with the second (2, 1).

    Args:
        tuples_list: A list of tuples, e.g., [(5, 6), (1, 2), (6, 5), (2, 1)].

    Returns:
        The total count of bidirectional tuple pairs.
    """
    counts = collections.Counter(tuples_list)
    total_pairs = 0
    for (a, b), count_ab in counts.items():
        count_ba = counts[b, a]
        if a == b:
            continue
        if (a, b) < (b, a):
            total_pairs += count_ab * count_ba
    return total_pairs
