def is_perfect_square(num: int) -> bool:
    """
    Checks if a given number is a perfect square.

    A perfect square is an integer that can be expressed as the product of an integer by itself.
    For example, 9 is a perfect square because 3 * 3 = 9.

    Args:
        num: The integer to check.

    Returns:
        True if the number is a perfect square, False otherwise.
    """
    if num < 0:
        return False
    sqrt_val = int(math.sqrt(num))
    return sqrt_val * sqrt_val == num
