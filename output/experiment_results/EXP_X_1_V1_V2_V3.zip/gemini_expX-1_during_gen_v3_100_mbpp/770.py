def odd_num_sum(n):
    """
    Calculates the sum of the fourth power of the first n odd natural numbers.

    For example:
    If n = 2, the first two odd numbers are 1 and 3.
    The sum would be (1^4) + (3^4) = 1 + 81 = 82.

    Args:
        n (int): The number of first odd natural numbers to consider.
                 Must be a non-negative integer.

    Returns:
        int: The sum of the fourth power of the first n odd natural numbers.
    """
    total_sum = 0
    for i in range(1, n + 1):
        odd_num = 2 * i - 1
        fourth_power = odd_num ** 4
        total_sum += fourth_power
    return total_sum
