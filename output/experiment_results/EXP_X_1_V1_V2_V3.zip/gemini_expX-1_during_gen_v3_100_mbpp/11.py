def remove_Occ(input_string, char_to_remove):
    """
    Removes the first and last occurrence of a given character from a string.

    Args:
        input_string (str): The string from which to remove characters.
        char_to_remove (str): The character to be removed.

    Returns:
        str: The modified string with the first and last occurrences of the
             character removed. If the character is not found or found only once,
             it removes accordingly.
    """
    first_idx = input_string.find(char_to_remove)
    if first_idx == -1:
        return input_string
    temp_string = input_string[:first_idx] + input_string[first_idx + 1:]
    last_idx = temp_string.rfind(char_to_remove)
    if last_idx == -1:
        return temp_string
    else:
        return temp_string[:last_idx] + temp_string[last_idx + 1:]
