def move_num(s: str) -> str:
    """
    Moves all numeric characters to the end of the given string,
    maintaining the relative order of both non-numeric and numeric characters.

    Args:
        s (str): The input string.

    Returns:
        str: A new string with all numbers moved to the end.
    """
    non_digits = []
    digits = []
    for char in s:
        if char.isdigit():
            digits.append(char)
        else:
            non_digits.append(char)
    return ''.join(non_digits) + ''.join(digits)
