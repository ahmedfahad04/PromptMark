def surface_Area(base_edge, height):
    """
    Calculates the total surface area of a square pyramid.

    Based on the provided test cases, the 'height' parameter is interpreted
    as the 'slant height' (l) of the pyramid, not the perpendicular height (h).

    The formula for the surface area of a square pyramid (with base edge 'a'
    and slant height 'l') is:
    Surface Area = (Area of Base) + (Area of 4 Triangular Faces)
    Surface Area = (a * a) + (4 * 0.5 * a * l)
    Surface Area = a^2 + 2 * a * l

    Args:
        base_edge (float or int): The length of one side of the square base.
        height (float or int): The slant height of the pyramid (distance from the apex
                               to the midpoint of a base edge).

    Returns:
        float or int: The total surface area of the square pyramid.
    """
    area_base = base_edge ** 2
    area_lateral = 2 * base_edge * height
    total_surface_area = area_base + area_lateral
    return total_surface_area
