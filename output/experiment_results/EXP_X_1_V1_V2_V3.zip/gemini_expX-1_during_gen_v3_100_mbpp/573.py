def unique_product(numbers_list):
    """
    Calculates the product of unique numbers in a given list.

    Args:
        numbers_list: A list of numbers (integers or floats).

    Returns:
        The product of all unique numbers in the list.
        Returns 1 if the list is empty or contains no unique numbers (after processing).
        Returns 0 if 0 is one of the unique numbers.
    """
    unique_numbers = set(numbers_list)
    product = 1
    for number in unique_numbers:
        product *= number
        if product == 0:
            return 0
    return product
