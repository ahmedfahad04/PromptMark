def find_adverbs(text: str) -> str | None:
    """
    Finds the first word in a given string that ends with 'ly' (case-insensitive)
    and returns its position and the word itself.

    Args:
        text: The input string to search within.

    Returns:
        A string formatted as 'start_index-end_index: word' if an adverb is found.
        Returns None if no such word is found.
    """
    for match in re.finditer('\\b\\w+\\b', text):
        word = match.group(0)
        start_index = match.start()
        end_index = match.end()
        if word.lower().endswith('ly'):
            return f'{start_index}-{end_index}: {word}'
    return None
