def Find_Min(list_of_sublists):
    """
    Finds the sublist with the minimum length from a list of sublists.

    Args:
        list_of_sublists: A list containing multiple sublists.

    Returns:
        The sublist that has the minimum length.
    """
    if not list_of_sublists:
        return []
    min_length_sublist = min(list_of_sublists, key=len)
    return min_length_sublist
