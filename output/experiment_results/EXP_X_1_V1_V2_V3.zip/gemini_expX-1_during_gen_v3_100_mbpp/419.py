def round_and_sum(numbers):
    """
    Rounds every number in a given list, calculates their total sum,
    and then multiplies this sum by the length of the original list.

    Args:
        numbers (list): A list of numerical values (integers or floats).

    Returns:
        int: The total sum of rounded numbers multiplied by the length of the list.
    """
    list_length = len(numbers)
    rounded_numbers = [round(num) for num in numbers]
    sum_of_rounded = sum(rounded_numbers)
    final_result = sum_of_rounded * list_length
    return final_result
