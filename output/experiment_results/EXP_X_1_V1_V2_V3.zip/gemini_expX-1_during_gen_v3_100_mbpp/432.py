def median_trapezium(parallel_side_a, parallel_side_b, _):
    """
    Calculates the median length of a trapezium.

    The median length of a trapezium (also known as the mid-segment)
    is the average of the lengths of its two parallel sides.
    The third parameter is typically for another dimension (like height or a non-parallel side)
    but is not used in this specific median length calculation.

    Args:
        parallel_side_a (float or int): Length of the first parallel side.
        parallel_side_b (float or int): Length of the second parallel side.
        _ (float or int): An additional dimension, which is ignored for this calculation.

    Returns:
        float: The median length of the trapezium.
    """
    return (parallel_side_a + parallel_side_b) / 2
