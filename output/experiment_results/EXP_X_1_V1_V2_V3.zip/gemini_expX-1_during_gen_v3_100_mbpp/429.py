def and_tuples(tup1: tuple, tup2: tuple) -> tuple:
    """
    Performs an element-wise bitwise AND operation between corresponding
    elements of two input tuples.

    Args:
        tup1 (tuple): The first input tuple of integers.
        tup2 (tuple): The second input tuple of integers.
                      Assumes both tuples have the same length.

    Returns:
        tuple: A new tuple containing the results of the element-wise
               bitwise AND operations.
    """
    return tuple((a & b for a, b in zip(tup1, tup2)))
