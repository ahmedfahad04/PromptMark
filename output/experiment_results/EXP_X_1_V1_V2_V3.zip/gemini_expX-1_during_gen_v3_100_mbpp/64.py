def subject_marks(tuples_list):
    """
    Sorts a list of tuples based on the second element (value) of each tuple.

    Args:
        tuples_list: A list of tuples, where each tuple contains at least two elements.

    Returns:
        A new list of tuples, sorted by the second element of each tuple in ascending order.
    """
    return sorted(tuples_list, key=lambda x: x[1])
