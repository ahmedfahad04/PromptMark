def substract_elements(tuple1, tuple2):
    """
    Subtracts the elements of the second tuple from the corresponding elements
    of the first tuple with the same index.

    Args:
        tuple1 (tuple): The first tuple.
        tuple2 (tuple): The second tuple.

    Returns:
        tuple: A new tuple containing the results of the subtraction.
               The i-th element of the result is tuple1[i] - tuple2[i].
               Assumes both tuples have the same length.
    """
    result_list = [t1_elem - t2_elem for t1_elem, t2_elem in zip(tuple1, tuple2)]
    return tuple(result_list)
