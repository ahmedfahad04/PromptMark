def otherside_rightangle(side1: float, side2: float) -> float:
    """
    Calculates the length of the third side of a right-angled triangle.
    This function assumes that the two provided sides are the lengths of the
    two shorter sides (legs) of the triangle, and it calculates the hypotenuse.

    Args:
        side1 (float): The length of one leg of the right-angled triangle.
        side2 (float): The length of the other leg of the right-angled triangle.

    Returns:
        float: The length of the hypotenuse.
              (Based on the Pythagorean theorem: c = sqrt(a^2 + b^2))
    """
    hypotenuse_squared = side1 ** 2 + side2 ** 2
    hypotenuse = math.sqrt(hypotenuse_squared)
    return hypotenuse
