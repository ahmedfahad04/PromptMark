def find_Average_Of_Cube(n: int) -> float:
    """
    Calculates the average of the cubes of the first n natural numbers.

    The sum of cubes of the first n natural numbers is given by the formula:
    [n * (n + 1) / 2]^2

    The average is then (Sum of cubes) / n.

    Args:
        n: A positive integer representing the number of natural numbers.

    Returns:
        The average of the cubes of the first n natural numbers as a float.

    Raises:
        ValueError: If n is less than 1, as natural numbers start from 1.
    """
    if n < 1:
        raise ValueError('n must be a positive integer.')
    sum_of_n_natural_numbers = n * (n + 1) / 2
    sum_of_cubes = sum_of_n_natural_numbers ** 2
    average = sum_of_cubes / n
    return average
