def intersection_array(arr1, arr2):
    """
    Finds the intersection of two arrays.

    The intersection contains elements that are common to both arrays.
    This implementation uses sets for efficient computation of the intersection.

    Args:
        arr1 (list): The first input array.
        arr2 (list): The second input array.

    Returns:
        list: A new list containing the common elements found in both arrays.
              The order of elements in the result is not guaranteed.
    """
    set1 = set(arr1)
    set2 = set(arr2)
    common_elements = set1.intersection(set2)
    return list(common_elements)
