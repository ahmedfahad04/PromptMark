def find_lucas(n: int) -> int:
    """
    Calculates the n'th Lucas number.

    The Lucas sequence is defined as L(0) = 2, L(1) = 1,
    and L(n) = L(n-1) + L(n-2) for n > 1.

    Args:
        n: The index of the Lucas number to find (non-negative integer).

    Returns:
        The n'th Lucas number.
    """
    if n == 0:
        return 2
    if n == 1:
        return 1
    a, b = (2, 1)
    for _ in range(2, n + 1):
        next_lucas = a + b
        a = b
        b = next_lucas
    return b
