def check_value(dictionary, value_to_check):
    """
  Checks if all values in a dictionary are equal to a specified value.

  Args:
    dictionary: The input dictionary.
    value_to_check: The specific value to compare against all dictionary values.

  Returns:
    True if all values in the dictionary are equal to 'value_to_check',
    False otherwise. Returns True if the dictionary is empty, as there are no
    values to contradict the condition.
  """
    return all((v == value_to_check for v in dictionary.values()))
