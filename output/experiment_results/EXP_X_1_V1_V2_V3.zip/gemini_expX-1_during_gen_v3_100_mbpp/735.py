def toggle_middle_bits(num: int) -> int:
    """
    Toggles all bits of the number except the first (most significant)
    and the last (least significant) bit.

    Args:
        num: The integer whose middle bits are to be toggled.

    Returns:
        The integer after toggling its middle bits.
    """
    if num == 0:
        return 0
    n_bits = num.bit_length()
    if n_bits <= 2:
        return num
    mask_all_but_msb = (1 << n_bits - 1) - 1
    mask_middle_bits = mask_all_but_msb & ~1
    return num ^ mask_middle_bits
