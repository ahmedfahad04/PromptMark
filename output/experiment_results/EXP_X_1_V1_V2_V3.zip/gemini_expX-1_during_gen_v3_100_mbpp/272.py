def rear_extract(list_of_tuples):
    """
  Extracts the rear (last) element from each tuple in a list of tuples.

  Args:
    list_of_tuples: A list where each element is a tuple.

  Returns:
    A new list containing the last element of each tuple.
  """
    return [item_tuple[-1] for item_tuple in list_of_tuples]
