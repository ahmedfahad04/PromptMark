def max_product(arr):
    """
    Finds the maximum product formed by multiplying numbers of an increasing subsequence
    of the given array.

    Args:
        arr: A list of integers. Assumes elements are positive integers.

    Returns:
        The maximum product of an increasing subsequence. Returns 0 if the array is empty.
    """
    n = len(arr)
    if n == 0:
        return 0
    dp = list(arr)
    for i in range(n):
        for j in range(i):
            if arr[i] > arr[j]:
                dp[i] = max(dp[i], dp[j] * arr[i])
    return max(dp)
