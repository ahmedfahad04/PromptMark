def find_Max_Num(digits: list) -> int:
    """
    Finds the largest number that can be formed with the given list of digits.

    Args:
        digits: A list of integers representing the digits.

    Returns:
        The largest integer that can be formed by arranging the given digits.
    """
    digits.sort(reverse=True)
    num_str = ''.join((str(digit) for digit in digits))
    return int(num_str)
