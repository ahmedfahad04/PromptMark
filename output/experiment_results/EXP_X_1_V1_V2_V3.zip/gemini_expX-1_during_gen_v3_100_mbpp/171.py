def perimeter_pentagon(side_length):
    """
  Calculates the perimeter of a regular pentagon.

  A regular pentagon has 5 equal sides. The perimeter is the sum of the lengths
  of all its sides.

  Args:
    side_length: The length of one side of the regular pentagon.

  Returns:
    The perimeter of the regular pentagon.
  """
    perimeter = 5 * side_length
    return perimeter
