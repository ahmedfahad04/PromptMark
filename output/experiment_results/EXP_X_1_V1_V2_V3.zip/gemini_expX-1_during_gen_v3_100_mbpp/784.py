def mul_even_odd(numbers):
    """
    Finds the first even and first odd number in a list and returns their product.

    Args:
        numbers (list): A list of integers.

    Returns:
        int: The product of the first even and first odd number found in the list.
             Assumes that the list will always contain at least one even and one odd number.
    """
    first_even = None
    first_odd = None
    for num in numbers:
        if num % 2 == 0:
            if first_even is None:
                first_even = num
        elif first_odd is None:
            first_odd = num
        if first_even is not None and first_odd is not None:
            break
    return first_even * first_odd
