def extract_nth_element(list_of_tuples, n):
    """
  Extracts the nth element from each tuple in a given list of tuples.

  Args:
    list_of_tuples: A list where each element is a tuple.
    n: An integer representing the index of the element to extract from each tuple.
       (0-indexed)

  Returns:
    A new list containing the nth element from each tuple.
  """
    return [tup[n] for tup in list_of_tuples]
