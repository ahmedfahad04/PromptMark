def sum_even_and_even_index(numbers):
    """
    Calculates the sum of even numbers that are located at even positions (indices) in a list.

    Args:
        numbers: A list of integers.

    Returns:
        The sum of even numbers found at even indices.
    """
    total_sum = 0
    for index, num in enumerate(numbers):
        is_num_even = num % 2 == 0
        is_index_even = index % 2 == 0
        if is_num_even and is_index_even:
            total_sum += num
    return total_sum
