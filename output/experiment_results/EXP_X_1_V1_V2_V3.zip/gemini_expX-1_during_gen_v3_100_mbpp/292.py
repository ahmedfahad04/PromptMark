def find(num1, num2):
    """
  Calculates the quotient of two numbers, rounded down to the nearest integer (floor division).

  Args:
    num1: The dividend.
    num2: The divisor.

  Returns:
    The integer quotient of num1 divided by num2, rounded down.
  """
    return num1 // num2
