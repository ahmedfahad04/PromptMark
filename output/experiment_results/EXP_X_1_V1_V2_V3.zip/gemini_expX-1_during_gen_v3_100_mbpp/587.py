def list_tuple(input_list):
    """
  Converts a given list into a tuple.

  Args:
    input_list: The list to be converted.

  Returns:
    A tuple containing the same elements as the input list.
  """
    return tuple(input_list)
