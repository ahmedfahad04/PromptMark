def occurance_substring(main_string, sub_string):
    """
    Finds the first occurrence of a substring within a main string,
    returning the substring and its start and end positions.

    Args:
        main_string (str): The string to search within.
        sub_string (str): The substring to search for.

    Returns:
        tuple: A tuple (sub_string, start_index, end_index) if found,
               otherwise None.
    """
    start_index = main_string.find(sub_string)
    if start_index == -1:
        return None
    else:
        end_index = start_index + len(sub_string)
        return (sub_string, start_index, end_index)
