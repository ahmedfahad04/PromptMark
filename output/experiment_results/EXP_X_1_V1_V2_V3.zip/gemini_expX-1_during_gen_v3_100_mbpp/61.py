def count_Substrings(s: str) -> int:
    """
    Counts the number of substrings in a given string of digits where the sum of the
    digits in the substring is equal to the length of the substring.

    Args:
        s: The input string consisting of digits (e.g., '112112').

    Returns:
        The total count of substrings that satisfy the condition.
    """
    n = len(s)
    count = 0
    for i in range(n):
        current_sum = 0
        for j in range(i, n):
            current_sum += int(s[j])
            current_length = j - i + 1
            if current_sum == current_length:
                count += 1
    return count
