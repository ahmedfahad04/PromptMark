def find_first_occurrence(arr: list, target: int) -> int:
    """
    Finds the index of the first occurrence of a given number in a sorted array.

    Args:
        arr: A list of numbers, assumed to be sorted in ascending order.
        target: The number to search for.

    Returns:
        The index of the first occurrence of the target number.
        Returns -1 if the target number is not found in the array.
    """
    low = 0
    high = len(arr) - 1
    result = -1
    while low <= high:
        mid = low + (high - low) // 2
        if arr[mid] == target:
            result = mid
            high = mid - 1
        elif arr[mid] < target:
            low = mid + 1
        else:
            high = mid - 1
    return result
