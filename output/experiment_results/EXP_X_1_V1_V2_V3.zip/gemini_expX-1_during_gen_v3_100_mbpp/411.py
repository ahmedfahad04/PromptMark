def snake_to_camel(snake_case_string: str) -> str:
    """
    Converts a snake_case string to a CamelCase string.

    Args:
        snake_case_string: The input string in snake_case (e.g., 'android_tv').

    Returns:
        The converted string in CamelCase (e.g., 'AndroidTv').
    """
    words = snake_case_string.split('_')
    camel_case_words = [word.capitalize() for word in words]
    return ''.join(camel_case_words)
