def string_to_tuple(input_string):
    """
  Converts a given string into a tuple of its individual characters.

  Args:
    input_string: The string to be converted.

  Returns:
    A tuple containing each character of the input string as an element.
  """
    return tuple(input_string)
