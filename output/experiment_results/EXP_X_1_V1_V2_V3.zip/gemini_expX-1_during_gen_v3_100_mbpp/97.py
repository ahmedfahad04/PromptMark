def frequency_lists(list_of_lists: list) -> dict:
    """
    Finds the frequency of each element in a flattened list of lists.

    Args:
        list_of_lists: A list containing sublists of elements.

    Returns:
        A dictionary where keys are elements and values are their frequencies
        in the flattened list.
    """
    flattened_list = [item for sublist in list_of_lists for item in sublist]
    frequency_map = collections.Counter(flattened_list)
    return dict(frequency_map)
