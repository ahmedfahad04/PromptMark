def replace_char(s: str, old_char: str, new_char: str) -> str:
    """
    Replaces all occurrences of a specified character in a string with another character.

    Args:
        s: The input string.
        old_char: The character to be replaced.
        new_char: The character to replace old_char with.

    Returns:
        A new string with all instances of old_char replaced by new_char.
    """
    return s.replace(old_char, new_char)
