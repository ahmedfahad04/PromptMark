def count_same_pair(list1: list, list2: list) -> int:
    """
    Counts the number of indices where two lists of the same length have identical values.

    Args:
        list1: The first list of numbers.
        list2: The second list of numbers, which must be of the same length as list1.

    Returns:
        The total count of indices where list1[i] == list2[i].
    """
    same_value_count = 0
    for i in range(len(list1)):
        if list1[i] == list2[i]:
            same_value_count += 1
    return same_value_count
