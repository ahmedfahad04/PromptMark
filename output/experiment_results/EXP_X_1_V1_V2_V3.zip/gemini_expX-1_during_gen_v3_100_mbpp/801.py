def test_three_equal(a, b, c):
    """
    Counts the number of equal integers among three given numbers.

    Args:
        a (int): The first integer.
        b (int): The second integer.
        c (int): The third integer.

    Returns:
        int: The count of equal numbers.
             - 3 if all three numbers are equal.
             - 2 if exactly two numbers are equal.
             - 0 if no numbers are equal.
    """
    numbers = [a, b, c]
    num_unique = len(set(numbers))
    if num_unique == 1:
        return 3
    elif num_unique == 2:
        return 2
    else:
        return 0
