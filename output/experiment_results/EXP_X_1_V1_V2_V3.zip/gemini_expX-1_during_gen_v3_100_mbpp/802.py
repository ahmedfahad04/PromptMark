def count_rotation(arr: list[int]) -> int:
    """
    Counts the number of rotations required to generate a sorted array.
    This function determines the 'rotation count' based on the first
    occurrence where an element is greater than its subsequent element.

    Args:
        arr: A list of integers.

    Returns:
        The number of rotations. Returns 0 if the array is already sorted
        or contains 0/1 element.
    """
    n = len(arr)
    if n <= 1:
        return 0
    for i in range(n - 1):
        if arr[i] > arr[i + 1]:
            return i + 1
    return 0
