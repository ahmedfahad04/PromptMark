def largest_subset(nums: list[int]) -> int:
    """
    Finds the size of the largest subset of a list of numbers such that
    every pair of numbers in the subset is divisible by each other.

    This is achieved using dynamic programming:
    1. Sort the input list to ensure that if 'a' divides 'b', 'a' appears
       before 'b' in the sorted list. This simplifies divisibility checks.
    2. Initialize a DP array where dp[i] stores the length of the longest
       divisible subset ending with nums[i].
    3. Iterate through the sorted numbers. For each number nums[i], check
       all preceding numbers nums[j]. If nums[i] is divisible by nums[j],
       it means nums[i] can extend the divisible subset ending at nums[j].
       Update dp[i] accordingly.
    4. The maximum value in the DP array is the length of the longest
       divisible subset.

    Args:
        nums: A list of integers.

    Returns:
        The size of the largest divisible subset.
    """
    n = len(nums)
    if n == 0:
        return 0
    nums.sort()
    dp = [1] * n
    for i in range(n):
        for j in range(i):
            if nums[i] % nums[j] == 0:
                dp[i] = max(dp[i], 1 + dp[j])
    return max(dp)
