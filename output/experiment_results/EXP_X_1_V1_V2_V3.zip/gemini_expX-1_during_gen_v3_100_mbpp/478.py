def remove_lowercase(input_string):
    """
    Removes all lowercase characters from the input string and returns the modified string.

    Args:
        input_string (str): The string from which to remove lowercase characters.

    Returns:
        str: The new string with all lowercase characters removed.
    """
    result_chars = []
    for char in input_string:
        if not char.islower():
            result_chars.append(char)
    return ''.join(result_chars)
