def square_Sum(n: int) -> int:
    """
    Calculates the sum of the squares of the first n odd natural numbers.

    For example:
    If n = 2, the first 2 odd natural numbers are 1 and 3.
    Their squares are 1*1 = 1 and 3*3 = 9.
    The sum of squares is 1 + 9 = 10.

    Args:
        n (int): The number of odd natural numbers to consider.
                 Must be a positive integer.

    Returns:
        int: The sum of the squares of the first n odd natural numbers.
    """
    total_sum = 0
    for k in range(1, n + 1):
        odd_number = 2 * k - 1
        square_of_odd = odd_number ** 2
        total_sum += square_of_odd
    return total_sum
