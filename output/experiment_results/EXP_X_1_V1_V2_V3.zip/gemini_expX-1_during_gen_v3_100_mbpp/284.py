# Test cases
print(f"check_element(['green', 'orange', 'black', 'white'], 'blue') == False: {check_element(['green', 'orange', 'black', 'white'], 'blue') == False}")
print(f"check_element([1, 2, 3, 4], 7) == False: {check_element([1, 2, 3, 4], 7) == False}")
print(f"check_element(['green', 'green', 'green', 'green'], 'green') == True: {check_element(['green', 'green', 'green', 'green'], 'green') == True}")

# Additional test cases for completeness
print(f"check_element([], 'any') == True (empty list): {check_element([], 'any') == True}")
print(f"check_element([5], 5) == True: {check_element([5], 5) == True}")
print(f"check_element([5], 6) == False: {check_element([5], 6) == False}")