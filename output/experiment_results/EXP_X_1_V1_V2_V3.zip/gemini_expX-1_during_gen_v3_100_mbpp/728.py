def sum_list(list1: list, list2: list) -> list:
    """
    Takes two lists of numbers as input and returns a new list where each
    element is the sum of the corresponding elements from the input lists.

    Args:
        list1: The first list of numbers [a_1, ..., a_n].
        list2: The second list of numbers [b_1, ..., b_n].
               It is assumed that both lists have the same length.

    Returns:
        A new list [a_1+b_1, ..., a_n+b_n].
    """
    return [x + y for x, y in zip(list1, list2)]
