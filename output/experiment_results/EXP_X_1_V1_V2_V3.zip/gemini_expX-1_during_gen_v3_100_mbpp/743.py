def rotate_right(lst, n):
    """
    Rotates a list to the right by a specified number of items.

    Args:
        lst (list): The list to be rotated.
        n (int): The number of positions to rotate the list to the right.

    Returns:
        list: The new list after rotation.
    """
    if not lst or n == 0:
        return list(lst)
    list_length = len(lst)
    n = n % list_length
    if n == 0:
        return list(lst)
    rotated_list = lst[-n:] + lst[:-n]
    return rotated_list
