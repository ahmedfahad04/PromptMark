def average_tuple(data_tuple: tuple) -> list:
    """
    Calculates the average of elements at the same position across all inner tuples.

    Given a tuple of tuples, this function treats the collection as a matrix
    and calculates the average of each "column".

    Args:
        data_tuple: A tuple of tuples, e.g., ((val1_a, val1_b), (val2_a, val2_b)).
                    It's assumed that all inner tuples have the same length and are not empty.

    Returns:
        A list where each element is the average of values from a specific column
        (i.e., elements at the same index) across all inner tuples.
        Returns an empty list if the input data_tuple is empty.
    """
    if not data_tuple:
        return []
    averages = [sum(column_elements) / len(column_elements) for column_elements in zip(*data_tuple)]
    return averages
