def loss_amount(selling_price: float, cost_price: float) -> float:
    """
    Calculates the loss amount on a sale. If there is no loss (i.e., it's a profit
    or break-even), it returns 0.

    Args:
        selling_price (float): The price at which an item is sold.
        cost_price (float): The original cost of the item.

    Returns:
        float: The calculated loss amount, or 0 if there is no loss.
    """
    if cost_price > selling_price:
        return cost_price - selling_price
    else:
        return 0
