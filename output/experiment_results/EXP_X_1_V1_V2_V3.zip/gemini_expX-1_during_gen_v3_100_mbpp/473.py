def tuple_intersection(list1, list2):
    """
    Finds the intersection of elements between two lists of tuples,
    treating tuples like (a, b) and (b, a) as identical.

    Args:
        list1: The first list of tuples.
        list2: The second list of tuples.

    Returns:
        A set containing the common tuples (in a normalized sorted form)
        present in both input lists.
    """
    normalized_set1 = {tuple(sorted(t)) for t in list1}
    normalized_set2 = {tuple(sorted(t)) for t in list2}
    return normalized_set1.intersection(normalized_set2)
