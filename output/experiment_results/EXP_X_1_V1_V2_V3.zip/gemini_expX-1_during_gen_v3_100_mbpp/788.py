def new_tuple(input_list, input_string):
    """
  Creates a new tuple by combining elements from a given list and a string.

  Args:
    input_list: A list of elements to be included in the tuple.
    input_string: A string to be added as the last element of the tuple.

  Returns:
    A new tuple containing all elements from the input_list followed by the input_string.
  """
    return tuple(input_list) + (input_string,)
