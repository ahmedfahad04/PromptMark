def remove_dirty_chars(main_string: str, dirty_chars_string: str) -> str:
    """
    Removes characters from the first string which are present in the second string.

    This function iterates through the `main_string` and builds a new string
    containing only those characters that are NOT found in the `dirty_chars_string`.
    It uses a set for efficient lookup of "dirty" characters.

    Args:
        main_string: The string from which characters will be removed.
        dirty_chars_string: The string containing characters to be removed from the main_string.

    Returns:
        A new string with characters from main_string that are not in dirty_chars_string.
    """
    dirty_chars_set = set(dirty_chars_string)
    cleaned_chars = [char for char in main_string if char not in dirty_chars_set]
    return ''.join(cleaned_chars)
