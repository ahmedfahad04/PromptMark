def sum_range_list(numbers, start_index, end_index):
    """
    Calculates the sum of numbers in a list within a range specified by two indices.

    Args:
        numbers (list): The list of numbers.
        start_index (int): The starting index of the range (inclusive).
        end_index (int): The ending index of the range (inclusive).

    Returns:
        int or float: The sum of the numbers in the specified range.
                      Returns 0 if the specified range results in an empty list.
    """
    sublist = numbers[start_index:end_index + 1]
    return sum(sublist)
