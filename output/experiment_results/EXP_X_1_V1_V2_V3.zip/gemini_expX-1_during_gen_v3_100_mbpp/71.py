def comb_sort(arr):
    """
    Sorts a list of elements using the Comb Sort algorithm.

    Comb Sort is an improvement over Bubble Sort. It eliminates 'turtles'
    (small values near the end of the list) which slow down Bubble Sort.
    It does this by using a 'gap' that shrinks over time, similar to Shell Sort.
    """
    n = len(arr)
    if n <= 1:
        return arr
    gap = n
    shrink_factor = 1.3
    swapped = True
    while gap > 1 or swapped:
        gap = int(gap / shrink_factor)
        if gap < 1:
            gap = 1
        swapped = False
        for i in range(n - gap):
            if arr[i] > arr[i + gap]:
                arr[i], arr[i + gap] = (arr[i + gap], arr[i])
                swapped = True
    return arr
