def remove_whitespaces(input_string: str) -> str:
    """
    Removes all whitespace characters from the given string.

    This function leverages Python's string splitting and joining capabilities.
    When `str.split()` is called without any arguments, it splits the string
    by any sequence of whitespace characters (spaces, tabs, newlines) and
    discards any empty strings that result from the split.
    Then, `"".join()` concatenates these non-whitespace parts back together
    without any separator, effectively removing all original whitespaces.

    Args:
        input_string: The string from which to remove whitespaces.

    Returns:
        A new string with all whitespace characters removed.
    """
    return ''.join(input_string.split())
