def extract_string(string_list: list[str], size: int) -> list[str]:
    """
    Extracts strings of a specified length from a given list of strings.

    Args:
        string_list: A list of string values.
        size: The exact length of strings to extract.

    Returns:
        A new list containing only the strings from string_list that have the specified size.
    """
    extracted_strings = []
    for s in string_list:
        if len(s) == size:
            extracted_strings.append(s)
    return extracted_strings
