def sector_area(radius, angle):
    """
  Calculates the area of a circular sector.

  Args:
    radius: The radius of the circle.
    angle: The central angle of the sector in degrees.

  Returns:
    The area of the sector if the angle is 360 degrees or less,
    otherwise None.
  """
    if angle > 360:
        return None
    area = angle / 360 * math.pi * radius ** 2
    return area
