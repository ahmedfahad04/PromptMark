def count_vowels(s: str) -> int:
    """
    Counts characters (specifically consonants) that have at least one vowel
    as their immediate neighbor (left or right) in the given string.

    The interpretation of "characters which have vowels as their neighbors"
    is derived from the provided test cases. It implies counting consonants
    that are adjacent to at least one vowel.

    Args:
        s: The input string.

    Returns:
        The count of such characters.
    """
    vowels = {'a', 'e', 'i', 'o', 'u'}
    count = 0
    n = len(s)
    for i in range(n):
        current_char = s[i]
        if current_char not in vowels:
            has_vowel_neighbor = False
            if i > 0 and s[i - 1] in vowels:
                has_vowel_neighbor = True
            if i < n - 1 and s[i + 1] in vowels:
                has_vowel_neighbor = True
            if has_vowel_neighbor:
                count += 1
    return count
