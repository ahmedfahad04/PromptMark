def sequence(n: int) -> int:
    """
    Calculates the nth number in the Newman-Conway sequence.

    The Newman-Conway sequence is defined as:
    P(1) = 1
    P(2) = 1
    P(n) = P(P(n-1)) + P(n-P(n-1)) for n > 2

    This function uses dynamic programming (memoization) to store and retrieve
    previously calculated values, making it efficient for larger 'n' by avoiding
    redundant computations.

    Args:
        n: The positive integer representing the desired term in the sequence.

    Returns:
        The nth number in the Newman-Conway sequence.

    Raises:
        ValueError: If n is less than 1, as the sequence is defined for n >= 1.
    """
    if n < 1:
        raise ValueError('n must be a positive integer for the Newman-Conway sequence.')
    if n == 1 or n == 2:
        return 1
    dp = [0] * (n + 1)
    dp[1] = 1
    dp[2] = 1
    for i in range(3, n + 1):
        dp[i] = dp[dp[i - 1]] + dp[i - dp[i - 1]]
    return dp[n]
