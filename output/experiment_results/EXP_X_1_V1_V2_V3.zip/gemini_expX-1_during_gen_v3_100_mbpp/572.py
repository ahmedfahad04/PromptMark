def two_unique_nums(nums: list) -> list:
    """
    Removes duplicate numbers from a list, returning only those numbers
    that appear exactly once in the input list, while preserving their
    original order of appearance.

    Args:
        nums: A list of integers.

    Returns:
        A new list containing only the numbers that appear exactly once.
    """
    num_counts = Counter(nums)
    result = []
    for num in nums:
        if num_counts[num] == 1:
            result.append(num)
    return result
