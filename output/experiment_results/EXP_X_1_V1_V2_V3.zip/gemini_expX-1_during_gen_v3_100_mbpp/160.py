import math

def _egcd(a, b):
    """
    Extended Euclidean Algorithm.
    Computes (g, x, y) such that a*x + b*y = g = gcd(a, b).
    The 'g' returned is the absolute greatest common divisor.
    The coefficients x and y satisfy the equation for the returned g.
    """
    if b == 0:
        return a, 1, 0
    
    g, x1, y1 = _egcd(b, a % b)
    x = y1
    y = x1 - (a // b) * y1
    return g, x, y

def find_solution(a, b, n):
    """
    Finds integer solutions (x, y) for the linear Diophantine equation ax + by = n.
    Returns a tuple (x, y) if a solution exists, otherwise returns None.
    
    The function handles special cases where a or b are zero, and for the general case,
    it uses the Extended Euclidean Algorithm to find a particular solution and then
    adjusts it to match a specific representation (e.g., smallest non-negative x
    for positive a, b, consistent with Python's modulo operator behavior).
    """
    
    # Handle special cases where a or b (or both) are zero
    if a == 0 and b == 0:
        if n == 0:
            # 0*x + 0*y = 0 is true for any x,y. (0,0) is a valid arbitrary choice.
            return (0, 0) 
        else:
            # 0*x + 0*y = n (n != 0) has no solution.
            return None 
    
    if a == 0: # Equation simplifies to b*y = n
        if n % b == 0:
            # x can be 0 (or any integer); we return 0 for simplicity.
            return (0, n // b) 
        else:
            return None
            
    if b == 0: # Equation simplifies to a*x = n
        if n % a == 0:
            # y can be 0 (or any integer); we return 0 for simplicity.
            return (n // a, 0) 
        else:
            return None

    # General case: both a and b are non-zero
    
    # 1. Use Extended Euclidean Algorithm to find g = gcd(a, b) and x_coeff, y_coeff
    # such that a*x_coeff + b*y_coeff = g.
    g_raw, x_coeff, y_coeff = _egcd(a, b)
    
    # Ensure g is positive, which is the standard definition of gcd.
    # Adjust coefficients if the raw g from _egcd was negative.
    g = abs(g_raw)
    if g_raw < 0:
        x_coeff = -x_coeff
        y_coeff = -y_coeff
    
    # 2. Check if n is divisible by g. If not, no integer solution exists (Bezout's identity).
    if n % g != 0:
        return None
        
    # 3. Scale the solution from a*x_coeff + b*y_coeff = g to a*x + b*y = n.
    # The factor for scaling is n / g.
    k = n // g
    x_particular = x_coeff * k
    y_particular = y_coeff * k
    
    # 4. Adjust the solution to find a specific representation.
    # The general solution form is x = x_p + (b/g)*t, y = y_p - (a/g)*t for integer t.
    # We aim to find x in a specific range (e.g., [0, |b/g|-1] for positive b).
    # Python's `%` operator behavior (a % n has the same sign as n) is used here.
    # Since b is non-zero in this general case, b // g will also be non-zero.
    
    b_divided_by_g = b // g 
    
    # This modulo operation effectively finds a suitable 't' to shift x_particular
    # into a consistent range. For positive b_divided_by_g, x_final will be in [0, b_divided_by_g - 1].
    # For negative b_divided_by_g, x_final will be in [b_divided_by_g + 1, 0].
    x_final = x_particular % b_divided_by_g
    
    # Once x_final is determined, y_final is uniquely fixed by the equation ax_final + by_final = n.
    y_final = (n - a * x_final) // b
    
    return (x_final, y_final)