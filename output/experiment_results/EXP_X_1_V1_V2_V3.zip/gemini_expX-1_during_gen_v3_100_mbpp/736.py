def left_insertion(arr, x):
    """
    Locates the left insertion point for a specified value in a sorted list.

    This function finds the index where 'x' would be inserted into 'arr'
    to maintain its sorted order. If 'x' already exists in 'arr', the
    insertion point will be before (to the left of) any existing entries of 'x'.

    Args:
        arr (list): A sorted list of numbers.
        x (int/float): The value for which to find the insertion point.

    Returns:
        int: The index where 'x' should be inserted.
    """
    low = 0
    high = len(arr)
    while low < high:
        mid = (low + high) // 2
        if arr[mid] < x:
            low = mid + 1
        else:
            high = mid
    return low
