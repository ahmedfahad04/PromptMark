def text_match_wordz(text):
    """
    Checks if the given text contains at least one word that includes the letter 'z'.

    Args:
        text (str): The input string to search within.

    Returns:
        bool: True if a word containing 'z' is found, False otherwise.
    """
    pattern = '\\b\\w*z\\w*\\b'
    if re.search(pattern, text):
        return True
    else:
        return False
