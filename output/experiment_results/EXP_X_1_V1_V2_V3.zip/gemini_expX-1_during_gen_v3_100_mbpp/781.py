def count_divisors(n: int) -> bool:
    """
    Checks if the count of divisors for a given positive integer 'n' is even.

    A positive integer 'n' has an odd number of divisors if and only if 'n' is a perfect square.
    Therefore, this function effectively checks if 'n' is NOT a perfect square.

    Args:
        n (int): The positive integer to check.

    Returns:
        bool: True if the count of divisors is even, False otherwise.
              Returns False for non-positive inputs as they typically don't
              fit the standard definition of 'count of divisors' in this context.
    """
    if n <= 0:
        return False
    sqrt_n = int(math.sqrt(n))
    return sqrt_n * sqrt_n != n
