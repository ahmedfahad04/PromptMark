def swap_List(input_list):
    """
  Interchanges the first and last element of a given list.

  Args:
    input_list: The list whose first and last elements need to be swapped.

  Returns:
    The list with its first and last elements interchanged.
  """
    if len(input_list) >= 2:
        input_list[0], input_list[-1] = (input_list[-1], input_list[0])
    return input_list
