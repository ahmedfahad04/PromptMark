def list_split(data_list, n):
    """
    Splits a list for every nth element, returning a list of the resulting lists.

    Args:
        data_list (list): The input list to be split.
        n (int): The integer specifying the split pattern (every nth element).
                 Must be a positive integer.

    Returns:
        list: A list of lists, where each inner list contains elements
              from the original list based on the nth element pattern.
              The first inner list contains elements at indices 0, n, 2n, ...
              The second inner list contains elements at indices 1, n+1, 2n+1, ...
              and so on, up to the nth inner list.

    Raises:
        TypeError: If data_list is not a list.
        ValueError: If n is not a positive integer.
    """
    if not isinstance(data_list, list):
        raise TypeError("Input 'data_list' must be a list.")
    if not isinstance(n, int) or n <= 0:
        raise ValueError("Input 'n' must be a positive integer.")
    result_lists = [[] for _ in range(n)]
    for i, item in enumerate(data_list):
        sublist_index = i % n
        result_lists[sublist_index].append(item)
    return result_lists
