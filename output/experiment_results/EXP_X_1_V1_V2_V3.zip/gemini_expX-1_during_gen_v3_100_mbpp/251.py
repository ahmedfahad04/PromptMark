def insert_element(input_list, element):
    """
    Inserts a given element before each element in a list.

    Args:
        input_list (list): The original list of elements.
        element: The element to be inserted.

    Returns:
        list: A new list with the element inserted before each original element.
    """
    result_list = []
    for item in input_list:
        result_list.append(element)
        result_list.append(item)
    return result_list
