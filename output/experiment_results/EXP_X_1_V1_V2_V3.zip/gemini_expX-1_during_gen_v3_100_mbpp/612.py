def merge(list_of_lists):
    """
    Transforms a list of lists (representing rows) into a list of lists (representing columns).

    Each sublist in the input is treated as a row. The function returns a new list
    where the first sublist contains all the first elements from the input rows,
    the second sublist contains all the second elements, and so on.

    Args:
        list_of_lists: A list of lists, e.g., [['x', 'y'], ['a', 'b']].
                       Assumes all inner lists have the same length.

    Returns:
        A list of lists where elements are grouped by their position across the original sublists.
        Example: [['x', 'a'], ['y', 'b']]
    """
    if not list_of_lists:
        return []
    return [list(column) for column in zip(*list_of_lists)]
