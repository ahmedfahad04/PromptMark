def remove_nested(input_tuple: tuple) -> tuple:
    """
    Removes nested tuples from a given tuple.

    Args:
        input_tuple: The original tuple which may contain nested tuples.

    Returns:
        A new tuple with all nested tuples removed.
    """
    result_list = []
    for item in input_tuple:
        if not isinstance(item, tuple):
            result_list.append(item)
    return tuple(result_list)
