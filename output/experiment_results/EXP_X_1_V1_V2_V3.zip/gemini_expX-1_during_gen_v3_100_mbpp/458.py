def rectangle_area(length, width):
    """
  Calculates the area of a rectangle given its length and width.

  Args:
    length: The length of the rectangle (a non-negative number).
    width: The width of the rectangle (a non-negative number).

  Returns:
    The area of the rectangle (length * width).
  """
    return length * width
