def capital_words_spaces(s):
    """
    Inserts spaces between words that start with a capital letter in a given string.

    Args:
        s (str): The input string.

    Returns:
        str: The modified string with spaces inserted.
    """
    if not s:
        return ''
    result_chars = []
    for i, char in enumerate(s):
        if i > 0 and char.isupper():
            result_chars.append(' ')
        result_chars.append(char)
    return ''.join(result_chars)
