def sum_series(n: int) -> int:
    """
    Calculates the sum of the series (n - 2*i) for i from 0 to n // 2.
    This effectively sums n + (n-2) + (n-4) + ... until the term is 0 or 1.

    Args:
        n: An integer representing the starting point of the series.

    Returns:
        The total sum of the series.
    """
    total_sum = 0
    for i in range(n // 2 + 1):
        term = n - 2 * i
        total_sum += term
    return total_sum
