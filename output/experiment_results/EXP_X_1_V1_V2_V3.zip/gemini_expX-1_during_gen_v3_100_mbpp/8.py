def square_nums(num_list):
    """
  Calculates the square of each element in a given list of numbers.

  Args:
    num_list: A list of numbers (integers or floats).

  Returns:
    A new list containing the squares of the original elements.
  """
    return [num ** 2 for num in num_list]
