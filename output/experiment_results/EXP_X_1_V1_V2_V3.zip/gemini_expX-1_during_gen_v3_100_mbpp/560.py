def union_elements(tuple1: tuple, tuple2: tuple) -> tuple:
    """
    Finds the union of elements from two given tuples and returns them in sorted order.

    The union operation combines all unique elements from both input tuples.
    The result is then sorted and returned as a new tuple.

    Args:
        tuple1 (tuple): The first input tuple.
        tuple2 (tuple): The second input tuple.

    Returns:
        tuple: A new tuple containing the sorted union of elements from tuple1 and tuple2.

    Examples:
        >>> union_elements((3, 4, 5, 6), (5, 7, 4, 10))
        (3, 4, 5, 6, 7, 10)
        >>> union_elements((1, 2, 3, 4), (3, 4, 5, 6))
        (1, 2, 3, 4, 5, 6)
    """
    union_set = set(tuple1) | set(tuple2)
    sorted_union_list = sorted(list(union_set))
    return tuple(sorted_union_list)
