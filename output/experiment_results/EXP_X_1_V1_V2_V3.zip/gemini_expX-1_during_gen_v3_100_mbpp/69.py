def is_sublist(main_list, sub_list):
    """
    Checks if a sub_list exists contiguously within a main_list.

    Args:
        main_list (list): The list to search within.
        sub_list (list): The sublist to search for.

    Returns:
        bool: True if sub_list is found within main_list, False otherwise.
    """
    if not sub_list:
        return True
    if len(sub_list) > len(main_list):
        return False
    for i in range(len(main_list) - len(sub_list) + 1):
        if main_list[i:i + len(sub_list)] == sub_list:
            return True
    return False
