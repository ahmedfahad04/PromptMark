def sum_of_fourth_powers(n):
    """
    Calculate the sum of the fourth powers of the first n odd natural numbers.
    
    Args:
    n (int): The number of initial odd natural numbers to consider.
    
    Returns:
    int: The sum of the fourth powers of the first n odd natural numbers.
    """
    total_sum = 0
    current_odd_number = 1
    for _ in range(n):
        total_sum += current_odd_number ** 4
        current_odd_number += 2
    return total_sum
