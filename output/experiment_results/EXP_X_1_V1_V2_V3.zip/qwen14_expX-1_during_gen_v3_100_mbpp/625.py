def swap_first_last(lst):
    """
    Swap the first and last elements in the given list.

    Args:
    lst (list): The input list.

    Returns:
    list: The modified list with swapped first and last elements.
    """
    if len(lst) <= 1:
        return lst
    lst[0], lst[-1] = (lst[-1], lst[0])
    return lst
