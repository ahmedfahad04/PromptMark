def replace_characters(input_string):
    """
    Replaces all occurrences of 'a' with '*' in the input string.

    Args:
    input_string (str): The original string containing characters to be replaced.

    Returns:
    str: The modified string with 'a' replaced by '*'.
    """
    return input_string.replace('a', '*')
