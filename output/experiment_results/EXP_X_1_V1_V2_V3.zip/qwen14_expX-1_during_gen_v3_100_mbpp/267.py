def sum_of_squares_of_odds(n):
    """
    Calculate the sum of the squares of the first n odd natural numbers.
    
    Args:
    n (int): The number of initial odd natural numbers to consider.
    
    Returns:
    int: The sum of the squares of the first n odd natural numbers.
    """
    total_sum = 0
    current_odd = 1
    for _ in range(n):
        total_sum += current_odd ** 2
        current_odd += 2
    return total_sum
