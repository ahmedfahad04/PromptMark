def extract_strings_by_size(strings, size):
    """
    Extracts and returns strings of a specified size from the input list.

    :param strings: List of string values.
    :param size: Desired length of the strings to be extracted.
    :return: A list containing only the strings of the specified size.
    """
    return [s for s in strings if len(s) == size]
