def has_31_days(month_number):
    """
    Checks if the given month number contains 31 days.
    
    Args:
    month_number (int): The number of the month (1 for January, 2 for February, etc.)
    
    Returns:
    bool: True if the month has 31 days, False otherwise.
    """
    months_with_31_days = [1, 3, 5, 7, 8, 10, 12]
    return month_number in months_with_31_days
