def extract_elements(tup1, tup2):
    """
    Extracts elements from the given two tuples and returns them as separate lists.
    
    Args:
    tup1 (tuple): The first input tuple.
    tup2 (tuple): The second input tuple.
    
    Returns:
    list: A list containing two sublists - one with elements from the first tuple,
          and another with elements from the second tuple.
    """
    result = []
    result.append(list(tup1))
    result.append(list(tup2))
    return result
