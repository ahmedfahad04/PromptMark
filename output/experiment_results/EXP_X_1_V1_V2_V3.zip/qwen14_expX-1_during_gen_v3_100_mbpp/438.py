def count_bidirectional_pairs(pairs):
    """
    Count the number of unique bidirectional tuple pairs.
    
    Args:
    pairs (list): A list of tuples representing pairs.
    
    Returns:
    int: The count of unique bidirectional pairs.
    """
    unique_pairs = set()
    for pair in pairs:
        sorted_pair = tuple(sorted(pair))
        unique_pairs.add(sorted_pair)
    return len(unique_pairs)
