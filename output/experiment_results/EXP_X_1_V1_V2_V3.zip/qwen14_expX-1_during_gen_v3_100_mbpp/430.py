def find_directrix(a):
    """
    Calculate the directrix of a parabola given its coefficient 'a'.
    
    The directrix of a parabola y = ax^2 + bx + c is y = -1/(4a).
    
    Parameters:
    a (float): Coefficient of x^2 in the equation of the parabola.
    
    Returns:
    float: The y-coordinate of the directrix.
    """
    if a == 0:
        raise ValueError("Coefficient 'a' must be non-zero.")
    directrix_y = -1 / (4 * a)
    return directrix_y
