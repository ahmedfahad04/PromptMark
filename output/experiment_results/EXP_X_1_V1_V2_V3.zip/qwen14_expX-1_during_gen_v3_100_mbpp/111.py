def find_common_elements(nested_lists):
    """
    Find and return the common elements present in all sublists of the given nested list.
    
    :param nested_lists: List of lists containing elements
    :return: A set of common elements found in all sublists
    """
    if not nested_lists:
        return set()
    sets_of_sublists = [set(sublist) for sublist in nested_lists]
    common_elements = sets_of_sublists[0].intersection(*sets_of_sublists[1:])
    return common_elements
