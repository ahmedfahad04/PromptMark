def all_values_same(input_dict):
    """
    Check if all values in the input dictionary are the same.

    Args:
    input_dict (dict): The dictionary whose values need to be checked.

    Returns:
    bool: True if all values are the same, False otherwise.
    """
    return len(set(input_dict.values())) <= 1
