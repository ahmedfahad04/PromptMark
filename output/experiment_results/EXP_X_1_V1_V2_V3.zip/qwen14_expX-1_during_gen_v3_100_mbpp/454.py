def match_word_with_z(word):
    """
    This function checks if the input word contains the letter 'z'.
    
    Args:
    word (str): The word to be checked.
    
    Returns:
    bool: True if the word contains 'z', False otherwise.
    """
    pattern = 'z'
    if re.search(pattern, word):
        return True
    else:
        return False
