def count_elements(flattened_list):
    """
    Function to count the frequency of each element in a flattened list and return the counts in a dictionary.
    
    :param flattened_list: List of lists containing elements
    :return: Dictionary with elements as keys and their frequencies as values
    """
    flat_list = [item for sublist in flattened_list for item in sublist]
    freq_dict = Counter(flat_list)
    return freq_dict
