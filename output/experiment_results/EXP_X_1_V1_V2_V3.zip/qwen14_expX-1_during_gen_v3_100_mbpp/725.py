def extract_values_between_quotes(input_string):
    """
    Extracts and returns all substrings found within double quotes " ".
    
    Args:
    input_string (str): The string from which to extract values.
    
    Returns:
    list: A list containing all substrings found within double quotes.
    """
    result = []
    quote_flag = False
    current_value = ''
    for char in input_string:
        if char == '"':
            quote_flag = not quote_flag
        elif quote_flag:
            current_value += char
        elif current_value:
            result.append(current_value)
            current_value = ''
    if current_value:
        result.append(current_value)
    return result
