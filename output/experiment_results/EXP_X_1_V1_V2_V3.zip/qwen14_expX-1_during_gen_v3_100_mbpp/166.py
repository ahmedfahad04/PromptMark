def count_even_xor_pairs(nums):
    """
    Counts the number of pairs (i, j) in nums such that i < j and nums[i] ^ nums[j] is even.

    :param nums: List[int] - A list of integers.
    :return: int - The count of pairs with even XOR result.
    """
    even_xor_count = 0
    for i in range(len(nums)):
        for j in range(i + 1, len(nums)):
            if (nums[i] ^ nums[j]) % 2 == 0:
                even_xor_count += 1
    return even_xor_count
