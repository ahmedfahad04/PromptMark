def count_vowel_neighbors(s):
    """
    Counts characters with vowel neighbors in the given string.

    Args:
    s (str): The input string.

    Returns:
    int: Count of characters having vowel neighbors.
    """
    vowels = 'aeiouAEIOU'
    count = 0
    for i in range(1, len(s) - 1):
        if s[i - 1] in vowels or s[i + 1] in vowels:
            count += 1
    return count
