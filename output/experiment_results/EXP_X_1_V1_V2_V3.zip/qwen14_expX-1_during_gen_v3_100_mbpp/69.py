def contains_sublist(main_list, sub_list):
    """
    Check if main_list contains sub_list.

    Args:
    main_list (list): The main list to search within.
    sub_list (list): The sublist to find in the main list.

    Returns:
    bool: True if sub_list is found in main_list, False otherwise.
    """
    if not sub_list:
        return True
    for i in range(len(main_list) - len(sub_list) + 1):
        if main_list[i:i + len(sub_list)] == sub_list:
            return True
    return False
