def right_rotate_list(lst, n):
    """
    Rotates the elements of the given list 'lst' to the right by 'n' positions.

    Args:
    lst (list): The input list to be rotated.
    n (int): Number of positions to rotate the list to the right.

    Returns:
    list: The rotated list.
    """
    n = n % len(lst)
    return lst[-n:] + lst[:-n]
