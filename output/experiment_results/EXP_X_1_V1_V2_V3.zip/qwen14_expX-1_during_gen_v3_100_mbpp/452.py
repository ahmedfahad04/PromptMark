def calculate_loss(sale_amount, cost_price):
    """
    Calculate the loss amount on a sale if there's a loss; otherwise, return 0.

    :param sale_amount: The amount at which the item was sold.
    :param cost_price: The original cost price of the item.
    :return: Loss amount if there's a loss, otherwise 0.
    """
    if sale_amount < cost_price:
        return cost_price - sale_amount
    else:
        return 0
