def convert_to_floats(nested_list):
    """
    Converts all integer and float strings in a nested list to their respective numeric types.
    
    :param nested_list: List of lists containing string representations of numbers
    :return: A new list of lists with converted numbers
    """
    result = []
    for sublist in nested_list:
        # Convert each element in the sublist to float if it's a valid number representation
        result.append([float(item) if item.replace('.', '', 1).isdigit() else item for item in sublist])
    return result