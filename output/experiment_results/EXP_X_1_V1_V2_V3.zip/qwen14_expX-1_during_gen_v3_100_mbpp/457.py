def find_min_length_sublist(lst):
    """
    Finds and returns the sublist with the minimum length from a list of sublists.
    
    :param lst: List of sublists
    :return: Sublist with the minimum length
    """
    if not lst:
        return []
    min_length = float('inf')
    min_sublist = None
    for sublist in lst:
        if len(sublist) < min_length:
            min_length = len(sublist)
            min_sublist = sublist
    return min_sublist
