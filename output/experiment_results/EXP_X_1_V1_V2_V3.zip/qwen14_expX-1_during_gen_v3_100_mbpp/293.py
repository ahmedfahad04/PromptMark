def find_third_side(leg1, leg2):
    """
    Calculate the length of the third side (hypotenuse) of a right-angled triangle,
    given the lengths of the other two sides using Pythagoras' theorem.

    :param leg1: Length of one leg of the triangle.
    :param leg2: Length of the other leg of the triangle.
    :return: The length of the hypotenuse.
    """
    import math
    hypotenuse = math.sqrt(leg1 ** 2 + leg2 ** 2)
    return hypotenuse
