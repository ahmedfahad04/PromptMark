def area_of_sector(radius, angle):
    """
    Calculate the area of a sector given its radius and central angle.
    
    Parameters:
        radius (float): The radius of the circle.
        angle (float): The central angle of the sector in degrees.
        
    Returns:
        float or None: The area of the sector if the angle <= 360, otherwise returns None.
    """
    import math
    if angle > 360:
        return None
    arc_angle_in_radians = math.radians(angle)
    area = 1 / 2 * radius ** 2 * arc_angle_in_radians
    return area
