def find_smallest_missing(nums):
    """
    Finds the smallest missing number in a sorted list of natural numbers.
    
    Args:
    nums (list): A sorted list of natural numbers.
    
    Returns:
    int: The smallest missing number in the list.
    """
    if not nums:
        return 1
    start, end = (0, len(nums) - 1)
    if nums[start] > 0:
        return 0
    while start <= end:
        mid = (start + end) // 2
        if nums[mid] - mid > 1:
            end = mid - 1
        else:
            start = mid + 1
    return start
