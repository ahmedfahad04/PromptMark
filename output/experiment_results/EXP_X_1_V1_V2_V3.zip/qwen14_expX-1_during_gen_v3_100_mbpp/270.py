def sum_even_at_even_positions(lst):
    """
    This function takes a list and returns the sum of even numbers located at even indices.
    
    :param lst: List of integers
    :return: Sum of even numbers at even positions
    """
    total_sum = 0
    for i in range(0, len(lst), 2):
        if lst[i] % 2 == 0:
            total_sum += lst[i]
    return total_sum
