def largest_number(digits):
    """
    This function takes a list of non-negative integers and returns the largest number 
    that can be formed by concatenating those integers.
    """
    str_digits = [str(digit) for digit in digits]
    str_digits.sort(key=lambda x: x * 3, reverse=True)
    largest_num_str = ''.join(str_digits)
    return int(largest_num_str.lstrip('0')) if largest_num_str else 0
