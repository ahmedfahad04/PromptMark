def min_swaps_to_convert(binary1: str, binary2: str) -> int:
    """
    Calculate the minimum number of swaps required to convert binary1 to binary2 by flipping exactly one '0' to '1' per swap.
    
    :param binary1: Source binary string
    :param binary2: Target binary string
    :return: Minimum number of swaps needed
    """
    if len(binary1) != len(binary2):
        raise ValueError('Binary strings must be of equal length')
    mismatch_count = sum((1 for b1, b2 in zip(binary1, binary2) if b1 == '0' and b2 == '1'))
    if mismatch_count % 2 != 0:
        return -1
    return mismatch_count // 2
