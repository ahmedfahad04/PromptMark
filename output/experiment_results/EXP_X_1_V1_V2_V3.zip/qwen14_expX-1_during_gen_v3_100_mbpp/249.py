def find_intersection(arr1, arr2):
    """
    Finds and returns the intersection of two arrays.

    Args:
    arr1 (list): First input list.
    arr2 (list): Second input list.

    Returns:
    list: A list containing elements common to both input lists.
    """
    set1 = set(arr1)
    set2 = set(arr2)
    intersection = set1.intersection(set2)
    return list(intersection)
