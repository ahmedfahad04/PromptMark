def count_matching_indices(list1, list2):
    """
    Counts the number of indices where elements in list1 and list2 are equal.

    Args:
    - list1: A list of integers.
    - list2: A list of integers, with the same length as list1.

    Returns:
    - The count of indices where the corresponding elements in list1 and list2 match.
    """
    matching_count = 0
    for i in range(len(list1)):
        if list1[i] == list2[i]:
            matching_count += 1
    return matching_count
