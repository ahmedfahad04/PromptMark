def toggle_bits_except_edge(n):
    """
    Toggle all bits of the integer 'n' except the first and the last bit.

    Args:
    n (int): The input integer whose bits are to be toggled.

    Returns:
    int: The resulting integer after toggling the specified bits.
    """
    msb = n.bit_length() - 1
    mask = (1 << msb) - 1
    mask &= ~(1 | 1 << msb)
    result = n ^ mask
    return result
