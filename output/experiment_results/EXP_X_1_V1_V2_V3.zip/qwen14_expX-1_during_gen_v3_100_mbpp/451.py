def remove_whitespaces(input_string):
    """
    Removes all whitespaces from the given string.

    Args:
        input_string (str): The string from which to remove whitespaces.

    Returns:
        str: The resulting string without any whitespaces.
    """
    return input_string.replace(' ', '')
