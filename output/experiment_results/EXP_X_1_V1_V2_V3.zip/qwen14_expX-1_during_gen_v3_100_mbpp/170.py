def sum_of_range(numbers, start_index, end_index):
    """
    Calculate the sum of elements in the list 'numbers' from index 'start_index'
    to index 'end_index' (inclusive).

    :param numbers: List of integers.
    :param start_index: Starting index for the range.
    :param end_index: Ending index for the range.
    :return: Sum of elements in the specified range.
    """
    if start_index < 0 or end_index >= len(numbers) or start_index > end_index:
        return None
    return sum(numbers[start_index:end_index + 1])
