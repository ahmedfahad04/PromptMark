def average_of_cubes(n):
    """
    Calculate the average of cubes of first n natural numbers.
    
    :param n: The number of initial natural numbers to consider.
    :return: The average of cubes of first n natural numbers.
    """
    sum_of_cubes = 0
    for i in range(1, n + 1):
        sum_of_cubes += i ** 3
    average = sum_of_cubes / n
    return average
