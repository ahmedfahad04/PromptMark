def count_rotations(arr):
    """
    Function to count the number of rotations required to make an array sorted.
    
    :param arr: List[int] - The input array which may be a rotated version of a sorted array.
    :return: int - Number of rotations needed to sort the array.
    """
    min_element = float('inf')
    min_index = -1
    n = len(arr)
    for i in range(n):
        if arr[i] < min_element:
            min_element = arr[i]
            min_index = i
    if min_index == 0 or (min_index > 0 and arr[min_index - 1] > arr[min_index]):
        return min_index
    return 0
