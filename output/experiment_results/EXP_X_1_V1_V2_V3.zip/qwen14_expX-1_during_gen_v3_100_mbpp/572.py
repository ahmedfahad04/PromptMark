def remove_duplicates(*lists):
    """
    Removes duplicates across all provided lists and returns a single list with unique elements.

    :param lists: Variable number of lists containing integers.
    :return: A list of unique integers.
    """
    unique_elements = list(set().union(*lists))
    return unique_elements
