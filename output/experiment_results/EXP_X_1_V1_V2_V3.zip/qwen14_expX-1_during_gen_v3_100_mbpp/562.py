def longest_sublist_length(lists):
    """
    Finds the length of the longest sublist within a list of lists.

    :param lists: A list of lists where each sublist contains elements.
    :return: The length of the longest sublist.
    """
    # Check if the input is an empty list
    if not lists:
        return 0
    
    # Find the maximum length among all sublists
    max_length = max(len(sublist) for sublist in lists)
    
    return max_length