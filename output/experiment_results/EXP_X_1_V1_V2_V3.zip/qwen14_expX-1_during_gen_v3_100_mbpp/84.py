def newman_conway(num):
    """
    Returns the nth number in the Newman-Conway sequence.
    
    The Newman-Conway sequence is defined by the recurrence relation:
    P(n) = P(P(n - 1)) + P(n - P(n - 1)), with initial conditions P(1) = 1 and P(2) = 1.
    """
    if num <= 0:
        return None
    pc = [0, 1, 1]
    for i in range(3, num + 1):
        pc.append(pc[pc[i - 1]] + pc[i - pc[i - 1]])
    return pc[num]
