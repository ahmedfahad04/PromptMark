def find_first_occurrence(arr, target):
    """
    Finds the index of the first occurrence of 'target' in the sorted list 'arr'.
    
    :param arr: List[int] - A sorted list of integers.
    :param target: int - The integer to search for in the list.
    :return: int - The index of the first occurrence of 'target', or -1 if not found.
    """
    left, right = (0, len(arr) - 1)
    while left <= right:
        mid = (left + right) // 2
        if arr[mid] < target:
            left = mid + 1
        elif arr[mid] > target:
            right = mid - 1
        elif mid == 0 or arr[mid - 1] != target:
            return mid
        else:
            right = mid - 1
    return -1
