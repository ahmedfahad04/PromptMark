def flatten_list_of_lists(nested_list):
    """
    Flattens a nested list into a single set of numbers.

    Args:
    nested_list (list): A list of lists containing numbers.

    Returns:
    set: A set containing all the numbers from the nested lists.
    """
    return {item for sublist in nested_list for item in sublist}
