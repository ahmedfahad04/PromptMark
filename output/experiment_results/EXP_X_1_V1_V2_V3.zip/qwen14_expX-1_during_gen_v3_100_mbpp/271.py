def sum_of_even_fifth_powers(n):
    """
    Calculate the sum of the first n even natural numbers raised to the fifth power.
    
    :param n: Number of initial even natural numbers to consider.
    :return: Sum of these numbers each raised to the fifth power.
    """
    total_sum = 0
    for i in range(1, n + 1):
        even_number = 2 * i
        total_sum += even_number ** 5
    return total_sum
