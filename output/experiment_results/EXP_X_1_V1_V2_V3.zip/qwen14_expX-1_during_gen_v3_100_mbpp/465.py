def drop_empty_items(input_dict):
    """
    This function takes a dictionary and returns a new dictionary with all key-value pairs where the value is not an empty string, list, set, tuple, or dictionary.
    
    :param input_dict: The dictionary from which to remove empty items.
    :return: A new dictionary without empty values.
    """
    result_dict = {k: v for k, v in input_dict.items() if v}
    return result_dict
