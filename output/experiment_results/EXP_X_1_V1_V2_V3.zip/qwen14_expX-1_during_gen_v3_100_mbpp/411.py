def convert_snake_to_camel(snake_str):
    """
    Convert a snake_case string to CamelCase string.
    
    Args:
    snake_str (str): The snake_case string to be converted.
    
    Returns:
    str: The converted CamelCase string.
    """
    components = snake_str.split('_')
    return components[0] + ''.join((x.capitalize() or '_' for x in components[1:]))
