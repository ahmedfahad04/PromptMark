def multiply_and_divide(lst):
    """
    Multiply all the numbers in the list and then divide the result by the length of the list.
    
    :param lst: List of numbers
    :return: Result of multiplication divided by the length of the list
    """
    if not lst:
        return 0
    product = 1
    for num in lst:
        product *= num
    return product / len(lst)
