def max_product_of_increasing_subsequence(arr):
    """
    Finds the maximum product formed by multiplying numbers of an increasing subsequence of the input array.

    :param arr: List[int] - The input list of integers.
    :return: int - The maximum product of any increasing subsequence.
    """
    if not arr:
        return 0
    max_product = float('-inf')
    current_product = 1
    for num in arr:
        if num > 1:
            current_product *= num
        else:
            current_product = num
        max_product = max(max_product, current_product)
    return max_product
