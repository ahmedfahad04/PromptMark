def add_spaces_before_caps(s):
    """
    Adds a space before each uppercase letter in the string except the first one if it's uppercase.

    :param s: Input string
    :return: Modified string with spaces added before capital letters
    """
    result = []
    prev_char_is_lower = True
    for i, char in enumerate(s):
        if char.isupper() and (not (i == 0 and s[i] != ' ')):
            if not prev_char_is_lower:
                result.append(' ')
            prev_char_is_lower = False
        else:
            prev_char_is_lower = char.islower()
        result.append(char)
    return ''.join(result)
