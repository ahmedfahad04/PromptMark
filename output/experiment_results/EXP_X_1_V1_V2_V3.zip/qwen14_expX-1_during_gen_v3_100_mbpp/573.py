def product_of_unique_numbers(numbers):
    """
    Calculate the product of the unique numbers in a given list.

    Args:
    - numbers (list): A list of integers.

    Returns:
    - int: The product of the unique numbers in the list.
    """
    unique_numbers = list(set(numbers))
    product = 1
    for num in unique_numbers:
        product *= num
    return product
