def sort_list(input_list):
    """
    Sorts the given list in ascending order using Python's built-in sorted function.

    :param input_list: List of elements to be sorted.
    :return: A new list containing the sorted elements.
    """
    return sorted(input_list)
