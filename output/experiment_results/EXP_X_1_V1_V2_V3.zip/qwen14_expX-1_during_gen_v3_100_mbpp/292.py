def find_quotient(dividend: int, divisor: int) -> int:
    """
    Calculate the quotient of two integers by performing integer division.

    Args:
        dividend (int): The number to be divided.
        divisor (int): The number by which to divide.

    Returns:
        int: Quotient of dividend and divisor, rounded down to the nearest integer.
    """
    return dividend // divisor
