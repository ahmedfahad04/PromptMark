def find_solution(a, b, n):
    """
    Finds integers x and y such that ax + by = n.
    
    Args:
    a (int): Coefficient of x.
    b (int): Coefficient of y.
    n (int): The target value.
    
    Returns:
    tuple or None: A tuple (x, y) if a solution exists, otherwise None.
    """
    # Extended Euclidean Algorithm to find gcd and coefficients x, y
    def extended_gcd(a, b):
        if a == 0:
            return b, 0, 1
        else:
            gcd, x1, y1 = extended_gcd(b % a, a)
            x = y1 - (b // a) * x1
            y = x1
            return gcd, x, y
    
    gcd, x, y = extended_gcd(abs(a), abs(b))
    
    # If n is not divisible by gcd, then there's no solution
    if n % gcd != 0:
        return None
    
    # Scale the base solution to get the actual solution
    x *= n // gcd
    y *= n // gcd
    
    # Adjust signs based on original values of a and b
    if a < 0:
        x *= -1
    if b < 0:
        y *= -1
    
    return (x, y)

# Test cases