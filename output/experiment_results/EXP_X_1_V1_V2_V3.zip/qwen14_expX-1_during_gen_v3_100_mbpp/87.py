def merge_three_dicts(dict1, dict2, dict3):
    """
    Merges three dictionaries into one.
    
    Args:
    dict1 (dict): First input dictionary.
    dict2 (dict): Second input dictionary.
    dict3 (dict): Third input dictionary.
    
    Returns:
    dict: A merged dictionary containing all key-value pairs from the three input dictionaries.
          If there are overlapping keys, the values from the later dictionaries will overwrite earlier ones.
    """
    merged_dict = {**dict1, **dict2, **dict3}
    return merged_dict
