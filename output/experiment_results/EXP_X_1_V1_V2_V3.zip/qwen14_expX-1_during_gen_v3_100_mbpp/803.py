def is_perfect_square(num):
    """
    Check if the given number is a perfect square.

    Args:
    num (int): The number to be checked.

    Returns:
    bool: True if num is a perfect square, False otherwise.
    """
    sqrt_num = round(math.sqrt(num))
    return sqrt_num ** 2 == num
