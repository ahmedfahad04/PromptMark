def list_to_tuple(input_list):
    """
    Converts a given list into a tuple.
    
    Parameters:
        input_list (list): The list to be converted.
        
    Returns:
        tuple: The converted tuple from the list.
    """
    return tuple(input_list)
