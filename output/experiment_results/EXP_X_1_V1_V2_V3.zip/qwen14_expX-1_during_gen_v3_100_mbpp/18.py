def remove_chars(s1, s2):
    """
    Remove characters from s1 that are present in s2.

    :param s1: Source string from which characters will be removed.
    :param s2: String containing characters to be removed from s1.
    :return: A new string with characters removed.
    """
    return ''.join([char for char in s1 if char not in s2])
