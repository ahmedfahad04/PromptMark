def remove_tuples(input_tuple):
    """
    This function takes a tuple and returns it without any tuple elements.
    
    :param input_tuple: A tuple containing various elements including other tuples.
    :return: A new tuple with all tuple elements removed.
    """
    result_list = []
    for item in input_tuple:
        if not isinstance(item, tuple):
            result_list.append(item)
    return tuple(result_list)
