def move_numbers_to_end(s):
    """
    Moves all digits in the input string 's' to the end while preserving the order of non-digit characters.
    
    :param s: Input string containing alphanumeric characters.
    :return: String with all digits moved to the end.
    """
    digits = ''.join(filter(str.isdigit, s))
    non_digits = ''.join(filter(lambda x: not str(x).isdigit(), s))
    result = non_digits + digits
    return result
