def subtract_tuples(tup1, tup2):
    """
    Subtract corresponding elements of two tuples.
    
    Args:
    tup1 (tuple): First input tuple.
    tup2 (tuple): Second input tuple.
    
    Returns:
    tuple: A new tuple containing the differences of corresponding elements.
    """
    if len(tup1) != len(tup2):
        raise ValueError('Tuples must be of the same length')
    result = tuple((a - b for a, b in zip(tup1, tup2)))
    return result
