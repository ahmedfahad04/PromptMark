def calculate_sum(n):
    """
    Calculate the sum of the series n - 2*i for i ranging from 0 to n//2.

    :param n: The starting number of the series.
    :return: The calculated sum of the series.
    """
    total_sum = 0
    for i in range(n // 2 + 1):
        total_sum += n - 2 * i
    return total_sum
