def calculate_power(a, b):
    """
    Calculate the value of 'a' to the power 'b'.
    
    Args:
    a (int): The base number.
    b (int): The exponent.
    
    Returns:
    int: The result of 'a' raised to the power 'b'.
    """
    return a ** b
