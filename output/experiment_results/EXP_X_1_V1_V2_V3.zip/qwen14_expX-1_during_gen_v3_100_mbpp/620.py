def max_divisible_subset_size(nums):
    """
    Finds the maximum size of a subset where each pair of elements is divisible by one another.
    
    :param nums: List[int] - A list of positive integers.
    :return: int - The size of the largest such subset.
    """
    if not nums:
        return 0
    nums.sort()
    n = len(nums)
    dp = [1] * n
    for i in range(1, n):
        for j in range(i):
            if nums[i] % nums[j] == 0:
                dp[i] = max(dp[i], dp[j] + 1)
    return max(dp)
