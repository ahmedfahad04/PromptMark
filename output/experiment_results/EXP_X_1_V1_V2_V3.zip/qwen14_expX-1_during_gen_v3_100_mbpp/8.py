def square_elements(input_list):
    """
    This function takes a list of numbers and returns a new list containing the squares of each element.
    
    :param input_list: List of numbers (integers or floats)
    :return: A new list with squared values of the original elements
    """
    squared_list = []
    for num in input_list:
        squared_list.append(num ** 2)
    return squared_list
