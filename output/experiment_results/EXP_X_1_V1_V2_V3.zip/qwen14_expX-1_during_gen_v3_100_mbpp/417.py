def find_common_first_element(lst_of_tuples):
    """
    Find the common first element in a given list of tuples.

    Args:
    lst_of_tuples (list): A list containing tuples.

    Returns:
    Any: The common first element if all tuples have the same first element,
         otherwise returns None.
    """
    if not lst_of_tuples or not isinstance(lst_of_tuples[0], tuple):
        return None
    first_elements = [t[0] for t in lst_of_tuples]
    unique_elements = set(first_elements)
    if len(unique_elements) == 1:
        return next(iter(unique_elements))
    else:
        return None
