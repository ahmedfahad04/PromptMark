def remove_first_last_occurrence(s, char):
    """
    Removes the first and last occurrences of a specified character from the string.
    
    :param s: The input string from which characters will be removed.
    :param char: The character to be removed from both ends if found.
    :return: A new string with the first and last occurrences of 'char' removed.
    """
    try:
        first_index = s.index(char)
        last_index = s.rindex(char)
    except ValueError:
        return s
    if first_index == last_index:
        return ''
    elif first_index == 0:
        return s[last_index + 1:]
    elif last_index == len(s) - 1:
        return s[:first_index]
    else:
        return s[:first_index] + s[first_index + 1:last_index] + s[last_index + 1:]
