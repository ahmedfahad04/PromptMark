def find_nth_lucas(n):
    """
    Returns the n-th Lucas number using recursion and memoization for efficiency.
    
    The Lucas numbers are defined by the recurrence relation:
    L(n) = L(n-1) + L(n-2)
    with initial values L(0) = 2 and L(1) = 1.
    """
    if n == 0:
        return 2
    elif n == 1:
        return 1
    return find_nth_lucas(n - 1) + find_nth_lucas(n - 2)
