def find_union_sorted(tup1, tup2):
    """
    Finds the union of two tuples and returns the result as a sorted list.
    
    :param tup1: First input tuple
    :param tup2: Second input tuple
    :return: Sorted list containing unique elements from both tuples
    """
    union_list = list(set(tup1) | set(tup2))
    union_list.sort()
    return union_list
