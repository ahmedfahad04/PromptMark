def are_all_dicts_empty(dicts_list):
    """
    Checks if all dictionaries in the provided list are empty.

    Args:
    dicts_list (list): A list of dictionaries.

    Returns:
    bool: True if all dictionaries are empty, False otherwise.
    """
    return all((not d for d in dicts_list))
