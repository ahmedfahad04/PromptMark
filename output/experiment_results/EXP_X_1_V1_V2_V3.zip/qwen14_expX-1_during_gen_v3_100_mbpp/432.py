def find_median_trapezium(base1, base2):
    """
    Calculate the median (midline) of a trapezium given its two bases.
    
    Parameters:
    base1 (float): The length of one base of the trapezium.
    base2 (float): The length of the other base of the trapezium.
    
    Returns:
    float: The median length of the trapezium.
    """
    median_length = (base1 + base2) / 2
    return median_length
