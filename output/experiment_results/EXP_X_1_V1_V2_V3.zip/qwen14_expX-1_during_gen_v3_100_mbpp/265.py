def split_list_every_n(lst, n):
    num_sublists = len(lst) // n
    sublists = [lst[i * n:(i + 1) * n] for i in range(num_sublists)]
    if len(lst) % n != 0:
        sublists.append(lst[num_sublists * n:])
    return sublists
