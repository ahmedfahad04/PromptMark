def find_substring_occurrences(main_string, substring):
    """
    Finds all occurrences and their positions of a substring within a main string.
    
    Args:
    main_string (str): The string to search within.
    substring (str): The substring to find.
    
    Returns:
    list of tuples: Each tuple contains the start index and end index of each occurrence.
                    Returns None if no matches are found.
    """
    if substring == '':
        return None
    positions = []
    start = 0
    while True:
        start = main_string.find(substring, start)
        if start == -1:
            break
        positions.append((start, start + len(substring) - 1))
        start += 1
    return positions if positions else None
