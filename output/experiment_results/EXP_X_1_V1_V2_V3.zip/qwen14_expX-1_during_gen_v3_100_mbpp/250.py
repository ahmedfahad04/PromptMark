def count_occurrences(tup, elem):
    """
    Counts the occurrences of an element in a tuple.

    :param tup: Tuple containing elements to be searched.
    :param elem: Element whose occurrences need to be counted.
    :return: Number of times the element appears in the tuple.
    """
    return tup.count(elem)
