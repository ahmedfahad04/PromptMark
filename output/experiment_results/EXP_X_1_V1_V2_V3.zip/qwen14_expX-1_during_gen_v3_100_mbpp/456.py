def reverse_strings(string_list):
    """
    Reverses each string in the provided list.

    Args:
    string_list (list): A list of strings to be reversed.

    Returns:
    list: A new list containing the reversed strings.
    """
    return [s[::-1] for s in string_list]
