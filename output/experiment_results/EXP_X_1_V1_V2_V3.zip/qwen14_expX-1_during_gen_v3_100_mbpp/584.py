def find_first_adverb(text):
    """
    Finds the first adverb ending with 'ly' in the given text and returns it along with its start and end positions.
    
    :param text: The input string where we need to search for an adverb.
    :return: A tuple containing the found adverb and its start and end positions; returns None if no adverb is found.
    """
    pattern = '\\b\\w+ly\\b'
    match = re.search(pattern, text)
    if match:
        return (match.group(), match.start(), match.end())
    else:
        return None
