def product_of_even_odd(numbers):
    """
    This function takes a list of numbers and returns the product of the first even and odd numbers.
    
    :param numbers: List of integers
    :return: Product of the first even and odd numbers in the list
    """
    first_even = None
    first_odd = None
    for num in numbers:
        if first_even is None and num % 2 == 0:
            first_even = num
        elif first_odd is None and num % 2 != 0:
            first_odd = num
        if first_even is not None and first_odd is not None:
            break
    product = first_even * first_odd if first_even is not None and first_odd is not None else None
    return product
