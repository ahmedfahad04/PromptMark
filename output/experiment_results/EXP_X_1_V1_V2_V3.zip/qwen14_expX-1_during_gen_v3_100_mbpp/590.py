def polar_to_rectangular(r, theta):
    """
    Convert polar coordinates (r, theta) to rectangular coordinates (x, y).
    
    Parameters:
        r (float): The radial distance from the origin.
        theta (float): The angle in radians from the positive x-axis.
        
    Returns:
        tuple: A tuple containing the rectangular coordinates (x, y).
    """
    x = r * math.cos(theta)
    y = r * math.sin(theta)
    return (x, y)
