def find_words_starting_with_p(words):
    """
    Returns the first two words from the input list that start with the letter 'p'.
    
    :param words: List of words
    :return: Tuple containing the first two words starting with 'p', if available
    """
    p_words = []
    for word in words:
        if word.lower().startswith('p'):
            p_words.append(word)
            if len(p_words) == 2:
                break
    return tuple(p_words)
