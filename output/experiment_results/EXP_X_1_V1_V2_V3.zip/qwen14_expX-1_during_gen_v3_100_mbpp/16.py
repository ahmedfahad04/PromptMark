def check_lowercase_sequence(s):
    """
    Checks if the input string contains sequences of lowercase letters joined with an underscore.
    
    Args:
    s (str): The input string to be checked.
    
    Returns:
    bool: True if the string matches the pattern, False otherwise.
    """
    pattern = '^[a-z]+_[a-z]+$'
    if re.match(pattern, s):
        return True
    else:
        return False
