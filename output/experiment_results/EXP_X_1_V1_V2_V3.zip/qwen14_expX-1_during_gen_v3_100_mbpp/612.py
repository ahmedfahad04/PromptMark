def separate_elements(pairs):
    """
    Takes a list of pairs (sublists with two elements) and separates them into two lists,
    one containing the first elements and the other containing the second elements.
    
    :param pairs: List of sublists, each with two elements.
    :return: A list of two lists - [list_of_first_elements, list_of_second_elements]
    """
    if not all((len(pair) == 2 for pair in pairs)):
        raise ValueError('Each sublist must contain exactly two elements.')
    first_elements = [pair[0] for pair in pairs]
    second_elements = [pair[1] for pair in pairs]
    return [first_elements, second_elements]
