def find_left_insertion_point(sorted_list, target):
    """
    Locate the left insertion point for a specified value in sorted order.

    Args:
    - sorted_list (List[int]): A list of integers sorted in ascending order.
    - target (int): The integer value to be inserted.

    Returns:
    - int: The index at which the target should be inserted to maintain sorted order.
    """
    low = 0
    high = len(sorted_list)
    while low < high:
        mid = (low + high) // 2
        if sorted_list[mid] < target:
            low = mid + 1
        else:
            high = mid
    return low
