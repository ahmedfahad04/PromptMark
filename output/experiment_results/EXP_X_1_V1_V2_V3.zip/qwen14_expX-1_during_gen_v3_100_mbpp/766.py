def get_consecutive_pairs(items):
    """
    Generates a list of tuples containing pairs of consecutive items from the input list.

    :param items: A list of items.
    :return: A list of tuples where each tuple contains a pair of consecutive items.
    """
    if len(items) < 2:
        return []
    return [(items[i], items[i + 1]) for i in range(len(items) - 1)]
