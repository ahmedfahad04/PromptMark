def surface_area_square_pyramid(base_edge, height):
    """
    Calculate the surface area of a square pyramid.

    Args:
    base_edge (float): The length of one edge of the square base.
    height (float): The height from the base to the apex of the pyramid.

    Returns:
    float: The total surface area of the square pyramid.
    """
    base_area = base_edge ** 2
    slant_height = ((base_edge / 2) ** 2 + height ** 2) ** 0.5
    lateral_area = 4 * (1 / 2) * base_edge * slant_height
    total_surface_area = base_area + lateral_area
    return total_surface_area
