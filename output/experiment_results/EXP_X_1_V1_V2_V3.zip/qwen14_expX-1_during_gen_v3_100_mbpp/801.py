def count_equal_numbers(a, b, c):
    """
    Counts the number of equal integers among three given integers.

    Args:
    a (int): The first integer.
    b (int): The second integer.
    c (int): The third integer.

    Returns:
    int: The count of equal integers among the three.
    """
    count = 0
    if a == b == c:
        count = 3
    elif a == b or b == c or a == c:
        count = 2
    else:
        count = 1
    return count
