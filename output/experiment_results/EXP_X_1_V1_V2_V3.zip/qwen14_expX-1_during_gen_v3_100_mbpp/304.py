def rotate_array(arr, d, index):
    """
    Rotate the array 'arr' by 'd' positions and return the element at 'index'.

    :param arr: List[int] - The input list of integers.
    :param d: int - Number of times the array should be rotated.
    :param index: int - Index of the element to return after rotation.
    :return: int - Element at the specified index after rotation.
    """
    n = len(arr)
    d = d % n
    rotated_arr = arr[d:] + arr[:d]
    return rotated_arr[index]
