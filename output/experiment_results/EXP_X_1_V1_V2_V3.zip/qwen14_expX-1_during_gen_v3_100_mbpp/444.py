def trim_tuples(tuples_list, k):
    """
    Trims each tuple in the given list by removing the last k elements from each tuple.

    :param tuples_list: List of tuples to be trimmed.
    :param k: Number of elements to remove from the end of each tuple.
    :return: A new list with each tuple trimmed.
    """
    k = min(k, len(min(tuples_list, key=len)))
    return [tup[:-k] if len(tup) > k else () for tup in tuples_list]
