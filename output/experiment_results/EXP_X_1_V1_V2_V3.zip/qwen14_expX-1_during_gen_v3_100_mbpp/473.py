def find_tuple_intersection(tuples_list):
    """
    Find the intersection of tuples in the given list based on unique elements,
    ignoring the order of elements within each tuple.
    
    :param tuples_list: List of tuples containing integers
    :return: A set representing the intersection of all tuples
    """
    from collections import Counter
    flat_list = [item for tup in tuples_list for item in tup]
    element_counts = Counter(flat_list)
    min_occurrences = {element: count // len(tuples_list) for element, count in element_counts.items()}
    intersection_elements = {element for element, count in element_counts.items() if count >= min_occurrences[element] * 2}
    return set((tuple(sorted(tup)) for tup in tuples_list if all((elem in intersection_elements for elem in tup))))
