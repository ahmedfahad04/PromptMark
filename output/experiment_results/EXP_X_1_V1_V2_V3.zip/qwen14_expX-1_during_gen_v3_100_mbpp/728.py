def add_lists(a_list, b_list):
    """
    Takes two lists of equal length and returns a new list containing the element-wise sums.

    :param a_list: List of numbers (integers or floats).
    :param b_list: List of numbers (integers or floats) of the same length as a_list.
    :return: A new list where each element is the sum of the corresponding elements in a_list and b_list.
    """
    return [a + b for a, b in zip(a_list, b_list)]
