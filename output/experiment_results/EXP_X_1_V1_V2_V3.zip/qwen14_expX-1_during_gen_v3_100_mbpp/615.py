def average_of_tuples(tuples):
    """
    Calculate the average value for each tuple and return the results as a list.
    
    :param tuples: A tuple of tuples containing numerical values
    :return: A list of averages for each inner tuple
    """
    averages = []
    for tup in tuples:
        avg = sum(tup) / len(tup)
        averages.append(avg)
    return averages
