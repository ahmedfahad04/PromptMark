def sort_tuples_by_second_value(tuples_list):
    """
    Sorts a list of tuples based on the second value of each tuple.

    :param tuples_list: List of tuples to be sorted.
    :return: Sorted list of tuples.
    """
    sorted_list = sorted(tuples_list, key=lambda x: x[1])
    return sorted_list
