def count_substrings(s):
    """
    This function counts the number of substrings where the sum of the digits equals the length of the substring.
    
    :param s: Input string consisting of digits
    :return: Count of valid substrings
    """
    count = 0
    n = len(s)
    for i in range(n):
        sum_digits = 0
        for j in range(i, n):
            sum_digits += int(s[j])
            if sum_digits == j - i + 1:
                count += 1
    return count
