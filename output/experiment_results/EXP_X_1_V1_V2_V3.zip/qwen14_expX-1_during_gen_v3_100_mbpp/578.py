def interleave_lists(list1, list2, list3):
    """
    Interleaves three lists of the same length into a single flat list.
    
    Args:
    - list1 (list): First input list.
    - list2 (list): Second input list.
    - list3 (list): Third input list.
    
    Returns:
    - list: A single flat list containing elements from the input lists interleaved.
    """
    # Check if all lists have the same length
    if len(list1) != len(list2) or len(list1) != len(list3):
        raise ValueError("All lists must be of the same length")
    
    # Use zip to pair up elements and then flatten the tuples
    result = [item for sublist in zip(list1, list2, list3) for item in sublist]
    
    return result