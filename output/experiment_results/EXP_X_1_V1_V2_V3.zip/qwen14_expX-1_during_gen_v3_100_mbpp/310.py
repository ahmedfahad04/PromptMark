def string_to_tuple(input_string):
    """
    Converts the input string into a tuple of its characters.
    
    Parameters:
        input_string (str): The string to be converted.
        
    Returns:
        tuple: A tuple containing each character from the input string.
    """
    return tuple(input_string)
