def round_and_multiply(numbers):
    """
    Rounds each number in the given list 'numbers', calculates the sum of these rounded numbers,
    multiplies it by the length of the list, and prints the result.
    
    :param numbers: List of floating point numbers to be rounded and processed.
    """
    rounded_numbers = [round(num) for num in numbers]
    sum_rounded = sum(rounded_numbers)
    result = sum_rounded * len(numbers)
