def extract_nth_element(lst, n):
    """
    Extracts the nth element from each tuple in the given list of tuples.

    Args:
    lst (list): A list of tuples.
    n (int): The index of the element to extract from each tuple.

    Returns:
    list: A list containing the nth elements from each tuple.
    """
    return [t[n] for t in lst if len(t) > n]
