def check_all_equal(lst, element):
    """
    Checks if all elements in the list 'lst' are equal to 'element'.

    Args:
    lst (list): The input list.
    element: The element to compare against.

    Returns:
    bool: True if all elements are equal to 'element', False otherwise.
    """
    return all((item == element for item in lst))
