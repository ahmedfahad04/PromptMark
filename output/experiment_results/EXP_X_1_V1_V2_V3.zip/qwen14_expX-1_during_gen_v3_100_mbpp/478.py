def remove_lowercase_substrings(input_string):
    """
    This function takes an input string and removes all lowercase substrings from it.
    
    :param input_string: The string from which lowercase substrings will be removed.
    :return: A new string with all lowercase substrings removed.
    """
    result = ''
    i = 0
    while i < len(input_string):
        if input_string[i].islower():
            j = i + 1
            while j < len(input_string) and input_string[j].islower():
                j += 1
            i = j
        else:
            result += input_string[i]
            i += 1
    return result
