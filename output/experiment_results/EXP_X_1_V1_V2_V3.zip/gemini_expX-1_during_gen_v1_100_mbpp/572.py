def a(*lists):
    """
    Removes duplicate numbers from a given number of lists.

    Args:
        *lists: A variable number of list arguments, each containing numbers.

    Returns:
        A new list containing all unique numbers from the input lists.
        The order of numbers in the returned list is not guaranteed.
    """
    all_numbers = []
    for current_list in lists:
        all_numbers.extend(current_list)
    unique_numbers = set(all_numbers)
    return list(unique_numbers)
