def a(s1: str, s2: str) -> int:
    """
    Calculates the minimum number of swaps required to convert one binary string
    (s1) to another (s2).

    Args:
        s1: The source binary string.
        s2: The target binary string.

    Returns:
        The minimum number of swaps needed. Returns -1 if conversion is
        impossible (e.g., different lengths or different counts of '0's/'1's).
    """
    if len(s1) != len(s2):
        return -1
    if not all((char in '01' for char in s1)) or not all((char in '01' for char in s2)):
        return -1
    ones_to_zeros = 0
    zeros_to_ones = 0
    for i in range(len(s1)):
        if s1[i] == '1' and s2[i] == '0':
            ones_to_zeros += 1
        elif s1[i] == '0' and s2[i] == '1':
            zeros_to_ones += 1
    if ones_to_zeros != zeros_to_ones:
        return -1
    return ones_to_zeros
