def a(numbers_list):
    """
    Identifies and returns all even numbers from a given list of integers.

    This function iterates through each number in the provided list.
    It uses the modulo operator (%) to check if a number is perfectly
    divisible by 2 (meaning it has a remainder of 0), which indicates
    that the number is even. All even numbers found are collected into
    a new list and returned.

    Args:
        numbers_list (list): A list of integers from which to find even numbers.
                             Example: [1, 2, 3, 4, 5, 6]

    Returns:
        list: A new list containing only the even numbers.
              Example for input [1, 2, 3, 4, 5, 6]: [2, 4, 6]
    """
    even_numbers = []
    for number in numbers_list:
        if number % 2 == 0:
            even_numbers.append(number)
    return even_numbers
