def is_perfect_square(a: int) -> bool:
    """
    Checks if a given number 'a' is a perfect square.

    A perfect square is an integer that is the square of an integer.
    For example, 9 is a perfect square because it's 3*3.

    Args:
        a: The integer number to check.

    Returns:
        True if 'a' is a perfect square, False otherwise.
    """
    if a < 0:
        print(f'Number {a} is negative, so it cannot be a perfect square.')
        return False
    if a == 0 or a == 1:
        print(f'Number {a} is 0 or 1, which are perfect squares.')
        return True
    sqrt_a = math.sqrt(a)
    print(f'The square root of {a} is approximately {sqrt_a:.4f}.')
    rounded_sqrt_a = round(sqrt_a)
    print(f'Rounding {sqrt_a:.4f} to the nearest integer gives {rounded_sqrt_a}.')
    if rounded_sqrt_a * rounded_sqrt_a == a:
        print(f'Because {rounded_sqrt_a} * {rounded_sqrt_a} equals {a}, {a} IS a perfect square.')
        return True
    else:
        print(f'Because {rounded_sqrt_a} * {rounded_sqrt_a} equals {rounded_sqrt_a * rounded_sqrt_a} (which is not {a}), {a} is NOT a perfect square.')
        return False
