def find_union_and_sort(tuple1, tuple2):
    """
  Finds the union of elements from two given tuples and returns them
  in sorted order.

  Args:
    tuple1: The first input tuple.
    tuple2: The second input tuple.

  Returns:
    A list containing the unique elements from both tuples, sorted in ascending order.
  """
    combined_elements = tuple1 + tuple2
    unique_elements = set(combined_elements)
    sorted_union = sorted(list(unique_elements))
    return sorted_union
