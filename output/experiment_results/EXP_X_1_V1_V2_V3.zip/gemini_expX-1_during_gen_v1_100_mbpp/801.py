def a(num1, num2, num3):
    """
    Counts the number of equal numbers from three given integers.

    Args:
        num1 (int): The first integer.
        num2 (int): The second integer.
        num3 (int): The third integer.

    Returns:
        int: The count of equal numbers.
             - 3 if all three numbers are equal.
             - 2 if exactly two numbers are equal.
             - 0 if all three numbers are different.
    """
    if num1 == num2 and num2 == num3:
        return 3
    elif num1 == num2 or num1 == num3 or num2 == num3:
        return 2
    else:
        return 0
