def find_first_ly_adverb(text: str) -> tuple[str | None, int | None]:
    """
    Finds the first word in a string that ends with 'ly' and its starting position.
    For this task, "adverb" is defined by the word ending with "ly".

    Args:
        text (str): The input string to search within.

    Returns:
        tuple[str | None, int | None]: A tuple containing the adverb (str) and its
                                       starting index (int) in the original string.
                                       Returns (None, None) if no such adverb is found.
    """
    if not text:
        return (None, None)
    pattern = '\\b[a-zA-Z]+ly\\b'
    for match in re.finditer(pattern, text):
        adverb = match.group(0)
        position = match.start()
        return (adverb, position)
    return (None, None)
