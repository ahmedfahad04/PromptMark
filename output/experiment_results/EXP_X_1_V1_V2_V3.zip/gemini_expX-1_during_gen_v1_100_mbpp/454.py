def match_word_with_z(word):
    """
  Checks if a given word contains the lowercase letter 'z'.

  Args:
    word: The input string (word) to be checked.

  Returns:
    True if the word contains 'z', False otherwise.
  """
    return 'z' in word
