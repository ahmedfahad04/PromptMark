def extract_quoted_values(text: str) -> list[str]:
    """
    Extracts values enclosed within double quotation marks from a given string.

    This function uses regular expressions to find all substrings that are
    surrounded by double quotes and returns them as a list.

    Args:
        text: The input string from which to extract quoted values.

    Returns:
        A list of strings, where each string is a value found between
        double quotation marks. Returns an empty list if no such values are found.

    Example:
        >>> extract_quoted_values('This is a "test" string with "multiple" values.')
        ['test', 'multiple']
        >>> extract_quoted_values('No quotes here.')
        []
        >>> extract_quoted_values('Another example with "just one".')
        ['just one']
    """
    matches = re.findall('"([^"]*)"', text)
    return matches
