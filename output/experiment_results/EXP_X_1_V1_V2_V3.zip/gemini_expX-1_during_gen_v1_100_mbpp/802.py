def count_rotations(arr):
    """
    Counts the number of rotations required to generate a sorted array
    from a given rotated sorted array. The number of rotations is
    equivalent to the index of the minimum element in the array.

    Args:
        arr (list): A list of integers representing a rotated sorted array.

    Returns:
        int: The number of rotations. Returns 0 if the array is empty or
             already sorted (0 rotations).
    """
    n = len(arr)
    if n == 0:
        return 0
    if arr[0] <= arr[n - 1]:
        return 0
    low = 0
    high = n - 1
    while low < high:
        mid = (low + high) // 2
        if arr[mid] > arr[high]:
            low = mid + 1
        else:
            high = mid
    return low
