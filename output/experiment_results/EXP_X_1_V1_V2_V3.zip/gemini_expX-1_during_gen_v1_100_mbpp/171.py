def find_pentagon_perimeter(a):
    """
  Calculates the perimeter of a regular pentagon given the length of one side.

  Args:
    a: The length of one side of the regular pentagon.

  Returns:
    The perimeter of the regular pentagon.
  """
    perimeter = 5 * a
    return perimeter
