def count_bidirectional_pairs(tuple_list):
    """
    Counts the number of unique bidirectional tuple pairs in a list.

    A 'bidirectional pair' (a, b) means that both the tuple (a, b) AND its
    reverse (b, a) are present in the input `tuple_list`.
    Pairs like (1, 2) and (2, 1) together constitute a single bidirectional pair.
    Similarly, a tuple like (3, 3) is considered bidirectional if it's present,
    as its reverse is also (3, 3).

    Args:
        tuple_list: A list of tuples, where each tuple contains two elements.
                    Example: [(1, 2), (2, 1), (3, 4)]

    Returns:
        The total count of unique bidirectional tuple pairs found in the list.
    """
    tuple_set = set(tuple_list)
    counted_normalized_pairs = set()
    for current_tuple in tuple_list:
        a, b = current_tuple
        reverse_tuple = (b, a)
        if reverse_tuple in tuple_set:
            normalized_pair = tuple(sorted(current_tuple))
            counted_normalized_pairs.add(normalized_pair)
    return len(counted_normalized_pairs)
