def interleave_three_lists(list1, list2, list3):
    """
    Interleaves three lists of the same length into a single flat list.

    Args:
        list1 (list): The first list.
        list2 (list): The second list.
        list3 (list): The third list.

    Returns:
        list: A new list containing the interleaved elements.

    Example:
        >>> interleave_three_lists([1, 2, 3], ['a', 'b', 'c'], [True, False, True])
        [1, 'a', True, 2, 'b', False, 3, 'c', True]
    """
    interleaved_list = []
    for i in range(len(list1)):
        interleaved_list.append(list1[i])
        interleaved_list.append(list2[i])
        interleaved_list.append(list3[i])
    return interleaved_list
