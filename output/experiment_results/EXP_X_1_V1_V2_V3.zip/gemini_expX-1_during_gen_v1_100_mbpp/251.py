def insert_before_each_element(original_list, element_to_insert):
    """
    Inserts a given element before each element in the original list.

    Args:
        original_list (list): The list into which elements will be inserted.
        element_to_insert: The element to be inserted before each item.

    Returns:
        list: A new list with the element inserted before each original item.
              Returns an empty list if the original list is empty.
    """
    result_list = []
    for item in original_list:
        result_list.append(element_to_insert)
        result_list.append(item)
    return result_list
