def move_numbers_to_end(input_string):
    """
    Moves all numeric characters to the end of a given string,
    preserving the relative order of both non-numeric and numeric characters.

    Args:
        input_string (str): The string to process.

    Returns:
        str: A new string with all non-numeric characters first,
             followed by all numeric characters.
    """
    non_numeric_chars = ''
    numeric_chars = ''
    for char in input_string:
        if char.isdigit():
            numeric_chars += char
        else:
            non_numeric_chars += char
    return non_numeric_chars + numeric_chars
