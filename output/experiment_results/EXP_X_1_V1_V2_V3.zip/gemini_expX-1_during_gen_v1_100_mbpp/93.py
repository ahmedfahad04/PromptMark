def a(base, exponent):
    """
    Calculates the value of 'base' raised to the power of 'exponent'.

    Args:
        base (int or float): The number to be raised to a power.
        exponent (int): The power to which the base is raised.

    Returns:
        int or float: The result of 'base' to the power 'exponent'.
    """
    result = base ** exponent
    return result
