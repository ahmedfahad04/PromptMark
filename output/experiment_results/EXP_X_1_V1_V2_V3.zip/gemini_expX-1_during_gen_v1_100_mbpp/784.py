def find_product_of_first_even_and_odd(numbers):
    """
    Finds the product of the first even number and the first odd number
    encountered in a given list of numbers.

    Args:
        numbers (list): A list of integers.

    Returns:
        int or None: The product of the first even and first odd number found.
                     Returns None if either the first even or first odd number
                     is not found in the list.
    """
    first_even = None
    first_odd = None
    for num in numbers:
        if first_even is None and num % 2 == 0:
            first_even = num
        elif first_odd is None and num % 2 != 0:
            first_odd = num
        if first_even is not None and first_odd is not None:
            break
    if first_even is not None and first_odd is not None:
        return first_even * first_odd
    else:
        return None
