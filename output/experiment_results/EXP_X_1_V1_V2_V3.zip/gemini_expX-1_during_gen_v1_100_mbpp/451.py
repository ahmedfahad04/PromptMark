def a(input_string):
    """
  Removes all whitespace characters from the given string.

  Args:
    input_string: The string from which to remove whitespaces.

  Returns:
    A new string with all whitespace characters removed.
  """
    return input_string.replace(' ', '')
