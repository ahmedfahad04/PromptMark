def remove_tuples(input_tuple):
    """
    Removes all nested tuples from the given tuple.

    Args:
        input_tuple: A tuple that may contain other tuples as elements.

    Returns:
        A new tuple containing only the elements that are not tuples.
    """
    result_list = []
    for item in input_tuple:
        if not isinstance(item, tuple):
            result_list.append(item)
    return tuple(result_list)
