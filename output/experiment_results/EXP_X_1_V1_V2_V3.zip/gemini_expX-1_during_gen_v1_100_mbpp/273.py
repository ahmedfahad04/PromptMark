def subtract_tuples(tuple1, tuple2):
    """
    Subtracts elements of the second tuple from the first tuple at corresponding indices.

    This function iterates through both tuples simultaneously, subtracting the element
    from `tuple2` from the corresponding element in `tuple1`. If the tuples have
    different lengths, the subtraction will only occur up to the length of the
    shorter tuple.

    Args:
        tuple1 (tuple): The first tuple. Its elements will be the minuends.
        tuple2 (tuple): The second tuple. Its elements will be the subtrahends.

    Returns:
        tuple: A new tuple containing the results of the element-wise subtraction.
               The length of the resulting tuple will be the minimum of the lengths
               of the two input tuples.

    Example:
        subtract_tuples((10, 20, 30), (1, 2, 3))  # Returns (9, 18, 27)
        subtract_tuples((5, 10, 15, 20), (1, 2))  # Returns (4, 8)
    """
    result_elements = []
    for element1, element2 in zip(tuple1, tuple2):
        difference = element1 - element2
        result_elements.append(difference)
    return tuple(result_elements)
