def a(numbers_list):
    """
    Calculates the product of unique numbers in a given list.

    Args:
        numbers_list (list): A list of numbers (integers or floats).

    Returns:
        int/float: The product of the unique numbers. Returns 1 for an empty list
                   (as 1 is the multiplicative identity).
    """
    unique_numbers = set(numbers_list)
    product = 1
    for number in unique_numbers:
        product *= number
    return product
