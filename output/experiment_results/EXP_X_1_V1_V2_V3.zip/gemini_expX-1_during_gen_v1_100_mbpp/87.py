def a(dict1, dict2, dict3):
    """
    Merges three dictionaries into a single new dictionary.

    This function combines key-value pairs from three input dictionaries
    into a brand new dictionary. If the same key appears in multiple
    input dictionaries, the value from the dictionary that appears
    later in the argument list will overwrite the values from earlier
    dictionaries.

    Args:
        dict1 (dict): The first dictionary to merge.
        dict2 (dict): The second dictionary to merge.
        dict3 (dict): The third dictionary to merge.

    Returns:
        dict: A new dictionary containing all unique key-value pairs
              from the three input dictionaries, with later dictionaries
              taking precedence for duplicate keys.
    """
    merged_dict = {**dict1, **dict2, **dict3}
    return merged_dict
