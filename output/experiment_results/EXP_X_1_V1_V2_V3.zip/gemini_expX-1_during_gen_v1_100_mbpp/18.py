def remove_characters_from_first_string(main_string, chars_to_remove_string):
    """
    Removes characters from the first string that are present in the second string.

    Args:
        main_string (str): The string from which characters will be removed.
        chars_to_remove_string (str): The string containing characters to be removed
                                       from the main_string.

    Returns:
        str: A new string with the specified characters removed.
    """
    chars_to_remove_set = set(chars_to_remove_string)
    filtered_characters = []
    for char in main_string:
        if char not in chars_to_remove_set:
            filtered_characters.append(char)
    return ''.join(filtered_characters)
