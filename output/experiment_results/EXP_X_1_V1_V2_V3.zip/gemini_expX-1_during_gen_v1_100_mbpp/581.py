def find_square_pyramid_surface_area(base_edge, height):
    """
    Calculates the total surface area of a square pyramid.

    A square pyramid has a square base and four triangular faces.
    The total surface area is the sum of the base area and the lateral surface area (four triangular faces).

    Args:
        base_edge (float or int): The length of one side of the square base.
        height (float or int): The perpendicular height from the apex to the center of the base.

    Returns:
        float: The total surface area of the square pyramid.
    """
    base_area = base_edge * base_edge
    half_base_edge = base_edge / 2
    slant_height = math.sqrt(height ** 2 + half_base_edge ** 2)
    triangle_face_area = 0.5 * base_edge * slant_height
    lateral_surface_area = 4 * triangle_face_area
    total_surface_area = base_area + lateral_surface_area
    return total_surface_area
