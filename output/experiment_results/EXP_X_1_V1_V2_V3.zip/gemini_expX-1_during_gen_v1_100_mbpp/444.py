def trim_tuples_by_k(tuple_list: list[tuple], k: int) -> list[tuple]:
    """
    Trims each tuple in a list of tuples by removing the last 'k' elements.

    This function iterates through a list of tuples and for each tuple,
    it creates a new tuple that excludes the last 'k' elements.
    If 'k' is 0, the original tuple is returned.
    If 'k' is greater than the length of a tuple, an empty tuple is returned
    for that specific tuple.

    Args:
        tuple_list (list[tuple]): A list where each element is a tuple.
        k (int): The number of elements to remove from the end of each tuple.
                 Must be a non-negative integer.

    Returns:
        list[tuple]: A new list containing the trimmed tuples.

    Example:
        >>> trim_tuples_by_k([(1, 2, 3, 4), (5, 6, 7)], 1)
        [(1, 2, 3), (5, 6)]
        >>> trim_tuples_by_k([(10, 20), (30, 40, 50)], 0)
        [(10, 20), (30, 40, 50)]
        >>> trim_tuples_by_k([(1,), (2, 3, 4)], 5)
        [(), ()]
    """
    return [tpl[:-k] for tpl in tuple_list]
