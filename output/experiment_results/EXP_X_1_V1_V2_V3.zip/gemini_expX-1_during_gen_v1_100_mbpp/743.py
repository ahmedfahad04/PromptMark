def rotate_list_right(input_list, num_rotations):
    """
    Rotates a given list to the right by a specified number of items.

    Args:
        input_list (list): The list to be rotated.
        num_rotations (int): The number of positions to rotate the list to the right.

    Returns:
        list: A new list that is the rotated version of the input_list.
    """
    if not input_list or num_rotations == 0:
        return input_list
    effective_rotations = num_rotations % len(input_list)
    if effective_rotations == 0:
        return input_list
    rotated_part = input_list[-effective_rotations:]
    remaining_part = input_list[:-effective_rotations]
    return rotated_part + remaining_part
