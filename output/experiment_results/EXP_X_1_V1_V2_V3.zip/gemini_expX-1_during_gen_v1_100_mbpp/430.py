def find_directrix(a, b, c):
    """
    Calculates the equation of the directrix for a parabola in the form y = ax^2 + bx + c.

    Args:
        a (float): The coefficient of x^2.
        b (float): The coefficient of x.
        c (float): The constant term.

    Returns:
        str: The equation of the directrix in the form "y = value".
             Returns an error message if 'a' is zero (as it's not a parabola).
    """
    if a == 0:
        return "Error: 'a' cannot be zero for a parabola. If a=0, it's a straight line (y = bx + c)."
    h = -b / (2 * a)
    k = a * h ** 2 + b * h + c
    p = 1 / (4 * a)
    directrix_y = k - p
    return f'y = {directrix_y}'
