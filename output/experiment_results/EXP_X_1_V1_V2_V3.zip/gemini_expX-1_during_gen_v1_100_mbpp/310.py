def convert_string_to_char_tuple(input_string):
    """
  Converts a given string into a tuple of its individual characters.

  Args:
    input_string: The string to be converted.

  Returns:
    A tuple where each element is a character from the input_string.
  """
    return tuple(input_string)
