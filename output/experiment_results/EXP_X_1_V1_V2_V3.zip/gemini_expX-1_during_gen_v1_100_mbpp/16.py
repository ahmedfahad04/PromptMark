def is_lowercase_underscore_sequence(input_string: str) -> bool:
    """
    Checks if the input string contains sequences of lowercase letters 
    joined with an underscore.

    Args:
        input_string: The string to check.

    Returns:
        True if the string matches the pattern (e.g., "hello_world", "a_b"),
        False otherwise (e.g., "HelloWorld", "hello-world", "a", "_b").
    """
    pattern = '^[a-z]+_[a-z]+$'
    if re.fullmatch(pattern, input_string):
        return True
    else:
        return False
