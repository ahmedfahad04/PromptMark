def convert_snake_to_camel(snake_case_string):
    """
    Converts a snake_case string to a camelCase string.

    Args:
        snake_case_string (str): The input string in snake_case.

    Returns:
        str: The converted string in camelCase.
    """
    words = snake_case_string.split('_')
    camel_case_words = [words[0]] + [word.capitalize() for word in words[1:]]
    return ''.join(camel_case_words)
