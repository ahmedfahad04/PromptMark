def sum_even_at_even_positions(numbers):
    """
    Calculates the sum of even numbers that are located at even positions (0, 2, 4, ...)
    within a list of numbers.

    Args:
        numbers: A list of integers.

    Returns:
        The sum of even numbers at even positions.
    """
    total_sum = 0
    for index, num in enumerate(numbers):
        if index % 2 == 0 and num % 2 == 0:
            total_sum += num
    return total_sum
