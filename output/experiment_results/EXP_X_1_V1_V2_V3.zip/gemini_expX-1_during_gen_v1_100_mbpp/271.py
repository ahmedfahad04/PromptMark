def a(n: int) -> int:
    """
    Calculates the sum of the first n even natural numbers, each raised to the fifth power.

    Args:
        n: An integer representing the count of even natural numbers to consider.

    Returns:
        The sum of these numbers raised to the fifth power.
    """
    total_sum = 0
    for i in range(1, n + 1):
        even_number = 2 * i
        fifth_power = even_number ** 5
        total_sum += fifth_power
    return total_sum
