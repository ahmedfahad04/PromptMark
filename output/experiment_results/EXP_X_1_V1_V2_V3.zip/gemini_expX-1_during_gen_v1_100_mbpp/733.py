def find_first_occurrence_index(arr, target):
    """
    Finds the index of the first occurrence of a given number in a sorted array.

    This function uses a modified binary search approach to efficiently locate
    the first instance of the target number. If the number is not found,
    it returns -1.

    Args:
        arr (list): A sorted list of numbers (integers or floats).
        target (int/float): The number to search for.

    Returns:
        int: The index of the first occurrence of the target number,
             or -1 if the target is not found in the array.
    """
    low = 0
    high = len(arr) - 1
    first_occurrence_index = -1
    while low <= high:
        mid = low + (high - low) // 2
        if arr[mid] == target:
            first_occurrence_index = mid
            high = mid - 1
        elif arr[mid] < target:
            low = mid + 1
        else:
            high = mid - 1
    return first_occurrence_index
