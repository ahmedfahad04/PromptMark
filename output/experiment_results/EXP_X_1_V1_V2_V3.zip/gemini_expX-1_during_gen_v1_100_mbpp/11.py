def remove_first_and_last_char_occurrence(text_string: str, char_to_remove: str) -> str:
    """
    Removes the first and last occurrence of a given character from a string.

    Args:
        text_string: The original string.
        char_to_remove: The character to remove.

    Returns:
        The string with the first and last occurrences of the character removed.
        Returns the original string if the character is not found, or found only once.
    """
    if not char_to_remove or len(char_to_remove) != 1:
        return text_string
    first_index = text_string.find(char_to_remove)
    last_index = text_string.rfind(char_to_remove)
    if first_index == -1 or first_index == last_index:
        return text_string
    modified_string = text_string[:first_index] + text_string[first_index + 1:last_index] + text_string[last_index + 1:]
    return modified_string
