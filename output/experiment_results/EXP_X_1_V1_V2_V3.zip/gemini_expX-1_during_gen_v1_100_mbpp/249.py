# Example Usage:
list_a = [1, 2, 3, 4, 5]
list_b = [4, 5, 6, 7, 8]
list_c = [10, 20, 30]
list_d = [20, 25, 30]
list_e = [1, 1, 2, 3, 4] # List with duplicates
list_f = [3, 4, 4, 5, 5] # Another list with duplicates

# Find the intersection of list_a and list_b
intersection1 = find_array_intersection(list_a, list_b)
print(f"Intersection of {list_a} and {list_b}: {intersection1}") # Expected: [4, 5] (order might vary)

# Find the intersection of list_c and list_d
intersection2 = find_array_intersection(list_c, list_d)
print(f"Intersection of {list_c} and {list_d}: {intersection2}") # Expected: [20, 30] (order might vary)

# Find the intersection of lists with duplicates
intersection3 = find_array_intersection(list_e, list_f)
print(f"Intersection of {list_e} and {list_f}: {intersection3}") # Expected: [3, 4] (order might vary)

# No common elements
list_g = [1, 2]
list_h = [3, 4]
intersection4 = find_array_intersection(list_g, list_h)
print(f"Intersection of {list_g} and {list_h}: {intersection4}") # Expected: []