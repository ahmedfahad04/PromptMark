def polar_to_rectangular(r, theta_degrees):
    """
    Converts polar coordinates (r, theta) to rectangular coordinates (x, y).

    Args:
        r (float): The radial distance from the origin.
        theta_degrees (float): The angle in degrees from the positive x-axis.

    Returns:
        tuple: A tuple containing the rectangular coordinates (x, y).
    """
    theta_radians = math.radians(theta_degrees)
    x = r * math.cos(theta_radians)
    y = r * math.sin(theta_radians)
    return (x, y)
