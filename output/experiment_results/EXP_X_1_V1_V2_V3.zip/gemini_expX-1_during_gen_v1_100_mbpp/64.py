def a(list_of_tuples):
    """
    Sorts a list of tuples based on the second value of each tuple.

    Args:
        list_of_tuples: A list of tuples, where each tuple has at least two elements.

    Returns:
        A new list of tuples, sorted by the second element.
    """
    return sorted(list_of_tuples, key=lambda x: x[1])
