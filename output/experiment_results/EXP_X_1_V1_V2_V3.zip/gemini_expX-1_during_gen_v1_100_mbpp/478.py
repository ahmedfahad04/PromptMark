def remove_lowercase_substrings(input_string):
    """
    Removes all lowercase characters from a given string, effectively
    removing any lowercase substrings.

    Args:
        input_string (str): The string from which to remove lowercase characters.

    Returns:
        str: A new string containing only the characters that are not lowercase.
             This includes uppercase letters, digits, symbols, and whitespace.
    """
    result_chars = []
    for char in input_string:
        if not char.islower():
            result_chars.append(char)
    return ''.join(result_chars)
