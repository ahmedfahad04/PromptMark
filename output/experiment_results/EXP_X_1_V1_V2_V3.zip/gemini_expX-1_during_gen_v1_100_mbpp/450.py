def a(list_of_strings, target_size):
    """
    Extracts strings of a specified size from a given list of strings.

    Args:
        list_of_strings (list): A list of string values.
        target_size (int): The desired length of strings to extract.

    Returns:
        list: A new list containing only the strings that match the target_size.
    """
    extracted_strings = []
    for s in list_of_strings:
        if len(s) == target_size:
            extracted_strings.append(s)
    return extracted_strings
