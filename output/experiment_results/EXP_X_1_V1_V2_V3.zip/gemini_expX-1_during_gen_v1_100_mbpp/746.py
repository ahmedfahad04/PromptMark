def calculate_sector_area(radius, angle):
    """
    Calculates the area of a circular sector.

    Args:
        radius (float or int): The radius of the circle.
        angle (float or int): The angle of the sector in degrees.

    Returns:
        float: The area of the sector if the angle is within 0-360 degrees.
        None: If the angle is greater than 360 degrees.
    """
    if angle > 360:
        return None
    area = angle / 360 * math.pi * radius ** 2
    return area
