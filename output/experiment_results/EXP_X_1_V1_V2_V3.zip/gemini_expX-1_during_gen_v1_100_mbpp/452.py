def a(cost_price, selling_price):
    """
    Calculates the loss amount on a sale if there is a loss, otherwise returns 0.

    Args:
        cost_price (float or int): The original cost of the item.
        selling_price (float or int): The price at which the item was sold.

    Returns:
        float or int: The loss amount if selling_price is less than cost_price,
                      otherwise returns 0.
    """
    if selling_price < cost_price:
        return cost_price - selling_price
    else:
        return 0
