def find_quotient(dividend: int | float, divisor: int | float) -> int:
    """
    Calculates the quotient of two numbers, rounded down to the nearest integer (floor division).

    Args:
        dividend: The number to be divided.
        divisor: The number by which to divide. Must not be zero.

    Returns:
        The integer result of the floor division (rounded down to the nearest integer).

    Raises:
        ZeroDivisionError: If the divisor is zero.

    Examples:
        >>> find_quotient(10, 3)
        3
        >>> find_quotient(7, 2)
        3
        >>> find_quotient(-7, 2)
        -4
        >>> find_quotient(10.5, 3)
        3
        >>> find_quotient(7.9, 2.1)
        3
    """
    if divisor == 0:
        raise ZeroDivisionError('Cannot divide by zero.')
    return int(dividend // divisor)
