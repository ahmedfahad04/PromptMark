def count_chars_with_vowel_neighbors(s: str) -> int:
    """
    Counts characters in a string that have at least one vowel as an immediate neighbor.

    A neighbor can be to the left or to the right of the character.
    Vowels are considered 'a', 'e', 'i', 'o', 'u' (case-insensitive).

    Args:
        s: The input string.

    Returns:
        The total count of characters with vowel neighbors.
    """
    vowels = 'aeiouAEIOU'
    count = 0
    n = len(s)
    if n <= 1:
        return 0
    for i in range(n):
        has_vowel_neighbor = False
        if i > 0:
            if s[i - 1] in vowels:
                has_vowel_neighbor = True
        if i < n - 1:
            if s[i + 1] in vowels:
                has_vowel_neighbor = True
        if has_vowel_neighbor:
            count += 1
    return count
