def a(original_string: str, old_char: str, new_char: str) -> str:
    """
    Replaces all occurrences of a specified character in a string with another character.

    Args:
        original_string (str): The string in which to perform the replacement.
        old_char (str): The character (or substring) to be replaced.
        new_char (str): The character (or substring) to replace with.

    Returns:
        str: A new string with the replacements made.
    """
    return original_string.replace(old_char, new_char)
