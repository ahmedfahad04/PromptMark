def a(list_of_lists):
    """
    Splits a list of sublists (each with two elements) into two separate lists.
    The first returned list contains all the first elements of the sublists,
    and the second returned list contains all the second elements.

    Args:
        list_of_lists: A list where each element is a sublist of two elements.
                       Example: [[1, 2], [3, 4], [5, 6]]

    Returns:
        A list containing two lists:
        - The first list comprises the first elements from each sublist.
        - The second list comprises the second elements from each sublist.
        Example: [[1, 3, 5], [2, 4, 6]]
    """
    first_elements = []
    second_elements = []
    for sublist in list_of_lists:
        first_elements.append(sublist[0])
        second_elements.append(sublist[1])
    return [first_elements, second_elements]
