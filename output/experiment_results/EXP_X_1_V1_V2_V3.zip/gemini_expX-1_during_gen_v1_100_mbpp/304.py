def find_element_after_rotations(arr: list, rotations: int, index: int) -> int:
    """
    Finds the element at a given index after a specified number of left rotations.

    Args:
        arr (list): The input list (array) of elements.
        rotations (int): The number of left rotations to perform.
        index (int): The target index to find the element at after rotations.

    Returns:
        int: The element at the given index after rotations.

    Raises:
        IndexError: If the target index is out of bounds for the array.
        ValueError: If the array is empty.

    Example:
        >>> arr = [1, 2, 3, 4, 5]
        >>> rotations = 2
        >>> target_index = 0
        >>> find_element_after_rotations(arr, rotations, target_index)
        3

        >>> arr = [10, 20, 30, 40, 50]
        >>> rotations = 3
        >>> target_index = 2
        >>> find_element_after_rotations(arr, rotations, target_index)
        50
        # Original: [10, 20, 30, 40, 50]
        # 1 rotation: [20, 30, 40, 50, 10]
        # 2 rotations: [30, 40, 50, 10, 20]
        # 3 rotations: [40, 50, 10, 20, 30]
        # At index 2 is 10. Let's check our formula:
        # original_pos = (2 + 3) % 5 = 5 % 5 = 0
        # arr[0] is 10. Correct!
    """
    n = len(arr)
    if n == 0:
        raise ValueError('The array cannot be empty.')
    if not 0 <= index < n:
        raise IndexError(f'Index {index} is out of bounds for an array of size {n}.')
    effective_rotations = rotations % n
    original_position = (index + effective_rotations) % n
    return arr[original_position]
