def find_squares_of_elements(a):
    """
  Calculates the square of each element in a given list.

  Args:
    a: A list of numbers (integers or floats).

  Returns:
    A new list containing the squares of the individual elements
    from the input list.
  """
    squared_elements = []
    for element in a:
        squared_elements.append(element * element)
    return squared_elements
