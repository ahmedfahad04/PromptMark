def find_longest_sublist_length(list_of_lists):
    """
    Finds the length of the longest sublist within a list of lists.

    Args:
        list_of_lists: A list where each element is itself a list (a sublist).
                       Example: [[1, 2], [3, 4, 5], [6]]

    Returns:
        An integer representing the length of the longest sublist.
        Returns 0 if the input list_of_lists is empty.
    """
    max_length = 0
    for sublist in list_of_lists:
        current_length = len(sublist)
        if current_length > max_length:
            max_length = current_length
    return max_length
