def a(list_of_tuples):
    """
    Finds common first elements in a given list of tuples.
    A first element is considered common if it appears as the first element
    in more than one tuple within the list.

    Args:
        list_of_tuples: A list of tuples, e.g., [(1, 'a'), (2, 'b'), (1, 'c')]

    Returns:
        A list of first elements that appear more than once.
        Returns an empty list if no such elements are found.
    """
    if not list_of_tuples:
        return []
    first_elements = [item[0] for item in list_of_tuples]
    element_counts = collections.Counter(first_elements)
    common_elements = []
    for element, count in element_counts.items():
        if count > 1:
            common_elements.append(element)
    return common_elements
