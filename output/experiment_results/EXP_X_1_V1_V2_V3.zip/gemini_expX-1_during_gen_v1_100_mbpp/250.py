def a(my_tuple, element):
    """
  Counts the occurrences of a given element in a tuple.

  Args:
    my_tuple: The input tuple to search within.
    element: The element whose occurrences need to be counted.

  Returns:
    The number of times the element appears in the tuple.
  """
    return my_tuple.count(element)
