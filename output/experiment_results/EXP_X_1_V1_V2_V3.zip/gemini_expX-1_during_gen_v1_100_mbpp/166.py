def a(numbers):
    """
    Counts the number of pairs of integers in a list whose XOR sum is an even number.

    Args:
        numbers: A list of integers.

    Returns:
        The total count of such pairs.
    """
    even_count = 0
    odd_count = 0
    for num in numbers:
        if num % 2 == 0:
            even_count += 1
        else:
            odd_count += 1
    pairs_from_even = 0
    if even_count >= 2:
        pairs_from_even = even_count * (even_count - 1) // 2
    pairs_from_odd = 0
    if odd_count >= 2:
        pairs_from_odd = odd_count * (odd_count - 1) // 2
    return pairs_from_even + pairs_from_odd
