def a(tuple1, tuple2):
    """
  Extracts element-wise tuples from two given tuples.

  Args:
    tuple1: The first input tuple.
    tuple2: The second input tuple.

  Returns:
    A new tuple where each element is a tuple containing the corresponding
    elements from tuple1 and tuple2. The length of the resulting tuple
    will be the length of the shorter input tuple.

  Example:
    >>> a((1, 2, 3), ('a', 'b', 'c'))
    ((1, 'a'), (2, 'b'), (3, 'c'))
    >>> a((10, 20), (1, 2, 3, 4))
    ((10, 1), (20, 2))
  """
    return tuple(zip(tuple1, tuple2))
