def a(parallel_side_1, parallel_side_2):
    """
  Calculates the median length of a trapezium.

  The median length of a trapezium is the average of the lengths of its two parallel sides.

  Args:
    parallel_side_1 (float or int): The length of the first parallel side of the trapezium.
    parallel_side_2 (float or int): The length of the second parallel side of the trapezium.

  Returns:
    float: The median length of the trapezium.
  """
    if not (isinstance(parallel_side_1, (int, float)) and isinstance(parallel_side_2, (int, float))):
        raise TypeError('Both parallel sides must be numbers (integers or floats).')
    if parallel_side_1 <= 0 or parallel_side_2 <= 0:
        raise ValueError('Side lengths must be positive.')
    median_length = (parallel_side_1 + parallel_side_2) / 2
    return median_length
