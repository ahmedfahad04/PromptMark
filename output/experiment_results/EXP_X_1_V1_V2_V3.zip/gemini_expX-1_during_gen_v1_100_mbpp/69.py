def check_sublist(main_list, sublist):
    """
    Checks if a given 'sublist' is present as a contiguous sequence
    within the 'main_list'.

    This function iterates through the 'main_list', taking slices that are
    the same length as the 'sublist' and comparing them.

    Args:
        main_list (list): The larger list to search within.
        sublist (list): The smaller list (sublist) to find.

    Returns:
        bool: True if the sublist is found within the main_list, False otherwise.

    Examples:
        check_sublist([1, 2, 3, 4, 5], [3, 4]) == True
        check_sublist([1, 2, 3, 4, 5], [1, 5]) == False (not contiguous)
        check_sublist([1, 2, 3], []) == True (empty sublist is always considered present)
        check_sublist([1, 2], [1, 2, 3]) == False (sublist is longer)
    """
    if not sublist:
        return True
    if len(sublist) > len(main_list):
        return False
    for i in range(len(main_list) - len(sublist) + 1):
        current_slice = main_list[i:i + len(sublist)]
        if current_slice == sublist:
            return True
    return False
