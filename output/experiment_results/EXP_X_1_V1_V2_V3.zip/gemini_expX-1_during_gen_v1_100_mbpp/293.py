def a(side1, side2, is_hypotenuse_given=False):
    """
    Calculates the length of the third side of a right-angled triangle.

    This function uses the Pythagorean theorem (a² + b² = c²) to find the
    unknown side.

    Args:
        side1 (float or int): The length of the first known side. Must be positive.
        side2 (float or int): The length of the second known side. Must be positive.
        is_hypotenuse_given (bool, optional):
            - If `False` (default): `side1` and `side2` are treated as the two legs
              (the shorter sides) of the triangle, and the function calculates the hypotenuse
              (the longest side opposite the right angle).
              (i.e., you provide 'a' and 'b', and it finds 'c')
            - If `True`: `side1` is treated as one leg and `side2` is treated as
              the hypotenuse. The function calculates the length of the other leg.
              (i.e., you provide 'a' and 'c', and it finds 'b')

    Returns:
        float: The length of the calculated third side.

    Raises:
        TypeError: If side lengths are not numbers.
        ValueError: If side lengths are not positive, or if a leg is
                    provided that is greater than or equal to the hypotenuse,
                    which would make an invalid triangle.
    """
    if not isinstance(side1, (int, float)) or not isinstance(side2, (int, float)):
        raise TypeError('Error: Side lengths must be numbers (integers or floating-point numbers).')
    if side1 <= 0 or side2 <= 0:
        raise ValueError('Error: Side lengths must be positive values.')
    if is_hypotenuse_given:
        hypotenuse_length = side2
        known_leg_length = side1
        if known_leg_length >= hypotenuse_length:
            raise ValueError("Error: A leg's length cannot be greater than or equal to the hypotenuse's length. Please ensure the hypotenuse is the longest side when 'is_hypotenuse_given' is True.")
        unknown_leg_squared = hypotenuse_length ** 2 - known_leg_length ** 2
        return math.sqrt(unknown_leg_squared)
    else:
        hypotenuse_squared = side1 ** 2 + side2 ** 2
        return math.sqrt(hypotenuse_squared)
