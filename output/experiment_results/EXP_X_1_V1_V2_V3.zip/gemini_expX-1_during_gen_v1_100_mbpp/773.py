def a(main_string: str, sub_string: str):
    """
    Finds all occurrences and their positions (start and end indices) of a substring
    within a main string.

    Args:
        main_string (str): The string to search within.
        sub_string (str): The substring to search for.

    Returns:
        list[tuple[int, int]] | None: A list of (start_index, end_index) tuples
                                     for each occurrence, or None if no matches are found.
    """
    if not sub_string:
        return None
    occurrences = []
    start_search_index = 0
    while True:
        found_index = main_string.find(sub_string, start_search_index)
        if found_index == -1:
            break
        else:
            end_index = found_index + len(sub_string)
            occurrences.append((found_index, end_index))
            start_search_index = found_index + 1
    return occurrences if occurrences else None
