def a(sorted_list):
    """
    Finds the smallest missing natural number from a sorted list of natural numbers.

    A "natural number" typically refers to a positive integer (1, 2, 3, ...).
    This function assumes the input list is sorted in non-decreasing order.

    Args:
        sorted_list: A list of natural numbers, sorted in non-decreasing order.
                     The list can be empty, or contain duplicates.

    Returns:
        The smallest natural number that is not present in the list,
        assuming the expected sequence of natural numbers starts from 1.

    Examples:
        # All numbers are present, so the next expected number (6) is missing
        # from the infinite sequence of natural numbers.
        a([1, 2, 3, 4, 5]) == 6

        # The number 3 is missing between 2 and 4.
        a([1, 2, 4, 5]) == 3

        # The list starts from 2, but the smallest natural number is 1, so 1 is missing.
        a([2, 3, 4, 5]) == 1

        # An empty list means the smallest natural number, 1, is missing.
        a([]) == 1

        # Even with duplicates, the logic correctly finds the next missing number.
        # Here, 1, 2, and 3 are present (ignoring the duplicate 2), so 4 is missing.
        a([1, 2, 2, 3]) == 4
    """
    expected_num = 1
    for num in sorted_list:
        if num < expected_num:
            continue
        elif num == expected_num:
            expected_num += 1
        else:
            return expected_num
    return expected_num
