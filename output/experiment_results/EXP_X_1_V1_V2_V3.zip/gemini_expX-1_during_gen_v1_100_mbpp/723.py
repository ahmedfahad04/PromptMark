def a(list1, list2):
    """
    Counts the number of indices where two lists have the same value.

    Args:
        list1 (list): The first list of values.
        list2 (list): The second list of values, expected to be of the same length as list1.

    Returns:
        int: The total count of indices where list1[i] == list2[i].
    """
    count = 0
    for i in range(len(list1)):
        if list1[i] == list2[i]:
            count += 1
    return count
