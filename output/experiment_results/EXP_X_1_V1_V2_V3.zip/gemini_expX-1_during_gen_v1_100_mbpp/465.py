def drop_empty_items(input_dict: dict) -> dict:
    """
    Removes items from a dictionary where the value is considered "empty" (falsy).

    In Python, values like None, False, 0, 0.0, "", [], {}, and set()
    are all considered "falsy" and will be dropped by this function.

    Args:
        input_dict: The dictionary from which to drop empty items.

    Returns:
        A new dictionary with only the non-empty items.
    """
    return {key: value for key, value in input_dict.items() if value}
