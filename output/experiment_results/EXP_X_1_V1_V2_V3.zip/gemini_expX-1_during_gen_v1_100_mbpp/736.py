def left_insertion_point(sorted_list, value):
    """
    Locates the left insertion point for a specified value in a sorted list.

    This function finds the index where 'value' can be inserted into 'sorted_list'
    while maintaining its sorted order. If 'value' already exists, it returns the
    index of the first occurrence.

    Args:
        sorted_list (list): A list of elements sorted in ascending order.
        value: The value to find the insertion point for.

    Returns:
        int: The index where 'value' should be inserted.
    """
    low = 0
    high = len(sorted_list)
    while low < high:
        mid = (low + high) // 2
        if sorted_list[mid] < value:
            low = mid + 1
        else:
            high = mid
    return low
