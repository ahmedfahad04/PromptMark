def check_even_divisor_count(number):
    """
    Checks if a given number has an even count of divisors.

    This function leverages the mathematical property:
    A positive integer has an odd number of divisors if and only if it is a perfect square.
    Therefore, it has an even number of divisors if and only if it is NOT a perfect square.

    Args:
        number (int): The integer to check. It should be a non-negative integer.

    Returns:
        bool: True if the number has an even count of divisors, False otherwise.

    Raises:
        ValueError: If the input 'number' is negative.
    """
    if number < 0:
        raise ValueError('Input number must be a non-negative integer for divisor calculations.')
    integer_sqrt = int(math.sqrt(number))
    return integer_sqrt * integer_sqrt != number
