def a(input_list):
    """
    Returns a list of all pairs of consecutive items in a given list.

    Args:
        input_list: A list of items.

    Returns:
        A list of tuples, where each tuple represents a consecutive pair
        from the input list. Returns an empty list if the input list has
        fewer than two items.
    """
    consecutive_pairs = []
    for i in range(len(input_list) - 1):
        pair = (input_list[i], input_list[i + 1])
        consecutive_pairs.append(pair)
    return consecutive_pairs
