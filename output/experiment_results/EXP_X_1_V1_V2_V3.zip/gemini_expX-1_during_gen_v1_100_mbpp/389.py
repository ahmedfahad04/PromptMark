def find_nth_lucas_number(n: int) -> int:
    """
    Calculates the n'th Lucas number.

    Args:
        n: The index of the Lucas number to find (must be a non-negative integer).

    Returns:
        The n'th Lucas number.

    Raises:
        ValueError: If n is a negative integer.
    """
    if n < 0:
        raise ValueError('Lucas number index must be a non-negative integer.')
    if n == 0:
        return 2
    elif n == 1:
        return 1
    current_minus_2 = 2
    current_minus_1 = 1
    for _ in range(2, n + 1):
        current_lucas = current_minus_2 + current_minus_1
        current_minus_2 = current_minus_1
        current_minus_1 = current_lucas
    return current_minus_1
