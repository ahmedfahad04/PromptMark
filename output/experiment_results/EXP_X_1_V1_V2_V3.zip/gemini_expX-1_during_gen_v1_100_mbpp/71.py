def a(elements):
    """
  Sorts a list of elements in ascending order.

  Args:
    elements: A list of comparable elements (e.g., numbers, strings).

  Returns:
    A new list containing the elements from the input list, sorted in ascending order.
  """
    return sorted(elements)
