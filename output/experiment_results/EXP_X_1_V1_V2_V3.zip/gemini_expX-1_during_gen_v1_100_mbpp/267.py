def a(n: int) -> int:
    """
    Calculates the sum of the squares of the first n odd natural numbers.

    For example:
    If n = 1, the first odd number is 1. Sum = 1^2 = 1
    If n = 2, the first two odd numbers are 1, 3. Sum = 1^2 + 3^2 = 1 + 9 = 10
    If n = 3, the first three odd numbers are 1, 3, 5. Sum = 1^2 + 3^2 + 5^2 = 1 + 9 + 25 = 35

    Args:
        n: An integer representing how many odd natural numbers to consider.
           Must be a non-negative integer.

    Returns:
        The sum of the squares of the first n odd natural numbers.
        Returns 0 if n is 0 or negative.
    """
    if n <= 0:
        return 0
    total_sum = 0
    for k in range(1, n + 1):
        odd_number = 2 * k - 1
        total_sum += odd_number ** 2
    return total_sum
