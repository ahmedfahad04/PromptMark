def newman_conway(n: int) -> int:
    """
    Calculates the nth number in the Newman-Conway sequence.

    The Newman-Conway sequence is a self-referencing integer sequence defined as:
    P(1) = 1
    P(2) = 1
    P(n) = P(P(n-1)) + P(P(n-2)) for n > 2

    This implementation uses dynamic programming (memoization) with a list
    to store previously computed terms, avoiding redundant calculations
    and making it efficient for larger 'n' values.

    Args:
        n (int): The position of the number in the sequence to find (1-indexed).
                 Must be a positive integer.

    Returns:
        int: The nth number in the Newman-Conway sequence.

    Raises:
        ValueError: If n is not a positive integer.
    """
    if not isinstance(n, int) or n <= 0:
        raise ValueError("Input 'n' must be a positive integer.")
    if n == 1:
        return 1
    if n == 2:
        return 1
    P_vals = [0] * (n + 1)
    P_vals[1] = 1
    P_vals[2] = 1
    for k in range(3, n + 1):
        val_pk_minus_1 = P_vals[k - 1]
        val_pk_minus_2 = P_vals[k - 2]
        P_vals[k] = P_vals[val_pk_minus_1] + P_vals[val_pk_minus_2]
    return P_vals[n]
