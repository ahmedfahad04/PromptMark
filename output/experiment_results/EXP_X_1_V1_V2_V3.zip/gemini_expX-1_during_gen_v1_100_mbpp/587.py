def a(input_list):
    """
  Converts a given list to a tuple.

  Args:
    input_list: The list to be converted.

  Returns:
    A tuple containing the elements of the input_list.
  """
    return tuple(input_list)
