def toggle_bits_except_first_last(number):
    """
    Toggles all bits of a positive integer 'number' EXCEPT its Most Significant Bit (MSB)
    and its Least Significant Bit (LSB).

    For example, if number = 10 (binary 1010):
    - MSB is the leftmost '1' (at position 3).
    - LSB is the rightmost '0' (at position 0).
    - The bits to toggle are the ones in between: '01' (at positions 2 and 1).
    - Toggling '01' gives '10'.
    - The result would be 1(MSB) 1(toggled) 0(toggled) 0(LSB) -> 1100 (binary) which is 12.

    Args:
        number (int): The positive integer whose bits are to be toggled.

    Returns:
        int: The number with its middle bits toggled, or the original number
             if it has 2 or fewer bits (as there are no middle bits to toggle).
    """
    num_bits = number.bit_length()
    if num_bits <= 2:
        return number
    middle_bits_count = num_bits - 2
    raw_mask = (1 << middle_bits_count) - 1
    toggle_mask = raw_mask << 1
    result = number ^ toggle_mask
    return result
