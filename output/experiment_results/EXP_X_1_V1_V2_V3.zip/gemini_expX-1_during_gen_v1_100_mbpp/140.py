def a(list_of_lists):
    """
    Flattens a list of lists into a single set of numbers.

    Args:
        list_of_lists: A list of lists, where each inner list contains numbers.

    Returns:
        A set containing all unique numbers from the input lists.
    """
    flattened_set = set()
    for inner_list in list_of_lists:
        for number in inner_list:
            flattened_set.add(number)
    return flattened_set
