def extended_gcd_solver(a, b, n):
    """
    Finds integers x and y that satisfy the equation ax + by = n.
    This function uses the Extended Euclidean Algorithm to find a particular
    solution (x_prime, y_prime) for ax_prime + by_prime = gcd(a, b).
    If n is a multiple of gcd(a, b), a solution exists and is scaled from
    the particular solution.

    Args:
        a (int): The coefficient of x.
        b (int): The coefficient of y.
        n (int): The target value.

    Returns:
        tuple[int, int] or None: A tuple (x, y) representing a solution
                                 if one exists, otherwise None.
    """

    # Helper function: Extended Euclidean Algorithm
    # Returns (g, x, y) such that g = gcd(a, b) and a*x + b*y = g
    def egcd(a, b):
        if b == 0:
            # Base case: gcd(a, 0) = a.
            # a*1 + 0*0 = a, so x=1, y=0.
            return (a, 1, 0)
        else:
            # Recursive step:
            # Call egcd for (b, a % b). Let it return (g, x1, y1)
            # such that b*x1 + (a % b)*y1 = g
            # We know a % b = a - (a // b) * b
            # Substitute: b*x1 + (a - (a // b)*b)*y1 = g
            # Rearrange: a*y1 + b*(x1 - (a // b)*y1) = g
            # So, for a*x + b*y = g, we have:
            # x = y1
            # y = x1 - (a // b)*y1
            g, x1, y1 = egcd(b, a % b)
            return (g, y1, x1 - (a // b) * y1)

    # Handle the special case where both a and b are zero
    if a == 0 and b == 0:
        if n == 0:
            # 0*x + 0*y = 0. Any (x, y) is a solution; (0, 0) is a simple one.
            return (0, 0)
        else:
            # 0*x + 0*y = n (where n != 0) has no solution.
            return None

    # Calculate gcd(a, b) and a particular solution (x_prime, y_prime)
    # for a*x_prime + b*y_prime = gcd(a, b)
    g, x_prime, y_prime = egcd(a, b)

    # Check if n is divisible by gcd(a, b)
    # If not, no integer solution exists for ax + by = n.
    if n % g != 0:
        return None

    # If n is divisible by g, scale the particular solution to find (x, y)
    # such that ax + by = n.
    # We have a*x_prime + b*y_prime = g
    # Multiply by (n / g):
    # a*(x_prime * (n / g)) + b*(y_prime * (n / g)) = g * (n / g) = n
    # So, x = x_prime * (n / g) and y = y_prime * (n / g)
    factor = n // g
    x = x_prime * factor
    y = y_prime * factor

    return (x, y)