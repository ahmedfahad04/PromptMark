def a(dictionary):
    """
    Checks if all values in a dictionary are the same.

    Args:
        dictionary (dict): The input dictionary.

    Returns:
        bool: True if all values are the same (or if the dictionary is empty), 
              False otherwise.
    """
    if not dictionary or len(dictionary) <= 1:
        return True
    values = dictionary.values()
    unique_values = set(values)
    return len(unique_values) == 1
