def a(input_list):
    """
  Interchanges the first and last elements of a list.

  Args:
    input_list: The list whose first and last elements are to be interchanged.

  Returns:
    The list with the first and last elements interchanged.
    Returns the original list unchanged if it has less than 2 elements.
  """
    if len(input_list) < 2:
        return input_list
    input_list[0], input_list[-1] = (input_list[-1], input_list[0])
    return input_list
