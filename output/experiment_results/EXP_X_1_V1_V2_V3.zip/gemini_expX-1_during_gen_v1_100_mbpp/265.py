def split_list_every_n(input_list: list, n: int) -> list[list]:
    """
    Splits a list into sublists, where each sublist contains up to 'n' elements.

    Args:
        input_list: The original list to be split.
        n: The maximum number of elements in each sublist. Must be a positive integer.

    Returns:
        A list of lists, where each inner list is a segment of the original list
        of length at most 'n'.

    Raises:
        ValueError: If 'n' is not a positive integer.

    Examples:
        >>> split_list_every_n([1, 2, 3, 4, 5, 6, 7, 8], 3)
        [[1, 2, 3], [4, 5, 6], [7, 8]]

        >>> split_list_every_n(['a', 'b', 'c', 'd', 'e'], 2)
        [['a', 'b'], ['c', 'd'], ['e']]

        >>> split_list_every_n([10, 20, 30], 1)
        [[10], [20], [30]]

        >>> split_list_every_n([1, 2, 3], 5)
        [[1, 2, 3]]

        >>> split_list_every_n([], 3)
        []
    """
    if not isinstance(n, int) or n <= 0:
        raise ValueError('n must be a positive integer.')
    if not input_list:
        return []
    result = []
    for i in range(0, len(input_list), n):
        sublist = input_list[i:i + n]
        result.append(sublist)
    return result
