def reverse_each_string_in_list(string_list):
    """
    Reverses each string in a given list of string values.

    Args:
        string_list: A list of string values.

    Returns:
        A new list where each string from the input list is reversed.
    """
    reversed_strings = []
    for s in string_list:
        reversed_strings.append(s[::-1])
    return reversed_strings
