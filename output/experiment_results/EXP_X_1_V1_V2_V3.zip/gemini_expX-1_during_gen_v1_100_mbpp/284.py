def a(input_list, element):
    """
  Checks if all items in the given list are equal to the specified element.

  Args:
    input_list: The list to check.
    element: The element to compare against each item in the list.

  Returns:
    True if all items in the list are equal to the element, False otherwise.
    Returns True for an empty list.
  """
    return all((item == element for item in input_list))
