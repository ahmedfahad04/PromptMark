def a(s: str) -> str:
    """
    Inserts spaces between words in a string where a new word starts with a capital letter.

    This function handles common camelCase and PascalCase conversions, as well as
    inserting spaces before words that start with a capital letter following
    an acronym or a lowercase word.

    Examples:
    - "HelloWorld" -> "Hello World"
    - "HTTPClient" -> "HTTP Client"
    - "USAMyCountry" -> "USA My Country"
    - "myFunctionName" -> "my Function Name"

    Args:
        s: The input string.

    Returns:
        The string with spaces inserted between words starting with capital letters.
    """
    if not s:
        return ''
    result_chars = []
    for i, char in enumerate(s):
        if i > 0 and char.isupper():
            prev_char = s[i - 1]
            if prev_char.islower():
                result_chars.append(' ')
            elif prev_char.isupper() and i + 1 < len(s) and s[i + 1].islower():
                result_chars.append(' ')
        result_chars.append(char)
    return ''.join(result_chars)
