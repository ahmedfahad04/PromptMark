def a(list_a, list_b):
    """
    Takes two lists of numbers of the same length and returns a new list
    where each element is the sum of the corresponding elements from the input lists.

    Args:
        list_a (list): The first list of numbers.
        list_b (list): The second list of numbers.

    Returns:
        list: A new list containing the sum of corresponding elements from list_a and list_b.
    """
    return [x + y for x, y in zip(list_a, list_b)]
