def trim_tuples(tuples_list, k):
    """
    Trims each tuple by k elements from the end.
    
    :param tuples_list: List of tuples to be trimmed
    :param k: Number of elements to trim from each tuple
    :return: A new list with trimmed tuples
    """
    return [t[:-k] if len(t) > k else () for t in tuples_list]
