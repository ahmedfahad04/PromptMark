arr = [1, 2, 4, 4, 5, 6]
target = 4