def calculate_pentagon_perimeter(side_length):
    """
    Calculate the perimeter of a regular pentagon given the length of one side.
    
    Parameters:
    side_length (float): The length of one side of the pentagon.
    
    Returns:
    float: The perimeter of the pentagon.
    """
    perimeter = 5 * side_length
    return perimeter
