def find_common_first_element(lst):
    if not lst:
        return None
    first_elements = [t[0] for t in lst]
    common_element = None
    for element in set(first_elements):
        if first_elements.count(element) == len(lst):
            common_element = element
            break
    return common_element
