def longest_sublist_length(lst):
    """
    Finds the length of the longest sublist in the given list.

    Parameters:
    lst (list): A list of lists.

    Returns:
    int: The length of the longest sublist.
    """
    if not lst:
        return 0
    max_length = 0
    for sublist in lst:
        if len(sublist) > max_length:
            max_length = len(sublist)
    return max_length
