def find_directrix(a):
    """
    Find the directrix of a parabola given its coefficient 'a' in the equation x^2 = 4*a*y.
    
    Parameters:
    a (float): The coefficient 'a' in the parabola equation.
    
    Returns:
    float: The y-coordinate of the directrix.
    """
    directrix_y = -a
    return directrix_y
