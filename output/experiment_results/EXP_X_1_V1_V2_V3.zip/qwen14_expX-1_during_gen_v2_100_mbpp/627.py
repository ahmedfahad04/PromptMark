def find_smallest_missing(numbers):
    """
    Finds the smallest missing number in a sorted list of natural numbers.
    
    Args:
    numbers (list): A sorted list of natural numbers.
    
    Returns:
    int: The smallest missing number in the list.
    """
    if not numbers:
        return 1
    start, end = (0, len(numbers) - 1)
    while start <= end:
        mid = (start + end) // 2
        if numbers[mid] - mid > 1:
            end = mid - 1
        else:
            start = mid + 1
    return start + 1
