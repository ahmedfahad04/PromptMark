def area_of_sector(radius, angle):
    """
    Calculate the area of a sector given its radius and angle.
    
    Args:
    radius (float): The radius of the circle.
    angle (float): The central angle of the sector in degrees.
    
    Returns:
    float or None: The area of the sector if the angle is <= 360 degrees, otherwise None.
    """
    if angle > 360:
        return None
    else:
        angle_in_radians = math.radians(angle)
        area = angle_in_radians / (2 * math.pi) * math.pi * radius ** 2
        return area
