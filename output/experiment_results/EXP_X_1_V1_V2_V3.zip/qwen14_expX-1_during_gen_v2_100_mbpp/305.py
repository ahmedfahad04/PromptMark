def find_words_starting_with_p(words):
    p_words = [word for word in words if word.startswith('p')]
    return p_words[:2]
