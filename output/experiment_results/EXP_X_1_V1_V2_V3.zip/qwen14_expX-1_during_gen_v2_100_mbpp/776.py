def count_vowel_neighbors(s):
    """
    Counts characters that have vowels as their neighbors in the given string.
    
    :param s: Input string
    :return: Count of characters with vowel neighbors
    """
    vowels = 'aeiouAEIOU'
    count = 0
    for i in range(1, len(s) - 1):
        if s[i - 1] in vowels or s[i + 1] in vowels:
            count += 1
    if len(s) > 0 and s[0] in vowels:
        count += 1
    if len(s) > 1 and s[-1] in vowels:
        count += 1
    return count
