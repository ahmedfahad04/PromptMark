def max_product_increasing_subsequence(arr):
    if not arr:
        return 0
    n = len(arr)
    max_ending_here = [1] * n
    min_ending_here = [1] * n
    max_so_far = float('-inf')
    for i in range(1, n):
        if arr[i] > arr[i - 1]:
            max_ending_here[i] = max_ending_here[i - 1] * arr[i]
            min_ending_here[i] = min_ending_here[i - 1] * arr[i]
        elif arr[i] < arr[i - 1]:
            max_ending_here[i] = min_ending_here[i - 1] * arr[i]
            min_ending_here[i] = max_ending_here[i - 1] * arr[i]
        else:
            max_ending_here[i] = arr[i]
            min_ending_here[i] = arr[i]
        max_so_far = max(max_so_far, max_ending_here[i])
    return max_so_far
