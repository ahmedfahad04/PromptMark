def match_word_with_z(word):
    pattern = '\\bz\\b'
    return bool(re.search(pattern, word))
