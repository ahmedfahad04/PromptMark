def find_common_elements(nested_lists):
    """
    Finds and returns a list of common elements present in all nested lists.
    
    :param nested_lists: List of lists containing elements
    :return: List of common elements
    """
    if not nested_lists:
        return []
    from collections import Counter
    flat_list = [item for sublist in nested_lists for item in sublist]
    element_counts = Counter(flat_list)
    common_elements = [element for element, count in element_counts.items() if count == len(nested_lists)]
    return common_elements
