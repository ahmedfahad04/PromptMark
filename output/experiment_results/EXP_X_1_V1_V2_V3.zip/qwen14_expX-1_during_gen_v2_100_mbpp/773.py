def find_substring_occurrences(main_string, substring):
    """
    Finds all occurrences and their positions of a substring within a main string.
    
    Parameters:
    main_string (str): The string to search within.
    substring (str): The substring to find.
    
    Returns:
    list or None: A list of tuples (start_position, end_position) for each occurrence of the substring,
                  or None if no matches are found.
    """
    if not main_string or not substring:
        return None
    positions = []
    start = 0
    while True:
        start = main_string.find(substring, start)
        if start == -1:
            break
        positions.append((start, start + len(substring)))
        start += 1
    return positions if positions else None
