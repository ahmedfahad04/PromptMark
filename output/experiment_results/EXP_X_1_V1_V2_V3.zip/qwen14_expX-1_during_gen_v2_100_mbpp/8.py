def square_elements(input_list):
    """
    This function takes a list of numbers and returns a new list containing the squares of the original elements.
    
    :param input_list: List of numbers
    :return: List of squared numbers
    """
    return [x ** 2 for x in input_list]
