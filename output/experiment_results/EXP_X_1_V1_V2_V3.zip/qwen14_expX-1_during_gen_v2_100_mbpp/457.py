def find_min_length_sublist(lst):
    """
    Finds and returns the sublist with the minimum length from the given list of sublists.
    
    Parameters:
    lst (list): A list containing multiple sublists.
    
    Returns:
    list: The sublist with the minimum length. If there are multiple sublists with the same minimum length,
          the first one encountered is returned.
    """
    if not lst:
        return []
    min_length = float('inf')
    min_sublist = None
    for sublist in lst:
        if len(sublist) < min_length:
            min_length = len(sublist)
            min_sublist = sublist
    return min_sublist
