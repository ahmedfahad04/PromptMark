def multiply_and_divide(lst):
    if not lst:
        return 0
    product = 1
    for num in lst:
        product *= num
    result = product / len(lst)
    return result
