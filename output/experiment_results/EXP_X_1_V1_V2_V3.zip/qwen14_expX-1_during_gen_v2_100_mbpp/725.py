def extract_quoted_values(input_string):
    """
    Extracts and returns all values enclosed in double quotes from the input string.
    
    Args:
    input_string (str): The string to extract quoted values from.
    
    Returns:
    list: A list of strings containing the values extracted from the input string.
    """
    matches = re.findall('"(.*?)"', input_string)
    return matches
