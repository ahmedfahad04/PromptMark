def reverse_strings(string_list):
    """
    Reverses each string in the given list.
    
    :param string_list: List of strings to be reversed
    :return: List of reversed strings
    """
    return [s[::-1] for s in string_list]
