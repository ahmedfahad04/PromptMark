def string_to_tuple(input_string: str) -> tuple:
    return tuple(input_string)
