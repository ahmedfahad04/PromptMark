def average_of_cubes(n):
    """
    Calculate the average of cubes of first n natural numbers.
    
    :param n: int - the number of natural numbers to consider
    :return: float - the average of cubes of first n natural numbers
    """
    sum_of_cubes = sum((i ** 3 for i in range(1, n + 1)))
    average = sum_of_cubes / n
    return average
