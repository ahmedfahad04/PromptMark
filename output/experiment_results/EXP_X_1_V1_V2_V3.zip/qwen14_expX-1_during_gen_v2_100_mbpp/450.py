def extract_strings_by_size(strings_list, size):
    """
    Extracts and returns a list of strings from the input list that have the specified size.
    
    :param strings_list: List of string values.
    :param size: The exact size of strings to be extracted.
    :return: A list of strings with the specified size.
    """
    return [s for s in strings_list if len(s) == size]
