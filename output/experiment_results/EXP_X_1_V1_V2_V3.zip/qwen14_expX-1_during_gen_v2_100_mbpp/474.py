def replace_characters(input_string):
    """
    Replaces all occurrences of 'a' with '*' in the input string.
    
    Parameters:
    input_string (str): The string to be processed.
    
    Returns:
    str: The modified string with 'a' replaced by '*'.
    """
    return input_string.replace('a', '*')
