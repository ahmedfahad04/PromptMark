def find_solution(a, b, n):
    def extended_gcd(a, b):
        if a == 0:
            return b, 0, 1
        gcd, x1, y1 = extended_gcd(b % a, a)
        x = y1 - (b // a) * x1
        y = x1
        return gcd, x, y
    
    gcd, x, y = extended_gcd(a, b)
    
    # Check if n is divisible by the gcd of a and b
    if n % gcd != 0:
        return None
    
    # Scale the solution up by n / gcd
    x *= n // gcd
    y *= n // gcd
    
    return (x, y)