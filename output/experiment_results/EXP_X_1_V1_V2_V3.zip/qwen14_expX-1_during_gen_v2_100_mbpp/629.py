def find_even_numbers(numbers):
    """
    This function takes a list of numbers and returns a new list containing only the even numbers.
    
    :param numbers: List of integers
    :return: List of even integers
    """
    even_numbers = [num for num in numbers if num % 2 == 0]
    return even_numbers
