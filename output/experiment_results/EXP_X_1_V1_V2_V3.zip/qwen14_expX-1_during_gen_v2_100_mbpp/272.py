def get_rear_elements(tuples_list):
    """
    This function takes a list of tuples and returns a list of the last element from each tuple.
    
    :param tuples_list: List of tuples
    :return: List of the last elements from each tuple
    """
    return [t[-1] for t in tuples_list]
