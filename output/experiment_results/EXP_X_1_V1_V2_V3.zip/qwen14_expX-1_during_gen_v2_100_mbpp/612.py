def separate_elements(pairs):
    """
    Takes a list of pairs (sublists with two elements) and separates them into two lists.
    
    :param pairs: List of lists, where each sublist contains two elements.
    :return: A list containing two lists, first with all the first elements and second with all the second elements.
    """
    first_elements = [pair[0] for pair in pairs]
    second_elements = [pair[1] for pair in pairs]
    return [first_elements, second_elements]
