def interleave_lists(list1, list2, list3):
    """
    Interleaves three lists of the same length into a single flat list.
    
    Parameters:
    - list1: First input list.
    - list2: Second input list.
    - list3: Third input list.
    
    Returns:
    A single flat list containing elements from list1, list2, and list3 interleaved.
    """
    result = []
    for i in range(len(list1)):
        result.append(list1[i])
        result.append(list2[i])
        result.append(list3[i])
    return result
