def find_frequency(flattened_list):
    freq_dict = Counter(flattened_list)
    return freq_dict
