def split_list_every_n(lst, n):
    return [lst[i::n] for i in range(n)]
