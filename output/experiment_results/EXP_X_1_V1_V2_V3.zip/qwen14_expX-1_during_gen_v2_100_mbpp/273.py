def subtract_tuples(t1, t2):
    """
    Subtract the elements of the second tuple from the first tuple element-wise.
    
    Args:
    t1 (tuple): The minuend tuple.
    t2 (tuple): The subtrahend tuple.
    
    Returns:
    tuple: A new tuple containing the results of the subtraction.
    """
    return tuple((x - y for x, y in zip(t1, t2)))
