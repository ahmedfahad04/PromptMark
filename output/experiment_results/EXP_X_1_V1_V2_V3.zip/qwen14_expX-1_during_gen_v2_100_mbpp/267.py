def sum_of_squares_of_odds(n):
    """
    This function takes an integer n and returns the sum of the squares of the first n odd natural numbers.
    
    :param n: int - the number of initial odd natural numbers to consider
    :return: int - the sum of the squares of the first n odd natural numbers
    """
    return sum(((2 * i + 1) ** 2 for i in range(n)))
