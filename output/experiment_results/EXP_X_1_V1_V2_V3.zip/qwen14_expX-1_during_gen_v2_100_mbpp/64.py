def sort_tuples_by_second_value(tuples_list):
    """
    Sorts a list of tuples based on the second value of each tuple.

    Args:
    tuples_list (list): A list of tuples to be sorted.

    Returns:
    list: The sorted list of tuples.
    """
    return sorted(tuples_list, key=lambda x: x[1])
