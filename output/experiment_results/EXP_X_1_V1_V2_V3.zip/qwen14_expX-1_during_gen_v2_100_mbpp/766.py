def consecutive_pairs(items):
    """
    Returns a list of tuples containing pairs of consecutive items from the input list.
    
    :param items: List of items
    :return: List of tuples with consecutive pairs
    """
    return [(items[i], items[i + 1]) for i in range(len(items) - 1)]
