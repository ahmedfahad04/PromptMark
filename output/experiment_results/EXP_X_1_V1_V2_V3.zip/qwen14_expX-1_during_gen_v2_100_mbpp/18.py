def remove_chars_from_first(first_string, second_string):
    """
    Removes characters from first_string that are present in second_string.

    Args:
    first_string (str): The original string from which characters will be removed.
    second_string (str): The string containing characters to remove from first_string.

    Returns:
    str: The modified version of first_string with characters removed.
    """
    return ''.join([char for char in first_string if char not in second_string])
