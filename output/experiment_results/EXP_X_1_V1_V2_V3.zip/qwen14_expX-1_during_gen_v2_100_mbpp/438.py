def count_bidirectional_pairs(pairs):
    """
    Count the number of unique bidirectional tuple pairs.
    
    Args:
    pairs (list): A list of tuples representing pairs.
    
    Returns:
    int: The count of unique bidirectional pairs.
    """
    unique_pairs = set()
    for pair in pairs:
        unique_pairs.add(pair)
        unique_pairs.add(pair[::-1])
    return len(unique_pairs)
