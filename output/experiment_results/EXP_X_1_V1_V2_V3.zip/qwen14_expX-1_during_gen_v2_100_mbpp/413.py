def extract_nth_element(lst_of_tuples, n):
    """
    Extracts the nth element from each tuple in the given list of tuples.
    
    Parameters:
    lst_of_tuples (list): A list of tuples.
    n (int): The index of the element to extract from each tuple.
    
    Returns:
    list: A list containing the nth element from each tuple.
    """
    return [t[n] for t in lst_of_tuples if len(t) > n]
