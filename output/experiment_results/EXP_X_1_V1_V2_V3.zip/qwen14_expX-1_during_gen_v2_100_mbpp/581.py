def calculate_surface_area(base_edge, height):
    """
    Calculate the surface area of a square pyramid.
    
    Args:
    base_edge (float): The length of one edge of the square base.
    height (float): The height of the pyramid from the base to the apex.
    
    Returns:
    float: The surface area of the square pyramid.
    """
    base_area = base_edge ** 2
    slant_height = math.sqrt((base_edge / 2) ** 2 + height ** 2)
    lateral_area = 4 * (1 / 2) * base_edge * slant_height
    surface_area = base_area + lateral_area
    return surface_area
