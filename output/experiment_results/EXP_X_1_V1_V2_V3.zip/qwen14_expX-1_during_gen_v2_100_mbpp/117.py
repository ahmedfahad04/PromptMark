def convert_to_floats(nested_list):
    """
    Converts all possible convertible elements in a list of lists to floats.

    Args:
    nested_list (list): A list of lists containing elements that can be converted to float.

    Returns:
    list: A list of lists with convertible elements converted to floats.
    """
    result = []
    for sublist in nested_list:
        converted_sublist = []
        for item in sublist:
            try:
                converted_value = float(item)
                converted_sublist.append(converted_value)
            except ValueError:
                converted_sublist.append(item)
        result.append(converted_sublist)
    return result
