def merge_dictionaries(dict1, dict2, dict3):
    """
    Merge three dictionaries into a single dictionary.
    
    Args:
    dict1 (dict): First dictionary.
    dict2 (dict): Second dictionary.
    dict3 (dict): Third dictionary.
    
    Returns:
    dict: Merged dictionary.
    """
    merged_dict = {**dict1, **dict2, **dict3}
    return merged_dict
