def count_substrings_with_digit_sum(s):
    def digit_sum(n):
        return sum(int(digit) for digit in str(n))
    
    count = 0
    n = len(s)
    for i in range(n):
        current_sum = 0
        for j in range(i, n):
            current_sum += int(s[j])
            if current_sum == (j - i + 1):
                count += 1
    return count