def largest_divisible_subset(nums):
    """
    Finds the size of the largest subset of nums where every pair (Si, Sj) satisfies Si % Sj == 0 or Sj % Si == 0.
    
    :param nums: List[int] - A list of unique positive integers.
    :return: int - The size of the largest divisible subset.
    """
    if not nums:
        return 0
    nums.sort()
    n = len(nums)
    dp = [1] * n
    max_size = 1
    for i in range(1, n):
        for j in range(i):
            if nums[i] % nums[j] == 0:
                dp[i] = max(dp[i], dp[j] + 1)
        max_size = max(max_size, dp[i])
    return max_size
