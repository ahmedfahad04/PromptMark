def count_matching_indices(list1, list2):
    """
    Counts the number of indices where the elements in the two lists are the same.

    Parameters:
    - list1: First list of elements.
    - list2: Second list of elements.

    Returns:
    - count: Number of indices with matching elements.
    """
    if len(list1) != len(list2):
        raise ValueError('Both lists must be of the same length')
    count = sum((1 for x, y in zip(list1, list2) if x == y))
    return count
