def sort_list(elements):
    return sorted(elements)
