def remove_lowercase_substrings(input_string):
    result = ''
    i = 0
    while i < len(input_string):
        if not input_string[i].islower():
            result += input_string[i]
        else:
            j = i + 1
            while j < len(input_string) and input_string[j].islower():
                j += 1
            i = j
        i += 1
    return result
