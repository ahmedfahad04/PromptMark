binary1 = "101010"
binary2 = "010101"