def rotate_array(arr, d, index):
    """
    Rotate the array 'arr' by 'd' elements and return the element at 'index'.

    Parameters:
    arr (list): The input list.
    d (int): Number of rotations.
    index (int): The index of the element to be returned after rotation.

    Returns:
    int: Element at the specified index after rotation.
    """
    n = len(arr)
    d = d % n
    rotated_arr = arr[d:] + arr[:d]
    return rotated_arr[index]
