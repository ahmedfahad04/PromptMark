def remove_tuples(input_tuple):
    """
    Remove tuples from the given tuple and return an empty tuple.
    
    Args:
    input_tuple (tuple): The input tuple containing any elements including other tuples.
    
    Returns:
    tuple: An empty tuple after removing all tuples.
    """
    result = ()
    for elem in input_tuple:
        if not isinstance(elem, tuple):
            result += (elem,)
    return result
