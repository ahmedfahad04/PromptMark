def add_spaces(string):
    return ' '.join((word for word in string if word.isupper() or word.islower()))
