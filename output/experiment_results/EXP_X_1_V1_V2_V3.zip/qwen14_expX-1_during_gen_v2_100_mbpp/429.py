def extract_elements(tup1, tup2):
    elementwise = [x + y for x, y in zip(tup1, tup2)]
    tuples_extracted = (tup1, tup2)
    return (elementwise, tuples_extracted)
