def check_all_equal(lst, element):
    return all((item == element for item in lst))
