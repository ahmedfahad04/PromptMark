def create_new_tuple(input_string, input_list):
    new_tuple = (input_string,) + tuple(input_list)
    return new_tuple
