def find_quotient(dividend: int, divisor: int) -> int:
    """
    Finds the quotient of two numbers (dividend and divisor) rounded down to the nearest integer.

    Args:
    dividend (int): The number to be divided.
    divisor (int): The number by which to divide.

    Returns:
    int: The quotient rounded down to the nearest integer.
    """
    return dividend // divisor
