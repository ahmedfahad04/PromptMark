def sum_of_range(numbers, start_index, end_index):
    """
    Calculate the sum of elements in the list 'numbers' from index 'start_index' to 'end_index' (inclusive).
    
    :param numbers: List of integers.
    :param start_index: Starting index of the range.
    :param end_index: Ending index of the range.
    :return: Sum of elements in the specified range.
    """
    return sum(numbers[start_index:end_index + 1])
