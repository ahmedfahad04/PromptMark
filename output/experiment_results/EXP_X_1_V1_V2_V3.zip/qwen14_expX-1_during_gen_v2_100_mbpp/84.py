def newman_conway(n):
    if n <= 0:
        return None
    elif n == 1 or n == 2:
        return 1
    sequence = [0, 1, 1]
    for i in range(3, n + 1):
        next_value = sequence[sequence[i - 1]] + sequence[i - sequence[i - 1]]
        sequence.append(next_value)
    return sequence[n]
