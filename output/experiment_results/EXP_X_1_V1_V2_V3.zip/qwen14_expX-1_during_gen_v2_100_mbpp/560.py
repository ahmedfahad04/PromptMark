def find_union_sorted(tup1, tup2):
    combined = set(tup1) | set(tup2)
    result = tuple(sorted(combined))
    return result
