def remove_whitespaces(input_string):
    """
    Removes all whitespaces from the given string.

    Args:
    input_string (str): The string from which whitespaces need to be removed.

    Returns:
    str: A new string with all whitespaces removed.
    """
    return input_string.replace(' ', '')
