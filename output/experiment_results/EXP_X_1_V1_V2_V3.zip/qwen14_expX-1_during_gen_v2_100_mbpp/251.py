def insert_before_each(lst, element):
    return [element] + lst if not lst else [element] + [element] + insert_before_each(lst[1:], element)
