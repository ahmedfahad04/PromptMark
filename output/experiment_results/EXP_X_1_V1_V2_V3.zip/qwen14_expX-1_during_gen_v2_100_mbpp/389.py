def find_nth_lucas_number(n):
    """
    Find the n'th Lucas number.
    
    Args:
    n (int): The position in the Lucas sequence.
    
    Returns:
    int: The n'th Lucas number.
    """
    if n == 0:
        return 2
    elif n == 1:
        return 1
    a, b = (2, 1)
    for _ in range(2, n + 1):
        a, b = (b, a + b)
    return b
