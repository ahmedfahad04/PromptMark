def count_occurrences(tup, elem):
    return tup.count(elem)
