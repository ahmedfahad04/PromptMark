def find_median_length(a, b):
    """
    Calculate the median length of a trapezium given its two parallel sides (bases).

    Parameters:
    a (float): Length of one base.
    b (float): Length of the other base.

    Returns:
    float: The median length of the trapezium.
    """
    median_length = (a + b) / 2
    return median_length
