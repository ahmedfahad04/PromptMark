def sum_of_even_fifth_powers(n):
    """
    This function calculates the sum of the first n even natural numbers raised to the fifth power.
    
    :param n: int - the number of initial even natural numbers to consider
    :return: int - the sum of the specified even numbers raised to the fifth power
    """
    total_sum = 0
    current_even_number = 2
    for _ in range(n):
        total_sum += current_even_number ** 5
        current_even_number += 2
    return total_sum
