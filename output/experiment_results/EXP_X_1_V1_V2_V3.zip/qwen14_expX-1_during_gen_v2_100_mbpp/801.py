def count_equal_numbers(a: int, b: int, c: int) -> int:
    """
    Counts the number of equal integers among three given integers.

    Parameters:
    a (int): The first integer.
    b (int): The second integer.
    c (int): The third integer.

    Returns:
    int: The count of equal integers among the three.
    """
    counts = [0, 0, 0]
    counts[a] += 1
    counts[b] += 1
    counts[c] += 1
    return max(counts.count(2), counts.count(3))
