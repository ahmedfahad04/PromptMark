def find_first_adverb(text):
    pattern = '\\b\\w+ly\\b'
    match = re.search(pattern, text)
    if match:
        return (match.group(), [match.start()])
    else:
        return (None, [])
