def calculate_loss(sale_amount, cost_amount):
    """
    Calculate the loss amount on a sale.
    
    Args:
    sale_amount (float): The amount at which the item was sold.
    cost_amount (float): The cost price of the item.
    
    Returns:
    float: The loss amount if there is a loss, otherwise returns 0.
    """
    if sale_amount < cost_amount:
        return cost_amount - sale_amount
    else:
        return 0
