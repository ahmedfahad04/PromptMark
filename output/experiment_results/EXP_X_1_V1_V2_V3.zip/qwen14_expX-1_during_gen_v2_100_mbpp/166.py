def count_even_xor_pairs(arr):
    """
    Counts the number of pairs (i, j) in the array such that arr[i] ^ arr[j] is even.
    
    :param arr: List of integers
    :return: Number of pairs with even XOR result
    """
    even_count = 0
    odd_count = 0
    for num in arr:
        if num % 2 == 0:
            even_count += 1
        else:
            odd_count += 1
    return even_count * (even_count - 1) // 2 + odd_count * (odd_count - 1) // 2
