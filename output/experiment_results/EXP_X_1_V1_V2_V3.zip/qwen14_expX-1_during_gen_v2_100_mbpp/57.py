def largest_number(digits):
    """
    Finds the largest number that can be formed with the given list of digits.
    
    :param digits: List[int] - a list of non-negative integers (digits)
    :return: int - the largest number that can be formed
    """
    str_digits = [str(digit) for digit in digits]
    str_digits.sort(key=lambda x: x * 10, reverse=True)
    largest_num = int(''.join(str_digits))
    return largest_num
