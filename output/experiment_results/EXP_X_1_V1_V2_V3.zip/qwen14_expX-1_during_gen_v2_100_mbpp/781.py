def is_divisor_count_even(n):
    """
    Check if the number of divisors of n is even.

    Args:
    n (int): The number to check.

    Returns:
    bool: True if the number of divisors is even, False otherwise.
    """
    count = 0
    for i in range(1, int(n ** 0.5) + 1):
        if n % i == 0:
            if n // i == i:
                count += 1
            else:
                count += 2
    return count % 2 == 0
