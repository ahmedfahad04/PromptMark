def all_values_same(dictionary):
    """
    Check if all values in the given dictionary are the same.

    Args:
    dictionary (dict): The dictionary to check.

    Returns:
    bool: True if all values are the same, False otherwise.
    """
    value_set = set(dictionary.values())
    return len(value_set) == 1
