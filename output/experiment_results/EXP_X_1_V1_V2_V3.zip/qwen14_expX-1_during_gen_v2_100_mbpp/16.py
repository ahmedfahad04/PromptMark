def check_lowercase_sequence(input_string):
    pattern = '^[a-z]+_[a-z]+$'
    if re.search(pattern, input_string):
        return True
    else:
        return False
