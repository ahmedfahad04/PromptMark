test_list = [1, 2, 3, 4, 5]
rotation_amount = 2
rotated_list = right_rotate_list(test_list, rotation_amount)