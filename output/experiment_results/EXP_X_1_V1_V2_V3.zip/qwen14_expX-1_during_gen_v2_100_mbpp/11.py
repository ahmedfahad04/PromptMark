def remove_first_last_occurrence(char, input_string):
    """
    Removes the first and last occurrence of a given character from the string.
    
    :param char: The character to be removed.
    :param input_string: The original string.
    :return: A new string with the first and last occurrences of the character removed.
    """
    if not input_string:
        return ''
    try:
        start_index = input_string.index(char)
        end_index = input_string.rindex(char)
    except ValueError:
        return input_string
    if start_index == end_index:
        return input_string[:start_index] + input_string[start_index + 1:]
    elif start_index == 0:
        return input_string[end_index + 1:]
    elif end_index == len(input_string) - 1:
        return input_string[:end_index]
    else:
        return input_string[:start_index] + input_string[start_index + 1:end_index] + input_string[end_index + 1:]
