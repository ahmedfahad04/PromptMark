def tuple_intersection(tuples_list):
    """
    Find the intersection of tuples in the given list irrespective of their order.
    
    Args:
    tuples_list (list): A list of tuples.
    
    Returns:
    set: A set containing the intersecting elements across all tuples.
    """
    if not tuples_list:
        return set()
    sorted_tuples = [sorted(set(t)) for t in tuples_list]
    intersection_set = set.intersection(*map(set, sorted_tuples))
    return intersection_set
