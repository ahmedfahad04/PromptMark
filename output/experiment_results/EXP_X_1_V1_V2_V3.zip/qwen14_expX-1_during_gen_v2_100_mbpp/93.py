def power(a, b):
    """
    Calculate the value of 'a' to the power 'b'.
    
    Args:
    a (int or float): The base number.
    b (int): The exponent.
    
    Returns:
    int or float: The result of raising 'a' to the power 'b'.
    """
    return a ** b
