def average_of_tuples(tuples):
    averages = []
    for tup in tuples:
        avg = sum(tup) / len(tup)
        averages.append(avg)
    return averages
