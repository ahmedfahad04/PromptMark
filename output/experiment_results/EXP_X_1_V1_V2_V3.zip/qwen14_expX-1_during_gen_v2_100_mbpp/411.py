def convert_snake_to_camel(snake_str):
    """
    Convert a snake_case string to CamelCase string.
    
    Parameters:
    snake_str (str): The snake_case string to be converted.
    
    Returns:
    str: The converted CamelCase string.
    """
    return ''.join((word.capitalize() or '_' for word in snake_str.split('_')))
