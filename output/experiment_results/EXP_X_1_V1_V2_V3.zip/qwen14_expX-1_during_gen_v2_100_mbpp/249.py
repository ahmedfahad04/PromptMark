def find_intersection(arr1, arr2):
    """
    Finds the intersection of two arrays.
    
    Parameters:
    arr1 (list): The first array.
    arr2 (list): The second array.
    
    Returns:
    list: A list containing the intersection of the two arrays.
    """
    intersection = set(arr1) & set(arr2)
    return list(intersection)
