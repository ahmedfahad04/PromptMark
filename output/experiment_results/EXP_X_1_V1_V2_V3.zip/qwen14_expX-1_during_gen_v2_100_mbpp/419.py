def rounded_sum_multiplied(numbers):
    import math
    rounded_numbers = [round(num) for num in numbers]
    total_sum = sum(rounded_numbers)
    result = total_sum * len(numbers)
    return result
