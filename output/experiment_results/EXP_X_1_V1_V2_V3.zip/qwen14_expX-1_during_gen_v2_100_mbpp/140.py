def flatten_list_of_lists(lst):
    """
    Flattens a list of lists into a single set of numbers.
    
    Args:
    lst (list): A list of lists containing numbers.
    
    Returns:
    set: A set containing all the numbers from the nested lists.
    """
    return set((num for sublist in lst for num in sublist))
