def sum_of_fourth_powers(n):
    """
    This function calculates the sum of the fourth powers of the first n odd natural numbers.
    
    :param n: int - the number of initial odd natural numbers to consider
    :return: int - the sum of the fourth powers of the first n odd natural numbers
    """
    total_sum = 0
    for i in range(1, 2 * n, 2):
        total_sum += i ** 4
    return total_sum
