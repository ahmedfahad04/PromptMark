def remove_duplicates(*lists):
    """
    Remove duplicate numbers from multiple input lists.
    
    Args:
    *lists: Variable number of list arguments containing integers.
    
    Returns:
    A list of lists with duplicates removed from each input list.
    """
    result = []
    for lst in lists:
        unique_lst = list(set(lst))
        result.append(unique_lst)
    return result
