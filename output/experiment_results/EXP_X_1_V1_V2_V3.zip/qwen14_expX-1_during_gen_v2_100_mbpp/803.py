import math

def is_perfect_square(num):
    """
    Check if the given number is a perfect square.

    Args:
    num (int): The number to check.

    Returns:
    bool: True if num is a perfect square, False otherwise.
    """
    if num < 0:
        return False
    root = math.isqrt(num)
    return root * root == num

# Test the function with some test cases
test_cases = [1, 4, -1, 0, 25, 26]
for num in test_cases: