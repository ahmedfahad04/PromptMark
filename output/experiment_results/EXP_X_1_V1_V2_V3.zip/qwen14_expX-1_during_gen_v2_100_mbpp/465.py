def drop_empty_items(input_dict):
    """
    Drop empty items from the given dictionary.

    Args:
    input_dict (dict): The dictionary from which to remove empty items.

    Returns:
    dict: A new dictionary with no empty values.
    """
    return {key: value for key, value in input_dict.items() if value}
