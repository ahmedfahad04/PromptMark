def remove_first_last_occurrence(char, input_string):
    """
    Removes the first and last occurrences of a given character from the string.
    
    :param char: The character to be removed.
    :param input_string: The original string.
    :return: A new string with the first and last occurrences of 'char' removed.
    """
    if not input_string or char not in input_string:
        return input_string
    first_index = input_string.find(char)
    last_index = input_string.rfind(char)
    if first_index == -1 or last_index == -1:
        return input_string
    if first_index == last_index:
        return input_string[:first_index] + input_string[first_index + 1:]
    new_string = input_string[:first_index] + input_string[first_index + 1:last_index] + input_string[last_index + 1:]
    return new_string
