def a(main_string: str, substring: str) -> list[tuple[int, int]] | None:
    """
    Finds all non-overlapping occurrences of a substring within a main string
    and returns their occurrence number and starting position.

    This function iterates through the main string to locate every instance
    of the given substring. It keeps track of which occurrence it is (1st, 2nd, etc.)
    and where it starts in the main string. If the substring is found multiple times,
    a list of tuples `(occurrence_number, start_position)` is returned.
    If no matches are found, or if the substring is empty, the function returns None.

    Args:
        main_string (str): The string in which to search for the substring.
        substring (str): The substring to search for.

    Returns:
        list[tuple[int, int]] | None: A list of tuples, where each tuple contains
                                      (occurrence_number, start_position) for each
                                      found non-overlapping match.
                                      Returns None if no matches are found,
                                      or if the `substring` is an empty string,
                                      or if `main_string` is empty.

    Examples:
        >>> a("hello world hello", "hello")
        [(1, 0), (2, 12)]

        >>> a("banana", "na")
        [(1, 2), (2, 4)]

        >>> a("mississippi", "iss")
        [(1, 1), (2, 4)]

        >>> a("aaaaa", "aa") # Finds non-overlapping matches
        [(1, 0), (2, 2)]

        >>> a("Python is fun", "Java")
        None

        >>> a("test", "") # Empty substring
        None

        >>> a("", "test") # Empty main string
        None
    """
    if not substring:
        return None
    if not main_string:
        return None
    results = []
    start_search_index = 0
    occurrence_count = 1
    while True:
        found_position = main_string.find(substring, start_search_index)
        if found_position == -1:
            break
        else:
            results.append((occurrence_count, found_position))
            start_search_index = found_position + len(substring)
            occurrence_count += 1
    if not results:
        return None
    else:
        return results
