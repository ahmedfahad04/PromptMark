def _extended_gcd_recursive(a, b):
    """
    Helper function to compute gcd(a, b) and coefficients x, y such that ax + by = gcd(a, b).
    This is the core Extended Euclidean Algorithm.
    Assumes a, b are non-negative integers.
    
    Args:
        a (int): First non-negative integer.
        b (int): Second non-negative integer.
        
    Returns:
        tuple[int, int, int]: A tuple (g, x, y) where g = gcd(a, b) and 
                              a*x + b*y = g.
    """
    # Base case: If a is 0, gcd(0, b) = b.
    # The equation becomes 0*x + b*y = b. We can choose x=0 and y=1.
    if a == 0:
        return b, 0, 1
    
    # Recursive step: Call the function with (b % a, a)
    # Let g, x1, y1 be the result such that (b % a) * x1 + a * y1 = g
    g, x1, y1 = _extended_gcd_recursive(b % a, a)
    
    # Update x and y using the results from the recursive call
    # We know: b % a = b - (b // a) * a
    # Substitute this into (b % a) * x1 + a * y1 = g:
    # (b - (b // a) * a) * x1 + a * y1 = g
    # b * x1 - (b // a) * a * x1 + a * y1 = g
    # Rearrange to match the form a*x + b*y = g:
    # a * (y1 - (b // a) * x1) + b * x1 = g
    # So, our current x and y are:
    x = y1 - (b // a) * x1
    y = x1
    
    return g, x, y

def extended_gcd_solution(a: int, b: int, n: int) -> tuple[int, int] | None:
    """
    Finds integer solutions x and y for the linear Diophantine equation ax + by = n.
    This function implements the Extended Euclidean Algorithm to solve Bezout's identity
    and then scales the coefficients to match n.

    Args:
        a (int): Coefficient of x.
        b (int): Coefficient of y.
        n (int): The constant term.

    Returns:
        tuple[int, int] | None: A tuple (x, y) if an integer solution exists,
                                otherwise None.
    """
    # Special case: If both a and b are zero
    # The equation becomes 0*x + 0*y = n, which simplifies to 0 = n.
    if a == 0 and b == 0:
        if n == 0:
            return (0, 0)  # Any (x, y) would work, (0, 0) is a simple choice.
        else:
            return None    # If n is not 0, then 0 = n is false, so no solution exists.

    # Calculate the greatest common divisor (g) of |a| and |b|,
    # and initial Bezout coefficients x_prime, y_prime
    # such that abs(a)*x_prime + abs(b)*y_prime = g.
    # We use absolute values because the _extended_gcd_recursive function
    # is designed for non-negative inputs.
    g, x_prime, y_prime = _extended_gcd_recursive(abs(a), abs(b))

    # According to Bezout's identity, a solution to ax + by = n exists
    # if and only if n is divisible by g (the gcd of a and b).
    if n % g != 0:
        return None

    # Scale the Bezout coefficients (x_prime, y_prime) to find a particular
    # solution for ax + by = n.
    # Since abs(a)*x_prime + abs(b)*y_prime = g,
    # multiplying by (n // g) will give:
    # abs(a)*(x_prime * (n // g)) + abs(b)*(y_prime * (n // g)) = n
    k = n // g
    
    # Adjust x_prime and y_prime based on the original signs of a and b.
    # The _extended_gcd_recursive function assumes positive a, b.
    # If the original 'a' was negative, 'x' must have an opposite sign
    # to maintain the correct product a*x relative to abs(a)*x_prime.
    # For example, if a = -6, abs(a) = 6. If 6*x_prime is positive, then -6*(-x_prime) is also positive.
    
    # Determine the sign adjustments for x and y based on original a and b
    # If a is negative, we flip the sign of x. If b is negative, we flip the sign of y.
    # This ensures that the terms (a * final_x) and (b * final_y) align with
    # (abs(a) * x_prime) and (abs(b) * y_prime) after scaling.
    final_x = x_prime * (1 if a >= 0 else -1) * k
    final_y = y_prime * (1 if b >= 0 else -1) * k
    
    return (final_x, final_y)