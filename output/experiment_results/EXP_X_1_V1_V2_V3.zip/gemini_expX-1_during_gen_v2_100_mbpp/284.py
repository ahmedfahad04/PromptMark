def a(my_list, element):
    """
  Checks if all items in the given list are equal to the specified element.

  Args:
    my_list: The list to check.
    element: The element to compare against.

  Returns:
    True if all items in my_list are equal to element, False otherwise.
    Returns True for an empty list.
  """
    return all((item == element for item in my_list))
