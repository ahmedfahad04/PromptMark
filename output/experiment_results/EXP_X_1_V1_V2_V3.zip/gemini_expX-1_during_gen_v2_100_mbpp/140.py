def a(list_of_lists):
    """
    Flattens a list of lists into a single set of numbers.

    Args:
        list_of_lists: A list where each element is itself a list of numbers.

    Returns:
        A set containing all unique numbers from the input lists.
    """
    flattened_set = set()
    for sublist in list_of_lists:
        for number in sublist:
            flattened_set.add(number)
    return flattened_set
