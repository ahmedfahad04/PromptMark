def a(numbers_list):
    """
    Rounds every number in the given list, calculates their sum,
    and then prints this sum multiplied by the length of the list.

    Args:
        numbers_list (list): A list of numbers (integers or floats).
    """
    rounded_numbers = [round(num) for num in numbers_list]
    total_sum_rounded = sum(rounded_numbers)
    list_length = len(numbers_list)
    final_result = total_sum_rounded * list_length
    print(final_result)
