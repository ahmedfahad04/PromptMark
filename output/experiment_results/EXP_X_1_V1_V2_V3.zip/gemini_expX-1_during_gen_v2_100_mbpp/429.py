def a(tuple1: tuple, tuple2: tuple) -> tuple:
    """
    Extracts element-wise tuples from two given tuples.

    This function combines corresponding elements from the two input tuples
    into new individual tuples. These new tuples are then collected into a
    single resulting tuple. The process stops when the shorter of the two
    input tuples runs out of elements.

    Args:
        tuple1: The first input tuple.
        tuple2: The second input tuple.

    Returns:
        A new tuple where each element is a tuple containing corresponding
        elements from `tuple1` and `tuple2`.

    Example:
        >>> a((1, 2, 3), ('a', 'b', 'c'))
        ((1, 'a'), (2, 'b'), (3, 'c'))
        >>> a((10, 20), ('x', 'y', 'z')) # Shorter tuple (tuple1) determines length
        ((10, 'x'), (20, 'y'))
        >>> a(('apple', 'banana', 'cherry'), (1, 2)) # Shorter tuple (tuple2) determines length
        (('apple', 1), ('banana', 2))
        >>> a((), (1, 2, 3)) # Empty tuple results in an empty output tuple
        ()
    """
    zipped_elements_iterator = zip(tuple1, tuple2)
    result_tuple_of_tuples = tuple(zipped_elements_iterator)
    return result_tuple_of_tuples
