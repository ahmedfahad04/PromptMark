def a(n):
    """
    Calculates the n'th Lucas number.

    The Lucas numbers are a sequence of integers similar to the Fibonacci numbers.
    They are defined by the recurrence relation L(n) = L(n-1) + L(n-2),
    with the initial conditions L(0) = 2 and L(1) = 1.

    The sequence starts as: 2, 1, 3, 4, 7, 11, 18, 29, 47, ...

    Args:
        n: A non-negative integer representing the index of the desired Lucas number.

    Returns:
        The n'th Lucas number as an integer.

    Raises:
        ValueError: If n is a negative integer.
        TypeError: If n is not an integer.
    """
    if not isinstance(n, int):
        raise TypeError("Input 'n' must be an integer.")
    if n < 0:
        raise ValueError("Input 'n' must be a non-negative integer.")
    if n == 0:
        return 2
    if n == 1:
        return 1
    prev_prev_lucas = 2
    prev_lucas = 1
    for _ in range(2, n + 1):
        current_lucas = prev_prev_lucas + prev_lucas
        prev_prev_lucas = prev_lucas
        prev_lucas = current_lucas
    return prev_lucas
