def remove_whitespaces(input_string):
    """
    Removes all whitespace characters (spaces, tabs, newlines, etc.)
    from the given string.

    This function uses the string's `split()` method without arguments,
    which splits the string by any sequence of whitespace characters
    (spaces, tabs, newlines, etc.) and discards empty strings.
    The resulting list of non-whitespace words is then joined back
    together using an empty string `""` as a separator, effectively
    removing all original whitespaces.

    Args:
        input_string: The string from which to remove whitespaces.

    Returns:
        A new string with all whitespace characters removed.
    """
    return ''.join(input_string.split())
