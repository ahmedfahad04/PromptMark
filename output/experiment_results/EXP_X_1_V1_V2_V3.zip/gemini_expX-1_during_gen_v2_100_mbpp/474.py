def replace_char_in_string(original_string, old_char, new_char):
    """
    Replaces all occurrences of a specified character with another character in a string.

    Args:
        original_string (str): The string in which to perform the replacement.
        old_char (str): The character to be replaced.
        new_char (str): The character to replace with.

    Returns:
        str: A new string with the characters replaced.
    """
    return original_string.replace(old_char, new_char)
