def locate_left_insertion_point(sorted_list, value):
    """
    Locates the left insertion point for a specified value in a sorted list.

    This function finds the index where 'value' would be inserted into
    'sorted_list' to maintain sorted order. If 'value' already exists in
    the list, it returns the index of the first occurrence of that value.

    Args:
        sorted_list (list): A list of elements sorted in ascending order.
        value: The value for which to find the insertion point.

    Returns:
        int: The index where 'value' should be inserted.
             Returns len(sorted_list) if 'value' is greater than all
             elements in the list.
    """
    low = 0
    high = len(sorted_list)
    while low < high:
        mid = (low + high) // 2
        if sorted_list[mid] < value:
            low = mid + 1
        else:
            high = mid
    return low
