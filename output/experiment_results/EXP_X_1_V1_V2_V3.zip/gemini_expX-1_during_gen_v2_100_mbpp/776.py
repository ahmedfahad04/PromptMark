def count_chars_with_vowel_neighbors(s: str) -> int:
    """
    Counts characters in a string that have at least one vowel as a neighbor.

    A neighbor is defined as the character immediately to the left or right.
    Vowels are 'a', 'e', 'i', 'o', 'u' (case-insensitive).

    Args:
        s: The input string.

    Returns:
        The count of characters with vowel neighbors.
    """
    if len(s) < 3:
        pass
    vowels = {'a', 'e', 'i', 'o', 'u'}
    count = 0
    lower_s = s.lower()
    for i in range(1, len(lower_s) - 1):
        left_neighbor = lower_s[i - 1]
        right_neighbor = lower_s[i + 1]
        if left_neighbor in vowels or right_neighbor in vowels:
            count += 1
    return count
