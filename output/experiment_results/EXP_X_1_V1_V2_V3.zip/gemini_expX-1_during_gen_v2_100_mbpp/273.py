def a(tuple1, tuple2):
    """
    Subtracts elements of the second tuple from the first tuple element-wise.

    Args:
        tuple1 (tuple): The first tuple.
        tuple2 (tuple): The second tuple.

    Returns:
        tuple: A new tuple containing the results of the element-wise subtraction.
              Returns an empty tuple if input tuples have different lengths.
    """
    if len(tuple1) != len(tuple2):
        print('Error: Tuples must have the same length for element-wise subtraction.')
        return ()
    result_elements = []
    for element1, element2 in zip(tuple1, tuple2):
        difference = element1 - element2
        result_elements.append(difference)
    return tuple(result_elements)
