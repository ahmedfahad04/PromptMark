def is_perfect_square(num: int) -> bool:
    """
    Checks if a given non-negative integer is a perfect square.

    A perfect square is an integer that can be expressed as the product
    of an integer by itself (e.g., 9 is a perfect square because 3*3 = 9).

    Args:
        num: The integer to check.

    Returns:
        True if the number is a perfect square, False otherwise.
    """
    if num < 0:
        return False
    int_sqrt = math.isqrt(num)
    return int_sqrt * int_sqrt == num
