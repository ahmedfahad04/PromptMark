def a(length, width):
    """
  Calculates the area of a rectangle given its length and width.

  Args:
    length: The length of the rectangle.
    width: The width of the rectangle.

  Returns:
    The area of the rectangle.
  """
    area = length * width
    return area
