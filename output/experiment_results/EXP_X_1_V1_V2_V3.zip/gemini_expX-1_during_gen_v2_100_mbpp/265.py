def a(input_list: list, n: int) -> list[list]:
    """
    Splits a given list into sublists, where each sublist contains 'n' elements.
    The last sublist may contain fewer than 'n' elements if the original list
    length is not perfectly divisible by 'n'.

    Args:
        input_list: The original list to be split.
        n: The integer determining the size of each sublist.

    Returns:
        A list of lists, where each inner list is a segment of the original list.

    Raises:
        ValueError: If 'n' is not a positive integer.
    """
    if not isinstance(n, int) or n <= 0:
        raise ValueError('n must be a positive integer.')
    result_lists = []
    for i in range(0, len(input_list), n):
        sublist = input_list[i:i + n]
        result_lists.append(sublist)
    return result_lists
