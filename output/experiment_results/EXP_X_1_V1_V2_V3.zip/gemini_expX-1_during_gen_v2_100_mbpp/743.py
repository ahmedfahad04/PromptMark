def rotate_list_right(input_list: list, num_rotations: int) -> list:
    """
    Rotates a given list to the right by a specified number of items.

    This function takes a list and an integer 'num_rotations'.
    It moves the last 'num_rotations' elements to the beginning of the list,
    and the remaining elements follow.

    Args:
        input_list: The list to be rotated.
        num_rotations: The number of positions to rotate the list to the right.
                       If num_rotations is 0, the list remains unchanged.
                       If num_rotations is greater than the list's length,
                       it effectively wraps around (e.g., rotating by N in a list
                       of length N is the same as rotating by 0).

    Returns:
        A new list that is the rotated version of the input_list.
    """
    if not input_list:
        return []
    list_length = len(input_list)
    effective_rotations = num_rotations % list_length
    split_point = list_length - effective_rotations
    rotated_list = input_list[split_point:] + input_list[:split_point]
    return rotated_list
