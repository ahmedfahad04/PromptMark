def a(elements):
    """
    Sorts a list of elements in ascending order.

    This function uses Python's built-in `sorted()` function, which returns
    a new sorted list without modifying the original list.

    Args:
        elements (list): The list of elements to be sorted.

    Returns:
        list: A new list containing the sorted elements.
    """
    return sorted(elements)
