def find_smallest_missing_number(nums: list) -> int:
    """
    Finds the smallest missing natural number from a sorted list of natural numbers.
    This function assumes "natural numbers" include 0 (i.e., non-negative integers: 0, 1, 2, ...).
    The input list is expected to be sorted in ascending order.

    Args:
        nums: A sorted list of natural numbers (non-negative integers).

    Returns:
        The smallest natural number that is missing from the list.
        For example, if nums = [0, 1, 3, 4], the smallest missing is 2.
        If nums = [1, 2, 3], the smallest missing is 0.
        If nums = [0, 1, 2, 3], the smallest missing is 4.
    """
    n = len(nums)

    # Edge case 1: If the list is empty, the smallest missing number is 0.
    # Edge case 2: If the first element is not 0, then 0 is the smallest missing.
    if n == 0 or nums[0] != 0:
        return 0

    low = 0
    high = n - 1
    
    # 'smallest_missing' will store our result.
    # Initialize it to 'n'. If all numbers from 0 to n-1 are present,
    # then 'n' itself is the smallest missing number.
    smallest_missing = n 

    # Perform binary search to find the first index 'i' where nums[i] != i.
    while low <= high:
        mid = (low + high) // 2

        # If the number at 'mid' index is equal to its index (nums[mid] == mid),
        # it means the sequence is continuous up to this point (e.g., [0, 1, 2] at index 2).
        # The missing number must be in the right half of the list.
        low = mid + 1

        # If the number at 'mid' index is greater than its index (nums[mid] > mid),
        # it means there's a gap. The missing number is either 'mid' itself,
        # or it lies to the left of 'mid'.
        # We record 'mid' as a potential answer and search in the left half.
        else: # nums[mid] > mid
            smallest_missing = mid
            high = mid - 1
            
    # After the loop, 'smallest_missing' will hold the index of the first
    # number that is not equal to its index, or 'n' if all numbers from 0 to n-1 were present.
    return smallest_missing