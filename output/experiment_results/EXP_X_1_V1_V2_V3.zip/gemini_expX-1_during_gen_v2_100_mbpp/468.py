def max_product_increasing_subsequence(arr):
    """
    Finds the maximum product formed by multiplying numbers of an increasing subsequence
    of the given array.

    Args:
        arr: A list of integers.

    Returns:
        The maximum product of an increasing subsequence. Returns 0 if the array is empty.
    """
    n = len(arr)
    if n == 0:
        return 0
    dp = list(arr)
    max_prod = max(dp)
    for i in range(n):
        for j in range(i):
            if arr[i] > arr[j]:
                current_potential_product = dp[j] * arr[i]
                if current_potential_product > dp[i]:
                    dp[i] = current_potential_product
        max_prod = max(max_prod, dp[i])
    return max_prod
