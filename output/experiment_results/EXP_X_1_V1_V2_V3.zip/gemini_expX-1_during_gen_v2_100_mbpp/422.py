def average_of_cubes(n):
    """
    Calculates the average of the cubes of the first n natural numbers.

    Args:
        n (int): The number of natural numbers. Must be a positive integer.

    Returns:
        float: The average of the cubes of the first n natural numbers.
               Returns 0 if n is 0 to avoid division by zero, though
               the problem implies n is a positive natural number.
    """
    if n <= 0:
        print("Error: 'n' must be a positive integer for natural numbers.")
        return 0.0
    sum_of_cubes = 0
    for i in range(1, n + 1):
        cube = i ** 3
        sum_of_cubes += cube
    average = sum_of_cubes / n
    return average
