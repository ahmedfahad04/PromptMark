def trim_tuples_by_k(tuple_list, k):
    """
    Trims each tuple in a list of tuples to its first 'k' elements.

    This function iterates through a given list of tuples and for each tuple,
    it creates a new tuple containing only the first 'k' elements.
    If a tuple has fewer than 'k' elements, the entire tuple is kept.

    Args:
        tuple_list: A list of tuples, e.g., [(1, 2, 3), (4, 5)].
        k: An integer representing the number of elements to keep from the
           beginning of each tuple. Must be non-negative.

    Returns:
        A new list of tuples, where each tuple is trimmed to its first 'k' elements.

    Examples:
        >>> trim_tuples_by_k([(1, 2, 3, 4), (5, 6), (7, 8, 9)], 2)
        [(1, 2), (5, 6), (7, 8)]

        >>> trim_tuples_by_k([(10, 20), (30, 40, 50)], 1)
        [(10,), (30,)]

        >>> trim_tuples_by_k([(1, 2), (3,)], 5) # k > tuple length
        [(1, 2), (3,)]

        >>> trim_tuples_by_k([(1, 2, 3)], 0) # k = 0 results in empty tuples
        [()]
    """
    trimmed_list = [tpl[:k] for tpl in tuple_list]
    return trimmed_list
