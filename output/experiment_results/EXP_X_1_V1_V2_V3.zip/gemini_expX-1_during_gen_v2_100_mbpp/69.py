def a(main_list: list, sublist: list) -> bool:
    """
    Checks if a given sublist is present within a main list.

    Args:
        main_list: The list to search within.
        sublist: The sublist to search for.

    Returns:
        True if the sublist is found in the main_list, False otherwise.
    """
    if not sublist:
        return True
    if len(sublist) > len(main_list):
        return False
    for i in range(len(main_list) - len(sublist) + 1):
        if main_list[i:i + len(sublist)] == sublist:
            return True
    return False
