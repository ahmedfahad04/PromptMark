def a(coeff_a, coeff_b, coeff_c):
    """
    Calculates the equation of the directrix for a parabola in the form y = ax^2 + bx + c.

    Args:
        coeff_a (float): The coefficient 'a' from the parabola equation y = ax^2 + bx + c.
                         This cannot be zero for a parabola in this specific form.
        coeff_b (float): The coefficient 'b' from the parabola equation y = ax^2 + bx + c.
        coeff_c (float): The coefficient 'c' from the parabola equation y = ax^2 + bx + c.

    Returns:
        str: The equation of the directrix in the format "y = [value]".

    Raises:
        ValueError: If coeff_a is zero, as it would not represent a parabola opening vertically.
    """
    if coeff_a == 0:
        raise ValueError("The coefficient 'a' cannot be zero for a parabola in the form y = ax^2 + bx + c. If a=0, it's a straight line.")
    h = -coeff_b / (2 * coeff_a)
    k = coeff_a * h ** 2 + coeff_b * h + coeff_c
    p = 1 / (4 * coeff_a)
    directrix_y = k - p
    return f'y = {directrix_y}'
