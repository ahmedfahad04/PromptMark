def count_rotations(arr):
    """
    Counts the number of rotations required to generate a sorted array.
    This is equivalent to finding the index of the minimum element in a rotated sorted array.

    Args:
        arr: A list of integers representing the rotated sorted array.

    Returns:
        An integer representing the number of rotations. Returns 0 for empty or already sorted arrays.
    """
    n = len(arr)
    if n == 0 or n == 1:
        return 0
    min_element = arr[0]
    min_index = 0
    for i in range(1, n):
        if arr[i] < min_element:
            min_element = arr[i]
            min_index = i
            break
    return min_index
