def a(list_of_tuples, n):
    """
    Extracts the nth element from each tuple in a given list of tuples.

    Args:
        list_of_tuples (list): A list where each element is a tuple.
        n (int): The index of the element to extract from each tuple (0-indexed).

    Returns:
        list: A new list containing the nth element from each tuple.
              Returns an empty list if the input list is empty.
              Raises IndexError if n is out of bounds for any tuple.

    Example:
        >>> data = [('apple', 10, 'red'), ('banana', 20, 'yellow'), ('cherry', 30, 'red')]
        >>> a(data, 0)
        ['apple', 'banana', 'cherry']
        >>> a(data, 1)
        [10, 20, 30]
    """
    extracted_elements = []
    for tup in list_of_tuples:
        extracted_elements.append(tup[n])
    return extracted_elements
