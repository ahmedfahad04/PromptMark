def a(radius: float, angle: float) -> float | None:
    """
    Calculates the area of a sector given its radius and angle.

    The formula for the area of a sector is (angle / 360) * pi * radius^2.

    Args:
        radius (float): The radius of the circle.
        angle (float): The central angle of the sector in degrees.

    Returns:
        float | None: The area of the sector if the angle is 360 degrees or less,
                      otherwise returns None if the angle is larger than 360 degrees.
    """
    if angle > 360:
        print('Error: Angle cannot be greater than 360 degrees for a single sector.')
        return None
    area = angle / 360 * math.pi * radius ** 2
    return area
