def move_numbers_to_end(input_string):
    """
    Moves all numeric characters to the end of a given string,
    preserving the relative order of both non-numeric and numeric characters.

    Args:
        input_string (str): The string to process.

    Returns:
        str: A new string with all numbers moved to the end.
    """
    non_numeric_parts = []
    numeric_parts = []
    for char in input_string:
        if char.isdigit():
            numeric_parts.append(char)
        else:
            non_numeric_parts.append(char)
    return ''.join(non_numeric_parts) + ''.join(numeric_parts)
