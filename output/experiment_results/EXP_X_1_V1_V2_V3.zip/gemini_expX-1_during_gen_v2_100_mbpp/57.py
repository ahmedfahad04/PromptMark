def find_largest_number(digits):
    """
    Finds the largest number that can be formed with the given list of digits.

    This function takes a list of digits (integers or strings) and arranges
    them in descending order to form the largest possible number.

    Args:
        digits (list): A list of integers or string digits (e.g., [1, 2, 3] or ['1', '2', '3']).

    Returns:
        int: The largest number formed by the digits. Returns 0 if the input list is empty.

    Examples:
        find_largest_number([1, 2, 3]) == 321
        find_largest_number([5, 1, 9]) == 951
        find_largest_number([0, 0, 1]) == 100
        find_largest_number([]) == 0
    """
    if not digits:
        return 0
    str_digits = [str(d) for d in digits]
    str_digits.sort(reverse=True)
    largest_num_str = ''.join(str_digits)
    return int(largest_num_str)
