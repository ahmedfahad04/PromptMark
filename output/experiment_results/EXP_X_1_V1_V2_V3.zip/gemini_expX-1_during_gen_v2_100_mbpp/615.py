def calculate_average_per_tuple(tuple_of_tuples):
    """
    Calculates the average value for each inner tuple within a tuple of tuples.

    Args:
        tuple_of_tuples: A tuple where each element is itself a tuple of numbers
                         (integers or floats).

    Returns:
        A list of floats, where each float is the average of the corresponding
        inner tuple. If an inner tuple is empty, its average is considered 0.0.
    """
    averages = []
    for inner_tuple in tuple_of_tuples:
        if len(inner_tuple) > 0:
            average = sum(inner_tuple) / len(inner_tuple)
            averages.append(average)
        else:
            averages.append(0.0)
    return averages
