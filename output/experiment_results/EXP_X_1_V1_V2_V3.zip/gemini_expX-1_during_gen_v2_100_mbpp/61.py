def count_substrings(s: str) -> int:
    """
    Counts the number of substrings in a given string where the sum of their
    digits equals their length.

    Args:
        s: The input string.

    Returns:
        The total count of such substrings.
    """
    count = 0
    n = len(s)
    for i in range(n):
        current_digit_sum = 0
        for j in range(i, n):
            char = s[j]
            if char.isdigit():
                current_digit_sum += int(char)
            current_length = j - i + 1
            if current_digit_sum == current_length:
                count += 1
    return count
