def find_common_elements_in_nested_lists(nested_list):
    """
    Finds the common elements present in all sublists within a given nested list.

    Args:
        nested_list (list): A list containing other lists as its elements.
                            Example: [[1, 2, 3], [2, 3, 4], [3, 4, 5]]

    Returns:
        list: A list of elements common to all sublists.
              Returns an empty list if the input is empty or no common elements are found.
    """
    if not nested_list:
        return []
    common_elements_set = set(nested_list[0])
    for sublist in nested_list[1:]:
        current_sublist_set = set(sublist)
        common_elements_set = common_elements_set.intersection(current_sublist_set)
        if not common_elements_set:
            break
    return list(common_elements_set)
