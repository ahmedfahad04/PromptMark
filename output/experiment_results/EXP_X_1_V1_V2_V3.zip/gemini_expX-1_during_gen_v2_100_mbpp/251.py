def a(input_list, element_to_insert):
    """
    Inserts a given element before each existing element in a list.

    Args:
        input_list (list): The list in which to insert elements.
        element_to_insert: The element to be inserted before each item.

    Returns:
        list: A new list with the element inserted before each original item.

    Example:
        >>> a([1, 2, 3], 'x')
        ['x', 1, 'x', 2, 'x', 3]
        >>> a(['apple', 'banana'], 0)
        [0, 'apple', 0, 'banana']
    """
    result_list = []
    for item in input_list:
        result_list.append(element_to_insert)
        result_list.append(item)
    return result_list
