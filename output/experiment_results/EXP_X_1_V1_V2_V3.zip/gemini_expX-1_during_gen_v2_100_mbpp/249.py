# Example 1: Basic intersection
list1 = [1, 2, 3, 4, 5]
list2 = [4, 5, 6, 7, 8]
result = find_array_intersection(list1, list2)
print(f"Intersection of {list1} and {list2}: {result}") # Expected: [4, 5] (order might vary)

# Example 2: Lists with duplicates
list3 = [1, 2, 2, 3, 4]
list4 = [2, 3, 3, 5]
result = find_array_intersection(list3, list4)
print(f"Intersection of {list3} and {list4}: {result}") # Expected: [2, 3] (duplicates removed by sets)

# Example 3: No common elements
list5 = [1, 2, 3]
list6 = [4, 5, 6]
result = find_array_intersection(list5, list6)
print(f"Intersection of {list5} and {list6}: {result}") # Expected: []

# Example 4: Empty list
list7 = []
list8 = [1, 2, 3]
result = find_array_intersection(list7, list8)
print(f"Intersection of {list7} and {list8}: {result}") # Expected: []