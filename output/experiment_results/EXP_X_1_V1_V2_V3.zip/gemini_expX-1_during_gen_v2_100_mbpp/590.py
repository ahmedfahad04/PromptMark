def convert_polar_to_rectangular(r, theta):
    """
    Converts polar coordinates (r, theta) to rectangular coordinates (x, y).

    Args:
        r (float): The radial distance from the origin.
        theta (float): The angle in radians from the positive x-axis.

    Returns:
        tuple: A tuple (x, y) representing the rectangular coordinates.
    """
    x = r * math.cos(theta)
    y = r * math.sin(theta)
    return (x, y)
