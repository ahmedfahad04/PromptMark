def a(num1, num2, num3):
    """
  Counts the number of equal numbers among three given integers.

  Args:
    num1: The first integer.
    num2: The second integer.
    num3: The third integer.

  Returns:
    An integer representing the count of equal numbers (0, 2, or 3).
  """
    if num1 == num2 and num2 == num3:
        return 3
    elif num1 == num2 or num1 == num3 or num2 == num3:
        return 2
    else:
        return 0
