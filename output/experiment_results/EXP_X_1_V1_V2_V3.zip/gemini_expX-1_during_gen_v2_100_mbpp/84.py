def a(n: int) -> int:
    """
    Calculates the nth number in the Newman-Conway sequence.

    The Newman-Conway sequence is defined as:
    p(1) = 1
    p(2) = 1
    p(n) = p(p(n-1)) + p(n-p(n-1)) for n > 2

    This function uses dynamic programming (an iterative approach with memoization)
    to efficiently compute the nth term by storing previously calculated values.

    Args:
        n: The position (1-indexed) of the number to find in the sequence.
           For example, if n=1, it returns the 1st number; if n=5, the 5th number.

    Returns:
        The nth Newman-Conway number.

    Raises:
        ValueError: If n is less than 1, as the sequence is defined for positive integers.
    """
    if n < 1:
        raise ValueError('The Newman-Conway sequence is defined for n >= 1.')
    if n == 1:
        return 1
    if n == 2:
        return 1
    dp = [0] * (n + 1)
    dp[1] = 1
    dp[2] = 1
    for i in range(3, n + 1):
        dp[i] = dp[dp[i - 1]] + dp[i - dp[i - 1]]
    return dp[n]
