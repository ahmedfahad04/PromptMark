def a(list1, list2):
    """
    Counts the number of indices where two lists have the same values.

    Args:
        list1: The first list of values.
        list2: The second list of values. Both lists are assumed to be of the same length.

    Returns:
        An integer representing the total count of indices where list1[i] == list2[i].
    """
    match_count = 0
    for element1, element2 in zip(list1, list2):
        if element1 == element2:
            match_count += 1
    return match_count
