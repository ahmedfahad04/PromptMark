def find_element_frequency(list_of_lists):
    """
    Flattens a list of lists and finds the frequency of each element.

    Args:
        list_of_lists: A list where each element is itself a list (e.g., [[1, 2], [3, 1]]).

    Returns:
        A dictionary where keys are the elements and values are their frequencies
        in the flattened list.
    """
    flattened_list = [item for sublist in list_of_lists for item in sublist]
    frequency_dict = collections.Counter(flattened_list)
    return dict(frequency_dict)
