def a(input_list):
    """
    Returns a list of all pairs of consecutive items in a given list.

    For example:
    If input_list is [1, 2, 3, 4], it should return [(1, 2), (2, 3), (3, 4)]
    If input_list is ['a', 'b', 'c'], it should return [('a', 'b'), ('b', 'c')]
    If input_list is [5], it should return []
    If input_list is [], it should return []

    Args:
        input_list: A list of items.

    Returns:
        A list of tuples, where each tuple represents a consecutive pair.
        Returns an empty list if there are fewer than two items in the input_list.
    """
    consecutive_pairs = []
    for i in range(len(input_list) - 1):
        pair = (input_list[i], input_list[i + 1])
        consecutive_pairs.append(pair)
    return consecutive_pairs
