def a(data):
    """
    Splits a list of lists (where each sublist has two elements) into two separate lists.

    Args:
        data: A list of lists, e.g., [[1, 2], [3, 4], [5, 6]].
              Each sublist must contain exactly two elements.

    Returns:
        A list containing two lists. The first inner list contains all the
        first elements from the input sublists, and the second inner list
        contains all the second elements.
        Example: If data is [[1, 2], [3, 4]], returns [[1, 3], [2, 4]].
    """
    first_elements = []
    second_elements = []
    for sublist in data:
        first_elements.append(sublist[0])
        second_elements.append(sublist[1])
    return [first_elements, second_elements]
