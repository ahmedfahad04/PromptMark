def a(list_of_strings):
    """
    Reverses each string in a given list of string values.

    Args:
        list_of_strings: A list of strings.

    Returns:
        A new list where each string from the input list is reversed.
    """
    reversed_strings = []
    for s in list_of_strings:
        reversed_strings.append(s[::-1])
    return reversed_strings
