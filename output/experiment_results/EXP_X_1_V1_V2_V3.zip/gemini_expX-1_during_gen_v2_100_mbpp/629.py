def find_even_numbers(numbers):
    """
    Finds all even numbers from a given list of numbers.

    Args:
        numbers: A list of integers.

    Returns:
        A new list containing only the even numbers from the input list.
    """
    even_numbers = []
    for num in numbers:
        if num % 2 == 0:
            even_numbers.append(num)
    return even_numbers
