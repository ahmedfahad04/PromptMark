def remove_first_last_occurrence(s: str, char: str) -> str:
    """
    Removes the first and last occurrence of a given character from a string.

    Args:
        s: The input string.
        char: The character to remove (must be a single character string).

    Returns:
        The modified string with the first and last occurrences of the character removed.
        Returns the original string if the character is not found, or if the char
        argument is not a single character.
    """
    if not isinstance(char, str) or len(char) != 1:
        return s
    first_index = s.find(char)
    last_index = s.rfind(char)
    if first_index == -1:
        return s
    if first_index == last_index:
        return s[:first_index] + s[first_index + 1:]
    return s[:first_index] + s[first_index + 1:last_index] + s[last_index + 1:]
