def a(list1, list2, list3):
    """
    Interleaves three lists of the same length into a single flat list.

    Args:
        list1 (list): The first list.
        list2 (list): The second list.
        list3 (list): The third list.

    Returns:
        list: A new list with elements interleaved from list1, list2, and list3.

    Example:
        list1 = [1, 2, 3]
        list2 = ['A', 'B', 'C']
        list3 = ['x', 'y', 'z']
        result = a(list1, list2, list3)
        # result will be [1, 'A', 'x', 2, 'B', 'y', 3, 'C', 'z']
    """
    interleaved_list = []
    for i in range(len(list1)):
        interleaved_list.append(list1[i])
        interleaved_list.append(list2[i])
        interleaved_list.append(list3[i])
    return interleaved_list
