def a(side_length):
    """
  Calculates the perimeter of a regular pentagon.

  Args:
    side_length (float or int): The length of one side of the pentagon.

  Returns:
    float: The perimeter of the regular pentagon.
  """
    perimeter = 5 * side_length
    return perimeter
