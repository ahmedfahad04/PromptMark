def contains_z(word):
    """
    Checks if a given word contains the letter 'z'.

    Args:
        word (str): The word to check.

    Returns:
        bool: True if 'z' is found in the word, False otherwise.
    """
    return 'z' in word
