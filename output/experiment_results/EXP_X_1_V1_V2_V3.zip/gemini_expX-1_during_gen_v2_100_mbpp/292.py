def find_quotient_rounded_down(numerator: int, denominator: int) -> int:
    """
    Calculates the quotient of two numbers, rounded down to the nearest integer.

    This function uses Python's floor division operator (//), which
    automatically handles rounding down to the nearest whole number.
    For example:
    7 // 2 = 3
    -7 // 2 = -4 (not -3)

    Args:
        numerator (int): The number to be divided.
        denominator (int): The number by which to divide.
                           Must not be zero to avoid a ZeroDivisionError.

    Returns:
        int: The quotient of the division, rounded down to the nearest integer.

    Raises:
        ZeroDivisionError: If the denominator is zero.
    """
    if denominator == 0:
        raise ZeroDivisionError('Denominator cannot be zero.')
    return numerator // denominator
