def a(base_edge, height):
    """
    Calculates the surface area of a square pyramid given its base edge and height.

    The surface area of a square pyramid is the sum of the area of its square base
    and the area of its four triangular faces.

    Formula:
    Surface Area = (Base Edge)^2 + 2 * Base Edge * Slant Height
    Where Slant Height = sqrt(Height^2 + (Base Edge / 2)^2)

    Args:
        base_edge (float or int): The length of one side of the square base.
        height (float or int): The perpendicular height from the apex to the center of the base.

    Returns:
        float: The total surface area of the square pyramid.

    Raises:
        ValueError: If base_edge or height are not positive values.
    """
    if not isinstance(base_edge, (int, float)) or not isinstance(height, (int, float)):
        raise TypeError('Base edge and height must be numbers.')
    if base_edge <= 0 or height <= 0:
        raise ValueError('Base edge and height must be positive values.')
    base_area = base_edge ** 2
    half_base_edge = base_edge / 2
    slant_height = math.sqrt(height ** 2 + half_base_edge ** 2)
    lateral_surface_area = 2 * base_edge * slant_height
    total_surface_area = base_area + lateral_surface_area
    return total_surface_area
