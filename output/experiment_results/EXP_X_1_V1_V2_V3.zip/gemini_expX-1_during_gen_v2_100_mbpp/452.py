def a(cost_price, selling_price):
    """
    Calculates the loss amount on a sale.

    Args:
        cost_price (float or int): The original cost of the item.
        selling_price (float or int): The price at which the item was sold.

    Returns:
        float or int: The loss amount if a loss occurred, otherwise 0.
    """
    if selling_price < cost_price:
        loss_amount = cost_price - selling_price
        return loss_amount
    else:
        return 0
