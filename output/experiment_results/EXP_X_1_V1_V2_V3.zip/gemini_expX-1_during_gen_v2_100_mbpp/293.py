def a(side_a=None, side_b=None, hypotenuse=None):
    """
    Calculates the length of the third side of a right-angled triangle
    using the Pythagorean theorem (a^2 + b^2 = c^2).

    Provide exactly two known sides as arguments, and leave the side
    you want to find as None.

    Args:
        side_a (float or int, optional): Length of the first leg. Defaults to None.
        side_b (float or int, optional): Length of the second leg. Defaults to None.
        hypotenuse (float or int, optional): Length of the hypotenuse. Defaults to None.

    Returns:
        float: The length of the calculated third side.

    Raises:
        ValueError: If an invalid combination of arguments is provided (e.g.,
                    more than one None, less than two known sides, or impossible
                    side lengths like a leg being longer than the hypotenuse).
    """
    known_sides = [s for s in [side_a, side_b, hypotenuse] if s is not None]
    unknown_sides = [s for s in [side_a, side_b, hypotenuse] if s is None]
    if len(unknown_sides) != 1:
        raise ValueError('Please provide exactly two known sides and one unknown side (None).')
    if any((s <= 0 for s in known_sides)):
        raise ValueError('Side lengths must be positive numbers.')
    if hypotenuse is None:
        if side_a is not None and side_b is not None:
            return math.sqrt(side_a ** 2 + side_b ** 2)
        else:
            raise ValueError('To find the hypotenuse, both legs (side_a and side_b) must be provided.')
    elif side_a is None:
        if hypotenuse is None or side_b is None:
            raise ValueError('To find a leg, the other leg and the hypotenuse must be provided.')
        if hypotenuse <= side_b:
            raise ValueError('Hypotenuse must be longer than a leg.')
        return math.sqrt(hypotenuse ** 2 - side_b ** 2)
    elif side_b is None:
        if hypotenuse is None or side_a is None:
            raise ValueError('To find a leg, the other leg and the hypotenuse must be provided.')
        if hypotenuse <= side_a:
            raise ValueError('Hypotenuse must be longer than a leg.')
        return math.sqrt(hypotenuse ** 2 - side_a ** 2)
