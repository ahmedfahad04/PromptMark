def sum_even_at_even_positions(numbers):
    """
    Calculates the sum of even numbers that are located at even positions
    (0-indexed) within a list of numbers.

    Args:
        numbers (list): A list of integers.

    Returns:
        int: The sum of even numbers found at even positions.
             Returns 0 if no such numbers are found or the list is empty.
    """
    total_sum = 0
    for index, num in enumerate(numbers):
        if index % 2 == 0:
            if num % 2 == 0:
                total_sum += num
    return total_sum
