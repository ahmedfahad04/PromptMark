def convert_snake_to_camel(snake_case_string: str) -> str:
    """
    Converts a snake_case string to a camelCase string.

    This function takes a string formatted in snake_case (where words are
    separated by underscores) and transforms it into camelCase.
    In camelCase, the first word remains lowercase, and the first letter
    of every subsequent word is capitalized, with no underscores.

    Examples:
    - "hello_world" becomes "helloWorld"
    - "my_long_variable_name" becomes "myLongVariableName"
    - "singleword" becomes "singleword"
    - "" (empty string) becomes ""
    - "a" becomes "a" (as per the test case)

    Args:
        snake_case_string: The input string that is in snake_case format.

    Returns:
        The converted string in camelCase format.
    """
    if not snake_case_string:
        return ''
    parts = snake_case_string.split('_')
    camel_case_parts = [parts[0]]
    for part in parts[1:]:
        camel_case_parts.append(part.capitalize())
    return ''.join(camel_case_parts)
