def a(n: int) -> int:
    """
    Calculates the sum of the squares of the first n odd natural numbers.

    This function iterates through the first 'n' natural numbers,
    determines the corresponding odd number, squares it, and adds
    it to a running total.

    Args:
        n: An integer representing the count of odd natural numbers
           whose squares are to be summed. If n is less than or equal to 0,
           the sum will be 0.

    Returns:
        The sum of the squares of the first n odd natural numbers.
        For example, if n=3, it calculates (1*1) + (3*3) + (5*5) = 1 + 9 + 25 = 35.
    """
    if n <= 0:
        return 0
    total_sum_of_squares = 0
    for i in range(1, n + 1):
        current_odd_number = 2 * i - 1
        square_of_odd_number = current_odd_number * current_odd_number
        total_sum_of_squares += square_of_odd_number
    return total_sum_of_squares
