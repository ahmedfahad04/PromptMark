def a(s1: str, s2: str) -> int:
    """
    Counts the minimum number of swaps required to convert one binary string (s1)
    to another (s2).

    Args:
        s1: The source binary string.
        s2: The target binary string.

    Returns:
        The minimum number of swaps needed. Returns -1 if conversion is impossible.
    """
    if len(s1) != len(s2):
        return -1
    if s1.count('0') != s2.count('0') or s1.count('1') != s2.count('1'):
        return -1
    zeros_to_ones_mismatches = 0
    for char_s1, char_s2 in zip(s1, s2):
        if char_s1 == '0' and char_s2 == '1':
            zeros_to_ones_mismatches += 1
    return zeros_to_ones_mismatches
