def a(n):
    """
    Calculates the sum (n - 2*i) from i=0 to n // 2.
    For example: n + (n-2) + (n-4)... (until the term is <= 0).
    The terms will be non-negative within the specified range.

    Args:
        n (int): The starting integer for the series.

    Returns:
        int: The calculated sum of the series.
    """
    total_sum = 0
    for i in range(n // 2 + 1):
        term = n - 2 * i
        total_sum += term
    return total_sum
