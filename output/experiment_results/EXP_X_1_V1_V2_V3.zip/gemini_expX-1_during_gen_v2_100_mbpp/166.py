def count_even_xor_pairs(numbers):
    """
    Counts the number of pairs of integers in a list that XOR to an even number.

    Args:
        numbers: A list of integers.

    Returns:
        The total count of pairs (a, b) from the list such that a ^ b is even.
    """
    count_even = 0
    count_odd = 0
    for num in numbers:
        if num % 2 == 0:
            count_even += 1
        else:
            count_odd += 1
    pairs_from_evens = count_even * (count_even - 1) // 2
    pairs_from_odds = count_odd * (count_odd - 1) // 2
    total_even_xor_pairs = pairs_from_evens + pairs_from_odds
    return total_even_xor_pairs
