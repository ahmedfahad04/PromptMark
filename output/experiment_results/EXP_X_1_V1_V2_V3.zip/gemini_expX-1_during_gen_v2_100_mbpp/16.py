def a(input_string):
    """
  Checks if the input string contains sequences of lowercase letters 
  joined with an underscore.

  Args:
    input_string: The string to check.

  Returns:
    True if the string matches the pattern, False otherwise.
  """
    pattern = '[a-z]+_[a-z]+'
    if re.search(pattern, input_string):
        return True
    else:
        return False
