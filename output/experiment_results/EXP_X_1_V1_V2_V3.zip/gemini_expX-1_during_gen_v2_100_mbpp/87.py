def a(dict1: dict, dict2: dict, dict3: dict) -> dict:
    """
    Merges three dictionaries into a single new dictionary.

    This function combines all key-value pairs from the three input dictionaries
    into one new dictionary. If there are duplicate keys across the dictionaries,
    the value from the dictionary that appears later in the argument list
    (i.e., dict3 will overwrite dict2's value, which will overwrite dict1's value)
    will be preserved in the final merged dictionary.

    Args:
        dict1: The first dictionary to merge.
        dict2: The second dictionary to merge.
        dict3: The third dictionary to merge.

    Returns:
        A new dictionary containing the merged contents of dict1, dict2, and dict3.
    """
    merged_dict = {**dict1, **dict2, **dict3}
    return merged_dict
