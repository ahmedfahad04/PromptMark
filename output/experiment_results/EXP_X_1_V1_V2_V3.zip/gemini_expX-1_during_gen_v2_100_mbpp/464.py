def check_all_values_same(dictionary):
    """
    Checks if all values in a dictionary are the same.

    This function iterates through the values of the given dictionary and
    determines if all of them are identical. It also handles edge cases
    like empty or single-element dictionaries.

    Args:
        dictionary (dict): The input dictionary to check.

    Returns:
        bool: True if all values in the dictionary are identical,
              or if the dictionary is empty (vacuously true).
              False otherwise.

    Examples:
        >>> check_all_values_same({'a': 1, 'b': 1, 'c': 1})
        True
        >>> check_all_values_same({'x': 10, 'y': 20, 'z': 10})
        False
        >>> check_all_values_same({'only_one': 'value'})
        True
        >>> check_all_values_same({})
        True
        >>> check_all_values_same({'k1': 'apple', 'k2': 'apple', 'k3': 'apple'})
        True
        >>> check_all_values_same({'k1': 'apple', 'k2': 'banana'})
        False
    """
    if not dictionary:
        return True
    values = dictionary.values()
    unique_values = set(values)
    return len(unique_values) == 1
