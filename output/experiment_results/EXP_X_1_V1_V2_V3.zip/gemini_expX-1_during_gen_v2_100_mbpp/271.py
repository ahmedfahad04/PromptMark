def sum_of_first_n_even_powers_of_five(n: int) -> int:
    """
    Calculates the sum of the first n even natural numbers, each raised to the fifth power.

    Args:
        n: An integer representing the number of even natural numbers to consider.
           Must be a non-negative integer.

    Returns:
        The sum of the first n even natural numbers raised to the fifth power.

    Examples:
        If n = 1, the sum is (2^5) = 32
        If n = 2, the sum is (2^5) + (4^5) = 32 + 1024 = 1056
    """
    if not isinstance(n, int) or n < 0:
        raise ValueError("Input 'n' must be a non-negative integer.")
    total_sum = 0
    for i in range(1, n + 1):
        current_even_number = 2 * i
        total_sum += current_even_number ** 5
    return total_sum
