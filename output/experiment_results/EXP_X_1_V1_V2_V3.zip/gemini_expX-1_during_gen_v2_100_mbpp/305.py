def find_two_p_words(word_list):
    """
    Returns up to two words from a list that start with the letter 'p' (case-insensitive).

    Args:
        word_list (list): A list of strings (words).

    Returns:
        list: A new list containing the first two words found that start with 'p'.
              If fewer than two are found, it returns whatever 'p' words were found.
    """
    p_words_found = []
    for word in word_list:
        if word.lower().startswith('p'):
            p_words_found.append(word)
            if len(p_words_found) == 2:
                break
    return p_words_found
