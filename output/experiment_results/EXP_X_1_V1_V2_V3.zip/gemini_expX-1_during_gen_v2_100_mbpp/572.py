def a(*lists):
    """
    Removes duplicate numbers from a given number of lists,
    returning a single list containing only unique numbers.

    Args:
        *lists: A variable number of lists (e.g., list1, list2, list3, ...).
                Each list is expected to contain numbers.

    Returns:
        A new list containing all unique numbers found across all input lists.
        The order of elements in the returned list is not guaranteed, as it
        is derived from a set.
    """
    unique_numbers = set()
    for current_list in lists:
        for number in current_list:
            unique_numbers.add(number)
    return list(unique_numbers)
