def extract_quoted_values(text: str) -> list[str]:
    """
    Extracts all values enclosed within double quotation marks from a given string.

    This function is designed to help a junior developer understand how to use
    regular expressions (regex) for common string manipulation tasks.
    It identifies and captures text segments that are surrounded by double quotes.

    Args:
        text (str): The input string from which to extract quoted values.

    Returns:
        list[str]: A list of strings, where each string is a value found
                   between double quotation marks. Returns an empty list
                   if no quoted values are found.

    Explanation of the Regular Expression (r'"([^"]*)"'):
    -----------------------------------------------------
    - `r''`: This denotes a "raw string" in Python. It's good practice for regex
             patterns because it treats backslashes (`\\`) as literal characters,
             preventing Python from interpreting them as escape sequences (e.g., `
` for newline).
    - `"`: This matches a literal double quotation mark. It signifies the start
           of a quoted value.
    - `(` and `)`: These create a "capturing group". Whatever matches inside these
                   parentheses will be extracted and returned by `re.findall()`.
                   This is key, as we want the *content* between the quotes, not the quotes themselves.
    - `[^"]`: This is a "character set" that matches any single character *except*
              a double quotation mark.
              - `[` and `]`: Define the character set.
              - `^`: When placed at the beginning inside a character set (e.g., `[^...]`),
                     it negates the set, meaning "match any character NOT in this set".
    - `*`: This is a "quantifier" that means "match the preceding element zero or more times".
           So, `[^"]*` means "match any sequence of characters that are not double quotes,
           including an empty sequence". This allows it to capture empty strings like `""`.
    - `"`: This matches the closing literal double quotation mark, signifying the
           end of the quoted value.

    How `re.findall()` works:
    --------------------------
    The `re.findall()` function searches the entire `text` string for all
    non-overlapping matches of the `pattern`.
    - If the pattern contains no capturing groups, `re.findall()` returns a list
      of the full matching strings.
    - If the pattern contains one or more capturing groups (like ours does with `([^"]*)`),
      it returns a list of strings (or tuples of strings if there are multiple groups),
      where each string corresponds to the content captured by the group(s).
      Since we have one capturing group that contains the actual value, it returns a list of those values.

    Example Usage for a junior developer:
    ------------------------------------
    >>> extract_quoted_values('This is a "simple" string with "two" values.')
    ['simple', 'two']

    >>> extract_quoted_values('No quotes in this sentence.')
    []

    >>> extract_quoted_values('Just "one value" here.')
    ['one value']

    >>> extract_quoted_values('String with an empty "" quote and another "non-empty".')
    ['', 'non-empty']

    >>> extract_quoted_values('"Beginning" and "end" of the string.')
    ['Beginning', 'end']
    """
    pattern = '"([^"]*)"'
    quoted_values = re.findall(pattern, text)
    return quoted_values
