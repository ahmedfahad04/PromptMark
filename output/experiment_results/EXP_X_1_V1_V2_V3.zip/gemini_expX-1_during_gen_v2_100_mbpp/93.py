def power(a, b):
    """
  Calculates the value of 'a' to the power of 'b'.

  Args:
    a: The base number.
    b: The exponent.

  Returns:
    The result of a raised to the power of b.
  """
    return a ** b
