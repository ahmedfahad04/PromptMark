def a(my_list):
    """
    Interchanges the first and last elements of a given list.

    Args:
        my_list: The list in which to interchange elements.

    Returns:
        The list with its first and last elements interchanged.
        If the list has fewer than two elements, the original list is returned.
    """
    if len(my_list) >= 2:
        my_list[0], my_list[-1] = (my_list[-1], my_list[0])
    return my_list
