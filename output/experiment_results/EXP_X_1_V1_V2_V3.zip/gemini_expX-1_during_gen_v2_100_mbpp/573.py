def calculate_unique_product(numbers):
    """
    Calculates the product of unique numbers in a given list.

    Args:
        numbers: A list of integers or floats.

    Returns:
        The product of the unique numbers in the list. Returns 1 if the
        list is empty or contains no unique numbers (after processing).
    """
    if not numbers:
        return 1
    unique_numbers = set(numbers)
    product = 1
    for num in unique_numbers:
        product *= num
    return product
