def count_occurrences_in_tuple(input_tuple, target_element):
    """
  Counts the occurrences of a specific element in a given tuple.

  Args:
    input_tuple: The tuple to search within.
    target_element: The element whose occurrences need to be counted.

  Returns:
    The number of times the target_element appears in the input_tuple.
  """
    return input_tuple.count(target_element)
