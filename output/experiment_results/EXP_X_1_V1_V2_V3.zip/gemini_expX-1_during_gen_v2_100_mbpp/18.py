def a(str1: str, str2: str) -> str:
    """
    Removes characters from the first string that are present in the second string.

    Args:
        str1: The string from which characters will be removed.
        str2: The string containing characters to be removed from str1.

    Returns:
        A new string with characters from str1 that are not found in str2.
    """
    chars_to_remove = set(str2)
    result_chars = []
    for char in str1:
        if char not in chars_to_remove:
            result_chars.append(char)
    return ''.join(result_chars)
