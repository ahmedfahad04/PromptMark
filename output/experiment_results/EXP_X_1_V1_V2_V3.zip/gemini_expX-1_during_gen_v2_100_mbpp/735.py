def a(number):
    """
    Toggles all bits of a number except the first (Most Significant Bit)
    and the last (Least Significant Bit).

    Args:
        number (int): The integer whose bits are to be toggled.

    Returns:
        int: The number with its middle bits toggled.
    """
    num_bits = number.bit_length()
    if num_bits <= 1:
        return number
    full_mask = (1 << num_bits) - 1
    mask_without_lsb = full_mask & ~1
    final_mask = mask_without_lsb & ~(1 << num_bits - 1)
    result = number ^ final_mask
    return result
