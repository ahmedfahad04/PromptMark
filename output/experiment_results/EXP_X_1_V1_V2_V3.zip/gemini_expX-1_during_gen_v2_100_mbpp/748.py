def a(input_string: str) -> str:
    """
    Inserts spaces before words that start with a capital letter in a given string.

    This function handles common cases like:
    - CamelCase (e.g., "helloWorld" -> "hello World")
    - PascalCase (e.g., "HelloWorld" -> "Hello World")
    - Acronyms followed by a word (e.g., "HTMLParser" -> "HTML Parser")
    - Acronyms (e.g., "MyAPI" -> "My API")

    Args:
        input_string: The string to process.

    Returns:
        The string with spaces inserted as appropriate.
    """
    if not input_string:
        return ''
    result_chars = []
    for i, char in enumerate(input_string):
        if char.isupper() and i > 0:
            previous_char = input_string[i - 1]
            if previous_char.islower():
                result_chars.append(' ')
            elif previous_char.isupper() and i + 1 < len(input_string) and input_string[i + 1].islower():
                result_chars.append(' ')
        result_chars.append(char)
    return ''.join(result_chars)
