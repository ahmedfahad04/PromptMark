def a(input_string: str) -> tuple:
    """
    Converts a given string into a tuple of its individual characters.

    This function takes a string as input and iterates over its characters,
    placing each character as a separate element into a new tuple.

    Args:
        input_string (str): The string to be converted into a tuple of characters.

    Returns:
        tuple: A tuple where each element is a character from the original string.

    Example:
        >>> a("hello")
        ('h', 'e', 'l', 'l', 'o')
        >>> a("Python")
        ('P', 'y', 't', 'h', 'o', 'n')
        >>> a("")
        ()
    """
    return tuple(input_string)
