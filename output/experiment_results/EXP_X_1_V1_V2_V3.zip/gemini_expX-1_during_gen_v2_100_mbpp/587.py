def a(input_list):
    """
  Converts a given list into a tuple.

  Args:
    input_list: The list to be converted.

  Returns:
    A tuple containing all elements from the input_list.
  """
    converted_tuple = tuple(input_list)
    return converted_tuple
