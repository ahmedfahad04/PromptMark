def a(input_list):
    """
    Calculates the square of each element in a given list.

    Args:
        input_list (list): A list of numbers (integers or floats).

    Returns:
        list: A new list containing the squares of the individual elements
              from the input_list.
    """
    squared_elements = []
    for element in input_list:
        squared_elements.append(element * element)
    return squared_elements
