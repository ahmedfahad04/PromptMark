def remove_lowercase_substrings(input_string):
    """
    Removes all individual lowercase characters from the given string.

    This function iterates through the input_string and constructs a new string
    containing only characters that are not lowercase. This includes uppercase
    letters, digits, symbols, and spaces.

    Args:
        input_string (str): The string from which to remove lowercase characters.

    Returns:
        str: A new string with all lowercase characters removed.
    """
    filtered_chars = [char for char in input_string if not char.islower()]
    return ''.join(filtered_chars)
