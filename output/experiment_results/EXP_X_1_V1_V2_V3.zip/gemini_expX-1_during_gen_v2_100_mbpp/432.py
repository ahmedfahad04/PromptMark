def a(base1, base2):
    """
  Calculates the median length of a trapezium.

  The median length of a trapezium (also known as the midsegment)
  is the average of the lengths of its two parallel bases.

  Args:
    base1 (float or int): The length of the first parallel base.
    base2 (float or int): The length of the second parallel base.

  Returns:
    float: The median length of the trapezium.
  """
    median_length = (base1 + base2) / 2
    return median_length
