def extract_rear_elements(list_of_tuples):
    """
    Takes a list of tuples and returns a new list containing the last element
    of each tuple.

    Args:
        list_of_tuples: A list where each element is a tuple.

    Returns:
        A list containing the rear (last) element of each tuple from the input list.
    """
    rear_elements = []
    for item_tuple in list_of_tuples:
        if item_tuple:
            rear_elements.append(item_tuple[-1])
    return rear_elements
