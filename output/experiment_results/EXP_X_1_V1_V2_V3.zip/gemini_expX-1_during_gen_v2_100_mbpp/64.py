def a(list_of_tuples):
    """
    Sorts a list of tuples based on the second value of each tuple.

    This function uses Python's built-in `sorted()` function, which is a versatile
    way to sort any iterable. The `key` argument is essential here, as it tells
    `sorted()` which part of each tuple to use for comparison during the sorting process.

    Args:
        list_of_tuples: A list of tuples. Each tuple is expected to have at least
                        two elements, as the sorting is based on the element at index 1.
                        Example: [('apple', 3), ('banana', 1), ('cherry', 2)]

    Returns:
        A new list containing the original tuples, but sorted in ascending order
        based on their second element. The original list remains unchanged.

    Example:
        >>> my_data = [('item1', 10), ('item2', 5), ('item3', 15)]
        >>> sorted_data = a(my_data)
        >>> print(sorted_data)
        [('item2', 5), ('item1', 10), ('item3', 15)]
    """
    return sorted(list_of_tuples, key=lambda x: x[1])
