def find_first_ly_adverb(text: str) -> tuple[str | None, tuple[int, int] | None]:
    """
    Finds the first word ending with 'ly' and its positions in the given string.

    For the purpose of this task, "adverb ending with ly" is interpreted as
    "any word-like sequence of characters ending in 'ly'".
    A true grammatical identification of an adverb would typically require a
    dictionary or Natural Language Processing (NLP) library, which is beyond
    the scope of a basic string manipulation task.

    Args:
        text: The input string to search within.

    Returns:
        A tuple containing:
        - The first word found that ends with 'ly' (str), or None if no such word is found.
        - A tuple (start_index, end_index) indicating the 0-based
          start and end positions of the word in the input string,
          or None if no such word is found.
    """
    for match in re.finditer('\\b(\\w+ly)\\b', text, re.IGNORECASE):
        word = match.group(1)
        start_index = match.start(1)
        end_index = match.end(1)
        return (word, (start_index, end_index))
    return (None, None)
