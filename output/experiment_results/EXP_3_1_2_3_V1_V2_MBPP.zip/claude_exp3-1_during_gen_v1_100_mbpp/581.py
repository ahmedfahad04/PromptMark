import math

def surface_Area(core_length, pyramid_top):
    # Calculate the surface area of a square pyramid
    # Formula: base area + 4 × triangular face area
    
    # Calculate base area (square)
    foundation_portion = core_length * core_length
    
    # Calculate slant height for triangular faces
    # From pyramid center to face midpoint
    center_to_corner = core_length / 2
    triangular_gradient = math.sqrt(pyramid_top * pyramid_top + center_to_corner * center_to_corner)
    
    # Calculate area of one triangular face
    # Triangle area = (1/2) × base × height (slant height)
    one_face_portion = 0.5 * core_length * triangular_gradient
    
    # Total lateral surface area (4 triangular faces)
    lateral_portion = 4 * one_face_portion
    
    # Total surface area
    final_result = foundation_portion + lateral_portion
    
    return int(final_result)