def union_elements(first_tuple, other_tuple):
    # Convert tuples to sets to get unique elements, then combine them
    combined_set = set(first_tuple) | set(other_tuple)
    
    # Convert back to tuple and return in sorted order
    return tuple(sorted(combined_set))