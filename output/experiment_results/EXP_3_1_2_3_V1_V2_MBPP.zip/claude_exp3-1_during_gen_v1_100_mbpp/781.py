def count_divisors(number):
    """Check if the count of divisors for given number is even"""
    # Count all positive factors of the number
    factor_count = 0
    
    # Loop through potential factors from 1 to number
    for potential_factor in range(1, number + 1):
        if number % potential_factor == 0:
            factor_count += 1
    
    # Return True if count is even, False if odd
    return factor_count % 2 == 0