def common_in_nested_lists(nested_lists):
    # Quick return for corner case
    if not nested_lists:
        return []
    
    # Convert first list to common set
    common_pool = set(nested_lists[0])
    
    # Go through remaining lists, find overlaps
    for current_list in nested_lists[1:]:
        current_pool = set(current_list)
        common_pool = common_pool.intersection(current_pool)
    
    return list(common_pool)