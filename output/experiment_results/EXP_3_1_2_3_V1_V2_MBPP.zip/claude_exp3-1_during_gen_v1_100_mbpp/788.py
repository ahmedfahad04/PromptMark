def new_tuple(list_part, text_part):
    # Combine list content plus text to form final tuple
    result = tuple(list_part + [text_part])
    return result