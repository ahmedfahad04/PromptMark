def check_value(person_records, target_grade):
    # Quick return for no records
    if not person_records:
        return True
    
    # Collect grades from persons
    grade_list = list(person_records.values())
    
    # Compare target grade to first grade, then check remaining grades
    first_grade = grade_list[0]
    
    # Target grade must qualify first
    if target_grade != first_grade:
        return False
    
    # Process remaining grades for consistency
    for current_grade in grade_list[1:]:
        if current_grade != target_grade:
            return False
    
    return True