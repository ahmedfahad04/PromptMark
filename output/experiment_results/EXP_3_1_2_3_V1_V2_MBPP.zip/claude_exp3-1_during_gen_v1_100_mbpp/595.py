def min_Swaps(first_string, target_string):
    # Check for fundamental requirements
    if len(first_string) != len(target_string):
        return "Not Possible"
    
    first_ones = first_string.count('1')
    target_ones = target_string.count('1')
    
    if first_ones != target_ones:
        return "Not Possible"
    
    # Count positions needing change
    position_diff = 0
    for current_pos in range(len(first_string)):
        if first_string[current_pos] != target_string[current_pos]:
            position_diff += 1
    
    # Pairs that need swapping
    return position_diff // 2