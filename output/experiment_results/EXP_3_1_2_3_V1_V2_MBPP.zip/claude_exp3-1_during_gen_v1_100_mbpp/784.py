def mul_even_odd(number_list):
    # Find first odd and first even numbers in the given list
    first_odd = None
    first_even = None
    
    for current_number in number_list:
        if current_number % 2 == 0 and first_even is None:
            first_even = current_number
        elif current_number % 2 == 1 and first_odd is None:
            first_odd = current_number
        
        # Once found, no need to continue checking
        if first_odd is not None and first_even is not None:
            break
    
    # Calculate product of first odd and first even
    product_result = first_odd * first_even
    return product_result