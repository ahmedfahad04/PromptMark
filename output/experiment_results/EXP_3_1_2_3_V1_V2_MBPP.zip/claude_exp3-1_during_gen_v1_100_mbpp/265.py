def list_split(original_list, n):
    # Create n groups to collect the nth elements
    result_groups = [[] for _ in range(n)]
    
    for position, current_element in enumerate(original_list):
        group_number = position % n
        result_groups[group_number].append(current_element)
    
    return result_groups