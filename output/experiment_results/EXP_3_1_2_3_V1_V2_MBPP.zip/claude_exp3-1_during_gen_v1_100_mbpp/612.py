def merge(nested_list):
    # Get the length of the first nested pair to generate correct count of output groups
    if not nested_list or not nested_list[0]:
        return []
    
    output_groups = []
    group_count = len(nested_list[0])
    
    # Create groups for collecting position-fixed components
    for position in range(group_count):
        current_group = []
        for pair in nested_list:
            if position < len(pair):
                current_group.append(pair[position])
        output_groups.append(current_group)
    
    return output_groups