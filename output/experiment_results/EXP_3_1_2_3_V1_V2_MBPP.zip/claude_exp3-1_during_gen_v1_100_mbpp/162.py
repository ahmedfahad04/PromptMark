def sum_series(n):
    # Calculate progression total for pattern n + (n-2) + (n-4) + ...
    total_progression = 0
    current_offset = 0
    
    # Process each term from original number down
    for counter in range(n // 2 + 1):
        current_term = n - 2 * counter
        if current_term <= 0:
            break
        total_progression += current_term
        
    return total_progression