def subject_marks(grade_list):
    # Function to get grade point from tuple pair
    def grade_point_from_tuple(course_grade_pair):
        return course_grade_pair[1]
    
    return sorted(grade_list, key=grade_point_from_tuple)