def count_rotation(given_list):
    length = len(given_list)
    
    # Find the position that results in minimum rotations
    optimal_rotations = length
    
    for rotation_count in range(length):
        # Create rotated copy
        rotated_copy = given_list[rotation_count:] + given_list[:rotation_count]
        
        # Check if rotated copy forms sorted order
        properly_ordered = True
        for position in range(1, length):
            if rotated_copy[position] < rotated_copy[position - 1]:
                properly_ordered = False
                break
        
        # Track minimum rotations needed
        if properly_ordered:
            optimal_rotations = min(optimal_rotations, rotation_count)
    
    return optimal_rotations