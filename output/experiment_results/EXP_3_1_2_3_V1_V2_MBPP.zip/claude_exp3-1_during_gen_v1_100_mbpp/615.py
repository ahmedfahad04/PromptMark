def average_tuple(tuple_collection):
    if not tuple_collection:
        return []
    
    num_positions = len(tuple_collection[0])
    position_totals = []
    
    # Calculate totals for each position
    for position_index in range(num_positions):
        position_total = 0
        for current_tuple in tuple_collection:
            position_total += current_tuple[position_index]
        position_totals.append(position_total)
    
    # Calculate averages
    tuple_count = len(tuple_collection)
    final_results = []
    for total in position_totals:
        final_results.append(total / tuple_count)
    
    return final_results