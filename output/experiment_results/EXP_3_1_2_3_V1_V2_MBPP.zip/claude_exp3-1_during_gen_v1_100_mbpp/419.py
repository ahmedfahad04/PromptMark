def round_and_sum(number_list):
    # Round each number and collect rounded values
    rounded_numbers = [round(num) for num in number_list]
    
    # Calculate total of rounded numbers
    total = sum(rounded_numbers)
    
    # Get length of original list
    length = len(number_list)
    
    # Calculate final result
    final_result = total * length
    
    return final_result