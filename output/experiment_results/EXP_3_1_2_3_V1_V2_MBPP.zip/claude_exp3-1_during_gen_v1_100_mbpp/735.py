def toggle_middle_bits(number):
    # Find position of leftmost non-zero bit
    if number == 0:
        return 0
    
    # Get position of leftmost non-zero bit
    position_count = number.bit_length()
    
    # For numbers with only 1 or 2 bits, no middle bits exist
    if position_count <= 2:
        return number
    
    # Create toggle pattern for middle bits only
    # Generate pattern with 1s for middle positions
    toggle_pattern = 0
    for position in range(1, position_count - 1):
        toggle_pattern |= (1 << position)
    
    # Toggle middle bits only
    final_result = number ^ toggle_pattern
    return final_result