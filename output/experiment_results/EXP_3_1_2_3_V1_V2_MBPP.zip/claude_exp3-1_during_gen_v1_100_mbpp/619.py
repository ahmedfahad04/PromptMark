def move_num(text_content):
    # Collect characters that form letters, placing numerics later
    letter_portion = []
    number_portion = []
    
    for current_char in text_content:
        if current_char.isdigit():
            number_portion.append(current_char)
        else:
            letter_portion.append(current_char)
    
    # Join collected parts to form final output
    result_output = ''.join(letter_portion) + ''.join(number_portion)
    return result_output