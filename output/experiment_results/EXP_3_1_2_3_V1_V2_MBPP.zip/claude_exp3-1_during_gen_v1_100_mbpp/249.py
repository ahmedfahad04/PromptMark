def intersection_array(first_collection, collection_target):
    # Convert to collections for O(1) lookup time
    first_collection_lookup = set(first_collection)
    
    # Find common elements preserving order from collection_target
    common_numbers = []
    for number in collection_target:
        if number in first_collection_lookup:
            common_numbers.append(number)
    
    return common_numbers