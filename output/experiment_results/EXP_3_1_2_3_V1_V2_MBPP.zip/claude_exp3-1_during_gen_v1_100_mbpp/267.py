def square_Sum(n):
    # Calculate total of quartic progression for first n terms
    total_quartic = 0
    
    for position in range(n):
        # Get current odd figure: 2*position + 1
        current_odd_figure = 2 * position + 1
        # Calculate quartic of current odd figure
        quartic_of_odd = current_odd_figure ** 2
        total_quartic += quartic_of_odd
    
    return total_quartic