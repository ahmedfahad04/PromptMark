def pair_wise(given_list):
    # Process consecutive pair formation for the given collection
    pair_results = []
    
    for position in range(len(given_list) - 1):
        current_item = given_list[position]
        next_item = given_list[position + 1]
        pair_tuple = (current_item, next_item)
        pair_results.append(pair_tuple)
    
    return pair_results