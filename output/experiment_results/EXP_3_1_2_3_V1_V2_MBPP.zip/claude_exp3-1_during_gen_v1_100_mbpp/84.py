def sequence(target_position):
    # Newman-Conway sequence: P(n) = P(P(n-1)) + P(n-P(n-1))
    newman_conway = [0, 1, 1]  # P(0)=0, P(1)=1, P(2)=1
    
    for position in range(3, target_position + 1):
        previous_term = newman_conway[position - 1]
        complement_term = newman_conway[position - previous_term]
        next_term = newman_conway[previous_term] + complement_term
        newman_conway.append(next_term)
    
    return newman_conway[target_position]