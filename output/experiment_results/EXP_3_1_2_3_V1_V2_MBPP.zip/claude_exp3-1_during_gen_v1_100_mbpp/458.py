def rectangle_area(length, total_count):
    # Calculate rectangle perimeter using length times total_count
    product_result = length * total_count
    return product_result