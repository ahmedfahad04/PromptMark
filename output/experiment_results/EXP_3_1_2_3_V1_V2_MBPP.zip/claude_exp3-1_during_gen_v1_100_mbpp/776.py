def count_vowels(text_string):
    # Track characters that qualify - only count vowels next to other vowels
    qualified_count = 0
    
    # Consider common vowel letters
    found_vowels = {'a', 'e', 'i', 'o', 'u'}
    
    for position in range(len(text_string)):
        current_letter = text_string[position]
        
        # Only proceed if current letter is a vowel
        if current_letter.lower() in found_vowels:
            # Check left neighbor exists and contains vowel
            left_neighbor_vowel = (position > 0 and 
                                 text_string[position - 1].lower() in found_vowels)
            
            # Check right neighbor exists and contains vowel  
            right_neighbor_vowel = (position < len(text_string) - 1 and
                                  text_string[position + 1].lower() in found_vowels)
            
            # Only count if current vowel neighbors another vowel
            if left_neighbor_vowel or right_neighbor_vowel:
                qualified_count += 1
    
    return qualified_count