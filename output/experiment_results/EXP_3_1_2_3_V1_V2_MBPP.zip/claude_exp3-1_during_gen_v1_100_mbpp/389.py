def find_lucas(position):
    if position == 0:
        return 2
    if position == 1:
        return 1
    
    # Lucas sequence follows: current = previous + prev_of_previous
    prev_of_previous = 2  # L(0)
    previous = 1         # L(1)
    
    for count in range(2, position + 1):
        current = previous + prev_of_previous
        prev_of_previous = previous
        previous = current
    
    return current