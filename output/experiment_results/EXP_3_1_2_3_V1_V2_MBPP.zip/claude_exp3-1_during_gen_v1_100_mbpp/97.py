def frequency_lists(nested_list):
    frequency_counter = {}
    
    # Process nested list to count occurrences
    for current_list in nested_list:
        for current_number in current_list:
            if current_number in frequency_counter:
                frequency_counter[current_number] += 1
            else:
                frequency_counter[current_number] = 1
    
    return frequency_counter