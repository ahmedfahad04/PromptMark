def find_first_occurrence(nums, target):
    # Find leftmost position of target number
    left_pointer = 0
    right_pointer = len(nums) - 1
    first_position = -1
    
    while left_pointer <= right_pointer:
        center_point = (left_pointer + right_pointer) // 2
        
        if nums[center_point] == target:
            first_position = center_point
            right_pointer = center_point - 1  # Continue left to find first occurrence
        elif nums[center_point] < target:
            left_pointer = center_point + 1
        else:
            right_pointer = center_point - 1
    
    return first_position