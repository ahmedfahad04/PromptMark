def perimeter_pentagon(quantity_of_pentagon_length):
    # Pentagon perimeter calculation for regular five-corner polygon
    fixed_corner_count = 5
    total_perimeter = quantity_of_pentagon_length * fixed_corner_count
    return total_perimeter