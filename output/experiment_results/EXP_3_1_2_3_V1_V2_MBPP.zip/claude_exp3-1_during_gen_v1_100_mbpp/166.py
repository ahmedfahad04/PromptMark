def find_even_pair(numbers):
    # Count pairs where XOR produces even results
    count = 0
    
    for first_pos in range(len(numbers)):
        for next_pos in range(first_pos + 1, len(numbers)):
            first_num = numbers[first_pos]
            next_num = numbers[next_pos]
            
            # Check parity - two odds or two evens give even XOR
            if (first_num % 2) == (next_num % 2):
                count += 1
    
    return count