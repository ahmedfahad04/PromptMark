def find_Element(original_list, rotation_operations, num_rotations, target_position):
    # Create copy to perform operations on
    current_list = original_list[:]
    
    for rotation_count in range(num_rotations):
        # Get current rotation operation
        rotation_pair = rotation_operations[rotation_count]
        left_position = rotation_pair[0]
        right_position = rotation_pair[1]
        
        # Perform left rotation on the given range
        rotation_segment = current_list[left_position:right_position + 1]
        if len(rotation_segment) > 1:
            # Left rotation: first goes to the end
            rotated_part = rotation_segment[1:] + [rotation_segment[0]]
            current_list[left_position:right_position + 1] = rotated_part
    
    return current_list[target_position]