def occurance_substring(text_content, target_pattern):
    # Find first occurrence of pattern
    position_found = text_content.find(target_pattern)
    
    if position_found == -1:
        return None
    
    # Calculate completion position 
    closing_position = position_found + len(target_pattern)
    
    return (target_pattern, position_found, closing_position)