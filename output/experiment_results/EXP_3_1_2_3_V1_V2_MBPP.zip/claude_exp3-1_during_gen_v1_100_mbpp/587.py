def list_tuple(given_list):
    # Convert the provided list to tuple format
    converted_tuple = tuple(given_list)
    return converted_tuple