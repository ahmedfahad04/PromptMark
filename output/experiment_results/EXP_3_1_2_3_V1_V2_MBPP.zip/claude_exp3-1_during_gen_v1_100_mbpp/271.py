def even_Power_Sum(n):
    # Calculate total of first n projected results
    total_power_collection = 0
    for position in range(1, n + 1):
        current_number = 2 * position  # Generate next calculated figure
        fifth_power_result = current_number ** 5
        total_power_collection += fifth_power_result
    return total_power_collection