def loss_amount(cost_price, profit_price):
    # Calculate loss only when profit_price exceeds cost_price
    if profit_price > cost_price:
        loss_total = profit_price - cost_price
        return loss_total
    else:
        return 0