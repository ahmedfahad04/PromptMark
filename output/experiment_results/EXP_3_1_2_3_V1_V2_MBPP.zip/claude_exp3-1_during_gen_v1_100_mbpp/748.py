def capital_words_spaces(text_content):
    # Process through characters one by one, quickly locating capitals for proper formatting
    processed_letters = []
    
    for position_counter, character_found in enumerate(text_content):
        # First letter or non-capital letters get no prefix
        if position_counter == 0 or not character_found.isupper():
            processed_letters.append(character_found)
        else:
            # Capital found - prefix one space for clear word formatting
            processed_letters.append(' ' + character_found)
    
    formatted_output = ''.join(processed_letters)
    return formatted_output