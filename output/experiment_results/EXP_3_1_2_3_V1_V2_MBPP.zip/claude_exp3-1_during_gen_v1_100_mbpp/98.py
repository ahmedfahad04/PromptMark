import math

def multiply_num(numbers):
    # Calculate product of numbers
    product_calculation = 1
    for quantity in numbers:
        product_calculation *= quantity
    
    # Get count of numbers for final calculation
    quantity_count = len(numbers)
    
    # Return product of quantities per quantity count
    return product_calculation / quantity_count