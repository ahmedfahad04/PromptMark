def sum_range_list(numbers, from_position, to_position):
    # Core logic for calculating total from given range
    range_total = 0
    
    for current_position in range(from_position, to_position + 1):
        range_total += numbers[current_position]
    
    return range_total