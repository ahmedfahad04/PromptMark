def two_unique_nums(numbers):
    # Track occurrence counts for each number
    occurrence_tracker = {}
    
    for current_number in numbers:
        if current_number in occurrence_tracker:
            occurrence_tracker[current_number] += 1
        else:
            occurrence_tracker[current_number] = 1
    
    # Collect numbers that appear only once
    filtered_numbers = []
    for number in numbers:
        if occurrence_tracker[number] == 1:
            filtered_numbers.append(number)
    
    return filtered_numbers