def group_tuples(tuple_list):
    grouped_collections = {}
    
    for pair in tuple_list:
        first_char = pair[0]
        remaining_part = pair[1]
        
        if first_char not in grouped_collections:
            grouped_collections[first_char] = [first_char]
        
        grouped_collections[first_char].append(remaining_part)
    
    # Convert to tuples
    final_grouped = []
    for group_parts in grouped_collections.values():
        final_grouped.append(tuple(group_parts))
    
    return final_grouped