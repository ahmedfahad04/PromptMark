def otherside_rightangle(first_leg, other_leg):
    # Calculate third part of right triangle configuration
    total_leg_power = first_leg**2 + other_leg**2
    
    # Get final length through root calculation
    potential_corner = total_leg_power**0.5
    
    return potential_corner