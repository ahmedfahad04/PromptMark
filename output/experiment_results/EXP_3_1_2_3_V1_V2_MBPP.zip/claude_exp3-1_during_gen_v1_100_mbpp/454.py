import re

def text_match_wordz(text_content):
    # Pattern to find complete tokens containing 'z'
    pattern = r'\b\w*z\w*\b'
    
    # Find tokens containing 'z' character
    found_tokens = re.findall(pattern, text_content)
    
    return len(found_tokens) > 0