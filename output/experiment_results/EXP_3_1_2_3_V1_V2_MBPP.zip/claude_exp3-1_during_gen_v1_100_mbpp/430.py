def parabola_directrix(coefficient_of_x_squared, linear_term, constant_term):
    # Calculate the coefficient multiplier for directrix formula
    four_times_coefficient = 4 * coefficient_of_x_squared
    
    # Calculate the numerator for directrix formula
    quadratic_part = linear_term * linear_term
    constant_contribution = 4 * coefficient_of_x_squared * constant_term
    numerator = quadratic_part - constant_contribution
    
    # Compute directrix value using formula: (p² - 4ac - 1) / 4a
    top_part = numerator - four_times_coefficient
    result = top_part / four_times_coefficient
    
    return int(result)