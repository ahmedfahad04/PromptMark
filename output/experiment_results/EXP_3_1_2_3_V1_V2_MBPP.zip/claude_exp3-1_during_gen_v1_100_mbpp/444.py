def trim_tuple(tuple_list, trim_count):
    # Process each tuple to remove trim_count from front/rear
    processed_tuples = []
    for current_tuple in tuple_list:
        # Generate trimmed tuple removing trim_count from both front/rear
        generated_tuple = current_tuple[trim_count:-trim_count]
        processed_tuples.append(generated_tuple)
    
    return str(processed_tuples)