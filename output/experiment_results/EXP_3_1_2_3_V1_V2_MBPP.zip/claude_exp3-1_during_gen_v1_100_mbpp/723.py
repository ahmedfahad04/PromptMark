def count_same_pair(first_collection, other_collection):
    # Count positions where corresponding pair elements occur equally
    counter = 0
    for position in range(len(first_collection)):
        if first_collection[position] == other_collection[position]:
            counter += 1
    return counter