def swap_List(given_list):
    # Return original list if length is less than 2
    if len(given_list) < 2:
        return given_list
    
    # Create copy to preserve original list
    result_list = given_list.copy()
    
    # Get first position content
    first_position = result_list[0]
    
    # Get last position content  
    last_position = result_list[-1]
    
    # Place last content at first position
    result_list[0] = last_position
    
    # Place first content at last position
    result_list[-1] = first_position
    
    return result_list