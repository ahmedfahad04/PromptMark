def interleave_lists(first_collection, next_collection, third_collection):
    # Connect triplets from corresponding positions
    final_output = []
    total_length = len(first_collection)
    
    for position_counter in range(total_length):
        final_output.append(first_collection[position_counter])
        final_output.append(next_collection[position_counter])
        final_output.append(third_collection[position_counter])
    
    return final_output