def empty_dit(target_list):
    # Guard clause for non-list types
    if not isinstance(target_list, list):
        return len(target_list) == 0
    
    # Process each collection in the list
    for current_dict in target_list:
        # Check for presence of contents
        if len(current_dict) > 0:
            return False
    
    return True