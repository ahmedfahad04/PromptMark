def max_product(numbers):
    if not numbers:
        return 0
    
    length = len(numbers)
    # track maximum product for increasing subsequence ending at position j
    products = [0] * length
    
    # first position can only form subsequence of one element
    products[0] = numbers[0]
    
    for position in range(1, length):
        # current element forms subsequence of length 1
        products[position] = numbers[position]
        
        # try extending from all previous positions
        for previous in range(position):
            if numbers[previous] < numbers[position]:
                # calculate product of extending subsequence from previous position
                new_product = products[previous] * numbers[position]
                products[position] = max(products[position], new_product)
    
    # find maximum product across all positions
    final_result = max(products)
    return final_result