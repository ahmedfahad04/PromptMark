from functools import cmp_to_key

def find_Max_Num(list_of_numbers):
    # Transform number list to text representations
    text_representations = [str(number) for number in list_of_numbers]
    
    # Custom comparison logic for optimal concatenation
    def compare_for_concat(first_text, next_text):
        if first_text + next_text > next_text + first_text:
            return -1
        elif first_text + next_text < next_text + first_text:
            return 1
        else:
            return 0
    
    # Order text representations for optimal concatenation
    text_representations.sort(key=cmp_to_key(compare_for_concat))
    
    # Combine ordered text parts to form final number
    concatenated_text = ''.join(text_representations)
    
    return int(concatenated_text)