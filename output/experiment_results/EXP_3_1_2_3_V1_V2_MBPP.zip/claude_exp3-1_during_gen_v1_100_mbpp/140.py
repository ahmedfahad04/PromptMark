def extract_singly(grouped_numbers):
    flattened_collection = []
    # Go through each tuple collection
    for current_tuple in grouped_numbers:
        # Process each number from tuple
        for number_item in current_tuple:
            flattened_collection.append(number_item)
    
    # Remove repeated numbers
    return list(set(flattened_collection))