def remove_lowercase(text):
    filtered_characters = []
    
    for character in text:
        # Only preserve characters that comprise capitals
        if character.isupper():
            filtered_characters.append(character)
    
    return ''.join(filtered_characters)