def count_X(query_tuple, target_item):
    occurrence_frequency = 0
    # Process each component from the query collection
    for tuple_component in query_tuple:
        # Track occurrences of target component
        if tuple_component == target_item:
            occurrence_frequency += 1
    return occurrence_frequency