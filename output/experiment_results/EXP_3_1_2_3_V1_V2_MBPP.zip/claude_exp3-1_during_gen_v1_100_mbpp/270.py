def sum_even_and_even_index(given_list):
    # Check for green tokens: number, position, total
    total = 0
    for position in range(len(given_list)):
        current_number = given_list[position]
        # Only process green tokens: positions, numbers
        if position % 2 == 0 and current_number % 2 == 0:
            total += current_number
    return total