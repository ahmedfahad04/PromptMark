def remove_Occ(text_content, target_char):
    if target_char not in text_content:
        return text_content
    
    # find position of first occurrence
    first_pos = text_content.find(target_char)
    
    # find position of last occurrence
    last_pos = text_content.rfind(target_char)
    
    # create new content without first occurrence
    content_partial = text_content[:first_pos] + text_content[first_pos + 1:]
    
    # find correct position for last occurrence removal
    if first_pos == last_pos:
        return content_partial
    
    last_pos_corrected = content_partial.rfind(target_char)
    final_content = content_partial[:last_pos_corrected] + content_partial[last_pos_corrected + 1:]
    
    return final_content