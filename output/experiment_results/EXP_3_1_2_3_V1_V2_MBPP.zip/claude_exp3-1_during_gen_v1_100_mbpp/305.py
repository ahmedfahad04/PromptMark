def start_withp(phrase_collection):
    # Find terms that commence with letter 'p'
    qualified_terms = []
    
    for phrase_group in phrase_collection:
        terms_list = phrase_group.split()
        
        for term in terms_list:
            if term.lower().startswith('p'):
                qualified_terms.append(term)
                
                # Got two terms, can return now
                if len(qualified_terms) == 2:
                    return (qualified_terms[0], qualified_terms[1])
    
    # Return found terms or empty tuple
    if len(qualified_terms) >= 2:
        return (qualified_terms[0], qualified_terms[1])
    
    return ()