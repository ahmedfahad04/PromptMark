def is_sublist(original_list, target_pattern):
    # Check for contiguous occurrence of target pattern
    pattern_length = len(target_pattern)
    
    if pattern_length == 0:
        return True
    
    for current_position in range(len(original_list) - pattern_length + 1):
        found_pattern = True
        
        for pattern_pointer in range(pattern_length):
            if original_list[current_position + pattern_pointer] != target_pattern[pattern_pointer]:
                found_pattern = False
                break
        
        if found_pattern:
            return True
    
    return False