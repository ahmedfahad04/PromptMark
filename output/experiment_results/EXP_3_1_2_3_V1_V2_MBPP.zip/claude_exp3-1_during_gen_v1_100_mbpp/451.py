def remove_whitespaces(target_string):
    # Process through characters, filtering out whitespace tokens
    processed_chars = []
    for character in target_string:
        if character != ' ':
            processed_chars.append(character)
    
    # Join filtered characters to construct final output
    joined_result = ''.join(processed_chars)
    return joined_result