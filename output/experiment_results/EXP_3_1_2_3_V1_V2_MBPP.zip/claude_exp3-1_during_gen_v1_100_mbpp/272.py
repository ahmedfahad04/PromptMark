def rear_extract(tuples_collection):
    # Get final position from tuples
    final_positions = []
    for current_tuple in tuples_collection:
        # Get the position of the concluding piece
        concluding_piece = current_tuple[-1]
        final_positions.append(concluding_piece)
    return final_positions