def insert_element(original_list, prefix_item):
    # Create output collection for final result
    final_output = []
    
    # Process through original collection
    for current_item in original_list:
        # Place prefix first, then original item
        final_output.append(prefix_item)
        final_output.append(current_item)
    
    return final_output