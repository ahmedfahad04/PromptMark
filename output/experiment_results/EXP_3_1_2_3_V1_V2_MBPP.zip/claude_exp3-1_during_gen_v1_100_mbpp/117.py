def list_to_float(nested_list):
    """Process nested tuples to convert numeric text to float format"""
    processed_list = []
    
    for tuple_pair in nested_list:
        converted_tuple = []
        
        for current_token in tuple_pair:
            try:
                # Convert to float format 
                float_conversion = float(current_token)
                converted_tuple.append(float_conversion)
            except ValueError:
                # Preserve original format for non-numeric tokens
                converted_tuple.append(current_token)
        
        processed_list.append(tuple(converted_tuple))
    
    return processed_list