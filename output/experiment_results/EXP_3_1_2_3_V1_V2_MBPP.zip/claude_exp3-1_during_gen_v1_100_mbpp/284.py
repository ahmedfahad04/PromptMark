def check_element(collection, target_object):
    # Check collection contains only target_object occurrences
    for current_object in collection:
        if current_object != target_object:
            return False
    return True