def remove_dirty_chars(primary_text, filter_chars):
    # Create quick lookup for characters to filter out
    forbidden_chars = set(filter_chars)
    
    # Process each character and gather clean ones
    clean_result = []
    for current_char in primary_text:
        if current_char not in forbidden_chars:
            clean_result.append(current_char)
    
    return ''.join(clean_result)