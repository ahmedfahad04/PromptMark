def find(first_operand, q_second):
    # Calculate floor quotient of first_operand over q_second
    quotient_result = first_operand // q_second
    return quotient_result