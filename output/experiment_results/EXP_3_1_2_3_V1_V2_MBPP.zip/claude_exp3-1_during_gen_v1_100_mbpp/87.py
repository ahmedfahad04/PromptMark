def merge_dictionaries_three(first_collection, target_collection, query_collection):
    # Prepare final output collection
    output_result = {}
    
    # Process collections in proper order for correct precedence
    for current_collection in [first_collection, target_collection, query_collection]:
        for grid_position, grid_content in current_collection.items():
            output_result[grid_position] = grid_content
    
    return output_result