def tuple_intersection(first_tuple_collection, other_tuple_collection):
    # Function to normalize tuple ordering for comparison
    def normalize_tuple_pair(tuple_pair):
        return tuple(sorted(tuple_pair))
    
    # Convert first collection to normalized tuples
    first_normalized_collection = {normalize_tuple_pair(tuple_pair) for tuple_pair in first_tuple_collection}
    
    # Convert other collection to normalized tuples  
    other_normalized_collection = {normalize_tuple_pair(tuple_pair) for tuple_pair in other_tuple_collection}
    
    # Get common normalized tuples
    common_normalized_pairs = first_normalized_collection & other_normalized_collection
    
    return common_normalized_pairs