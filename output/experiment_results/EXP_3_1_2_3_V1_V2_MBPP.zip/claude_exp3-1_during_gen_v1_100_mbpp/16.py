def text_lowercase_underscore(text_content):
    # Check for lowercase letter groups joined only by one or more letters
    for character_position in range(len(text_content)):
        current_letter = text_content[character_position]
        
        # Only proceed for lowercase or permitted join character
        if current_letter == '_':
            continue
        elif current_letter.islower():
            continue
        else:
            return False
    
    # Check that format contains proper letter groups
    if '_' not in text_content:
        return False
    
    # Groups of letters need to connect through one or more letters
    groups_of_letters = text_content.split('_')
    
    for group_part in groups_of_letters:
        if not group_part:
            return False
        for character_position in group_part:
            if not character_position.islower():
                return False
    
    return True