def extract_nth_element(tuple_list, position):
    # Create output list for collecting nth position from tuples
    output_collection = []
    
    for current_tuple in tuple_list:
        # Get the nth position from current tuple
        nth_position_content = current_tuple[position]
        output_collection.append(nth_position_content)
    
    return output_collection