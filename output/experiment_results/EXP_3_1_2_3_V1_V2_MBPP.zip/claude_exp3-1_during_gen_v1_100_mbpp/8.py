def square_nums(numbers_list):
    # Process collection to generate quadratic results
    quadratic_results = []
    
    # Parse through collection, calculate quadratic for respective number
    for current_number in numbers_list:
        quadratic_product = current_number * current_number
        quadratic_results.append(quadratic_product)
    
    return quadratic_results