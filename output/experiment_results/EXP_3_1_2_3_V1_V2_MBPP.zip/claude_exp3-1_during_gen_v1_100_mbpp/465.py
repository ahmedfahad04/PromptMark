def drop_empty(original_dict):
    # Filter out None or empty content from the original
    filtered_content = {}
    
    for current_key, current_value in original_dict.items():
        if current_value is not None:
            filtered_content[current_key] = current_value
    
    return filtered_content