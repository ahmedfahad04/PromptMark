def left_insertion(target_list, target_value):
    # Get left point of target_value to place the given target_value
    left_point = 0
    right_point = len(target_list)
    
    # Find correct position using looping logic
    while left_point < right_point:
        center_point = (left_point + right_point) // 2
        
        if target_list[center_point] < target_value:
            left_point = center_point + 1
        else:
            right_point = center_point
    
    return left_point