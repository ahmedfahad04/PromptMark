def replace_char(original_text, target_char, replacement_char):
    # Process character replacement through text traversal
    resulting_chars = []
    for current_char in original_text:
        if current_char == target_char:
            resulting_chars.append(replacement_char)
        else:
            resulting_chars.append(current_char)
    
    # Join processed characters to form final text
    final_output = ''.join(resulting_chars)
    return final_output