def largest_subset(numbers):
    if not numbers:
        return 0
    
    # order numbers from least to greatest
    numbers.sort()
    
    # track maximum count for final output
    max_count = 1
    n = len(numbers)
    
    # qurrent_length records longest chain terminating per position
    qurrent_length = [1] * n
    
    for j in range(1, n):
        for prev_position in range(j):
            # check pair compatibility: current number splits cleanly from prior
            if numbers[j] % numbers[prev_position] == 0:
                qurrent_length[j] = max(qurrent_length[j], qurrent_length[prev_position] + 1)
        
        # refresh global count
        max_count = max(max_count, qurrent_length[j])
    
    return max_count