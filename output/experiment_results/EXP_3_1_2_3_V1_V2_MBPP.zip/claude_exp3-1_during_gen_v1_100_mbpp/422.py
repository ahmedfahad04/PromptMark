def find_Average_Of_Cube(n):
    # Calculate total of cubes for first n natural numbers
    total_of_cubes = 0
    for current_position in range(1, n + 1):
        cube_of_current = current_position ** 3
        total_of_cubes += cube_of_current
    
    # Final calculation of ratio
    ratio_result = total_of_cubes / n
    return ratio_result