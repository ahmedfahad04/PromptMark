def extract_string(text_collection, target_length):
    # Filter text entries that exactly match the required character count
    filtered_results = []
    for current_text in text_collection:
        if len(current_text) == target_length:
            filtered_results.append(current_text)
    return filtered_results