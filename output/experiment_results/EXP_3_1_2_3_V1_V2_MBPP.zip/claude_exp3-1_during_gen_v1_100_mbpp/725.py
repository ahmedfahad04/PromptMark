def extract_quotation(text_content):
    # Parse content to find quoted portions
    quoted_portions = []
    current_position = 0
    
    while current_position < len(text_content):
        # Locate opening quote
        opening_quote_position = text_content.find('"', current_position)
        
        if opening_quote_position == -1:
            break
        
        # Find corresponding closing quote
        closing_quote_position = text_content.find('"', opening_quote_position + 1)
        
        if closing_quote_position == -1:
            break
        
        # Get content from quotation pair
        quoted_text = text_content[opening_quote_position + 1:closing_quote_position]
        quoted_portions.append(quoted_text)
        
        # Continue from position past closing quote
        current_position = closing_quote_position + 1
    
    return quoted_portions