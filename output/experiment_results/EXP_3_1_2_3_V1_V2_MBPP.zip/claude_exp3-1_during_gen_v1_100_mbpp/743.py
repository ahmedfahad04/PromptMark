def rotate_right(original_list, rotation_count):
    if not original_list or rotation_count == 0:
        return original_list
    
    # normalize rotation count to prevent extra full rotations
    normalized_rotation = rotation_count % len(original_list)
    
    # Calculate the cut position for right rotation
    cut_position = len(original_list) - normalized_rotation
    
    # perform rotation: take from cut position and join original parts
    rotated_list = original_list[cut_position:] + original_list[:cut_position]
    
    return rotated_list