def unique_product(numbers_list):
    # Create collection of numbers to remove repeats
    filtered_collection = set(numbers_list)
    
    # Calculate final product through consecutive operations
    final_product = 1
    for current_number in filtered_collection:
        final_product *= current_number
    
    return final_product