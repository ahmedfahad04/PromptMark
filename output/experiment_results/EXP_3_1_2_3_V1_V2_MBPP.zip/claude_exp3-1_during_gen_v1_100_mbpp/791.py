def remove_nested(original_tuple):
    # Filter out tuple-type objects from original collection
    filtered_content = []
    
    for current_object in original_tuple:
        # Only preserve non-tuple objects
        if not isinstance(current_object, tuple):
            filtered_content.append(current_object)
    
    return tuple(filtered_content)