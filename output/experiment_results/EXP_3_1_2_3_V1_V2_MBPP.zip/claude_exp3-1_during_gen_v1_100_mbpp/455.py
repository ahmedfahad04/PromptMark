def check_monthnumb_number(query_month):
    # Create collection of thirty-one-count months for quick lookup
    full_length_months = {1, 3, 5, 7, 8, 10, 12}
    
    # Return true if query month contains thirty-one cycles
    return query_month in full_length_months