def test_three_equal(first_number, second_number, third_number):
    # Count occurrences of each number
    counter_first = 1
    counter_second = 1 if second_number == first_number else 0
    counter_third = 1 if third_number == first_number else 0
    
    first_total = counter_first + counter_second + counter_third
    
    if first_total >= 2:
        return first_total
    
    # Check for pairs not involving first number
    counter_pair = 2 if second_number == third_number else 0
    
    return counter_pair