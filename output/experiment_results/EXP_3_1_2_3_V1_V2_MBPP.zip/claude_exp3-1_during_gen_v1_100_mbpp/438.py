def count_bidirectional(tuple_list):
    # Count occurrences of normalized tuple pairs
    pair_counts = {}
    
    for current_tuple in tuple_list:
        first_num, next_num = current_tuple
        # Create normalized form of tuple pair
        normalized_pair = tuple(sorted([first_num, next_num]))
        
        if normalized_pair in pair_counts:
            pair_counts[normalized_pair] += 1
        else:
            pair_counts[normalized_pair] = 1
    
    # Calculate total pairs from counts
    total_pairs = 0
    for pair_count in pair_counts.values():
        # Generate combinations of count taken 2
        total_pairs += pair_count * (pair_count - 1) // 2
    
    return total_pairs