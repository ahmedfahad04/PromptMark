def Find_Min(collection_of_records):
    # Find record with fewest count
    quickest_record = collection_of_records[0]
    
    for current_record in collection_of_records:
        # Compare record counts to find minimal one
        if len(current_record) < len(quickest_record):
            quickest_record = current_record
    
    return quickest_record