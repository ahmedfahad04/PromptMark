def Find_Max_Length(nested_list):
    # Track longest count found
    longest_count = 0
    
    # Check each nested collection
    for current_list in nested_list:
        current_length = len(current_list)
        # Compare current group length to record
        if current_length > longest_count:
            longest_count = current_length
    
    return longest_count