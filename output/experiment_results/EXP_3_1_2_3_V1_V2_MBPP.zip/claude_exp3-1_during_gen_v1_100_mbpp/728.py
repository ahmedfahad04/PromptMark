def sum_list(first_numbers, other_numbers):
    # Create result list containing paired totals
    paired_totals = []
    for position in range(len(first_numbers)):
        current_total = first_numbers[position] + other_numbers[position]
        paired_totals.append(current_total)
    return paired_totals