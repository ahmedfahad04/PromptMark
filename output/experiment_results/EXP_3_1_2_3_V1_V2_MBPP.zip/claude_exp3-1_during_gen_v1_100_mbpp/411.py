def snake_to_camel(text_content):
    #plit on underscores to get component parts
    fragment_list = text_content.split('_')
    
    # capitalize first letter of each fragment part
    capitalized_fragments = []
    for piece in fragment_list:
        if piece:  # only process non-empty fragments
            capitalized_fragments.append(piece.capitalize())
    
    # join fragments together for final result
    return ''.join(capitalized_fragments)