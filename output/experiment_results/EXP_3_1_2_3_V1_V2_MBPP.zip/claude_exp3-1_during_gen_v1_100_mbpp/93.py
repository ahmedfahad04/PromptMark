def power(foundation_number, raised_power):
    # Calculate power through repeated multiplication for correct results
    computed_result = 1
    for repetition_count in range(raised_power):
        computed_result *= foundation_number
    return computed_result