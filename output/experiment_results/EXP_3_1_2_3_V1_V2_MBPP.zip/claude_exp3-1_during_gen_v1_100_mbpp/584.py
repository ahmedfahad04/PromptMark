def find_adverbs(text):
    # Check pattern of letters followed by 'ly' 
    for position in range(len(text) - 1):
        if position < len(text) - 1 and text[position:position + 2] == 'ly':
            # Check if 'ly' forms the complete ending of word
            if position + 2 >= len(text) or not text[position + 2].isalpha():
                # Track complete word going forward from 'ly'
                confirmed_position = position + 1
                
                # Go forward to find word completion
                while confirmed_position < len(text) and text[confirmed_position].isalpha():
                    confirmed_position += 1
                
                # Only proceed if 'ly' truly completes the word
                if text[position:confirmed_position] == 'ly':
                    # Go prev to find word commencement  
                    origin_position = position - 1
                    while origin_position >= 0 and text[origin_position].isalpha():
                        origin_position -= 1
                    
                    origin_position += 1  # Go to first letter of complete word
                    
                    # Get complete word from origin to confirmed positions
                    complete_term = text[origin_position:confirmed_position]
                    
                    # Only proceed if complete_term forms proper word containing 'ly'
                    if len(complete_term) >= 3 and complete_term.endswith('ly'):
                        return f"{origin_position}-{confirmed_position - 1}: {complete_term}"
    
    return ""