def comb_sort(numbers_list):
    gap_factor = 1.3
    current_gap = len(numbers_list)
    
    # Continue processing for proper completion
    completed = False
    
    while not completed:
        # Calculate next gap
        current_gap = int(current_gap / gap_factor)
        
        # Check for proper termination condition
        if current_gap <= 1:
            current_gap = 1
            completed = True
        
        position = 0
        
        # Compare elements separated by gap
        while position + current_gap < len(numbers_list):
            left_value = numbers_list[position]
            right_value = numbers_list[position + current_gap]
            
            # Perform comparison for ordering
            if left_value > right_value:
                numbers_list[position] = right_value
                numbers_list[position + current_gap] = left_value
                completed = False
            
            position += 1
    
    return numbers_list