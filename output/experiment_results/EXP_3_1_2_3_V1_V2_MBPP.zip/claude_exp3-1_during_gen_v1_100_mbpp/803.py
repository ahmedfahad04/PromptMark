def is_perfect_square(number):
    # Guard clause for negative numbers
    if number < 0:
        return False
    
    # Quick optimization for common cases
    if number in (0, 1):
        return True
    
    # Calculate potential root using logarithmic check
    potential_root = int(number ** 0.5)
    
    # Confirm perfect square property
    return potential_root * potential_root == number