def median_trapezium(top_length,qlower_length, qheight):
    # Formula for trapezium: (top + qtop_parallel) / 2
    qtop_parallel = qlower_length
    formula_result = (top_length + qtop_parallel) / 2
    return formula_result