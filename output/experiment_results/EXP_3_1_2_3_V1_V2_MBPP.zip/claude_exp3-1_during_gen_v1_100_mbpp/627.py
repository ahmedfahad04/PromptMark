def find_First_Missing(number_list):
    # Convert to organized collection for quick lookup
    number_collection = set(number_list)
    
    # Quest for the first gap in natural progression
    current_position = 0
    
    # Progress through natural count checking for gaps
    for position_counter in range(len(number_list) + 1):
        if current_position not in number_collection:
            return current_position
        current_position += 1
    
    return current_position