def count_Substrings(text_content):
    total_count = 0
    
    for o in range(len(text_content)):
        current_digit_total = 0
        for j in range(o, len(text_content)):
            current_digit_total += int(text_content[j])
            current_length = j - o + 1
            
            # Check condition: total of digit contents equals current length
            if current_digit_total == current_length:
                total_count += 1
    
    return total_count