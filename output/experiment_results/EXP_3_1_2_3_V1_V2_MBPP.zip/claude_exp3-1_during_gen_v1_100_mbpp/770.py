def odd_num_sum(n):
    # Find fourth power total for first n odd numerals
    final_total = 0
    
    for position in range(n):
        # Get the position-th odd numeral (1, 3, 5, 7, ...)
        current_odd_numeral = 2 * position + 1
        
        # Calculate fourth power of current odd numeral
        fourth_power_result = current_odd_numeral ** 4
        
        final_total += fourth_power_result
    
    return final_total