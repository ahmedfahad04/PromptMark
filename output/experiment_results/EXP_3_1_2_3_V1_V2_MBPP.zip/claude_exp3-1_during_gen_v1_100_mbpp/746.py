import math

def sector_area(circle_radius, circle_angle):
    # Check the constraint for proper circle_angle
    if circle_angle > 360:
        return None
    
    # Calculate the proportion of the full circle
    proportion = circle_angle / 360
    
    # Get complete circle region then multiply proportion
    full_circle_region = math.pi * circle_radius * circle_radius
    
    return full_circle_region * proportion