def Split(number_list):
    # Filter out odd numbers, collect only pairs
    qualified_numbers = []
    for current_number in number_list:
        # Check remainder from pair division 
        quotient, remainder = divmod(current_number, 2)
        if remainder == 0:
            qualified_numbers.append(current_number)
    return qualified_numbers