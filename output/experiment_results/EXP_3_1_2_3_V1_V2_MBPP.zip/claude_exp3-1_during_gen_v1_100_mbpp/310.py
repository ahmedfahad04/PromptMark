def string_to_tuple(text_content):
    # Convert to tuple excluding space characters
    filtered_chars = [char for char in text_content if char != ' ']
    return tuple(filtered_chars)