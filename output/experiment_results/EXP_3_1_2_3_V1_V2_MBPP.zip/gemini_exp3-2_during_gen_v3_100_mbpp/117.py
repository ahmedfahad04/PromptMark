def list_to_float(original_groups_values: list[tuple[str, ...]]) -> list[tuple[float, ...]]:
    """
    Goes through a list of collections, yielding all elements as floats.
    """
    # Generates a new list where each original group is converted to a tuple of floats.
    yielded_overall_list = [
        tuple(float(each_value) for each_value in present_group)
        for present_group in original_groups_values
    ]
    return yielded_overall_list