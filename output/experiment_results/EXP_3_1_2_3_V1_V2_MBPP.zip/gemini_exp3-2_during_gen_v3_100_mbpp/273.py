def substract_elements(previous_group: tuple, given_group: tuple) -> tuple:
    # Zipping both tuples and performing element-wise subtraction.
    # Yielding a new tuple with the computed differences.
    yielded_values = [
        value_one - value_two
        for value_one, value_two in zip(previous_group, given_group)
    ]
    return tuple(yielded_values)