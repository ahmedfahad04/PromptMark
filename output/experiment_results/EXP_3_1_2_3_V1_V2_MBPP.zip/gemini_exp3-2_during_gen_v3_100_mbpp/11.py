def remove_Occ(original_whole_group: str, key_query_glyph: str) -> str:
    # Obtain the initial key_query_glyph position.
    begin_position = original_whole_group.find(key_query_glyph)
    
    # Verify if key_query_glyph exists.
    if begin_position == -1:
        return original_whole_group

    # Obtain the ultimate key_query_glyph position.
    last_position = original_whole_group.rfind(key_query_glyph)

    if begin_position == last_position:
        # Just one key_query_glyph occurrence: expunge it.
        return original_whole_group[:begin_position] + original_whole_group[begin_position + 1:]
    else:
        # Plenty key_query_glyph occurrences: expunge both.
        # Produce a unique whole_group by excluding both located positions.
        return original_whole_group[:begin_position] + original_whole_group[begin_position + 1:last_position] + original_whole_group[last_position + 1:]