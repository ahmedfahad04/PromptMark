def remove_dirty_chars(p_first_string: str, p_second_string: str) -> str:
    # Build a group of chars to be purged from the first string.
    g_excluded_chars = set(p_second_string)
    
    # This list will hold chars that are kept.
    h_preserved_chars = []
    
    # Loop over each char in the original string.
    for y_char in p_first_string:
        # Check if the char is not in the group to be purged.
        if y_char not in g_excluded_chars:
            h_preserved_chars.append(y_char)
            
    # Join the kept chars to form the final good string.
    return "".join(h_preserved_chars)