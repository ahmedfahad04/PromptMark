def count_X(y_tuple, g_element):
    p_count = 0  # Zero the occurrences counter.
    # Go over each value within the given tuple.
    for o_value in y_tuple:
        # Query if the current value equals the given element.
        if o_value == g_element:
            # Plus the count when values are equal.
            p_count += 1
    # Yield the final count.
    return p_count