def perimeter_pentagon(length_value: int) -> int:
    # Obtains pentagon perimeter.
    # length_value: One edge's value.
    
    pent_quantity = 5  # Quantity of edges.
    perimeter_output = pent_quantity * length_value
    
    return perimeter_output