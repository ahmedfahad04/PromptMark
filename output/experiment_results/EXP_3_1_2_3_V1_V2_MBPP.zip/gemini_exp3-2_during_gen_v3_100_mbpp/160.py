def pegcd(value_a, value_b):
    # Produces (g, x, y) such that value_a*x + value_b*y = g = gcd(value_a, value_b).
    if value_a == 0:
        return (value_b, 0, 1)
    
    y_g, x_previous, y_previous = pegcd(value_b % value_a, value_a)
    current_x = y_previous - (value_b // value_a) * x_previous
    current_y = x_previous
    return (y_g, current_x, current_y)

def find_solution(value_a, value_b, value_n):
    # Handle edge case: both coefficients value_a, value_b zero.
    if value_a == 0 and value_b == 0:
        if value_n == 0:
            return (0, 0) # Any (x, y) works, produce a basic one.
        else:
            return None # 0x + 0y = n cannot be solved if n != 0.

    # Handle edge case: only value_a zero.
    if value_a == 0:
        if value_n % value_b == 0:
            return (0, value_n // value_b)
        else:
            return None

    # Handle edge case: only value_b zero.
    if value_b == 0:
        if value_n % value_a == 0:
            return (value_n // value_a, 0)
        else:
            return None

    # General case: both coefficients value_a, value_b non-zero.
    # Utilize Extended Euclidean Algorithm.
    gcd_val, param_x, param_y = pegcd(value_a, value_b)

    # Verify if a solution exists.
    if value_n % gcd_val != 0:
        return None

    # Compute a particular solution.
    # Scale x, y by value_n / gcd_val.
    factor_q = value_n // gcd_val
    particular_x = param_x * factor_q
    particular_y = param_y * factor_q

    # Adjust to procure smallest non-negative x.
    # General solutions: x = particular_x + k * (value_b / gcd_val)
    #                    y = particular_y - k * (value_a / gcd_val)
    
    # Calculate the normalized coefficients for k.
    beta_coefficient = value_b // gcd_val 
    alpha_coefficient = value_a // gcd_val

    # Python's % operator naturally yields a result with the same sign as the divisor (beta_coefficient),
    # which ensures final_x is in [0, beta_coefficient - 1] if beta_coefficient is positive.
    final_x = particular_x % beta_coefficient

    # Compute k_adjustment_val to shift particular_x towards final_x.
    k_adjustment_val = (final_x - particular_x) // beta_coefficient
    
    # Compute corresponding y-value.
    final_y = particular_y - k_adjustment_val * alpha_coefficient

    return (final_x, final_y)