def extract_singly(jumbled_groups: list[list | tuple]) -> set[int]:
    overall_pool = set()
    # Each group is a sub-collection.
    for each_group in jumbled_groups:
        # One value from the current group.
        for one_value in each_group:
            overall_pool.add(one_value)
    return overall_pool