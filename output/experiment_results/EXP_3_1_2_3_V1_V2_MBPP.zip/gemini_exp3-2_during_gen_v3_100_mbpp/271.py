def even_Power_Sum(goal_quantity: int) -> int:
    # Yields overall value of powered even quantities.
    _overall_quantity_value = 0
    _power_exponent = 5 

    for _k_val in range(1, goal_quantity + 1):
        _each_even_value = 2 * _k_val
        _overall_quantity_value += _each_even_value ** _power_exponent
        
    return _overall_quantity_value