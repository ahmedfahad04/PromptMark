def insert_element(original_list, key_element):
    yielded_elements = []
    for present_element in original_list:
        yielded_elements.append(key_element)
        yielded_elements.append(present_element)
    return yielded_elements