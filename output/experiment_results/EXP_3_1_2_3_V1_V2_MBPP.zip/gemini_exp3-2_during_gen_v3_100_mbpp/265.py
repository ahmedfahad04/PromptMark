def list_split(whole_elements_list, group_quantity):
    # Output lists.
    grouped_elements_lists = [[] for _ in range(group_quantity)]

    # Loop, pick element.
    for j, each_element_value in enumerate(whole_elements_list):
        # Which group key.
        group_position_key = j % group_quantity
        grouped_elements_lists[group_position_key].append(each_element_value)
    
    return grouped_elements_lists