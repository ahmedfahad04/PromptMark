def sum_even_and_even_index(given_list: list) -> int:
    # Gathers overall value of even numbers found at even positions.
    grand_total = 0
    whole_length = len(given_list)

    # Goes over each element using its positional index.
    for j_pos in range(whole_length):
        # Evaluates if j_pos (position) is even and if the value at j_pos is even.
        if j_pos % 2 == 0 and given_list[j_pos] % 2 == 0:
            grand_total += given_list[j_pos]

    return grand_total