def sum_range_list(whole_list: list[int], low_bound_idx: int, high_bound_idx: int) -> int:
    """Gathers good sum of values present within a given position limit in a list."""
    present_sum = 0 # Keeps good value

    # Loops via 'low_bound_idx' up unto 'high_bound_idx', keeping both.
    # Python's 'range()' excludes end value, which obliges '+ 1'.
    for j in range(low_bound_idx, high_bound_idx + 1):
        present_sum += whole_list[j]
    return present_sum