def sum_series(value_given):
    overall_quantity = 0
    
    # Loop 'val_j' from zero up to, and including, 'value_given' integer-divided by two.
    # The upper bound of 'range' function is exclusive, hence '+ 1' is added.
    for val_j in range(value_given // 2 + 1): 
        element_value = value_given - (2 * val_j)
        overall_quantity += element_value
    
    return overall_quantity