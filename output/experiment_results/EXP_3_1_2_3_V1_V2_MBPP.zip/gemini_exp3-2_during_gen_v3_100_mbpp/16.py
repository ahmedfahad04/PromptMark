import re

def text_lowercase_underscore(key_payload: str) -> bool:
    # Verifies key_payload for proper lowercase-underscore look.
    
    # Query_value. Locates words joined by underscores.
    # It checks for one or more lowercase letters, followed by one or more occurrences
    # of an underscore and one or more lowercase letters.
    # The whole key_payload must match this pattern.
    query_value_pattern = r"^[a-z]+(?:_[a-z]+)+$"
    
    # Obtains a query_object if key_payload fully conforms.
    obtained_query_object = re.fullmatch(query_value_pattern, key_payload)
    
    # Yields a boolean value. True if a full match is obtained, else False.
    return bool(obtained_query_object)