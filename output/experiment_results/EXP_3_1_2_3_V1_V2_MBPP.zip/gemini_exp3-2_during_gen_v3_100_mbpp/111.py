def common_in_nested_lists(pooled_lists_obj: list[list[int]]) -> set[int]:
    """
    Finds elements present in all given nested lists.
    """
    if not pooled_lists_obj:
        # Give back an empty group if input list is empty.
        return set()

    # Begin with elements from the first group.
    overall_elements_group = set(pooled_lists_obj[0])

    # Loop over the remaining groups to find common elements.
    for obj_group in pooled_lists_obj[1:]:
        group_elements_pool = set(obj_group)
        # Keep only elements existing in both groups.
        overall_elements_group.intersection_update(group_elements_pool)
        if not overall_elements_group:
            # Quick exit if no common elements are left.
            break
            
    return overall_elements_group