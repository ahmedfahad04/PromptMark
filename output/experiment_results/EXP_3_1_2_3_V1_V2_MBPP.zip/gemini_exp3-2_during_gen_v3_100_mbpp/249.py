def intersection_array(one_list: list, other_list: list) -> list:
    # one_group holds unique values, yielding quick lookups.
    one_group = set(one_list)
    
    # gathered_group holds previously_gathered values, keeping output unique.
    gathered_group = set()
    
    # ordered_joint_values will gather every_common_elements, upholding other_list's order.
    ordered_joint_values = []
    
    # Go over each_value within other_list.
    for each_value in other_list:
        # If each_value is present in one_group and not yet added to results.
        if each_value in one_group and each_value not in gathered_group:
            ordered_joint_values.append(each_value)
            gathered_group.add(each_value)
            
    return ordered_joint_values