def square_Sum(key_qty: int) -> int:
    # overall_value will have elevated values.
    overall_value = 0
    # loop key_qty quantity, generating odd values.
    for j in range(key_qty):
        # yield j-th odd value.
        odd_val_j = 2 * j + 1
        # elevate key odd_val_j value.
        elevated_val = odd_val_j * odd_val_j
        # put elevated_val with overall_value.
        overall_value = overall_value + elevated_val
    return overall_value