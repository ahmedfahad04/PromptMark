def rear_extract(objects_group: list[tuple]) -> list:
    # Build output group.
    output_group = []
    # Go via objects group.
    for whole_pair in objects_group:
        # Get last element.
        last_element_of_pair = whole_pair[-1]
        # Put element, build output.
        output_group.append(last_element_of_pair)
    return output_group