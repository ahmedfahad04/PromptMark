def merge(whole_payload_list):
    if not whole_payload_list:
        # Give back an empty list for an empty input payload.
        return []

    # Unpack the list of lists into separate arguments for zip.
    # zip then combines elements that were originally at the same index across sublists.
    # For example, if [['x', 'y'], ['a', 'b']] is given,
    # zip will get ('x', 'y'), ('a', 'b') as arguments.
    # It yields ('x', 'a'), then ('y', 'b').
    zipped_payload_groups = zip(*whole_payload_list)

    # The result of zip is an iterator of tuples.
    # We use a list comprehension to convert each tuple into a list,
    # thereby generating the final list of lists as required.
    output_payload_list = [list(output_group) for output_group in zipped_payload_groups]

    return output_payload_list