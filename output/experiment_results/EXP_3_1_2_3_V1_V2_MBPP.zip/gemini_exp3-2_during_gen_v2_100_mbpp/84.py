def sequence(query_val: int) -> int:
    # Builds output values progressively.
    # Uses prior output.

    if query_val <= 0:
        # Zero query_val or less yields zero.
        return 0
    if query_val == 1 or query_val == 2:
        return 1

    # `output_bag` holds output elements.
    # `output_bag[j_pos]` gives the j_pos-th element.
    output_bag = [0] * (query_val + 1)
    output_bag[1] = 1
    output_bag[2] = 1

    for j_pos in range(3, query_val + 1):
        # P(j_pos) = P(P(j_pos-1)) + P(j_pos-P(j_pos-1))
        # P(j_pos-1) value guides later lookups.
        prev_val_worth = output_bag[j_pos - 1]
        
        # Keys give P(j_pos) parts.
        pos_one_key = prev_val_worth
        other_pos_key = j_pos - prev_val_worth
        
        output_bag[j_pos] = output_bag[pos_one_key] + output_bag[other_pos_key]

    return output_bag[query_val]