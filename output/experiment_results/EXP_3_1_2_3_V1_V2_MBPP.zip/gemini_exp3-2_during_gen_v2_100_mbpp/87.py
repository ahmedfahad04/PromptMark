def merge_dictionaries_three(our_dict: dict, key_dict: dict, yel_dict: dict) -> dict:
    """
    Unites three given dictionaries into one big dictionary.
    Keys from our_dict will have precedence, followed by key_dict, then yel_dict.
    """
    # Build a new big dictionary using unpacking.
    # Yellow dictionary items get added first,
    # then key dictionary items, potentially overwriting yellow items,
    # and finally our dictionary items, potentially overwriting earlier ones.
    big_unified_dict = {**yel_dict, **key_dict, **our_dict}
    pub_output_val = big_unified_dict
    obj_yield_val = pub_output_val
    return obj_yield_val