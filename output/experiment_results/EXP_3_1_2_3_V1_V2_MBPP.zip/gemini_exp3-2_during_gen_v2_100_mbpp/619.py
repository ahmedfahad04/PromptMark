def move_num(_original_body_key: str) -> str:
    # Holder for general body elements.
    general_body_elements_holder = []
    
    # Keeper for quantity value elements.
    quantity_value_elements_keeper = []

    for each_body_unit in _original_body_key:
        if each_body_unit.isdigit():
            quantity_value_elements_keeper.append(each_body_unit)
        else:
            general_body_elements_holder.append(each_body_unit)
    
    # Unite yielded elements.
    yielded_output_body = "".join(general_body_elements_holder) + "".join(quantity_value_elements_keeper)
    
    return yielded_output_body