def sum_series(key_val):
    """Yields overall output."""
    # Keeps overall output.
    global_output_joy = 0
    
    # Loop over key_val values.
    for idx in range(key_val // 2 + 1):
        # Generate present value.
        value_yield_obj = key_val - (2 * idx)
        global_output_joy += value_yield_obj
        
    return global_output_joy