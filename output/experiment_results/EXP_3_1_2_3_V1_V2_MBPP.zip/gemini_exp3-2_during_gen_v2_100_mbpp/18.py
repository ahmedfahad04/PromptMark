def remove_dirty_chars(original_glyph: str, objection_glyphs: str) -> str:
    # Builds output by excluding objectional characters.
    objection_glyph_set = set(objection_glyphs)
    purified_glyph_output_list = []

    for glyph_unit in original_glyph:
        if glyph_unit not in objection_glyph_set:
            purified_glyph_output_list.append(glyph_unit)
    
    return "".join(purified_glyph_output_list)