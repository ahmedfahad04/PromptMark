def find_First_Missing(ordered_list: list[int]) -> int:
    # Quick check for the beginning.
    # Obvious case: if the list doesn't begin with zero, then zero is what's gone.
    if not ordered_list or ordered_list[0] != 0:
        return 0

    # Go through the list, element by element.
    # Juggling through each position.
    for juggler_index, present_value in enumerate(ordered_list):
        # We expect present_value to be equal to its index.
        # Yet that's not, we've found our gap.
        if present_value != juggler_index:
            return juggler_index

    # Yet we exit the loop, it implies all numbers from 0 up to
    # the list's length minus one are present.
    # Hence, the next number (equal to the list's length) is what's missing.
    # Yield the list's length as the value.
    return len(ordered_list)