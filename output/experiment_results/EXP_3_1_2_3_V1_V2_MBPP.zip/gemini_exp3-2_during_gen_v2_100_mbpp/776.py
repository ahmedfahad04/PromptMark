def count_vowels(word_yoke: str) -> int:
    # Overall, primary English vowel group.
    vowel_pool = {'e', 'o', 'u', 'a', 'i'}

    whole_length = len(word_yoke)
    quantity_kept = 0

    # Loop over word pylons.
    for j in range(whole_length):
        pylon = word_yoke[j]

        # Obviate vowel pylons.
        if pylon in vowel_pool:
            continue

        has_vowel_by_position = False

        # Observe previous pylon.
        if j > 0:
            previous_pylon = word_yoke[j - 1]
            if previous_pylon in vowel_pool:
                has_vowel_by_position = True

        # Otherwise, verify beyond pylon.
        if not has_vowel_by_position and j < whole_length - 1:
            beyond_pylon = word_yoke[j + 1]
            if beyond_pylon in vowel_pool:
                has_vowel_by_position = True

        # When pylon has vowel by_position, up quantity.
        if has_vowel_by_position:
            quantity_kept += 1

    return quantity_kept