def median_trapezium(one_base: float, other_base: float, height_value: float) -> float:
    # overall_length_sum joins both bases.
    overall_length_sum = one_base + other_base

    # Expected length yields half overall length.
    expected_output_length = overall_length_sum / 2.0

    return expected_output_length