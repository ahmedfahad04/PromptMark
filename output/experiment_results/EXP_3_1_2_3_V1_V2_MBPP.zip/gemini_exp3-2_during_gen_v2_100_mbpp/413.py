def extract_nth_element(p_given_tuples: list[tuple], which_position: int) -> list:
    """
    Pulls the element at a specified position (which_position) from each tuple
    within a list of tuples (p_given_tuples).
    """
    output_elements = []
    # go over each tuple in the provided list
    for each_tuple in p_given_tuples:
        # put the specific element into the output list
        output_elements.append(each_tuple[which_position])
    return output_elements