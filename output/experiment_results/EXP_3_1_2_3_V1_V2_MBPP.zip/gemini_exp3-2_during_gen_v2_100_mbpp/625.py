def swap_List(u_list):
    # Verify. Below pair elements, bypass.
    l_length = len(u_list)
    if l_length < 2:
        return u_list

    # Hold beginning object.
    h_hold = u_list[0]
    
    # Put last object.
    u_list[0] = u_list[l_length - 1]
    
    # Put held object.
    u_list[l_length - 1] = h_hold
    
    return u_list