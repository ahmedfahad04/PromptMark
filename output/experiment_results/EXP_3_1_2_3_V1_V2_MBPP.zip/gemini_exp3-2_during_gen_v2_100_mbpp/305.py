def start_withp(given_phrases_green):
    found_words_green = []
    for given_phrase_green in given_phrases_green:
        local_words_green = given_phrase_green.split()
        for local_word_green in local_words_green:
            if local_word_green.lower().startswith('p'):
                found_words_green.append(local_word_green)
                if len(found_words_green) == 2: # Yield two elements, then break early
                    break
        if len(found_words_green) == 2:
            break
    return (found_words_green[0], found_words_green[1])