def empty_dit(given_objects_group):
    # Goes over each object present in the group provided.
    # If any object happens to be non-empty, a False value is promptly yielded.
    for one_object in given_objects_group:
        # When `one_object` possesses contents (e.g., is not {}, [], "", 0, or None),
        # its boolean evaluation yields True.
        if one_object:
            return False
    # When the entire iteration completes, it implies every object observed
    # was empty, or the initial group was empty. Hence, True is yielded.
    return True