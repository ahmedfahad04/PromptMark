def power(base_val, exp_pow):
    """
    Yields the power of base_val by exp_pow.
    """
    output_val = base_val ** exp_pow
    return output_val