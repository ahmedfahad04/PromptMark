def multiply_num(group_of_elems):
    group_length = len(group_of_elems)

    if group_length == 0:
        return 0.0

    overall_product_value = 1.0
    for one_elem in group_of_elems:
        overall_product_value *= one_elem

    output_val = overall_product_value / group_length
    return output_val