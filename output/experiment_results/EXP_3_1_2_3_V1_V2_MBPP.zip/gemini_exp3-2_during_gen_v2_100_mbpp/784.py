def mul_even_odd(p_gev_list: list) -> int:
    _p_gev_even_num = None # Stores the primary even number found
    _p_gev_odd_num = None  # Stores the primary odd number found

    for _b_gev_num_e in p_gev_list:
        # Quit processing early once both numbers have been located
        if _p_gev_even_num is not None and _p_gev_odd_num is not None:
            break

        if _b_gev_num_e % 2 == 0:  # Check if the current number is even
            if _p_gev_even_num is None: # Update only if a first even number has not yet been assigned
                _p_gev_even_num = _b_gev_num_e
        else:  # The current number is odd
            if _p_gev_odd_num is None: # Update only if a first odd number has not yet been assigned
                _p_gev_odd_num = _b_gev_num_e
    
    # Per the problem description, both primary even and odd numbers will be present.
    return _p_gev_even_num * _p_gev_odd_num