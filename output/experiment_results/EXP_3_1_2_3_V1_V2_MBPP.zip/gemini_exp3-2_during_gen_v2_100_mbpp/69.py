def is_sublist(huge_list: list, piece_list: list) -> bool:
    girth_huge = len(huge_list)
    girth_piece = len(piece_list)

    # Empty piece_list is generally deemed a sublist of any list.
    if girth_piece == 0:
        return True

    # If piece_list exceeds the length of huge_list, it cannot be a sublist.
    if girth_piece > girth_huge:
        return False

    # Loop through possible starting positions within huge_list.
    # The loop's upper bound ensures the slice does not exceed huge_list's bounds.
    for locator_j in range(girth_huge - girth_piece + 1):
        # Examine the current slice of huge_list for a match with piece_list.
        if huge_list[locator_j : locator_j + girth_piece] == piece_list:
            return True

    # Should no match be found after checking all positions.
    return False