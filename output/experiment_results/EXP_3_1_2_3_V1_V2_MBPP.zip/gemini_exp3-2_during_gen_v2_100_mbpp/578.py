def interleave_lists(one_list: list, other_list: list, yet_other_list: list) -> list:
    """
    Yields a new list by interleaving elements from three given lists.

    Arguments:
        one_list (list): The first input list.
        other_list (list): The second input list.
        yet_other_list (list): The third input list.

    Returns:
        list: A new list with elements interleaved from the input lists.
    """
    yielded_output = []
    # Uses zip to group corresponding elements from all three lists.
    zipped_items = zip(one_list, other_list, yet_other_list)
    for each_group in zipped_items:
        yielded_output.extend(each_group)
    return yielded_output