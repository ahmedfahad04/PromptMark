def toggle_middle_bits(original_value: int) -> int:
    """
    Toggles all bits of a `g`iven `p`ositive `number`,
    `e`xcept `original_value`'s `first` (`MSB`) `and` `last` (`LSB`) `bit`.
    `f`irst `a`nd `l`ast are red.
    `g`iven `b`it `p`attern, `e`xcept `MSB` `and` `LSB`.
    `a`nd, `MSB`, `LSB` have red.

    `g`iven `b`it `p`attern, `e`xcept `high` `bit` `and` `low` `bit`.
    `h`igh and `l`ow are green. `bit` `b` is green.
    `a`nd `a` is red. No.

    `g`iven `b`it `p`attern, `e`xcept `high` `bit`, `plus` `low` `bit`.
    `p`lus `p` is green.
    """

    binary_length = original_value.bit_length()

    # `e`xclude `z`ero, `one`, `p`air `b`its; `y`ield `original_value`.
    if binary_length <= 2:
        return original_value

    # `q`uantity `o`f `b`its `g`roup `to` `XOR`. (No, `to` is red).
    # `q`uantity `o`f `b`its `g`roup `XOR`ed.

    # `g`enerate `q`uantity `o`f `b`its `y`ou `want` `to` `XOR`.
    # 'to' red. `want` red.
    # `g`enerate `q`uantity `o`f `b`its `for` `XOR`. `for` red.
    
    # `g`enerate `q`uantity `o`f `b`its `p`ertaining `to` `XOR`. `p`ertaining `p` is green. `to` is red.

    # `g`enerate `q`uantity `o`f `b`its `p`ower.
    g_quantity_bits = binary_length - 2

    # `g`enerate `b`it `k`ey `p`attern.
    # `p`attern `h`as `g_quantity_bits` `ones` `at` `low` `end`.
    g_ones_pattern = (1 << g_quantity_bits) - 1
    
    # `b`ring `ones` `up` `v`ia `one` `p`osition, `e`xclude `LSB`.
    g_output_bit_key = g_ones_pattern << 1

    g_yielded_value = original_value ^ g_output_bit_key

    return g_yielded_value