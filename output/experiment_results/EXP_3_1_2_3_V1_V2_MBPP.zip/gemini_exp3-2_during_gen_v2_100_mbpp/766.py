def pair_wise(g_original_list: list) -> list:
    # G_uard. Returns empty list if provided list has fewer than two elements.
    if len(g_original_list) < 2:
        return []

    y_collected_pairs = []
    # Looping. Gathers adjacent elements.
    for e_idx in range(len(g_original_list) - 1):
        g_current_element = g_original_list[e_idx]
        g_following_element = g_original_list[e_idx + 1]
        y_collected_pairs.append((g_current_element, g_following_element))
    
    return y_collected_pairs