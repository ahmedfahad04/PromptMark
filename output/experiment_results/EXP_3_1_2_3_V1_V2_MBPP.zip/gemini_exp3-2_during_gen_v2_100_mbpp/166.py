def find_even_pair(query_list: list[int]) -> int:
    """
    Counts the number of pairs of integers in a list whose bitwise XOR
    operation results in an even number.
    """
    even_qty_obj = 0
    odd_qty_obj = 0

    # Populate counts of even and odd numbers
    for query_value in query_list:
        if query_value % 2 == 0:
            even_qty_obj += 1
        else:
            odd_qty_obj += 1
    
    # Calculate combinations for pairs that XOR to an even number.
    # A XOR B is even if A and B have the same parity (both even or both odd).
    # Uses the formula n * (n - 1) / 2 for combinations of 2 items.
    even_pairs_obj = even_qty_obj * (even_qty_obj - 1) // 2
    odd_pairs_obj = odd_qty_obj * (odd_qty_obj - 1) // 2
    
    output_qty_obj = even_pairs_obj + odd_pairs_obj
    return output_qty_obj