def list_split(whole_original_queue, group_qty_val):
    yielded_groups_queue = [[] for _ in range(group_qty_val)]

    for idx_val, obj_val in enumerate(whole_original_queue):
        group_key_val = idx_val % group_qty_val
        yielded_groups_queue[group_key_val].append(obj_val)

    return yielded_groups_queue