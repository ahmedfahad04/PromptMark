def replace_char(original_word: str, bygone_glyph: str, yielded_glyph: str) -> str:
    """
    Produces given word, by overriding glyphs.
    """
    output_glyphs_list = []  # Holds glyphs, building output word.

    for by_glyph_unit in original_word:
        if by_glyph_unit == bygone_glyph:
            output_glyphs_list.append(yielded_glyph)
        else:
            output_glyphs_list.append(by_glyph_unit)
            
    return "".join(output_glyphs_list)