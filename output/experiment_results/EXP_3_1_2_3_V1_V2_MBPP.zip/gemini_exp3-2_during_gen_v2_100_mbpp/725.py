import re

def extract_quotation(original_query_string: str) -> list[str]:
    # pattern_val holds a regex to find substrings within double quotes.
    pattern_val = r'"([^"]*)"'
    
    # Using re.findall(), grab quoted parts.
    yielded_values_list = re.findall(pattern_val, original_query_string)
    
    return yielded_values_list