def rotate_right(given_list: list, k_positions: int) -> list:
    """
    Performs a right rotation on a given list by a specified number of items.

    Args:
        given_list (list): The original list to be rotated.
        k_positions (int): The number of positions to rotate to the right.

    Returns:
        list: A newly generated list after performing the right rotation.
    """
    whole_length = len(given_list)

    # Handle edge cases: empty list or no rotation needed.
    if not whole_length or k_positions == 0:
        return given_list

    # Calculate effective jumps when k_positions exceeds list length.
    effective_jumps = k_positions % whole_length

    # If effective_jumps is zero after modulo, it means a full rotation,
    # resulting in the original list.
    if effective_jumps == 0:
        return given_list

    # Determine the break point for splitting the list.
    break_point = whole_length - effective_jumps

    # Split the list into two parts: the elements that will move to the front
    # and the elements that will follow.
    back_part = given_list[break_point:]
    front_part = given_list[:break_point]

    # Join the two parts to get the right-rotated list.
    output_list = back_part + front_part
    return output_list