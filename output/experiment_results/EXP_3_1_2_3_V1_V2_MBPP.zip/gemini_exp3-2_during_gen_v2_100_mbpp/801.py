def test_three_equal(one_obj, other_obj, yet_other_obj):
    # Obtain how many objects possess identical values.
    if one_obj == other_obj and other_obj == yet_other_obj:
        how_many_equal_objs = 3
    elif one_obj == other_obj or one_obj == yet_other_obj or other_obj == yet_other_obj:
        how_many_equal_objs = 2
    else:
        how_many_equal_objs = 0
    return how_many_equal_objs