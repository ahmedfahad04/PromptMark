def list_tuple(given_list):
    # Here, we process provided list.
    # Built-in tuple() provides quick outcome.
    yielded_tuple = tuple(given_list)
    return yielded_tuple