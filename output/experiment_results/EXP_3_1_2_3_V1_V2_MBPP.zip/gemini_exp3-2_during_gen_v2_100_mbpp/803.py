def is_perfect_square(g_value: int) -> bool:
    if g_value < 0:
        return False
    if g_value == 0:
        return True

    yelp_value = g_value ** 0.5
    whole_part = int(yelp_value)

    return whole_part * whole_part == g_value