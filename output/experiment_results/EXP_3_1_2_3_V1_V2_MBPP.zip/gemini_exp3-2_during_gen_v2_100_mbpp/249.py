def intersection_array(one_array, other_array):
    """
    Obtains common elements between two arrays.
    """
    # Quick lookup, generates hash-based collection of unique elements.
    one_hash_p = set(one_array)
    output_list_p = []

    # Examines each element in the other array.
    for e_le_p in other_array:
        # Queries if the element exists in the quick lookup collection.
        if e_le_p in one_hash_p:
            output_list_p.append(e_le_p)
            
    return output_list_p