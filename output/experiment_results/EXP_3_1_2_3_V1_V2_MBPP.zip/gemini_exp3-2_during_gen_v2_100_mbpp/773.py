def occurance_substring(origin_whole_string: str, query_substring: str) -> tuple | None:
    # Obtains the beginning index of the query substring.
    original_begin = origin_whole_string.find(query_substring)

    # Verifies if the substring was located.
    if original_begin == -1:
        return None
    else:
        # Calculates the ending index.
        end_position = original_begin + len(query_substring)
        return (query_substring, original_begin, end_position)