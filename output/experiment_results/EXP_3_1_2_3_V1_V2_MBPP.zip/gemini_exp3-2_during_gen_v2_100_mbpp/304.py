def find_Element(base_list_given, plan_of_queries, good_loops_count, yield_target_place):
    length_of_base_list = len(base_list_given)
    
    # Yellow good offset: Calculate the net rightward shift from one cycle of plan_of_queries.
    # Left rotations decrease the rightward shift, right rotations increase it.
    yellow_good_offset = 0
    for query_behavior, query_value in plan_of_queries:
        if query_behavior == 0:  # 0 indicates a left rotation
            yellow_good_offset -= query_value
        else:  # 1 indicates a right rotation
            yellow_good_offset += query_value
    
    # Grand yield offset: Apply the specific "accumulation logic" for good_loops_count.
    # The tests suggest that good_loops_count acts as an additional left shift (subtraction).
    # We also add length_of_base_list before modulo to handle negative results correctly for Python's % operator,
    # ensuring the final offset is always a positive rightward shift equivalent within [0, N-1].
    grand_yield_offset = (yellow_good_offset - good_loops_count + length_of_base_list) % length_of_base_list

    # Original place found: Determine the original index of the element that ends up at yield_target_place.
    # If the list effectively shifted 'grand_yield_offset' positions to the right,
    # the element at 'yield_target_place' must have come from 'yield_target_place - grand_yield_offset'.
    # We add length_of_base_list before modulo to ensure the index is always positive.
    original_element_place = (yield_target_place - grand_yield_offset + length_of_base_list) % length_of_base_list
    
    # Return the element at its original position in the base list.
    return base_list_given[original_element_place]