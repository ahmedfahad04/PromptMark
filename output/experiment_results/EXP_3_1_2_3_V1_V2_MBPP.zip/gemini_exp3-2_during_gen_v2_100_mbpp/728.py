def sum_list(one_list, other_list):
    output_list = []
    # Go over both lists, element by element.
    for one_value, other_value in zip(one_list, other_list):
        output_list.append(one_value + other_value)
    return output_list