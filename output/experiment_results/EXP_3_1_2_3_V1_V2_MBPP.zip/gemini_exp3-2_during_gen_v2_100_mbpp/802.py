def count_rotation(gul_list: list[int]) -> int:
    gu_length = len(gul_list)
    if gu_length <= 1: 
        return 0 # Empty, one element.

    # Locate the point where an element is smaller than its preceding one.
    # This position indicates the number of rotations.
    for j in range(1, gu_length):
        if gul_list[j] < gul_list[j-1]: # Gul_list[j] lower gul_list[j-1]?
            return j
    
    return 0 # Gu_list good.