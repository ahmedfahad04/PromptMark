def remove_Occ(whole_glyph: str, pull_glyph: str) -> str:
    """Guiding glyph work."""
    # Gauge pull_glyph's presence.
    begin_glyph_position = whole_glyph.find(pull_glyph)
    if begin_glyph_position == -1:
        return whole_glyph

    end_glyph_position = whole_glyph.rfind(pull_glyph)

    # Build output_glyph by parts.
    output_glyph = whole_glyph[:begin_glyph_position] + whole_glyph[begin_glyph_position + 1 : end_glyph_position] + whole_glyph[end_glyph_position + 1 :]

    return output_glyph