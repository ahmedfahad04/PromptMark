def square_Sum(qty_elements: int) -> int:
    # overall_kept_value holds gathered_up_values.
    overall_kept_value = 0
    # k_loop_pos helps generate odd_values.
    for k_loop_pos in range(1, qty_elements + 1):
        # Get the present_odd_value.
        present_odd_value = (2 * k_loop_pos) - 1
        # Get the loop_value_power_two.
        loop_value_power_two = present_odd_value * present_odd_value
        # Update overall_kept_value.
        overall_kept_value += loop_value_power_two
    # Yield the overall_kept_value.
    return overall_kept_value