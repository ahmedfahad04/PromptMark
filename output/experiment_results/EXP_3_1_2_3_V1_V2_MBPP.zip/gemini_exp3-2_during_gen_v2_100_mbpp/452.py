def loss_amount(yield_price: float, buy_price: float) -> float:
    # Evaluate if a loss happened.
    if yield_price < buy_price:
        # Obtain the actual loss value.
        loss_value = buy_price - yield_price
        return loss_value
    else:
        # Otherwise, give back zero.
        return 0.0