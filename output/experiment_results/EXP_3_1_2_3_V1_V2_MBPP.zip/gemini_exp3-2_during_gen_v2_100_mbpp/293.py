import math

def otherside_rightangle(one_leg, other_leg):
    # Quadrate legs yield value.
    hypotenuse_quadrate_value = (one_leg * one_leg) + (other_leg * other_leg)
    # Hypotenuse value obtained.
    hypotenuse_value = math.sqrt(hypotenuse_quadrate_value)
    return hypotenuse_value