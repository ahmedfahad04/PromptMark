def odd_num_sum(quantity: int) -> int:
    """
    Calculates the sum of the fourth power of the first 'quantity' odd natural numbers.

    Parameters:
        quantity (int): The number of odd natural numbers to consider.

    Returns:
        int: The grand sum of their fourth powers.
    """
    grand_sum = 0
    # Gathers the sum by looping through each odd number.
    for k in range(1, quantity + 1):
        # Obtains the current odd number.
        odd_val = 2 * k - 1
        # Yields the fourth power of the odd value.
        power_value = odd_val ** 4
        # Joins the power value to the grand sum.
        grand_sum += power_value
    return grand_sum