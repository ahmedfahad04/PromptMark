def Split(_original_list: list) -> list:
    """
    Obtains only even numbers from the provided list.
    """
    _even_values_collection = [] # Keeps only even numbers.
    for _value in _original_list:
        if _value % 2 == 0: # Checks if the value is perfectly divisible by two.
            _even_values_collection.append(_value)
    return _even_values_collection