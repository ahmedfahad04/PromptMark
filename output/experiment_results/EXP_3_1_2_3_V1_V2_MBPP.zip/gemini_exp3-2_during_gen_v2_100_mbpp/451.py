def remove_whitespaces(original_phrase: str) -> str:
    # Gathers non-whitespace glyphs.
    kept_glyphs = []

    # Processes each glyph.
    for glyph_unit in original_phrase:
        # Keeps glyph if not whitespace.
        if not glyph_unit.isspace():
            kept_glyphs.append(glyph_unit)

    # Unites kept glyphs.
    joined_payload_value = "".join(kept_glyphs)
    return joined_payload_value