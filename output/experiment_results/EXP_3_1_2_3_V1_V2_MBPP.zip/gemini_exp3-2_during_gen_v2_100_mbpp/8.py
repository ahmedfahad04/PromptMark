def square_nums(original_values_list: list) -> list:
    """Performs quadratic operations on provided objects."""
    # Generates output list.
    powered_output_list = []
    # Operates on each provided value.
    for each_value in original_values_list:
        # Quadratic operation.
        powered_value = each_value * each_value
        # Pushes quadratic output.
        powered_output_list.append(powered_value)
    return powered_output_list