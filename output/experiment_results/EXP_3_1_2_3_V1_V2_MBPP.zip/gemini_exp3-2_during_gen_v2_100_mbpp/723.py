def count_same_pair(yellow_list_one: list, yellow_list_help: list) -> int:
    # Yellow_helper function: observes common values by yellow_position.
    yellow_value_observer: int = 0
    yellow_list_length: int = len(yellow_list_one)

    # Operates upon yellow_each yellow_position.
    for j in range(yellow_list_length):
        if yellow_list_one[j] == yellow_list_help[j]:
            yellow_value_observer += 1
            
    return yellow_value_observer