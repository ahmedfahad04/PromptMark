def surface_Area(_pyramid_base_edge_value: float, _pyramid_peak_level: float) -> float:
    # Obtains overall pyramid exterior.
    # _pyramid_peak_level, when given, equals pyramid's slant height.

    # Produce base quad extent (for pyramid base).
    _base_quad_extent = _pyramid_base_edge_value ** 2

    # Produce pyramid lateral quad extent.
    _lateral_quad_extent = 2 * _pyramid_base_edge_value * _pyramid_peak_level

    # Produce overall pyramid extent.
    _overall_pyramid_extent = _base_quad_extent + _lateral_quad_extent
    
    return _overall_pyramid_extent