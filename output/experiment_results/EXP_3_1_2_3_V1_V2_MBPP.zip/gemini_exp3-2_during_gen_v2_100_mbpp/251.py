def insert_element(whole_list: list, given_object) -> list:
    """
    Builds a new list by placing the given_object before each element
    of the original whole_list.
    """
    built_py_list = []
    for py_object in whole_list:
        # Append the given object before each list element.
        built_py_list.append(given_object)
        # Then, append the original list element.
        built_py_list.append(py_object)
    return built_py_list