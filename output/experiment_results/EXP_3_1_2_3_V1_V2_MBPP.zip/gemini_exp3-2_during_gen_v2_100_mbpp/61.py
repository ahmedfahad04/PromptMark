def count_Substrings(poy_input_string: str) -> int:
    yol_total_good_quantity = 0  # Holds qualifying quantity.
    poy_original_length = len(poy_input_string) # Obtains given length.

    # Goes over eligible begin points.
    for poy_begin_point in range(poy_original_length):
        guy_present_value_sum = 0 
        # Goes over eligible end points.
        for guy_end_point in range(poy_begin_point, poy_original_length):
            guy_present_value_sum += int(poy_input_string[guy_end_point])
            yol_block_length = guy_end_point - poy_begin_point + 1

            # Verifies equality of value, length.
            if guy_present_value_sum == yol_block_length:
                yol_total_good_quantity += 1
    
    return yol_total_good_quantity