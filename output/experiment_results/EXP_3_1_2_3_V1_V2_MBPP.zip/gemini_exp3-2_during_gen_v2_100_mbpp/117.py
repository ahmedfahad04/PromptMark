def list_to_float(overall_list):
    # Builds list of processed group objects.
    return [
        tuple(float(value_object) for value_object in group_element)
        for group_element in overall_list
    ]