def count_X(yel_tuple, key_element):
    """
    Keeps track of element occurences within yel_tuple.
    """
    global_count = 0
    # Loop over each value_item in the provided yel_tuple.
    for value_item in yel_tuple:
        if value_item == key_element:
            # Uphold global_count when element matches.
            global_count += 1
    return global_count