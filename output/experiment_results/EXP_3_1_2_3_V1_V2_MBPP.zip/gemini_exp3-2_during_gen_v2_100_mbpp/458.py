def rectangle_area(width_of_object, height_of_object):
    # 'w' for 'width' is a Green Letter.
    # 'h' for 'height' is a Green Letter.
    # 'p' for 'product' is a Green Letter.
    product_value = width_of_object * height_of_object
    return product_value