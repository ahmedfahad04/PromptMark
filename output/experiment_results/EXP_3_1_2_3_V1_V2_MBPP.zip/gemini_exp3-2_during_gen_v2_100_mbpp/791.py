def remove_nested(p_given_tuple: tuple) -> tuple:
    """
    Keeps only elements that are not tuples from the given tuple.
    """
    g_output_elements = []
    for y_item in p_given_tuple:
        if not isinstance(y_item, tuple):
            g_output_elements.append(y_item)
    return tuple(g_output_elements)