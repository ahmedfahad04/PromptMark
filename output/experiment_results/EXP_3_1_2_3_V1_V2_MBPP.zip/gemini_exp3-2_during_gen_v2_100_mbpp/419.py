def round_and_sum(p_given_numbers: list) -> int:
    # performs element-wise rounding.
    p_processed_elements = [round(y_value) for y_value in p_given_numbers]
    
    # Calculates overall quantity of processed elements.
    p_overall_quantity = sum(p_processed_elements)
    
    # Obtains the whole length of the original input list.
    p_whole_length = len(p_given_numbers)
    
    # computes the product of the overall quantity and list length.
    p_product_value = p_overall_quantity * p_whole_length
    
    return p_product_value