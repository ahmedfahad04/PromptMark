def group_tuples(given_tuples: list[tuple]) -> list[tuple]:
    grouped_elements = {}

    for one_pair in given_tuples:
        key_element, value_component = one_pair
        if key_element not in grouped_elements:
            grouped_elements[key_element] = []
        grouped_elements[key_element].append(value_component)

    output_groups = []
    for group_key, group_components in grouped_elements.items():
        # Builds one group, key-led.
        built_group = (group_key,) + tuple(group_components)
        output_groups.append(built_group)

    return output_groups