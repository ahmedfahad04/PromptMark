def largest_subset(given_numbers_list):
    # Order the given numbers to simplify query of divisibility.
    # Proceeding, order helps look over only lower values.
    ordered_values_query = sorted(given_numbers_list)
    whole_length = len(ordered_values_query)

    # Initialize a dynamic programming list.
    # group_lengths[idx_j] will hold length of biggest grouped elements
    # ending with ordered_values_query[idx_j].
    group_lengths = [1] * whole_length  # Each element itself forms a grouped unit of length 1.

    overall_biggest_length = 0
    if whole_length > 0:
        # If given whole length is positive, lowest length is 1.
        overall_biggest_length = 1
    elif whole_length == 0:
        return 0 # Handle empty list case explicitly

    # Populate the group_lengths list.
    # Loop through each element in ordered list.
    for idx_j in range(whole_length):
        present_value_j = ordered_values_query[idx_j]
        # Per each element, observe every previous element.
        for idx_k in range(idx_j):
            previous_value_k = ordered_values_query[idx_k]
            # Observe if present_value_j wholly contains previous_value_k (i.e., is divisible).
            if present_value_j % previous_value_k == 0:
                # If query holds, we can possibly extend grouped elements
                # ending at previous_value_k.
                # Update group_lengths[idx_j] if we observed bigger grouped elements.
                group_lengths[idx_j] = max(group_lengths[idx_j], 1 + group_lengths[idx_k])

        # Update the overall_biggest_length.
        overall_biggest_length = max(overall_biggest_length, group_lengths[idx_j])

    return overall_biggest_length