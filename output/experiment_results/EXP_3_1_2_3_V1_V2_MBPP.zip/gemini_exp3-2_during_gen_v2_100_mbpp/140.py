def extract_singly(outer_groupings: list[tuple[int, ...]]) -> set[int]:
    """Produces a single set of unique elements from provided outer groupings."""
    unique_elements_holder: set[int] = set()

    # Walks over each inner group.
    for group_element in outer_groupings:
        # Puts each element from the inner group into the unique holder.
        for element_present in group_element:
            unique_elements_holder.add(element_present)

    return unique_elements_holder