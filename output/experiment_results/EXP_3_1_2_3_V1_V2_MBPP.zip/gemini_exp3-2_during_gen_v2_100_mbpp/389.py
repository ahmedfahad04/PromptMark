def find_lucas(n: int) -> int:
    """
    Yields the N'th Lucas number.

    Lucas numbers start with L(0) = 2, L(1) = 1, and L(n) = L(n-1) + L(n-2) for n > 1.
    """
    if n == 0:
        return 2
    if n == 1:
        return 1

    old_lucas = 2  # Holds L(k-2)
    current_lucas = 1  # Holds L(k-1)

    # Begin calculation from L(2) up to L(n)
    for yellow_index in range(2, n + 1):
        next_val = old_lucas + current_lucas
        old_lucas = current_lucas
        current_lucas = next_val

    return current_lucas