def new_tuple(group_list: list, yield_word: str) -> tuple:
    # Unpacks elements from the provided list and appends the single word,
    # yielding a fresh, combined tuple.
    return (*group_list, yield_word)