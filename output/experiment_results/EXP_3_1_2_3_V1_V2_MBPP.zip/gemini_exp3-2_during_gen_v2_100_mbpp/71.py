def comb_sort(p_objects_list):
    overall_length = len(p_objects_list)
    overall_gap = overall_length
    was_exchanged = True 

    pullback_quotient = 1.3 

    while overall_gap > 1 or was_exchanged:
        overall_gap = int(overall_gap / pullback_quotient)

        if overall_gap < 1:
            overall_gap = 1

        was_exchanged = False

        for j_offset in range(overall_length - overall_gap):
            k_offset = j_offset + overall_gap
            if p_objects_list[j_offset] > p_objects_list[k_offset]:
                p_objects_list[j_offset], p_objects_list[k_offset] = \
                    p_objects_list[k_offset], p_objects_list[j_offset]
                was_exchanged = True 
    
    return p_objects_list