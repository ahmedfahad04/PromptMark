import re

def text_lowercase_underscore(given_body: str) -> bool:
    """
    Judges if the input body contains sequences of lowercase letters
    joined by an underscore, matching the whole body.
    """
    # Keeps pattern judging whole body: lowercase parts joined by underscore.
    pattern_key = r"^[a-z]+_[a-z]+$"
    body_judged_outcome = re.fullmatch(pattern_key, given_body)
    return bool(body_judged_outcome)