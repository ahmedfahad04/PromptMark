def perimeter_pentagon(pentagon_length: float) -> float:
    # Obtains the total length of a regular pentagon.
    pentagon_edge_quantity = 5  # Provides the value for the quantity of equal edges.
    overall_length = pentagon_edge_quantity * pentagon_length
    return overall_length