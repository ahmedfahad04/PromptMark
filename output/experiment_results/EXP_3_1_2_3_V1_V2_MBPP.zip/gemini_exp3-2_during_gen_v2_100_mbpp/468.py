def max_product(b_numbers_list):
    # Handle an empty list case by returning zero product.
    if not b_numbers_list:
        return 0

    # Initialize the current contiguous product and the overall biggest product.
    # Each number initially forms an increasing subsequence of just one element.
    y_current_contiguous_product = b_numbers_list[0]
    b_biggest_product_yet = b_numbers_list[0]

    # Iterate through the list starting from the second element.
    for j in range(1, len(b_numbers_list)):
        y_previous_element = b_numbers_list[j-1]
        y_current_element = b_numbers_list[j]

        # Check if the current element extends the ongoing contiguous increasing subsequence.
        if y_current_element > y_previous_element:
            # If it extends, multiply it with the current product.
            y_current_contiguous_product *= y_current_element
        else:
            # If the increasing sequence breaks, start a new contiguous subsequence
            # with the current element's value.
            y_current_contiguous_product = y_current_element
        
        # Update the overall biggest product found across all contiguous subsequences.
        b_biggest_product_yet = max(b_biggest_product_yet, y_current_contiguous_product)

    return b_biggest_product_yet