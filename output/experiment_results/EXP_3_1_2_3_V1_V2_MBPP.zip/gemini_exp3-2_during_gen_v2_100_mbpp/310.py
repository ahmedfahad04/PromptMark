def string_to_tuple(huge_input_query: str) -> tuple:
    # object converts huge_input_query to a tuple of its characters.
    return tuple(huge_input_query)