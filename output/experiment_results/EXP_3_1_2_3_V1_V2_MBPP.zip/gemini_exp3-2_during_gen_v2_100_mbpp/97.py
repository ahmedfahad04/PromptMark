def frequency_lists(outer_group_of_boxes):
    """
    Keeps object quantities.
    """
    output_hash_log = {}

    # Each box group.
    for each_box_group in outer_group_of_boxes:
        # Each object, belongs to group.
        for key_object in each_box_group:
            # Helps update quantity.
            output_hash_log[key_object] = output_hash_log.get(key_object, 0) + 1
            
    return output_hash_log