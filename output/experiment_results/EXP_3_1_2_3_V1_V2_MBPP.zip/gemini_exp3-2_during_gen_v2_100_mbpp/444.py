def trim_tuple(given_list, k):
    # Holds yielded grouping.
    updated_payload_list = []

    for each_grouping_payload in given_list:
        payload_length = len(each_grouping_payload)
        # Obtains portion by excluding outer k units.
        yielding_payload_part = each_grouping_payload[k : payload_length - k]
        updated_payload_list.append(yielding_payload_part)
    
    return str(updated_payload_list)