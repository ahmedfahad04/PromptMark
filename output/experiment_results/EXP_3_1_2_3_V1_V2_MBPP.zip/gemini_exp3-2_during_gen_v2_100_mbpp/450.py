def extract_string(py_original_values_list: list[str], expected_py_length: int) -> list[str]:
    """
    Obtains string values of a given length from the input list.

    Args:
        py_original_values_list (list[str]): The input list of string values.
        expected_py_length (int): The precise length to be matched.

    Returns:
        list[str]: A new list containing only strings with the expected_py_length.
    """
    output_py_values = [] # Builds up chosen string values.
    for py_string_value in py_original_values_list:
        # Checks if current string's length is equal to expected_py_length.
        if len(py_string_value) == expected_py_length:
            output_py_values.append(py_string_value)
    return output_py_values