import math

def _compute_euclidean_extended(one_val, other_val):
    """
    Computes the greatest common divisor (GCD) of two non-negative integers
    and finds integers x and y such that one_val*x + other_val*y = gcd(one_val, other_val).
    This helper expects non-negative inputs.
    """
    if one_val == 0:
        return (other_val, 0, 1)
    
    # Recursive call to get GCD and coefficients for the smaller problem
    gcd_val, x_one, y_one = _compute_euclidean_extended(other_val % one_val, one_val)
    
    # Back-substitute to find x and y for the current level
    # Formula derived from the extended Euclidean algorithm
    x_val = y_one - (other_val // one_val) * x_one
    y_val = x_one
    
    return (gcd_val, x_val, y_val)


def find_solution(alpha_val, beta_val, numeric_val):
    """
    Generates integer solutions (x, y) for the Diophantine equation
    alpha_val * x + beta_val * y = numeric_val.
    
    Returns a tuple (x, y) where x and y are non-negative, or None if no such
    non-negative integer solution exists. If multiple non-negative solutions exist,
    the one with the smallest non-negative x is preferred (obtained by choosing
    the smallest valid 'k').
    """

    # Gathers `alpha_val` and `beta_val` values to handle edge cases
    if alpha_val == 0 and beta_val == 0:
        # If both coefficients are zero:
        # If numeric_val is zero, any (0, 0) works.
        # Otherwise, no solution.
        return (0, 0) if numeric_val == 0 else None

    # Determines the greatest common divisor for the absolute values
    # `math.gcd` ensures `g_val` is always non-negative.
    g_val = math.gcd(alpha_val, beta_val)
    
    # If the numeric_val is not divisible by the GCD, no integer solution exists.
    if numeric_val % g_val != 0:
        return None

    # Generates a particular solution (x_g_val, y_g_val) for
    # abs(alpha_val)*x + abs(beta_val)*y = g_val
    _, x_g_val, y_g_val = _compute_euclidean_extended(abs(alpha_val), abs(beta_val))

    # Obtains the scaling factor to relate `g_val` to `numeric_val`
    k_factor = numeric_val // g_val
    
    # Calculates a particular solution (x_particular, y_particular) for
    # alpha_val * x + beta_val * y = numeric_val.
    # Adjusts signs based on original alpha_val and beta_val.
    x_particular = x_g_val * k_factor
    if alpha_val < 0:
        x_particular = -x_particular
    
    y_particular = y_g_val * k_factor
    if beta_val < 0:
        y_particular = -y_particular

    # Handles cases where alpha_val or beta_val is zero separately
    # after the initial GCD check and particular solution calculation.
    # This ensures `x_step` and `y_step` are non-zero later.
    if alpha_val == 0: # Equation is beta_val * y = numeric_val
        y_solution = numeric_val // beta_val
        return (0, y_solution) if y_solution >= 0 else None
    if beta_val == 0: # Equation is alpha_val * x = numeric_val
        x_solution = numeric_val // alpha_val
        return (x_solution, 0) if x_solution >= 0 else None

    # Generates step values for `x` and `y` in the general solution formula:
    # x = x_particular + k * x_step
    # y = y_particular - k * y_step
    x_step = beta_val // g_val
    y_step = alpha_val // g_val

    # Determines bounds for `k` to ensure both `x` and `y` are non-negative
    k_lower_bound = -float('inf')
    k_upper_bound = float('inf')

    # Updates `k` bounds based on `x >= 0` constraint
    if x_step > 0:
        k_lower_bound = max(k_lower_bound, math.ceil(-x_particular / x_step))
    elif x_step < 0:
        k_upper_bound = min(k_upper_bound, math.floor(-x_particular / x_step))

    # Updates `k` bounds based on `y >= 0` constraint
    # (y_particular - k * y_step >= 0) implies (k * y_step <= y_particular)
    if y_step > 0:
        k_upper_bound = min(k_upper_bound, math.floor(y_particular / y_step))
    elif y_step < 0:
        k_lower_bound = max(k_lower_bound, math.ceil(y_particular / y_step))
    
    # If no integer `k` satisfies both non-negative conditions
    if k_lower_bound > k_upper_bound:
        return None

    # Obtains the smallest integer `k` within the valid range.
    # This choice generally yields the smallest non-negative `x` if `x_step > 0`.
    chosen_k = math.ceil(k_lower_bound)

    # Computes the final `x` and `y` values using the chosen `k`
    final_x = x_particular + chosen_k * x_step
    final_y = y_particular - chosen_k * y_step

    return (final_x, final_y)