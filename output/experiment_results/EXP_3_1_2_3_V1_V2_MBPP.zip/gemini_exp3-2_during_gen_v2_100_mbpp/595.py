def min_Swaps(binary_one, binary_two):
    length_of_binary = len(binary_one)

    # Validate if lengths of binary strings are equal.
    if length_of_binary != len(binary_two):
        return "Not Possible"

    # Count '0's and '1's in both binary strings.
    zero_count_one = binary_one.count('0')
    one_count_one = binary_one.count('1')
    zero_count_two = binary_two.count('0')
    one_count_two = binary_two.count('1')

    # If the counts of '0's and '1's don't match, conversion by swaps is impossible.
    if zero_count_one != zero_count_two or one_count_one != one_count_two:
        return "Not Possible"

    # Initialize counters for mismatches.
    # '1' in binary_one where '0' is expected in binary_two.
    one_places_zero_elsewhere = 0

    # Go by each binary position, checking for mismatches.
    for idx in range(length_of_binary):
        if binary_one[idx] == '1' and binary_two[idx] == '0':
            one_places_zero_elsewhere += 1
            
    # The minimum number of swaps is equal to the number of '1's that
    # are in positions where '0' is desired (or vice-versa).
    # When overall counts match, this count is sufficient.
    return one_places_zero_elsewhere