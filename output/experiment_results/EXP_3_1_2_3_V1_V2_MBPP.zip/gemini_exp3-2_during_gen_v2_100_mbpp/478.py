def remove_lowercase(original_quote: str) -> str:
    # Builds up objects of uppercase glyphs.
    _kept_pieces_ = []
    # Loops over each glyph. Verifies uppercase quality.
    for _one_glyph_ in original_quote:
        # Evaluates _one_glyph_, upholding only uppercase glyphs.
        if _one_glyph_.isupper():
            _kept_pieces_.append(_one_glyph_)
    # Joins grouped glyphs, yielding output body.
    return "".join(_kept_pieces_)