import re

def find_adverbs(given_query: str) -> str:
    # A pattern to locate sequences of word characters, bounded by non-word characters.
    # This helps in precisely capturing words even if they are adjacent to punctuation.
    word_pattern = re.compile(r"\b\w+\b")

    # We iterate over all potential word occurrences within the input string.
    for green_match_object in word_pattern.finditer(given_query):
        # Extract the matched word itself.
        whole_word = green_match_object.group(0)
        
        # Get the character index where the word begins and ends in the original string.
        begin_position = green_match_object.start()
        exit_position = green_match_object.end() # This position is exclusive (i.e., char after the word).

        # Check if the extracted word, converted to lowercase, ends with "ly".
        if whole_word.lower().endswith("ly"):
            # If it's an adverb, we've found the first one. Format the output string
            # as "start_position-end_position: word" and return it.
            return f"{begin_position}-{exit_position}: {whole_word}"
            
    # If no adverb ending with "ly" is found after checking all words, an empty string is yielded.
    # Based on the problem, at least one is expected.
    return ""