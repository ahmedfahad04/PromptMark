def check_element(oby_list, given_element):
    # Verifies every object equals given_element.
    boolean_outcome = all(guy_value == given_element for guy_value in oby_list)
    return boolean_outcome