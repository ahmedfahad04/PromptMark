def rear_extract(original_tuples_list: list) -> list:
    """
    Obtains the concluding value of each tuple.

    This function processes a provided list of tuples, yielding
    a new list composed exclusively of the final element from
    every tuple present in the input collection.
    """
    # Gathers the concluding item from every tuple.
    output_elements_list = [each_tuple[-1] for each_tuple in original_tuples_list]
    return output_elements_list