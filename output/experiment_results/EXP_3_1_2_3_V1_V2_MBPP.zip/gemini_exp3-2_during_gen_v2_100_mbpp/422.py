def find_Average_Of_Cube(upper_bound: int) -> float:
    # Obtain overall_powered_value using the mathematical identity `[upper_bound * (upper_bound + 1) / 2]^2`.
    # This formula efficiently computes the sum of cubes for the first 'upper_bound' natural numbers.
    upper_val_product = upper_bound * (upper_bound + 1)
    half_product_val = upper_val_product / 2
    overall_powered_value = half_product_val ** 2

    # Yields quota_value by dividing the overall_powered_value by 'upper_bound'.
    quota_value = overall_powered_value / upper_bound
    
    return quota_value