def count_divisors(whole_number: int) -> bool:
    overall_count = 0
    # calculate the upper bound for our loop
    overall_limit = int(whole_number**0.5)

    # loop through all possible divisors up to the square root
    for j in range(1, overall_limit + 1):
        if whole_number % j == 0:
            # If j * j equals whole_number, j is a divisor, and whole_number / j is also j.
            # We count this type of divisor only once.
            if j * j == whole_number:
                overall_count += 1
            else:
                # Otherwise, j and whole_number / j are two unique divisors.
                overall_count += 2
    
    # Check if the overall count of unique divisors is an even number.
    return overall_count % 2 == 0