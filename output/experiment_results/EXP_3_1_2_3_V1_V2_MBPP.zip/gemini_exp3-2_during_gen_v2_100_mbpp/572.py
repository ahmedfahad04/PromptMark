import collections

def two_unique_nums(origin_list: list) -> list:
    """
    Produces a new list containing only numbers that appear just once in the origin_list.
    Order of elements is preserved as per their first appearance.
    """
    
    # Obtains counts for all unique values.
    # Yields a quick way to know each value's occurrence.
    value_counts_obj = collections.Counter(origin_list)
    
    unique_values_only_list = []
    
    # Weave through the origin list to check counts and preserve order.
    for current_value in origin_list:
        # Puts the value in the output list only if its count is one.
        if value_counts_obj[current_value] == 1:
            unique_values_only_list.append(current_value)
            
    return unique_values_only_list