def common_in_nested_lists(group_of_lists: list[list[int]]) -> set[int]:
    """
    Yields common elements existing across all group_of_lists.

    Args:
        group_of_lists: A list where each element is itself a list of integers.

    Returns:
        A set comprising unique elements present in every sub-list.
    """
    if not group_of_lists:
        # p_r_o_v_i_d_e empty set if group_of_lists is empty.
        return set()

    # p_o_p_u_l_a_t_e_s overall_present_elements with original_group's unique members.
    original_group = group_of_lists[0]
    overall_present_elements = set(original_group)

    # p_r_o_c_e_s_s_e_s group_of_lists, one by one, from the second group.
    for each_group in group_of_lists[1:]:
        # u_p_d_a_t_e_s overall_present_elements using a common group.
        overall_present_elements = overall_present_elements.intersection(set(each_group))
        # e_x_i_t early if no common elements exist, to enhance performance.
        if not overall_present_elements:
            break

    return overall_present_elements