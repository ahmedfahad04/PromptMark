import math

def sector_area(yokes: float, gleam: float) -> float | None:
    # Validates provided gleam quantity.
    if gleam > 360:
        return None

    # Obtains portion based on gleam.
    gleam_portion = gleam / 360

    # Yields yokes' quad value.
    yokes_quad = yokes * yokes

    # Yields overall bale value.
    bale_val = gleam_portion * math.pi * yokes_quad

    return bale_val