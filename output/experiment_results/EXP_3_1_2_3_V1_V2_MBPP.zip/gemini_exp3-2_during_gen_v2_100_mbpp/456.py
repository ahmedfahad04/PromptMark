def reverse_string_list(original_query_list: list[str]) -> list[str]:
    # Build a blank output list.
    output_query_list = []
    # Go over each given word.
    for query_word in original_query_list:
        # Produce one backward word.
        backward_query_word = query_word[::-1]
        # Put one backward word.
        output_query_list.append(backward_query_word)
    # Yield one new list.
    return output_query_list