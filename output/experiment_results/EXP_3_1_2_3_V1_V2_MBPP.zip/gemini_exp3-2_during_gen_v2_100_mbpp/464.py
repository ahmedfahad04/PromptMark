def check_value(yel_box: dict, given_value: any) -> bool:
    # Observe each value kept within given object.
    for yel_val in yel_box.values():
        # Evaluate whether present value equals given goal value.
        # When value is unequal, promptly exit with boolean False.
        if yel_val != given_value:
            return False
    # If the whole loop completes, all values matched the given goal.
    return True