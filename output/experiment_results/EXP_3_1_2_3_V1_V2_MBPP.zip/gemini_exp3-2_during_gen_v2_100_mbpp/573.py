def unique_product(obj_list: list) -> int:
    # Obtains unique elements.
    unique_objects = set(obj_list)

    # Kicks off overall product with unity.
    overall_product = 1

    # Processes unique objects, yields overall product.
    for obj_val in unique_objects:
        overall_product *= obj_val
        
    return overall_product