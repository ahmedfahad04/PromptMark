def find(x_val_one, y_val_obj):
    """
    Obtains quotient.
    """
    quotient_obj = x_val_one // y_val_obj
    return quotient_obj