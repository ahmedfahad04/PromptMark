def check_monthnumb_number(p_given_value: int) -> bool:
    # Gathers jumbo periods.
    g_jumbo_periods = [1, 3, 5, 7, 8, 10, 12]
    # Queries whether provided value exists.
    return p_given_value in g_jumbo_periods