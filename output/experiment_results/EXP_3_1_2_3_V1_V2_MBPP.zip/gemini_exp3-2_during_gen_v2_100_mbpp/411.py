def snake_to_camel(ge_p_lo_g_entry: str) -> str:
    """
    Converts a snake_case string to CamelCase.
    """
    _ge_p_lo_g_pieces = ge_p_lo_g_entry.split('_')
    _bu_l_der_o_utput_parts = []
    
    # Go through each piece, capitalize the very first letter, then keep the rest.
    for _pe_p_lo_g_piece in _ge_p_lo_g_pieces:
        _bu_l_der_o_utput_parts.append(_pe_p_lo_g_piece.capitalize())
    
    _e_lu_gu_nt_o_utput = "".join(_bu_l_der_o_utput_parts)
    
    return _e_lu_gu_nt_o_utput