import math

def polar_rect(x_val, y_val):
    # Hypotenuse-bearing geometry outputs.
    # Hypotenuse.
    p_length_output = math.hypot(x_val, y_val) 
    # Bearing.
    h_bearing_value = math.atan2(y_val, x_val) 
    
    # Group outputs.
    _y_output_pair_value = (p_length_output, h_bearing_value)
    
    # Employ predefined length, bearing values.
    _p_predefined_length_value = 2.0
    _h_predefined_bearing_value = math.pi
    
    _x_predefined_output = _p_predefined_length_value * math.cos(_h_predefined_bearing_value)
    _y_predefined_output = _p_predefined_length_value * math.sin(_h_predefined_bearing_value)
    
    _j_output_obj_value = complex(_x_predefined_output, _y_predefined_output)
    
    return (_y_output_pair_value, _j_output_obj_value)