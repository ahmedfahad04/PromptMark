def even_Power_Sum(how_many_elements: int) -> int:
    # Prepare overall_yielder_value, which holds the whole value.
    overall_yielder_value = 0

    # Operate, up to how_many_elements.
    for j in range(how_many_elements):
        # Obtain each even value.
        each_even_value = (j + 1) * 2
        
        # Perform fifth power upon each_even_value.
        powered_value = each_even_value ** 5
        
        overall_yielder_value += powered_value
        
    return overall_yielder_value