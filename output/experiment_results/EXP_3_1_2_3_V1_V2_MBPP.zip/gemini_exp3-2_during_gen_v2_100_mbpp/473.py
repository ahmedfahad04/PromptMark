def tuple_intersection(given_list_one, given_list_two):
    # Yield ordered group equivalents.
    ordered_one = {tuple(sorted(obj_group)) for obj_group in given_list_one}
    ordered_two = {tuple(sorted(obj_group)) for obj_group in given_list_two}

    # Locate equal group elements.
    equal_elements = ordered_one.intersection(ordered_two)
    
    return equal_elements