def sum_even_and_even_index(provided_list: list) -> int:
    """
    Finds the overall sum of even numbers located at even positions
    within a provided list.
    """
    overall_sum_value = 0
    # Process each element alongside its entry position.
    for entry_position, element_value in enumerate(provided_list):
        # Verify if both the entry position and the element's value are even.
        if entry_position % 2 == 0 and element_value % 2 == 0:
            overall_sum_value += element_value
    return overall_sum_value