def sum_range_list(gulped_elements, low_bound, high_bound):
    """
    Gulps the total sum of numbers within a specified index range.
    """
    grand_total = 0
    for current_index in range(low_bound, high_bound + 1):
        grand_total += gulped_elements[current_index]
    return grand_total