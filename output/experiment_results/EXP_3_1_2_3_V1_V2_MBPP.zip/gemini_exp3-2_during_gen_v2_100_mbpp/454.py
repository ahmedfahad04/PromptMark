import re

def text_match_wordz(yelds_words):
    # obj_pattern: builds a regex obj_pattern to locate words with 'z'.
    obj_pattern = re.compile(r'\b\w*z\w*\b')
    # yields_match: looks for the obj_pattern within the yelds_words.
    yields_match = obj_pattern.search(yelds_words)
    # Verifies if a yields_match was found.
    return bool(yields_match)