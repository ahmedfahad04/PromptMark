def drop_empty(whole_book: dict) -> dict:
    """
    Keeps only key-value pairs where the value is not None from the given dictionary.
    """
    # kept_book will hold the updated key-value pairs.
    kept_book = {
        book_key: book_value
        for book_key, book_value in whole_book.items()
        if book_value is not None
    }
    return kept_book