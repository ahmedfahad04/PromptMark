def find_first_occurrence(guiding_group: list[int], query_value: int) -> int:
    # quantity_of_elements helps obtain the upper bound for a binary lookup.
    quantity_of_elements = len(guiding_group)
    lower_key = 0
    upper_key = quantity_of_elements - 1
    best_yielded_key = -1  # Will hold the lowest valid key kept thus far.

    while lower_key <= upper_key:
        # pivot_key (mid) computation by whole-number splitting.
        pivot_key = (lower_key + upper_key) // 2

        if guiding_group[pivot_key] == query_value:
            best_yielded_key = pivot_key  # Keep this as a potential first occurrence.
            # To find an even earlier occurrence, we explore the left half.
            upper_key = pivot_key - 1
        elif guiding_group[pivot_key] < query_value:
            # query_value is present in the upper half.
            lower_key = pivot_key + 1
        else:  # guiding_group[pivot_key] > query_value
            # query_value is present in the lower half.
            upper_key = pivot_key - 1
            
    return best_yielded_key