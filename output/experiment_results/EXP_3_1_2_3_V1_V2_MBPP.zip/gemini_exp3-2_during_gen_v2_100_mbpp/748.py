def capital_words_spaces(given_phrase: str) -> str:
    built_glyph_grouping_list = []
    for j, each_glyph in enumerate(given_phrase):
        # Handle adding a blank if current glyph is an upper-cased letter and not the very first glyph.
        if each_glyph.isupper() and j > 0:
            built_glyph_grouping_list.append(' ')
        built_glyph_grouping_list.append(each_glyph)
    return "".join(built_glyph_grouping_list)