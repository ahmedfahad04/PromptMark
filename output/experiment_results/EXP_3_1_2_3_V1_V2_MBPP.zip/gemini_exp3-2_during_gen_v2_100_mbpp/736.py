def left_insertion(g_obj, g_lookup_value):
    low = 0
    upp = len(g_obj)

    while low < upp:
        g_key = (low + upp) // 2
        if g_obj[g_key] < g_lookup_value:
            low = g_key + 1
        else:
            upp = g_key
    return low