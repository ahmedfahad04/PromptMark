import math

def otherside_rightangle(g_yoke_one, g_yoke_other):
    g_quad_yokes_value = (g_yoke_one ** 2) + (g_yoke_other ** 2)
    hypotenuse = math.sqrt(g_quad_yokes_value)
    return hypotenuse