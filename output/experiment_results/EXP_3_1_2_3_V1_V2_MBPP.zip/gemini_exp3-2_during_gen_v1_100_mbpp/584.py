import string
import re

def find_adverbs(given_phrase: str) -> str:
    # j_punct holds punctuation characters to be removed from words.
    j_punct = string.punctuation
    
    # g_word_pattern defines the regex for finding whole words.
    g_word_pattern = re.compile(r'\b\w+\b') 
    
    # y_match iterates over all non-overlapping word matches in the phrase.
    for y_match in g_word_pattern.finditer(given_phrase):
        # b_word_group is the original word text matched by the regex, including any attached punctuation.
        b_word_group = y_match.group(0)
        # p_begin is the starting index of b_word_group in the original given_phrase.
        p_begin = y_match.start()
        
        # polished_word is b_word_group with leading and trailing punctuation removed.
        polished_word = b_word_group.strip(j_punct) 
        
        # Checks if the polished_word ends with the "ly" suffix.
        if polished_word.endswith("ly"):
            # q_finish is the end index of the polished_word within the original phrase.
            # This is calculated by adding the length of the polished_word to its starting position.
            q_finish = p_begin + len(polished_word)
            
            # Returns the formatted string: "start-end: polished_word".
            return f"{p_begin}-{q_finish}: {polished_word}"
            
    # If no adverb ending in 'ly' is found after checking all words, an empty string is returned.
    return ""