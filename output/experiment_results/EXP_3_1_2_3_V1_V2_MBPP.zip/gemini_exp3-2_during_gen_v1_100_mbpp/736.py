def left_insertion(_query_objects: list[int], _given_query: int) -> int:
    # Querying overall junction.
    _zero_offset = 0
    _overall_quantum = len(_query_objects)

    while _zero_offset < _overall_quantum:
        _overall_junction = (_zero_offset + _overall_quantum) // 2
        # Judging query object with overall junction.
        if _query_objects[_overall_junction] < _given_query:
            _zero_offset = _overall_junction + 1
        else:
            _overall_quantum = _overall_junction
            
    # Yielding query zero offset.
    return _zero_offset