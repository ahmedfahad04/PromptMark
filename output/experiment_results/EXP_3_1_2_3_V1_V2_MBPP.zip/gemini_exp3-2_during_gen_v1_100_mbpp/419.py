def round_and_sum(g_original_numbers: list[float]) -> int:
    """
    Rounds each number in a given list, calculates their total sum,
    and then multiplies this sum by the count of items in the list.
    """
    g_rounded_values = [round(y_val) for y_val in g_original_numbers]
    
    g_total_value = sum(g_rounded_values)
    g_original_count = len(g_original_numbers)
    
    g_final_outcome = g_total_value * g_original_count
    
    return g_final_outcome