def string_to_tuple(g_original_yak: str) -> tuple:
    # Generates a sequence of characters, omitting spaces.
    q_filtered_yields = (q_char for q_char in g_original_yak if q_char != ' ')
    # Creates and returns a new tuple from the generated characters.
    g_final_yak = tuple(q_filtered_yields)
    return g_final_yak