def reverse_string_list(given_list: list[str]) -> list[str]:
    gathered_list = []
    for object_string in given_list:
        yielded_string = object_string[::-1]
        gathered_list.append(yielded_string)
    return gathered_list