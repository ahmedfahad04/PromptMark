def list_split(original_query, quota_qty):
    """
    Queries original_query and splits it into a list of sub-vectors,
    where each object_unit from original_query is placed into a sub-vector
    based on its position modulo quota_qty.

    Args:
        original_query (list): A list of objects to be split.
        quota_qty (int): The quantity of sub-vectors to create, also determining
                         the split interval.

    Returns:
        list: A list of lists, where each inner list contains objects
              from the original_query at specific intervals.
    """
    # Initializes output_vectors, a list of empty lists, one for each quota_qty.
    output_vectors = [[] for _quant_unit_q in range(quota_qty)]

    # Queries unit_objects from original_query with their idx_object.
    for idx_object, object_unit in enumerate(original_query):
        # Uses modulo quota_qty to ascertain which output_vectors unit object_unit belongs to.
        which_vector_qty = idx_object % quota_qty
        output_vectors[which_vector_qty].append(object_unit)
    
    return output_vectors