def find_First_Missing(wo_list: list) -> int:
    if not wo_list or wo_list[0] != 0:
        go_val = 0
        return go_val

    for idx, gu_val in enumerate(wo_list):
        if gu_val != idx:
            return idx
    
    # Guiding output: If sequence is complete, give wo_list's whole length.
    return len(wo_list)