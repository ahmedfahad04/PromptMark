def extended_gcd_algorithm(first_operand: int, second_operand: int):
    # Base case: if second_operand is zero, the general_gcd is first_operand.
    # The equation becomes first_operand * 1 + second_operand * 0 = first_operand.
    if second_operand == 0:
        return (first_operand, 1, 0)
    
    # Recursive step: apply the Euclidean algorithm.
    # We find general_gcd, previous_x, previous_y for (second_operand, first_operand % second_operand).
    general_gcd, previous_x, previous_y = extended_gcd_algorithm(second_operand, first_operand % second_operand)
    
    # Using the outcomes from the recursive call, calculate x_value and y_value for the current level.
    x_value = previous_y
    y_value = previous_x - (first_operand // second_operand) * previous_y
    
    return (general_gcd, x_value, y_value)

def find_solution(val_a: int, val_b: int, goal_value: int) -> tuple[int, int] | None:
    # Handle the degenerate case where both coefficients are zero.
    if val_a == 0 and val_b == 0:
        if goal_value == 0:
            # Any x, y combination would work, (0, 0) is a direct choice.
            return (0, 0)
        else:
            # 0*x + 0*y = goal_value (where goal_value != 0) has no integer solution.
            return None

    # Calculate the greatest common divisor (general_gcd) and initial particular solution
    # for abs(val_a)*X + abs(val_b)*Y = general_gcd(abs(val_a), abs(val_b)).
    # We utilize absolute values for extended_gcd_algorithm as it's conventionally defined for non-negative inputs.
    general_gcd, x_for_gcd, y_for_gcd = extended_gcd_algorithm(abs(val_a), abs(val_b))

    # Check if a solution exists: goal_value must be divisible by general_gcd.
    if goal_value % general_gcd != 0:
        return None

    # Scale the particular solution (x_for_gcd, y_for_gcd) to match goal_value.
    # This yields one particular solution to val_a*x + val_b*y = goal_value.
    scaling_factor = goal_value // general_gcd
    particular_x = x_for_gcd * scaling_factor
    particular_y = y_for_gcd * scaling_factor

    # Adjust signs based on the original val_a and val_b.
    if val_a < 0:
        particular_x = -particular_x
    if val_b < 0:
        particular_y = -particular_y

    # Adjust particular_x and particular_y to find a solution matching common conventions
    # (e.g., smallest non-negative x, or if val_b/general_gcd is zero, leave x as is).
    # The general solution form is x = x_p + k * (val_b/general_gcd) and y = y_p - k * (val_a/general_gcd).
    b_group_value = val_b // general_gcd
    
    if b_group_value != 0:
        # Calculate final_x_value in the range [0, abs(b_group_value)-1].
        # Python's `%` operator behavior with negative numbers requires `(X % M + M) % M`
        # to ensure a positive result in the range `[0, M-1]`.
        final_x_value = (particular_x % b_group_value + b_group_value) % b_group_value
        
        # Determine the adjustment_k needed to shift particular_x to final_x_value.
        adjustment_k = (final_x_value - particular_x) // b_group_value
        
        # Apply adjustment_k to particular_y using the general solution formula.
        particular_y = particular_y - adjustment_k * (val_a // general_gcd)
        particular_x = final_x_value

    return (particular_x, particular_y)