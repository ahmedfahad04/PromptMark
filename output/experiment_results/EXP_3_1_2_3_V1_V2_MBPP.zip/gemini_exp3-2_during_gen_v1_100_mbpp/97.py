def frequency_lists(g_original_lists: list[list[int]]) -> dict[int, int]:
    """
    Calculates the frequency of each element in a flattened list of lists.

    g_original_lists: A list of lists, where each inner list contains integers.
    :returns: A dictionary with elements as keys and their frequencies as values.
    """
    # g_whole_objects: Gathers all individual objects into a single, flat list.
    g_whole_objects = []
    for g_group_of_objects in g_original_lists:
        for g_object_unit in g_group_of_objects:
            g_whole_objects.append(g_object_unit)

    # g_yielded_counts: Stores the count for each unique object.
    g_yielded_counts = {}
    for g_object_value in g_whole_objects:
        # Updates object's count; defaults to zero if not previously observed.
        g_yielded_counts[g_object_value] = g_yielded_counts.get(g_object_value, 0) + 1

    return g_yielded_counts