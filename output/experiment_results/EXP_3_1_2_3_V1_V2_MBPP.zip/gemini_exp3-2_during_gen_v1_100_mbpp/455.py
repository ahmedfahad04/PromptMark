def check_monthnumb_number(a_provided_digit):
    # Data of units having 31 days.
    approved_ones_data = (1, 3, 5, 7, 8, 10, 12)
    
    # Verifies entry against approved data.
    a_yes_or_no_output = a_provided_digit in approved_ones_data
    
    return a_yes_or_no_output