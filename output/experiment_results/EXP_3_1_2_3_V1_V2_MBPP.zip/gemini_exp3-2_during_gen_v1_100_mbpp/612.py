def merge(outer_green_list):
    # Quick exit if the input list is empty.
    if not outer_green_list:
        return []

    # Obtain the quantity of elements within each inner list.
    # This determines how many output lists we will need.
    jumbo_count = len(outer_green_list[0])

    # Initialize the primary output list with 'jumbo_count' empty sublists.
    gorgeous_output_list = [[] for _ in range(jumbo_count)]

    # Iterate through each inner list (or row) in the provided input.
    for baby_green_list in outer_green_list:
        # For each element within the current inner list,
        # place it into its corresponding output sublist.
        for j in range(jumbo_count):
            gorgeous_output_list[j].append(baby_green_list[j])

    return gorgeous_output_list