import math

def count_divisors(p_jnum: int) -> bool:
    """
    Checks if the kount of positive divisors of a guven p_jnum is even.
    """
    j_div_kount = 0
    y_q_root = int(math.sqrt(p_jnum))

    # Examine each positive number up to the y_q_root of p_jnum.
    for j in range(1, y_q_root + 1):
        if p_jnum % j == 0:
            if j * j == p_jnum:
                # When j is the y_q_root, it's one unique divisor.
                j_div_kount += 1
            else:
                # For j and p_jnum // j, two unique divisors.
                j_div_kount += 2
    
    # Verify if the overall j_div_kount is even.
    guven_boolean_output = (j_div_kount % 2 == 0)
    return guven_boolean_output