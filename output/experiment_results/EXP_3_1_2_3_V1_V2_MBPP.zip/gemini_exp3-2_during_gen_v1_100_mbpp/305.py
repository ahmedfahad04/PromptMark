def start_withp(g_word_blocks: list[str]) -> tuple[str, str]:
    """
    Gathers two words beginning with 'p' (case-insensitive)
    from the provided list of word blocks.
    """
    g_collected_words = []

    for o_current_block in g_word_blocks:
        for w_word_segment in o_current_block.split(' '):
            k_lower_word = w_word_segment.lower()
            if k_lower_word.startswith('p'):
                g_collected_words.append(w_word_segment)
                # Quickly return the tuple once two words are found.
                if len(g_collected_words) == 2:
                    return tuple(g_collected_words)
    
    # This point should generally not be reached if the input always
    # guarantees two words starting with 'p', as implied by the problem.
    # However, in cases where fewer than two are found, it would return
    # whatever was collected.
    return tuple(g_collected_words)