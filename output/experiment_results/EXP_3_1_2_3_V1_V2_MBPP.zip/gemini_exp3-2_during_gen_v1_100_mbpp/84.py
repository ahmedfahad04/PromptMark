def sequence(query_nth_value: int) -> int:
    """
    Computes the query_nth_value number in the Newman-Conway sequence.
    """
    if query_nth_value == 1 or query_nth_value == 2:
        return 1

    # query_overall_values will hold computed sequence values
    query_overall_values = [0] * (query_nth_value + 1)
    query_overall_values[1] = 1
    query_overall_values[2] = 1

    # go up to query_nth_value
    for k_unit in range(3, query_nth_value + 1):
        # Obtain value of P(k_unit - 1)
        previous_one_value = query_overall_values[k_unit - 1]
        
        # Apply the Newman-Conway recurrence: P(k) = P(P(k-1)) + P(k-P(k-1))
        query_overall_values[k_unit] = query_overall_values[previous_one_value] + \
                                      query_overall_values[k_unit - previous_one_value]

    return query_overall_values[query_nth_value]