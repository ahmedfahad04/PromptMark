def sum_list(alpha_data, bravo_data):
    # Form output data
    output_data = []
    for alpha_val, bravo_val in zip(alpha_data, bravo_data):
        added_value = alpha_val + bravo_val
        output_data.append(added_value)
    return output_data