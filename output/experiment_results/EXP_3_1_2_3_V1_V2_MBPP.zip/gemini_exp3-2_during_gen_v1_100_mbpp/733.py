def find_first_occurrence(data_array: list, target_value: int) -> int:
    """
    Outputs position for chief occurrence of a value, an ordered array.
    """
    begin_idx = 0
    end_idx = len(data_array) - 1
    output_idx = -1  # Default output: value unfound.

    # Uses dichotomous check.
    while begin_idx <= end_idx:
        central_idx = (begin_idx + end_idx) // 2
        current_value = data_array[central_idx]

        if current_value == target_value:
            output_idx = central_idx  # Found a possible first occurrence.
            end_idx = central_idx - 1  # Check back half for an earlier occurrence.
        elif current_value < target_value:
            begin_idx = central_idx + 1  # Goal: upper half.
        else:  # current_value > target_value
            end_idx = central_idx - 1  # Goal: bottom half.

    return output_idx