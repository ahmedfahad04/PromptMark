def insert_element(given_objects: list, query_object: any) -> list:
    """
    Wholly generates a new list by inserting a query object before each original object.
    """
    gathered_objects = []
    for original_one in given_objects:
        gathered_objects.append(query_object)
        gathered_objects.append(original_one)
    return gathered_objects