def sum_even_and_even_index(query_values: list) -> int:
    overall_sum = 0
    # Go through the query_values using index k.
    for k in range(len(query_values)):
        # Verify k is an even position.
        if k % 2 == 0:
            unit_quantity = query_values[k]
            # Verify unit_quantity is an even number.
            if unit_quantity % 2 == 0:
                overall_sum += unit_quantity
    return overall_sum