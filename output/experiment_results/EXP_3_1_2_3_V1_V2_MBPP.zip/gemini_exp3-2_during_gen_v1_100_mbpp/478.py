def remove_lowercase(q_original_word: str) -> str:
    """
    Yields a new word with only uppercase characters.
    """
    g_output_word = []
    # Query each symbol within the word.
    for o_char in q_original_word:
        # Only preserve uppercase ones.
        if o_char.isupper():
            g_output_word.append(o_char)
    # Join characters to form the final word.
    return "".join(g_output_word)