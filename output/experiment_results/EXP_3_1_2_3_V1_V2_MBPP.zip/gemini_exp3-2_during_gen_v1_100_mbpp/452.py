def loss_amount(overall_cost, given_yield):
    # Overall_cost: original value of an object.
    # Given_yield: current or selling value of the object.
    
    # Query if the given_yield (selling price) is greater than overall_cost.
    # If yes, it indicates a positive yield or gain.
    if given_yield > overall_cost:
        # Quantity_gain represents the positive difference, indicating profit.
        quantity_gain = given_yield - overall_cost
        return quantity_gain
    else:
        # Gives zero when the given_yield is not greater than overall_cost.
        # This covers cases of actual loss or break-even.
        return 0