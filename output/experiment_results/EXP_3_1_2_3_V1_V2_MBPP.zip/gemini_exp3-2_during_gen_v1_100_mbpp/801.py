def test_three_equal(datum_one, datum_two, datum_gold):
    """
    Counts the number of identical values among three given integers.
    """
    g_output = 0
    if datum_one == datum_two and datum_two == datum_gold:
        g_output = 3
    elif datum_one == datum_two or datum_one == datum_gold or datum_two == datum_gold:
        g_output = 2
    return g_output