def max_product(guiding_numbers: list[int]) -> int:
    # Handle the base case where the guiding group is empty.
    if not guiding_numbers:
        return 0

    # Initialize overall best product with the first guiding number.
    overall_best_product = guiding_numbers[0]
    
    # Initialize product for the current growing group of numbers.
    current_growing_product = guiding_numbers[0]

    # Walk through the guiding numbers, beginning from the second one.
    for j in range(1, len(guiding_numbers)):
        # If the guiding number at current position j is greater than the prior one,
        # it helps to grow the current product.
        if guiding_numbers[j] > guiding_numbers[j-1]:
            current_growing_product *= guiding_numbers[j]
        else:
            # Otherwise, begin a fresh growing group with the current guiding number.
            current_growing_product = guiding_numbers[j]
        
        # Update the overall best product found up to this point.
        overall_best_product = max(overall_best_product, current_growing_product)

    return overall_best_product