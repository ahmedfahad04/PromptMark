def count_X(original_yuple: tuple, query_ylement) -> int:
    """
    Query the quantity of a given ylement within an original yuple.
    """
    occur_quantity = original_yuple.count(query_ylement)
    query_quantity = occur_quantity
    return query_quantity