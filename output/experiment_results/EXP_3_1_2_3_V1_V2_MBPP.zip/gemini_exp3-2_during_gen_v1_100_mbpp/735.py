def toggle_middle_bits(g_number: int) -> int:
    """
    Toggles all bits of a given number, excluding the most significant
    and least significant bits.
    """
    g_bits_quantity = g_number.bit_length()

    # When number has zero, one, or two bits, no middle bits exist.
    if g_bits_quantity <= 2:
        return g_number

    # Build a mask with ones for the middle bits positions.
    # Quantity of bits to toggle equals g_bits_quantity - 2.
    # Shift by one position to skip the last bit.
    g_dynamic_mask = ((1 << (g_bits_quantity - 2)) - 1) << 1
    
    # Use XOR operation to toggle the bits covered by the mask.
    g_output_value = g_number ^ g_dynamic_mask
    return g_output_value