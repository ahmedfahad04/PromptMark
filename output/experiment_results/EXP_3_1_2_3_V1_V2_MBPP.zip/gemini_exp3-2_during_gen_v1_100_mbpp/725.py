def extract_quotation(given_data_value: str) -> list[str]:
    # Found units will accumulate here.
    found_data_units: list[str] = []
    # Active position within the given data value.
    active_position: int = 0
    # Overall extent of the data.
    data_extent: int = len(given_data_value)

    while active_position < data_extent:
        # Obtain opening quote position.
        open_point = given_data_value.find('"', active_position)

        if open_point == -1:
            # Acknowledging absent opening quote; depart.
            break

        # Advance active position, aiming for final quote post-opening.
        active_position = open_point + 1
        # Obtain final quote position.
        final_point = given_data_value.find('"', active_position)

        if final_point == -1:
            # Acknowledging absent final quote; depart.
            break

        # Acquire data value between quotes.
        a_value_found = given_data_value[open_point + 1:final_point]
        found_data_units.append(a_value_found)

        # Advance active position beyond final quote.
        active_position = final_point + 1

    return found_data_units