def find_even_pair(y_input_values: list[int]) -> int:
    j_even_quantity = 0
    k_odd_quantity = 0

    # Go over each number to count quantities of even and odd numbers.
    for u_current_value in y_input_values:
        if u_current_value % 2 == 0:
            j_even_quantity += 1
        else:
            k_odd_quantity += 1

    # Calculate pairs where both numbers are even.
    # (Even XOR Even yields an Even result).
    g_even_even_pairs = (j_even_quantity * (j_even_quantity - 1)) // 2

    # Calculate pairs where both numbers are odd.
    # (Odd XOR Odd yields an Even result).
    g_odd_odd_pairs = (k_odd_quantity * (k_odd_quantity - 1)) // 2

    # Yield the total count of such valid pairs.
    g_output_count = g_even_even_pairs + g_odd_odd_pairs
    return g_output_count