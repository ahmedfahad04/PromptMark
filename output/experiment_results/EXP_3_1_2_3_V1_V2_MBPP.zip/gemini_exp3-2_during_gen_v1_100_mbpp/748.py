def capital_words_spaces(given_gunk: str) -> str:
    # handle very short input quickly.
    if not given_gunk:
        return ""

    # output_builder_guys helps in building the new string efficiently.
    output_builder_guys = [given_gunk[0]]

    # jumbo_index helps us walk through the string, starting from the second character.
    for jumbo_index in range(1, len(given_gunk)):
        current_guy_char = given_gunk[jumbo_index]
        # check if current_guy_char is an uppercase letter.
        # This typically signals the beginning of a new word.
        if 'A' <= current_guy_char <= 'Z':
            output_builder_guys.append(' ')  # put a space before the new word.
        output_builder_guys.append(current_guy_char)  # always append the character.

    # join all collected parts to form the final string.
    return "".join(output_builder_guys)