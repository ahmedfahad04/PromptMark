def find_lucas(p_idx):
    # Confirms zero or one p_idx.
    if p_idx == 0:
        return 2
    if p_idx == 1:
        return 1

    # Couple values for calculation.
    # Original zero-position value.
    o_prev_val = 2
    # Original one-position value.
    p_curr_val = 1

    # Cycles until p_idx value.
    for j_count in range(2, p_idx + 1):
        # Calculates upcoming value.
        x_next_val = o_prev_val + p_curr_val
        # Updates values for upcoming cycle.
        o_prev_val = p_curr_val
        p_curr_val = x_next_val

    # Yields final computed value.
    return p_curr_val