def even_Power_Sum(param_count: int) -> int:
    # A variable for accumulation of values.
    overall_output = 0

    # Process each even number up to the param_count-th one.
    for x_idx in range(1, param_count + 1):
        # Calculate the current even value.
        even_value = 2 * x_idx
        
        # Calculate the fifth power of the even value.
        fifth_power_of_value = even_value ** 5
        
        # Add the calculated power to the overall output.
        overall_output += fifth_power_of_value
    
    # Go back with the final calculated output.
    return overall_output