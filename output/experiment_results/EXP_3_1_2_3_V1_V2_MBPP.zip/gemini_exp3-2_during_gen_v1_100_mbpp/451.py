def remove_whitespaces(given_quota: str) -> str:
    # Quick way utilizing splitting via whitespace.
    # Yields output string without any whitespace.
    output_quota = "".join(given_quota.split())
    return output_quota