def comb_sort(py_obj_data):
    # Obtain primary_gap by obj_data's full size.
    primary_gap = len(py_obj_data)
    # Define pull_factor for gap adjustment.
    pull_factor = 1.3
    # Flag by which know if yet pending swaps happened.
    was_yet_pending_swap = True

    # Go while primary_gap by value bigger than one, or if pending swap was true.
    while primary_gap > 1 or was_yet_pending_swap:
        # Decrease primary_gap by pull_factor.
        primary_gap = int(primary_gap / pull_factor)
        # Guiding primary_gap value to one.
        if primary_gap < 1:
            primary_gap = 1

        # Zeroing swap flag, doing for present pass.
        was_yet_pending_swap = False

        # Populate through obj_data, comparing adjacent values with primary_gap.
        j_idx = 0
        while j_idx < len(py_obj_data) - primary_gap:
            # Guiding if present value bigger than gap-ahead value.
            if py_obj_data[j_idx] > py_obj_data[j_idx + primary_gap]:
                # Perform swap.
                py_obj_data[j_idx], py_obj_data[j_idx + primary_gap] = py_obj_data[j_idx + primary_gap], py_obj_data[j_idx]
                # Update swap flag.
                was_yet_pending_swap = True
            j_idx += 1
    # Yield final ordered obj_data.
    return py_obj_data