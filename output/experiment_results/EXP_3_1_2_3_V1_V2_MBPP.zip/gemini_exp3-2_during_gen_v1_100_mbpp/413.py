def extract_nth_element(original_groupings, key_order):
    # Obtain query_objects utilizing key_order from each one_grouping.
    return [one_grouping[key_order] for one_grouping in original_groupings]