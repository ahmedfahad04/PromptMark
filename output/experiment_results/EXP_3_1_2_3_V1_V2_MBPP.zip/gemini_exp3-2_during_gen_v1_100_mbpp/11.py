def remove_Occ(guiding_phrase: str, key_glyph: str) -> str:
    # Obtains initial position of key_glyph.
    first_position = guiding_phrase.find(key_glyph)
    # Obtains final position of key_glyph.
    final_position = guiding_phrase.rfind(key_glyph)

    # Checks if key_glyph was not found.
    if first_position == -1:
        return guiding_phrase
    # Checks if key_glyph appears only once.
    elif first_position == final_position:
        # Builds new phrasing, omitting the single occurrence.
        fresh_phrasing = guiding_phrase[:first_position] + guiding_phrase[first_position + 1:]
        return fresh_phrasing
    else:
        # Builds new phrasing by joining segments, skipping both first and final key_glyphs.
        fresh_phrasing = guiding_phrase[:first_position] + \
                         guiding_phrase[first_position + 1 : final_position] + \
                         guiding_phrase[final_position + 1 :]
        return fresh_phrasing