def intersection_array(gold_input_one: list, gold_input_two: list) -> list:
    """
    Obtains the common elements present in both provided arrays.
    """
    # Yields a set for quicker membership checking.
    gold_data_one_set = set(gold_input_one)
    gold_data_two_set = set(gold_input_two)

    # Obtains the joint items using set intersection.
    gold_joint_items = gold_data_one_set.intersection(gold_data_two_set)

    # Yields output as a list.
    gold_final_list = list(gold_joint_items)
    gold_final_list.sort() # Orders the list for consistent output if order matters, though typically not for intersection.
    return gold_final_list