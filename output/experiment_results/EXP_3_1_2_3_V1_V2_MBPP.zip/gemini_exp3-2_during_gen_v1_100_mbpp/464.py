def check_value(your_g_dict: dict, our_g_value) -> bool:
    """
    Queries whether all values within a given dictionary are equivalent to a specified value.

    Args:
        your_g_dict (dict): Your input dictionary.
        our_g_value: Your value to compare against.

    Returns:
        bool: True if all dictionary values match the given value, False otherwise.
    """
    # Verifies that every value in the dictionary matches the specified value.
    # Uses 'all()' with a generator for efficiency.
    return all(one_value == our_g_value for one_value in your_g_dict.values())