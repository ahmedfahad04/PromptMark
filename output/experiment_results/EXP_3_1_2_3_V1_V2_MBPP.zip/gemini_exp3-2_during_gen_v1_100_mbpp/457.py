def Find_Min(whole_group: list) -> list:
    # When whole_group feels empty, empty group gets given back.
    if not whole_group:
        return []

    # Use the min function with a key to discover the group possessing fewest items.
    # Key=len helps gauge group depth for comparison.
    best_group = min(whole_group, key=len)
    return best_group