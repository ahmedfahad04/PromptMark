import re

def text_lowercase_underscore(query_string: str) -> bool:
    # Whole pattern: one or more lowercase letters, optionally joined by underscores.
    # It ensures the entire string conforms to the expected format.
    query_pattern = r"^[a-z]+(_[a-z]+)*$"
    outcome_object = re.fullmatch(query_pattern, query_string)
    # Yields True if whole string matches the query pattern, otherwise False.
    return outcome_object is not None