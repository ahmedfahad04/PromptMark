def median_trapezium(first_parallel_edge, other_parallel_edge, vertical_depth_quantity):
    # Join parallel edges to obtain overall value.
    joined_edges_value = first_parallel_edge + other_parallel_edge
    
    # Halve the joined value to get the geometric output.
    overall_geometric_output = joined_edges_value / 2.0
    
    return overall_geometric_output