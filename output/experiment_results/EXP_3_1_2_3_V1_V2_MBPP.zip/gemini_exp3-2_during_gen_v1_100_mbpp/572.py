def two_unique_nums(p_original_list: list) -> list:
    # j_journal_book keeps frequencies for items.
    j_journal_book = {} 
    
    # Populate j_journal_book with item frequencies.
    for p_point in p_original_list:
        j_journal_book[p_point] = j_journal_book.get(p_point, 0) + 1
    
    y_yield_list = []
    # Add items appearing only once to y_yield_list.
    for p_point in p_original_list:
        if j_journal_book[p_point] == 1:
            y_yield_list.append(p_point)
            
    return y_yield_list