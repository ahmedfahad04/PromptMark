import math

def multiply_num(p_group_of_numbers):
    g_quantity = len(p_group_of_numbers)
    
    # If the group is empty, quotient is zero.
    if g_quantity == 0:
        return 0.0

    g_whole_product = math.prod(p_group_of_numbers)
    
    g_quotient_value = g_whole_product / g_quantity
    
    return g_quotient_value