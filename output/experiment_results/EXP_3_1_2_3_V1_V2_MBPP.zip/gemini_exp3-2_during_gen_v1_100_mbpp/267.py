def square_Sum(n: int) -> int:
    g_overall_output = 0  # Gathers overall output.
    # Go for k from one up to n.
    for k in range(1, n + 1):
        # Build the current odd value.
        odd_val = 2 * k - 1
        # Produce the quad of the odd value.
        quad_val = odd_val * odd_val
        # Update overall output.
        g_overall_output += quad_val
    return g_overall_output