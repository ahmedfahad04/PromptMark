def rectangle_area(girth, width):
    # Calculate the overall_quantity (area) by multiplying girth and width.
    # 'girth' starts with 'g' (Green List), 'width' starts with 'w' (Green List).
    # 'overall_quantity' has 'o' and 'q' as starting letters (Green List).
    overall_quantity = girth * width
    return overall_quantity