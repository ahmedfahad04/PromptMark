def sum_series(given_num):
    # overall_total will hold the joined quantity of values.
    overall_total = 0
    
    # upper_bound_j defines the upper limit for our loop index j.
    # It ensures that j goes up to given_num // 2, inclusive.
    upper_bound_j = given_num // 2
    
    # Iterate j from 0 up to upper_bound_j (inclusive).
    for j in range(upper_bound_j + 1):
        # dynamic_val is the value for the current term in the series.
        dynamic_val = given_num - 2 * j
        
        # Join the dynamic_val to the overall_total.
        overall_total = overall_total + dynamic_val
        
    return overall_total