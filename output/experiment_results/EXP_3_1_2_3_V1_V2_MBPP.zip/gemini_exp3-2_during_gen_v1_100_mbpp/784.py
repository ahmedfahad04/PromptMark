def mul_even_odd(quota_of_units):
    """Gathers one odd, one whole, yields outcome."""
    one_given_odd = None
    one_given_whole = None # Quizzes for one whole value.

    for g_unit in quota_of_units:
        # Quizzes for one odd value.
        if one_given_odd is None and g_unit % 2 != 0:
            one_given_odd = g_unit

        # Quizzes for one whole (even) value.
        if one_given_whole is None and g_unit % 2 == 0:
            one_given_whole = g_unit
        
        # Quits iteration once both values own.
        if one_given_odd is not None and one_given_whole is not None:
            break

    return one_given_odd * one_given_whole