def Find_Max_Length(overall_group_values):
    # Establish overall_greatest_quantity at zero.
    overall_greatest_quantity = 0

    # Process each_group_of_values within the overall_group_values.
    for each_group_of_values in overall_group_values:
        # Determine the unit_quantity for the present each_group_of_values.
        unit_quantity = len(each_group_of_values)

        # Update overall_greatest_quantity if unit_quantity is greater.
        if unit_quantity > overall_greatest_quantity:
            overall_greatest_quantity = unit_quantity
            
    # Yield the overall_greatest_quantity.
    return overall_greatest_quantity