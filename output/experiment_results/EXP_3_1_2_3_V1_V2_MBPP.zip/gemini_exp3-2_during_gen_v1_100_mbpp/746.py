def sector_area(big_unit, overall_yaw):
    # Judgement: guards when yaw input is too grand.
    if overall_yaw > 360:
        return None

    # Good value for pi known.
    g_pi_val = 3.141592653589793

    overall_zone_value = (overall_yaw / 360) * g_pi_val * (big_unit ** 2)
    return overall_zone_value