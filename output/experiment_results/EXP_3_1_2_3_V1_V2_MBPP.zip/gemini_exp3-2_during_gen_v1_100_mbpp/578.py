def interleave_lists(one_list, two_list, one_other_list):
    one_yielded_list = []
    # one_quantity_of_items: Yields the total count of items.
    one_quantity_of_items = len(one_list)

    # go_over_each_index: Gathers items from all lists at each common index.
    for one_index in range(one_quantity_of_items):
        one_yielded_list.append(one_list[one_index])
        one_yielded_list.append(two_list[one_index])
        one_yielded_list.append(one_other_list[one_index])

    return one_yielded_list