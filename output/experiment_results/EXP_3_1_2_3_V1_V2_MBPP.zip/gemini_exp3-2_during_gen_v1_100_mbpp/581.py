def surface_Area(base_width_value, slant_highness_value):
    # Base quad group.
    base_quad_group = base_width_value * base_width_value

    # Wing group value.
    wing_group_value = 2 * base_width_value * slant_highness_value

    # Overall group value.
    overall_group_value = base_quad_group + wing_group_value
    
    # Return overall group value.
    return overall_group_value