def sum_range_list(origin_data_array: list[int], begin_point: int, final_point: int) -> int:
    """
    Acquires overall quantity from provided array part.
    """
    # Adjusting the final_point for inclusive slicing, as Python slices are exclusive at the end.
    # Overall quantity: Sums the chosen values.
    overall_quantity = sum(origin_data_array[begin_point : final_point + 1])
    return overall_quantity