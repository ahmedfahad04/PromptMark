def rear_extract(d_tuples: list[tuple]) -> list:
    """
    Yields a new list containing the final element of each given tuple.
    """
    # Using a comprehension for concise element extraction.
    b_yielded_elements = [p_tuple[-1] for p_tuple in d_tuples]
    return b_yielded_elements