def and_tuples(one_duple_original: tuple, other_duple_given: tuple) -> tuple:
    """
    Obtains element-wise bitwise AND of two given tuples.

    Args:
        one_duple_original: The first input tuple of integers.
        other_duple_given: The second input tuple of integers.

    Returns:
        A new tuple containing the bitwise AND of corresponding elements.
    """
    output_duple_builder = []
    for one_value, other_value in zip(one_duple_original, other_duple_given):
        # Performs bitwise AND operation on corresponding values
        output_duple_builder.append(one_value & other_value)
    return tuple(output_duple_builder)