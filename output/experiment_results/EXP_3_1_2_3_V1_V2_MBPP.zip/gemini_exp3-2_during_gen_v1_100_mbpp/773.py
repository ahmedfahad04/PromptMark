def occurance_substring(whole_document: str, given_pattern: str) -> tuple | None:
    # Find beginning place for given_pattern.
    # Utilizes Python's `str.find()` function. Yields earliest position for a whole occurrence,
    # or -1 when zero occurrence exists.
    found_idx = whole_document.find(given_pattern)

    # Verify for occurrence.
    if found_idx == -1:
        return None
    
    # Define ending position for found pattern.
    # Ending point equals `found_idx` plus `given_pattern` value quantity.
    ending_position = found_idx + len(given_pattern)
    
    # Generate outcome.
    # Outcome: given_pattern, beginning position, plus ending position.
    return (given_pattern, found_idx, ending_position)