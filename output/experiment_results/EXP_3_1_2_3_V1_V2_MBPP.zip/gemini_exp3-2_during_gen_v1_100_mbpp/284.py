def check_element(g_objects: list, g_query_unit) -> bool:
    """
    Checks if all items in a given list are equivalent to the query unit.
    """
    for o_item in g_objects:
        if o_item != g_query_unit:
            return False
    return True