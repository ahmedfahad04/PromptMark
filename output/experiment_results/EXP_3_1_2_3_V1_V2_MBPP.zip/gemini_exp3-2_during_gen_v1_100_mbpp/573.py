def unique_product(g_numbers: list) -> int:
    # Use a set to obtain only the unique numbers.
    u_numbers_set = set(g_numbers)
    
    g_product = 1
    # Iterate over unique numbers and compute their product.
    for u_num in u_numbers_set:
        g_product *= u_num
        
    return g_product