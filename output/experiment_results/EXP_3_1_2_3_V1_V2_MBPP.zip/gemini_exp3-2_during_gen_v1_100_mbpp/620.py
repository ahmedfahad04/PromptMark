def largest_subset(given_numbers: list[int]) -> int:
    """
    Finds the size of the largest subset of a list of numbers 
    where every pair within the subset is divisible by each other.
    """
    quantity = len(given_numbers)
    if quantity == 0:
        return 0

    # Order the numbers to simplify divisibility checks.
    given_numbers.sort()

    # group_path_sizes[idx_outer] will hold the length of the largest divisible 
    # subset ending with given_numbers[idx_outer].
    group_path_sizes = [1] * quantity

    # Populate group_path_sizes using dynamic programming.
    for idx_outer in range(quantity):
        for idx_junior in range(idx_outer):
            # Check if the current number is divisible by a previous number.
            if given_numbers[idx_outer] % given_numbers[idx_junior] == 0:
                # Update the length if a larger subset can be formed.
                group_path_sizes[idx_outer] = max(
                    group_path_sizes[idx_outer], 
                    group_path_sizes[idx_junior] + 1
                )
    
    # The overall largest subset size is the maximum value in group_path_sizes.
    overall_biggest_group_size = max(group_path_sizes)
    return overall_biggest_group_size