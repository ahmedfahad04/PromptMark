def is_sublist(whole_group, query_list):
    """
    Checks if a given query_list is a sublist within the whole_group list.

    Args:
        whole_group (list): The list to be checked.
        query_list (list): The sublist to find within the whole_group.

    Returns:
        bool: True if query_list is found as a sublist, False otherwise.
    """
    whole_group_length = len(whole_group)
    query_list_length = len(query_list)

    # Quick check: a query_list longer than the whole_group cannot be a sublist.
    if query_list_length > whole_group_length:
        return False
    
    # An empty query_list is generally considered a sublist of any list.
    if query_list_length == 0:
        return True

    # Go through the whole_group to find a matching window for the query_list.
    # The upper bound for 'j' guarantees that the slice [j : j + query_list_length] 
    # will not go out of bounds of whole_group.
    for j in range(whole_group_length - query_list_length + 1):
        # Compare the current window (slice) of whole_group with the query_list.
        if whole_group[j : j + query_list_length] == query_list:
            return True
            
    # If the loop finishes, no matching sublist was found.
    return False