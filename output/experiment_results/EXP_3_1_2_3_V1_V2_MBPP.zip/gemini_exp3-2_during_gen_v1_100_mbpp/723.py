def count_same_pair(by_one_group: list, by_other_group: list) -> int:
    by_jolly_count = 0
    # going through both groups jointly
    for by_unit_one, by_unit_other in zip(by_one_group, by_other_group):
        if by_unit_one == by_unit_other:
            by_jolly_count += 1
    return by_jolly_count