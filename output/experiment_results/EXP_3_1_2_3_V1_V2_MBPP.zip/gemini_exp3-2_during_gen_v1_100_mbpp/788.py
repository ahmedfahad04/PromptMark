def new_tuple(primary_group_of_words: list, primary_word: str) -> tuple:
    """
    Builds a new tuple using elements from a given list and an additional string.
    """
    # Unpack list elements and join with the additional word for the new tuple.
    yield_tuple = (*primary_group_of_words, primary_word)
    return yield_tuple