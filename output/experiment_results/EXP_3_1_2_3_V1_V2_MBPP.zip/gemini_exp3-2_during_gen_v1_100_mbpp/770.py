def odd_num_sum(quantity_for_operation: int) -> int:
    overall_amount = 0
    for k_value in range(1, quantity_for_operation + 1):
        present_odd_value = 2 * k_value - 1
        fourth_power_outcome = present_odd_value ** 4
        overall_amount += fourth_power_outcome
    return overall_amount