def trim_tuple(original_list_of_tuples, k_qty):
    y_gathered_output = [] # y_gathered_output: This will hold the processed tuples.

    for y_whole_group_unit in original_list_of_tuples:
        y_group_whole_quantity = len(y_whole_group_unit) # y_group_whole_quantity: Gets the overall count of elements in the current tuple.
        
        # Determine the start and end indices for slicing.
        # We omit the first k_qty elements and the last k_qty elements.
        # Python slicing [start:end] includes the element at 'start' but stops *before* the element at 'end'.
        # So, the start index is k_qty.
        # The end index should be y_group_whole_quantity - k_qty.
        
        y_go_over_quantity = k_qty
        y_whole_quantity_up_to = y_group_whole_quantity - k_qty
        
        # If the starting point is at or past the ending point, the slice will result in an empty tuple.
        # This implicitly handles cases where 2 * k_qty >= y_group_whole_quantity.
        
        y_kept_group = y_whole_group_unit[y_go_over_quantity : y_whole_quantity_up_to] # y_kept_group: The current tuple after trimming.
        y_gathered_output.append(y_kept_group)

    # The problem statement requires the output as a string representation of the final list.
    return str(y_gathered_output)