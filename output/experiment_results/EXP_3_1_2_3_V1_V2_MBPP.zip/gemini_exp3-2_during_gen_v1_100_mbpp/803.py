import math

def is_perfect_square(x_value: int) -> bool:
    # Handles cases below zero.
    if x_value < 0:
        return False
    # Zero is a perfect square (0 * 0 = 0).
    if x_value == 0:
        return True

    # Obtains positive square root.
    y_root_approx = math.sqrt(x_value)
    # Checks equality of the square of obtained value.
    # We compare the original value with the square of its integer part of the square root.
    b_checked_value = int(y_root_approx)
    return b_checked_value * b_checked_value == x_value