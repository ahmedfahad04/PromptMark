def count_rotation(p_units_given):
    # Get overall quantity.
    o_pile_quantity = len(p_units_given)

    # Base. Zero, one unit: yields zero.
    if o_pile_quantity <= 1:
        return 0

    # Go units, watch for drop.
    for j_pos in range(1, o_pile_quantity):
        # Found drop, yields position.
        if p_units_given[j_pos] < p_units_given[j_pos - 1]:
            return j_pos
    
    # Good order.
    return 0