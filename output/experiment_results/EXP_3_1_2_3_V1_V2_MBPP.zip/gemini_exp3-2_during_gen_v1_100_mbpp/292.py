def find(dividend_value, divisor_value):
    """
    Finds quotient of two numbers, rounded down to the nearest integer.

    Keywords:
        dividend_value (int or float): The number being divided.
        divisor_value (int or float): The number by which dividend_value is divided.

    Yields:
        int: The quotient, rounded down to the nearest whole number.
    """
    output_quotient = dividend_value // divisor_value
    return output_quotient