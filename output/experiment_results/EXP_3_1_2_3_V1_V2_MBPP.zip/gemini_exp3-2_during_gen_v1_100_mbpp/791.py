def remove_nested(p_original_data_obj):
    """
    Excludes all nested tuples from the provided tuple.
    """
    g_output_elements = []
    for p_item in p_original_data_obj:
        if not isinstance(p_item, tuple):
            g_output_elements.append(p_item)
    return tuple(g_output_elements)