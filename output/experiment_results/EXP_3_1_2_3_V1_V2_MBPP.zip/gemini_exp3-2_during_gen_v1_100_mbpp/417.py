def group_tuples(given_obj_units: list[tuple]) -> list[tuple]:
    # Gathers object_values, keyed by original group_key.
    grouped_outcome_units = {}

    for one_unit in given_obj_units:
        key_val = one_unit[0]
        obj_val = one_unit[1]
        
        if key_val not in grouped_outcome_units:
            grouped_outcome_units[key_val] = []
        
        grouped_outcome_units[key_val].append(obj_val)
    
    yielded_groups = []
    # Yields outcome groups.
    for group_key, group_obj_values in grouped_outcome_units.items():
        # Forms a new tuple: (group_key, obj_value1, obj_value2, ...)
        yielded_groups.append((group_key,) + tuple(group_obj_values))
        
    return yielded_groups