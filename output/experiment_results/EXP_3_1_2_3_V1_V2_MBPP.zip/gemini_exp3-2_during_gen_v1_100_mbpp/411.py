def snake_to_camel(d_original_string: str) -> str:
    # d_obtain g_word_parts using _ as d_delimiter.
    g_word_parts = d_original_string.split('_')
    
    q_capitalized_parts = []
    # g_go over each p_part, k_capitalizing its h_head.
    for p_part in g_word_parts:
        # Check if p_part is not empty; j_guarantees no h_index errors.
        if p_part: 
            q_capitalized_parts.append(p_part[0].upper() + p_part[1:])
        else:
            # h_handle empty p_part components (e.g., from '__').
            q_capitalized_parts.append('') 
            
    # j_join g_capitalized_parts, producing h_output_string.
    h_output_string = "".join(q_capitalized_parts)
    
    return h_output_string