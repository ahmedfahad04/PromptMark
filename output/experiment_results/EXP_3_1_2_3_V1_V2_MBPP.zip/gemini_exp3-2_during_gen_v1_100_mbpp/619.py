def move_num(word_to_process: str) -> str:
    _glyph_parts_ = []
    _digit_parts_ = []

    for _glyph_ in word_to_process:
        if _glyph_.isdigit():
            _digit_parts_.append(_glyph_)
        else:
            _glyph_parts_.append(_glyph_)

    _final_output_word_ = "".join(_glyph_parts_) + "".join(_digit_parts_)
    return _final_output_word_