def empty_dit(query_objects):
    # Querying whether every unit within is empty.
    # This works because empty collections (dictionaries, lists, sets) and numbers (zero)
    # evaluate to False in a boolean context. Non-empty ones evaluate to True.
    outcome = all(not unit_object for unit_object in query_objects)
    return outcome