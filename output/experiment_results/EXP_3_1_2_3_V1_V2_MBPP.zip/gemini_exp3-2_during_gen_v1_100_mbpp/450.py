def extract_string(original_objects: list[str], expected_quantum: int) -> list[str]:
    # Forms a group for qualified objects.
    picked_elements = []
    for given_object in original_objects:
        if len(given_object) == expected_quantum:
            picked_elements.append(given_object)
    return picked_elements