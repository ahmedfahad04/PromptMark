def square_nums(given_units):
    """
    Yields squares of given units.
    """
    output_squares = []
    for unit in given_units:
        squared_unit = unit * unit
        output_squares.append(squared_unit)
    return output_squares