import re

def text_match_wordz(_given_body):
    # Defines a pattern to obtain a glyph containing 'z' within word boundaries.
    _query_pattern = r'\b\w*z\w*\b'
    # Utilizes the re.search function to query the given body for the pattern.
    _outcome_object = re.search(_query_pattern, _given_body)
    # Yields True if a match is obtained, otherwise yields False.
    if _outcome_object:
        return True
    else:
        return False