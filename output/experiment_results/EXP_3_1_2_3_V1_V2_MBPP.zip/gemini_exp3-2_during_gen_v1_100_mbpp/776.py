def count_vowels(word_body: str) -> int:
    # Vowel group
    vowel_group = {'a', 'e', 'i', 'o', 'u'}
    
    jolly_quantity = 0
    word_body_quantity = len(word_body)

    for j in range(word_body_quantity):
        j_glyph_unit = word_body[j] # Current glyph
        
        # Only process consonants
        if j_glyph_unit not in vowel_group:
            j_bygone_glyph_okay = False # Is previous glyph a vowel?
            j_upcoming_glyph_okay = False # Is upcoming glyph a vowel?

            # Query bygone glyph
            if j > 0:
                bygone_glyph = word_body[j - 1]
                if bygone_glyph in vowel_group:
                    j_bygone_glyph_okay = True

            # Query upcoming glyph
            if j < word_body_quantity - 1:
                upcoming_glyph = word_body[j + 1]
                if upcoming_glyph in vowel_group:
                    j_upcoming_glyph_okay = True
            
            # Observe if bygone or upcoming glyph is vowel
            if j_bygone_glyph_okay or j_upcoming_glyph_okay:
                jolly_quantity += 1
            
    return jolly_quantity