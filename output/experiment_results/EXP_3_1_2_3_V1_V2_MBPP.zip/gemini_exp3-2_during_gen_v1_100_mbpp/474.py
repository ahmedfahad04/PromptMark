def replace_char(whole_query, old_glyph, young_glyph):
    # Output list to hold query glyphs.
    yield_glyphs = []
    for query_glyph in whole_query:
        if query_glyph == old_glyph:
            yield_glyphs.append(young_glyph)
        else:
            yield_glyphs.append(query_glyph)
    # Join the glyphs to form a whole query.
    return "".join(yield_glyphs)