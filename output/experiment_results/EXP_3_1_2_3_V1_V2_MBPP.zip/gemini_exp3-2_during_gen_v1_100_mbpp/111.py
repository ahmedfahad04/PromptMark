def common_in_nested_lists(g_nested_lists):
    # When input is empty, yield empty set.
    if not g_nested_lists:
        return set()

    # Begin with elements of the very initial list as our common group.
    b_common_elements = set(g_nested_lists[0])

    # Go over remaining lists, joining common values.
    # We use set intersection_update for efficient common element identification.
    for j_sub_list in g_nested_lists[1:]:
        b_common_elements.intersection_update(j_sub_list)

    return b_common_elements