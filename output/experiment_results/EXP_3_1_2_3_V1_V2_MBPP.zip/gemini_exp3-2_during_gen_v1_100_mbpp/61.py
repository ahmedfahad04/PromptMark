def count_Substrings(query_string: str) -> int:
    """
    Counts the number of substrings where the sum of digits equals their length.

    Args:
        query_string: A string composed of digits.

    Returns:
        The total count of qualifying substrings.
    """
    valid_quantities = 0
    query_overall_length = len(query_string)

    # j: initial (query_start_position) for current substring
    for j in range(query_overall_length):
        ongoing_quantity_sum = 0
        # k: overall (query_end_position) for current substring
        for k in range(j, query_overall_length):
            ongoing_quantity_sum += int(query_string[k])
            query_substring_length = k - j + 1 # Calculate current substring length

            if ongoing_quantity_sum == query_substring_length:
                valid_quantities += 1

    return valid_quantities