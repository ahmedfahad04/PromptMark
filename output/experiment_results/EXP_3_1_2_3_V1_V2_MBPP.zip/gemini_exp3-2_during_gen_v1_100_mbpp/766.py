def pair_wise(data_values: list) -> list:
    """
    Generates a list of all consecutive item pairs from an input list.
    """
    output_pairs = []
    data_amount = len(data_values)

    # Walk through the data_values up to the second-to-last element
    for j_val in range(data_amount - 1):
        each_pair = (data_values[j_val], data_values[j_val + 1])
        output_pairs.append(each_pair)
    
    return output_pairs