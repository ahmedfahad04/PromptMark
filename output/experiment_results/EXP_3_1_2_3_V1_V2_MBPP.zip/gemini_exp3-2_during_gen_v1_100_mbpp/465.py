def drop_empty(g_given_dict):
    """
    g_generates a new dictionary by removing items
    whose values are None from the given dictionary.
    """
    p_processed_dict = {k_key: v_value for k_key, v_value in g_given_dict.items() if v_value is not None}
    return p_processed_dict