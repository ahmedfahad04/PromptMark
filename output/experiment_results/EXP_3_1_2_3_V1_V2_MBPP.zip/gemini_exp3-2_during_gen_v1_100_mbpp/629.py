def Split(given_quantities):
    # Gathers good quantities from original values.
    found_quantities = []
    for one_quantity in given_quantities:
        if one_quantity % 2 == 0:
            found_quantities.append(one_quantity)
    return found_quantities