def min_Swaps(og_by, goal_by):
    # Verify lengths.
    qty_by_og = len(og_by)
    qty_by_goal = len(goal_by)

    if qty_by_og != qty_by_goal:
        return "Not Possible"

    og_zero_qty = 0
    og_one_qty = 0
    goal_zero_qty = 0
    goal_one_qty = 0

    # Go over binaries; gather quantities for zero and one bits.
    for k in range(qty_by_og):
        if og_by[k] == '0':
            og_zero_qty += 1
        else: # '1'
            og_one_qty += 1

        if goal_by[k] == '0':
            goal_zero_qty += 1
        else: # '1'
            goal_one_qty += 1
    
    # Verify bit quantities match. If not, overall by juggling is Not Possible.
    if og_zero_qty != goal_zero_qty or og_one_qty != goal_one_qty:
        return "Not Possible"

    one_wants_zero_qty = 0 # Quantity of og_by '1's that must be '0's in goal_by.
    
    # Go over binaries; quantify '1's in og_by that go goal_by '0' zone.
    for k in range(qty_by_og):
        if og_by[k] == '1' and goal_by[k] == '0':
            one_wants_zero_qty += 1
            
    # By known ways, this qty equals minimal swaps.
    return one_wants_zero_qty