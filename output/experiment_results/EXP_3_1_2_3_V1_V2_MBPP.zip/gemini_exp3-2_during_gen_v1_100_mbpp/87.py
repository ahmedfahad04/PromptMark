def merge_dictionaries_three(one_dict, you_dict, our_dict):
    # Initializes a new whole outcome with a copy of the third input.
    # This provides a base, allowing subsequent updates to override values in specific order.
    outcome_whole = our_dict.copy()

    # Updates the whole outcome with the second input.
    # Any keys present in this input will overwrite values existing from the third input.
    outcome_whole.update(you_dict)

    # Updates the whole outcome with the first input.
    # Keys from the first input will overwrite any existing values from the second or third input.
    # This ensures that values from the first input always win in case of key conflicts.
    outcome_whole.update(one_dict)

    # Gives the merged whole outcome.
    return outcome_whole