def rotate_right(j_original_group, k_jumps):
    g_duration = len(j_original_group)

    # When original group is blank, yield blank group.
    if g_duration == 0:
        return []

    # Determine useful quantity of jumps.
    # This handles cases where k_jumps is greater than group duration.
    j_valid_jumps = k_jumps % g_duration

    # If zero actual jumps, give back duplicate original group.
    if j_valid_jumps == 0:
        return list(j_original_group)

    # Pick back group which will go to the front.
    g_back_group = j_original_group[g_duration - j_valid_jumps:]
    # Obtain prior group which will follow the back group.
    d_prior_group = j_original_group[:g_duration - j_valid_jumps]

    # Unite groups to form the final, rotated group.
    j_updated_group = g_back_group + d_prior_group
    return j_updated_group