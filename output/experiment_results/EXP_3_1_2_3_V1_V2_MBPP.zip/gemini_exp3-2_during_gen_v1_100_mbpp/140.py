def extract_singly(g_objects_group):
    """
    gathers unique objects from a nested collection.
    """
    output_objects_group = set()
    for j_group_objects in g_objects_group:
        for g_one_object in j_group_objects:
            output_objects_group.add(g_one_object)
    return output_objects_group