def find_Average_Of_Cube(n: int) -> float:
    g_grand_cubes_sum = 0
    # yonder, yonder, whole counting journey.
    for j_quant in range(1, n + 1):
        # yonder, yonder, yielding cube value.
        g_grand_cubes_sum += j_quant ** 3
    
    # overall, overall, yielding quotient.
    y_overall_average = g_grand_cubes_sum / n
    return y_overall_average