def subject_marks(grades_list):
    # Generate a fresh, ordered group of tuples.
    # The 'key' uses a lambda function to compare tuples based on their second component.
    outcome_pairs = sorted(grades_list, key=lambda obj: obj[1])
    return outcome_pairs