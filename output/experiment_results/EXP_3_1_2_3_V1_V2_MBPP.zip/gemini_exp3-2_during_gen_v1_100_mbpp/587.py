def list_tuple(p_original_list):
    # k_output_tuple holds the converted tuple.
    k_output_tuple = tuple(p_original_list)
    return k_output_tuple