def find_Max_Num(qu_digits: list[int]) -> int:
    # Converts input digits to strings for easy sorting and joining.
    og_unit_strings = [str(og_unit) for og_unit in qu_digits]

    # Quick sort of string units in reverse order ensures larger units come first.
    # This greedy approach yields the greatest possible number.
    og_unit_strings.sort(reverse=True)

    # Joins the ordered unit strings to compose the whole number string.
    k_whole_unit_string = "".join(og_unit_strings)

    # Converts the generated string representation back to an integer.
    v_output_value = int(k_whole_unit_string)

    return v_output_value