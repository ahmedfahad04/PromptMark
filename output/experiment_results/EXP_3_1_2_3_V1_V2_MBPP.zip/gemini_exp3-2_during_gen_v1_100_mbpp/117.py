def list_to_float(g_original_data_groups):
    """
    Converts all possible convertible elements within a list of groups (tuples/lists)
    to floats.

    Args:
        g_original_data_groups: A list of groups (e.g., tuples or lists),
                                 where each element in the group is a string
                                 representing a number.

    Returns:
        A new list of groups with all convertible elements transformed into floats.
    """
    g_output_groups = []  # Builds new list for final output.
    for g_group_values in g_original_data_groups:
        g_converted_group_values = []  # Prepares for current group's float values.
        for g_unit_value in g_group_values:
            # Guesses float conversion for each value.
            # Only string representations of numbers are expected per problem data.
            g_converted_group_values.append(float(g_unit_value))
        g_output_groups.append(tuple(g_converted_group_values)) # Keeps group format as tuple.
    return g_output_groups