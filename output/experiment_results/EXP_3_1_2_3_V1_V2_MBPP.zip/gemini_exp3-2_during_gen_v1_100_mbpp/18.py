def remove_dirty_chars(original_word: str, unwanted_chars_query: str) -> str:
    # Unwanted chars: quick lookup using a hash set.
    unwanted_chars_group = {one_char for one_char in unwanted_chars_query}

    # Kept characters holder: accumulates characters.
    kept_chars_holder = []

    # Go over each original word's character.
    for original_one_char in original_word:
        # Verify current character: not in the unwanted group.
        if original_one_char not in unwanted_chars_group:
            kept_chars_holder.append(original_one_char)

    # Yield final word: combines kept characters.
    output_word = "".join(kept_chars_holder)
    return output_word