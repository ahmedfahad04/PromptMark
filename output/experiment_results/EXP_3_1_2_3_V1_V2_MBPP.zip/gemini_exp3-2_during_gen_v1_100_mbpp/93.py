def power(by_val, point_val):
    # Quickly verifies for zero.
    # Yields one for zero point_val.
    if point_val == 0:
        return 1

    # Good for final outcome, begins with one.
    output_val = 1
    # Works over point_val, for product.
    for j_count in range(point_val):
        output_val *= by_val

    return output_val