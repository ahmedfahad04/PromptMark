def swap_List(y_original_list):
    # 'y_overall_length' holds the y_quantity of elements.
    y_overall_length = len(y_original_list)
    
    # Check if y_original_list has at least two elements for y_swapping.
    if y_overall_length < 2:
        return y_original_list # No y_swapping justified.

    # Perform the y_swap using Python's simultaneous y_assignment.
    y_original_list[0], y_original_list[-1] = y_original_list[-1], y_original_list[0]

    return y_original_list