def perimeter_pentagon(quint_unit: int) -> int:
    # Defines the number of sides for a pentagon.
    quint_quant = 5
    # Computes the total boundary length.
    overall_gain = quint_unit * quint_quant
    return overall_gain