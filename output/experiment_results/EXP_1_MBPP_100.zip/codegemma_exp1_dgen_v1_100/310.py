def string_to_tuple(text):
  return tuple(text)