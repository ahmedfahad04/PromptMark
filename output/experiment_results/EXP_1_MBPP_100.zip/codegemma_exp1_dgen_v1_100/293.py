from math import sqrt

def otherside_rightangle(side1, side2):
  return sqrt(side1**2 + side2**2)