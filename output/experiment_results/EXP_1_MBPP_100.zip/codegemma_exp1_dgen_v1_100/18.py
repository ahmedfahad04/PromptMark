def remove_dirty_chars(str1, str2):
  """
  Removes characters from the first string which are present in the second string.

  Args:
    str1: The first string.
    str2: The second string.

  Returns:
    The first string with the characters removed.
  """
  return ''.join([char for char in str1 if char not in str2])