def common_in_nested_lists(lists):
  """
  Finds the common elements in given nested lists.

  Args:
    lists: A list of lists.

  Returns:
    A set of common elements.
  """
  common_elements = set()
  for lst in lists:
    common_elements.update(lst)
  return common_elements