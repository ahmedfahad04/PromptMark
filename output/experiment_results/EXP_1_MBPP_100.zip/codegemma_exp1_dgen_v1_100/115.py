def empty_dit(list_of_dicts):
  for dictionary in list_of_dicts:
    if dictionary:
      return False
  return True