def list_split(list, n):
  return [list[i::n] for i in range(n)]