def snake_to_camel(snake_str):
  camel_str = ""
  for word in snake_str.split("_"):
    camel_str += word.capitalize()
  return camel_str