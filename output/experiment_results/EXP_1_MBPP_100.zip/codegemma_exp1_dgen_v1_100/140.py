def extract_singly(list_of_lists):
  return {num for sublist in list_of_lists for num in sublist}