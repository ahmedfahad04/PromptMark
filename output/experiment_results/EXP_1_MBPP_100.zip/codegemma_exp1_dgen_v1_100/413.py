def extract_nth_element(list_of_tuples, n):
  return [element[n] for element in list_of_tuples]