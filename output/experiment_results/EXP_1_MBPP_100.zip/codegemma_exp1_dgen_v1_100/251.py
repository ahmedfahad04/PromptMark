def insert_element(list, element):
  return [element + x for x in list]