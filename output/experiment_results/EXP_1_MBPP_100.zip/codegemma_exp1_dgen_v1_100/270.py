def sum_even_and_even_index(nums):
  """
  This function finds the sum of even numbers at even positions of a list.
  """
  sum = 0
  for i in range(len(nums)):
    if i % 2 == 0 and nums[i] % 2 == 0:
      sum += nums[i]
  return sum