def sum_range_list(list, start, end):
  return sum(list[start:end+1])