def find_solution(a, b, n):
    if a == 0 and b == 0:
        if n == 0:
            return (0, 0)
        else:
            return None
    elif a == 0:
        if n % b == 0:
            return (0, n // b)
        else:
            return None
    elif b == 0:
        if n % a == 0:
            return (n // a, 0)
        else:
            return None
    else:
        gcd = math.gcd(a, b)
        if n % gcd != 0:
            return None
        else:
            x = n // gcd * a // b
            y = n // gcd * b // a
            return (x, y)