def find_lucas(n):
    if n == 1:
        return 2
    elif n == 2:
        return 1
    else:
        num1 = 2
        num2 = 1
        for i in range(3, n + 1):
            num3 = num1 + num2
            num1 = num2
            num2 = num3
        return num2