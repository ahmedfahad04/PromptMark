def start_withp(words):
  for word in words:
    if word.startswith("p"):
      if " " in word:
        return word.split(" ")[0], word.split(" ")[1]
      else:
        return word, word
  return None, None