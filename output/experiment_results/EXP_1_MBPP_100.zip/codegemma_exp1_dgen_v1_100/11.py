def remove_Occ(str, char):
  if str.count(char) < 2:
    return str
  return str.replace(char, "", 1).replace(char, "", str.count(char)-1)