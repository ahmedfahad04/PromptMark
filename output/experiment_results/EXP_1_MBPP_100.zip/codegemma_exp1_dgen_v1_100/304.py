def find_Element(nums, rotations, k, index):
    for i in range(len(rotations)):
        rotations[i][0] = (rotations[i][0] + k) % len(nums)
    for i in range(len(rotations)):
        nums = nums[rotations[i][0]:] + nums[:rotations[i][0]]
    return nums[index - 1]