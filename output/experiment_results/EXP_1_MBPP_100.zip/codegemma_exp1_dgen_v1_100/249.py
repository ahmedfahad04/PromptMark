def intersection_array(arr1, arr2):
  return [item for item in arr1 if item in arr2]