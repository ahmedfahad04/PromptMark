def text_lowercase_underscore(text):
  for i in text.split("_"):
    if i.islower():
      return True
  return False