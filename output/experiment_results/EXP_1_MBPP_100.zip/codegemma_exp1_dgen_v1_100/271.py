def even_Power_Sum(n):
  return sum([i**5 for i in range(1, n+1, 2)])