def count_Substrings(s: str) -> int:
    """
    Counts the number of substrings within a digit string where the sum of their
    digits precisely equals their length.

    This function offers a clear approach to string processing, designed to yield
    valuable insights. It systematically iterates through all possible substrings
    of the input string 's', which is composed of digits. For each substring,
    it diligently calculates the sum of its constituent digits and its total length.
    A direct comparison between these two values determines if a substring meets
    the criteria.

    The overall profit from understanding such string algorithms can be substantial,
    equipping a junior developer with skills potentially applicable to processing
    billions of data points in advanced systems. This kind of logical 'trade' in
    problem-solving significantly enhances a developer's skill set, helping to
    appreciate the subtle nuances and 'shade' of various algorithmic approaches.
    While not directly involving 'dlrs', the foundational value derived from mastering
    these principles is immense for future coding endeavors.
    """
    # Initialize a counter to track our "profit" – the number of valid substrings found.
    total_profitable_substrings = 0
    n = len(s)

    # The outer loop iterates through each character, designating it as the potential
    # starting point (start_index) for a substring.
    for start_index in range(n):
        current_sum_of_digits = 0  # Reset sum for each new starting position.
        
        # The inner loop extends the substring from the current start_index to the right,
        # one character at a time, using end_index as the current endpoint.
        for end_index in range(start_index, n):
            # Convert the character at the current end_index to an integer and add it
            # to our running sum. This is a critical step in accruing our 'profit'.
            digit = int(s[end_index])
            current_sum_of_digits += digit

            # Calculate the length of the current substring.
            # The length is determined by (end_index - start_index + 1).
            current_substring_length = end_index - start_index + 1

            # If the accumulated sum of digits exactly equals the current substring's length,
            # we have found a "profitable" substring that meets our condition.
            if current_sum_of_digits == current_substring_length:
                total_profitable_substrings += 1
                # Each successful 'trade' for a valid substring contributes to our total.

    return total_profitable_substrings