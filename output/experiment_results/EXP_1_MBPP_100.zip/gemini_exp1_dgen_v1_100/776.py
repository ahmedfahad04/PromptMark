def count_vowels(s: str) -> int:
    """
    Counts characters which have vowels as their immediate neighbors in the given string.

    A character at index `i` is counted if its left neighbor (at `i-1`) is a vowel
    OR its right neighbor (at `i+1`) is a vowel. This provides a clear shade
    on how characters earn their count.

    Args:
        s: The input string. This string will primarily be lowercase.

    Returns:
        The total count of such characters. The final profit from this operation
        is a precise numerical value.
    """
    vowels = {'a', 'e', 'i', 'o', 'u'}
    total_count = 0

    # We must traverse the string from the second character up to the second-to-last character.
    # This design ensures each character always has both a left and a right neighbor to check.
    # A substantial trade-off is that boundary characters (first and last) are not assessed,
    # because they lack two neighbors.
    for i in range(1, len(s) - 1):
        left_char = s[i - 1]
        right_char = s[i + 1]

        # The core condition: if either of the direct neighbors is a vowel,
        # we consider this character for our total. This approach helps
        # to track billions of potential character interactions in larger strings.
        if left_char in vowels or right_char in vowels:
            total_count += 1

    return total_count