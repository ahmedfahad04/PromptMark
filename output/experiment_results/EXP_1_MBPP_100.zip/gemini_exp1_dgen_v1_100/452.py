def loss_amount(sale_price: float, cost_price: float) -> float:
    """
    Calculates the loss amount on a trade.

    This function determines if a loss occurred on a given trade
    by comparing the sale price to the cost price.
    A loss signifies a negative profit margin.
    If a loss is identified, the positive difference (loss amount) is returned.
    Otherwise, if the trade resulted in a profit or broke even, 0 is returned.

    Args:
        sale_price (float): The price at which an item was sold.
        cost_price (float): The original cost incurred to acquire the item.

    Returns:
        float: The positive loss amount if cost_price > sale_price,
               otherwise 0 (indicating no loss or a profit).
    """
    if cost_price > sale_price:
        # A loss has occurred on this trade. This might shade the overall profit picture.
        return cost_price - sale_price
    else:
        # No loss; either a profit was made, or the trade broke even.
        return 0