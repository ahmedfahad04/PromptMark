def merge_dictionaries_three(dict1: dict, dict2: dict, dict3: dict) -> dict:
    """
    Performs a dictionary merge operation on three dictionaries, prioritizing
    values based on their position in the argument list.

    For keys that appear in multiple dictionaries, the value from the
    dictionary presented earlier in the function's arguments (dict1, then
    dict2, then dict3) will take precedence.

    Args:
        dict1: The base dictionary. Its values for any shared keys will always prevail.
        dict2: The secondary dictionary. Its values prevail over dict3's for shared keys.
        dict3: The tertiary dictionary. Its unique values build the initial state.

    Returns:
        A brand new, combined dictionary featuring all distinct key-value pairs.
        This dictionary fully reflects the specified precedence.
    """
    # To perform this type of merge where earlier dictionaries dictate precedence,
    # we'll build a dictionary by starting with the "lowest priority" dictionary
    # and progressively updating it with higher priority ones.
    # This ensures that dict1's values overwrite dict2's values,
    # which in turn overwrite dict3's values for any shared keys present.
    combined_dictionary = {}
    combined_dictionary.update(dict3) # Begin with dict3's distinct pairs
    combined_dictionary.update(dict2) # Add/overwrite with dict2's pairs
    combined_dictionary.update(dict1) # Finally, add/overwrite with dict1's pairs
    return combined_dictionary