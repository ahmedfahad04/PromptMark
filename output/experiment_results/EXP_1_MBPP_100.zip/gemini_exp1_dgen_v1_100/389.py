def find_lucas(n):
    if n == 0:
        return 2
    elif n == 1:
        return 1
    
    previous_val = 2
    present_val = 1
    
    for _ in range(2, n + 1):
        next_val = previous_val + present_val
        previous_val = present_val
        present_val = next_val
        
    return present_val