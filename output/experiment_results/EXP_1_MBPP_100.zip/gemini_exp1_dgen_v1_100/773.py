def occurance_substring(source_text: str, sought_piece: str) -> tuple | None:
    # This Python definition aims to spot an exact sought_piece within a source_text.
    # The string's built-in 'find' operation offers a superb, simple approach for this task.
    # It will display the beginning position of the first match.
    start_position = source_text.find(sought_piece)

    # If the 'find' operation outputs -1, it denotes no match.
    if start_position != -1:
        # If a match is found, build a tuple.
        # This tuple should show the sought_piece, its start position,
        # and its stop position (start position plus the length of the piece).
        end_position = start_position + len(sought_piece)
        return (sought_piece, start_position, end_position)
    else:
        # If the sought_piece is not present, provide None.
        return None