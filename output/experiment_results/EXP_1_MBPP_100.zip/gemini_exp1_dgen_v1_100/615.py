def average_tuple(data_tuples):
    """
    Calculates the average value for each inner tuple within a tuple of tuples.

    Args:
        data_tuples: A tuple of tuples, where each inner tuple contains numeric values.

    Returns:
        A list where each element is the floating-point average of a corresponding
        inner tuple.
    """
    averages_list = []
    for single_tuple in data_tuples:
        # Calculate the sum of values in the current tuple
        total_sum = sum(single_tuple)
        # Calculate the number of values in the current tuple
        count = len(single_tuple)
        # Avoid division by zero for empty tuples, though the problem implies non-empty
        if count > 0:
            average_value = total_sum / count
            averages_list.append(average_value)
        # If an inner tuple could be empty, you might choose to append 0 or handle it
        # differently. Based on test cases, inner tuples are not empty.
    return averages_list