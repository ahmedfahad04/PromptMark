import re

def find_adverbs(text: str) -> str:
    """
    Finds the first word ending with 'ly' (treated as an adverb) and its 
    positions within the given string.

    Args:
        text: The input string to search within.

    Returns:
        A string formatted as 'start-end: word', representing the start and 
        end indices of the found word and the word itself.
        Returns None if no such word is found.
    """
    # Use a regular expression to find the first whole word (\b) 
    # that ends with 'ly'. The parentheses create a capturing group
    # for the word itself.
    match = re.search(r'\b(\w*ly)\b', text)

    if match:
        # match.start(1) gives the starting index of the captured group (the word)
        # match.end(1) gives the ending index of the captured group
        # match.group(1) gives the actual word that was captured
        start_position = match.start(1)
        end_position = match.end(1)
        adverb_found = match.group(1)
        return f"{start_position}-{end_position}: {adverb_found}"
    return None # Typically, test cases imply a match will always occur.