import re

def extract_quotation(input_string: str) -> list[str]:
    """
    Extracts values enclosed within double quotation marks from a given string.

    This function utilizes regular expressions to find all occurrences of text
    that are surrounded by " characters. It is designed to capture the content
    between the double quotes, not including the quotes themselves.

    Args:
        input_string: The string from which to extract quoted values.

    Returns:
        A list of strings, where each string is a value found between
        double quotation marks. Returns an empty list if no such values
        are found or if single quotes are used instead of double quotes.
    """
    # The regular expression pattern r'"([^"]*)"' works as follows:
    # "       - Matches a literal double quotation mark.
    # (       - Starts a capturing group. This is what we want to extract.
    # [^"]*   - Matches any character that is NOT a double quotation mark, zero or more times.
    #           The '*' makes it capable of handling empty quotes if needed, though problem implies content.
    #           For the specific problem, [^"]+ (one or more) is also fitting. Let's use '+' for clarity
    #           as test cases always show content.
    # )       - Ends the capturing group.
    # "       - Matches the closing literal double quotation mark.
    #
    # re.findall will return a list of all strings that match the capturing group.
    pattern = r'"([^"]+)"'
    found_values = re.findall(pattern, input_string)
    return found_values