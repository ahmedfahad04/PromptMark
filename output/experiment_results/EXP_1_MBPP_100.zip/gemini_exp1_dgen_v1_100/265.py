def list_split(data_list, partition_size):
    """
    Divides a list into `partition_size` sub-lists by distributing elements at `partition_size`-based intervals.
    Each sub-list contains elements starting from a distinct initial position, then picking every `partition_size`-th element.

    Args:
        data_list (list): The original list to process.
        partition_size (int): The positive integer dictating how many sub-lists to produce and the interval for element picking.

    Returns:
        list[list]: A list of lists, where each inner list represents a partition.

    Examples:
        >>> list_split(['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n'], 3)
        [['a', 'd', 'g', 'j', 'm'], ['b', 'e', 'h', 'k', 'n'], ['c', 'f', 'i', 'l']]
        >>> list_split([1,2,3,4,5,6,7,8,9,10,11,12,13,14], 3)
        [[1, 4, 7, 10, 13], [2, 5, 8, 11, 14], [3, 6, 9, 12]]
        >>> list_split(['python','java','C','C++','DBMS','SQL'], 2)
        [['python', 'C', 'DBMS'], ['java', 'C++', 'SQL']]
    """
    if not isinstance(data_list, list):
        raise TypeError("Input 'data_list' must be a list.")
    if not isinstance(partition_size, int) or partition_size <= 0:
        raise ValueError("Input 'partition_size' must be a positive integer.")

    # Prepare `partition_size` distinct partitions (sub-lists).
    # This pre-allocates `partition_size` empty lists within `divisions`.
    divisions = [[] for _ in range(partition_size)]

    # Distribute elements from the original `data_list` into their respective partitions.
    # The modulus operation (index % partition_size) picks the proper sub-list
    # for each item, ensuring a systematic distribution.
    for index, item in enumerate(data_list):
        divisions[index % partition_size].append(item)

    return divisions