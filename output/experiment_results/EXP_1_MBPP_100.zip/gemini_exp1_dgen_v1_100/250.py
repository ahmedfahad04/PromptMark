def count_X(data_tuple, target_element):
    """
    Counts the occurrences of a specified element within a tuple.

    Args:
        data_tuple (tuple): The tuple to search within.
        target_element: The element to count.

    Returns:
        int: The total number of times the target_element appears in the tuple.
    """
    return data_tuple.count(target_element)