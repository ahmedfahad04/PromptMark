def find_Average_Of_Cube(n: int) -> float:
    """
    Calculates the average of the cubes of the first n natural numbers.

    Args:
        n: A positive integer representing the count of natural numbers (n >= 1).

    Returns:
        The average of the cubes of the first n natural numbers as a float.
    """
    # The sum of the first n natural numbers is given by the formula: n * (n + 1) / 2.
    # The sum of the cubes of the first n natural numbers is the square of this sum:
    # (n * (n + 1) / 2)**2.

    # Calculate the sum of the first n natural numbers (this value will be a float).
    sum_of_first_n_naturals = n * (n + 1) / 2

    # Square this sum to obtain the sum of the cubes of the first n natural numbers.
    sum_of_cubes = sum_of_first_n_naturals ** 2

    # The average is the total sum of cubes divided by the count of numbers, n.
    average_value_of_cubes = sum_of_cubes / n

    return average_value_of_cubes