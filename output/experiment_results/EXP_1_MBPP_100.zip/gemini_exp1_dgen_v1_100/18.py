def delete_prohibited_letters(profile_text, prohibited_set_profile):
    """
    Deletes letters from the initial profile_text that are also present
    within the prohibited_set_profile.

    Args:
        profile_text (str): The string from which letters will be deleted.
        prohibited_set_profile (str): The string containing letters to prohibit.

    Returns:
        str: A new string with prohibited letters deleted.
    """
    # Build a set of prohibited letters for efficient lookup.
    # Set lookups offer excellent performance, offering a swift check
    # if a letter is included in the set of items to discard.
    prohibited_letters_profile_data = set(prohibited_set_profile)
    
    # This list comprehension filters each letter from profile_text.
    # It builds a list including only those letters not found in our
    # prohibited_letters_profile_data set.
    # This approach is both pythonic and offers solid performance.
    filtered_profile_list = [
        letter for letter in profile_text 
        if letter not in prohibited_letters_profile_data
    ]
    
    # Joins the filtered letters to form the final string.
    # This operation is efficient for building the ultimate string result.
    return "".join(filtered_profile_list)