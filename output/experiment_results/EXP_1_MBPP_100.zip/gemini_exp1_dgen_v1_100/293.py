import math

def otherside_rightangle(side1: float, side2: float) -> float:
    """
    Calculates the third side (hypotenuse) of a right-angled triangle
    given the lengths of its two shorter sides (legs).

    Utilizes the Pythagorean theorem: a^2 + b^2 = c^2, where 'c' is the hypotenuse.

    Args:
        side1 (float): The length of the first leg of the triangle.
        side2 (float): The length of the second leg of the triangle.

    Returns:
        float: The length of the hypotenuse.
    """
    # The sum of the squares of the two given sides (legs)
    sum_of_powers = (side1 ** 2) + (side2 ** 2)
    
    # The hypotenuse is the square root of that sum
    hypotenuse = math.sqrt(sum_of_powers)
    
    return hypotenuse