def left_insertion(ordered_list: list, target_value: int) -> int:
    """
    Locates the left insertion point for a specified value in a sorted list.

    This function applies a binary search approach to pinpoint the index where the
    target_value would be inserted to sustain the sorted order of the list.
    If the target_value already exists, the insertion point will be before
    any existing instances of that value.

    Args:
        ordered_list: A list of numerical data, assumed to be in ascending order.
        target_value: The value for which to find the insertion point.

    Returns:
        The integer index representing the left-most position where target_value
        could be inserted to preserve the list's sorted property.
    """
    low_idx = 0
    high_idx = len(ordered_list)

    # Perform a binary search to pinpoint the insertion location.
    # The loop continues as long as a possible span for the insertion
    # point remains.
    while low_idx < high_idx:
        # Calculate the pivot index. Integer division ensures an integer result.
        pivot_idx = (low_idx + high_idx) // 2

        # If the element at the pivot index is less than the target value,
        # then the insertion point must be in the right half of the present span.
        # We advance low_idx to (pivot_idx + 1) to proceed with that portion.
        if ordered_list[pivot_idx] < target_value:
            low_idx = pivot_idx + 1
        # Otherwise, the element at pivot_idx is greater than or equal to the target value.
        # This implies that pivot_idx could be the insertion point, or an earlier
        # position. We narrow down the search to the left half, including pivot_idx.
        else:
            high_idx = pivot_idx

    # Upon loop completion, low_idx (and high_idx, as they will be equal)
    # represents the precise left insertion point.
    # This position guarantees that all elements before it are less than target_value,
    # and all elements at or after it are greater than or equal to target_value.
    return low_idx