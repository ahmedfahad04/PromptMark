def sum_series(n: int) -> int:
    """
    Calculates the sum (n - 2*i) for i from 0 to n // 2.

    For example:
    If n is 6, the series is 6 + (6-2) + (6-4) + (6-6) = 6 + 4 + 2 + 0 = 12.
    If n is 10, the series is 10 + (10-2) + (10-4) + (10-6) + (10-8) + (10-10) = 10 + 8 + 6 + 4 + 2 + 0 = 30.
    If n is 9, the series is 9 + (9-2) + (9-4) + (9-6) + (9-8) = 9 + 7 + 5 + 3 + 1 = 25.

    Args:
        n: An integer representing the starting value for the series.

    Returns:
        The integer sum of the series.
    """
    total_sum = 0
    # The loop iterates from i=0 up to n // 2 (inclusive).
    # Python's range(stop) goes up to stop-1, so we use range(n // 2 + 1).
    for i in range(n // 2 + 1):
        term = n - (2 * i)
        total_sum += term
    return total_sum

# Test Cases:
# assert sum_series(6) == 12
# assert sum_series(10) == 30
# assert sum_series(9) == 25