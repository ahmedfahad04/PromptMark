from collections import defaultdict

def group_tuples(tuples_list):
    # Utilize defaultdict to conveniently group elements.
    # When a new first_element is encountered, a new list is automatically created for it.
    grouped_elements = defaultdict(list)

    # Traverse each tuple provided in the list.
    for first_element, second_element in tuples_list:
        # Append the second element to the list associated with its unique first_element.
        grouped_elements[first_element].append(second_element)

    # Prepare the final list for output.
    final_profit_trade = []
    # Iterate through the items of the grouped dictionary.
    for first_shade_key, associated_values_for_trade in grouped_elements.items():
        # Construct the output tuple: the first_shade_key followed by all associated values.
        # The '*' operator unpacks the list of associated values into individual elements.
        final_profit_trade.append((first_shade_key, *associated_values_for_trade))

    return final_profit_trade