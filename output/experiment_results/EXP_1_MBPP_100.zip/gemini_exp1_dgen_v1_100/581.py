import math

def surface_Area(base_edge, height):
    """
    Calculates the total surface area of a square pyramid.

    Parameters:
    base_edge (float or int): The length of one side of the square base.
    height (float or int): The perpendicular height from the base to the apex of the pyramid.

    Returns:
    float: The total surface area of the square pyramid.
    """
    # Determine the area of the square base plane
    base_plane_area = base_edge * base_edge

    # To compute the lateral surface area, we first need the slant height.
    # This involves a right-angled triangle formed by:
    # 1. The pyramid's height (one leg)
    # 2. Half of the base edge (the other leg)
    # 3. The slant height (the hypotenuse)
    half_base_dimension = base_edge / 2
    pyramid_slant_height = math.sqrt(height**2 + half_base_dimension**2)

    # The lateral surface area comprises four triangular panels.
    # The area of one such triangle is (0.5 * base * height), where 'base' is base_edge
    # and 'height' is the pyramid_slant_height.
    # So, four panels provide a total lateral area of 4 * (0.5 * base_edge * pyramid_slant_height)
    # This simplifies to 2 * base_edge * pyramid_slant_height.
    triangle_panels_total_area = 2 * base_edge * pyramid_slant_height

    # The total pyramid surface area is the sum of the base area and the lateral triangular panels' area.
    total_pyramid_surface_area = base_plane_area + triangle_panels_total_area

    return total_pyramid_surface_area