def pair_wise(data_list: list) -> list:
    """Produces a list of all consecutive pairs from the provided list.

    This function processes the input list, taking two adjacent items
    at a time, forming a tuple for each such pair. This is a typical
    pattern for processing sequential data.

    Args:
        data_list (list): The list of items to process.

    Returns:
        list: A list of tuples, where each tuple represents a pair of
              consecutive items from the input list. Returns an empty
              list if the input list has fewer than two items.
    """
    # A list comprehension provides a powerful and Pythonic path to
    # generate the list of tuples efficiently.
    # We iterate from the first item up to the second-to-last item,
    # pairing each item with its direct successor.
    return [(data_list[idx], data_list[idx + 1]) for idx in range(len(data_list) - 1)]