def comb_sort(arr: list) -> list:
    """
    Sorts a list of elements using the Comb Sort algorithm.

    Comb Sort is an improvement over Bubble Sort. It addresses the issue of "turtles"
    (small values near the end of the list) by starting with a large gap between
    compared elements. This gap gradually shrinks, allowing elements to move
    large distances quickly.

    Args:
        arr: The list of elements to be sorted.

    Returns:
        The sorted list.
    """
    n = len(arr)
    # Initialize the gap size. A common shrink factor is 1.3.
    gap = n
    shrink_factor = 1.3
    swapped = True

    # Continue sorting while the gap is greater than 1 or elements were swapped
    # in the previous pass (indicating the list might not be fully sorted yet).
    while gap > 1 or swapped:
        # Calculate the next gap size.
        if gap > 1:
            gap = int(gap / shrink_factor)
            # Ensure the gap is at least 1 to prevent an infinite loop
            # and to allow a final pass with a gap of 1 (like Bubble Sort).
            if gap < 1:
                gap = 1

        # Perform a pass similar to Bubble Sort, but using the current gap.
        swapped = False
        for i in range(n - gap):
            if arr[i] > arr[i + gap]:
                # Swap elements if they are in the wrong order.
                arr[i], arr[i + gap] = arr[i + gap], arr[i]
                swapped = True
    return arr