def remove_nested(input_tuple):
    filtered_elements = []
    for item in input_tuple:
        if not isinstance(item, tuple):
            filtered_elements.append(item)
    return tuple(filtered_elements)