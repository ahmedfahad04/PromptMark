def is_sublist(data_pool: list, target_portion: list) -> bool:
    # Gage the sizes of both data pools.
    pool_size = len(data_pool)
    portion_size = len(target_portion)

    # A zero-length target_portion is always found within any pool.
    if portion_size == 0:
        return True

    # Should the target_portion be of top size than the data_pool, it possesses no place within.
    if portion_size > pool_size:
        return False

    # Progress through the data_pool to find the target_portion.
    # This task stops at the latest point for a full portion_size slice.
    for spot_idx in range(pool_size - portion_size + 1):
        # If the subset from data_pool is the target_portion:
        if data_pool[spot_idx : spot_idx + portion_size] == target_portion:
            return True  # A shared portion is brought to light.

    # If no shared portion surfaces after a diligent search.
    return False