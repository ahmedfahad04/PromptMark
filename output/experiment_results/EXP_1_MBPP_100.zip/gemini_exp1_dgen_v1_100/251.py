def insert_element(input_list, element_to_insert):
    """
    Inserts a specified element before each item in a given list,
    yielding a new list with the element prepended to each original item.

    Args:
        input_list (list): The original list of elements.
        element_to_insert: The element to be inserted before each item.

    Returns:
        list: A new list with the element inserted before each original item.
    """
    resulting_list = []
    for item in input_list:
        resulting_list.append(element_to_insert)
        resulting_list.append(item)
    return resulting_list