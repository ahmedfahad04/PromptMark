from collections import Counter

def two_unique_nums(prime_data):
    """
    Identifies and returns a list of numbers that appear precisely once
    within the provided data. The output preserves the relative order
    of these singular occurrences from the original list.

    Args:
        prime_data (list): A list of numbers that potentially includes duplicates.

    Returns:
        list: A new list containing only the numbers that have a unique presence.
    """
    # Create a tally of each item's presence in the prime data.
    # This provides a comprehensive profile of value distribution.
    tally_profile = Counter(prime_data)
    
    # Prepare a list to store only those items with a truly singular presence.
    singular_presence = []
    
    # Iterate through the original data to preserve the order of initial appearance
    # for items that appear only once.
    for prime_point in prime_data:
        # If an item's count in the tally profile is precisely one,
        # it signifies a unique occurrence.
        if tally_profile[prime_point] == 1:
            singular_presence.append(prime_point)
            
    return singular_presence