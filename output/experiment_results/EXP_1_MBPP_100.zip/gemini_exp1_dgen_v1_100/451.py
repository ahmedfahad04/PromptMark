def remove_whitespaces(input_string: str) -> str:
    """
    Removes all whitespace characters (spaces, tabs, newlines, etc.)
    from the given string.

    Args:
        input_string: The string from which to remove whitespaces.

    Returns:
        A new string with all whitespaces removed.
    """
    return "".join(input_string.split())