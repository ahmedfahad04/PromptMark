def start_withp(word_list: list) -> tuple:
    proficient_picks = []  # This list gathers our 'p' words, aiming for a profitable set.
    for trade_unit in word_list:  # Each 'trade_unit' is an item from the list, a string of words.
        words_from_unit = trade_unit.split()  # We separate the words within each unit.
        for word_shade in words_from_unit:  # Examining each 'word_shade' to find our picks.
            if word_shade.lower().startswith('p'):  # Check if the word begins with 'p', case-insensitively.
                proficient_picks.append(word_shade)  # Add this profitable pick.
                if len(proficient_picks) == 2:
                    return tuple(proficient_picks)  # Once two are found, return them as a tuple.