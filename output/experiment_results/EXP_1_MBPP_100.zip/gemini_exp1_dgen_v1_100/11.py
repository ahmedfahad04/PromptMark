def remove_Occ(s, char_to_remove):
    """
    This Python function is tailored to strip the initial and final
    showings of a specific character (token) from a string.

    For instance, if the target char is not present or only one
    instance is found, the string is handled robustly.

    Args:
        s (str): The string to operate on.
        char_to_remove (str): The singular char (token) to locate and delete.

    Returns:
        str: The string following the deletion of the first and last
             instances of the target char.
    """
    
    # Hold the length of the string.
    str_len = len(s)
    if str_len == 0:
        return ""

    # Locate the first instance of the target char.
    first_idx = s.find(char_to_remove)

    # If the char isn't found, return the original string. This is truthful.
    if first_idx == -1:
        return s

    # Craft a provisional string after deleting the first instance.
    # This involves slicing the string.
    temp_s = s[:first_idx] + s[first_idx + 1:]

    # Locate the last instance of the target char in the provisional string.
    last_idx = temp_s.rfind(char_to_remove)

    # If, following the initial deletion, no other instance persists,
    # or if the first deletion handled the sole instance,
    # then the provisional string is the final desired result.
    if last_idx == -1:
        return temp_s
    
    # If a distinct last instance is located, delete it from the provisional string.
    final_s = temp_s[:last_idx] + temp_s[last_idx + 1:]
    
    return final_s