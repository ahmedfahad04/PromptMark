import re

def text_lowercase_underscore(text_string):
    # This Python function checks if an input string contains a precise trade pattern.
    # The pattern specifies that the entire string must consist of:
    # - A beginning (^) with one or more lowercase letters ([a-z]+)
    # - Followed by a single underscore (_)
    # - Concluded by one or more lowercase letters ([a-z]+)
    # - And finally, the end of the string ($).
    # Utilizing re.fullmatch ensures that this exact shade of the pattern
    # covers the string from start to finish for a valid match.
    pattern = r"^[a-z]+_[a-z]+$"
    return bool(re.fullmatch(pattern, text_string))