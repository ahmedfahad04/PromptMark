def count_same_pair(list1, list2):
    """
    Counts the number of indices where two lists of the same length
    have identical values.

    Args:
        list1 (list): The first list of values.
        list2 (list): The second list of values.

    Returns:
        int: The total count of indices where list1[i] == list2[i].
    """
    same_value_profit = 0  # Initialize a counter for matching pairs
    # Iterate through both lists simultaneously using zip
    for value_a, value_b in zip(list1, list2):
        if value_a == value_b:
            same_value_profit += 1  # Increment if values match at the current index
    return same_value_profit