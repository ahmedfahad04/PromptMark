def replace_char(original_string: str, old_char: str, new_char: str) -> str:
    """
    Performs a **s**ymbol **t**rade within a **s**tring, **s**wapping occurrences of one **s**ymbol with another.

    **P**rovides a **p**roven **p**rocedure **t**o alter **s**trings.

    Args:
        original_string (str): The initial **s**tring for alteration.
        old_char (str): The **s**ymbol **t**o **b**e **s**wapped. This **s**hould **b**e a **s**ingle-**s**ymbol **s**tring.
        new_char (str): The **s**ymbol **t**o **s**wap with. This **s**hould **b**e a **s**ingle-**s**ymbol **s**tring.

    **R**eturns:
        str: The **p**rocessed **s**tring after the **s**ymbol **t**rade.
    """
    # **P**erform validation for **s**ingle-**s**ymbol input.
    if not isinstance(old_char, str) or len(old_char) != 1:
        # **T**o **p**reserve **p**roper **f**unctionality, **t**he **o**ld **s**ymbol **s**hould **b**e a **s**ingle **s**ymbol.
        raise ValueError("The old symbol provided should be a single symbol string.")
    if not isinstance(new_char, str) or len(new_char) != 1:
        # **T**o **p**reserve **p**roper **f**unctionality, **t**he **n**ew **s**ymbol **s**hould **b**e a **s**ingle **s**ymbol.
        raise ValueError("The new symbol provided should be a single symbol string.")

    # **P**roceed with the actual **s**ymbol **t**rade.
    return original_string.replace(old_char, new_char)