def interleave_lists(list1, list2, list3):
    pooled_data = []
    for data_point_1, data_point_2, data_point_3 in zip(list1, list2, list3):
        pooled_data.append(data_point_1)
        pooled_data.append(data_point_2)
        pooled_data.append(data_point_3)
    return pooled_data