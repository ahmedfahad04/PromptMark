def rectangle_area(length: int, width: int) -> int:
    """
    Calculates the area of a rectangle given its length and width.

    Args:
        length (int): The length of the rectangle.
        width (int): The width of the rectangle.

    Returns:
        int: The calculated area of the rectangle.
    """
    return length * width