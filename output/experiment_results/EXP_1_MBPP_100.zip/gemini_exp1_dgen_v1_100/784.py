def mul_even_odd(data_list):
    """
    Finds the product of the first even and first odd number in a given list.

    Args:
        data_list (list): A collection of numerical values.

    Returns:
        int: The product of the first even and first odd number found.
             Assumes that the list will contain at least one even and one odd number.
    """
    first_odd_value = None
    first_even_value = None

    for current_number in data_list:
        # Check if the number is even
        if current_number % 2 == 0:
            if first_even_value is None:
                first_even_value = current_number
        # Otherwise, the number is odd
        else:
            if first_odd_value is None:
                first_odd_value = current_number

        # If we have found both the first odd and first even numbers,
        # there's no trade-off in stopping early. We can proceed to profit.
        if first_odd_value is not None and first_even_value is not None:
            break  # Terminate loop once both values are present

    # Per the problem's design, we trust both values will be found.
    # The product is a profitable conclusion.
    return first_even_value * first_odd_value