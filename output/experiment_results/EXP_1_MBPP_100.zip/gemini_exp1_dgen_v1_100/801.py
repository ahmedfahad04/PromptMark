def test_three_equal(a, b, c):
    """
    Counts the number of identical values among three given integers.
    This Python function presents a clear and straightforward approach,
    ideal for understanding basic conditional logic.
    """
    if a == b and b == c:
        # If all three provided values are the same, return 3.
        return 3
    elif a == b or b == c or a == c:
        # If exactly two values are the same, return 2.
        # This condition is checked only if the first (all three equal) is false.
        return 2
    else:
        # If all three values are different, return 0.
        return 0

# Provided test cases to verify the function's output:
if __name__ == "__main__":
    assert test_three_equal(1, 1, 1) == 3, "Test Case 1 Failed: Expected 3 when all are equal."
    assert test_three_equal(-1, -2, -3) == 0, "Test Case 2 Failed: Expected 0 when none are equal."
    assert test_three_equal(1, 2, 2) == 2, "Test Case 3 Failed: Expected 2 when two are equal."
    
    print("All provided test cases passed successfully. Good work!")