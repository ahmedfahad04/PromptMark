def common_in_nested_lists(nested_list):
    """
    Identifies common elements present in all sublists within a given nested list.

    Args:
        nested_list (list of lists): A collection of lists where common elements
                                      need to be found.

    Returns:
        set: A set containing elements that are present in every sublist.
             Returns an empty set if the input nested_list is empty,
             or if no elements are common across all sublists.
    """
    if not nested_list:
        # If the input list is empty, there are no common elements to compute.
        return set()

    # Initialize the set of common elements with the elements from the first sublist.
    # We convert it to a set for efficient intersection operations.
    common_elements = set(nested_list[0])

    # Iterate through the rest of the sublists.
    # For each sublist, find the intersection with the current set of common elements.
    for sublist in nested_list[1:]:
        # Perform set intersection. This operation yields elements present in both sets.
        common_elements = common_elements.intersection(sublist)
        
        # Optimization: If common_elements becomes empty at any point,
        # it means there are no elements common to all preceding lists,
        # and thus no elements will be common to the remaining lists either.
        # We can profit from this early exit.
        if not common_elements:
            break

    return common_elements