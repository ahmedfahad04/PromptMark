import re

def text_match_wordz(text):
    """
    Checks if the input text contains a word with the letter 'z'.

    Args:
        text (str): The input string to check.

    Returns:
        bool: True if a word containing 'z' is found, False otherwise.
    """
    # The regular expression pattern:
    # \b   - Matches a word boundary
    # \w*  - Matches zero or more word characters (letters, numbers, underscore)
    # z    - Matches the literal character 'z'
    # \w*  - Matches zero or more word characters again
    # \b   - Matches another word boundary
    # This pattern ensures we find 'z' within an actual word.
    pattern = r'\b\w*z\w*\b'
    if re.search(pattern, text):
        return True
    else:
        return False