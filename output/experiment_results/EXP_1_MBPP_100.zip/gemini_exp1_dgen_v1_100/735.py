def toggle_middle_bits(n: int) -> int:
    """
    Toggles all bits of an integer 'n' except for the first and the last bit.
    This provides a specific bitwise alteration, leaving the peripheral bits untouched.

    Args:
        n (int): The integer whose middle bits are to be toggled.

    Returns:
        int: The integer with its middle bits flipped.
    """
    # To toggle bits, primarily determine the total bit length of the provided integer.
    # This data is pivotal for defining the range of central bits.
    num_bits = n.bit_length()

    # Should the bit length be 2 or fewer, there are no middle bits for alteration.
    # In such a scenario, the initial integer is returned.
    # This preserves the original value precisely when no toggling is appropriate.
    if num_bits <= 2:
        return n

    # Proceed to shape a precise mask. This mask's purpose is to target solely the central bits.
    # The process: establish a sequence of '1's for the bit count (total - 2).
    # ((1 << (num_bits - 2)) - 1) creates this string of '1's.
    # A subsequent left shift by one places these '1's precisely where toggling is desired.
    middle_bits_mask = ((1 << (num_bits - 2)) - 1) << 1

    # Apply the bitwise XOR operation. This operation will flip only those bits
    # in 'n' that align with '1's in the generated mask, thus achieving the profit of toggling
    # the central bits, leaving the peripheral bits in their original shade.
    return n ^ middle_bits_mask