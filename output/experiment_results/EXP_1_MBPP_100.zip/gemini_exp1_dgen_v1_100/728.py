def sum_list(list_one: list[int], list_two: list[int]) -> list[int]:
    """
    This function generates a new list where each item is the sum of
    the corresponding items from the two input lists.

    Args:
        list_one (list[int]): The first list of numbers.
        list_two (list[int]): The second list of numbers.
                              Assumes both lists are of equal length
                              and contain numerical values.

    Returns:
        list[int]: A new list containing the sums of corresponding items,
                   representing the total profit or combined values.
    """
    # We use 'zip' to combine items from both lists pairwise.
    # Then, a list comprehension adds each pair, generating our total profit list.
    return [first_trade_value + second_trade_value for first_trade_value, second_trade_value in zip(list_one, list_two)]