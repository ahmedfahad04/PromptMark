def subject_marks(marks_list):
    """
    Sorts a list of tuples based on the second value of each tuple.

    Args:
        marks_list: A list of tuples, where each tuple contains (subject_name, score).

    Returns:
        A new list of tuples, sorted in ascending order by the score.
    """
    return sorted(marks_list, key=lambda x: x[1])