def find_First_Missing(data: list[int]) -> int:
    if not data or data[0] != 0:
        return 0

    for i in range(len(data)):
        if data[i] != i:
            return i

    return len(data)