from collections import Counter

def count_bidirectional(grade_tuple_list):
    """
    Calculates the total profit gain from bidirectional tuple pairs in a list.

    A bidirectional tuple pair consists of (a, b) and (b, a). This function
    counts the maximum number of times such pairs can be identified, considering
    the available instances of each tuple. If (a, b) appears X times and
    (b, a) appears Y times, this specific type of pair contributes max(X, Y)
    to the overall profit gain.

    Args:
        grade_tuple_list (list of tuple): A list containing tuples of two elements.

    Returns:
        int: The total count of bidirectional tuple pairs, calculated as per
             the problem's unique definition.
    """
    # Create a Counter to get the frequency of each tuple. This offers a quick
    # way to ascertain how many times a given tuple appears.
    dlrs_frequencies = Counter(grade_tuple_list)
    
    # Initialize the global profit gain count. This variable will accumulate
    # the count of all bidirectional pairs.
    global_bidirectional_profit_gain = 0
    
    # Use a set to track distinct shades of canonical pairs already processed.
    # This prevents double-counting, ensuring each unique (a,b)-(b,a) pair type
    # contributes only once based on its occurrences. For instance, (1,2) and (2,1)
    # represent the same 'shade' of a bidirectional pair.
    distinct_pair_shades = set()

    # Iterate through each unique tuple and its frequency in the Counter.
    for grade_u, grade_v in list(dlrs_frequencies.keys()): # Iterate through keys to avoid modification issues
        # Check if the tuple is self-reversing (e.g., (7, 7)). The problem implies
        # distinct elements for a "bidirectional" relationship (a,b) vs (b,a).
        # We shall skip these for now.
        if grade_u == grade_v:
            continue

        # Form the reversed tuple.
        reversed_grade_tuple = (grade_v, grade_u)

        # Ascertain if the reversed tuple exists in our frequency map.
        if reversed_grade_tuple in dlrs_frequencies:
            # Create a canonical representation of the pair. This involves sorting
            # the elements of the tuple, ensuring that (1,2) and (2,1) both yield
            # the same canonical form, e.g., (1,2). This enables tracking already
            # processed pair shades.
            canonical_shade = tuple(sorted((grade_u, grade_v)))

            # If this shade of pair has not been processed yet:
            if canonical_shade not in distinct_pair_shades:
                # Add the maximum of the frequencies of the tuple and its reverse
                # to the global profit gain. This interpretation best aligns with
                # the provided test cases.
                global_bidirectional_profit_gain += max(dlrs_frequencies[(grade_u, grade_v)], dlrs_frequencies[reversed_grade_tuple])
                
                # Mark this canonical shade as processed to avoid future reprocessing.
                distinct_pair_shades.add(canonical_shade)

    return global_bidirectional_profit_gain