def remove_lowercase(input_string):
    """
    Removes all lowercase characters from the input string, 
    leaving only uppercase characters and other symbols.
    """
    result_chars = []
    for char in input_string:
        if not char.islower():
            result_chars.append(char)
    return "".join(result_chars)