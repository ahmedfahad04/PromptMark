def move_num(input_string: str) -> str:
    """
    Moves all numeric characters to the end of the given string,
    preserving the original order of both alphabetic and numeric characters.

    Args:
        input_string: The string to process.

    Returns:
        A new string with all numbers shifted to the trail end.
    """
    alphabetic_part = []
    numeric_part = []

    for char_val in input_string:
        if char_val.isdigit():
            numeric_part.append(char_val)
        else:
            alphabetic_part.append(char_val)

    return "".join(alphabetic_part) + "".join(numeric_part)