import math

def is_perfect_square(data):
    if data < 0:
        return False
    if data == 0:
        return True
    
    side_data = int(math.sqrt(data))
    
    return side_data * side_data == data