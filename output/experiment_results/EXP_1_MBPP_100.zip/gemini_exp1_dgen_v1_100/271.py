def even_Power_Sum(n: int) -> int:
    """
    Calculates the sum of the first n even natural numbers, each raised to the fifth power.

    Args:
        n: An integer representing the count of even natural numbers to consider.

    Returns:
        The total sum of these powered even numbers.
    """
    total_sum_of_powers = 0
    for i in range(1, n + 1):
        # Determine the current even natural number
        current_even_number = 2 * i
        # Add its fifth power to the running total
        total_sum_of_powers += current_even_number ** 5
    return total_sum_of_powers