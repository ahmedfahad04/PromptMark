def find_solution(a, b, n):
    """
    Finds non-negative integers x and y that satisfy the linear Diophantine equation ax + by = n.
    This function prioritizes finding a solution where x and y are both non-negative.

    Args:
        a (int): The integer coefficient for x.
        b (int): The integer coefficient for y.
        n (int): The target integer sum.

    Returns:
        tuple[int, int] or None: A tuple (x, y) if a non-negative integer solution is found.
                                 Returns None if no such solution exists or if a=0, b=0 and n!=0.
    """
    # If the target sum 'n' is negative, and 'a' and 'b' are positive
    # (implied by test cases for non-negative x, y), no non-negative x, y will satisfy it.
    if n < 0:
        return None

    # Handle special case where both 'a' and 'b' are zero.
    # 0*x + 0*y = n
    if a == 0 and b == 0:
        return (0, 0) if n == 0 else None # If n is 0, (0,0) is a valid solution. Otherwise, no solution.

    # Handle cases where one coefficient is zero.
    # If a is zero, the equation simplifies to by = n.
    if a == 0:
        if b != 0 and n % b == 0: # If b is not zero and n is a multiple of b.
            return (0, n // b)     # x must be 0, y is determined.
        else:
            return None             # No solution if b is zero and n isn't or n is not a multiple.

    # If b is zero, the equation simplifies to ax = n.
    if b == 0:
        if a != 0 and n % a == 0: # If a is not zero and n is a multiple of a.
            return (n // a, 0)     # y must be 0, x is determined.
        else:
            return None             # No solution if a is zero and n isn't (already handled) or n is not a multiple.

    # At this point, both 'a' and 'b' are non-zero.
    # We iterate through possible non-negative integer values for x.
    # The maximum possible value for x such that a*x does not exceed n (and x >= 0).
    max_x_possible = n // a

    for x in range(max_x_possible + 1):
        remaining_value = n - (a * x)
        
        # If the 'remaining_value' is non-negative and divisible by 'b',
        # then we have found a valid non-negative integer y.
        if remaining_value >= 0 and remaining_value % b == 0:
            y = remaining_value // b
            return (x, y)

    # If the loop finishes without finding a solution, none exists for non-negative x, y.
    return None