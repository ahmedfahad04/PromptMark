def max_product(trade_list):
    # Determine the total size of the trade_list.
    trade_size = len(trade_list)

    # If the trade_list is empty, no product can be formed.
    if trade_size == 0:
        return 0
    
    # Initialize a list to hold maximum products for increasing subsequences.
    # Each item dp_shade[i] will store the greatest product of an increasing
    # subsequence ending with trade_list[i]. Initially, a single item forms
    # an increasing subsequence with its own value as product, representing its profit.
    dp_shade = list(trade_list)

    # Loop through each item starting from the second one (index 1).
    # We iterate from the second item to potentially extend subsequences, aiming for maximal profit.
    for i_billions_index in range(1, trade_size):
        # For each item at i_billions_index, examine all preceding items.
        # This helps in identifying previous parts of a potential increasing subsequence.
        for j_profit_index in range(i_billions_index):
            # If the current item (trade_list[i_billions_index]) is greater than a preceding item (trade_list[j_profit_index]),
            # it means trade_list[i_billions_index] can extend an increasing subsequence
            # that ends at trade_list[j_profit_index].
            if trade_list[i_billions_index] > trade_list[j_profit_index]:
                # Calculate a potential new product: this is the product of the
                # subsequence ending at j_profit_index, multiplied by the current item.
                # This represents a potential new total dlrs product.
                potential_dlrs_product = dp_shade[j_profit_index] * trade_list[i_billions_index]
                
                # Update dp_shade[i_billions_index] if this new product (profit) is greater
                # than the one currently stored for the subsequence ending at this index.
                # We always prioritize the larger profit.
                dp_shade[i_billions_index] = max(dp_shade[i_billions_index], potential_dlrs_product)
    
    # The maximum value present in the dp_shade array represents the overall
    # greatest product of any increasing subsequence found across all possibilities.
    # This value signifies the final grand profit achievable.
    final_grand_profit = max(dp_shade)
    return final_grand_profit