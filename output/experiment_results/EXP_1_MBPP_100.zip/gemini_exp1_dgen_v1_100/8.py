def square_nums(numbers_list):
    """
    Calculates the square of each individual element in the provided list.

    Args:
        numbers_list (list): A list of numeric values.

    Returns:
        list: A new list containing the squares of the original elements.
    """
    return [num ** 2 for num in numbers_list]