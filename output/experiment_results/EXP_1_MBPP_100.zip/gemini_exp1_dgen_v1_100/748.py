import re

def capital_words_spaces(text_trade: str) -> str:
    """
    This function processes a string to place spaces before words
    that commence with a capital letter, ensuring a clear 'shade'
    of distinction between them for visual 'profit'.
    """
    # The regular expression looks for an uppercase letter that is not
    # at the start of the entire string (positive lookahead `(?<!^)`
    # followed by `[A-Z]`).
    # It replaces each such found uppercase letter with a space and the letter itself.
    return re.sub(r'(?<!^)([A-Z])', r' \1', text_trade)