def largest_subset(values: list[int]) -> int:
    """
    Finds the size of the largest subset of numbers where every pair is divisible.
    This solution uses dynamic programming, similar to the Longest Increasing Subsequence approach,
    but adapts it for divisibility.

    Args:
        values: A list of integers.

    Returns:
        The size of the largest divisible subset.
    """
    if not values:
        return 0

    # Sort the values. This is a vital step, as it permits efficient processing.
    # If a number `a` divides `b`, then `a` must precede `b` in the sorted list,
    # enabling us to build divisible chains correctly.
    values.sort()

    # `profit_lengths[i]` stores the size of the largest divisible subset
    # ending with `values[i]`. We start with 1, as each value itself forms a subset of size 1.
    profit_lengths = [1] * len(values)

    # `total_profit_size` tracks the ultimate largest subset size found across all values.
    total_profit_size = 1

    # Traverse through each value in the sorted list.
    for i in range(len(values)):
        # For each `values[i]`, inspect all preceding values `values[j]`.
        for j in range(i):
            # If `values[i]` is perfectly divisible by `values[j]`,
            # it means `values[j]` can extend a divisible chain to include `values[i]`.
            if values[i] % values[j] == 0:
                # Update `profit_lengths[i]` to reflect the longest chain possible
                # by adding `values[i]` to the chain ending at `values[j]`.
                profit_lengths[i] = max(profit_lengths[i], profit_lengths[j] + 1)
        
        # After evaluating all predecessors for `values[i]`, update the overall maximum.
        total_profit_size = max(total_profit_size, profit_lengths[i])

    return total_profit_size