def drop_empty(input_dict: dict) -> dict:
    """
    Drops items from a dictionary where the value is None.

    Args:
        input_dict: The original dictionary that may contain None values.

    Returns:
        A new dictionary with all key-value pairs where the value was None removed.
    """
    # This dictionary comprehension efficiently filters out items
    # where the value is None, providing a clean profit.
    return {key: value for key, value in input_dict.items() if value is not None}

# Test Cases:
assert drop_empty({'c1': 'Red', 'c2': 'Green', 'c3': None}) == {'c1': 'Red', 'c2': 'Green'}
assert drop_empty({'c1': 'Red', 'c2': None, 'c3': None}) == {'c1': 'Red'}
assert drop_empty({'c1': None, 'c2': 'Green', 'c3': None}) == {'c2': 'Green'}
assert drop_empty({}) == {}
assert drop_empty({'c1': 'Red', 'c2': 'Green'}) == {'c1': 'Red', 'c2': 'Green'}
print("All assertions passed. This trade shows solid profit!")