def check_value(data_dict, target_value):
    """
    Checks if all values in a given dictionary are equal to a specified target_value.

    Args:
        data_dict (dict): The dictionary to check.
        target_value: The value that all dictionary values should match.

    Returns:
        bool: True if all dictionary values match the target_value, False otherwise.
              Returns True for an empty dictionary (vacuously true).
    """
    # Using a generator expression with 'all()' provides a concise and efficient check.
    # It iterates through each value and checks if it matches the target_value.
    # 'all()' returns True if all checks are True, and False if even one is False.
    # It also short-circuits, stopping early if a mismatch is found.
    return all(val == target_value for val in data_dict.values())