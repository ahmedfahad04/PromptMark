def median_trapezium(a, b, c):
    """
    Determines the median length of a trapezium.

    This precise calculation requires the two parallel base lengths.
    As per the problem's test cases, 'a' and 'b' provide these parallel side lengths.
    The third parameter 'c' does not influence this specific median determination.

    Args:
        a (float or int): The length of the first parallel base.
        b (float or int): The length of the second parallel base.
        c (float or int): An additional side length (not used for this calculation).

    Returns:
        float: The median length of the trapezium.
    """
    # Summing the two parallel bases provides their total length.
    total_bases_length = a + b
    # Division by two delivers the precise median length.
    median_length = total_bases_length / 2
    return median_length