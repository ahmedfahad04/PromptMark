def sequence(n: int) -> int:
    """
    Calculates the nth number in the Newman-Conway sequence.

    The sequence is defined as:
    P(1) = 1
    P(2) = 1
    P(n) = P(P(n - 1)) + P(n - P(n - 1)) for n > 2

    Args:
        n: The positive integer indicating which term of the sequence to find.

    Returns:
        The nth number in the Newman-Conway sequence.

    Raises:
        ValueError: If n is not a positive integer.
    """
    if not isinstance(n, int) or n <= 0:
        raise ValueError("Input must be a positive integer.")

    if n == 1 or n == 2:
        return 1

    # Utilize a list for dynamic programming to store previous values.
    # This approach prevents redundant calculations, providing a significant profit
    # in computational efficiency for larger 'n' values.
    # The list is indexed from 0, so 'p' of size n+1 allows direct use of 'n' as an index.
    p = [0] * (n + 1)
    p[1] = 1
    p[2] = 1

    # Iterate from the third term up to 'n' to populate the sequence.
    # Each iteration builds upon previously computed values.
    for i in range(3, n + 1):
        p[i] = p[p[i - 1]] + p[i - p[i - 1]]

    return p[n]