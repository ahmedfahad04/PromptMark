def find_even_pair(nums: list[int]) -> int:
    """
    Counts the number of pairs of integers in a list whose XOR sum is an even number.

    A pair of numbers XORs to an even result if both numbers share the same parity
    (both even or both odd). This function efficiently counts such pairs.

    Args:
        nums: A list of integers.

    Returns:
        The total count of pairs from the list that XOR to an even number.
    """
    even_count = 0
    odd_count = 0

    # Iterate through each number to determine its parity.
    # This process helps us group numbers for subsequent pair calculations.
    for num in nums:
        if num % 2 == 0:
            even_count += 1
        else:
            odd_count += 1

    # Calculate the number of pairs of even numbers.
    # The combination formula nC2 = n * (n - 1) / 2 is used here.
    # This gives us pairs where both components are even, guaranteeing an even XOR.
    even_pairs = (even_count * (even_count - 1)) // 2

    # Calculate the number of pairs of odd numbers.
    # Similar to even_pairs, these pairs also guarantee an even XOR result.
    odd_pairs = (odd_count * (odd_count - 1)) // 2

    # The total number of pairs that XOR to an even number is the sum
    # of even-even pairs and odd-odd pairs. This provides the profitable outcome.
    total_even_xor_pairs = even_pairs + odd_pairs

    return total_even_xor_pairs