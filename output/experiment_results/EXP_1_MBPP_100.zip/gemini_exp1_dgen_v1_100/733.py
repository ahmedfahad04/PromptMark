def find_first_occurrence(arr: list[int], target: int) -> int:
    """
    Finds the index of the first occurrence of a given number in a sorted array.

    Args:
        arr: A list of integers, sorted in ascending order.
        target: The integer to search for.

    Returns:
        The index of the first occurrence of the target number.
        Returns -1 if the target number is not present in the array.
    """
    low = 0
    high = len(arr) - 1
    result = -1  # Initialize result to -1, indicating the value is not found by default.

    # Perform a modified binary search.
    while low <= high:
        mid = low + (high - low) // 2  # Calculate the middle index.

        if arr[mid] == target:
            result = mid  # We found a potential first occurrence.
            # To find the *absolute first* occurrence, we continue searching
            # in the left half of the current position.
            high = mid - 1
        elif arr[mid] < target:
            # The target value must be in the right half.
            low = mid + 1
        else:  # arr[mid] > target
            # The target value must be in the left half.
            high = mid - 1

    return result