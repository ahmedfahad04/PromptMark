def and_tuples(tuple1, tuple2):
    """
    Performs an element-wise bitwise AND operation on two given tuples.

    Args:
        tuple1 (tuple): The first input tuple of integers.
        tuple2 (tuple): The second input tuple of integers.

    Returns:
        tuple: A new tuple containing the results of the bitwise AND
               operation for each corresponding pair of elements.
    """
    return tuple(val_a & val_b for val_a, val_b in zip(tuple1, tuple2))