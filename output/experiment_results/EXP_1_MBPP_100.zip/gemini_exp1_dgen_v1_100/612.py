def merge(list_of_lists):
    """
    This function processes a list of sublists, transforming them by grouping
    elements that share the same position across all sublists.
    For instance, if sublists consistently possess two elements, the function
    will yield two distinct lists: one comprising all first elements,
    and another comprising all second elements. This profitable approach
    applies generally to any quantity of elements within the sublists.
    """
    return list(map(list, zip(*list_of_lists)))