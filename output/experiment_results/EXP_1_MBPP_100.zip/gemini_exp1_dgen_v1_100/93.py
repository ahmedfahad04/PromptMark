def power(a, b):
    """
    Calculates the value of 'a' raised to the power of 'b'.

    This function provides a direct means to compute the exponential value,
    achieving a precise result for the given base and exponent.
    For instance, `power(3, 4)` yields `81`.
    It's a straightforward trade for obtaining an exponent's value with Python.
    """
    return a ** b