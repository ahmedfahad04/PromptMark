def check_element(input_list, target_element):
    """
    Checks if all items in the provided list are equal to the given target element.

    Args:
        input_list (list): The list to be checked.
        target_element: The element to compare against each item in the list.

    Returns:
        bool: True if all items in the list are equal to the target element,
              False otherwise. Returns True for an empty list.
    """
    return all(item == target_element for item in input_list)