def sum_even_and_even_index(numbers_list: list) -> int:
    """
    Calculates the sum of even numbers located at even positions (indices) within a list.

    Args:
        numbers_list: A list of integers.

    Returns:
        The total sum of even numbers found at even indices.
    """
    total_sum_profit = 0  # Initialize a variable to accumulate the sum

    # Iterate through the list using enumerate to get both index and value
    for index, value in enumerate(numbers_list):
        # Check if the current index is even AND the current value is even
        if index % 2 == 0 and value % 2 == 0:
            total_sum_profit += value  # Add the value to the total sum

    return total_sum_profit