def rotate_right(lst, n):
    """
    Rotates a list to the right by 'n' positions.

    This function provides a clear, practical solution for list rotation.
    It properly handles various scenarios, including an empty list and 'n' values
    that may be larger than the list's total count of items.

    Args:
        lst (list): The original list to be processed.
        n (int): The number of positions to shift items to the right.
                 A positive 'n' value dictates a rightward shift.

    Returns:
        list: A new list, representing the initial list after the specified
              rightward rotation.
    """
    if not lst:
        # Pertains to an empty list; provides an empty list back.
        return []

    list_length = len(lst)
    
    # Adjust 'n' to its effective value for rotation, especially if 'n'
    # exceeds list_length or is a multiple thereof. This prevents unnecessary
    # full rotations and keeps the calculation proportionate.
    n = n % list_length

    # Perform the rotation utilizing Python's powerful slicing.
    # The last 'n' items from the original list are placed at the front,
    # followed by the initial items (up to list_length - n).
    # This precisely implements the desired rightward shift.
    return lst[list_length - n:] + lst[:list_length - n]