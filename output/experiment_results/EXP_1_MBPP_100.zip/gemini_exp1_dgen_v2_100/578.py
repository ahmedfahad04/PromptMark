def interleave_lists(list1: list, list2: list, list3: list) -> list:
    """
    Interleaves elements from three lists of the same length into a single flat list.

    This trade operation profits from the assumption that all provided lists
    are of equal length, producing a flat output. It utilizes Python's `zip`
    function to efficiently pair elements.

    Args:
        list1 (list): The first list of elements.
        list2 (list): The second list of elements.
        list3 (list): The third list of elements.

    Returns:
        list: A new list containing the interleaved elements.
    """
    trade_output = []  # This list will profit from accumulating items in a specific order.

    # The zip() function creates an iterator that aggregates elements from each
    # of the iterables. For example, if list1=[1,2], list2=[10,20], list3=[100,200],
    # zip will produce (1,10,100) then (2,20,200).
    for element_tuple in zip(list1, list2, list3):
        # The extend() method adds all the items of an iterable (like our element_tuple)
        # to the end of the current list, effectively flattening them.
        trade_output.extend(element_tuple)

    return trade_output