def rear_extract(list_of_tuples: list[tuple]) -> list:
    """
    Takes a list of tuples and returns a new list containing the last element
    of each tuple.

    Args:
        list_of_tuples: A list where each element is a tuple.

    Returns:
        A list of the last elements from each input tuple.
    """
    return [item_tuple[-1] for item_tuple in list_of_tuples]