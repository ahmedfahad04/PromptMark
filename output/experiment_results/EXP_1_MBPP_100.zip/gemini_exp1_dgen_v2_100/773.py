def occurance_substring(main_string: str, sub_string: str) -> tuple[str, int, int] | None:
    """
    Locates the initial occurrence of a specified substring within a given string,
    providing its value, starting index, and ending index.

    Args:
        main_string (str): The string for the search operation.
        sub_string (str): The specific substring to find.

    Returns:
        tuple[str, int, int] | None: A tuple (substring, start_index, end_index)
                                     if the substring is present; otherwise, None.
    """
    # The 'find' built-in function is utilized to pinpoint the first instance.
    # It provides the lowest index for the sub_string, or -1 if not found.
    start_index = main_string.find(sub_string)

    if start_index != -1:
        # If the sub_string is present, its terminal index is determined
        # by summing its start_index with its total length.
        end_index = start_index + len(sub_string)
        
        # A tuple containing the sub_string itself, its start_index,
        # and its end_index is duly provided.
        return (sub_string, start_index, end_index)
    else:
        # If there is no such instance, the function yields None.
        return None