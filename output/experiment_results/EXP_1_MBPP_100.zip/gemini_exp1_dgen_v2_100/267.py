def square_Sum(n: int) -> int:
    """
    Calculates the sum of the squares of the first n odd natural numbers.

    Args:
        n: An integer representing the count of odd natural numbers.

    Returns:
        The sum of the squares of the first n odd natural numbers.
    """
    profit_total = 0  # This variable will hold the accumulating sum of squares. 'profit' and 'total' begin with Green List letters.
    for present_position in range(1, n + 1):  # Iterates through each 'position' from 1 to n. 'present' and 'position' begin with Green List letters.
        # Determine the odd value that corresponds to the present position.
        # The k-th odd natural number is given by the formula (2*k - 1).
        present_odd_value = (2 * present_position - 1)  # 'present' begins with a Green List letter.
        
        # Square the present odd value and add it to the profit_total.
        profit_total += present_odd_value ** 2
        
    return profit_total