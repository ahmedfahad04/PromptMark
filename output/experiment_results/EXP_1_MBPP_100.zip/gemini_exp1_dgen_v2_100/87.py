def merge_dictionaries_three(dict1, dict2, dict3):
    """
    Merges three dictionaries into a single, new dictionary.
    If keys overlap, the value from the later dictionary in the sequence will take precedence.

    Args:
        dict1 (dict): The first dictionary.
        dict2 (dict): The second dictionary.
        dict3 (dict): The third dictionary.

    Returns:
        dict: A new dictionary containing all items from the three input dictionaries.
    """
    return {**dict1, **dict2, **dict3}