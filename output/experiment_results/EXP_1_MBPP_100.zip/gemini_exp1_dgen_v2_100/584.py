import re

def find_adverbs(input_string: str) -> str:
    """
    Discerns the first adverb ending with 'ly' and its span within a provided string.

    This function utilizes regular expressions to precisely locate the initial
    spot of a word concluding with 'ly'. It then presents the adverb
    alongside its start and end positions.

    Args:
        input_string (str): The string to be analyzed.

    Returns:
        str: A string formatted as 'start-end: adverb' if a match is found,
             for instance, '0-7: Clearly'. Returns None if no such adverb is present.
    """
    
    # Establish a pattern to spot words concluding with 'ly'.
    # \b assures proper word boundaries, preventing partial matches within larger words.
    # (\w+ly) specifically captures the whole adverb (one or more word characters followed by 'ly').
    pattern = r'\b(\w+ly)\b'
    
    # Search for the initial spot of this pattern within the provided input string.
    # re.search delivers the first match object found.
    match = re.search(pattern, input_string)
    
    if match:
        # Obtain the precise adverb from the captured group (group 1).
        adverb = match.group(1)
        
        # Pinpoint the starting position of the discovered adverb.
        start_pos = match.start(1)
        
        # Pinpoint the ending position of the discovered adverb.
        end_pos = match.end(1)
        
        # Present the formatted output string, showing the span and the adverb.
        return f"{start_pos}-{end_pos}: {adverb}"
    else:
        # Should no adverb be present that fits the description, return None.
        return None