def find_first_occurrence(arr, target):
    """
    Finds the index of the first occurrence of a given number in a sorted array.

    Args:
        arr (list): A sorted list of numbers.
        target (int): The number to find.

    Returns:
        int: The index of the first occurrence of the target number.
             Returns -1 if the target is not found in the array.
    """
    low = 0
    high = len(arr) - 1
    result = -1  # Initialize result to -1, indicating not found

    while low <= high:
        mid = low + (high - low) // 2  # Calculate mid to prevent potential overflow

        if arr[mid] == target:
            result = mid  # Found a potential first occurrence
            high = mid - 1  # Continue searching in the left half for an earlier occurrence
        elif arr[mid] < target:
            low = mid + 1  # Target is in the right half
        else:  # arr[mid] > target
            high = mid - 1  # Target is in the left half

    return result