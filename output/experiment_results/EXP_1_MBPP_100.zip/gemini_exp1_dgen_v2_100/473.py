def tuple_intersection(list1, list2):
    """
    Finds the intersection of tuples in two lists, treating tuples like (a, b) and (b, a) as identical.

    Args:
        list1 (list): The first list of tuples.
        list2 (list): The second list of tuples.

    Returns:
        set: A set containing the common tuples (in a normalized sorted form).
    """
    normalized_set1 = set()
    for tpl in list1:
        normalized_set1.add(tuple(sorted(tpl)))

    normalized_set2 = set()
    for tpl in list2:
        normalized_set2.add(tuple(sorted(tpl)))

    return normalized_set1 & normalized_set2

# Test Cases:
# assert tuple_intersection([(3, 4), (5, 6), (9, 10), (4, 5)] , [(5, 4), (3, 4), (6, 5), (9, 11)]) == {(4, 5), (3, 4), (5, 6)}
# assert tuple_intersection([(4, 1), (7, 4), (11, 13), (17, 14)] , [(1, 4), (7, 4), (16, 12), (10, 13)]) == {(4, 7), (1, 4)}
# assert tuple_intersection([(2, 1), (3, 2), (1, 3), (1, 4)] , [(11, 2), (2, 3), (6, 2), (1, 3)]) == {(1, 3), (2, 3)}