def find_lucas(n_position: int) -> int:
    """
    Solves for the N'th Lucas number.
    This function determines the specific Lucas value at a given index.
    
    The Lucas sequence begins with L(0) = 2, L(1) = 1,
    and each subsequent term is the sum of the two preceding ones.
    For example: L(2) = L(1) + L(0) = 1 + 2 = 3.

    Args:
        n_position (int): The position (index) of the Lucas number to find.
                          Must be a non-negative integer.

    Returns:
        int: The Lucas number at the specified n_position.
    """
    if n_position == 0:
        return 2
    if n_position == 1:
        return 1

    # Begin the sequence with its initial terms: L(0) and L(1).
    # 'past_two_val' tracks the value L(k-2) in our progression.
    past_two_val = 2  # This stores the L(0) value.
    # 'past_one_val' tracks the value L(k-1) in our progression.
    past_one_val = 1  # This stores the L(1) value.

    # Progress through the sequence to the desired position.
    # The loop steps from the third term (index 2) up to and including n_position.
    for _ in range(2, n_position + 1):
        # The present total is simply the sum of the two prior values.
        present_total = past_one_val + past_two_val
        # Shift the values: the prior L(k-1) becomes the new L(k-2).
        past_two_val = past_one_val
        # The newly computed total becomes the new L(k-1).
        past_one_val = present_total
    
    # After the loop completes, 'past_one_val' holds the N'th Lucas number.
    return past_one_val