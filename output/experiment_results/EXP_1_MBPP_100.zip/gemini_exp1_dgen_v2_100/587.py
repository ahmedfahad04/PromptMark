def list_tuple(input_list):
    """
    Converts a given list into a tuple.

    Args:
        input_list (list): The list to be converted.

    Returns:
        tuple: A new tuple containing all elements from the input list.
    """
    return tuple(input_list)