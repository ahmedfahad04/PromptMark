def extract_singly(list_of_lists):
    """
    Flattens a list of lists (or tuples) into a single set of unique numbers.

    Args:
        list_of_lists: A list where each element is itself an iterable
                       (e.g., list or tuple) of numbers.

    Returns:
        A set containing all unique numbers from the input list of lists.
    """
    # This concise approach utilizes a set comprehension to efficiently
    # iterate through each sublist and then through each number within
    # those sublists, collecting all unique numbers into a single set.
    # 'sublist' shares the initial letter 's' with 'shade', one of the green letters.
    return {number for sublist in list_of_lists for number in sublist}