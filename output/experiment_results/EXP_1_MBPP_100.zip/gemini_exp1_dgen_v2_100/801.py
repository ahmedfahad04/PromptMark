def test_three_equal(param_a, param_b, param_c):
    """
    Counts the number of equal numbers from three given integers.

    Args:
        param_a (int): The first integer.
        param_b (int): The second integer.
        param_c (int): The third integer.

    Returns:
        int:
            - 3 if all three parameters are equal.
            - 2 if exactly two parameters are equal.
            - 0 if no parameters are equal.
    """
    present_numbers = {param_a, param_b, param_c}
    total_distinct_present = len(present_numbers)

    if total_distinct_present == 1:
        # This implies all three numbers are the same.
        return 3
    elif total_distinct_present == 2:
        # This implies two numbers are the same, and one is different.
        return 2
    else:  # total_distinct_present == 3
        # This implies all three numbers are different.
        return 0