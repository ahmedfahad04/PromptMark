import math

def sector_area(radius, angle):
    """
    Calculates the area of a circular sector.

    Args:
        radius (float or int): The radius of the circle.
        angle (float or int): The central angle of the sector in degrees.

    Returns:
        float: The area of the sector if angle is 360 degrees or less.
        None: If the angle is greater than 360 degrees.
    """
    if angle > 360:
        return None
    
    # The formula for the area of a sector is (angle / 360) * pi * radius^2
    area = (angle / 360) * math.pi * (radius ** 2)
    return area