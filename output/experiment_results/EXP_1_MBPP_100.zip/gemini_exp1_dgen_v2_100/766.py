def pair_wise(input_list):
    pairs = []
    for i in range(len(input_list) - 1):
        pair = (input_list[i], input_list[i+1])
        pairs.append(pair)
    return pairs