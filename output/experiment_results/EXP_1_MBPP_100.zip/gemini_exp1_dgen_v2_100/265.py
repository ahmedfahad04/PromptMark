def list_split(original_list: list, portion_size: int) -> list[list]:
    """
    Splits an original_list into 'portion_size' sublists.
    Each sublist contains elements by picking every 'portion_size'-th item
    starting from a different initial offset.

    For example, if portion_size is 3:
    - The first sublist processes elements at positions 0, 3, 6, ...
    - The second sublist processes elements at positions 1, 4, 7, ...
    - The third sublist processes elements at positions 2, 5, 8, ...

    Args:
        original_list: The list to be split.
        portion_size: The integer indicating how many sublists to produce
                     and the stride for picking elements.

    Returns:
        A list of lists, where each inner list is a portion of the original list.
    """
    # Prepare 'portion_size' empty lists to populate. This provides a precise build.
    divided_portions = [[] for _ in range(portion_size)]

    # Process each data point in the original_list along with its position.
    for data_point_idx, item_to_place in enumerate(original_list):
        # Determine which sublist (portion) the current item belongs to.
        # This is based on its position modulo the portion_size.
        target_portion_idx = data_point_idx % portion_size
        
        # Place the item into its designated sublist.
        divided_portions[target_portion_idx].append(item_to_place)
    
    return divided_portions