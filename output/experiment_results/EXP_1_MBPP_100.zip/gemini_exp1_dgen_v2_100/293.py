import math

def otherside_rightangle(side1: float, side2: float) -> float:
    """
    Calculates the length of the third side of a right-angled triangle,
    assuming the two provided sides are the legs (perpendicular sides).

    This function applies the Pythagorean theorem: a^2 + b^2 = c^2,
    where 'a' and 'b' are the lengths of the legs, and 'c' is the length
    of the hypotenuse.

    Args:
        side1 (float): The length of the first leg of the triangle.
        side2 (float): The length of the second leg of the triangle.

    Returns:
        float: The length of the hypotenuse.

    Examples:
        >>> otherside_rightangle(3, 4)
        5.0
        >>> otherside_rightangle(7, 8)
        10.63014581273465
    """
    # Square each of the provided sides (legs).
    side1_squared = side1 ** 2
    side2_squared = side2 ** 2

    # Sum the squares of the two legs. This sum equals the square of the hypotenuse.
    sum_of_squares = side1_squared + side2_squared

    # Calculate the square root of the sum to find the length of the hypotenuse.
    hypotenuse = math.sqrt(sum_of_squares)

    return hypotenuse