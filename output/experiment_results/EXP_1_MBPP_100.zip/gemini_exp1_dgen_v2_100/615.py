def average_tuple(collection_of_tuples: tuple[tuple[float | int, ...], ...]) -> list[float]:
    """
    Calculates the average value for each inner tuple within a collection of tuples.

    Args:
        collection_of_tuples: A tuple where each element is another tuple of numbers (integers or floats).

    Returns:
        A list of floats, where each float is the average of an inner tuple.
        Returns an empty list if collection_of_tuples is empty.
        For an empty inner tuple, its average is considered 0.0 to prevent ZeroDivisionError.
    """
    return [
        (sum(sub_collection) / len(sub_collection) if sub_collection else 0.0)
        for sub_collection in collection_of_tuples
    ]