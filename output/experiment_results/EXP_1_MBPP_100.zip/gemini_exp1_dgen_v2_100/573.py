def unique_product(data_list):
    distinct_data_points = set(data_list)
    total_product_value = 1
    for data_point in distinct_data_points:
        total_product_value *= data_point
    return total_product_value