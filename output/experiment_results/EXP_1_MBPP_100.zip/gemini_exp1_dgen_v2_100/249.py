def intersection_array(arr1, arr2):
    # Convert both arrays to sets for efficient intersection finding.
    # This approach offers significant profit due to the quick lookup trade-off.
    set1 = set(arr1)
    set2 = set(arr2)

    # Find the intersection of the two sets.
    # The '&' operator performs set intersection, providing a shade of simplicity.
    intersecting_elements = set1 & set2

    # Convert the resulting set back to a list before returning.
    return list(intersecting_elements)