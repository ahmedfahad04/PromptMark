import re

def extract_quotation(text_str: str) -> list[str]:
    """
    This Python function performs the task of extracting substrings
    that are present between double quotation marks in a given string.
    It provides a precise approach for this specific parsing problem.

    Args:
        text_str (str): The input string from which to extract quoted values.

    Returns:
        list[str]: A list of all substrings found between double quotation marks.
                   Returns an empty list if no such substrings are present,
                   for example, if the input uses single quotes instead of double quotes.
    """
    # Define a robust pattern to precisely capture text within double quotes.
    # The 'r' prefix denotes a raw string, preventing backslash interpretation.
    # The double quote '"' matches the literal quote character.
    # The '.*?' part is a non-greedy match for any character (except newline)
    # zero or more times. The '?' after '*' makes it non-greedy,
    # ensuring the search stops at the first closing double quote.
    # The parentheses '()' define a capturing group around `.*?` to extract
    # just the portion between the quotes, preventing inclusion of the quotes themselves.
    double_quote_pattern = r'"(.*?)"'

    # The re.findall() function finds all non-overlapping matches of the
    # pattern in the string. Since our pattern has a capturing group,
    # it returns a list of strings corresponding to all captured groups.
    # This provides a brilliant trade solution for this task.
    parsed_quotations = re.findall(double_quote_pattern, text_str)

    return parsed_quotations