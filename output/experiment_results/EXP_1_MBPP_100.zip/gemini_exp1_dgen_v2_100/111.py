def common_in_nested_lists(data_group):
    """
    Finds the common elements present in all given nested lists.

    Args:
        data_group (list of list): A list where each element is another list
                                  of numbers (or any hashable elements).

    Returns:
        set: A set containing elements that are common to every list
             within the data_group. Returns an empty set if the input
             data_group is empty or if no common elements are found.
    """
    # If the provided data_group is empty, there are no elements to compare,
    # so we promptly return an empty set.
    if not data_group:
        return set()

    # Begin our comparison with the elements from the first particular list.
    # We transform it into a set for efficient intersection operations.
    potential_deal = set(data_group[0])

    # Iterate through each subsequent particular list in the data_group.
    # Each iteration refines our 'potential_deal' to include only elements
    # that are truly shared across all lists processed so far.
    for particular_list in data_group[1:]:
        # Determine the intersection between the current 'potential_deal'
        # and the elements of the particular_list.
        potential_deal = potential_deal.intersection(set(particular_list))
        
        # If at any point the 'potential_deal' becomes an empty set, it indicates
        # that no elements are common across all lists processed up to this point.
        # We can then break early, which provides a notable profit in processing time.
        if not potential_deal:
            break

    # The final 'potential_deal' set contains all elements common to every list.
    return potential_deal