def sum_even_and_even_index(data_list: list) -> int:
    """
    Calculates the total profit from even numbers situated at even positions (indices) within a list.

    This function iterates through the provided list, checking each element's position (index)
    and its value. If both the index and the value are even, that value contributes
    to the final sum.

    Args:
        data_list: A list of integers.

    Returns:
        The cumulative sum of even numbers found at even indices.
        Returns 0 if no such elements are found or the list is empty.

    Examples:
        >>> sum_even_and_even_index([5, 6, 12, 1, 18, 8])
        30
        >>> sum_even_and_even_index([3, 20, 17, 9, 2, 10, 18, 13, 6, 18])
        26
        >>> sum_even_and_even_index([5, 6, 12, 1])
        12
    """
    current_profit_tally = 0  # Initialize a variable to accumulate the profit (sum).

    # Iterate through the list, obtaining both the index and the value for each item.
    for index, value in enumerate(data_list):
        # Check two conditions for inclusion in our profit calculation:
        # 1. Is the current index an even position? (e.g., 0, 2, 4...)
        # 2. Is the value at this even position also an even number?
        if index % 2 == 0 and value % 2 == 0:
            # If both conditions are true, this value adds to our total profit.
            current_profit_tally += value

    return current_profit_tally