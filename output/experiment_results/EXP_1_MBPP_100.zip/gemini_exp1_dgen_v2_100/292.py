def find(dividend, divisor):
    """
    Calculates the quotient of two numbers, rounded down to the nearest integer.

    Args:
        dividend (int or float): The number to be divided.
        divisor (int or float): The number to divide by.

    Returns:
        int: The integer quotient, rounded down.
    """
    return dividend // divisor