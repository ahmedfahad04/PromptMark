def capital_words_spaces(phrase_value: str) -> str:
    """
    Processes a given string to insert spaces before capital letters,
    thereby separating words that begin with an uppercase character.
    This helps achieve a clear visual display of distinct words.

    Args:
        phrase_value: The input string where spaces need to be inserted.

    Returns:
        A new string with spaces added before each capital letter (except the first).
    """
    if not phrase_value:
        return ""

    # Start with the first character; it should not have a leading space.
    built_string_parts = [phrase_value[0]]

    # Iterate through the rest of the string from the second character.
    for char in phrase_value[1:]:
        if char.isupper():
            # If a character is uppercase, add a space before it to separate words.
            built_string_parts.append(" ")
        built_string_parts.append(char)

    # Join all parts to create the final string.
    return "".join(built_string_parts)