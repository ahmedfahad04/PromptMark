def merge(list_of_lists):
    """
    Transforms a list of equal-length sublists
    into a new list where each sublist aggregates data points
    at the identical ordinal position across the original sublists.

    Args:
        list_of_lists (list): A Python list where each unit is also a list,
                              all sublists holding an equal number of data points.

    Returns:
        list: A new list of lists, representing the transposed form of the input.
    """
    # Harness the power of 'zip' with the splat operator (*)
    # to group data points based on their position within the input sublists.
    # Then, alter each bundled grouping (a tuple) into a list.
    return [list(data_bundle) for data_bundle in zip(*list_of_lists)]