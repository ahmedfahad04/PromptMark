def start_withp(word_lists):
    """
    Identifies and returns the first two words starting with the letter 'p' (case-insensitive)
    from a given list of strings.

    Args:
        word_lists (list[str]): A list of strings, where each string may contain multiple words.

    Returns:
        tuple[str, str]: A tuple containing the first two 'p'-starting words found.
                         Returns a tuple with fewer elements if fewer than two are found.
    """
    p_words_found = []
    for phrase in word_lists:
        words_in_phrase = phrase.split()
        for word_item in words_in_phrase:
            if word_item.lower().startswith('p'):
                p_words_found.append(word_item)
                if len(p_words_found) == 2:
                    return tuple(p_words_found)
    return tuple(p_words_found)