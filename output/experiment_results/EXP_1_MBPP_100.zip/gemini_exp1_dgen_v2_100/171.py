def perimeter_pentagon(side_length):
    """
    Calculates the perimeter of a regular pentagon.

    A regular pentagon has five equal sides. Its perimeter is the sum of
    the lengths of its sides, which simplifies to five times the length
    of one side.

    Args:
        side_length (float or int): The length of one side of the pentagon.

    Returns:
        float or int: The total perimeter of the pentagon.
    """
    return 5 * side_length