def Split(numbers):
    """
    Finds and returns all even numbers from a list of numbers.

    Args:
        numbers (list): A list of integers.

    Returns:
        list: A new list containing only the even numbers from the input list.
    """
    return [num for num in numbers if num % 2 == 0]