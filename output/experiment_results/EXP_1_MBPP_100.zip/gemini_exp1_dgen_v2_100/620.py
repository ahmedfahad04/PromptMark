import math

def largest_subset(nums: list[int]) -> int:
    """
    Finds the size of the largest subset of numbers where every pair within the subset is divisible.

    A subset {s1, s2, ..., sk} is considered a divisible subset if for every pair (si, sj)
    in the subset, either si % sj == 0 or sj % si == 0.
    This implies that if the subset is sorted, say s1 < s2 < ... < sk, then each subsequent
    element must be divisible by its predecessor (s_i % s_{i-1} == 0).

    Args:
        nums: A list of integers.

    Returns:
        The size of the largest divisible subset.
    """
    if not nums:
        return 0

    # Sort the numbers in ascending order. This simplifies checking divisibility,
    # as we only need to check if a larger number is divisible by a smaller one.
    nums.sort()

    # dp[i] will store the size of the largest divisible subset ending with nums[i].
    # Each number itself forms a divisible subset of size 1.
    dp = [1] * len(nums)

    # Initialize the maximum size found so far.
    overall_max_subset_size = 1

    # Iterate through each number in the sorted list.
    for i in range(len(nums)):
        # For each nums[i], check all previous numbers nums[j] (where j < i).
        for j in range(i):
            # If nums[i] is divisible by nums[j], it means nums[i] can extend a divisible
            # subset that ends with nums[j].
            if nums[i] % nums[j] == 0:
                # Update dp[i] to be the maximum of its current value and (dp[j] + 1).
                # (dp[j] + 1) represents extending the subset ending at nums[j] by adding nums[i].
                dp[i] = max(dp[i], dp[j] + 1)
        
        # After evaluating all possible extensions for nums[i], update the overall maximum size.
        overall_max_subset_size = max(overall_max_subset_size, dp[i])

    return overall_max_subset_size