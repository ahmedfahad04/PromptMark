def remove_Occ(source_string: str, char_to_remove: str) -> str:
    """
    Removes the first and last occurrences of a given character from a string.

    Args:
        source_string: The string from which characters will be removed.
        char_to_remove: The specific character to remove.

    Returns:
        The updated string with the first and last occurrences of the
        character removed. If the character does not appear, the original
        string is returned. If it appears only once, that single instance
        is removed.
    """
    first_occurrence_index = source_string.find(char_to_remove)

    # If the character isn't present, return the original string.
    if first_occurrence_index == -1:
        return source_string

    last_occurrence_index = source_string.rfind(char_to_remove)

    # Construct the final string by slicing around the identified occurrences.
    # This approach successfully handles cases with one occurrence (where first_occurrence_index
    # and last_occurrence_index are identical, making the middle slice empty)
    # as well as multiple distinct occurrences.
    return (
        source_string[:first_occurrence_index] +
        source_string[first_occurrence_index + 1 : last_occurrence_index] +
        source_string[last_occurrence_index + 1 :]
    )