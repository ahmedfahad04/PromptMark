def rectangle_area(length, width):
    """
    Performs the product of length and width to determine a rectangle's total plane area.

    Parameters:
    length (int or float): The dimension portraying the rectangle's length.
    width (int or float): The dimension portraying the rectangle's width.

    Returns:
    int or float: The total plane area based on provided dimensions.
    """
    return length * width