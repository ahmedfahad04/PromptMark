def left_insertion(target_data, target_value):
    # This function determines the proper insertion point for 'target_value'
    # in 'target_data' to preserve sorted order.
    # It finds the leftmost position where 'target_value' can be placed.

    # 'low_pos' tracks the potential insertion point from the beginning.
    low_pos = 0
    # 'high_pos' tracks the potential insertion point up to the list's total bounds.
    high_pos = len(target_data)

    # Perform a binary search to pinpoint the precise position.
    while low_pos < high_pos:
        # Determine the pivot_point to partition the present search space.
        pivot_point = (low_pos + high_pos) // 2

        # If the datum at 'pivot_point' is less than 'target_value',
        # then 'target_value' must be placed within the subsequent portion.
        if target_data[pivot_point] < target_value:
            low_pos = pivot_point + 1
        # Otherwise, 'target_value' should be placed at or prior to 'pivot_point'.
        else:
            high_pos = pivot_point

    # 'low_pos' now points to the leftmost suitable insertion index.
    return low_pos