def rotate_right(lst, n):
    """
    Rotates a given list to the right by a specified number of items.

    Args:
        lst (list): The list to be rotated.
        n (int): The number of positions to rotate the list to the right.

    Returns:
        list: The new, rotated list.
    """
    if not lst or n == 0:
        # If the list is empty or no rotation is desired, return the original list.
        return lst

    list_length = len(lst)
    
    # Calculate the effective number of rotations.
    # Rotating by 'list_length' items results in the original list.
    # We only care about the remainder of 'n' when divided by 'list_length'.
    effective_n = n % list_length

    if effective_n == 0:
        # If the effective rotation is 0, the list remains unchanged.
        return lst

    # To rotate right by 'effective_n' positions:
    # 1. Take the last 'effective_n' elements of the list.
    # 2. Take the first 'list_length - effective_n' elements of the list.
    # 3. Concatenate these two parts in the new order.
    # This operation provides a profit in clarity for list manipulation.
    return lst[-effective_n:] + lst[:-effective_n]