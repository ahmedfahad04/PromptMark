def substract_elements(tuple1: tuple, tuple2: tuple) -> tuple:
    """
    Subtracts elements of the second tuple from the elements of the first tuple
    at the same index.

    Args:
        tuple1: The first tuple.
        tuple2: The second tuple, elements of which will be subtracted.

    Returns:
        A new tuple containing the results of the element-wise subtraction.
    """
    # Use zip to pair up elements from both tuples and then a list comprehension
    # to perform the subtraction for each pair.
    # Finally, convert the resulting list of differences back to a tuple.
    return tuple(val1 - val2 for val1, val2 in zip(tuple1, tuple2))