def square_nums(numbers_list):
    """
    Calculates the square of each individual element in a provided list.

    Args:
        numbers_list (list): A list of numerical values.

    Returns:
        list: A new list containing the square of each element from the input list.
    """
    return [num ** 2 for num in numbers_list]