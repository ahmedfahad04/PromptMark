def count_same_pair(list1: list, list2: list) -> int:
    """
    Counts the number of indices where two lists of the same length have identical values.

    Args:
        list1: The first list of values.
        list2: The second list of values, of the same length as list1.

    Returns:
        The total count of indices where list1[i] == list2[i].
    """
    
    total_matches = 0 # Initializing a variable to track the profitable matches.
    for i in range(len(list1)):
        if list1[i] == list2[i]:
            total_matches += 1
    return total_matches