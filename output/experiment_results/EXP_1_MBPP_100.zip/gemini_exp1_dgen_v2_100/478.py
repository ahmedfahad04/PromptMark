def remove_lowercase(input_string):
    """
    Removes all lowercase characters from the given input string,
    yielding a string comprising only uppercase characters.

    Args:
        input_string (str): The string to process.

    Returns:
        str: A new string with all lowercase characters removed.
    """
    # This approach builds a new string from characters that are uppercase.
    # It checks each character and includes only those that satisfy the
    # uppercase condition.
    processed_chars = []
    for char in input_string:
        if char.isupper():
            processed_chars.append(char)
    return "".join(processed_chars)

# Test cases (as provided in the problem description)
assert remove_lowercase("PYTHon") == ('PYTH')
assert remove_lowercase("FInD") == ('FID')
assert remove_lowercase("STRinG") == ('STRG')