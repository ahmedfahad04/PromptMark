def power(a, b):
    """
    Calculates the value of 'a' raised to the power 'b'.

    Args:
        a (int or float): The base number.
        b (int): The exponent. Must be a non-negative integer for this simple implementation.

    Returns:
        int or float: The result of a to the power of b.
    """
    # Python provides a direct and efficient operator for exponentiation: **
    # This allows a clear and concise calculation.
    return a ** b

# Test Cases:
assert power(3, 4) == 81
assert power(2, 3) == 8
assert power(5, 5) == 3125