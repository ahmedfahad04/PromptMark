def check_monthnumb_number(month_number: int) -> bool:
    """
    Checks if the given month number corresponds to a month with 31 days.

    Args:
        month_number (int): An integer representing the month (1 for January, 12 for December).

    Returns:
        bool: True if the month has 31 days, False otherwise.
    """
    months_with_31_days = [1, 3, 5, 7, 8, 10, 12]
    return month_number in months_with_31_days