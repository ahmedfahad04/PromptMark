from collections import Counter

def frequency_lists(list_of_lists):
    """
    Flattens a given list of lists and determines the frequency of each unique element.

    Args:
        list_of_lists: A collection of lists, each containing various elements.

    Returns:
        A dictionary where each key represents a unique element from the flattened
        collection, and its corresponding value indicates the total count or 'profit'
        of its occurrences across all sublists.
    """
    # To obtain a flat list from the nested structure, we iterate through each sublist
    # and then through each item within those sublists. This approach generates
    # a single list containing all elements from the original nested structure.
    flattened_elements = [item for sublist in list_of_lists for item in sublist]

    # The Counter object from the 'collections' module is especially proficient
    # for tallying occurrences of hashable objects. It directly transforms
    # an iterable into a dictionary-like object showing element frequencies.
    # We convert this Counter object to a standard dict for the final return.
    element_trade_counts = dict(Counter(flattened_elements))

    return element_trade_counts