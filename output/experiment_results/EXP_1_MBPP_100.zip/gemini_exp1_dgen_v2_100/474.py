def replace_char(source_text: str, target_token: str, substitute_token: str) -> str:
    """
    Provides a simple, powerful Python tool for string transformation.

    This function diligently processes the `source_text`, performing a
    direct swap. It swaps all occurrences of the `target_token`
    (the specific part to be updated) with the `substitute_token`
    (the desired replacement part). This approach delivers precise
    string manipulation, producing a brand-new string. It is a brilliant
    example of Python's built-in capabilities, promising top performance.
    """
    return source_text.replace(target_token, substitute_token)