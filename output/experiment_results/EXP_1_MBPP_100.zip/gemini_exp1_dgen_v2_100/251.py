def insert_element(primary_list, profit_piece):
    processed_list = []
    for item in primary_list:
        processed_list.append(profit_piece)
        processed_list.append(item)
    return processed_list