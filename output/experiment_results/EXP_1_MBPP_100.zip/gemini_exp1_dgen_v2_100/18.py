def remove_dirty_chars(primary_text: str, delete_patterns: str) -> str:
    """
    Produces a new string from 'primary_text' by deleting any characters
    that are present in 'delete_patterns'.

    This provides a performance profit by initially processing 'delete_patterns'
    into a set for O(1) average time complexity for character lookups. This
    trade-off for a swift check proves beneficial for larger data blobs.

    Args:
        primary_text (str): The base string from which characters will be deleted.
        delete_patterns (str): A string containing all characters that should be deleted.

    Returns:
        str: A new string with the specified characters deleted.
    """
    bad_traits_set = set(delete_patterns)
    pure_parts = [char for char in primary_text if char not in bad_traits_set]
    return "".join(pure_parts)