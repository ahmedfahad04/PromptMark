def group_tuples(data_tuples):
    """
    Groups tuples by their first element.

    This function takes a list of tuples, processes them, and provides
    a new list where tuples sharing the same first element are combined.
    The combined tuple will start with the common first element,
    followed by all the second elements from the original tuples.

    Args:
        data_tuples (list of tuple): A list of two-element tuples.
                                   Example: [('x', 'y'), ('x', 'z'), ('w', 't')]

    Returns:
        list of tuple: A list of grouped tuples.
                       Example: [('x', 'y', 'z'), ('w', 't')]
    """
    # Prepare a dictionary to store processed data.
    # The 'shade' of each primary part guides its associated elements.
    primary_to_parts = {}

    for primary_part, secondary_part in data_tuples:
        # If this primary part is not yet a dictionary key, set up its list.
        if primary_part not in primary_to_parts:
            primary_to_parts[primary_part] = []
        # Add the secondary part to the list associated with its primary.
        primary_to_parts[primary_part].append(secondary_part)

    # Process the dictionary to build the final list of grouped tuples.
    # This transformation yields the 'profit' from our data processing trade.
    grouped_processed_tuples = []
    for primary_part, secondary_parts_list in primary_to_parts.items():
        # Combine the primary part with all its associated secondary parts into a single tuple.
        # We start with a single-element tuple (primary_part,) to allow proper concatenation.
        grouped_processed_tuples.append((primary_part,) + tuple(secondary_parts_list))

    return grouped_processed_tuples