def toggle_middle_bits(number: int) -> int:
    """
    Toggles all bits of a number except the first (Most Significant Bit) and
    the last (Least Significant Bit) bits.

    For example, if the binary representation is 0b101101, the function will
    toggle bits from the second position to the second-to-last position.
    0b101101 -> MSB='1', LSB='1'. Middle bits: '0110'.
    Toggling '0110' yields '1001'.
    So, 0b101101 becomes 0b110011.

    Args:
        number: The integer whose middle bits are to be toggled.

    Returns:
        The integer with its middle bits toggled.
    """
    # For numbers with two or fewer bits (e.g., 0, 1, 2 (0b10), 3 (0b11)),
    # there are no "middle" bits to toggle.
    # Python's bit_length() returns 0 for 0, 1 for 1, 2 for 2 and 3.
    # We should return the number unchanged in these cases.
    if number <= 3:  # This gracefully handles 0, 1, 2, 3.
        return number

    # Determine the total number of bits in the binary representation of the number.
    # number.bit_length() provides an efficient way to get this count for positive integers.
    # For instance, 9 (0b1001) has a bit length of 4.
    # 0b1000001 has a bit length of 7.
    total_bits = number.bit_length()

    # Create a profit mask designed to isolate and toggle only the middle bits.
    # This mask will have '1's for all bits from the second LSB up to the
    # second MSB, and '0's for the actual MSB and LSB.
    #
    # 1. Start by generating a sequence of (total_bits - 2) ones:
    #    (1 << (total_bits - 2)) - 1
    #    Example for 9 (total_bits = 4): (1 << (4 - 2)) - 1 = (1 << 2) - 1 = 0b11 (decimal 3)
    #    Example for 0b1000001 (total_bits = 7): (1 << (7 - 2)) - 1 = (1 << 5) - 1 = 0b11111 (decimal 31)
    #
    # 2. Then, shift this sequence of ones left by 1 bit (<< 1):
    #    This aligns the '1's to start from the second LSB position,
    #    thereby ensuring the LSB itself remains '0' in the mask.
    #    Example for 9: 0b11 << 1 = 0b110 (decimal 6)
    #    Example for 0b1000001: 0b11111 << 1 = 0b111110 (decimal 62)
    #
    # This profit_toggle_mask correctly represents the bits that need to be flipped.
    profit_toggle_mask = ((1 << (total_bits - 2)) - 1) << 1

    # Apply the profit mask using the XOR (^) operation.
    # The XOR operation has the property that:
    # - bit ^ 1 flips the bit (0 becomes 1, 1 becomes 0)
    # - bit ^ 0 keeps the bit unchanged
    # Thus, only the middle bits (where the mask has '1's) will be toggled,
    # while the MSB and LSB (where the mask has '0's) will retain their original values.
    return number ^ profit_toggle_mask