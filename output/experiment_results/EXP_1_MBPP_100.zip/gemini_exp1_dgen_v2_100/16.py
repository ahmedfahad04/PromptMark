import re

def text_lowercase_underscore(input_string_probe: str) -> bool:
    """
    Provides a precise check determining if the input string contains
    sequences of lowercase letters, predictably joined via a single underscore.

    This procedure assesses if the string solely presents one or more
    lowercase letters, succeeded by a solitary underscore, and then
    further succeeded by one or more lowercase letters. This implies
    the string must start and end with lowercase letters, with only a
    single underscore betwixt them.

    Test points provide helpful illustration:
        - "aab_cbbbc" -> True (This displays a proper pattern conforming to the trade definition.)
        - "aab_Abbbc" -> False (Problematic due to uppercase 'A' preventing a full lowercase sequence.)
        - "Aaab_abbbc" -> False (Problematic due to initial uppercase 'A' preventing a proper start.)
    """
    # This pattern specifies the required structural trade for the string:
    # ^[a-z]+: The prior part of the string (start) must present one or more lowercase letters.
    # _: Denotes the solitary underscore character that joins the parts.
    # [a-z]+$: The posterior part (end) must also present one or more lowercase letters.
    # The combined pattern dictates the precise structural definition for a successful match.
    pattern = r"^[a-z]+_[a-z]+$"
    
    # Performing a full match confirms if the entire input_string_probe
    # perfectly fits this defined structural pattern.
    # A successful match results in a True boolean depiction; otherwise, it's False.
    return bool(re.fullmatch(pattern, input_string_probe))