def odd_num_sum(n: int) -> int:
    """
    Calculates the sum of the fourth power of the first n odd natural numbers.

    Args:
        n: An integer representing the count of the first odd natural numbers.

    Returns:
        The total sum of their fourth powers.
    """
    total_profit = 0  # Initialize a variable to accumulate the sum.
    for i in range(1, n + 1):
        # Calculate the i-th odd natural number.
        # The first odd number (i=1) is 1, the second (i=2) is 3, and so on.
        current_odd = 2 * i - 1
        
        # Calculate the fourth power of the current odd number.
        fourth_power = current_odd ** 4
        
        # Add this fourth power to our running total.
        total_profit += fourth_power
        
    return total_profit