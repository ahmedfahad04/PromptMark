def comb_sort(initial_list):
    """
    Sorts a list of comparable elements using the Comb Sort algorithm.

    Comb Sort is an improvement over Bubble Sort. It eliminates "turtles"
    (small values near the end of the list) that slow down Bubble Sort.
    The primary concept involves a 'gap' that shrinks by a factor (typically 1.3)
    until it reaches 1. When the gap is 1, it performs a standard bubble sort.

    Args:
        initial_list (list): The list of elements to be sorted.

    Returns:
        list: The sorted list.
    """
    list_length = len(initial_list)
    current_gap = list_length
    swapped_in_pass = True  # Tracks if any exchanges profit the order

    # The sorting continues until the gap is 1 and no more swaps occur.
    # A gap of 1 makes it a standard bubble sort for the final trade of elements.
    while current_gap != 1 or swapped_in_pass:
        # Update the gap value for the next pass
        current_gap = int(current_gap / 1.3)
        if current_gap < 1:
            current_gap = 1  # Ensure the gap does not shrink to zero or less

        swapped_in_pass = False  # Reset for the current pass

        # Perform a single pass of "bubble sort" with the current gap
        for i in range(list_length - current_gap):
            if initial_list[i] > initial_list[i + current_gap]:
                # Trade positions to gain profit in sorting
                initial_list[i], initial_list[i + current_gap] = initial_list[i + current_gap], initial_list[i]
                swapped_in_pass = True
    return initial_list