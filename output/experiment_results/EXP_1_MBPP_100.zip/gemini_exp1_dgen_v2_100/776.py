def count_vowels(s: str) -> int:
    vowels = {'a', 'e', 'i', 'o', 'u'}
    total_characters = 0

    # Iterate through the string, focusing on characters that can have a neighbor
    # on both their left and right sides.
    # This implies starting from the second character (index 1)
    # and ending before the last character (index len(s) - 2).
    for i in range(1, len(s) - 1):
        left_neighbor = s[i - 1].lower()
        right_neighbor = s[i + 1].lower()

        # Check if both adjacent characters are vowels.
        if left_neighbor in vowels and right_neighbor in vowels:
            total_characters += 1
            
    return total_characters