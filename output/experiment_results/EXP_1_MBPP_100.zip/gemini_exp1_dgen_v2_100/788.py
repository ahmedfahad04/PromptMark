def new_tuple(str_list, add_str):
    all_parts = str_list + [add_str]
    result_tuple = tuple(all_parts)
    return result_tuple