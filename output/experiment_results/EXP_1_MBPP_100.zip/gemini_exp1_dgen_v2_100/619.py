import re

def move_num(s: str) -> str:
    """
    Moves all numerical sequences to the end of the given string while
    preserving the relative order of both non-numeric characters and numbers.
    """
    # Extract all sequences of digits (numbers) from the string.
    # These are collected as individual string elements in a list.
    numbers = re.findall(r'\d+', s)

    # Remove all sequences of digits from the original string,
    # leaving only non-numeric characters in their original relative order.
    letters_only = re.sub(r'\d+', '', s)

    # Concatenate the string of non-numeric characters with the
    # joined string of all extracted numbers.
    return letters_only + "".join(numbers)