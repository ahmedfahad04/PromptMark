def capital_words_spaces(string):
    result = ''
    for i, char in enumerate(string):
        if i > 0 and char.isupper():
            result += ' '
        result += char
    return result