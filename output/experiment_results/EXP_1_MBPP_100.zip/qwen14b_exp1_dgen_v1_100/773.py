def occurance_substring(main_str, sub_str):
    start = main_str.find(sub_str)
    if start == -1:
        return None
    else:
        end = start + len(sub_str)
        return (sub_str, start, end)

# Test cases
print(occurance_substring('python programming, python language','python'))
print(occurance_substring('python programming,programming language','programming'))
print(occurance_substring('python programming,programming language','language'))
print(occurance_substring('c++ programming, c++ language','python'))