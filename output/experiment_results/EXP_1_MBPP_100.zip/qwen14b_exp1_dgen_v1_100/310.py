def string_to_tuple(s):
    return tuple(char for char in s)