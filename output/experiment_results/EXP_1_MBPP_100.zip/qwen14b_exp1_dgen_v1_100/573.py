def unique_product(numbers):
    # Use set comprehension to filter out duplicate values
    unique_numbers = {number for number in numbers}
    # Calculate the product using a generator expression
    product = 1
    for num in unique_numbers:
        product *= num
    return product