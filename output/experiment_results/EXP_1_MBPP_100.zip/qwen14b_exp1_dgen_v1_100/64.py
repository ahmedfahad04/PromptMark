def subject_marks(subject_list):
    # Sort the list based on the second item in each tuple (marks)
    sorted_list = sorted(subject_list, key=lambda x: x[1])
    return sorted_list