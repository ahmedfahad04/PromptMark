def new_tuple(lst, strg):
    return tuple(lst) + (strg,)