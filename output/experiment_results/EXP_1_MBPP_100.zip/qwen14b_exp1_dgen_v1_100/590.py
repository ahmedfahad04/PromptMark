import cmath

def polar_rect(rho, theta):
    # Convert polar coordinates (rho, theta) into complex number which represents rectangular coordinates
    rect = rho * cmath.exp(cmath.pi * 1j * theta / 180)
    return ((abs(rect), cmath.phase(rect)), rect)

# Test cases
print(polar_rect(3, 4))
print(polar_rect(4, 7))
print(polar_rect(15, 17))