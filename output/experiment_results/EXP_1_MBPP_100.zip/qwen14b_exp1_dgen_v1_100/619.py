def move_num(s):
    nums = ''.join([char for char in s if char.isdigit()])
    chars = ''.join([char for char in s if not char.isdigit()])
    return chars + nums