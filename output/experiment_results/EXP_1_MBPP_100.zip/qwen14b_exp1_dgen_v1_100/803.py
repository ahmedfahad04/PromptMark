import math

def is_perfect_square(n):
    # Calculate the square root of n and round it down
    sqrt_n = math.isqrt(n)
    # Check if squaring the rounded value equals the original number
    return sqrt_n * sqrt_n == n