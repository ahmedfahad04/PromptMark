def toggle_middle_bits(n):
    # Calculate the mask by finding the highest bit position
    # and creating a mask where all bits except the first and last are set.
    bit = n.bit_length() - 1
    while (n >> bit) == 0:
        bit -= 1
    mask = (1 << bit) - 1
    mask &= ~(1 | (1 << bit))
    
    # Toggle the middle bits using XOR operation.
    return n ^ mask