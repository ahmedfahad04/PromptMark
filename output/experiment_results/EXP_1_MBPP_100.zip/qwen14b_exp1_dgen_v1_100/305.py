def start_withp(words):
    p_words = [word.strip() for word in words[0].split() if word.strip().startswith('p') or word.strip().startswith('P')]
    return tuple(p_words[:2])