def sequence(n):
    if n <= 0:
        return None
    elif n == 1 or n == 2:
        return 1
    
    dp = [0] * (n + 1)
    dp[1], dp[2] = 1, 1
    
    for i in range(3, n + 1):
        dp[i] = dp[dp[i - 1]] + dp[i - dp[i - 1]]
    
    return dp[n]

# Test cases
print(sequence(10))  # Output: 6
print(sequence(2))   # Output: 1
print(sequence(3))   # Output: 2