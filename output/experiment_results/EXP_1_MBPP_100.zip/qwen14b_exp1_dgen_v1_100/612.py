def merge(list_of_lists):
    # Extracting the first elements from each sublist
    first_elements = [sublist[0] for sublist in list_of_lists]
    # Extracting the second elements from each sublist
    second_elements = [sublist[1] for sublist in list_of_lists]
    # Returning a list containing both extracted lists
    return [first_elements, second_elements]

# Example usage (not part of the generated solution but provided for clarity)
result = merge([['x', 'y'], ['a', 'b'], ['m', 'n']])
print(result)  # Output should be [['x', 'a', 'm'], ['y', 'b', 'n']]