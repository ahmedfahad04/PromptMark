def comb_sort(arr):
    shrink_factor = 1.3
    gap = len(arr)
    swapped = True
    
    while gap > 1 or swapped:
        gap = int(gap / shrink_factor)
        if gap < 1:
            gap = 1
        swapped = False
        
        i = 0
        while (i + gap) < len(arr):
            if arr[i] > arr[i + gap]:
                arr[i], arr[i + gap] = arr[i + gap], arr[i]
                swapped = True
            i += 1
            
    return arr