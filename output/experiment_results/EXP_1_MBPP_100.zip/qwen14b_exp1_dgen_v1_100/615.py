def average_tuple(tup):
    averages = []
    for t in tup:
        avg = sum(t) / len(t)
        averages.append(avg)
    return averages

# Test cases
print(average_tuple(((10, 10, 10, 12), (30, 45, 56, 45), (81, 80, 39, 32), (1, 2, 3, 4))))
print(average_tuple(((1, 1, -5), (30, -15, 56), (81, -60, -39), (-10, 2, 3))))
print(average_tuple(((100, 100, 100, 120), (300, 450, 560, 450), (810, 800, 390, 320), (10, 20, 30, 40))))