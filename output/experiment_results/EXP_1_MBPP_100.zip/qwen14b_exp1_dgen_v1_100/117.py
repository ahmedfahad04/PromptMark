def list_to_float(list_of_lists):
    result = []
    for sublist in list_of_lists:
        converted_sublist = tuple(float(item) if item.replace('.', '', 1).isdigit() else item for item in sublist)
        result.append(converted_sublist)
    return result