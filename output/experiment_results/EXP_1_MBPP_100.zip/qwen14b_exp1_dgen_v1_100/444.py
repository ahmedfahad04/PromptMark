def trim_tuple(lst, k):
    return str([tuple(x[k:-k]) if k < len(x) else () for x in lst])

# Example usage:
result = trim_tuple([(5, 3, 2, 1, 4), (3, 4, 9, 2, 1), (9, 1, 2, 3, 5), (4, 8, 2, 1, 7)], 2)
print(result)