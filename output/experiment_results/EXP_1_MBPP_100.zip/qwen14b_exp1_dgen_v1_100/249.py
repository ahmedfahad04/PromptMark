def intersection_array(arr1, arr2):
    # Utilizing set operations to find common elements between two lists
    return list(set(arr1) & set(arr2))