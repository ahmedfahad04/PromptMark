def mul_even_odd(arr):
    even = None
    odd = None
    
    for num in arr:
        if even is None and num % 2 == 0:
            even = num
        elif odd is None and num % 2 != 0:
            odd = num
        if even is not None and odd is not None:
            break
            
    return even * odd

# Test cases
print(mul_even_odd([1,3,5,7,4,1,6,8]))  # Output: 4
print(mul_even_odd([1,2,3,4,5,6,7,8,9,10]))  # Output: 2
print(mul_even_odd([1,5,7,9,10]))  # Output: 10