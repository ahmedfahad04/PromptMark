def list_split(lst, n):
    result = [[] for _ in range(n)]
    for i, item in enumerate(lst):
        result[i % n].append(item)
    return result

# Example usage:
# print(list_split(['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n'], 3))