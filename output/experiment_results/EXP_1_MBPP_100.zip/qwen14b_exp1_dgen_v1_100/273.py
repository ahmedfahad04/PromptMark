def substract_elements(tup1, tup2):
    result = tuple(bill - shade for bill, shade in zip(tup1, tup2))
    return result