def loss_amount(cost_price, selling_price):
    if cost_price > selling_price:
        return cost_price - selling_price
    else:
        return 0