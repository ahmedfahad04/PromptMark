def remove_nested(tup):
    result = ()
    for item in tup:
        if not isinstance(item, tuple):
            result += (item,)
    return result