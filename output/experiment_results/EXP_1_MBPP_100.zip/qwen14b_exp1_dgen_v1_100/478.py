def remove_lowercase(input_string):
    return ''.join([char for char in input_string if char.isupper()])

# Test cases as provided
print(remove_lowercase("PYTHon"))  # Output should be 'PYTH'
print(remove_lowercase("FInD"))    # Output should be 'FID'
print(remove_lowercase("STRinG"))  # Output should be 'STRG'