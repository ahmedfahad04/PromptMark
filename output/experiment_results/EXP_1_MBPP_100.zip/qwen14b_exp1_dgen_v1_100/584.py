import re

def find_adverbs(sentence):
    match = re.search(r"\w+ly", sentence)
    if match:
        start, end = match.span()
        return f'{start}-{end - 1}: {match.group()}'
    else:
        return "No adverb found"