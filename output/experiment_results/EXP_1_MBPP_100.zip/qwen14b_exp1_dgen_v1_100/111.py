def common_in_nested_lists(nested_lists):
    # Convert each list within the nested list into a set
    sets = map(set, nested_lists)
    
    # Initialize result as the first set, then take intersection with the rest
    common_elements = sets.__next__()
    for s in sets:
        common_elements &= s
    
    return list(common_elements)

# Example usage (not part of the generated response but provided for clarity)
# results = common_in_nested_lists([[12, 18, 23, 25, 45], [7, 12, 18, 24, 28], [1, 5, 8, 12, 15, 16, 18]])
# print(results)  # Output will be [12, 18]