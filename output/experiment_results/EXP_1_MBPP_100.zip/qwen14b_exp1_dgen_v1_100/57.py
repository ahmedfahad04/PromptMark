def find_Max_Num(digits):
    # Sort the digits in descending order and join them to form the largest number
    max_num = ''.join(str(i) for i in sorted(digits, reverse=True))
    return int(max_num)