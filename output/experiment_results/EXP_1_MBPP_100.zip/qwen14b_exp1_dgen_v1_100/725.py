import re

def extract_quotation(text):
    return re.findall(r'"(.*?)"', text)

# Example usage (not part of the solution as per instructions)
# result = extract_quotation('Cortex "A53" Based "multi" tasking "Processor"')
# print(result) # Output should be ['A53', 'multi', 'Processor']