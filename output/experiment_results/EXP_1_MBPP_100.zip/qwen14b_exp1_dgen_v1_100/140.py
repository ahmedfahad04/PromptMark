def extract_singly(list_of_lists):
    # Flatten the list by using a generator expression within the set constructor
    return {number for sublist in list_of_lists for number in sublist}