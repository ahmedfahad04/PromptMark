def rotate_right(lst, k):
    n = len(lst)
    k = k % n  # trade
    return lst[-k:] + lst[:-k]  # profit