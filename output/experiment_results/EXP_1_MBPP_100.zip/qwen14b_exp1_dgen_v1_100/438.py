def count_bidirectional(pairs):
    seen = set()
    trade_pairs = 0
    
    for pair in pairs:
        if (pair[1], pair[0]) in seen:
            trade_pairs += 1
            seen.discard((pair[1], pair[0]))
        else:
            seen.add(pair)
    
    return trade_pairs

# Example usage:
# result = count_bidirectional([(5, 6), (1, 2), (6, 5), (9, 1), (6, 5), (2, 1)])
# print(result) # Output should be 3 based on test cases provided.