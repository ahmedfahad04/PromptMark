def count_rotation(arr):
    n = len(arr)
    count = 0
    for i in range(1, n):
        if arr[i - 1] > arr[i]:
            count += 1
            break
    return (count + 1) % n