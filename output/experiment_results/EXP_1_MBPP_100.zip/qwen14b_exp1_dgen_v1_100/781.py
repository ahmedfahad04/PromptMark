def count_divisors(n):
    divisor_count = 0
    for i in range(1, n + 1):
        if n % i == 0:
            divisor_count += 1
    return divisor_count % 2 == 0

# Test cases provided
assert count_divisors(10) == True
assert count_divisors(100) == False
assert count_divisors(125) == False