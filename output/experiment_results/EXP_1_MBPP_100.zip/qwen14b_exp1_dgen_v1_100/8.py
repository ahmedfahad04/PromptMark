def square_nums(numbers):
    return [num ** 2 for num in numbers]