import re

def text_lowercase_underscore(s):
    pattern = r'^[a-z]+_[a-z]+$'
    return bool(re.match(pattern, s))