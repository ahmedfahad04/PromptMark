import math

def otherside_rightangle(side1, side2):
    # Calculate the hypotenuse using Pythagoras theorem
    return math.sqrt(side1**2 + side2**2)