def remove_whitespaces(s):
    return s.replace(' ', '')

# Example usage based on test cases:
print(remove_whitespaces(' Google    Flutter '))
print(remove_whitespaces(' Google    Dart '))
print(remove_whitespaces(' iOS    Swift '))