def find_First_Missing(nums):
    i = 0
    while i < len(nums) and nums[i] == i:
        i += 1
    return i

# Test cases
print(find_First_Missing([0,1,2,3])) # Output: 4
print(find_First_Missing([0,1,2,6,9])) # Output: 3
print(find_First_Missing([2,3,5,8,9])) # Output: 0