def round_and_sum(numbers):
    rounded_sum = sum(round(num) for num in numbers)
    result = rounded_sum * len(numbers)
    return result