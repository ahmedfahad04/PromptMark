def parabola_directrix(a, b, c):
    # Calculate the directrix using the formula -c / (4 * a)
    return (-c) / (4 * a)

# Example usage, though not part of the required output
result = parabola_directrix(5, 3, 2)
print("Directrix:", result)