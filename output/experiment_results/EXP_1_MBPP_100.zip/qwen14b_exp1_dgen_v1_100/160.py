def extended_gcd(a, b):
    if a == 0 :
        return b, 0, 1
    gcd, x1, y1 = extended_gcd(b % a, a)
    x = y1 - (b//a) * x1
    y = x1
    return gcd, x, y

def find_solution(a, b, n):
    gcd, x, y = extended_gcd(a, b)
    if n % gcd != 0:
        return None
    x *= n // gcd
    y *= n // gcd
    return (x, y)

# Test cases provided
print(find_solution(2, 3, 7))
print(find_solution(4, 2, 7))
print(find_solution(1, 13, 17))