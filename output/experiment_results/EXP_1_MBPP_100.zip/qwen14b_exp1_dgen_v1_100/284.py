def check_element(lst, elem):
    return all(item == elem for item in lst)