def min_Swaps(s1, s2):
    diff_count = 0
    if len(s1) != len(s2):
        return "Invalid Input Size"
    
    # Count differing bits
    for i in range(len(s1)):
        if s1[i] != s2[i]:
            diff_count += 1
    
    # If number of differing bits is odd, conversion not possible
    if diff_count % 2 != 0:
        return "Not Possible"
    
    # Minimum swaps needed is half the number of differing bits
    return diff_count // 2

# Test cases
print(min_Swaps("1101", "1110"))
print(min_Swaps("111", "000"))
print(min_Swaps("111", "110"))