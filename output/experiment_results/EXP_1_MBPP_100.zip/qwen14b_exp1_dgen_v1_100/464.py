def check_value(dict_obj, value):
    return all(v == value for v in dict_obj.values())