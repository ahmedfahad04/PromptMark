def frequency_lists(lists):
    from itertools import chain
    flat_list = list(chain(*lists))
    freq_dict = {}
    for item in flat_list:
        if item in freq_dict:
            freq_dict[item] += 1
        else:
            freq_dict[item] = 1
    return freq_dict