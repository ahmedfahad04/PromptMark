def find_first_occurrence(arr, target):
    low = 0
    high = len(arr) - 1
    result = -1
    while low <= high:
        mid = (low + high) // 2
        if arr[mid] == target:
            result = mid
            high = mid - 1  # Trade-off for finding the first occurrence
        elif arr[mid] < target:
            low = mid + 1
        else:
            high = mid - 1
    return result