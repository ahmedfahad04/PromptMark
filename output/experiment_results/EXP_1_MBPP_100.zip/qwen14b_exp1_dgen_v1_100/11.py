def remove_Occ(s, char):
    first_occurrence = s.find(char)
    if first_occurrence == -1:
        return s  # Character not found in string
    
    after_first = s[first_occurrence+1:]
    second_occurrence = after_first.find(char) + first_occurrence + 1
    result_string = s[:second_occurrence] + s[second_occurrence+1:] if second_occurrence != -1 else s[:first_occurrence] + s[first_occurrence+1:]
    
    return result_string