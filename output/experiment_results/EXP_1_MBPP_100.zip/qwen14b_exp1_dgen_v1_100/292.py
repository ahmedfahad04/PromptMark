def find(numerator, denominator):
    return numerator // denominator