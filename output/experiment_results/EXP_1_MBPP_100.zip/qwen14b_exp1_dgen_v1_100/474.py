def replace_char(word, old_char, new_char):
    return word.replace(old_char, new_char)