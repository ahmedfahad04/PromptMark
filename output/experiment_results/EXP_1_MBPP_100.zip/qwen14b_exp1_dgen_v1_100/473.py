def tuple_intersection(tup_list1, tup_list2):
    # Convert each tuple list into sets of frozensets to ignore order within tuples
    set_tup1 = {frozenset(t) for t in tup_list1}
    set_tup2 = {frozenset(t) for t in tup_list2}
    
    # Find common frozensets between both lists
    common_elements = set_tup1.intersection(set_tup2)
    
    # Convert frozensets back to regular tuples
    result = {tuple(sorted(x)) for x in common_elements}
    
    return result