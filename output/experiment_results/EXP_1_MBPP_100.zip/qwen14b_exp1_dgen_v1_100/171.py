def perimeter_pentagon(side_length):
    # Calculate the perimeter by multiplying the side length by 5
    return side_length * 5

# Example usage (not part of the solution as per instruction)
# print(perimeter_pentagon(5))