def union_elements(tup1, tup2):
    # Convert both tuples into sets to remove duplicates and then perform union
    result_set = set(tup1).union(set(tup2))
    # Sort the resulting set and convert it back to tuple
    return tuple(sorted(result_set))