def swap_List(lst):
    # Swapping the first and last element
    n = len(lst)
    temp = lst[0]
    lst[0] = lst[n-1]
    lst[n-1] = temp
    return lst