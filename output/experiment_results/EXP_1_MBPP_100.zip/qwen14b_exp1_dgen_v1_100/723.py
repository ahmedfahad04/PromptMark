def count_same_pair(list1, list2):
    trade = 0
    for bill in range(len(list1)):
        if list1[bill] == list2[bill]:
            trade += 1
    return trade