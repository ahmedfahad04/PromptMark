def find_Element(arr, queries, n, idx):
    arr_copy = arr.copy()
    for query in queries:
        d = query[1]
        for i in range(d):
            last_element = arr_copy[-1]
            arr_copy = [last_element] + arr_copy[:-1]
    return arr_copy[idx]

# Test cases provided do not need to be included in the solution code as per instruction.