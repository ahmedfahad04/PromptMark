def count_Substrings(s):
    def valid_substring(sub):
        return sum(int(c) for c in sub) == len(sub)
    
    count = 0
    n = len(s)
    for i in range(n):
        for j in range(i + 1, n + 1):
            if valid_substring(s[i:j]):
                count += 1
    return count