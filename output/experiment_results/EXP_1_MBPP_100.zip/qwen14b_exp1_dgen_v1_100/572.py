def remove_duplicates(nums):
    seen = set()
    result = []
    for num in nums:
        if num not in seen:
            seen.add(num)
            result.append(num)
    return result

# Renaming the function as per the problem statement
two_unique_nums = remove_duplicates