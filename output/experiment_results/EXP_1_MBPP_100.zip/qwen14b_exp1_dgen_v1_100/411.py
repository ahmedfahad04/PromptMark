def snake_to_camel(snake_str):
    components = snake_str.split('_')
    return ''.join(x.title() for x in components)

# Example usage (not part of the generated code as per instruction)
# result1 = snake_to_camel('android_tv')
# result2 = snake_to_camel('google_pixel')
# result3 = snake_to_camel('apple_watch')