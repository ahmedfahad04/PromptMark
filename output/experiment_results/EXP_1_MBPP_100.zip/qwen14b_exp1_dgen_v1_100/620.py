def largest_subset(nums):
    nums.sort()
    dp = [1] * len(nums)
    for i in range(1, len(nums)):
        for j in range(i):
            if nums[i] % nums[j] == 0:
                dp[i] = max(dp[i], dp[j] + 1)
    return max(dp)

# Test cases provided
print(largest_subset([1, 3, 6, 13, 17, 18]))  # Output: 4
print(largest_subset([10, 5, 3, 15, 20]))     # Output: 3
print(largest_subset([18, 1, 3, 6, 13, 17]))  # Output: 4