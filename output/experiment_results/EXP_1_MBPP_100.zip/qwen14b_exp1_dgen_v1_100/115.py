def empty_dit(lst):
    return all(not d for d in lst)