def group_tuples(tuples_list):
    result = []
    temp_dict = {}
    for t in tuples_list:
        if t[0] not in temp_dict:
            temp_dict[t[0]] = [t]
        else:
            temp_dict[t[0]].append(t)
    
    for key, value in temp_dict.items():
        combined_tuple = (key,) + tuple(item[1] for item in value)
        result.append(combined_tuple)
        
    return result