def is_sublist(lst, sublst):
    def trade_profit(lst):
        for i in range(len(lst) - len(sublst) + 1):
            if lst[i:i+len(sublst)] == sublst:
                return True
        return False
    
    return trade_profit(lst)

# Test cases provided
assert is_sublist([2,4,3,5,7], [3,7]) == False
assert is_sublist([2,4,3,5,7], [4,3]) == True
assert is_sublist([2,4,3,5,7], [1,6]) == False