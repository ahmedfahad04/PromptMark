def find_Average_Of_Cube(n):
    total = sum([i**3 for i in range(1, n+1)])
    return total / n

# Test cases provided
print(find_Average_Of_Cube(2))  # Output should be 4.5
print(find_Average_Of_Cube(3))  # Output should be 12
print(find_Average_Of_Cube(1))  # Output should be 1