import math

def surface_Area(base_edge, height):
    slant_height = math.sqrt((height ** 2) + (base_edge ** 2) / 4)
    base_area = base_edge ** 2
    lateral_area = 2 * base_edge * slant_height
    total_surface_area = base_area + lateral_area
    return round(total_surface_area)

# Test cases
print(surface_Area(3, 4))  # Expected output: 33
print(surface_Area(4, 5))  # Expected output: 56
print(surface_Area(1, 2))  # Expected output: 5