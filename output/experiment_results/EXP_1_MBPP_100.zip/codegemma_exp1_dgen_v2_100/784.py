def mul_even_odd(nums):
  first_even = None
  first_odd = None
  for num in nums:
    if num % 2 == 0 and first_even is None:
      first_even = num
    elif num % 2 != 0 and first_odd is None:
      first_odd = num
  if first_even and first_odd:
    return first_even * first_odd
  return 0