def capital_words_spaces(text):
  new_text = []
  for word in text.split():
    if word[0].isupper():
      new_text.append(word)
    else:
      new_text.append(word + " ")
  return "".join(new_text)