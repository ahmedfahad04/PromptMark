def min_Swaps(num1, num2):
    if num1 == num2:
        return "Not Possible"
    
    count = 0
    for i in range(len(num1)):
        if num1[i] != num2[i]:
            count += 1
    
    return count