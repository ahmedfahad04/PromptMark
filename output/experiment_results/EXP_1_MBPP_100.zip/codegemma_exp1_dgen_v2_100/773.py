def occurance_substring(text, subtext):
  if subtext not in text:
    return None
  
  for i in range(len(text)):
    if text[i:i+len(subtext)] == subtext:
      return subtext, i, i+len(subtext)