def remove_lowercase(text):
  return ''.join([ch for ch in text if not ch.islower()])