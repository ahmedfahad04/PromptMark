import re

def find_adverbs(text):
  pattern = r"\b(\w+ly)\b"
  matches = re.finditer(pattern, text)
  adverbs = []
  for match in matches:
    adverbs.append(f"{match.span()[0]}-{match.span()[1]}: {match.group()}")
  return "\n".join(adverbs)