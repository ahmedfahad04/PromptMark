def toggle_middle_bits(num):
  """
  This function toggles bits of the number except the first and the last bit.
  """
  num = num & (num >> 1)
  num = num & (num << 1)
  return num