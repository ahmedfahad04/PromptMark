def reverse_string_list(str_list):
  """
  Reverses each string in a given list of string values.

  Args:
    str_list: A list of string values.

  Returns:
    A new list of strings with each string reversed.
  """
  return [str_[::-1] for str_ in str_list]