def trim_tuple(tuple_list, k):
  return '[' + ', '.join([str(tuple_[k:]) for tuple_ in tuple_list]) + ']'