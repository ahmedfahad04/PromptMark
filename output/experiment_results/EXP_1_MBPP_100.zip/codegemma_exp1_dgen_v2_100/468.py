def max_product(arr):
    max_product = float('-inf')
    current_product = 1
    for num in arr:
        current_product *= num
        if current_product > max_product:
            max_product = current_product
        if current_product == 0:
            current_product = 1
    return max_product