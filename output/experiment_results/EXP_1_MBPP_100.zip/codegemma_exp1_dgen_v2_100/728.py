def sum_list(a, b):
  return [a_i + b_i for a_i, b_i in zip(a, b)]