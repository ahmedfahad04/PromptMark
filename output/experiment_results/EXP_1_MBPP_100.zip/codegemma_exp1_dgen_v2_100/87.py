def merge_dictionaries_three(dict1, dict2, dict3):
    """
    Merges three dictionaries into a single dictionary.
    """
    merged_dict = {}
    merged_dict.update(dict1)
    merged_dict.update(dict2)
    merged_dict.update(dict3)
    return merged_dict