def rotate_right(nums, k):
  """
  Rotates a list by k items to the right direction.
  """
  n = len(nums)
  k = k % n
  nums[:] = nums[n - k:] + nums[:n - k]
  return nums