def average_tuple(tuple_of_tuples):
  """
  This function takes a tuple of tuples and returns the average value for each tuple as a list.
  """
  average_list = []
  for tup in tuple_of_tuples:
    average_list.append(sum(tup) / len(tup))
  return average_list