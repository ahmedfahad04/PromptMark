def interleave_lists(list1, list2, list3):
  """Interleaves three lists of the same length into a single flat list."""
  return [item for sublist in zip(list1, list2, list3) for item in sublist]