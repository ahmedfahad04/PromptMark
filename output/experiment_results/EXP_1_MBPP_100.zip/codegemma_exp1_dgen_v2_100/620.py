def largest_subset(nums):
  nums.sort()
  size = len(nums)
  for i in range(size):
    if nums[i] % nums[i + 1] == 0 or nums[i + 1] % nums[i] == 0:
      size -= 1
  return size