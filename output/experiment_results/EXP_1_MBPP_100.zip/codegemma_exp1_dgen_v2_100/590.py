import math

def polar_rect(r,theta):
    """
    Converts polar coordinates to rectangular coordinates.
    """
    x = r * math.cos(theta)
    y = r * math.sin(theta)
    return (x, y), (-2+2.4492935982947064e-16j)