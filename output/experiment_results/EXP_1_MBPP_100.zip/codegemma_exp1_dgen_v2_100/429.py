def and_tuples(tup1, tup2):
  res = []
  for i in range(len(tup1)):
    res.append(tup1[i] and tup2[i])
  return tuple(res)