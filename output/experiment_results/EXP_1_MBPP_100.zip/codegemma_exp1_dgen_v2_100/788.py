def new_tuple(list_of_words, new_word):
  return tuple(list_of_words + [new_word])