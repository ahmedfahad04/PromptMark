def frequency_lists(list_of_lists):
  """
  This function takes a list of lists and returns a dictionary of the frequency of each element in the flattened list of lists.
  """
  flattened_list = []
  for sublist in list_of_lists:
    flattened_list.extend(sublist)
  frequency_dict = {}
  for element in flattened_list:
    if element in frequency_dict:
      frequency_dict[element] += 1
    else:
      frequency_dict[element] = 1
  return frequency_dict