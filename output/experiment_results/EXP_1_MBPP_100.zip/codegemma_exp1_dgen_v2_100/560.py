def union_elements(tuple1, tuple2):
  """
  This function finds the union of the elements of two given tuples and outputs them in sorted order.
  """
  # Create a set to store the unique elements
  union_set = set(tuple1)
  union_set.update(tuple2)
  
  # Convert the set to a tuple and sort it
  union_tuple = tuple(sorted(union_set))
  
  # Return the sorted tuple
  return union_tuple