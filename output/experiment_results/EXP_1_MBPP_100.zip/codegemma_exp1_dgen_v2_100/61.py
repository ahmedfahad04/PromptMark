def count_Substrings(num):
  count = 0
  for i in range(len(num)):
    for j in range(i + 1, len(num) + 1):
      sub = num[i:j]
      if int(sub) == len(sub):
        count += 1
  return count