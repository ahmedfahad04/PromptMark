def is_perfect_square(num):
  if num < 0:
    return False
  sqrt = int(num ** 0.5)
  return sqrt * sqrt == num