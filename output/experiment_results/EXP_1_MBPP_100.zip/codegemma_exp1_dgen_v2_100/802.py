def count_rotation(nums):
  left = 0
  right = len(nums) - 1
  count = 0
  while left <= right:
    mid = (left + right) // 2
    if mid == 0 or nums[mid] < nums[mid - 1]:
      return count
    elif nums[mid] > nums[-1]:
      left = mid + 1
    else:
      right = mid - 1
    count += 1
  return -1