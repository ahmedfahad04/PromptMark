def replace_char(text, old, new):
    return text.replace(old, new)