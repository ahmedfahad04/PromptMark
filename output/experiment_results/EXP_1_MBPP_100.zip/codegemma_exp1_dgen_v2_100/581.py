def surface_Area(base_edge, height):
    """
    This function calculates the surface area of a square pyramid with a given base edge and height.
    """
    base_area = base_edge**2
    lateral_area = (base_edge * height) * 4
    return (base_area + lateral_area) / 2