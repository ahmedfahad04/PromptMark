from itertools import groupby

def group_tuples(tuples):
  return [[key] + list(group) for key, group in groupby(tuples, key=lambda t: t[0])]