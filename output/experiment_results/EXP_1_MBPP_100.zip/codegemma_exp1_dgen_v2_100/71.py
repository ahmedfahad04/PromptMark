def comb_sort(array):
    gap = len(array)
    swapped = True
    
    while gap > 0 and swapped:
        swapped = False
        for i in range(gap, len(array)):
            if array[i - gap] > array[i]:
                array[i - gap], array[i] = array[i], array[i - gap]
                swapped = True
        gap //= 1
    
    return array