def sequence(n):
    if n == 1:
        return 1
    if n == 2:
        return 1
    if n == 3:
        return 2
    
    a = 1
    b = 1
    c = 2
    
    for i in range(4, n):
        a, b, c = b, c, a + b
    
    return c