def merge(list_of_lists):
  """
  Merges a list of lists into two lists.
  The first list will have the first element of each sublist,
  and the second list will have the second element of each sublist.
  """
  first_list = []
  second_list = []
  for sublist in list_of_lists:
    first_list.append(sublist[0])
    second_list.append(sublist[1])
  return [first_list, second_list]