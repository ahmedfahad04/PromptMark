def swap_List(list):
  """
  This function swaps the first and last element in a given list.
  """
  list[0], list[-1] = list[-1], list[0]
  return list