def find_First_Missing(nums):
    if not nums:
        return 0
    
    if nums[-1] < 0:
        return 0
    
    for i in range(len(nums)):
        if nums[i] < 0:
            nums[i] = 0
    
    for i in range(len(nums)):
        num = abs(nums[i])
        if num < len(nums):
            if nums[num] > 0:
                nums[num] = -abs(nums[num])
    
    for i in range(len(nums)):
        if nums[i] > 0:
            return i
    
    return len(nums)