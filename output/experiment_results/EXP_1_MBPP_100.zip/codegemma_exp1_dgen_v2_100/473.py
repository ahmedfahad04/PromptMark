def tuple_intersection(list1, list2):
  """
  Finds the tuple intersection of elements in the given tuple list irrespective of their order.
  """
  set1 = set(list1)
  set2 = set(list2)
  return {element for element in set1 if element in set2}