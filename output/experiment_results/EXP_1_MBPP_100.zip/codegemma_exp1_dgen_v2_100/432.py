def median_trapezium(a,b,c):
  """
  This function calculates the median length of a trapezium.
  """
  if a > b:
    a, b = b, a
  if a > c:
    a, c = c, a
  if b > c:
    b, c = c, b
  if a + b < c:
    return "Not a trapezium"
  else:
    return (a + b - c) / 2