def move_num(text):
  """
  Moves all the numbers to the end of the given string.

  Args:
    text: The string to process.

  Returns:
    The processed string with all the numbers moved to the end.
  """
  result = []
  nums = []
  for char in text:
    if char.isdigit():
      nums.append(char)
    else:
      result.append(char)
  result.extend(nums)
  return ''.join(result)