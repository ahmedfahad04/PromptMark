def loss_amount(sp,cp):
    if sp<cp:
        return cp-sp
    else:
        return 0