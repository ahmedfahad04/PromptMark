import math

def multiply_num(list):
  product = 1
  for num in list:
    product *= num
  return product / len(list)