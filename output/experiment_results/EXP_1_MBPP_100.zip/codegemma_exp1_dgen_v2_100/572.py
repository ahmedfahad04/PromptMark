def two_unique_nums(nums):
  unique_nums = set()
  for num in nums:
    if num not in unique_nums:
      unique_nums.add(num)
  return list(unique_nums)