def check_value(dict, value):
  for key in dict.values():
    if key != value:
      return False
  return True