def round_and_sum(num_list):
  """
  Rounds every number of a given list of numbers and prints the total sum multiplied by the length of the list.
  """
  total_sum = 0
  for num in num_list:
    total_sum += round(num)
  print(total_sum * len(num_list))