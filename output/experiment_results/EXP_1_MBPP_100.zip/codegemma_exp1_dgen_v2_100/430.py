def parabola_directrix(a,b,c):
    if a == 0:
        raise ValueError("a cannot be zero")
    
    directrix = - (b**2 - 4*a*c) / (4*a)
    return directrix