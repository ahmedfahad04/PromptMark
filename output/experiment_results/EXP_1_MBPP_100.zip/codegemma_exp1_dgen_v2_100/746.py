import math

def sector_area(radius,angle):
  if angle > 360:
    return None
  else:
    area = (math.pi * radius**2 * angle) / 360
    return area