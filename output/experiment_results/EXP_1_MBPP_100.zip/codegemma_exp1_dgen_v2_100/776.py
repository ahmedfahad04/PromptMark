def count_vowels(s):
    vowels = 'aeiouAEIOU'
    count = 0
    for i in range(len(s)):
        if s[i] in vowels and (i == 0 or s[i - 1] not in vowels) and (i == len(s) - 1 or s[i + 1] not in vowels):
            count += 1
    return count