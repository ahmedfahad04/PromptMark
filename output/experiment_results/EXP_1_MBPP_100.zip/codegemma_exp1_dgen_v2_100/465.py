def drop_empty(dict):
  return {key: value for key, value in dict.items() if value is not None}