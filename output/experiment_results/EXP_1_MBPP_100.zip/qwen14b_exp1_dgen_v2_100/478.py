def remove_lowercase(input_string):
    return ''.join([char for char in input_string if char.isupper()])

# Test cases as provided
assert remove_lowercase("PYTHon") == 'PYTH'
assert remove_lowercase("FInD") == 'FID'
assert remove_lowercase("STRinG") == 'STRG'