def capital_words_spaces(text):
    result = ''
    for i, char in enumerate(text):
        if i > 0 and char.isupper():
            result += ' '
        result += char
    return result