def is_sublist(lst, sublst):
    if not sublst:
        return True
    for i in range(len(lst)):
        if lst[i] == sublst[0]:
            j = 1
            while (i + j) < len(lst) and j < len(sublst) and lst[i + j] == sublst[j]:
                j += 1
            if j == len(sublst):
                return True
    return False

# Test cases as requested
print(is_sublist([2,4,3,5,7], [3,7])) # Expected output: False
print(is_sublist([2,4,3,5,7], [4,3])) # Expected output: True
print(is_sublist([2,4,3,5,7], [1,6])) # Expected output: False