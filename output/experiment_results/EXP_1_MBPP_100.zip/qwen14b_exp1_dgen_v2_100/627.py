def find_First_Missing(nums):
    i = 0
    while i < len(nums) and nums[i] == i:
        i += 1
    return i