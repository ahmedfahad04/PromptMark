def extract_singly(list_of_lists):
    # Flatten the list of lists into a single set to remove duplicates
    return {number for sublist in list_of_lists for number in sublist}