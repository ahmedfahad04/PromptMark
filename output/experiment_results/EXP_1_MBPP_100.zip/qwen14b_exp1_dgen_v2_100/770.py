def odd_num_sum(n):
    total = 0
    for i in range(1, n * 2 + 1, 2):
        total += i ** 4
    return total

# Example usage (not part of the required output but shown for completeness)
# print(odd_num_sum(2))  # Output: 82
# print(odd_num_sum(3))  # Output: 707
# print(odd_num_sum(4))  # Output: 3108