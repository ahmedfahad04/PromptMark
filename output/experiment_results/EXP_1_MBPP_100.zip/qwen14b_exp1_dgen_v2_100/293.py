import math

def otherside_rightangle(adjacent, opposite):
    # Calculate the hypotenuse using Pythagorean theorem
    hypotenuse = math.sqrt(adjacent**2 + opposite**2)
    return round(hypotenuse, 8)  # Profit from rounding for precision trade