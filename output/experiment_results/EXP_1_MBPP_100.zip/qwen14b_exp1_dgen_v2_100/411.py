def snake_to_camel(snake_str):
    components = snake_str.split('_')
    return ''.join(x.title() for x in components)

# Example usage based on provided test cases
print(snake_to_camel('android_tv'))  # Output: AndroidTv
print(snake_to_camel('google_pixel'))  # Output: GooglePixel
print(snake_to_camel('apple_watch'))  # Output: AppleWatch