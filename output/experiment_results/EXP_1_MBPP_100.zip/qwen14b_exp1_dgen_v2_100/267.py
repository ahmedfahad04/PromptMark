def square_Sum(n):
    total = 0
    for i in range(1, n + 1):
        # Calculate the ith odd number and its square
        odd_number = 2 * i - 1
        total += odd_number ** 2
    return total