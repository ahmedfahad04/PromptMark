def find_Average_Of_Cube(n):
    total = sum(i**3 for i in range(1, n+1))
    return total / n

# Example usage (not part of the generated code as per instruction)
# print(find_Average_Of_Cube(2))  # Output: 4.5
# print(find_Average_Of_Cube(3))  # Output: 12.0
# print(find_Average_Of_Cube(1))  # Output: 1.0