def count_bidirectional(pairs):
    seen = set()
    trade_count = 0
    for pair in pairs:
        if pair[1], pair[0] in seen:
            trade_count += 1
            seen.remove((pair[1], pair[0]))
        else:
            seen.add(pair)
    return trade_count

# Example usage:
# result = count_bidirectional([(5, 6), (1, 2), (6, 5), (9, 1), (6, 5), (2, 1)])
# print(result) # Output should be 3