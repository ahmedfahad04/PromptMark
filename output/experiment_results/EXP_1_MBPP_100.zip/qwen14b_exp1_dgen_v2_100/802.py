def count_rotation(arr):
    n = len(arr)
    if n == 0:
        return 0
    for i in range(1, n):
        if arr[i] < arr[i - 1]:
            return i
    return 0