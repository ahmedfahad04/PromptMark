def average_tuple(tup):
    return [sum(sub_tup) / len(sub_tup) for sub_tup in tup]