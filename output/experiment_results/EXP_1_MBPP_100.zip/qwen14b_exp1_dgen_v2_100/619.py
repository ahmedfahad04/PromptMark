def move_num(s):
    digits = ''.join(filter(str.isdigit, s))
    non_digits = ''.join(filter(lambda x: not x.isdigit(), s))
    return non_digits + digits