def trim_tuple(lst, k):
    result = [tuple(t[k:len(t)-k]) for t in lst]
    return str(result)

# Example usage:
# trimmed_list = trim_tuple([(5, 3, 2, 1, 4), (3, 4, 9, 2, 1), (9, 1, 2, 3, 5), (4, 8, 2, 1, 7)], 2)