import math

def surface_Area(base_edge, height):
    slant_height = math.sqrt((height ** 2) + (base_edge ** 2) / 4)
    base_area = base_edge ** 2
    lateral_area = 2 * base_edge * slant_height
    return base_area + lateral_area

# Example usage:
# print(surface_Area(3, 4))