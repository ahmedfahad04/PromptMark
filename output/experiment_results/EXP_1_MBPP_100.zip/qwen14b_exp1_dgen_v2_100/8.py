def square_nums(numbers):
    return [num ** 2 for num in numbers]

# Example usage (not part of the original request, but provided for context)
result = square_nums([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
print(result)  # Output will be [1, 4, 9, 16, 25, 36, 49, 64, 81, 100] when printed