import re

def extract_quotation(text):
    return re.findall(r'"(.*?)"', text)

# Example usage:
print(extract_quotation('Cortex "A53" Based "multi" tasking "Processor"'))