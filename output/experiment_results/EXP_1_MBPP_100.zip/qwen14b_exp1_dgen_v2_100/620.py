def largest_subset(arr):
    arr.sort()
    n = len(arr)
    dp = [1] * n
    for i in range(1, n):
        for j in range(i):
            if arr[i] % arr[j] == 0:
                dp[i] = max(dp[i], dp[j] + 1)
    return max(dp)

# Example usage (not part of the generated response as per instruction):
# print(largest_subset([1, 3, 6, 13, 17, 18]))