def perimeter_pentagon(side_length):
    # Calculate the perimeter by multiplying side length by 5 (since a pentagon has 5 sides)
    return side_length * 5