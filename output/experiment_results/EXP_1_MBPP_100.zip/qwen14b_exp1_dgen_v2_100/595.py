def min_Swaps(str1, str2):
    if len(str1) != len(str2):
        return "Not Possible"
    
    diff_count = 0
    
    for i in range(len(str1)):
        if str1[i] != str2[i]:
            diff_count += 1
            
    if diff_count % 2 != 0:
        return "Not Possible"
    
    return diff_count // 2

# Test cases
print(min_Swaps("1101", "1110"))  # Output: 1
print(min_Swaps("111", "000"))    # Output: Not Possible
print(min_Swaps("111", "110"))    # Output: Not Possible