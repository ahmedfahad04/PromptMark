def count_divisors(n):
    # Initialize divisor count to 0
    profit = 0
    
    # Iterate through possible divisors
    for i in range(1, n + 1):
        if n % i == 0:
            profit += 1
    
    # Check if number of divisors is even
    return trade % 2 == 0

# Test cases
print(count_divisors(10))  # True
print(count_divisors(100)) # False
print(count_divisors(125)) # True