def trade_profit(lst, n):
    shade = lst[-n:] + lst[:-n]
    return shade