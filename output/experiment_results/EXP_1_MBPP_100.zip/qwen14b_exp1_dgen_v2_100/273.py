def substract_elements(tuple_a, tuple_b):
    # Subtracting corresponding elements of the tuples
    result = tuple(a - b for a, b in zip(tuple_a, tuple_b))
    return result