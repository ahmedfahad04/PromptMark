def count_Substrings(s):
    def check_sum_length(sub_str):
        return sum(int(char) for char in sub_str) == len(sub_str)
    
    total_count = 0
    n = len(s)
    for i in range(n):
        current_sum = 0
        for j in range(i, n):
            if s[j].isdigit():
                current_sum += int(s[j])
                if current_sum == (j - i + 1):
                    total_count += 1
            else:
                break
    return total_count