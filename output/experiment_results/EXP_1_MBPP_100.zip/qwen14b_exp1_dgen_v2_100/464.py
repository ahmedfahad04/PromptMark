def check_value(dict_obj, val):
    return all(v == val for v in dict_obj.values())