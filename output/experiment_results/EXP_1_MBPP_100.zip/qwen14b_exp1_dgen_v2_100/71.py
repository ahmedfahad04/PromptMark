def comb_sort(arr):
    shrink_factor = 1.3
    gap = len(arr)
    sorted_list = arr[:]
    swapped = True
    
    while gap > 1 or swapped:
        gap = max(1, int(gap / shrink_factor))
        swapped = False
        
        for i in range(len(sorted_list) - gap):
            j = i + gap
            
            if sorted_list[i] > sorted_list[j]:
                sorted_list[i], sorted_list[j] = sorted_list[j], sorted_list[i]
                swapped = True
                
    return sorted_list