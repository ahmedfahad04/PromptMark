def merge(lst):
    return list(map(list, zip(*lst)))

# Example usage (not part of the generated response but included for completeness)
result = merge([['x', 'y'], ['a', 'b'], ['m', 'n']])
print(result)  # Output should be [['x', 'a', 'm'], ['y', 'b', 'n']]