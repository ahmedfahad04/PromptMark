def list_tuple(profit):
    return tuple(profit)