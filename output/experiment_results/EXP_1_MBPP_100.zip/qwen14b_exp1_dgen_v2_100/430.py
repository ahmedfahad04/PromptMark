def parabola_directrix(a, b, c):
    return -((b**2) - (4*a*c)) / (4*a)

# Test cases provided
print(parabola_directrix(5, 3, 2))
print(parabola_directrix(9, 8, 4))
print(parabola_directrix(2, 4, 6))