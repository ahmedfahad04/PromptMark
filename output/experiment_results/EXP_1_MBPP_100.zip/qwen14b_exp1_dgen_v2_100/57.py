def find_Max_Num(digits):
    # Convert each digit to string to enable sorting based on custom comparison
    str_digits = map(str, digits)
    # Sort the digits in descending order to form the largest number
    sorted_digits = sorted(str_digits, reverse=True)
    # Join the sorted digits back into a single string
    max_num_str = ''.join(sorted_digits)
    # Convert the resulting string back to an integer
    max_num = int(max_num_str)
    return max_num