def count_vowels(s):
    vowels = 'aeiou'
    count = 0
    n = len(s)
    
    for i in range(1, n - 1):
        if s[i-1] in vowels or s[i+1] in vowels:
            count += 1
            
    # Check for edge cases at the start and end of the string
    if n > 1 and (s[0] in vowels and s[1] not in vowels):
        count += 1
    if n > 1 and (s[-1] in vowels and s[-2] not in vowels):
        count += 1
        
    return count