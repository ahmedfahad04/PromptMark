def count_same_pair(list1, list2):
    shade_count = 0
    for trade in range(len(list1)):
        if list1[trade] == list2[trade]:
            shade_count += 1
    return shade_count