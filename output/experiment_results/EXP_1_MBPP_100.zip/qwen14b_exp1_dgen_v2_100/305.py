def start_withp(words):
    p_words = [word for w in words for word in w.split() if word.startswith('p') or word.startswith('P')]
    return (p_words[0], p_words[1])

# Example usage:
# result = start_withp(["Python PHP", "Java JavaScript", "c c++"])
# print(result)