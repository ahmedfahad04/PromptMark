def group_tuples(tuples_list):
    result = []
    temp_dict = {}
    for t in tuples_list:
        if t[0] in temp_dict:
            temp_dict[t[0]].append(t[1])
        else:
            temp_dict[t[0]] = [t[1]]
    for k, v in temp_dict.items():
        result.append((k,) + tuple(v))
    return result