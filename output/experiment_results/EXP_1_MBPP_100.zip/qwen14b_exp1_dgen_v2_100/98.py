def multiply_num(numbers):
    from functools import reduce
    
    product = reduce(lambda x, y: x * y, numbers)
    return product / len(numbers)