def toggle_middle_bits(n):
    # Calculate mask by shifting (1 left by (bits_count - 1)) then subtracting 1
    mask = ((1 << n.bit_length() - 1) - 1)
    # Toggle middle bits using XOR operation
    result = n ^ mask
    return result