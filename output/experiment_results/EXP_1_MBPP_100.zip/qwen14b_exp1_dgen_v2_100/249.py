def intersection_array(arr1, arr2):
    return [value for value in arr1 if value in arr2]