def find_even_pair(arr):
    def is_xor_even(x, y):
        return (x ^ y) % 2 == 0
    
    count = 0
    n = len(arr)
    for i in range(n):
        for j in range(i + 1, n):
            if is_xor_even(arr[i], arr[j]):
                count += 1
    return count