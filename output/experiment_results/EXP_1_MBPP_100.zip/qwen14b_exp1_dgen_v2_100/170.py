def sum_range_list(numbers, start_index, end_index):
    # Calculate the sum of elements from start_index to end_index (inclusive)
    return sum(numbers[start_index:end_index+1])