def common_in_nested_lists(nested_lists):
    # Initialize the intersection set with the first list
    common_elements = set(nested_lists[0]) if nested_lists else set()
    
    # Iterate through each subsequent list
    for sublist in nested_lists[1:]:
        # Update the intersection set with the common elements of this sublist
        common_elements &= set(sublist)
        
    return list(common_elements)

# Example usage (not part of the generated solution as per instruction)
# result = common_in_nested_lists([[12, 18, 23, 25, 45], [7, 12, 18, 24, 28], [1, 5, 8, 12, 15, 16, 18]])
# print(result)  # Output should be [18, 12]