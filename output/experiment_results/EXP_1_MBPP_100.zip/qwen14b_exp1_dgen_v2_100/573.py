def unique_product(numbers):
    # Use set comprehension to filter out duplicate values from the list
    unique_numbers = {number for number in numbers}
    # Calculate the product using reduce with multiplication lambda function
    import functools
    result = functools.reduce(lambda x, y: x * y, unique_numbers)
    return result