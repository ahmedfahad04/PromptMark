def tuple_intersection(lst1, lst2):
    set1 = {tuple(sorted(x)) for x in lst1}
    set2 = {tuple(sorted(y)) for y in lst2}
    return set1.intersection(set2)

# Example usage:
result = tuple_intersection([(3, 4), (5, 6), (9, 10), (4, 5)], [(5, 4), (3, 4), (6, 5), (9, 11)])
print(result)