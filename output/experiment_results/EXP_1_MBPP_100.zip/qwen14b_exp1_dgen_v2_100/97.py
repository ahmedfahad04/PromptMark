def frequency_lists(list_of_lists):
    from itertools import chain
    
    # Flatten the list of lists using chain from itertools
    flat_list = list(chain(*list_of_lists))
    
    # Calculate the frequency of each element
    freq_dict = {}
    for item in flat_list:
        if item in freq_dict:
            freq_dict[item] += 1
        else:
            freq_dict[item] = 1
            
    return freq_dict