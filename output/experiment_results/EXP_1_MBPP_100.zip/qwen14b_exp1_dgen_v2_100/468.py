def max_product(nums):
    n = len(nums)
    if n < 2:
        return nums[0] if n else 0
    
    # Initialize two arrays
    inc_subseq_ending_here = [num for num in nums]
    dec_subseq_ending_here = [num for num in nums]
    
    max_product_value = float('-inf')
    
    for i in range(n):
        for j in range(i):
            if nums[i] > nums[j]:
                inc_subseq_ending_here[i] = max(inc_subseq_ending_here[i], nums[i] * inc_subseq_ending_here[j])
                dec_subseq_ending_here[i] = min(dec_subseq_ending_here[i], nums[i] * dec_subseq_ending_here[j])
                
        max_product_value = max(max_product_value, inc_subseq_ending_here[i], -dec_subseq_ending_here[i] * nums[i])
        
    return int(max_product_value)

# Example usage (not part of the required solution but included for demonstration purposes)
print(max_product([3, 100, 4, 5, 150, 6]))  # Output should be 3000
print(max_product([4, 42, 55, 68, 80]))      # Output should be 50265600
print(max_product([10, 22, 9, 33, 21, 50, 41, 60]))  # Output should be 2460