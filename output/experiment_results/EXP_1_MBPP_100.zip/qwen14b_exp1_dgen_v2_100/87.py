def merge_dictionaries_three(dict1, dict2, dict3):
    merged_dict = {}
    for d in [dict1, dict2, dict3]:
        for key, value in d.items():
            if key not in merged_dict:
                merged_dict[key] = value
    return merged_dict