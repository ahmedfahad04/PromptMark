def pair_wise(lst):
    # Generate pairs of consecutive items using zip and slicing
    return list(zip(lst, lst[1:]))

# Example usage:
result = pair_wise([1, 1, 2, 3, 3, 4, 4, 5])
print(result)