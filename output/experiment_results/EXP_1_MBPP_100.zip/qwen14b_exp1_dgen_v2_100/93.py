def power(a, b):
    if b == 0:
        return 1
    else:
        return a * power(a, b - 1)

# Example usage (not part of the generated solution as per instruction):
# print(power(3, 4))  # Output: 81
# print(power(2, 3))  # Output: 8
# print(power(5, 5))  # Output: 3125