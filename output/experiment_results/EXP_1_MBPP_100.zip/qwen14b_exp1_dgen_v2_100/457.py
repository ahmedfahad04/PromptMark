def Find_Min(lists):
    return min(lists, key=len)

# Test cases provided
print(Find_Min([[1], [1, 2], [1, 2, 3]]))  # Output: [1]
print(Find_Min([[1, 1], [1, 1, 1], [1, 2, 7, 8]]))  # Output: [1, 1]
print(Find_Min([['x'], ['x', 'y'], ['x', 'y', 'z']]))  # Output: ['x']