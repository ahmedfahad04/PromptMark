def find_Element(arr, rotations, target_index, num_rotations):
    # Calculate effective rotations based on total rotations modulo length of array
    effective_rotations = num_rotations % len(arr)
    
    # Apply each rotation in the list up to the calculated effective rotations
    for _ in range(effective_rotations):
        arr.insert(0, arr.pop())
    
    # Return the element at the specified target index
    return arr[target_index]

# Example usage (not part of the generated solution as per instruction):
# print(find_Element([1,2,3,4,5], [[0,2], [0,3]], 2, 1))
# print(find_Element([1,2,3,4], [[0,1], [0,2]], 1, 2))
# print(find_Element([1,2,3,4,5,6], [[0,1], [0,2]], 1, 1))