def median_trapezium(base1, base2, height):
    return (base1 + base2) / 2

# Example usage based on provided test cases
print(median_trapezium(15, 25, 35))  # Output should be 20
print(median_trapezium(10, 20, 30))  # Output should be 15
print(median_trapezium(6, 9, 4))     # Output should be 7.5