def sequence(n):
    if n <= 0:
        return None
    elif n == 1 or n == 2:
        return 1
    
    result = [0] * (n + 1)
    result[1], result[2] = 1, 1
    
    for i in range(3, n + 1):
        result[i] = result[result[i - 1]] + result[i - result[i - 1]]
    
    return result[n]

# Example usage:
print(sequence(10))  # Output should be 6
print(sequence(2))   # Output should be 1
print(sequence(3))   # Output should be 2