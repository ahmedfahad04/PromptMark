def find_even_numbers(numbers):
    return [num for num in numbers if num % 2 == 0]

# Example usage (not part of the generated solution as per instructions)
# result = find_even_numbers([1, 2, 3, 4, 5])
# print(result)  # Output should be [2, 4]