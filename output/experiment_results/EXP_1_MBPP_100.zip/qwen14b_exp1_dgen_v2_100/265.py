def list_split(lst, n):
    split_lists = [[] for _ in range(n)]
    for i, item in enumerate(lst):
        split_lists[i % n].append(item)
    return split_lists