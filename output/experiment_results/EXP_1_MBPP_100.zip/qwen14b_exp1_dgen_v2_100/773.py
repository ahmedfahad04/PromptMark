def occurance_substring(main_string, substring):
    index = main_string.find(substring)
    if index == -1:
        return None
    else:
        return (substring, index, index + len(substring))

# Example usage based on test cases provided:
print(occurance_substring('python programming, python language', 'python'))
print(occurance_substring('python programming,programming language', 'programming'))
print(occurance_substring('python programming,programming language', 'language'))
print(occurance_substring('c++ programming, c++ language', 'python'))