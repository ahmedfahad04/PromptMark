import cmath

def polar_rect(rho, theta):
    # Convert polar coordinates (rho, theta) to rectangular coordinates (x + yj)
    z = complex(rho * cmath.cos(theta), rho * cmath.sin(theta))
    return (abs(z), cmath.phase(z)), z