def remove_Occ(s, char):
    first_occurrence = s.find(char)
    # Find the index of the second occurrence after removing the first one
    if first_occurrence != -1:
        updated_string = s[first_occurrence+1:]
        second_occurrence = updated_string.find(char) + len(s) - len(updated_string)
        return s[:first_occurrence] + s[first_occurrence+1:second_occurrence] + s[second_occurrence+1:] if second_occurrence != first_occurrence else s[:first_occurrence] + s[first_occurrence+1:]
    return s